export const creTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: GOD'S CREATION (7 Materials) ---
  {
    id: "G1-CRE-CRE-01",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Creation",
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: "According to the Bible in the book of Genesis, who created the world and everything in it, including the sun, the moon, and the animals?,
      options: ["God, Adam", "Noah, Moses"].sort(() => Math.random() - 0.5),
      correctAnswer: "God
    })
  },
  {
    id: G1-CRE-CRE-02",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "God's Creation,
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " In the story of creation, God spoke and different things came into being. Which of the following did God create on the very first day?,
      options: [Light, Water, Plants", "Animals].sort(() => Math.random() - 0.5),
      correctAnswer: Light"
    })
  },
  {
    id: "G1-CRE-CRE-03",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Creation",
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: "God made the sun to shine during the day and the moon and stars to give light at night. What do we call the time when the sun shines?,
      options: [Daytime, Nighttime, "Evening, Midnight"].sort(() => Math.random() - 0.5),
      correctAnswer: "Daytime
    })
  },
  {
    id: G1-CRE-CRE-04",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "God's Creation,
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " God created fish to live in the water and birds to fly in the sky. On which day did God create the fish and birds according to Genesis?,
      options: [The fifth day, The fourth day, The sixth day", "The first day].sort(() => Math.random() - 0.5),
      correctAnswer: The fifth day"
    })
  },
  {
    id: "G1-CRE-CRE-05",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Creation",
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: "God created land animals and also created the first people, Adam and Eve. On which day did God create the first human beings?,
      options: [The sixth day, The fifth day", "The fourth day, The seventh day"].sort(() => Math.random() - 0.5),
      correctAnswer: "The sixth day
    })
  },
  {
    id: G1-CRE-CRE-06",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "God's Creation,
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " After God finished creating the world, He looked at everything He had made and said it was good. On which day did God rest from all His work?,
      options: [The seventh day, The sixth day, The fifth day", "The first day].sort(() => Math.random() - 0.5),
      correctAnswer: The seventh day"
    })
  },
  {
    id: "G1-CRE-CRE-07",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Creation",
    subtopic: "The World and Everything in It",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "The Bible teaches us that everything God created was made with love and purpose. How should we treat the world and everything in it that God made?,
      options: [We should take care of it., We should destroy it., "We should ignore it., We should throw it away."].sort(() => Math.random() - 0.5),
      correctAnswer: "We should take care of it.
    })
  },

  // --- MADA: GOD'S LOVE (4 Materials) ---
  {
    id: G1-CRE-LOV-01",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "God's Love,
    subtopic: "God Loves All People",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The Bible tells us in John 3:16 that God loved the world so much that He gave His one and only Son. What does this verse teach us about God?,
      options: [God loves us very much., God is very angry., God is far away.", "God does not care.].sort(() => Math.random() - 0.5),
      correctAnswer: God loves us very much."
    })
  },
  {
    id: "G1-CRE-LOV-02",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Love",
    subtopic: "God Loves All People,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Because God loves us, He sent Jesus to show us how to live. How does knowing that God loves us make us feel inside?,
      options: [Safe and cared for, Scared and lonely", "Angry and sad, Tired and bored"].sort(() => Math.random() - 0.5),
      correctAnswer: "Safe and cared for
    })
  },
  {
    id: G1-CRE-LOV-03",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "God's Love,
    subtopic: "God Loves All People",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " God's love is unconditional, which means He loves us no matter what we do. How should we respond to God's great love for us?,
      options: [We should love Him back., We should ignore Him., We should run away.", "We should be angry.].sort(() => Math.random() - 0.5),
      correctAnswer: We should love Him back."
    })
  },
  {
    id: "G1-CRE-LOV-04",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "God's Love",
    subtopic: "God Loves All People,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Jesus taught that we should love one another just as God loves us. Which of the following is a way to show love to our friends?,
      options: [Sharing our toys with them., Taking their toys away., "Ignoring them when they are sad., Pushing them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sharing our toys with them.
    })
  },

  // --- MADA: THE BIBLE (4 Materials) ---
  {
    id: G1-CRE-BIB-01",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is God's Word",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The Bible is the holy book of Christians. It is divided into two main parts. What are these two parts called?,
      options: [The Old Testament and The New Testament, The Old Book and The New Book, The First Book and The Second Book", "The History Book and The Story Book].sort(() => Math.random() - 0.5),
      correctAnswer: The Old Testament and The New Testament"
    })
  },
  {
    id: "G1-CRE-BIB-02",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is God's Word,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The Old Testament tells the story of the people of Israel before Jesus was born. It includes books like Genesis and Exodus. What does the New Testament tell us about?,
      options: [The life and teachings of Jesus, The story of creation, "The journey to the Promised Land, The building of the Temple"].sort(() => Math.random() - 0.5),
      correctAnswer: "The life and teachings of Jesus
    })
  },
  {
    id: G1-CRE-BIB-03",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is God's Word",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The Bible teaches us many important things about how to live our lives. Where should we go to learn more about what the Bible says?,
      options: [A church or Bible study group, A restaurant, A football field", "A shopping mall].sort(() => Math.random() - 0.5),
      correctAnswer: A church or Bible study group"
    })
  },
  {
    id: "G1-CRE-BIB-04",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is God's Word,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We believe the Bible is inspired by God and gives us guidance for our daily lives. How can reading the Bible help a Christian?,
      options: [It teaches them how to live a good and pleasing life., It teaches them how to cook., "It teaches them how to play games., It teaches them how to build houses."].sort(() => Math.random() - 0.5),
      correctAnswer: "It teaches them how to live a good and pleasing life.
    })
  },

  // --- MADA: JESUS (5 Materials) ---
  {
    id: G1-CRE-JES-01",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is God's Son",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Christians believe that Jesus is the Son of God. He came to Earth to teach us about God's love. In which city was Jesus born according to the Bible?,
      options: [Bethlehem, Nairobi, Jerusalem", "Nazareth].sort(() => Math.random() - 0.5),
      correctAnswer: Bethlehem"
    })
  },
  {
    id: "G1-CRE-JES-02",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is God's Son,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Jesus was born to a woman named Mary. An angel appeared to Mary to tell her she would have a special baby. Who is the father of Jesus according to Christian belief?,
      options: [God, Joseph, "David, Peter"].sort(() => Math.random() - 0.5),
      correctAnswer: "God
    })
  },
  {
    id: G1-CRE-JES-03",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is God's Son",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " When Jesus was a baby, His parents took Him to the temple. There, a man named Simeon saw Jesus and praised God. Who was Simeon?,
      options: [A righteous and devout man, A Roman soldier, A fisherman", "A tax collector].sort(() => Math.random() - 0.5),
      correctAnswer: A righteous and devout man"
    })
  },
  {
    id: "G1-CRE-JES-04",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is God's Son,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "When Jesus was a boy, He grew in wisdom and stature. He often went to the temple to learn about God. How did people react to Jesus when He was just 12 years old?,
      options: [They were amazed by His understanding., They were angry with Him.", "They ignored Him., They laughed at Him."].sort(() => Math.random() - 0.5),
      correctAnswer: "They were amazed by His understanding.
    })
  },
  {
    id: G1-CRE-JES-05",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is God's Son",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus grew up to be a teacher and a healer. He chose 12 special men to help Him in His work. What were these 12 men called?,
      options: [The Apostles, The Pharisees, The Sadducees", "The Romans].sort(() => Math.random() - 0.5),
      correctAnswer: The Apostles"
    })
  },

  // --- MADA: THE CHURCH (4 Materials) ---
  {
    id: "G1-CRE-CHU-01",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church is God's Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "The Church is not just a building; it is the people who follow Jesus. The Church is also known as God's family. Who is the head of the Church according to the Bible?,
      options: [Jesus Christ, The Pope, "The Pastor, The Bishop"].sort(() => Math.random() - 0.5),
      correctAnswer: "Jesus Christ
    })
  },
  {
    id: G1-CRE-CHU-02",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church is God's Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Christians gather together in the Church to worship God, pray, and learn from the Bible. What do we call the day when Christians go to Church to worship?,
      options: [Sunday, Monday, Saturday", "Friday].sort(() => Math.random() - 0.5),
      correctAnswer: Sunday"
    })
  },
  {
    id: "G1-CRE-CHU-03",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church is God's Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "When Christians gather in Church, they often sing songs of praise to God. What is another important thing Christians do when they meet together?,
      options: [They pray to God., They watch TV.", "They eat only., They play games."].sort(() => Math.random() - 0.5),
      correctAnswer: "They pray to God.
    })
  },
  {
    id: G1-CRE-CHU-04",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church is God's Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Belonging to the Church helps Christians support one another and grow in their faith. How should members of the Church treat each other?,
      options: [With love and kindness, With anger and harshness, With indifference", "With greed].sort(() => Math.random() - 0.5),
      correctAnswer: With love and kindness"
    })
  },

  // --- MADA: PRAYER (4 Materials) ---
  {
    id: "G1-CRE-PRA-01",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "Talking to God,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Prayer is the way Christians talk to God. Why is prayer important in the life of a Christian?,
      options: [It helps them communicate with God., It is a way to get food., "It is a way to get money., It is a game."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps them communicate with God.
    })
  },
  {
    id: G1-CRE-PRA-02",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "Talking to God",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Jesus taught His disciples a special prayer known as the Lord's Prayer. How does the Lord's Prayer begin?,
      options: [Our Father who art in heaven..., Thank you God..., I am sorry...", "Please God...].sort(() => Math.random() - 0.5),
      correctAnswer: Our Father who art in heaven..."
    })
  },
  {
    id: "G1-CRE-PRA-03",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "Talking to God,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Christians pray to God for different reasons, such as asking for help, thanking Him, and seeking forgiveness. What should we do when we pray to God?,
      options: ["We should talk to Him honestly., We should demand things.", "We should talk to Him as if He is a stranger., We should pray only when we are in trouble."].sort(() => Math.random() - 0.5),
      correctAnswer: "We should talk to Him honestly.
    })
  },
  {
    id: G1-CRE-PRA-04",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "Talking to God",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We can pray to God anywhere and at any time. Besides at home or in Church, where else can a Christian pray?,
      options: [Anywhere they want to talk to God., Only in the bathroom., Only on the bus.", "Only in the kitchen.].sort(() => Math.random() - 0.5),
      correctAnswer: Anywhere they want to talk to God."
    })
  },

  // --- MADA: THANKFULNESS (3 Materials) ---
  {
    id: "G1-CRE-THA-01",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Thankfulness",
    subtopic: "Thanking God for His Gifts,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "God gives us many good things every day, like food, family, and friends. How should we respond to God's gifts?,
      options: ["We should thank Him., We should keep them to ourselves.", "We should complain., We should ignore Him."].sort(() => Math.random() - 0.5),
      correctAnswer: "We should thank Him.
    })
  },
  {
    id: G1-CRE-THA-02",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Thankfulness,
    subtopic: "Thanking God for His Gifts",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We can thank God through our words and actions. Which of the following is a way to show thankfulness to God?,
      options: [Singing a song of praise to Him., Being greedy., Being rude to others.", "Throwing away food.].sort(() => Math.random() - 0.5),
      correctAnswer: Singing a song of praise to Him."
    })
  },
  {
    id: "G1-CRE-THA-03",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Thankfulness",
    subtopic: "Thanking God for His Gifts,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The Bible tells us to give thanks to the Lord for He is good. When is a good time to thank God for His blessings?,
      options: [Every day., Only on Sundays., "Only on Christmas., Only when we receive a gift."].sort(() => Math.random() - 0.5),
      correctAnswer: "Every day.
    })
  },

  // --- MADA: HELPING OTHERS (4 Materials) ---
  {
    id: G1-CRE-HEL-01",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Helping Others,
    subtopic: "Sharing and Caring",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " God teaches us to help those who are in need. Which of the following is a way to help someone who is hungry?,
      options: [Sharing food with them., Ignoring them., Taking their food.", "Pushing them.].sort(() => Math.random() - 0.5),
      correctAnswer: Sharing food with them."
    })
  },
  {
    id: "G1-CRE-HEL-02",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Helping Others",
    subtopic: "Sharing and Caring,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "In the Bible, Jesus told a story about a Good Samaritan who helped a man who was hurt. What lesson do we learn from the Good Samaritan?,
      options: [We should help everyone in need., We should only help our friends.", "We should not help strangers., We should ignore people who are hurt."].sort(() => Math.random() - 0.5),
      correctAnswer: "We should help everyone in need.
    })
  },
  {
    id: G1-CRE-HEL-03",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Helping Others,
    subtopic: "Sharing and Caring",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Helping others is a way of showing God's love to the world. What reward does the Bible promise to those who help others generously?,
      options: [They will be blessed by God., They will become very rich., They will never be tired.", "They will never need help.].sort(() => Math.random() - 0.5),
      correctAnswer: They will be blessed by God."
    })
  },
  {
    id: "G1-CRE-HEL-04",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Helping Others",
    subtopic: "Sharing and Caring,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We can help others not just with food, but also by being kind. How can we show kindness to someone at school who is feeling sad?,
      options: [By being their friend and listening to them., By laughing at them.", "By ignoring them., By taking their things."].sort(() => Math.random() - 0.5),
      correctAnswer: "By being their friend and listening to them.
    })
  },

  // --- MADA: FORGIVENESS (3 Materials) ---
  {
    id: G1-CRE-FOR-01",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Forgiveness,
    subtopic: "Saying Sorry and Forgiving Others",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The Bible teaches us that we should forgive others when they hurt us, just as God forgives us. What is the best thing to do when someone says sorry to you?,
      options: [Forgive them from the heart., Hold a grudge against them., Never talk to them again.", "Tell everyone what they did.].sort(() => Math.random() - 0.5),
      correctAnswer: Forgive them from the heart."
    })
  },
  {
    id: "G1-CRE-FOR-02",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "Forgiveness",
    subtopic: "Saying Sorry and Forgiving Others,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Jesus taught Peter that we should forgive others not just once, but many times. How many times should we forgive someone who asks for forgiveness?,
      options: [Seventy-seven times, Seven times", "Once, Ten times"].sort(() => Math.random() - 0.5),
      correctAnswer: "Seventy-seven times
    })
  },
  {
    id: G1-CRE-FOR-03",
    grade: "Grade 1,
    subject: Christian Religious Education",
    topic: "Forgiveness,
    subtopic: "Saying Sorry and Forgiving Others",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " When we ask God for forgiveness, He is always ready to forgive us because He is merciful. How should we treat people who have wronged us?,
      options: [We should forgive them as God forgives us., We should seek revenge., We should ignore them.", "We should report them to the police.].sort(() => Math.random() - 0.5),
      correctAnswer: We should forgive them as God forgives us."
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (1 Material) ---
  {
    id: "G1-CRE-TEN-01",
    grade: "Grade 1",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Rules for Living,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "God gave Moses a set of rules to help the people live good lives. These rules are called the Ten Commandments. Where did Moses receive the Ten Commandments?,
      options: [On Mount Sinai, In a river, "In a cave, In a house"].sort(() => Math.random() - 0.5),
      correctAnswer: "On Mount Sinai
    })
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE CREATION STORY (5 Materials) ---
  {
    id: G2-CRE-CRE-01",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Creation Story,
    subtopic: "How God Created the World in 7 Days",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " In the very beginning, God created everything in six days and rested on the seventh day. What is the seventh day called when God rested from all His work?,
      options: [The Sabbath, The Creation Day, The Rest Day", "The Holy Day].sort(() => Math.random() - 0.5),
      correctAnswer: The Sabbath"
    })
  },
  {
    id: "G2-CRE-CRE-02",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Creation Story",
    subtopic: "How God Created the World in 7 Days,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "On the fourth day of creation, God made lights in the sky to separate day from night. What lights did God place in the sky?,
      options: [The sun and the moon, The stars and the clouds", "The rainbow and the sun, The moon and the stars"].sort(() => Math.random() - 0.5),
      correctAnswer: "The sun and the moon
    })
  },
  {
    id: G2-CRE-CRE-03",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Creation Story,
    subtopic: "How God Created the World in 7 Days",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " On the third day, God created dry land and vegetation. He made all kinds of trees, plants, and flowers. What did God call the dry land?,
      options: [Earth, Sea, Sky", "Mountain].sort(() => Math.random() - 0.5),
      correctAnswer: Earth"
    })
  },
  {
    id: "G2-CRE-CRE-04",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Creation Story",
    subtopic: "How God Created the World in 7 Days,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "On the fifth day, God created creatures that swim in the water and creatures that fly in the sky. Which of the following creatures did God create on this day?,
      options: [Fish and birds, Lions and tigers", "Cows and goats, Snakes and worms"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fish and birds
    })
  },
  {
    id: G2-CRE-CRE-05",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Creation Story,
    subtopic: "How God Created the World in 7 Days",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " On the sixth day, God created the first man and the first woman. He made them in His own image. What were the names of the first man and the first woman?,
      options: [Adam and Eve, Moses and Miriam, Abraham and Sarah", "David and Bathsheba].sort(() => Math.random() - 0.5),
      correctAnswer: Adam and Eve"
    })
  },

  // --- MADA: THE FAMILY (4 Materials) ---
  {
    id: "G2-CRE-FAM-01",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Family",
    subtopic: "God Created Families,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "God created the family to be a source of love and support. Who are the main people in a family?,
      options: [Father, mother, and children, Teachers and students, "Doctors and nurses, Pastors and church members"].sort(() => Math.random() - 0.5),
      correctAnswer: "Father, mother, and children
    })
  },
  {
    id: G2-CRE-FAM-02",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Family,
    subtopic: "God Created Families",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " God's plan for the family is that it should be a place of love and learning. According to the Bible, what responsibility do parents have toward their children?,
      options: [To love and teach them, To feed and clothe them, To discipline and guide them", "All of the above].sort(() => Math.random() - 0.5),
      correctAnswer: All of the above"
    })
  },
  {
    id: "G2-CRE-FAM-03",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Family",
    subtopic: "God Created Families,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Children have a responsibility to obey and respect their parents. Which commandment in the Bible tells children to honor their father and mother?,
      options: [The fifth commandment, The first commandment, "The second commandment, The tenth commandment"].sort(() => Math.random() - 0.5),
      correctAnswer: "The fifth commandment
    })
  },
  {
    id: G2-CRE-FAM-04",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Family,
    subtopic: "God Created Families",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The family is the first place we learn about God's love. How can we show appreciation to our family for the love they give us?,
      options: [By helping with household chores, By ignoring them, By demanding more", "By being rude].sort(() => Math.random() - 0.5),
      correctAnswer: By helping with household chores"
    })
  },

  // --- MADA: THE BIBLE (4 Materials) ---
  {
    id: "G2-CRE-BIB-01",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Old Testament and The New Testament,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The Bible is made up of many books written by different people over many centuries. How is the Bible divided into two main sections?,
      options: [The Old Testament and the New Testament, The Old Book and the New Book, "The First Part and the Second Part, The Law and the Prophets"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Old Testament and the New Testament
    })
  },
  {
    id: G2-CRE-BIB-02",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Old Testament and The New Testament",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Old Testament contains the first 39 books of the Bible. It includes the story of creation, the exodus, and the prophets. Who is the main leader in the Old Testament who was given the Ten Commandments?,
      options: [Moses, Abraham, David", "Joseph].sort(() => Math.random() - 0.5),
      correctAnswer: Moses"
    })
  },
  {
    id: "G2-CRE-BIB-03",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Old Testament and The New Testament,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The New Testament is the second part of the Bible. It tells the story of Jesus Christ and the early church. Who is the central figure of the New Testament?,
      options: [Jesus Christ, The Apostle Paul, "Peter, John the Baptist"].sort(() => Math.random() - 0.5),
      correctAnswer: "Jesus Christ
    })
  },
  {
    id: G2-CRE-BIB-04",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Old Testament and The New Testament",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The Bible is the most important book for Christians because it reveals God's character and His plan for humanity. How should Christians treat the Bible?,
      options: [They should read it regularly, They should ignore it, They should keep it hidden", "They should throw it away].sort(() => Math.random() - 0.5),
      correctAnswer: They should read it regularly"
    })
  },

  // --- MADA: JESUS (5 Materials) ---
  {
    id: "G2-CRE-JES-01",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus Grew Up Like Us,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Jesus was born in a humble stable in Bethlehem. He grew up in the town of Nazareth with His mother Mary and His earthly father Joseph. What job did Joseph have?,
      options: [A carpenter, A fisherman, "A soldier, A priest"].sort(() => Math.random() - 0.5),
      correctAnswer: "A carpenter
    })
  },
  {
    id: G2-CRE-JES-02",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus Grew Up Like Us",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Even though Jesus was God's Son, He still had to learn and grow just like us. What does the Bible say about how Jesus grew as a child?,
      options: [He grew in wisdom and stature, He grew very rich, He grew to be strong", "He grew tall and famous].sort(() => Math.random() - 0.5),
      correctAnswer: He grew in wisdom and stature"
    })
  },
  {
    id: "G2-CRE-JES-03",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus Grew Up Like Us,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "When Jesus was 12 years old, His parents took Him to Jerusalem for a festival. He stayed in the temple to listen to and ask questions of the teachers. What did everyone think of Jesus?,
      options: [They were amazed at His understanding, They were angry", "They were scared, They were indifferent"].sort(() => Math.random() - 0.5),
      correctAnswer: "They were amazed at His understanding
    })
  },
  {
    id: G2-CRE-JES-04",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus Grew Up Like Us",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus had a special mission when He grew up. He went around teaching about God's love and performing miracles. What was the main message of Jesus' teaching?,
      options: [Repent and believe in the gospel, Make money, Fight the Romans", "Become famous].sort(() => Math.random() - 0.5),
      correctAnswer: Repent and believe in the gospel"
    })
  },
  {
    id: "G2-CRE-JES-05",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus Grew Up Like Us,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Before Jesus began His ministry, He was baptized by a prophet who lived in the wilderness. This prophet prepared the way for Jesus by calling people to repentance. Who was this prophet?,
      options: [John the Baptist, Isaiah", "Jeremiah, Elijah"].sort(() => Math.random() - 0.5),
      correctAnswer: "John the Baptist
    })
  },

  // --- MADA: JESUS' MIRACLES (4 Materials) ---
  {
    id: G2-CRE-MIR-01",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus Healed the Sick",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus performed many miracles to show that He was the Son of God. One time, He healed a man who was paralyzed. What did Jesus say to the paralyzed man?,
      options: [Get up and walk, Stay where you are, You will heal tomorrow", "Ask the priest].sort(() => Math.random() - 0.5),
      correctAnswer: Get up and walk"
    })
  },
  {
    id: "G2-CRE-MIR-02",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus Healed the Sick,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Another miracle Jesus performed was feeding a crowd of thousands of people with only five loaves of bread and two fish. How many people did Jesus feed?,
      options: [Five thousand, One thousand, "Ten thousand, One hundred"].sort(() => Math.random() - 0.5),
      correctAnswer: "Five thousand
    })
  },
  {
    id: G2-CRE-MIR-03",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus Healed the Sick",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus once calmed a storm with just His words. The wind and the waves obeyed Him. What does this miracle show us about Jesus?,
      options: [He has power over nature, He is a great fisherman, He loves storms", "He is a good teacher].sort(() => Math.random() - 0.5),
      correctAnswer: He has power over nature"
    })
  },
  {
    id: "G2-CRE-MIR-04",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus Healed the Sick,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Jesus performed many miracles during His time on Earth. The people were amazed and many believed in Him because of what they saw. What can we learn from Jesus' miracles?,
      options: [God can do all things, Jesus was a magician, "Miracles are impossible, Jesus was just a man"].sort(() => Math.random() - 0.5),
      correctAnswer: "God can do all things
    })
  },

  // --- MADA: THE CHURCH (3 Materials) ---
  {
    id: G2-CRE-CHU-01",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "Going to Church and Worshipping God",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Christians gather together in the Church to worship God. Why is going to Church important for a Christian?,
      options: [To pray and learn about God, To play games, To eat together", "To watch movies].sort(() => Math.random() - 0.5),
      correctAnswer: To pray and learn about God"
    })
  },
  {
    id: "G2-CRE-CHU-02",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "Going to Church and Worshipping God,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "When Christians go to Church, they participate in various activities. Which of the following activities do Christians do in Church?,
      options: [Singing hymns and praying, Doing homework", "Watching TV, Sleeping"].sort(() => Math.random() - 0.5),
      correctAnswer: "Singing hymns and praying
    })
  },
  {
    id: G2-CRE-CHU-03",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "Going to Church and Worshipping God",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The Church is the body of Christ, and every member has a role to play. How can members of the Church help one another?,
      options: [By praying for each other, By ignoring one another, By competing with each other", "By judging one another].sort(() => Math.random() - 0.5),
      correctAnswer: By praying for each other"
    })
  },

  // --- MADA: PRAYER (3 Materials) ---
  {
    id: "G2-CRE-PRA-01",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "How to Pray,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Prayer is how Christians talk to God. When we pray, we can talk to God about anything. What is the correct way to begin a prayer?,
      options: [Addressing God as 'Our Father', Asking for money", "Complaining, Telling God what to do"].sort(() => Math.random() - 0.5),
      correctAnswer: "Addressing God as 'Our Father'
    })
  },
  {
    id: G2-CRE-PRA-02",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "How to Pray",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " In prayer, we can express our gratitude, confession, and needs to God. Which of the following is a good thing to include in prayer?,
      options: [Thanking God for His blessings, Only asking for things, Repeating the same words always", "Praying only at night].sort(() => Math.random() - 0.5),
      correctAnswer: Thanking God for His blessings"
    })
  },
  {
    id: "G2-CRE-PRA-03",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "How to Pray,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Jesus taught his disciples a model prayer that includes praising God, asking for daily needs, and seeking forgiveness. What is this prayer called?,
      options: ["The Lord's Prayer, The Shema", "The Hail Mary, The Apostle's Creed"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Lord's Prayer
    })
  },

  // --- MADA: LOVE (3 Materials) ---
  {
    id: G2-CRE-LOV-01",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Love,
    subtopic: "Loving God and Loving Others",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The Bible teaches that the greatest commandment is to love God with all our heart, soul, and mind. What is the second greatest commandment?,
      options: [Love your neighbor as yourself, Love your family only, Love your church", "Love your pastor].sort(() => Math.random() - 0.5),
      correctAnswer: Love your neighbor as yourself"
    })
  },
  {
    id: "G2-CRE-LOV-02",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Love",
    subtopic: "Loving God and Loving Others,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Jesus gave a new commandment that we should love one another as He has loved us. What is the best way to show love to others?,
      options: [By being kind and helping them, By ignoring them, "By being selfish, By judging them"].sort(() => Math.random() - 0.5),
      correctAnswer: "By being kind and helping them
    })
  },
  {
    id: G2-CRE-LOV-03",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Love,
    subtopic: "Loving God and Loving Others",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The Bible says that love is patient and kind. It is not jealous or boastful. Who is the perfect example of love according to the Bible?,
      options: [God, The angels, The prophets", "The apostles].sort(() => Math.random() - 0.5),
      correctAnswer: God"
    })
  },

  // --- MADA: OBEDIENCE (3 Materials) ---
  {
    id: "G2-CRE-OBE-01",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Obedience",
    subtopic: "Obeying Parents and Teachers,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "God commands children to obey their parents and teachers. Why is it important to obey our parents and teachers?,
      options: [Because they love us and want the best for us, Because they are bigger than us, "Because they pay for things, Because they force us"].sort(() => Math.random() - 0.5),
      correctAnswer: "Because they love us and want the best for us
    })
  },
  {
    id: G2-CRE-OBE-02",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "Obedience,
    subtopic: "Obeying Parents and Teachers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The Bible promises that obedience leads to blessing. What happens to children who obey their parents according to the Bible?,
      options: [They will live long and prosper, They will be famous, They will be rich", "They will be strong].sort(() => Math.random() - 0.5),
      correctAnswer: They will live long and prosper"
    })
  },
  {
    id: "G2-CRE-OBE-03",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "Obedience",
    subtopic: "Obeying Parents and Teachers,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Even Jesus, the Son of God, obeyed His earthly parents. What does Jesus' obedience teach us?,
      options: ["We should be obedient too, We can ignore our parents", "We only obey God, We obey others only when we want to"].sort(() => Math.random() - 0.5),
      correctAnswer: "We should be obedient too
    })
  },

  // --- MADA: THE GOOD SAMARITAN (3 Materials) ---
  {
    id: G2-CRE-GOO-01",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Good Samaritan,
    subtopic: "Helping Others in Need",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus told a story about a man who was robbed and left hurt on the road. People passed by without helping, but one man stopped and cared for him. Who was this kind man?,
      options: [The Good Samaritan, The priest, The Levite", "The robber].sort(() => Math.random() - 0.5),
      correctAnswer: The Good Samaritan"
    })
  },
  {
    id: "G2-CRE-GOO-02",
    grade: "Grade 2",
    subject: "Christian Religious Education",
    topic: "The Good Samaritan",
    subtopic: "Helping Others in Need,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "In the story of the Good Samaritan, Jesus teaches us that our neighbor is anyone who is in need of help. How did the Good Samaritan help the injured man?,
      options: [He bandaged his wounds and took him to an inn, He gave him money and left", "He ignored him, He called the police"].sort(() => Math.random() - 0.5),
      correctAnswer: "He bandaged his wounds and took him to an inn
    })
  },
  {
    id: G2-CRE-GOO-03",
    grade: "Grade 2,
    subject: Christian Religious Education",
    topic: "The Good Samaritan,
    subtopic: "Helping Others in Need",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The story of the Good Samaritan teaches us an important lesson about compassion and mercy. What is the main lesson we learn from this parable?,
      options: [We should help everyone who is in need, We should only help our friends, We should not trust strangers", "We should be afraid of others].sort(() => Math.random() - 0.5),
      correctAnswer: We should help everyone who is in need"
    })
  }
  // =========================================================================
  // GRADE 3: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE CREATION STORY (5 Materials) ---
  {
    id: "G3-CRE-CRE-01",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Creation Story",
    subtopic: "God's Perfect Creation,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "In the beginning, God created the heavens and the earth. He made everything perfect and beautiful. How did God create the world and everything in it?,
      options: [He spoke and it came into being., He used tools.", "He built it with His hands., He copied it from another world."].sort(() => Math.random() - 0.5),
      correctAnswer: "He spoke and it came into being.
    })
  },
  {
    id: G3-CRE-CRE-02",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Creation Story,
    subtopic: "God's Perfect Creation",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " God made human beings in His own image. He gave them the responsibility to take care of the earth. What does it mean to be made in God's image?,
      options: [We have dignity and value., We look like God., We are the same as God.", "We have no special purpose.].sort(() => Math.random() - 0.5),
      correctAnswer: We have dignity and value."
    })
  },
  {
    id: "G3-CRE-CRE-03",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Creation Story",
    subtopic: "God's Perfect Creation,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "After God created the world, He saw everything He had made and declared it good. What does this tell us about God's nature?,
      options: [God is loving and kind., God is harsh and strict.", "God is only concerned with rules., God does not care about His creation."].sort(() => Math.random() - 0.5),
      correctAnswer: "God is loving and kind.
    })
  },
  {
    id: G3-CRE-CRE-04",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Creation Story,
    subtopic: "The Fall of Man",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Adam and Eve were given one rule: not to eat from the tree of knowledge of good and evil. But they disobeyed God and ate the fruit. What was the consequence of their disobedience?,
      options: [They were sent out of the Garden of Eden., They were given more land., They became very powerful.", "They were given a second chance.].sort(() => Math.random() - 0.5),
      correctAnswer: They were sent out of the Garden of Eden."
    })
  },
  {
    id: "G3-CRE-CRE-05",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Creation Story",
    subtopic: "The Fall of Man,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The story of Adam and Eve teaches us that disobedience to God has consequences. How did God continue to show His love even after they disobeyed?,
      options: [He promised to send a Savior., He sent them away forever., "He gave up on them., He punished them severely."].sort(() => Math.random() - 0.5),
      correctAnswer: "He promised to send a Savior.
    })
  },

  // --- MADA: THE FAMILY (5 Materials) ---
  {
    id: G3-CRE-FAM-01",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Family,
    subtopic: "The Importance of Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " God created the family as the basic unit of society. He designed it to be a place of love, support, and growth. What role do children play in the family according to God's design?,
      options: [They are to respect and obey their parents., They are to tell their parents what to do., They are to ignore their parents.", "They are to compete with their siblings.].sort(() => Math.random() - 0.5),
      correctAnswer: They are to respect and obey their parents."
    })
  },
  {
    id: "G3-CRE-FAM-02",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Family",
    subtopic: "The Importance of Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Bible teaches that parents are to love and guide their children in the ways of the Lord. What is the best way for a parent to guide their child?,
      options: [By teaching them God's Word and modeling good behavior., By giving them everything they want., "By punishing them severely., By ignoring their mistakes."].sort(() => Math.random() - 0.5),
      correctAnswer: "By teaching them God's Word and modeling good behavior.
    })
  },
  {
    id: G3-CRE-FAM-03",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Family,
    subtopic: "The Importance of Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " In a family, siblings are to love and support one another. What is a good way for siblings to demonstrate love to one another?,
      options: [By sharing and helping each other., By competing and fighting., By ignoring each other.", "By doing everything alone.].sort(() => Math.random() - 0.5),
      correctAnswer: By sharing and helping each other."
    })
  },
  {
    id: "G3-CRE-FAM-04",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Family",
    subtopic: "The Importance of Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "When family members work together and support each other, they reflect God's love. How does a family that respects and supports each other glorify God?,
      options: [It shows that God's love is present., It shows that they are perfect.", "It shows that they never argue., It shows that they have all things."].sort(() => Math.random() - 0.5),
      correctAnswer: "It shows that God's love is present.
    })
  },
  {
    id: G3-CRE-FAM-05",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Family,
    subtopic: "The Importance of Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " God's plan for the family includes roles for each member. What is the biblical role of a husband and father in the home?,
      options: [He is to lead with love and provide for the family., He is to be the only one who makes decisions., He is to work away from home always.", "He is to be strict and harsh.].sort(() => Math.random() - 0.5),
      correctAnswer: He is to lead with love and provide for the family."
    })
  },

  // --- MADA: THE BIBLE (5 Materials) ---
  {
    id: "G3-CRE-BIB-01",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "Using the Bible for Guidance,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The Bible is God's Word and serves as a guide for our lives. What is the best way to use the Bible to make good decisions?,
      options: [By reading it and applying its teachings., By reading it and ignoring it., "By reading it only on Sundays., By reading it only when in trouble."].sort(() => Math.random() - 0.5),
      correctAnswer: "By reading it and applying its teachings.
    })
  },
  {
    id: G3-CRE-BIB-02",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "Using the Bible for Guidance",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Bible is filled with wisdom and guidance for all areas of life. What should a Christian do when they are faced with a difficult decision?,
      options: [Pray and consult the Bible for wisdom., Make the decision based on feelings alone., Ignore the situation.", "Wait for someone else to decide.].sort(() => Math.random() - 0.5),
      correctAnswer: Pray and consult the Bible for wisdom."
    })
  },
  {
    id: "G3-CRE-BIB-03",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "Using the Bible for Guidance,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Bible teaches us how to treat others and how to live a life that pleases God. What is a key principle from the Bible for living a good life?,
      options: [Love God and love your neighbor., Only care about yourself., "Do whatever you want., Follow the crowd."].sort(() => Math.random() - 0.5),
      correctAnswer: "Love God and love your neighbor.
    })
  },
  {
    id: G3-CRE-BIB-04",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "Using the Bible for Guidance",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Bible says that God's Word is a lamp to our feet and a light to our path. What does this metaphor mean for our daily lives?,
      options: [The Bible gives us direction and clarity in life., The Bible shows us the right path for success., The Bible is a source of light.", "The Bible is only for guidance in spiritual matters.].sort(() => Math.random() - 0.5),
      correctAnswer: The Bible gives us direction and clarity in life."
    })
  },
  {
    id: "G3-CRE-BIB-05",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "Using the Bible for Guidance,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Bible is not just a collection of ancient stories; it is living and active. How does the Bible remain relevant to us today?,
      options: [Its teachings apply to all generations and cultures., Its teachings are only for ancient times., "Its teachings are outdated., Its teachings are only for priests."].sort(() => Math.random() - 0.5),
      correctAnswer: "Its teachings apply to all generations and cultures.
    })
  },

  // --- MADA: JESUS (5 Materials) ---
  {
    id: G3-CRE-JES-01",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is the Good Shepherd",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jesus described Himself as the Good Shepherd who lays down His life for the sheep. What does the role of a shepherd involve in biblical times?,
      options: [Guiding, protecting, and caring for the sheep., Leading the sheep to war., Abandoning the sheep.", "Using the sheep for food.].sort(() => Math.random() - 0.5),
      correctAnswer: Guiding, protecting, and caring for the sheep."
    })
  },
  {
    id: "G3-CRE-JES-02",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is the Good Shepherd,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus said that He knows His sheep and His sheep know Him. What does it mean for us to know Jesus as our Shepherd?,
      options: [It means we are in a personal relationship with Him., It means we know about Him, but not personally., "It means we have no connection to Him., It means we can do whatever we want."].sort(() => Math.random() - 0.5),
      correctAnswer: "It means we are in a personal relationship with Him.
    })
  },
  {
    id: G3-CRE-JES-03",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is the Good Shepherd",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A good shepherd protects the flock from danger, even at the risk of his own life. How did Jesus demonstrate that He is the Good Shepherd?,
      options: [He died on the cross to save us., He ran away from danger., He refused to protect His followers.", "He only cared about Himself.].sort(() => Math.random() - 0.5),
      correctAnswer: He died on the cross to save us."
    })
  },
  {
    id: "G3-CRE-JES-04",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is the Good Shepherd,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "When we follow Jesus, He guides us and gives us peace. How can we experience the peace that comes from Jesus?,
      options: [By trusting in Him and following His teachings., By worrying about everything.", "By relying on our own strength., By ignoring His guidance."].sort(() => Math.random() - 0.5),
      correctAnswer: "By trusting in Him and following His teachings.
    })
  },
  {
    id: G3-CRE-JES-05",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is the Good Shepherd",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Good Shepherd knows each of His sheep by name and cares for them individually. What does this imagery teach us about God's love?,
      options: [God cares for us personally., God only cares for the group., God does not care for us.", "God loves us collectively.].sort(() => Math.random() - 0.5),
      correctAnswer: God cares for us personally."
    })
  },

  // --- MADA: JESUS' MIRACLES (5 Materials) ---
  {
    id: "G3-CRE-MIR-01",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus Heals the Sick,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jesus healed many people during His ministry, demonstrating His divine power. One time, He healed a man who was born blind. How did Jesus heal him?,
      options: ["He spat on the ground, made mud, and applied it to the man's eyes., He spoke to the man directly.", "He used a special potion., He prayed to the Father."].sort(() => Math.random() - 0.5),
      correctAnswer: "He spat on the ground, made mud, and applied it to the man's eyes.
    })
  },
  {
    id: G3-CRE-MIR-02",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus Heals the Sick",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Jesus performed many miracles that showed His power over sickness, nature, and even death. What did Jesus do when He raised Lazarus from the dead?,
      options: [He called out Lazarus by name, and he came out of the tomb., He prayed to the Father., He broke the tomb.", "He gave a speech.].sort(() => Math.random() - 0.5),
      correctAnswer: He called out Lazarus by name, and he came out of the tomb."
    })
  },
  {
    id: "G3-CRE-MIR-03",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus Heals the Sick,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Jesus not only healed physical ailments but also spiritual ones. He forgave a paralyzed man his sins before healing him. What does this teach us about Jesus' priorities?,
      options: [He cares about both our physical and spiritual needs., He only cares about our physical needs., "He only cares about our spiritual needs., He doesn't care about either."].sort(() => Math.random() - 0.5),
      correctAnswer: "He cares about both our physical and spiritual needs.
    })
  },
  {
    id: G3-CRE-MIR-04",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus Heals the Sick",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jesus also cast out demons from people, showing His authority over the spiritual realm. What does Jesus' authority over demons indicate?,
      options: [He is the Son of God and has power over all things., He used magic., He was just a good man.", "He had special skills.].sort(() => Math.random() - 0.5),
      correctAnswer: He is the Son of God and has power over all things."
    })
  },
  {
    id: "G3-CRE-MIR-05",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus Heals the Sick,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus' miracles were not just acts of compassion; they also pointed to His divine identity. How did the people react when they witnessed Jesus' miracles?,
      options: [They were amazed and many believed in Him., They were angry and rejected Him., "They were indifferent to Him., They were scared and ran away."].sort(() => Math.random() - 0.5),
      correctAnswer: "They were amazed and many believed in Him.
    })
  },

  // --- MADA: THE CHURCH (3 Materials) ---
  {
    id: G3-CRE-CHU-01",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church is a Community of Believers",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The Church is not just a building; it is the community of people who believe in Jesus. What does the Church do as a community of believers?,
      options: [They worship, pray, and encourage each other., They only meet on Sundays., They only pray and nothing else.", "They keep to themselves.].sort(() => Math.random() - 0.5),
      correctAnswer: They worship, pray, and encourage each other."
    })
  },
  {
    id: "G3-CRE-CHU-02",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church is a Community of Believers,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "In the Church, members are called to love and serve one another. How can members of the Church serve each other?,
      options: [By using their spiritual gifts and talents., By competing with each other.", "By ignoring each other., By judging each other."].sort(() => Math.random() - 0.5),
      correctAnswer: "By using their spiritual gifts and talents.
    })
  },
  {
    id: G3-CRE-CHU-03",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church is a Community of Believers",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The Church is called to be the body of Christ on earth. As the body of Christ, what is the Church's mission?,
      options: [To spread the love of God and the gospel to others., To build big buildings., To collect money.", "To make laws.].sort(() => Math.random() - 0.5),
      correctAnswer: To spread the love of God and the gospel to others."
    })
  },

  // --- MADA: PRAYER (3 Materials) ---
  {
    id: "G3-CRE-PRA-01",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "Praying in Faith and Trust,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Jesus taught His disciples to pray with faith and trust in God. What is the key to praying effectively according to the Bible?,
      options: [Pray with faith and believe that God will answer., Pray only when you are in trouble., "Pray with loud voices., Pray in a specific location."].sort(() => Math.random() - 0.5),
      correctAnswer: "Pray with faith and believe that God will answer.
    })
  },
  {
    id: G3-CRE-PRA-02",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "Praying in Faith and Trust",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Bible encourages us to pray without ceasing. What does it mean to pray without ceasing?,
      options: [To maintain a constant attitude of prayer and communication with God., To pray only at night., To pray only in Church.", "To pray only in emergency situations.].sort(() => Math.random() - 0.5),
      correctAnswer: To maintain a constant attitude of prayer and communication with God."
    })
  },
  {
    id: "G3-CRE-PRA-03",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "Praying in Faith and Trust,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "When we pray, we are invited to bring our concerns and needs before God. How does God respond to our prayers when we trust Him?,
      options: [He hears us and acts according to His will., He ignores them.", "He only hears the prayers of leaders., He hears but does nothing."].sort(() => Math.random() - 0.5),
      correctAnswer: "He hears us and acts according to His will.
    })
  },

  // --- MADA: LOVE (3 Materials) ---
  {
    id: G3-CRE-LOV-01",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Love,
    subtopic: "Loving Others as Ourselves",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jesus commanded His disciples to love others as themselves. What does it mean to love others as we love ourselves?,
      options: [To treat others with the same care and respect we want for ourselves., To love others less than ourselves., To love others only when we feel like it.", "To love others only if they are like us.].sort(() => Math.random() - 0.5),
      correctAnswer: To treat others with the same care and respect we want for ourselves."
    })
  },
  {
    id: "G3-CRE-LOV-02",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Love",
    subtopic: "Loving Others as Ourselves,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Bible teaches that love is patient and kind. How can we demonstrate patience and kindness toward others in our daily lives?,
      options: [By being understanding and forgiving., By being quick to anger., "By being rude and impatient., By ignoring others' feelings."].sort(() => Math.random() - 0.5),
      correctAnswer: "By being understanding and forgiving.
    })
  },
  {
    id: G3-CRE-LOV-03",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Love,
    subtopic: "Loving Others as Ourselves",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Loving others involves putting their needs before our own. What is an example of putting someone else's needs before your own?,
      options: [Helping a friend who is struggling., Ignoring a friend's problem., Focusing only on your own needs.", "Competing with your friend.].sort(() => Math.random() - 0.5),
      correctAnswer: Helping a friend who is struggling."
    })
  },

  // --- MADA: OBEDIENCE (3 Materials) ---
  {
    id: "G3-CRE-OBE-01",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Obedience",
    subtopic: "Obeying God and Listening to His Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The Bible says that obeying God leads to blessings. How can we know what God wants us to do in our lives?,
      options: [By reading the Bible and listening to the Holy Spirit., By doing whatever we feel is right., "By asking our friends., By following the crowd."].sort(() => Math.random() - 0.5),
      correctAnswer: "By reading the Bible and listening to the Holy Spirit.
    })
  },
  {
    id: G3-CRE-OBE-02",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "Obedience,
    subtopic: "Obeying God and Listening to His Voice",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Obedience to God is not just about following rules; it is about having a heart that desires to honor Him. What is the best motivation for obeying God?,
      options: [To show our love for Him and our gratitude for His grace., To avoid punishment., To get what we want.", "To impress others.].sort(() => Math.random() - 0.5),
      correctAnswer: To show our love for Him and our gratitude for His grace."
    })
  },
  {
    id: "G3-CRE-OBE-03",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "Obedience",
    subtopic: "Obeying God and Listening to His Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The Bible recounts stories of people who obeyed God and those who disobeyed. What was the result of Abraham's obedience when God asked him to sacrifice Isaac?,
      options: [God blessed Abraham abundantly., God rejected him., "God was angry with him., God gave him a harder task."].sort(() => Math.random() - 0.5),
      correctAnswer: "God blessed Abraham abundantly.
    })
  },

  // --- MADA: THE LIFE OF MOSES (3 Materials) ---
  {
    id: G3-CRE-MOS-01",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Life of Moses,
    subtopic: "God Calls Moses to Lead His People",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " God chose Moses to lead the Israelites out of slavery in Egypt. Where did God speak to Moses and call him to this task?,
      options: [At the burning bush on Mount Horeb., In a dream., At the Red Sea.", "In the desert of Sinai.].sort(() => Math.random() - 0.5),
      correctAnswer: At the burning bush on Mount Horeb."
    })
  },
  {
    id: "G3-CRE-MOS-02",
    grade: "Grade 3",
    subject: "Christian Religious Education",
    topic: "The Life of Moses",
    subtopic: "God Calls Moses to Lead His People,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Moses was hesitant to accept God's call because he felt inadequate. How did God respond to Moses' fears and doubts?,
      options: [He assured Moses that He would be with him and gave him signs., He replaced Moses with Aaron., "He ignored his concerns., He sent him away."].sort(() => Math.random() - 0.5),
      correctAnswer: "He assured Moses that He would be with him and gave him signs.
    })
  },
  {
    id: G3-CRE-MOS-03",
    grade: "Grade 3,
    subject: Christian Religious Education",
    topic: "The Life of Moses,
    subtopic: "God Calls Moses to Lead His People",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Despite his initial reluctance, Moses obeyed God and became one of the greatest leaders in history. What can we learn from Moses' example of obedience?,
      options: [God can use anyone who is willing to obey Him., We should only obey God if we feel confident., We should avoid challenging tasks.", "We should only obey God when it is easy.].sort(() => Math.random() - 0.5),
      correctAnswer: God can use anyone who is willing to obey Him."
    })
  },

  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: GOD'S COVENANT (5 Materials) ---
  {
    id: "G4-CRE-COV-01",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "God's Covenant",
    subtopic: "God's Promises to Abraham,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "God made a covenant with Abraham, promising to make him the father of a great nation. What was God's promise to Abraham regarding his descendants?,
      options: [He would be the father of many nations., He would have only one child.", "He would be forgotten., He would be rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "He would be the father of many nations.
    })
  },
  {
    id: G4-CRE-COV-02",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "God's Covenant,
    subtopic: "God's Promises to Abraham",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Abraham believed God, and his faith was credited to him as righteousness. What is the significance of Abraham's faith in God?,
      options: [It shows that faith is essential for a relationship with God., It shows that good works are all that matter., It shows that faith is not important.", "It shows that faith is only for a few people.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows that faith is essential for a relationship with God."
    })
  },
  {
    id: "G4-CRE-COV-03",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "God's Covenant",
    subtopic: "God's Promises to Abraham,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "God tested Abraham's faith by asking him to sacrifice his son Isaac. How did Abraham respond to this test of faith?,
      options: [He obeyed God, trusting that God would provide a lamb., He refused and argued with God., "He ran away., He ignored God's command."].sort(() => Math.random() - 0.5),
      correctAnswer: "He obeyed God, trusting that God would provide a lamb.
    })
  },
  {
    id: G4-CRE-COV-04",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "God's Covenant,
    subtopic: "God's Promises to Abraham",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The covenant between God and Abraham was sealed with a sign. What was the sign of the covenant that God established with Abraham?,
      options: [Circumcision, Baptism, The Lord's Supper", "The Sabbath].sort(() => Math.random() - 0.5),
      correctAnswer: Circumcision"
    })
  },
  {
    id: "G4-CRE-COV-05",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "God's Covenant",
    subtopic: "God's Promises to Abraham,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "God's covenant with Abraham was unconditional and based on His grace. How does this covenant point forward to God's ultimate promise of salvation?,
      options: [It foreshadows the coming of Jesus Christ, the descendant of Abraham., It signifies the end of God's promises., "It points to the law., It foreshadows the Temple."].sort(() => Math.random() - 0.5),
      correctAnswer: "It foreshadows the coming of Jesus Christ, the descendant of Abraham.
    })
  },

  // --- MADA: THE BIBLE (4 Materials) ---
  {
    id: G4-CRE-BIB-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is the Word of God",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Bible is inspired by God and is the authoritative source of truth for Christians. Why is the Bible considered a reliable guide for life?,
      options: [It is the inspired Word of God and has been proven true., It is a collection of ancient stories., It contains myths.", "It is a book of philosophy.].sort(() => Math.random() - 0.5),
      correctAnswer: It is the inspired Word of God and has been proven true."
    })
  },
  {
    id: "G4-CRE-BIB-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is the Word of God,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Bible contains different types of literature, including history, poetry, prophecy, and letters. Why is it important to understand the different genres in the Bible?,
      options: ["To interpret the Bible accurately and understand its message., To know which parts to ignore.", "To impress others., To avoid reading certain books."].sort(() => Math.random() - 0.5),
      correctAnswer: "To interpret the Bible accurately and understand its message.
    })
  },
  {
    id: G4-CRE-BIB-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is the Word of God",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The New Testament tells the story of Jesus, the early church, and the teachings of the apostles. What is the central message of the New Testament?,
      options: [The life, death, and resurrection of Jesus Christ., The history of Israel., The creation of the world.", "The Ten Commandments.].sort(() => Math.random() - 0.5),
      correctAnswer: The life, death, and resurrection of Jesus Christ."
    })
  },
  {
    id: "G4-CRE-BIB-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is the Word of God,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Bible teaches us about God's character, His will for humanity, and His plan for redemption. How should we approach the Bible when we read it?,
      options: ["With reverence and a desire to learn from it., With skepticism and doubt.", "Only when we have time., Only when we are at Church."].sort(() => Math.random() - 0.5),
      correctAnswer: "With reverence and a desire to learn from it.
    })
  },

  // --- MADA: JESUS (4 Materials) ---
  {
    id: G4-CRE-JES-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is the Bread of Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Jesus said, 'I am the bread of life.' What does this statement mean for believers?,
      options: [Jesus is the one who provides spiritual nourishment and eternal life., He is like physical bread., He is a good teacher.", "He is a famous person.].sort(() => Math.random() - 0.5),
      correctAnswer: Jesus is the one who provides spiritual nourishment and eternal life."
    })
  },
  {
    id: "G4-CRE-JES-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is the Bread of Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "When Jesus spoke about being the bread of life, He was pointing to a deeper spiritual truth. What does it mean to 'eat' this bread?,
      options: [To believe in Jesus and receive His life., To eat a physical meal.", "To understand His teachings intellectually., To follow His rules."].sort(() => Math.random() - 0.5),
      correctAnswer: "To believe in Jesus and receive His life.
    })
  },
  {
    id: G4-CRE-JES-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Jesus,
    subtopic: "Jesus is the Bread of Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Bread of Life is not just for a moment, but for eternal life. How does Jesus give eternal life to those who come to Him?,
      options: [By offering Himself as the sacrifice for our sins., By giving us rules to follow., By teaching us good morals.", "By showing us the right path.].sort(() => Math.random() - 0.5),
      correctAnswer: By offering Himself as the sacrifice for our sins."
    })
  },
  {
    id: "G4-CRE-JES-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Jesus",
    subtopic: "Jesus is the Bread of Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Those who eat the Bread of Life will never be spiritually hungry. What does it mean to experience spiritual satisfaction in Christ?,
      options: [To find fulfillment and purpose in Him., To never need anything else., "To be physically full., To always feel happy."].sort(() => Math.random() - 0.5),
      correctAnswer: "To find fulfillment and purpose in Him.
    })
  },

  // --- MADA: THE KINGDOM OF GOD (4 Materials) ---
  {
    id: G4-CRE-KIN-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Kingdom of God,
    subtopic: "Jesus Teaches about the Kingdom of God",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jesus often spoke about the Kingdom of God, which is a central theme in His teachings. How did Jesus describe the nature of the Kingdom of God?,
      options: [It is a spiritual realm where God's will is done., It is a physical kingdom on earth., It is a political kingdom.", "It is a state of mind.].sort(() => Math.random() - 0.5),
      correctAnswer: It is a spiritual realm where God's will is done."
    })
  },
  {
    id: "G4-CRE-KIN-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Kingdom of God",
    subtopic: "Jesus Teaches about the Kingdom of God,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus taught that the Kingdom of God is like a mustard seed that grows into a large tree. What does this parable teach us about the Kingdom?,
      options: [It starts small but grows and expands to include many people., It is only for a few people., "It is a small and insignificant thing., It is a secret thing."].sort(() => Math.random() - 0.5),
      correctAnswer: "It starts small but grows and expands to include many people.
    })
  },
  {
    id: G4-CRE-KIN-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Kingdom of God,
    subtopic: "Jesus Teaches about the Kingdom of God",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " In the Kingdom of God, values such as humility, mercy, and peace are honored. What does it mean to be great in the Kingdom of God?,
      options: [To be a servant to others., To have power and authority., To be famous.", "To have riches.].sort(() => Math.random() - 0.5),
      correctAnswer: To be a servant to others."
    })
  },
  {
    id: "G4-CRE-KIN-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Kingdom of God",
    subtopic: "Jesus Teaches about the Kingdom of God,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jesus taught that the Kingdom of God is both a present reality and a future hope. How can we experience the Kingdom of God today?,
      options: [By living according to God's will and seeking His righteousness., By waiting for the future., "By building big churches., By becoming rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "By living according to God's will and seeking His righteousness.
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (4 Materials) ---
  {
    id: G4-CRE-TEN-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Living by God's Laws",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " God gave the Ten Commandments to Moses on Mount Sinai as a guide for His people. How should believers view the Ten Commandments today?,
      options: [They reveal God's holy character and standards for living., They are outdated and irrelevant., They are only for the Jews.", "They are just historical texts.].sort(() => Math.random() - 0.5),
      correctAnswer: They reveal God's holy character and standards for living."
    })
  },
  {
    id: "G4-CRE-TEN-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Living by God's Laws,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Ten Commandments are divided into two sections. The first four commandments concern our relationship with God. What do the other six commandments concern?,
      options: [Our relationships with one another., Our relationship with animals., "Our relationship with the environment., Our relationship with the government."].sort(() => Math.random() - 0.5),
      correctAnswer: "Our relationships with one another.
    })
  },
  {
    id: G4-CRE-TEN-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Living by God's Laws",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Ten Commandments include both positive and negative precepts. What is the purpose of these commandments for believers?,
      options: [To set boundaries for a godly life., To restrict our freedom., To make us unhappy.", "To show that God is harsh.].sort(() => Math.random() - 0.5),
      correctAnswer: To set boundaries for a godly life."
    })
  },
  {
    id: "G4-CRE-TEN-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Living by God's Laws,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus summarized the Ten Commandments into two great commandments. What are the two greatest commandments as taught by Jesus?,
      options: [Love God and love your neighbor as yourself., Honor your father and mother., "Do not kill., Do not steal."].sort(() => Math.random() - 0.5),
      correctAnswer: "Love God and love your neighbor as yourself.
    })
  },

  // --- MADA: PRAYER (4 Materials) ---
  {
    id: G4-CRE-PRA-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "The Power of Prayer",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Prayer is a powerful tool that connects us to God and invites His intervention in our lives. Why is prayer considered powerful for a believer?,
      options: [It invites God to work in our lives and align us with His will., It controls God's actions., It forces God to act.", "It is a ritual with no effect.].sort(() => Math.random() - 0.5),
      correctAnswer: It invites God to work in our lives and align us with His will."
    })
  },
  {
    id: "G4-CRE-PRA-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "The Power of Prayer,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Prayer is not just about asking for things; it is also about listening to God. How can we learn to listen to God in prayer?,
      options: [By being still and open to the Spirit's leading., By talking constantly., "By ignoring His voice., By only listening to others."].sort(() => Math.random() - 0.5),
      correctAnswer: "By being still and open to the Spirit's leading.
    })
  },
  {
    id: G4-CRE-PRA-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Prayer,
    subtopic: "The Power of Prayer",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " When we pray, we are invited to come boldly to the throne of grace. What does it mean to pray with boldness and confidence?,
      options: [To pray with the assurance that God hears and cares., To demand things from God., To pray loudly.", "To pray only in Church.].sort(() => Math.random() - 0.5),
      correctAnswer: To pray with the assurance that God hears and cares."
    })
  },
  {
    id: "G4-CRE-PRA-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Prayer",
    subtopic: "The Power of Prayer,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Bible promises that the prayer of a righteous person is powerful and effective. How does prayer affect the one who prays?,
      options: [It transforms their heart and aligns them with God's purposes., It changes God's mind., "It makes them righteous., It gives them magical powers."].sort(() => Math.random() - 0.5),
      correctAnswer: "It transforms their heart and aligns them with God's purposes.
    })
  },

  // --- MADA: THE CHURCH (4 Materials) ---
  {
    id: G4-CRE-CHU-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church as the Body of Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The Apostle Paul described the Church as the body of Christ, with each member having a unique role. How does this image of the Church benefit believers?,
      options: [It shows we are interconnected and need each other., It shows we are independent and don't need each other., It shows we are all the same.", "It shows we are unnecessary.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows we are interconnected and need each other."
    })
  },
  {
    id: "G4-CRE-CHU-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church as the Body of Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Each member of the Church has been given spiritual gifts for the building up of the body. What is the purpose of using our spiritual gifts?,
      options: [To serve others and glorify God., To make ourselves important., "To gain power., To compete with others."].sort(() => Math.random() - 0.5),
      correctAnswer: "To serve others and glorify God.
    })
  },
  {
    id: G4-CRE-CHU-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church as the Body of Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Church is called to be a light to the world, reflecting God's love and truth. How can the Church be a light in today's world?,
      options: [By living out the gospel and serving the community., By staying separate from society., By focusing only on internal matters.", "By building large buildings.].sort(() => Math.random() - 0.5),
      correctAnswer: By living out the gospel and serving the community."
    })
  },
  {
    id: "G4-CRE-CHU-04",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church as the Body of Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Church is united in Christ despite diverse backgrounds. What should be the distinguishing mark of the Church as followers of Jesus?,
      options: [Love for one another., Wealth and possessions., "Rituals and traditions., Social status."].sort(() => Math.random() - 0.5),
      correctAnswer: "Love for one another.
    })
  },

  // --- MADA: THE PROPHETS (3 Materials) ---
  {
    id: G4-CRE-PRO-01",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Prophets,
    subtopic: "Prophets Who Spoke for God",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Prophets in the Bible were called by God to speak His messages to the people. What was the primary role of a prophet in ancient Israel?,
      options: [To call people back to God and warn them of judgment., To predict the future for money., To work as priests.", "To lead the army.].sort(() => Math.random() - 0.5),
      correctAnswer: To call people back to God and warn them of judgment."
    })
  },
  {
    id: "G4-CRE-PRO-02",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "The Prophets",
    subtopic: "Prophets Who Spoke for God,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "One of the most prominent prophets was Jeremiah, who was called by God to speak to the people of Judah. What was Jeremiah's message to the people?,
      options: [He urged them to repent and turn from their evil ways., He told them to continue their sinful ways.", "He encouraged them to build the Temple., He told them to ignore God."].sort(() => Math.random() - 0.5),
      correctAnswer: "He urged them to repent and turn from their evil ways.
    })
  },
  {
    id: G4-CRE-PRO-03",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "The Prophets,
    subtopic: "Prophets Who Spoke for God",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The prophet Isaiah spoke about a suffering servant who would come to bear the sins of the people. Who is this suffering servant referring to?,
      options: [Jesus Christ, Jeremiah, Moses", "David].sort(() => Math.random() - 0.5),
      correctAnswer: Jesus Christ"
    })
  },

  // --- MADA: TRUST IN GOD (2 Materials) ---
  {
    id: "G4-CRE-TRU-01",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Trust in God",
    subtopic: "Trusting God in All Circumstances,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Trusting God means relying on Him completely, even when we cannot see the future. Why is trust in God essential for a believer?,
      options: [It gives us peace and confidence in God's plans., It gives us control over our lives.", "It makes us independent., It makes us immune to problems."].sort(() => Math.random() - 0.5),
      correctAnswer: "It gives us peace and confidence in God's plans.
    })
  },
  {
    id: G4-CRE-TRU-02",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Trust in God,
    subtopic: "Trusting God in All Circumstances",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Bible says, 'Trust in the Lord with all your heart and lean not on your own understanding.' What does this verse call us to do?,
      options: [To rely on God's wisdom instead of our own., To trust ourselves first., To ignore God's guidance.", "To rely on others.].sort(() => Math.random() - 0.5),
      correctAnswer: To rely on God's wisdom instead of our own."
    })
  },

  // --- MADA: SERVICE (2 Materials) ---
  {
    id: "G4-CRE-SER-01",
    grade: "Grade 4",
    subject: "Christian Religious Education",
    topic: "Service",
    subtopic: "Serving God by Serving Others,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Jesus taught that greatness is found in serving others. How did Jesus demonstrate the importance of service?,
      options: [He washed His disciples' feet., He built a large house., "He became a king., He demanded respect."].sort(() => Math.random() - 0.5),
      correctAnswer: "He washed His disciples' feet.
    })
  },
  {
    id: G4-CRE-SER-02",
    grade: "Grade 4,
    subject: Christian Religious Education",
    topic: "Service,
    subtopic: "Serving God by Serving Others",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When we serve others with a humble heart, we are serving God. How should we approach serving those in need?,
      options: [With humility and compassion., With pride and arrogance., With selfish motives.", "With reluctance.].sort(() => Math.random() - 0.5),
      correctAnswer: With humility and compassion."
    })
  }
  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: GOD'S COVENANT (Davidic Covenant) (4 Materials) ---
  {
    id: "G5-CRE-DAV-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "God's Covenant",
    subtopic: "The Covenant with David,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "God made a covenant with King David, promising that his descendants would rule forever. Who ultimately fulfills this Davidic Covenant?,
      options: [Jesus Christ, King Solomon", "King Josiah, King Hezekiah"].sort(() => Math.random() - 0.5),
      correctAnswer: "Jesus Christ
    })
  },
  {
    id: G5-CRE-DAV-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "God's Covenant,
    subtopic: "The Covenant with David",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " God promised David that his throne would be established forever. What does this everlasting promise signify for believers today?,
      options: [The coming of the Messiah as David's descendant., The end of the monarchy., The building of the Temple.", "David's immortality.].sort(() => Math.random() - 0.5),
      correctAnswer: The coming of the Messiah as David's descendant."
    })
  },
  {
    id: "G5-CRE-DAV-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "God's Covenant",
    subtopic: "The Covenant with David,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "David responded to God's covenant with humble gratitude and praise. How can we respond to God's promises in our own lives?,
      options: [By trusting God's faithfulness and praising Him., By ignoring them., "By doubting them., By demanding more promises."].sort(() => Math.random() - 0.5),
      correctAnswer: "By trusting God's faithfulness and praising Him.
    })
  },
  {
    id: G5-CRE-DAV-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "God's Covenant,
    subtopic: "The Covenant with David",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Davidic Covenant demonstrates God's unconditional faithfulness. What can we learn from the way God honored His promise to David?,
      options: [God always keeps His promises., God changes His mind., God only keeps promises to kings.", "God forgets His promises.].sort(() => Math.random() - 0.5),
      correctAnswer: God always keeps His promises."
    })
  },

  // --- MADA: THE BIBLE (The Psalms) (4 Materials) ---
  {
    id: "G5-CRE-PSA-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Psalms as Prayers and Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Psalms are a collection of songs and prayers used in worship. Who is traditionally credited with writing many of the Psalms?,
      options: [King David, Solomon, "Moses, Job"].sort(() => Math.random() - 0.5),
      correctAnswer: "King David
    })
  },
  {
    id: G5-CRE-PSA-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Psalms as Prayers and Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Psalm 23 is one of the most famous Psalms, describing the Lord as a shepherd. What is the main theme of Psalm 23?,
      options: [The Lord is my shepherd; I shall not want., The Lord is a warrior., The Lord is a judge.", "The Lord is a king.].sort(() => Math.random() - 0.5),
      correctAnswer: The Lord is my shepherd; I shall not want."
    })
  },
  {
    id: "G5-CRE-PSA-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Psalms as Prayers and Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Psalms express the full range of human emotion, from joy to despair. How can reading the Psalms help a believer today?,
      options: [It gives them words to pray and helps them connect with God's heart., It tells them to suppress their feelings.", "It is only for ancient people., It is just poetry with no meaning."].sort(() => Math.random() - 0.5),
      correctAnswer: "It gives them words to pray and helps them connect with God's heart.
    })
  },
  {
    id: G5-CRE-PSA-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Psalms as Prayers and Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Psalms teach us to praise God in all circumstances. What does it mean to praise God?,
      options: [To acknowledge His greatness and goodness., To sing loudly., To demand things from God.", "To be happy all the time.].sort(() => Math.random() - 0.5),
      correctAnswer: To acknowledge His greatness and goodness."
    })
  },

  // --- MADA: THE LIFE OF DAVID (5 Materials) ---
  {
    id: "G5-CRE-DLI-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Life of David",
    subtopic: "David's Rise from Shepherd to King,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "David was anointed as king when he was just a young shepherd. Who anointed David as the future king of Israel?,
      options: [Samuel, Saul, "Solomon, Nathan"].sort(() => Math.random() - 0.5),
      correctAnswer: "Samuel
    })
  },
  {
    id: G5-CRE-DLI-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Life of David,
    subtopic: "David's Rise from Shepherd to King",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " David gained fame when he defeated the giant Goliath with just a sling and a stone. What does this story demonstrate about David's character?,
      options: [His trust and faith in God., His physical strength., His political cunning.", "His desire for revenge.].sort(() => Math.random() - 0.5),
      correctAnswer: His trust and faith in God."
    })
  },
  {
    id: "G5-CRE-DLI-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Life of David",
    subtopic: "David's Rise from Shepherd to King,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Despite being anointed as king, David had to wait many years before he actually ruled. Why did David wait patiently rather than seize the throne by force?,
      options: [He respected God's timing and refused to harm God's anointed king., He was a coward.", "He didn't want to be king., He was waiting for Saul to die."].sort(() => Math.random() - 0.5),
      correctAnswer: "He respected God's timing and refused to harm God's anointed king.
    })
  },
  {
    id: G5-CRE-DLI-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Life of David,
    subtopic: "David's Rise from Shepherd to King",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " David was a man after God's own heart, yet he was not perfect. Which major sin did David commit during his reign as king?,
      options: [He committed adultery with Bathsheba and had her husband killed., He worshiped other gods., He built a golden calf.", "He cursed God.].sort(() => Math.random() - 0.5),
      correctAnswer: He committed adultery with Bathsheba and had her husband killed."
    })
  },
  {
    id: "G5-CRE-DLI-05",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Life of David",
    subtopic: "David's Repentance,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "After David sinned, the prophet Nathan confronted him. David repented and wrote Psalm 51. What does David's repentance teach us about God's mercy?,
      options: [God is forgiving when we come to Him with a repentant heart., God is unforgiving.", "God only forgives the righteous., God forgives only after punishment."].sort(() => Math.random() - 0.5),
      correctAnswer: "God is forgiving when we come to Him with a repentant heart.
    })
  },

  // --- MADA: THE PROPHETS (Elijah) (4 Materials) ---
  {
    id: G5-CRE-ELI-01",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Prophets,
    subtopic: "Elijah and the Prophets of Baal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The prophet Elijah challenged the prophets of Baal on Mount Carmel to prove who is the true God. What was the test that Elijah proposed?,
      options: [To call down fire from heaven., To perform a miracle., To preach a sermon.", "To build an altar.].sort(() => Math.random() - 0.5),
      correctAnswer: To call down fire from heaven."
    })
  },
  {
    id: "G5-CRE-ELI-02",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Prophets",
    subtopic: "Elijah and the Prophets of Baal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "When Elijah prayed to God, fire came down from heaven and consumed the offering. How did the people react when they saw the fire from heaven?,
      options: [They fell on their faces and declared, 'The Lord, He is God!', They ran away.", "They attacked Elijah., They worshiped Baal."].sort(() => Math.random() - 0.5),
      correctAnswer: "They fell on their faces and declared, 'The Lord, He is God!'
    })
  },
  {
    id: G5-CRE-ELI-03",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Prophets,
    subtopic: "Elijah and the Prophets of Baal",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " After the victory on Mount Carmel, Elijah ran for his life from Queen Jezebel. He was depressed and wanted to die. How did God minister to Elijah during his discouragement?,
      options: [An angel brought him food and water, and God spoke to him in a still small voice., He ignored him., He sent him back to battle.", "He gave him a new task.].sort(() => Math.random() - 0.5),
      correctAnswer: An angel brought him food and water, and God spoke to him in a still small voice."
    })
  },
  {
    id: "G5-CRE-ELI-04",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Prophets",
    subtopic: "Elijah and the Prophets of Baal,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Elijah was a prophet who demonstrated the power of God. He was taken up to heaven in a chariot of fire. Who succeeded Elijah as the next prophet of Israel?,
      options: [Elisha, Isaiah, "Jeremiah, Hosea"].sort(() => Math.random() - 0.5),
      correctAnswer: "Elisha
    })
  },

  // --- MADA: JESUS' PARABLES (5 Materials) ---
  {
    id: G5-CRE-PAR-01",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "Jesus' Parables,
    subtopic: "The Parable of the Sower",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Jesus taught using parables, which are stories with spiritual meanings. In the Parable of the Sower, the seed fell on different types of soil. What does the good soil represent?,
      options: [Those who hear the word and bear fruit., Those who hear and ignore it., Those who hear and reject it.", "Those who never hear it.].sort(() => Math.random() - 0.5),
      correctAnswer: Those who hear the word and bear fruit."
    })
  },
  {
    id: "G5-CRE-PAR-02",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "Jesus' Parables",
    subtopic: "The Parable of the Sower,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Jesus told the story of a sower who went out to plant seeds. Some seeds fell on rocky ground and withered away. What does the rocky ground symbolize?,
      options: [Those who receive the word but fall away when trouble comes., Those who are wise., "Those who are righteous., Those who are rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "Those who receive the word but fall away when trouble comes.
    })
  },
  {
    id: G5-CRE-PAR-03",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "Jesus' Parables,
    subtopic: "The Parable of the Prodigal Son",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The Parable of the Prodigal Son tells the story of a son who asked for his inheritance, wasted it, and later returned home. How did the father respond when the son returned?,
      options: [He ran to him and embraced him, forgiving and welcoming him home., He turned him away., He punished him severely.", "He ignored him.].sort(() => Math.random() - 0.5),
      correctAnswer: He ran to him and embraced him, forgiving and welcoming him home."
    })
  },
  {
    id: "G5-CRE-PAR-04",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "Jesus' Parables",
    subtopic: "The Parable of the Prodigal Son,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The elder brother in the Parable of the Prodigal Son was angry and refused to join the celebration. What did the father say to the elder brother?,
      options: [He assured him of his love and reminded him that everything he had was his., He scolded him., "He sent him away., He ignored him."].sort(() => Math.random() - 0.5),
      correctAnswer: "He assured him of his love and reminded him that everything he had was his.
    })
  },
  {
    id: G5-CRE-PAR-05",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "Jesus' Parables,
    subtopic: "The Parable of the Good Shepherd",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " In the Parable of the Good Shepherd, the shepherd leaves the ninety-nine sheep to search for the one that is lost. What does this parable teach us about God's love?,
      options: [God loves every individual and goes after the lost., God only cares for the group., God does not care about the lost.", "God is harsh with sinners.].sort(() => Math.random() - 0.5),
      correctAnswer: God loves every individual and goes after the lost."
    })
  },

  // --- MADA: THE POWER OF FAITH (4 Materials) ---
  {
    id: "G5-CRE-FAI-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Power of Faith",
    subtopic: "Faith in Action,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Faith is the assurance of things hoped for and the conviction of things not seen. How does faith manifest in the life of a believer?,
      options: [Through trust and obedience to God., Through fear and doubt., "Through wealth and power., Through magical powers."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through trust and obedience to God.
    })
  },
  {
    id: G5-CRE-FAI-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Power of Faith,
    subtopic: "Faith in Action",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Bible says that 'faith without works is dead.' What is the relationship between faith and good works?,
      options: [True faith naturally results in good works., Faith and works are the same thing., Works are more important than faith.", "Faith is a private matter and works are for others.].sort(() => Math.random() - 0.5),
      correctAnswer: True faith naturally results in good works."
    })
  },
  {
    id: "G5-CRE-FAI-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Power of Faith",
    subtopic: "Faith in Action,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The saints in Hebrews 11 are commended for their faith, even though they did not receive the fulfillment of the promises. What does their example encourage us to do?,
      options: [To persevere in faith, trusting God's faithfulness., To give up when things get hard.", "To doubt God's promises., To focus only on the present."].sort(() => Math.random() - 0.5),
      correctAnswer: "To persevere in faith, trusting God's faithfulness.
    })
  },
  {
    id: G5-CRE-FAI-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Power of Faith,
    subtopic: "Faith in Action",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Jesus commended the centurion for his great faith. How did the centurion's faith differ from the faith of many others?,
      options: [He understood authority and believed that Jesus could heal his servant with just a word., He was a soldier., He was rich.", "He was Jewish.].sort(() => Math.random() - 0.5),
      correctAnswer: He understood authority and believed that Jesus could heal his servant with just a word."
    })
  },

  // --- MADA: THE HOLY SPIRIT (4 Materials) ---
  {
    id: "G5-CRE-SPI-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Holy Spirit as Our Helper,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus promised to send the Holy Spirit as a helper to His disciples. What is the primary role of the Holy Spirit in the life of a believer?,
      options: [He guides, teaches, and empowers believers., He scares people., "He forces people to sin., He is only for apostles."].sort(() => Math.random() - 0.5),
      correctAnswer: "He guides, teaches, and empowers believers.
    })
  },
  {
    id: G5-CRE-SPI-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Holy Spirit as Our Helper",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Holy Spirit is described as the Comforter. How does the Holy Spirit comfort believers in times of trouble?,
      options: [He gives peace and assurance of God's presence., He ignores them., He scolds them.", "He leaves them alone.].sort(() => Math.random() - 0.5),
      correctAnswer: He gives peace and assurance of God's presence."
    })
  },
  {
    id: "G5-CRE-SPI-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Holy Spirit as Our Helper,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Holy Spirit helps believers in their weakness and intercedes for them. How does the Holy Spirit intercede for believers?,
      options: [He prays according to God's will., He prays for their prosperity., "He prays for their health., He doesn't pray."].sort(() => Math.random() - 0.5),
      correctAnswer: "He prays according to God's will.
    })
  },
  {
    id: G5-CRE-SPI-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Holy Spirit as Our Helper",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Holy Spirit also produces spiritual fruit in the life of a believer. What is one example of the fruit of the Spirit?,
      options: [Love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control., Anger and harshness., Fear and doubt.", "Greed and selfishness.].sort(() => Math.random() - 0.5),
      correctAnswer: Love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control."
    })
  },

  // --- MADA: THE CHURCH (The Early Church in Acts) (4 Materials) ---
  {
    id: "G5-CRE-ACT-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Early Church in Acts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "In the book of Acts, we read about the birth of the early church on the day of Pentecost. What happened on the day of Pentecost?,
      options: [The Holy Spirit descended and the disciples spoke in tongues., The disciples built a temple.", "The disciples ran away., The disciples fell asleep."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Holy Spirit descended and the disciples spoke in tongues.
    })
  },
  {
    id: G5-CRE-ACT-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Early Church in Acts",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The early church was devoted to fellowship, breaking bread, and prayer. What was the result of their devotion to these practices?,
      options: [They enjoyed the favor of all people and their numbers grew., They became divided., They became poor.", "They were persecuted without growth.].sort(() => Math.random() - 0.5),
      correctAnswer: They enjoyed the favor of all people and their numbers grew."
    })
  },
  {
    id: "G5-CRE-ACT-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Early Church in Acts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The early church shared their possessions and ensured that no one was in need. What does this example teach us about the nature of Christian fellowship?,
      options: [Christians are called to care for one another and share generously., Christians should keep everything for themselves., "Christians should be separate from each other., Christians should only care about their own needs."].sort(() => Math.random() - 0.5),
      correctAnswer: "Christians are called to care for one another and share generously.
    })
  },
  {
    id: G5-CRE-ACT-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Early Church in Acts",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The early church faced persecution but continued to grow. What was the mission of the early church as described in Acts 1:8?,
      options: [To be witnesses in Jerusalem, Judea, Samaria, and to the ends of the earth., To be witnesses only in Jerusalem., To be wealthy.", "To be famous.].sort(() => Math.random() - 0.5),
      correctAnswer: To be witnesses in Jerusalem, Judea, Samaria, and to the ends of the earth."
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (4 Materials) ---
  {
    id: "G5-CRE-TEN-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Loving God and Neighbors,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Ten Commandments can be divided into two categories: duties to God and duties to others. Which commandment teaches us to honor our parents?,
      options: [The fifth commandment, The first commandment, "The sixth commandment, The second commandment"].sort(() => Math.random() - 0.5),
      correctAnswer: "The fifth commandment
    })
  },
  {
    id: G5-CRE-TEN-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Loving God and Neighbors",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Jesus summarized the Ten Commandments into two great commandments. What are the two great commandments that summarize the law?,
      options: [Love the Lord your God and love your neighbor as yourself., Do not kill and do not steal., Honor your father and mother.", "Keep the Sabbath holy.].sort(() => Math.random() - 0.5),
      correctAnswer: Love the Lord your God and love your neighbor as yourself."
    })
  },
  {
    id: "G5-CRE-TEN-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Loving God and Neighbors,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The commandments that address our relationship with God include the first four commandments. What is the first and greatest commandment?,
      options: [Love the Lord your God with all your heart, soul, and mind., Do not have other gods., "Keep the Sabbath holy., Do not take the Lord's name in vain."].sort(() => Math.random() - 0.5),
      correctAnswer: "Love the Lord your God with all your heart, soul, and mind.
    })
  },
  {
    id: G5-CRE-TEN-04",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Loving God and Neighbors",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The commandments concerning our relationship with others include the last six commandments. Which commandment forbids stealing?,
      options: [The eighth commandment, The sixth commandment, The seventh commandment", "The ninth commandment].sort(() => Math.random() - 0.5),
      correctAnswer: The eighth commandment"
    })
  },

  // --- MADA: WORSHIP (3 Materials) ---
  {
    id: "G5-CRE-WOR-01",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "Worship",
    subtopic: "Worshiping God in Spirit and Truth,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jesus said that true worshipers worship the Father in spirit and truth. What does it mean to worship God in spirit?,
      options: [To worship with genuine devotion and sincerity from the heart., To worship in a specific building., "To worship with loud music., To worship only in Church."].sort(() => Math.random() - 0.5),
      correctAnswer: "To worship with genuine devotion and sincerity from the heart.
    })
  },
  {
    id: G5-CRE-WOR-02",
    grade: "Grade 5,
    subject: Christian Religious Education",
    topic: "Worship,
    subtopic: "Worshiping God in Spirit and Truth",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Worship is not just about singing songs; it is about surrendering our lives to God. How can we worship God in our daily lives?,
      options: [By living a life that honors Him and doing everything for His glory., By going to Church every day., By singing hymns all the time.", "By praying only.].sort(() => Math.random() - 0.5),
      correctAnswer: By living a life that honors Him and doing everything for His glory."
    })
  },
  {
    id: "G5-CRE-WOR-03",
    grade: "Grade 5",
    subject: "Christian Religious Education",
    topic: "Worship",
    subtopic: "Worshiping God in Spirit and Truth,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Psalmist declares that worship is both a personal and corporate act. How does corporate worship benefit the community of believers?,
      options: [It unites believers and glorifies God collectively., It creates division among believers., "It is only for the leaders., It is a private matter."].sort(() => Math.random() - 0.5),
      correctAnswer: "It unites believers and glorifies God collectively.
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE BIBLE (Canon and Authority) (4 Materials) ---
  {
    id: G6-CRE-BIB-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is God's Word",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Bible is the inspired Word of God. It is the authoritative source of truth for Christians. What does it mean that the Bible is 'inspired' by God?,
      options: [It means God guided the human authors to write exactly what He wanted., It means the authors wrote without any divine guidance., It means the Bible is a collection of myths.", "It means the Bible is just a history book.].sort(() => Math.random() - 0.5),
      correctAnswer: It means God guided the human authors to write exactly what He wanted."
    })
  },
  {
    id: "G6-CRE-BIB-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is God's Word,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Bible is composed of 66 books, divided into the Old and New Testaments. How is the Bible different from any other religious text?,
      options: [It is the unique revelation of God., It is just like any other religious book.", "It is a collection of stories., It is a moral guide only."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is the unique revelation of God.
    })
  },
  {
    id: G6-CRE-BIB-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Bible,
    subtopic: "The Bible is God's Word",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Bible is alive and active, sharper than any two-edged sword. What does this scripture mean for the believer?,
      options: [The Bible has the power to convict and transform lives., The Bible is just a physical book., The Bible is outdated.", "The Bible is meant only for scholars.].sort(() => Math.random() - 0.5),
      correctAnswer: The Bible has the power to convict and transform lives."
    })
  },
  {
    id: "G6-CRE-BIB-04",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Bible",
    subtopic: "The Bible is God's Word,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "All Scripture is God-breathed and is useful for teaching, rebuking, correcting, and training in righteousness. What is the ultimate purpose of the Bible?,
      options: ["To equip believers for every good work., To make us rich.", "To make us famous., To give us historical knowledge."].sort(() => Math.random() - 0.5),
      correctAnswer: "To equip believers for every good work.
    })
  },

  // --- MADA: THE LIFE OF JOSEPH (5 Materials) ---
  {
    id: G6-CRE-JOS-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Life of Joseph,
    subtopic: "Joseph's Journey from Slavery to Leadership",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Joseph was the favorite son of Jacob, which caused his brothers to hate him. They sold him into slavery. Where was Joseph taken as a slave?,
      options: [To Egypt, To Babylon, To Rome", "To Greece].sort(() => Math.random() - 0.5),
      correctAnswer: To Egypt"
    })
  },
  {
    id: "G6-CRE-JOS-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Life of Joseph",
    subtopic: "Joseph's Journey from Slavery to Leadership,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "While in Egypt, Joseph was falsely accused and put in prison. Despite his circumstances, he continued to trust God. What happened to Joseph in prison?,
      options: ["He interpreted the dreams of two of Pharaoh's officials., He escaped.", "He gave up on God., He was forgotten."].sort(() => Math.random() - 0.5),
      correctAnswer: "He interpreted the dreams of two of Pharaoh's officials.
    })
  },
  {
    id: G6-CRE-JOS-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Life of Joseph,
    subtopic: "Joseph's Journey from Slavery to Leadership",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Joseph interpreted Pharaoh's dream about a coming famine and was promoted to second-in-command of Egypt. What does Joseph's rise to power teach us about God's sovereignty?,
      options: [God can use any situation to fulfill His purposes and exalt the humble., God only helps the rich., God only helps those who are born into privilege.", "God doesn't care about our lives.].sort(() => Math.random() - 0.5),
      correctAnswer: God can use any situation to fulfill His purposes and exalt the humble."
    })
  },
  {
    id: "G6-CRE-JOS-04",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Life of Joseph",
    subtopic: "Joseph's Journey from Slavery to Leadership,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Joseph's brothers came to Egypt to buy food during the famine. Instead of seeking revenge, Joseph forgave them. What does Joseph's forgiveness teach us?,
      options: [We should forgive others as God has forgiven us., We should seek revenge.", "We should hold grudges., We should never forgive."].sort(() => Math.random() - 0.5),
      correctAnswer: "We should forgive others as God has forgiven us.
    })
  },
  {
    id: G6-CRE-JOS-05",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Life of Joseph,
    subtopic: "Joseph's Journey from Slavery to Leadership",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Joseph's story is a powerful example of God's sovereignty and redemption. How does Joseph's story encourage believers today?,
      options: [It shows that God can work all things for good for those who love Him., It shows that God only works for good for the rich., It shows that life is just a game of chance.", "It shows that God is distant and uncaring.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows that God can work all things for good for those who love Him."
    })
  },

  // --- MADA: THE EXODUS (4 Materials) ---
  {
    id: "G6-CRE-EXO-01",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Exodus",
    subtopic: "The Passover and the Exodus from Egypt,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Moses led the Israelites out of slavery in Egypt. What was the final plague that convinced Pharaoh to let the people go?,
      options: [The death of the firstborn., The plague of frogs., "The plague of boils., The plague of hail."].sort(() => Math.random() - 0.5),
      correctAnswer: "The death of the firstborn.
    })
  },
  {
    id: G6-CRE-EXO-02",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Exodus,
    subtopic: "The Passover and the Exodus from Egypt",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Passover was instituted to commemorate the night when the angel of death passed over the homes of the Israelites. What did the Israelites put on their doorposts to indicate that they were God's people?,
      options: [The blood of a lamb., A sign of the cross., A golden calf.", "A piece of bread.].sort(() => Math.random() - 0.5),
      correctAnswer: The blood of a lamb."
    })
  },
  {
    id: "G6-CRE-EXO-03",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Exodus",
    subtopic: "The Passover and the Exodus from Egypt,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Exodus is a foundational event in Israelite history. It demonstrates God's power and faithfulness. What does the Exodus foreshadow in the New Testament?,
      options: [The sacrifice of Jesus Christ., The building of the Temple., "The fall of Rome., The birth of the nation of Israel."].sort(() => Math.random() - 0.5),
      correctAnswer: "The sacrifice of Jesus Christ.
    })
  },
  {
    id: G6-CRE-EXO-04",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Exodus,
    subtopic: "The Passover and the Exodus from Egypt",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " After the Israelites left Egypt, they crossed the Red Sea on dry ground while Pharaoh's army was drowned. What does the parting of the Red Sea reveal about God?,
      options: [God is powerful and saves His people., God is weak and powerless., God is indifferent to the people's plight.", "God is a myth.].sort(() => Math.random() - 0.5),
      correctAnswer: God is powerful and saves His people."
    })
  },

  // --- MADA: THE WILDERNESS JOURNEY (4 Materials) ---
  {
    id: "G6-CRE-WIL-01",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Wilderness Journey",
    subtopic: "Manna and Water from the Rock,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "During their journey in the wilderness, the Israelites complained about hunger. What did God provide for them to eat?,
      options: [Manna from heaven., Bread from heaven.", "Fish from heaven., Meat from heaven."].sort(() => Math.random() - 0.5),
      correctAnswer: "Manna from heaven.
    })
  },
  {
    id: G6-CRE-WIL-02",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Wilderness Journey,
    subtopic: "Manna and Water from the Rock",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Israelites also complained about a lack of water. God instructed Moses to strike a rock, and water gushed out. What does this miracle reveal about God's provision?,
      options: [God is able to provide for His people in miraculous ways., God is only able to provide food., God is not able to provide water.", "God only provides when we are obedient.].sort(() => Math.random() - 0.5),
      correctAnswer: God is able to provide for His people in miraculous ways."
    })
  },
  {
    id: "G6-CRE-WIL-03",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Wilderness Journey",
    subtopic: "The Bronze Serpent,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Israelites were bitten by venomous snakes in the wilderness. Moses made a bronze serpent and lifted it up. What happened to those who looked at the bronze serpent?,
      options: [They were healed and lived., They died anyway., "They were cursed., They became sick."].sort(() => Math.random() - 0.5),
      correctAnswer: "They were healed and lived.
    })
  },
  {
    id: G6-CRE-WIL-04",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Wilderness Journey,
    subtopic: "Lessons from the Wilderness",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Israelites' journey through the wilderness was a time of testing and learning. What is the main lesson we can learn from Israel's wilderness experience?,
      options: [God is faithful even when His people are faithless., God only blesses the obedient., God is harsh and punishing.", "God abandons His people when they stray.].sort(() => Math.random() - 0.5),
      correctAnswer: God is faithful even when His people are faithless."
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (5 Materials) ---
  {
    id: "G6-CRE-TEN-01",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "The Meaning of Each Commandment,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Ten Commandments are a summary of God's moral law. What is the purpose of the Ten Commandments for believers today?,
      options: [They reveal God's holiness and our need for a Savior., They are only for ancient Israel., "They are irrelevant today., They are a path to salvation."].sort(() => Math.random() - 0.5),
      correctAnswer: "They reveal God's holiness and our need for a Savior.
    })
  },
  {
    id: G6-CRE-TEN-02",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "The Meaning of Each Commandment",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The first commandment states: 'You shall have no other gods before me.' What does this commandment teach us about God's desire for our hearts?,
      options: [God wants our exclusive devotion and worship., God is jealous and insecure., God is just one of many gods.", "God is indifferent.].sort(() => Math.random() - 0.5),
      correctAnswer: God wants our exclusive devotion and worship."
    })
  },
  {
    id: "G6-CRE-TEN-03",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "The Meaning of Each Commandment,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Sabbath commandment calls believers to set aside a day for rest and worship. What is the spiritual principle behind the Sabbath?,
      options: [It reminds us of God's creation and redemption., It is a day to work harder., "It is a day to do nothing., It is only for the priests."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reminds us of God's creation and redemption.
    })
  },
  {
    id: G6-CRE-TEN-04",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "The Meaning of Each Commandment",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The sixth commandment says: 'You shall not murder.' What does this commandment teach about the value of human life?,
      options: [Human life is sacred and created by God., Human life is not important., Human life is disposable.", "Human life is only valuable if one is rich.].sort(() => Math.random() - 0.5),
      correctAnswer: Human life is sacred and created by God."
    })
  },
  {
    id: "G6-CRE-TEN-05",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "The Meaning of Each Commandment,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The tenth commandment says: 'You shall not covet.' What does this commandment warn against?,
      options: [Jealousy and discontentment with what others have., Desiring material things., "Being greedy., All of the above."].sort(() => Math.random() - 0.5),
      correctAnswer: "All of the above.
    })
  },

  // --- MADA: JESUS' MIRACLES (4 Materials) ---
  {
    id: G6-CRE-MIR-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Calming the Storm",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Jesus was asleep in the boat when a violent storm arose. The disciples were terrified and woke Him up. How did Jesus respond to the storm?,
      options: [He rebuked the wind and the waves, and it became perfectly calm., He hid in fear., He abandoned the boat.", "He called for help.].sort(() => Math.random() - 0.5),
      correctAnswer: He rebuked the wind and the waves, and it became perfectly calm."
    })
  },
  {
    id: "G6-CRE-MIR-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Calming the Storm,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "After Jesus calmed the storm, the disciples were amazed and asked, 'What kind of man is this?' What does this miracle reveal about Jesus' identity?,
      options: ["He has authority over nature and is truly God., He is just a good teacher.", "He is a magician., He is a lucky man."].sort(() => Math.random() - 0.5),
      correctAnswer: "He has authority over nature and is truly God.
    })
  },
  {
    id: G6-CRE-MIR-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Feeding the 5",000",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Jesus fed over 5,000 people with just five loaves of bread and two fish. What does this miracle demonstrate about Jesus?,
      options: [He is the bread of life and can provide for all needs., He is a good cook., He is a miracle worker.", "He is a magician.].sort(() => Math.random() - 0.5),
      correctAnswer: He is the bread of life and can provide for all needs."
    })
  },
  {
    id: "G6-CRE-MIR-04",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Healing the Blind,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Jesus healed a man who was born blind by spitting on the ground, making mud, and applying it to the man's eyes. What does this healing reveal about Jesus?,
      options: ["He is the light of the world and can open spiritual eyes., He is a doctor.", "He is a healer., He is a magician."].sort(() => Math.random() - 0.5),
      correctAnswer: "He is the light of the world and can open spiritual eyes.
    })
  },

  // --- MADA: THE PARABLES (4 Materials) ---
  {
    id: G6-CRE-PAR-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Parables,
    subtopic: "The Parable of the Good Samaritan",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " In the Parable of the Good Samaritan, a man was beaten and left for dead. A priest and a Levite passed by, but a Samaritan stopped to help. Who is the Samaritan in the story?,
      options: [A despised outsider who showed true compassion., A priest., A rich man.", "A soldier.].sort(() => Math.random() - 0.5),
      correctAnswer: A despised outsider who showed true compassion."
    })
  },
  {
    id: "G6-CRE-PAR-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Parables",
    subtopic: "The Parable of the Good Samaritan,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The Parable of the Good Samaritan teaches us about the nature of true love. According to the parable, who is our neighbor?,
      options: [Anyone who is in need, regardless of their background., Only our friends.", "Only our relatives., Only those who are like us."].sort(() => Math.random() - 0.5),
      correctAnswer: "Anyone who is in need, regardless of their background.
    })
  },
  {
    id: G6-CRE-PAR-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Parables,
    subtopic: "The Parable of the Lost Sheep",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " In the Parable of the Lost Sheep, a shepherd leaves the ninety-nine sheep to go after the one that is lost. What does this parable reveal about God's heart for sinners?,
      options: [He rejoices over one repentant sinner., He is angry at sinners., He ignores sinners.", "He only cares about the righteous.].sort(() => Math.random() - 0.5),
      correctAnswer: He rejoices over one repentant sinner."
    })
  },
  {
    id: "G6-CRE-PAR-04",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Parables",
    subtopic: "The Parable of the Lost Sheep,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "When the shepherd finds the lost sheep, he rejoices and celebrates. What does the celebration signify in the context of God's kingdom?,
      options: [There is great joy in heaven over one sinner who repents., There is great joy in heaven over the righteous.", "There is great joy in heaven over wealth., There is great joy in heaven over the powerful."].sort(() => Math.random() - 0.5),
      correctAnswer: "There is great joy in heaven over one sinner who repents.
    })
  },

  // --- MADA: THE HOLY SPIRIT (3 Materials) ---
  {
    id: G6-CRE-SPI-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Holy Spirit Empowers Believers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Jesus promised to send the Holy Spirit to empower His followers. What did the disciples receive on the day of Pentecost?,
      options: [They received the power of the Holy Spirit and spoke in other tongues., They received the gift of prophecy., They received the gift of healing.", "They received wealth.].sort(() => Math.random() - 0.5),
      correctAnswer: They received the power of the Holy Spirit and spoke in other tongues."
    })
  },
  {
    id: "G6-CRE-SPI-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Holy Spirit Empowers Believers,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Holy Spirit gives believers spiritual gifts to build up the church. What is the purpose of spiritual gifts in the community of believers?,
      options: [They are given for the common good and to serve others., They are for personal glory., "They are for making money., They are for personal enjoyment."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are given for the common good and to serve others.
    })
  },
  {
    id: G6-CRE-SPI-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Holy Spirit Empowers Believers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Holy Spirit helps believers in their weakness and intercedes for them with groans that words cannot express. How does the Holy Spirit intercede for believers?,
      options: [He prays according to God's will., He prays for their success., He prays for their health.", "He prays for their wealth.].sort(() => Math.random() - 0.5),
      correctAnswer: He prays according to God's will."
    })
  },

  // --- MADA: THE CHURCH (The Mission of the Church) (3 Materials) ---
  {
    id: "G6-CRE-MIS-01",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Mission of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The mission of the Church is to spread the gospel and make disciples of all nations. What is the gospel message that the Church is called to proclaim?,
      options: [The death and resurrection of Jesus Christ for the forgiveness of sins., The building of the Temple., "The history of Israel., The laws of Moses."].sort(() => Math.random() - 0.5),
      correctAnswer: "The death and resurrection of Jesus Christ for the forgiveness of sins.
    })
  },
  {
    id: G6-CRE-MIS-02",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Mission of the Church",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Church is called to be a light to the world and to serve others. How can the Church serve its community?,
      options: [By meeting both spiritual and physical needs., By building big buildings., By collecting money.", "By making laws.].sort(() => Math.random() - 0.5),
      correctAnswer: By meeting both spiritual and physical needs."
    })
  },
  {
    id: "G6-CRE-MIS-03",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Mission of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Church is the body of Christ on earth. As the body of Christ, what is the Church's ultimate purpose?,
      options: [To glorify God and advance His kingdom., To build big churches.", "To become wealthy., To gain political power."].sort(() => Math.random() - 0.5),
      correctAnswer: "To glorify God and advance His kingdom.
    })
  },

  // --- MADA: THE ARMOR OF GOD (3 Materials) ---
  {
    id: G6-CRE-ARM-01",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Armor of God,
    subtopic: "Spiritual Warfare and Protection",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Paul describes the armor of God as a means of protection against spiritual forces. What is the belt of truth used for?,
      options: [It symbolizes truthfulness and integrity., It is a weapon., It is a piece of jewelry.", "It is a symbol of power.].sort(() => Math.random() - 0.5),
      correctAnswer: It symbolizes truthfulness and integrity."
    })
  },
  {
    id: "G6-CRE-ARM-02",
    grade: "Grade 6",
    subject: "Christian Religious Education",
    topic: "The Armor of God",
    subtopic: "Spiritual Warfare and Protection,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The shield of faith is part of the armor of God. What is the purpose of the shield of faith?,
      options: [It extinguishes the fiery darts of the evil one., It is a physical shield., "It is a weapon., It is a symbol of power."].sort(() => Math.random() - 0.5),
      correctAnswer: "It extinguishes the fiery darts of the evil one.
    })
  },
  {
    id: G6-CRE-ARM-03",
    grade: "Grade 6,
    subject: Christian Religious Education",
    topic: "The Armor of God,
    subtopic: "Spiritual Warfare and Protection",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The sword of the Spirit is the word of God. How is the word of God used as a weapon in spiritual warfare?,
      options: [It is used to counter lies and temptations., It is a physical sword., It is a symbol of power.", "It is a symbol of authority.].sort(() => Math.random() - 0.5),
      correctAnswer: It is used to counter lies and temptations."
    })
  }
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD JUNIOR SECONDARY CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE NATURE OF GOD (5 Materials) ---
  {
    id: "G7-CRE-GOD-01",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God is Creator, Sustainer, and Provider,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Bible teaches that God is the Creator of the heavens and the earth. What does it mean that God is also the Sustainer of the universe?,
      options: [He upholds and maintains all of creation., He created the universe and left it alone., "He only cares about the earth., He only sustains the righteous."].sort(() => Math.random() - 0.5),
      correctAnswer: "He upholds and maintains all of creation.
    })
  },
  {
    id: G7-CRE-GOD-02",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Nature of God,
    subtopic: "God is Creator", Sustainer, and Provider",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " God is not only the Creator of all things, but He also provides for His creation. Which Bible verse describes God's provision for the birds of the air?,
      options: [Matthew 6:26, Genesis 1:1, John 3:16", "Psalm 23:1].sort(() => Math.random() - 0.5),
      correctAnswer: Matthew 6:26"
    })
  },
  {
    id: "G7-CRE-GOD-03",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God is Creator, Sustainer, and Provider,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "God's sustaining power is evident in the order and complexity of creation. What does the order of the universe tell us about the nature of God?,
      options: [God is a God of order, not confusion., God is a God of confusion., "God is indifferent to the universe., God is limited in His power."].sort(() => Math.random() - 0.5),
      correctAnswer: "God is a God of order, not confusion.
    })
  },
  {
    id: G7-CRE-GOD-04",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Nature of God,
    subtopic: "God is Creator", Sustainer, and Provider",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Because God provides for all living things, we can trust Him with our daily needs. What does the Bible say about God's provision for His children?,
      options: [He will supply all our needs according to His riches., He only provides for the rich., He only provides for the poor.", "He provides for everyone equally.].sort(() => Math.random() - 0.5),
      correctAnswer: He will supply all our needs according to His riches."
    })
  },
  {
    id: "G7-CRE-GOD-05",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God is Creator, Sustainer, and Provider,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "God's role as Provider is seen throughout Scripture, from manna in the wilderness to Jesus feeding the 5,000. What does this teach us about God's character?,
      options: ["God is compassionate and cares for His people., God is harsh and demanding.", "God is indifferent to human needs., God is only concerned with spiritual matters."].sort(() => Math.random() - 0.5),
      correctAnswer: "God is compassionate and cares for His people.
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (5 Materials) ---
  {
    id: G7-CRE-TEN-01",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Understanding and Applying the Ten Commandments",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Ten Commandments are a moral and ethical foundation for believers. How can the Ten Commandments be applied to our daily lives today?,
      options: [They guide us in our relationship with God and with others., They are only for the Jews., They are outdated.", "They are impossible to follow.].sort(() => Math.random() - 0.5),
      correctAnswer: They guide us in our relationship with God and with others."
    })
  },
  {
    id: "G7-CRE-TEN-02",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Understanding and Applying the Ten Commandments,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Ten Commandments can be divided into two groups: duties to God and duties to others. Why is keeping the Sabbath holy considered a commandment to God?,
      options: [It honors God by setting aside a day for rest and worship., It is a day to work., "It is a day to do nothing., It is a day to shop."].sort(() => Math.random() - 0.5),
      correctAnswer: "It honors God by setting aside a day for rest and worship.
    })
  },
  {
    id: G7-CRE-TEN-03",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Understanding and Applying the Ten Commandments",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The commandment 'Honor your father and mother' is the first commandment with a promise. What is the promise that accompanies this commandment?,
      options: [That it may go well with you and you may enjoy long life., That you will become rich., That you will be famous.", "That you will never die.].sort(() => Math.random() - 0.5),
      correctAnswer: That it may go well with you and you may enjoy long life."
    })
  },
  {
    id: "G7-CRE-TEN-04",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Understanding and Applying the Ten Commandments,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The commandment 'You shall not commit adultery' focuses on the sanctity of marriage. Why is faithfulness in marriage important in the Christian faith?,
      options: [It honors God's design for marriage and reflects Christ's love for the church., It is just a rule., "It doesn't matter., It is only for the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "It honors God's design for marriage and reflects Christ's love for the church.
    })
  },
  {
    id: G7-CRE-TEN-05",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Understanding and Applying the Ten Commandments",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The commandment 'You shall not covet' addresses the desires of the heart. What does coveting lead to according to the Bible?,
      options: [Jealousy, discontentment, and even further sin., Happiness and contentment., Wealth and success.", "Peace and joy.].sort(() => Math.random() - 0.5),
      correctAnswer: Jealousy, discontentment, and even further sin."
    })
  },

  // --- MADA: THE LIFE OF JESUS (5 Materials) ---
  {
    id: "G7-CRE-LIF-01",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "The Birth and Baptism of Jesus,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Jesus was born in a humble stable in Bethlehem, fulfilling Old Testament prophecy. Which Old Testament prophet foretold the birth of Jesus in Bethlehem?,
      options: [Micah, Isaiah", "Jeremiah, Hosea"].sort(() => Math.random() - 0.5),
      correctAnswer: "Micah
    })
  },
  {
    id: G7-CRE-LIF-02",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Life of Jesus,
    subtopic: "The Birth and Baptism of Jesus",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Jesus was baptized by John the Baptist in the Jordan River. At His baptism, the heavens opened and the Holy Spirit descended on Him. What did the voice from heaven say at Jesus' baptism?,
      options: [This is my Son, whom I love; with Him I am well pleased., This is a good man., He is a prophet.", "He is a teacher.].sort(() => Math.random() - 0.5),
      correctAnswer: This is my Son, whom I love; with Him I am well pleased."
    })
  },
  {
    id: "G7-CRE-LIF-03",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "The Temptation of Jesus,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "After His baptism, Jesus was led into the wilderness where He was tempted by Satan for 40 days. What was the first temptation that Satan presented to Jesus?,
      options: [To turn stones into bread., To bow down and worship him.", "To throw Himself from the temple., To provide water from the rock."].sort(() => Math.random() - 0.5),
      correctAnswer: "To turn stones into bread.
    })
  },
  {
    id: G7-CRE-LIF-04",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Life of Jesus,
    subtopic: "The Temptation of Jesus",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Satan tempted Jesus three times, but Jesus responded to each temptation with Scripture. What is the significance of Jesus using Scripture to resist temptation?,
      options: [It shows the power of God's Word as a weapon against sin., It shows that Jesus was good at quoting the Bible., It shows that Scripture is only for religious leaders.", "It shows that Scripture is not helpful.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows the power of God's Word as a weapon against sin."
    })
  },
  {
    id: "G7-CRE-LIF-05",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "The Temptation of Jesus,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "After Jesus resisted Satan's temptations, angels came and ministered to Him. What does this incident teach us about God's care for His servants?,
      options: [God provides strength and encouragement after trials., God is always angry with those who are tempted.", "God only helps the perfect., God abandons those who are tempted."].sort(() => Math.random() - 0.5),
      correctAnswer: "God provides strength and encouragement after trials.
    })
  },

  // --- MADA: JESUS' TEACHINGS (5 Materials) ---
  {
    id: G7-CRE-TEA-01",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Jesus' Teachings,
    subtopic: "The Beatitudes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The Beatitudes are a collection of blessings taught by Jesus in the Sermon on the Mount. Which Beatitude promises that the meek will inherit the earth?,
      options: [Blessed are the meek, for they will inherit the earth., Blessed are the poor in spirit., Blessed are those who mourn.", "Blessed are the merciful.].sort(() => Math.random() - 0.5),
      correctAnswer: Blessed are the meek, for they will inherit the earth."
    })
  },
  {
    id: "G7-CRE-TEA-02",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Jesus' Teachings",
    subtopic: "The Beatitudes,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The Beatitudes describe the character of those who are blessed in God's kingdom. What does 'Blessed are the pure in heart, for they will see God' mean?,
      options: [Those with a pure heart will experience God's presence., Those with a pure heart will be rich.", "Those with a pure heart will be famous., Those with a pure heart will be powerful."].sort(() => Math.random() - 0.5),
      correctAnswer: "Those with a pure heart will experience God's presence.
    })
  },
  {
    id: G7-CRE-TEA-03",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Jesus' Teachings,
    subtopic: "The Beatitudes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The Beatitudes call believers to live a life of humility, mercy, and righteousness. How do the Beatitudes differ from the values of the world?,
      options: [They celebrate humility and dependence on God rather than pride and self-sufficiency., They celebrate pride and self-sufficiency., They are exactly the same as the world's values.", "They are only for the poor.].sort(() => Math.random() - 0.5),
      correctAnswer: They celebrate humility and dependence on God rather than pride and self-sufficiency."
    })
  },
  {
    id: "G7-CRE-TEA-04",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Jesus' Teachings",
    subtopic: "The Sermon on the Mount,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "In the Sermon on the Mount, Jesus taught about prayer, fasting, and almsgiving. What was the main theme of the Sermon on the Mount?,
      options: ["The nature of the kingdom of God and how to live as its citizens., The building of the Temple.", "The history of Israel., The laws of Moses."].sort(() => Math.random() - 0.5),
      correctAnswer: "The nature of the kingdom of God and how to live as its citizens.
    })
  },
  {
    id: G7-CRE-TEA-05",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Jesus' Teachings,
    subtopic: "The Sermon on the Mount",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Jesus taught His disciples to pray using the Lord's Prayer. What is the central request in the Lord's Prayer?,
      options: [Thy kingdom come, Thy will be done., Give us wealth., Give us power.", "Give us fame.].sort(() => Math.random() - 0.5),
      correctAnswer: Thy kingdom come, Thy will be done."
    })
  },

  // --- MADA: JESUS' MIRACLES (5 Materials) ---
  {
    id: "G7-CRE-MIR-01",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus' Power Over Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Jesus demonstrated His power over nature by calming a violent storm. What did the disciples learn about Jesus from this miracle?,
      options: [He has authority over nature and is truly God., He is just a good teacher., "He is a magician., He is a lucky man."].sort(() => Math.random() - 0.5),
      correctAnswer: "He has authority over nature and is truly God.
    })
  },
  {
    id: G7-CRE-MIR-02",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus' Power Over Nature",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Another miracle demonstrating Jesus' power over nature was walking on water. What did Peter attempt to do when he saw Jesus walking on the water?,
      options: [He also walked on the water toward Jesus., He ran away., He stayed in the boat.", "He jumped into the water and swam.].sort(() => Math.random() - 0.5),
      correctAnswer: He also walked on the water toward Jesus."
    })
  },
  {
    id: "G7-CRE-MIR-03",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus' Power Over Sickness,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Jesus healed many people, demonstrating His power over sickness. One time, He healed a man with leprosy. How did Jesus heal the leper?,
      options: ["He touched him and said, 'Be clean.', He prayed for him.", "He gave him medicine., He sent him to a doctor."].sort(() => Math.random() - 0.5),
      correctAnswer: "He touched him and said, 'Be clean.'
    })
  },
  {
    id: G7-CRE-MIR-04",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Jesus' Miracles,
    subtopic: "Jesus' Power Over Demons",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Jesus also cast out demons, demonstrating His authority over the spiritual realm. In the region of the Gerasenes, He cast out a legion of demons from a man. What did the demons do after being cast out?,
      options: [They entered a herd of pigs., They returned to the man., They entered a boat.", "They fled to the wilderness.].sort(() => Math.random() - 0.5),
      correctAnswer: They entered a herd of pigs."
    })
  },
  {
    id: "G7-CRE-MIR-05",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Jesus' Miracles",
    subtopic: "Jesus' Power Over Sickness,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Jesus healed a paralytic who was lowered through the roof by his friends. What did Jesus say to the paralytic before he healed him?,
      options: ['Your sins are forgiven.', 'You are a good man.', "'You will walk again.', 'You are healed.'"].sort(() => Math.random() - 0.5),
      correctAnswer: "'Your sins are forgiven.'
    })
  },

  // --- MADA: THE HOLY SPIRIT (5 Materials) ---
  {
    id: G7-CRE-SPI-01",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Work of the Holy Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Holy Spirit is the third person of the Trinity. What is the primary role of the Holy Spirit in the life of a believer?,
      options: [He convicts, guides, teaches, and empowers believers., He is only for the apostles., He is only for the prophets.", "He is only for the church leaders.].sort(() => Math.random() - 0.5),
      correctAnswer: He convicts, guides, teaches, and empowers believers."
    })
  },
  {
    id: "G7-CRE-SPI-02",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Work of the Holy Spirit,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Holy Spirit helps believers in their weakness and intercedes for them. How does the Holy Spirit empower believers to live a godly life?,
      options: [He gives them the strength to overcome sin and temptation., He gives them magical powers., "He makes them perfect., He gives them wealth."].sort(() => Math.random() - 0.5),
      correctAnswer: "He gives them the strength to overcome sin and temptation.
    })
  },
  {
    id: G7-CRE-SPI-03",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Work of the Holy Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The Holy Spirit inspired the writers of the Bible and reveals truth to believers. What is the role of the Holy Spirit in understanding Scripture?,
      options: [He illuminates the Word of God and helps us apply it to our lives., He makes it difficult to understand., He hides the truth from us.", "He is not involved in Scripture.].sort(() => Math.random() - 0.5),
      correctAnswer: He illuminates the Word of God and helps us apply it to our lives."
    })
  },
  {
    id: "G7-CRE-SPI-04",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Work of the Holy Spirit,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Holy Spirit convicts the world of sin, righteousness, and judgment. How does the Holy Spirit convict a believer of sin?,
      options: ["He reveals sin and leads the believer to repentance., He scares the believer.", "He punishes the believer., He ignores the believer."].sort(() => Math.random() - 0.5),
      correctAnswer: "He reveals sin and leads the believer to repentance.
    })
  },
  {
    id: G7-CRE-SPI-05",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Gifts of the Holy Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Holy Spirit gives spiritual gifts to believers for the building up of the church. What is the purpose of spiritual gifts in the church?,
      options: [They are given for the common good and to serve others., They are for personal glory., They are for making money.", "They are for personal enjoyment.].sort(() => Math.random() - 0.5),
      correctAnswer: They are given for the common good and to serve others."
    })
  },

  // --- MADA: THE EARLY CHURCH (5 Materials) ---
  {
    id: "G7-CRE-EAR-01",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Early Church",
    subtopic: "Pentecost and the Growth of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The birth of the church took place on the day of Pentecost. What happened when the Holy Spirit descended on the disciples on that day?,
      options: [They spoke in different tongues and Peter preached a powerful sermon., They built a temple., "They ran away., They fell asleep."].sort(() => Math.random() - 0.5),
      correctAnswer: "They spoke in different tongues and Peter preached a powerful sermon.
    })
  },
  {
    id: G7-CRE-EAR-02",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Early Church,
    subtopic: "Pentecost and the Growth of the Church",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " After Peter's sermon on the day of Pentecost, about 3,000 people were added to the church. What does this rapid growth indicate about the power of the Holy Spirit?,
      options: [The Holy Spirit works powerfully through the proclamation of the gospel., The Holy Spirit only works through a few people., The Holy Spirit does not care about numbers.", "The Holy Spirit works slowly.].sort(() => Math.random() - 0.5),
      correctAnswer: The Holy Spirit works powerfully through the proclamation of the gospel."
    })
  },
  {
    id: "G7-CRE-EAR-03",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Early Church",
    subtopic: "Pentecost and the Growth of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The early church devoted themselves to fellowship, breaking bread, and prayer. What was the result of their commitment to these practices?,
      options: ["The church grew both spiritually and numerically., The church became divided.", "The church became poor., The church lost its focus."].sort(() => Math.random() - 0.5),
      correctAnswer: "The church grew both spiritually and numerically.
    })
  },
  {
    id: G7-CRE-EAR-04",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "The Early Church,
    subtopic: "Pentecost and the Growth of the Church",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The early church shared their possessions so that no one was in need. What does this example teach us about the nature of Christian fellowship?,
      options: [Christians are called to care for and share with one another., Christians should keep everything for themselves., Christians should be separate from each other.", "Christians should only care about their own needs.].sort(() => Math.random() - 0.5),
      correctAnswer: Christians are called to care for and share with one another."
    })
  },
  {
    id: "G7-CRE-EAR-05",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "The Early Church",
    subtopic: "Pentecost and the Growth of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The early church faced persecution but continued to spread the gospel. What did the leaders of the early church believe about suffering for Christ?,
      options: [They considered it a privilege to suffer for Jesus., They avoided it at all costs., "They only endured it when necessary., They believed it was a punishment from God."].sort(() => Math.random() - 0.5),
      correctAnswer: "They considered it a privilege to suffer for Jesus.
    })
  },

  // --- MADA: CHRISTIAN ETHICS (5 Materials) ---
  {
    id: G7-CRE-ETH-01",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Living a Life Pleasing to God",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Bible calls believers to live lives that are holy and pleasing to God. What does it mean to live a life that is pleasing to God?,
      options: [It means living in obedience to God's commands and seeking His will., It means doing whatever we want., It means being perfect.", "It means never making mistakes.].sort(() => Math.random() - 0.5),
      correctAnswer: It means living in obedience to God's commands and seeking His will."
    })
  },
  {
    id: "G7-CRE-ETH-02",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Living a Life Pleasing to God,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Honesty and integrity are key aspects of Christian ethics. Why is honesty important in the life of a Christian?,
      options: [It reflects the character of God and builds trust., It is not that important., "It is only important for leaders., It is only important for children."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reflects the character of God and builds trust.
    })
  },
  {
    id: G7-CRE-ETH-03",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Living a Life Pleasing to God",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The Bible encourages believers to be kind and compassionate to others. How can a Christian demonstrate compassion in their daily life?,
      options: [By helping those in need and showing empathy., By ignoring the needs of others., By being selfish.", "By being indifferent.].sort(() => Math.random() - 0.5),
      correctAnswer: By helping those in need and showing empathy."
    })
  },
  {
    id: "G7-CRE-ETH-04",
    grade: "Grade 7",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Living a Life Pleasing to God,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The Bible also teaches that believers should be peacemakers. What does it mean to be a peacemaker in the context of Christian ethics?,
      options: [To actively work toward reconciliation and harmony., To avoid conflict., "To give in to others., To stay neutral."].sort(() => Math.random() - 0.5),
      correctAnswer: "To actively work toward reconciliation and harmony.
    })
  },
  {
    id: G7-CRE-ETH-05",
    grade: "Grade 7,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Living a Life Pleasing to God",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Christian ethics are rooted in the love of God and the love of neighbor. What did Jesus say is the greatest commandment?,
      options: [To love the Lord your God with all your heart, soul, mind, and strength., To honor your father and mother., To not steal.", "To not kill.].sort(() => Math.random() - 0.5),
      correctAnswer: To love the Lord your God with all your heart, soul, mind, and strength."
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD JUNIOR SECONDARY CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE NATURE OF GOD (5 Materials) ---
  {
    id: "G8-CRE-GOD-01",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God's Holiness, Justice, and Mercy,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Bible describes God as holy, just, and merciful. What does it mean that God is holy?,
      options: ["He is completely pure and separate from sin., He is distant and uncaring.", "He is strict and punishing., He is only concerned with rules."].sort(() => Math.random() - 0.5),
      correctAnswer: "He is completely pure and separate from sin.
    })
  },
  {
    id: G8-CRE-GOD-02",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Nature of God,
    subtopic: "God's Holiness", Justice, and Mercy",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " God is just and will judge the world in righteousness. However, His justice is balanced by His mercy. How do God's justice and mercy work together?,
      options: [God's justice demands punishment for sin, but His mercy provides forgiveness through Christ., God's justice and mercy are opposites., God's mercy overrides His justice.", "God's justice ignores sin.].sort(() => Math.random() - 0.5),
      correctAnswer: God's justice demands punishment for sin, but His mercy provides forgiveness through Christ."
    })
  },
  {
    id: "G8-CRE-GOD-03",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God's Holiness, Justice, and Mercy,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "God's mercy is demonstrated in His patience and forgiveness toward sinners. What does the Bible say about God's mercy?,
      options: [The Lord is merciful and gracious, slow to anger, and abounding in love., The Lord is harsh and unforgiving., "The Lord only shows mercy to the righteous., The Lord's mercy has limits."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Lord is merciful and gracious, slow to anger, and abounding in love.
    })
  },
  {
    id: G8-CRE-GOD-04",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Nature of God,
    subtopic: "God's Holiness", Justice, and Mercy",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The holiness of God calls His people to be holy. What does it mean for believers to be holy as God is holy?,
      options: [It means living a life set apart for God and reflecting His character., It means being perfect and sinless., It means following rules perfectly.", "It means being separate from everyone else.].sort(() => Math.random() - 0.5),
      correctAnswer: It means living a life set apart for God and reflecting His character."
    })
  },
  {
    id: "G8-CRE-GOD-05",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Nature of God",
    subtopic: "God's Holiness, Justice, and Mercy,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The cross of Christ perfectly displays the holiness, justice, and mercy of God. How does the cross demonstrate all three attributes of God?,
      options: ["It shows His justice in punishing sin and His mercy in offering forgiveness, while upholding His holiness., It shows His mercy alone.", "It shows His justice alone., It shows His holiness alone."].sort(() => Math.random() - 0.5),
      correctAnswer: "It shows His justice in punishing sin and His mercy in offering forgiveness, while upholding His holiness.
    })
  },

  // --- MADA: THE TEN COMMANDMENTS (5 Materials) ---
  {
    id: G8-CRE-TEN-01",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Deeper Reflection on the Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Ten Commandments are not just a list of rules; they reveal the character of God. How do the Ten Commandments reveal God's character?,
      options: [They reveal His holiness, His concern for justice, and His desire for relationship., They reveal His anger., They reveal His indifference.", "They reveal His limitations.].sort(() => Math.random() - 0.5),
      correctAnswer: They reveal His holiness, His concern for justice, and His desire for relationship."
    })
  },
  {
    id: "G8-CRE-TEN-02",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Deeper Reflection on the Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The first four commandments focus on our relationship with God. What does the first commandment, 'You shall have no other gods before me,' teach us about our devotion to God?,
      options: ["God demands exclusive loyalty and worship., God is just one of many gods.", "God is not concerned with our devotion., God is jealous and insecure."].sort(() => Math.random() - 0.5),
      correctAnswer: "God demands exclusive loyalty and worship.
    })
  },
  {
    id: G8-CRE-TEN-03",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Deeper Reflection on the Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The last six commandments focus on our relationship with others. What does the commandment 'You shall not bear false witness against your neighbor' teach us about truthfulness?,
      options: [We must speak the truth and not deceive others., We can lie if it is convenient., We can lie to protect ourselves.", "Truthfulness is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: We must speak the truth and not deceive others."
    })
  },
  {
    id: "G8-CRE-TEN-04",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Ten Commandments",
    subtopic: "Deeper Reflection on the Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The commandment 'You shall not covet' addresses the internal desires of the heart. Why is coveting considered a sin?,
      options: [It reveals a lack of contentment and trust in God's provision., It is just a harmless desire., "It is not a serious sin., It only affects the poor."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reveals a lack of contentment and trust in God's provision.
    })
  },
  {
    id: G8-CRE-TEN-05",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Ten Commandments,
    subtopic: "Deeper Reflection on the Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Jesus summarized the Ten Commandments into two great commandments: love God and love your neighbor. How does this summary fulfill the law?,
      options: [It shows that love is the fulfillment of the law., It disregards the Ten Commandments., It makes the law less important.", "It only emphasizes love for God.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows that love is the fulfillment of the law."
    })
  },

  // --- MADA: THE LIFE OF JESUS (5 Materials) ---
  {
    id: "G8-CRE-LIF-01",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "Jesus' Parables and Their Meanings,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Jesus often taught using parables. What is a parable and why did Jesus use them to teach?,
      options: [A parable is a story with a spiritual meaning, used to reveal truth to those who seek it., A parable is a fictional story with no meaning., "A parable is a moral lesson without a story., A parable is a history lesson."].sort(() => Math.random() - 0.5),
      correctAnswer: "A parable is a story with a spiritual meaning, used to reveal truth to those who seek it.
    })
  },
  {
    id: G8-CRE-LIF-02",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Life of Jesus,
    subtopic: "Jesus' Parables and Their Meanings",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " In the Parable of the Prodigal Son, the father ran to embrace his returning son. What does this parable teach about the nature of God?,
      options: [God is quick to forgive and rejoice over repentant sinners., God is harsh and unforgiving., God is indifferent to sinners.", "God only forgives the perfect.].sort(() => Math.random() - 0.5),
      correctAnswer: God is quick to forgive and rejoice over repentant sinners."
    })
  },
  {
    id: "G8-CRE-LIF-03",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "Jesus' Parables and Their Meanings,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In the Parable of the Good Samaritan, a Samaritan helped a man who was beaten and left for dead. What is the main lesson of this parable?,
      options: [True love means helping anyone in need, regardless of their background., We should only help our friends.", "We should only help our neighbors., We should only help those who can repay us."].sort(() => Math.random() - 0.5),
      correctAnswer: "True love means helping anyone in need, regardless of their background.
    })
  },
  {
    id: G8-CRE-LIF-04",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Life of Jesus,
    subtopic: "Jesus' Parables and Their Meanings",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " In the Parable of the Sower, the seed fell on different types of soil. What does the seed that fell on the path represent?,
      options: [It represents those who hear the word but do not understand it., It represents those who receive the word with joy., It represents those who fall away when trouble comes.", "It represents those who bear fruit.].sort(() => Math.random() - 0.5),
      correctAnswer: It represents those who hear the word but do not understand it."
    })
  },
  {
    id: "G8-CRE-LIF-05",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Life of Jesus",
    subtopic: "Jesus' Parables and Their Meanings,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Parable of the Lost Sheep teaches us about God's love for the lost. What does the shepherd do when he finds the lost sheep?,
      options: [He rejoices and celebrates with his friends., He punishes the sheep., "He ignores the sheep., He sells the sheep."].sort(() => Math.random() - 0.5),
      correctAnswer: "He rejoices and celebrates with his friends.
    })
  },

  // --- MADA: THE SUFFERING OF JESUS (5 Materials) ---
  {
    id: G8-CRE-SUF-01",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Suffering of Jesus,
    subtopic: "The Passion", Crucifixion, and Resurrection of Jesus",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Jesus' passion and crucifixion are the central events of the Christian faith. Why was Jesus willing to suffer and die on the cross?,
      options: [He willingly suffered to pay the penalty for our sins., He was forced to die., He died because He failed.", "He died because He was betrayed.].sort(() => Math.random() - 0.5),
      correctAnswer: He willingly suffered to pay the penalty for our sins."
    })
  },
  {
    id: "G8-CRE-SUF-02",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Suffering of Jesus",
    subtopic: "The Passion, Crucifixion, and Resurrection of Jesus,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Before His crucifixion, Jesus was betrayed by His disciple Judas. How did Jesus respond to Judas' betrayal?,
      options: [He showed love and grace, calling him friend even as he betrayed Him., He cursed him.", "He attacked him., He disowned him."].sort(() => Math.random() - 0.5),
      correctAnswer: "He showed love and grace, calling him friend even as he betrayed Him.
    })
  },
  {
    id: G8-CRE-SUF-03",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Suffering of Jesus,
    subtopic: "The Passion", Crucifixion, and Resurrection of Jesus",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Jesus was crucified on a cross, suffering immense physical and spiritual pain. What was the significance of Jesus' death on the cross?,
      options: [It was the atoning sacrifice for the sins of the world., It was a political execution., It was a tragic accident.", "It was a mistake.].sort(() => Math.random() - 0.5),
      correctAnswer: It was the atoning sacrifice for the sins of the world."
    })
  },
  {
    id: "G8-CRE-SUF-04",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Suffering of Jesus",
    subtopic: "The Passion, Crucifixion, and Resurrection of Jesus,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Three days after His death, Jesus rose from the dead, defeating sin and death. What does the resurrection of Jesus mean for believers?,
      options: ["It guarantees our justification and the hope of eternal life., It means we will never die.", "It means we will be perfect., It means we can do whatever we want."].sort(() => Math.random() - 0.5),
      correctAnswer: "It guarantees our justification and the hope of eternal life.
    })
  },
  {
    id: G8-CRE-SUF-05",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Suffering of Jesus,
    subtopic: "The Passion", Crucifixion, and Resurrection of Jesus",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The resurrection of Jesus is the cornerstone of the Christian faith. How does the resurrection validate Jesus' claims about Himself?,
      options: [It confirms that He is truly the Son of God and that His teachings are true., It confirms that He was a great teacher., It confirms that He was a prophet.", "It confirms that He was just a man.].sort(() => Math.random() - 0.5),
      correctAnswer: It confirms that He is truly the Son of God and that His teachings are true."
    })
  },

  // --- MADA: THE GREAT COMMISSION (5 Materials) ---
  {
    id: "G8-CRE-GRE-01",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Great Commission",
    subtopic: "Sharing the Gospel,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Before Jesus ascended to heaven, He gave His disciples the Great Commission. What is the Great Commission?,
      options: [To go into all the world and make disciples of all nations., To build a temple.", "To become wealthy., To rule the world."].sort(() => Math.random() - 0.5),
      correctAnswer: "To go into all the world and make disciples of all nations.
    })
  },
  {
    id: G8-CRE-GRE-02",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Great Commission,
    subtopic: "Sharing the Gospel",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Great Commission includes both going and making disciples. What does it mean to make disciples of all nations?,
      options: [To teach them to obey all of Jesus' commands and to baptize them., To convince them to follow Jesus by force., To convert them to a specific denomination.", "To make them rich.].sort(() => Math.random() - 0.5),
      correctAnswer: To teach them to obey all of Jesus' commands and to baptize them."
    })
  },
  {
    id: "G8-CRE-GRE-03",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Great Commission",
    subtopic: "Sharing the Gospel,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Great Commission is not just for pastors and missionaries; it is for every believer. How can an ordinary believer participate in the Great Commission?,
      options: [By sharing their faith and living a life that glorifies God., By building churches., "By becoming a missionary., By preaching in the streets."].sort(() => Math.random() - 0.5),
      correctAnswer: "By sharing their faith and living a life that glorifies God.
    })
  },
  {
    id: G8-CRE-GRE-04",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Great Commission,
    subtopic: "Sharing the Gospel",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Great Commission also includes the promise of Jesus' presence. What did Jesus promise His disciples as they carried out the Great Commission?,
      options: [He would be with them always, even to the end of the age., He would leave them alone., He would only be with them if they were successful.", "He would not be with them.].sort(() => Math.random() - 0.5),
      correctAnswer: He would be with them always, even to the end of the age."
    })
  },
  {
    id: "G8-CRE-GRE-05",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Great Commission",
    subtopic: "Sharing the Gospel,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Great Commission is fueled by the power of the Holy Spirit. What does the Holy Spirit provide to believers as they share the gospel?,
      options: [He provides boldness, wisdom, and supernatural power., He provides wealth and success., "He provides social status., He provides perfect speech."].sort(() => Math.random() - 0.5),
      correctAnswer: "He provides boldness, wisdom, and supernatural power.
    })
  },

  // --- MADA: THE HOLY SPIRIT (5 Materials) ---
  {
    id: G8-CRE-SPI-01",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Fruit of the Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The fruit of the Spirit is a manifestation of a life transformed by the Holy Spirit. What are the nine attributes of the fruit of the Spirit?,
      options: [Love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control., Power, wealth, success, fame, wisdom, strength, courage, honor, and glory., Pride, greed, lust, envy, gluttony, wrath, sloth, and arrogance.", "Hope, faith, love, charity, humility, patience, forgiveness, mercy, and grace.].sort(() => Math.random() - 0.5),
      correctAnswer: Love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control."
    })
  },
  {
    id: "G8-CRE-SPI-02",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Fruit of the Spirit,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The fruit of the Spirit grows in a believer's life as they abide in Christ. How does a believer bear the fruit of the Spirit?,
      options: [By living in relationship with Jesus and following the leading of the Holy Spirit., By working hard and being disciplined., "By following religious rituals., By being perfect."].sort(() => Math.random() - 0.5),
      correctAnswer: "By living in relationship with Jesus and following the leading of the Holy Spirit.
    })
  },
  {
    id: G8-CRE-SPI-03",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Fruit of the Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The fruit of the Spirit is not something we produce by our own efforts; it is a result of the Spirit's work in us. Why is the fruit of the Spirit important for Christians?,
      options: [It helps us to live a life pleasing to God and to witness to others., It makes us perfect., It makes us immune to sin.", "It makes us popular.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps us to live a life pleasing to God and to witness to others."
    })
  },
  {
    id: "G8-CRE-SPI-04",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Holy Spirit",
    subtopic: "The Fruit of the Spirit,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Holy Spirit produces the fruit of love, joy, peace, patience, kindness, goodness, faithfulness, gentleness, and self-control. How can a believer cultivate more of the fruit of the Spirit?,
      options: ["By spending time in prayer, studying the Word, and walking in step with the Spirit., By forcing themselves to be nice.", "By following religious rules., By being very disciplined."].sort(() => Math.random() - 0.5),
      correctAnswer: "By spending time in prayer, studying the Word, and walking in step with the Spirit.
    })
  },
  {
    id: G8-CRE-SPI-05",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Holy Spirit,
    subtopic: "The Fruit of the Spirit",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The fruit of the Spirit is the evidence of a life transformed by God. How does the fruit of the Spirit impact a believer's relationship with others?,
      options: [It helps them to be patient, kind, and self-controlled in their interactions., It makes them better than others., It makes them indifferent to others.", "It makes them superior to others.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps them to be patient, kind, and self-controlled in their interactions."
    })
  },

  // --- MADA: THE CHURCH (5 Materials) ---
  {
    id: "G8-CRE-CHU-01",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church as the Body of Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Apostle Paul describes the church as the body of Christ. What does this analogy mean for believers?,
      options: [We are interconnected and each of us has a unique role to play., We are independent and do not need each other., "We are all the same., We are unnecessary."].sort(() => Math.random() - 0.5),
      correctAnswer: "We are interconnected and each of us has a unique role to play.
    })
  },
  {
    id: G8-CRE-CHU-02",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church as the Body of Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Christ is the head of the church, and believers are the members of His body. How does the head of the body guide the rest of the body?,
      options: [Christ guides the church through His Word and the Holy Spirit., Christ controls the church through rules., Christ guides the church through political power.", "Christ guides the church through force.].sort(() => Math.random() - 0.5),
      correctAnswer: Christ guides the church through His Word and the Holy Spirit."
    })
  },
  {
    id: "G8-CRE-CHU-03",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church as the Body of Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Every member of the church is given a gift to serve the body. What is the purpose of spiritual gifts in the church?,
      options: [They are given to build up the body of Christ and serve one another., They are for personal benefit., "They are for making money., They are for gaining power."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are given to build up the body of Christ and serve one another.
    })
  },
  {
    id: G8-CRE-CHU-04",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Church as the Body of Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The church is called to be a light to the world. How can the church fulfill this calling today?,
      options: [By living out the gospel and serving the community., By staying separate from society., By focusing only on internal matters.", "By building large buildings.].sort(() => Math.random() - 0.5),
      correctAnswer: By living out the gospel and serving the community."
    })
  },
  {
    id: "G8-CRE-CHU-05",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Church as the Body of Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The church is unified in Christ despite diversity. What is the ultimate goal of the church as the body of Christ?,
      options: [To glorify God and advance His kingdom., To become wealthy., "To build large buildings., To gain political power."].sort(() => Math.random() - 0.5),
      correctAnswer: "To glorify God and advance His kingdom.
    })
  },

  // --- MADA: CHRISTIAN ETHICS (5 Materials) ---
  {
    id: G8-CRE-ETH-01",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Love", Forgiveness, and Reconciliation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Bible teaches that Christians should forgive others as God has forgiven them. Why is forgiveness important in Christian ethics?,
      options: [It reflects God's character and heals relationships., It is not necessary., It shows weakness.", "It is only for those who deserve it.].sort(() => Math.random() - 0.5),
      correctAnswer: It reflects God's character and heals relationships."
    })
  },
  {
    id: "G8-CRE-ETH-02",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Love, Forgiveness, and Reconciliation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Forgiveness does not mean ignoring wrongdoing; it means releasing the offender from the debt of the offense. What does biblical forgiveness look like?,
      options: [It involves a deliberate choice to release the offender and pray for them., It involves pretending the offense never happened., "It involves ignoring the offense., It involves seeking revenge."].sort(() => Math.random() - 0.5),
      correctAnswer: "It involves a deliberate choice to release the offender and pray for them.
    })
  },
  {
    id: G8-CRE-ETH-03",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Love", Forgiveness, and Reconciliation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Reconciliation involves restoring a broken relationship. How can believers work toward reconciliation with those who have hurt them?,
      options: [By taking the initiative to forgive and seek peace., By waiting for the other person to apologize., By ignoring the problem.", "By cutting off communication.].sort(() => Math.random() - 0.5),
      correctAnswer: By taking the initiative to forgive and seek peace."
    })
  },
  {
    id: "G8-CRE-ETH-04",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Love, Forgiveness, and Reconciliation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Jesus taught that we should love our enemies and pray for those who persecute us. How does this teaching challenge our natural inclinations?,
      options: [It calls us to respond to evil with love and grace., It is impossible to follow., "It is a suggestion., It is only for religious leaders."].sort(() => Math.random() - 0.5),
      correctAnswer: "It calls us to respond to evil with love and grace.
    })
  },
  {
    id: G8-CRE-ETH-05",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Love", Forgiveness, and Reconciliation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Christian ethics are rooted in the love of God. How does love serve as the foundation for all Christian ethical behavior?,
      options: [Love guides our actions, motivations, and relationships., Love is only for personal feelings., Love is not important.", "Love is only for the family.].sort(() => Math.random() - 0.5),
      correctAnswer: Love guides our actions, motivations, and relationships."
    })
  },

  // --- MADA: JUSTICE AND MERCY (5 Materials) ---
  {
    id: "G8-CRE-JUS-01",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "Justice and Mercy",
    subtopic: "Caring for the Poor and Oppressed,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Bible calls believers to care for the poor and oppressed. What are some examples of caring for the poor?,
      options: [Providing food, clothing, and shelter to those in need., Ignoring them., "Blaming them for their poverty., Judging them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Providing food, clothing, and shelter to those in need.
    })
  },
  {
    id: G8-CRE-JUS-02",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "Justice and Mercy,
    subtopic: "Caring for the Poor and Oppressed",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " God is particularly concerned with the rights of the poor and the oppressed. Why does God have a special concern for the marginalized?,
      options: [He is their defender and protector., He only cares about the rich., He does not care about the poor.", "He is indifferent to the marginalized.].sort(() => Math.random() - 0.5),
      correctAnswer: He is their defender and protector."
    })
  },
  {
    id: "G8-CRE-JUS-03",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "Justice and Mercy",
    subtopic: "Caring for the Poor and Oppressed,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Bible commands believers to speak up for those who cannot speak for themselves. What does it mean to advocate for the voiceless?,
      options: [To use your voice and influence to protect the vulnerable., To stay silent., "To ignore the situation., To let others handle it."].sort(() => Math.random() - 0.5),
      correctAnswer: "To use your voice and influence to protect the vulnerable.
    })
  },
  {
    id: G8-CRE-JUS-04",
    grade: "Grade 8,
    subject: Christian Religious Education",
    topic: "Justice and Mercy,
    subtopic: "Caring for the Poor and Oppressed",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " God's justice involves both punishing the wicked and defending the helpless. How should believers reflect God's justice in their own lives?,
      options: [By fighting against injustice and defending the marginalized., By ignoring injustice., By being indifferent to the plight of others.", "By focusing only on personal holiness.].sort(() => Math.random() - 0.5),
      correctAnswer: By fighting against injustice and defending the marginalized."
    })
  },
  {
    id: "G8-CRE-JUS-05",
    grade: "Grade 8",
    subject: "Christian Religious Education",
    topic: "Justice and Mercy",
    subtopic: "Caring for the Poor and Oppressed,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Bible promises that those who care for the poor will be blessed. How does caring for the poor bring blessings to the giver?,
      options: [It brings spiritual, emotional, and sometimes material blessings., It brings only material blessings., "It brings only spiritual blessings., It brings nothing in return."].sort(() => Math.random() - 0.5),
      correctAnswer: "It brings spiritual, emotional, and sometimes material blessings.
    })
  }
  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD SENIOR SECONDARY CRE SYLLABUS)
  // =========================================================================

  // --- MADA: THE DOCTRINE OF GOD (5 Materials) ---
  {
    id: G11-CRE-GOD-01",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Doctrine of God,
    subtopic: "The Nature and Attributes of God (Holiness", Love, Justice, Mercy)",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The doctrine of God is foundational to the Christian faith. God reveals Himself as holy, loving, just, and merciful. How do these attributes work together in the nature of God?,
      options: [They are perfectly harmonized in God's character, never in conflict., They sometimes contradict each other., Only holiness and justice are important.", "Love and mercy override justice and holiness.].sort(() => Math.random() - 0.5),
      correctAnswer: They are perfectly harmonized in God's character, never in conflict."
    })
  },
  {
    id: "G11-CRE-GOD-02",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Doctrine of God",
    subtopic: "The Nature and Attributes of God (Holiness, Love, Justice, Mercy),
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "God's holiness sets Him apart from all creation and calls His people to be holy. What does it mean for believers to be holy as God is holy?,
      options: [It means living a life set apart for God and reflecting His character., It means being perfect., "It means following religious rules., It means being separate from society."].sort(() => Math.random() - 0.5),
      correctAnswer: "It means living a life set apart for God and reflecting His character.
    })
  },
  {
    id: G11-CRE-GOD-03",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Doctrine of God,
    subtopic: "The Nature and Attributes of God (Holiness", Love, Justice, Mercy)",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " God's love is unconditional and sacrificial, demonstrated most clearly at the cross. How does God's love impact our understanding of His justice?,
      options: [God's justice is satisfied through the cross, while His love provides forgiveness., Justice is not important., Love overrides justice.", "Justice and love are unrelated.].sort(() => Math.random() - 0.5),
      correctAnswer: God's justice is satisfied through the cross, while His love provides forgiveness."
    })
  },
  {
    id: "G11-CRE-GOD-04",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Doctrine of God",
    subtopic: "The Nature and Attributes of God (Holiness, Love, Justice, Mercy),
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "God's mercy is His compassionate response to human suffering and sin. How does God's mercy give hope to believers who struggle with sin?,
      options: [It assures us that God is patient and willing to forgive when we repent., It means we can sin without consequence., "It means God ignores sin., It means we never have to change."].sort(() => Math.random() - 0.5),
      correctAnswer: "It assures us that God is patient and willing to forgive when we repent.
    })
  },
  {
    id: G11-CRE-GOD-05",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Doctrine of God,
    subtopic: "The Nature and Attributes of God (Holiness", Love, Justice, Mercy)",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Bible reveals that God is both transcendent (beyond the world) and immanent (present in the world). How does God's transcendence and immanence impact our worship and relationship with Him?,
      options: [God is worthy of our worship because He is transcendent, and we can know Him because He is immanent., Transcendence and immanence are contradictions., Only transcendence matters.", "Only immanence matters.].sort(() => Math.random() - 0.5),
      correctAnswer: God is worthy of our worship because He is transcendent, and we can know Him because He is immanent."
    })
  },

  // --- MADA: CHRISTOLOGY (5 Materials) ---
  {
    id: "G11-CRE-CHR-01",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christology",
    subtopic: "The Person and Work of Jesus Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Christology is the study of the person and work of Jesus Christ. Why is Christology central to the Christian faith?,
      options: [It defines who Jesus is and what He accomplished for our salvation., It is just a theological debate., "It is not important., It is only for church leaders."].sort(() => Math.random() - 0.5),
      correctAnswer: "It defines who Jesus is and what He accomplished for our salvation.
    })
  },
  {
    id: G11-CRE-CHR-02",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christology,
    subtopic: "The Person and Work of Jesus Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The early church wrestled with the nature of Christ, affirming that He is fully God and fully human. Why is the dual nature of Christ essential for salvation?,
      options: [His divine nature makes His sacrifice perfect, and His human nature allows Him to represent humanity., Only His divine nature is important., Only His human nature is important.", "Both are optional.].sort(() => Math.random() - 0.5),
      correctAnswer: His divine nature makes His sacrifice perfect, and His human nature allows Him to represent humanity."
    })
  },
  {
    id: "G11-CRE-CHR-03",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christology",
    subtopic: "The Person and Work of Jesus Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The work of Christ includes His incarnation, life, death, resurrection, ascension, and session at the right hand of the Father. What does Christ's session at the right hand of the Father signify?,
      options: ["It signifies His authority, His ongoing intercession, and His reign over all creation., It signifies His retirement.", "It signifies His absence., It signifies His weakness."].sort(() => Math.random() - 0.5),
      correctAnswer: "It signifies His authority, His ongoing intercession, and His reign over all creation.
    })
  },
  {
    id: G11-CRE-CHR-04",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christology,
    subtopic: "The Person and Work of Jesus Christ",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Christ's resurrection is the foundation of the Christian faith. How does the resurrection provide hope for believers?,
      options: [It guarantees our justification and the promise of our own resurrection., It just proves He was a good teacher., It has no relevance for us.", "It is just a historical event.].sort(() => Math.random() - 0.5),
      correctAnswer: It guarantees our justification and the promise of our own resurrection."
    })
  },
  {
    id: "G11-CRE-CHR-05",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christology",
    subtopic: "The Person and Work of Jesus Christ,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Christ's ascension marked the completion of His earthly ministry and the beginning of His heavenly reign. What did Christ do after ascending to heaven?,
      options: [He sat down at the right hand of the Father and poured out the Holy Spirit., He retired., "He went to rest., He abandoned the church."].sort(() => Math.random() - 0.5),
      correctAnswer: "He sat down at the right hand of the Father and poured out the Holy Spirit.
    })
  },

  // --- MADA: PNEUMATOLOGY (5 Materials) ---
  {
    id: G11-CRE-PNE-01",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Pneumatology,
    subtopic: "The Holy Spirit in the Old and New Testaments",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pneumatology is the study of the Holy Spirit. The Holy Spirit is active in both the Old and New Testaments. How was the Holy Spirit involved in the Old Testament?,
      options: [He empowered leaders, prophets, and craftsmen for specific tasks., He was entirely inactive., He was only active in the New Testament.", "He only appeared in prophetic visions.].sort(() => Math.random() - 0.5),
      correctAnswer: He empowered leaders, prophets, and craftsmen for specific tasks."
    })
  },
  {
    id: "G11-CRE-PNE-02",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Pneumatology",
    subtopic: "The Holy Spirit in the Old and New Testaments,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The Holy Spirit's work in the New Testament is more comprehensive. He indwells, empowers, and guides all believers. What was the significant event at Pentecost that marked the Holy Spirit's new role?,
      options: ["The Holy Spirit descended upon the disciples, empowering them for witness., The Holy Spirit left the church.", "The Holy Spirit became visible., The Holy Spirit was given only to the apostles."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Holy Spirit descended upon the disciples, empowering them for witness.
    })
  },
  {
    id: G11-CRE-PNE-03",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Pneumatology,
    subtopic: "The Holy Spirit in the Old and New Testaments",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " In the Old Testament, the Holy Spirit came upon individuals for specific tasks. In the New Testament, the Holy Spirit indwells every believer. What is the significance of the indwelling of the Holy Spirit?,
      options: [It marks believers as God's temple and empowers them to live holy lives., It is a symbolic gesture., It has no practical significance.", "It is only for religious leaders.].sort(() => Math.random() - 0.5),
      correctAnswer: It marks believers as God's temple and empowers them to live holy lives."
    })
  },
  {
    id: "G11-CRE-PNE-04",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Pneumatology",
    subtopic: "The Holy Spirit in the Old and New Testaments,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The Holy Spirit is the seal and guarantee of our salvation. What is the significance of the sealing of the Holy Spirit?,
      options: [It assures believers of their inheritance and security in Christ., It is a temporary mark., "It is not important., It is only for the apostles."].sort(() => Math.random() - 0.5),
      correctAnswer: "It assures believers of their inheritance and security in Christ.
    })
  },
  {
    id: G11-CRE-PNE-05",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Pneumatology,
    subtopic: "The Holy Spirit in the Old and New Testaments",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Holy Spirit also empowers believers for service and witness. How does the Holy Spirit empower believers today?,
      options: [He gives boldness, wisdom, and spiritual gifts for the building up of the church., He gives wealth and success., He gives social status.", "He gives perfect speech.].sort(() => Math.random() - 0.5),
      correctAnswer: He gives boldness, wisdom, and spiritual gifts for the building up of the church."
    })
  },

  // --- MADA: THE CHURCH (5 Materials) ---
  {
    id: "G11-CRE-CHU-01",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Nature and Mission of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The church is a divine institution established by Jesus Christ. The New Testament uses several metaphors for the church. What does it mean that the church is the bride of Christ?,
      options: [It signifies the intimate, exclusive, and loving relationship between Christ and His church., It is a term of endearment., "It means the church is married to Christ., It means the church is like a spouse."].sort(() => Math.random() - 0.5),
      correctAnswer: "It signifies the intimate, exclusive, and loving relationship between Christ and His church.
    })
  },
  {
    id: G11-CRE-CHU-02",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Nature and Mission of the Church",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The church is also described as the body of Christ, with Christ as the head. How does this metaphor shape our understanding of the church's unity and diversity?,
      options: [We are united in Christ but have diverse gifts and roles., We are all identical., We have no unity.", "We should not have diversity.].sort(() => Math.random() - 0.5),
      correctAnswer: We are united in Christ but have diverse gifts and roles."
    })
  },
  {
    id: "G11-CRE-CHU-03",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Nature and Mission of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The mission of the church is to make disciples of all nations, baptize them, and teach them to obey Christ's commands. What is the role of the church in fulfilling the Great Commission today?,
      options: ["The church is to go, proclaim the gospel, and make disciples., The church is only to meet together.", "The church is to build buildings., The church is to collect money."].sort(() => Math.random() - 0.5),
      correctAnswer: "The church is to go, proclaim the gospel, and make disciples.
    })
  },
  {
    id: G11-CRE-CHU-04",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Nature and Mission of the Church",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The church is also a community of worship, fellowship, and service. How does the church demonstrate its mission through worship and fellowship?,
      options: [By gathering for worship, prayer, and mutual edification, and by serving each other., By focusing only on worship., By focusing only on fellowship.", "By focusing only on service.].sort(() => Math.random() - 0.5),
      correctAnswer: By gathering for worship, prayer, and mutual edification, and by serving each other."
    })
  },
  {
    id: "G11-CRE-CHU-05",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Nature and Mission of the Church,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The church faces many challenges in the modern world: secularism, individualism, and skepticism. How can the church remain faithful to its mission despite these challenges?,
      options: ["By staying rooted in Scripture, prayer, and the power of the Holy Spirit., By compromising with the world.", "By adapting its message to fit culture., By isolating itself."].sort(() => Math.random() - 0.5),
      correctAnswer: "By staying rooted in Scripture, prayer, and the power of the Holy Spirit.
    })
  },

  // --- MADA: SALVATION (5 Materials) ---
  {
    id: G11-CRE-SAL-01",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Salvation,
    subtopic: "Justification", Sanctification, and Glorification",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Salvation is a comprehensive work of God that includes justification, sanctification, and glorification. What is justification, and what does it accomplish for the believer?,
      options: [It is the legal declaration that the believer is righteous before God through faith in Christ., It is the process of becoming holy., It is the final stage of salvation.", "It is a feeling of being saved.].sort(() => Math.random() - 0.5),
      correctAnswer: It is the legal declaration that the believer is righteous before God through faith in Christ."
    })
  },
  {
    id: "G11-CRE-SAL-02",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Salvation",
    subtopic: "Justification, Sanctification, and Glorification,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Sanctification is the ongoing process by which the Holy Spirit transforms the believer into the image of Christ. How does sanctification take place in the life of a believer?,
      options: [Through the work of the Holy Spirit, the Word of God, and obedience to God., Through good works alone., "Through church attendance alone., Through self-discipline alone."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through the work of the Holy Spirit, the Word of God, and obedience to God.
    })
  },
  {
    id: G11-CRE-SAL-03",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Salvation,
    subtopic: "Justification", Sanctification, and Glorification",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Glorification is the final stage of salvation, when believers will be resurrected and transformed into the likeness of Christ. What will glorification entail for believers?,
      options: [They will receive glorified bodies and be free from sin and suffering forever., They will become perfect., They will become angels.", "They will cease to exist.].sort(() => Math.random() - 0.5),
      correctAnswer: They will receive glorified bodies and be free from sin and suffering forever."
    })
  },
  {
    id: "G11-CRE-SAL-04",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Salvation",
    subtopic: "Justification, Sanctification, and Glorification,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Salvation is by grace through faith, not by works. What is the relationship between faith and salvation?,
      options: [Faith is the instrument by which we receive God's grace and the benefits of salvation., Faith is not necessary.", "Salvation is by works., Salvation is by both faith and works."].sort(() => Math.random() - 0.5),
      correctAnswer: "Faith is the instrument by which we receive God's grace and the benefits of salvation.
    })
  },
  {
    id: G11-CRE-SAL-05",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Salvation,
    subtopic: "Justification", Sanctification, and Glorification",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The doctrine of salvation brings assurance, security, and hope to believers. How should the assurance of salvation impact the daily lives of believers?,
      options: [It should produce gratitude, confidence, and a desire to live for God., It should make them careless., It should make them indifferent.", "It should make them fearful.].sort(() => Math.random() - 0.5),
      correctAnswer: It should produce gratitude, confidence, and a desire to live for God."
    })
  },

  // --- MADA: CHRISTIAN APOLOGETICS (5 Materials) ---
  {
    id: "G11-CRE-APO-01",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Apologetics",
    subtopic: "Defending the Faith, Reasons for Belief,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Christian apologetics is the discipline of defending the Christian faith. Why is apologetics important for believers today?,
      options: [It equips believers to give reasons for their hope and to respond to objections., It is not important., "It is only for pastors., It is only for intellectuals."].sort(() => Math.random() - 0.5),
      correctAnswer: "It equips believers to give reasons for their hope and to respond to objections.
    })
  },
  {
    id: G11-CRE-APO-02",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christian Apologetics,
    subtopic: "Defending the Faith", Reasons for Belief",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The Apostle Peter commands believers to always be prepared to give a defense for the hope that is in them. How can believers prepare themselves for apologetics?,
      options: [By studying Scripture, understanding worldviews, and praying for wisdom., By memorizing Bible verses., By taking a class.", "By avoiding difficult questions.].sort(() => Math.random() - 0.5),
      correctAnswer: By studying Scripture, understanding worldviews, and praying for wisdom."
    })
  },
  {
    id: "G11-CRE-APO-03",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Apologetics",
    subtopic: "Defending the Faith, Reasons for Belief,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "There are several classical arguments for the existence of God, including the cosmological, teleological, and moral arguments. What does the teleological argument (design argument) seek to demonstrate?,
      options: ["The complexity and order of the universe suggest an intelligent designer., The universe is a product of chance.", "The universe is eternal., The universe is self-existent."].sort(() => Math.random() - 0.5),
      correctAnswer: "The complexity and order of the universe suggest an intelligent designer.
    })
  },
  {
    id: G11-CRE-APO-04",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christian Apologetics,
    subtopic: "Defending the Faith", Reasons for Belief",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Apologetics is also about addressing objections to Christianity, such as the problem of evil and suffering. How can Christians respond to the problem of evil?,
      options: [By acknowledging the reality of evil while affirming God's goodness and sovereignty, and pointing to the cross., By denying the existence of evil., By blaming God for all evil.", "By saying evil is an illusion.].sort(() => Math.random() - 0.5),
      correctAnswer: By acknowledging the reality of evil while affirming God's goodness and sovereignty, and pointing to the cross."
    })
  },
  {
    id: "G11-CRE-APO-05",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Apologetics",
    subtopic: "Defending the Faith, Reasons for Belief,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Apologetics is not just intellectual; it also involves a life that reflects the gospel. How does a believer's life serve as an apologetic for the faith?,
      options: [A transformed life that reflects the love and grace of God is a powerful witness to the truth of the gospel., Only words matter., "Only actions matter., Neither words nor actions matter."].sort(() => Math.random() - 0.5),
      correctAnswer: "A transformed life that reflects the love and grace of God is a powerful witness to the truth of the gospel.
    })
  },

  // --- MADA: THE PROBLEM OF EVIL (5 Materials) ---
  {
    id: G11-CRE-EVI-01",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Problem of Evil,
    subtopic: "Theodicy and Suffering in the Christian Worldview",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The problem of evil is one of the most significant objections to belief in a good and powerful God. How does the Christian worldview explain the existence of evil and suffering?,
      options: [Evil is a result of human free will and the fall, and God uses it for redemptive purposes., Evil does not exist., God is the author of evil.", "Evil is an illusion.].sort(() => Math.random() - 0.5),
      correctAnswer: Evil is a result of human free will and the fall, and God uses it for redemptive purposes."
    })
  },
  {
    id: "G11-CRE-EVI-02",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Problem of Evil",
    subtopic: "Theodicy and Suffering in the Christian Worldview,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "God has given humanity free will, and evil is a consequence of misusing that freedom. Why did God allow free will if it would result in evil and suffering?,
      options: [Free will is necessary for genuine love and moral responsibility, despite the risk of evil., Free will was a mistake.", "God does not care about free will., Free will is an illusion."].sort(() => Math.random() - 0.5),
      correctAnswer: "Free will is necessary for genuine love and moral responsibility, despite the risk of evil.
    })
  },
  {
    id: G11-CRE-EVI-03",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Problem of Evil,
    subtopic: "Theodicy and Suffering in the Christian Worldview",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Bible reveals that God can bring good out of evil, as seen in the story of Joseph. What does Joseph's story teach us about God's sovereignty in the midst of suffering?,
      options: [God can use evil and suffering to accomplish His good purposes., God is not sovereign., God is indifferent to suffering.", "Suffering is always a punishment from God.].sort(() => Math.random() - 0.5),
      correctAnswer: God can use evil and suffering to accomplish His good purposes."
    })
  },
  {
    id: "G11-CRE-EVI-04",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "The Problem of Evil",
    subtopic: "Theodicy and Suffering in the Christian Worldview,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The cross of Christ is the ultimate example of God using evil for good. How does the cross provide the key to understanding the problem of evil?,
      options: [It shows that God took the worst evil (the murder of His Son) and used it for the greatest good (salvation)., It shows that God is weak., "It shows that God is cruel., It shows that evil is meaningless."].sort(() => Math.random() - 0.5),
      correctAnswer: "It shows that God took the worst evil (the murder of His Son) and used it for the greatest good (salvation).
    })
  },
  {
    id: G11-CRE-EVI-05",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "The Problem of Evil,
    subtopic: "Theodicy and Suffering in the Christian Worldview",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Suffering is not meaningless in the Christian worldview. How should believers respond to suffering in their own lives?,
      options: [By trusting God, growing in faith, and looking forward to the restoration that awaits., By giving up., By blaming God.", "By becoming bitter.].sort(() => Math.random() - 0.5),
      correctAnswer: By trusting God, growing in faith, and looking forward to the restoration that awaits."
    })
  },

  // --- MADA: CHRISTIAN ETHICS (5 Materials) ---
  {
    id: "G11-CRE-ETH-01",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Applied Christian Ethics in Contemporary Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Christian ethics are grounded in the character of God and the teachings of Jesus. How can Christians apply biblical ethics to contemporary social issues such as justice and inequality?,
      options: [By advocating for justice, caring for the marginalized, and promoting human dignity., By ignoring social issues., "By focusing only on personal piety., By separating faith from public life."].sort(() => Math.random() - 0.5),
      correctAnswer: "By advocating for justice, caring for the marginalized, and promoting human dignity.
    })
  },
  {
    id: G11-CRE-ETH-02",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Applied Christian Ethics in Contemporary Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Bioethics is an area where Christian ethics can provide valuable guidance, particularly on issues like abortion, euthanasia, and medical ethics. What is the biblical basis for the sanctity of human life?,
      options: [Human beings are made in the image of God and have inherent dignity., Human beings are just animals., Human beings are products of chance.", "Human beings have no intrinsic value.].sort(() => Math.random() - 0.5),
      correctAnswer: Human beings are made in the image of God and have inherent dignity."
    })
  },
  {
    id: "G11-CRE-ETH-03",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Applied Christian Ethics in Contemporary Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stewardship of the environment is a key aspect of Christian ethics. What is the biblical mandate for caring for the environment?,
      options: [God called humanity to rule over the earth and care for it as stewards., The environment is not important., "We can exploit the earth for our own gain., God does not care about the environment."].sort(() => Math.random() - 0.5),
      correctAnswer: "God called humanity to rule over the earth and care for it as stewards.
    })
  },
  {
    id: G11-CRE-ETH-04",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Applied Christian Ethics in Contemporary Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Christian ethics are also concerned with marriage, family, and sexual purity. What is the biblical model for marriage and family life?,
      options: [A covenant relationship between a man and a woman, reflecting the love of Christ and the church., Marriage is just a social contract., Marriage is not important.", "Sexual purity is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: A covenant relationship between a man and a woman, reflecting the love of Christ and the church."
    })
  },
  {
    id: "G11-CRE-ETH-05",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Applied Christian Ethics in Contemporary Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Christian ethics call believers to be agents of peace and reconciliation in a divided world. How can Christians promote peace and reconciliation in their communities?,
      options: [By practicing forgiveness, seeking justice, and promoting dialogue., By avoiding conflict., "By taking sides., By ignoring divisions."].sort(() => Math.random() - 0.5),
      correctAnswer: "By practicing forgiveness, seeking justice, and promoting dialogue.
    })
  },

  // --- MADA: ESCHATOLOGY (5 Materials) ---
  {
    id: G11-CRE-ESC-01",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Eschatology,
    subtopic: "The Resurrection", the Final Judgment, and the New Creation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Eschatology is the study of last things. What does the Bible teach about the resurrection of the dead?,
      options: [All people will be resurrected: believers to eternal life and unbelievers to judgment., Only believers will be resurrected., There is no resurrection.", "The resurrection is symbolic.].sort(() => Math.random() - 0.5),
      correctAnswer: All people will be resurrected: believers to eternal life and unbelievers to judgment."
    })
  },
  {
    id: "G11-CRE-ESC-02",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Eschatology",
    subtopic: "The Resurrection, the Final Judgment, and the New Creation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The final judgment is a day of reckoning when God will judge all people according to their deeds. How should the reality of judgment motivate believers to live faithfully?,
      options: [It should motivate them to live holy lives and to share the gospel with others., It should make them afraid., "It should make them despair., It should make them indifferent."].sort(() => Math.random() - 0.5),
      correctAnswer: "It should motivate them to live holy lives and to share the gospel with others.
    })
  },
  {
    id: G11-CRE-ESC-03",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Eschatology,
    subtopic: "The Resurrection", the Final Judgment, and the New Creation",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The new creation is the final state of the redeemed, where God will dwell with His people forever. What will the new creation be like according to Scripture?,
      options: [It will be a place of perfect peace, righteousness, and joy in God's presence., It will be a place of boredom., It will be a place of sleep.", "It will be a place of rest.].sort(() => Math.random() - 0.5),
      correctAnswer: It will be a place of perfect peace, righteousness, and joy in God's presence."
    })
  },
  {
    id: "G11-CRE-ESC-04",
    grade: "Grade 11",
    subject: "Christian Religious Education",
    topic: "Eschatology",
    subtopic: "The Resurrection, the Final Judgment, and the New Creation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The resurrection of Jesus is the guarantee of our own resurrection. How does the resurrection provide assurance and hope to believers?,
      options: [It guarantees that we will also be raised to eternal life, just as Christ was., It just proves He was a good teacher., "It has no relevance for us., It is just a historical event."].sort(() => Math.random() - 0.5),
      correctAnswer: "It guarantees that we will also be raised to eternal life, just as Christ was.
    })
  },
  {
    id: G11-CRE-ESC-05",
    grade: "Grade 11,
    subject: Christian Religious Education",
    topic: "Eschatology,
    subtopic: "The Resurrection", the Final Judgment, and the New Creation",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The hope of the new creation gives believers a transcendent perspective on their present suffering. How does the hope of the new creation transform the way believers live?,
      options: [It gives them strength to endure suffering and invest in what has eternal value., It makes them focus only on the present., It makes them escape reality.", "It makes them indifferent to the present.].sort(() => Math.random() - 0.5),
      correctAnswer: It gives them strength to endure suffering and invest in what has eternal value."
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD SENIOR SECONDARY CRE SYLLABUS)
  // =========================================================================

  // --- MADA: SYSTEMATIC THEOLOGY (5 Materials) ---
  {
    id: "G12-CRE-SYS-01",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Systematic Theology",
    subtopic: "The Study of God, Creation, and Redemption,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Systematic theology is the discipline of organizing the teachings of the Bible into coherent categories. What are the major categories of systematic theology?,
      options: [Theology proper, Christology, Pneumatology, Soteriology, Ecclesiology, and Eschatology., Only Christology., "Only Soteriology., Only Eschatology."].sort(() => Math.random() - 0.5),
      correctAnswer: "Theology proper, Christology, Pneumatology, Soteriology, Ecclesiology, and Eschatology.
    })
  },
  {
    id: G12-CRE-SYS-02",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Systematic Theology,
    subtopic: "The Study of God", Creation, and Redemption",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Theology proper is the study of God. It explores God's nature, attributes, and works. How does theology proper help believers understand God's character?,
      options: [It provides a systematic understanding of who God is and how He relates to the world., It is not necessary., It is only for scholars.", "It is only for pastors.].sort(() => Math.random() - 0.5),
      correctAnswer: It provides a systematic understanding of who God is and how He relates to the world."
    })
  },
  {
    id: "G12-CRE-SYS-03",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Systematic Theology",
    subtopic: "The Study of God, Creation, and Redemption,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The doctrine of creation teaches that God created the universe out of nothing. How does the doctrine of creation impact our understanding of the value of the physical world?,
      options: [It affirms that the physical world is good and ordered by a wise Creator., The physical world is evil., "The physical world is an illusion., The physical world is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It affirms that the physical world is good and ordered by a wise Creator.
    })
  },
  {
    id: G12-CRE-SYS-04",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Systematic Theology,
    subtopic: "The Study of God", Creation, and Redemption",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The doctrine of redemption is the central theme of the Bible, encompassing God's plan to save humanity through Christ. How does redemption affect the relationship between God and humanity?,
      options: [It reconciles humanity to God and restores the broken relationship., It leaves humanity in sin., It only affects the future.", "It does not change the present.].sort(() => Math.random() - 0.5),
      correctAnswer: It reconciles humanity to God and restores the broken relationship."
    })
  },
  {
    id: "G12-CRE-SYS-05",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Systematic Theology",
    subtopic: "The Study of God, Creation, and Redemption,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Systematic theology helps believers integrate their faith and apply it to all areas of life. How does systematic theology help believers in their daily walk with God?,
      options: [It gives them a solid foundation for faith and equips them to live a life consistent with the gospel., It makes faith complicated., "It is only for academics., It is not helpful in daily life."].sort(() => Math.random() - 0.5),
      correctAnswer: "It gives them a solid foundation for faith and equips them to live a life consistent with the gospel.
    })
  },

  // --- MADA: THE COVENANTS OF GOD (5 Materials) ---
  {
    id: G12-CRE-COV-01",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Covenants of God,
    subtopic: "The Old and New Covenants",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Bible is structured around a series of covenants between God and His people. What is a covenant in the biblical sense?,
      options: [A binding agreement between God and humanity, initiated by God and sealed by a sign., A simple promise., A human contract.", "A legal agreement.].sort(() => Math.random() - 0.5),
      correctAnswer: A binding agreement between God and humanity, initiated by God and sealed by a sign."
    })
  },
  {
    id: "G12-CRE-COV-02",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Covenants of God",
    subtopic: "The Old and New Covenants,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Old Covenant was established with Israel through Moses and the Law. The New Covenant was established through Jesus Christ. What is the main difference between the Old and New Covenants?,
      options: [The Old Covenant was based on the Law, while the New Covenant is based on grace., They are the same., "The New Covenant is more demanding., The Old Covenant is better."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Old Covenant was based on the Law, while the New Covenant is based on grace.
    })
  },
  {
    id: G12-CRE-COV-03",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Covenants of God,
    subtopic: "The Old and New Covenants",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The New Covenant was established by the blood of Christ and is available to all people, both Jews and Gentiles. What is the role of faith in the New Covenant?,
      options: [Faith is the means by which we receive the benefits of the New Covenant., Faith is not necessary., Faith is only for the Jews.", "Faith is only for the Gentiles.].sort(() => Math.random() - 0.5),
      correctAnswer: Faith is the means by which we receive the benefits of the New Covenant."
    })
  },
  {
    id: "G12-CRE-COV-04",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Covenants of God",
    subtopic: "The Old and New Covenants,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Old Covenant pointed forward to the New Covenant, foreshadowing Christ. How does the New Covenant fulfill the Old Covenant?,
      options: [Christ fulfills the Law and the Prophets, becoming the perfect sacrifice and mediator., The New Covenant replaces the Old.", "The New Covenant ignores the Old., The New Covenant is the same as the Old."].sort(() => Math.random() - 0.5),
      correctAnswer: "Christ fulfills the Law and the Prophets, becoming the perfect sacrifice and mediator.
    })
  },
  {
    id: G12-CRE-COV-05",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Covenants of God,
    subtopic: "The Old and New Covenants",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The New Covenant provides believers with a new heart and the indwelling of the Holy Spirit. How does the New Covenant transform the believer's relationship with God?,
      options: [It makes God's law internal, written on the heart, and gives believers access to God through Christ., It does not change anything., It only affects the future.", "It only applies to the church.].sort(() => Math.random() - 0.5),
      correctAnswer: It makes God's law internal, written on the heart, and gives believers access to God through Christ."
    })
  },

  // --- MADA: THE LIFE OF CHRIST (5 Materials) ---
  {
    id: "G12-CRE-LIF-01",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Life of Christ",
    subtopic: "A Comprehensive Overview of Jesus' Life and Teachings,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Jesus' life, from His birth to His ascension, is a model of obedience, humility, and love. What is the significance of the incarnation for understanding Jesus' life?,
      options: ["The incarnation demonstrates God's humility and His identification with humanity., The incarnation is not important.", "The incarnation is a myth., The incarnation is a theological concept with no practical significance."].sort(() => Math.random() - 0.5),
      correctAnswer: "The incarnation demonstrates God's humility and His identification with humanity.
    })
  },
  {
    id: G12-CRE-LIF-02",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Life of Christ,
    subtopic: "A Comprehensive Overview of Jesus' Life and Teachings",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Jesus' teachings, especially His parables and the Sermon on the Mount, reveal the nature of the Kingdom of God. How do Jesus' teachings challenge the values of the world?,
      options: [They call for humility, self-denial, and love for enemies, which contradict worldly values., They affirm worldly values., They are the same as worldly values.", "They do not challenge the world.].sort(() => Math.random() - 0.5),
      correctAnswer: They call for humility, self-denial, and love for enemies, which contradict worldly values."
    })
  },
  {
    id: "G12-CRE-LIF-03",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Life of Christ",
    subtopic: "A Comprehensive Overview of Jesus' Life and Teachings,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Jesus' death on the cross is the central event of His life. What does the crucifixion reveal about the nature of sin and the love of God?,
      options: [It reveals the severity of sin and the extent of God's love in providing a sacrifice., It reveals that sin is not important., "It reveals that God is harsh., It reveals that God does not love."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reveals the severity of sin and the extent of God's love in providing a sacrifice.
    })
  },
  {
    id: G12-CRE-LIF-04",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Life of Christ,
    subtopic: "A Comprehensive Overview of Jesus' Life and Teachings",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Jesus' resurrection is the vindication of His divinity and the foundation of Christian hope. How does the resurrection verify Jesus' identity and teaching?,
      options: [It confirms that He is the Son of God and that His teachings are true., It just proves He was a good teacher., It has no relevance for us.", "It is just a historical event.].sort(() => Math.random() - 0.5),
      correctAnswer: It confirms that He is the Son of God and that His teachings are true."
    })
  },
  {
    id: "G12-CRE-LIF-05",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Life of Christ",
    subtopic: "A Comprehensive Overview of Jesus' Life and Teachings,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Jesus' ascension marks the end of His earthly life and the beginning of His heavenly reign. What does Jesus' ascension signify for the church today?,
      options: [It signifies His exaltation and His ongoing intercession for believers., It signifies His retirement., "It signifies His absence., It signifies His weakness."].sort(() => Math.random() - 0.5),
      correctAnswer: "It signifies His exaltation and His ongoing intercession for believers.
    })
  },

  // --- MADA: THE WORK OF THE HOLY SPIRIT (5 Materials) ---
  {
    id: G12-CRE-SPI-01",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Work of the Holy Spirit,
    subtopic: "Regeneration", Sanctification, and Sealing",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Regeneration is the Holy Spirit's work of bringing a person from spiritual death to spiritual life. Why is regeneration necessary for salvation?,
      options: [It enables the sinner to repent and believe the gospel., It is optional., It is not necessary.", "It is only for the spiritually advanced.].sort(() => Math.random() - 0.5),
      correctAnswer: It enables the sinner to repent and believe the gospel."
    })
  },
  {
    id: "G12-CRE-SPI-02",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Work of the Holy Spirit",
    subtopic: "Regeneration, Sanctification, and Sealing,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Sanctification is the ongoing work of the Holy Spirit to make believers more like Christ. How does the Holy Spirit sanctify believers?,
      options: [By using the Word of God, prayer, and community to transform them., By making them perfect immediately., "By doing everything for them., By ignoring their efforts."].sort(() => Math.random() - 0.5),
      correctAnswer: "By using the Word of God, prayer, and community to transform them.
    })
  },
  {
    id: G12-CRE-SPI-03",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Work of the Holy Spirit,
    subtopic: "Regeneration", Sanctification, and Sealing",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Holy Spirit seals believers, marking them as God's possession and guaranteeing their inheritance. What does the sealing of the Holy Spirit mean for believers?,
      options: [It is God's mark of ownership and a guarantee of future redemption., It is a temporary mark., It is not important.", "It is only for the apostles.].sort(() => Math.random() - 0.5),
      correctAnswer: It is God's mark of ownership and a guarantee of future redemption."
    })
  },
  {
    id: "G12-CRE-SPI-04",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Work of the Holy Spirit",
    subtopic: "Regeneration, Sanctification, and Sealing,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Holy Spirit also empowers believers for witness and service. How does the Holy Spirit empower believers to be effective witnesses for Christ?,
      options: [He gives them boldness, wisdom, and supernatural power to proclaim the gospel., He gives them wealth and success., "He gives them social status., He gives them perfect speech."].sort(() => Math.random() - 0.5),
      correctAnswer: "He gives them boldness, wisdom, and supernatural power to proclaim the gospel.
    })
  },
  {
    id: G12-CRE-SPI-05",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Work of the Holy Spirit,
    subtopic: "Regeneration", Sanctification, and Sealing",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The Holy Spirit also produces the fruit of the Spirit in the lives of believers. How does the fruit of the Spirit serve as evidence of the Holy Spirit's work?,
      options: [It demonstrates the transformation of the believer's character and witness., It makes them perfect., It makes them immune to sin.", "It makes them popular.].sort(() => Math.random() - 0.5),
      correctAnswer: It demonstrates the transformation of the believer's character and witness."
    })
  },

  // --- MADA: THE CHURCH (5 Materials) ---
  {
    id: "G12-CRE-CHU-01",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Role of the Church in the World Today,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The church is not just a gathering of believers; it is the body of Christ on earth. What is the church's role in the world today?,
      options: [To proclaim the gospel, serve the community, and be a light in a dark world., To build large buildings., "To collect money., To gain political power."].sort(() => Math.random() - 0.5),
      correctAnswer: "To proclaim the gospel, serve the community, and be a light in a dark world.
    })
  },
  {
    id: G12-CRE-CHU-02",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Role of the Church in the World Today",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The church is called to be a prophetic voice in society, speaking truth to power and advocating for the marginalized. How can the church fulfill this prophetic role?,
      options: [By speaking out against injustice and advocating for the poor and oppressed., By staying silent., By avoiding controversy.", "By focusing only on internal matters.].sort(() => Math.random() - 0.5),
      correctAnswer: By speaking out against injustice and advocating for the poor and oppressed."
    })
  },
  {
    id: "G12-CRE-CHU-03",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Role of the Church in the World Today,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The church is also a community of worship, fellowship, and mutual edification. How can the church promote genuine community and discipleship?,
      options: ["By encouraging prayer, Bible study, and accountable relationships., By focusing only on programs.", "By focusing only on entertainment., By neglecting relationships."].sort(() => Math.random() - 0.5),
      correctAnswer: "By encouraging prayer, Bible study, and accountable relationships.
    })
  },
  {
    id: G12-CRE-CHU-04",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Church,
    subtopic: "The Role of the Church in the World Today",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The church is to be a servant to the world, following the example of Christ. How can the church serve its local community in practical ways?,
      options: [By meeting physical needs and sharing the love of Christ., By staying isolated., By focusing only on itself.", "By expecting the world to serve it.].sort(() => Math.random() - 0.5),
      correctAnswer: By meeting physical needs and sharing the love of Christ."
    })
  },
  {
    id: "G12-CRE-CHU-05",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Church",
    subtopic: "The Role of the Church in the World Today,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The church faces increasing opposition and persecution in many parts of the world. How should believers respond to opposition and persecution?,
      options: [By standing firm in faith, praying for their persecutors, and trusting God., By compromising the gospel., "By abandoning the church., By giving up."].sort(() => Math.random() - 0.5),
      correctAnswer: "By standing firm in faith, praying for their persecutors, and trusting God.
    })
  },

  // --- MADA: CHRISTIAN APOLOGETICS (5 Materials) ---
  {
    id: G12-CRE-APO-01",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Christian Apologetics,
    subtopic: "Engaging with Secularism", Atheism, and Other Worldviews",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Christian apologetics involves engaging with secularism, atheism, and other worldviews. Why is it important for Christians to understand and engage with other worldviews?,
      options: [To effectively communicate the gospel and address objections to the Christian faith., To confuse people., To win arguments.", "To prove others wrong.].sort(() => Math.random() - 0.5),
      correctAnswer: To effectively communicate the gospel and address objections to the Christian faith."
    })
  },
  {
    id: "G12-CRE-APO-02",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Christian Apologetics",
    subtopic: "Engaging with Secularism, Atheism, and Other Worldviews,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Secularism is a worldview that excludes God from public life and sees human reason as the ultimate authority. How can Christians engage with secularism?,
      options: [By demonstrating the relevance of faith in a secular age., By ignoring it., "By isolating themselves., By compromising their faith."].sort(() => Math.random() - 0.5),
      correctAnswer: "By demonstrating the relevance of faith in a secular age.
    })
  },
  {
    id: G12-CRE-APO-03",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Christian Apologetics,
    subtopic: "Engaging with Secularism", Atheism, and Other Worldviews",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Atheism denies the existence of God, arguing that the universe is all that exists. How can Christians respond to atheism?,
      options: [By presenting philosophical arguments for God's existence and pointing to the evidence of design., By avoiding the topic., By accepting atheism.", "By ignoring atheists.].sort(() => Math.random() - 0.5),
      correctAnswer: By presenting philosophical arguments for God's existence and pointing to the evidence of design."
    })
  },
  {
    id: "G12-CRE-APO-04",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Christian Apologetics",
    subtopic: "Engaging with Secularism, Atheism, and Other Worldviews,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Engaging with other worldviews requires both conviction and compassion. How can Christians engage with people of other faiths respectfully?,
      options: [By listening to their beliefs, sharing the gospel, and respecting their dignity., By arguing and debating., "By forcing their beliefs on others., By avoiding them."].sort(() => Math.random() - 0.5),
      correctAnswer: "By listening to their beliefs, sharing the gospel, and respecting their dignity.
    })
  },
  {
    id: G12-CRE-APO-05",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Christian Apologetics,
    subtopic: "Engaging with Secularism", Atheism, and Other Worldviews",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Apologetics is ultimately about pointing people to the truth of the gospel. How should apologetics be integrated with evangelism?,
      options: [Apologetics prepares the way for evangelism by answering objections and building trust., Apologetics is not necessary., Apologetics is for intellectuals only.", "Apologetics and evangelism are unrelated.].sort(() => Math.random() - 0.5),
      correctAnswer: Apologetics prepares the way for evangelism by answering objections and building trust."
    })
  },

  // --- MADA: CHRISTIAN ETHICS (5 Materials) ---
  {
    id: "G12-CRE-ETH-01",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Bioethics, Justice, and Care for the Poor,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Christian ethics address bioethical issues such as abortion, euthanasia, and genetic engineering. What is the biblical basis for the sanctity of human life?,
      options: ["Human beings are created in the image of God and have inherent dignity., Human beings are just animals.", "Human beings are products of chance., Human beings have no intrinsic value."].sort(() => Math.random() - 0.5),
      correctAnswer: "Human beings are created in the image of God and have inherent dignity.
    })
  },
  {
    id: G12-CRE-ETH-02",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Bioethics", Justice, and Care for the Poor",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Justice is a key theme in Christian ethics. What does the Bible require of believers regarding justice and fairness?,
      options: [To act justly, love mercy, and walk humbly with God., To pursue wealth and power., To ignore injustice.", "To focus only on personal holiness.].sort(() => Math.random() - 0.5),
      correctAnswer: To act justly, love mercy, and walk humbly with God."
    })
  },
  {
    id: "G12-CRE-ETH-03",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Bioethics, Justice, and Care for the Poor,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Bible commands believers to care for the poor and marginalized. How should Christians practically care for the poor in their communities?,
      options: [By providing food, shelter, and support to those in need., By ignoring them., "By blaming them for their poverty., By expecting the government to help."].sort(() => Math.random() - 0.5),
      correctAnswer: "By providing food, shelter, and support to those in need.
    })
  },
  {
    id: G12-CRE-ETH-04",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "Christian Ethics,
    subtopic: "Bioethics", Justice, and Care for the Poor",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Care for the poor is a mark of true religion according to the Bible. How does caring for the poor demonstrate the reality of faith?,
      options: [It shows that faith is alive and active, not just a profession of belief., It shows that faith is not important., It shows that faith is only about words.", "It shows that faith is only about feelings.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows that faith is alive and active, not just a profession of belief."
    })
  },
  {
    id: "G12-CRE-ETH-05",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "Christian Ethics",
    subtopic: "Bioethics, Justice, and Care for the Poor,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Christian ethics are ultimately grounded in the character of God and the teachings of Jesus. How should Christians integrate their faith with ethical decision-making?,
      options: [By seeking God's wisdom through prayer and Scripture, and acting with love and integrity., By doing whatever is convenient., "By following societal trends., By ignoring the Bible."].sort(() => Math.random() - 0.5),
      correctAnswer: "By seeking God's wisdom through prayer and Scripture, and acting with love and integrity.
    })
  },

  // --- MADA: THE SECOND COMING (5 Materials) ---
  {
    id: G12-CRE-SEC-01",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Second Coming,
    subtopic: "The Return of Christ and the Resurrection",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The second coming of Christ is a central doctrine of the Christian faith. What does the Bible teach about the events surrounding Christ's return?,
      options: [Christ will return in glory, raise the dead, and judge the world., He will return secretly., He will return to establish a political kingdom.", "He will not return.].sort(() => Math.random() - 0.5),
      correctAnswer: Christ will return in glory, raise the dead, and judge the world."
    })
  },
  {
    id: "G12-CRE-SEC-02",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Second Coming",
    subtopic: "The Return of Christ and the Resurrection,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The resurrection of the dead will occur at the time of Christ's return. What will the resurrection entail for believers?,
      options: [They will receive glorified bodies and be transformed into the likeness of Christ., They will remain in their physical bodies., "They will become angels., They will cease to exist."].sort(() => Math.random() - 0.5),
      correctAnswer: "They will receive glorified bodies and be transformed into the likeness of Christ.
    })
  },
  {
    id: G12-CRE-SEC-03",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Second Coming,
    subtopic: "The Return of Christ and the Resurrection",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The second coming of Christ brings both judgment and hope. How should the certainty of Christ's return shape the way believers live?,
      options: [They should live with urgency, readiness, and a focus on eternal priorities., They should live carelessly., They should live only for the present.", "They should live in fear.].sort(() => Math.random() - 0.5),
      correctAnswer: They should live with urgency, readiness, and a focus on eternal priorities."
    })
  },
  {
    id: "G12-CRE-SEC-04",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The Second Coming",
    subtopic: "The Return of Christ and the Resurrection,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The Bible warns that Christ will return at an unexpected time. How does the theme of readiness and preparedness permeate the New Testament?,
      options: [Believers are called to remain watchful and faithful as they await His return., Believers are called to ignore the warnings., "Believers are called to delay their response., Believers are called to live only for today."].sort(() => Math.random() - 0.5),
      correctAnswer: "Believers are called to remain watchful and faithful as they await His return.
    })
  },
  {
    id: G12-CRE-SEC-05",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The Second Coming,
    subtopic: "The Return of Christ and the Resurrection",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " The hope of the second coming gives believers confidence in the face of death and suffering. How does the hope of the second coming provide comfort to believers?,
      options: [It assures them that death is not the end and that God will make all things right., It provides no comfort., It makes them afraid.", "It makes them despair.].sort(() => Math.random() - 0.5),
      correctAnswer: It assures them that death is not the end and that God will make all things right."
    })
  },

  // --- MADA: THE NEW CREATION (5 Materials) ---
  {
    id: "G12-CRE-NEW-01",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The New Creation",
    subtopic: "A New Heaven and a New Earth,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Bible promises a new heaven and a new earth at the end of history. What will the new creation be like according to Scripture?,
      options: [It will be a place of perfect peace, righteousness, and joy in God's presence., It will be a place of boredom., "It will be a place of sleep., It will be a place of rest."].sort(() => Math.random() - 0.5),
      correctAnswer: "It will be a place of perfect peace, righteousness, and joy in God's presence.
    })
  },
  {
    id: G12-CRE-NEW-02",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The New Creation,
    subtopic: "A New Heaven and a New Earth",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The new creation is not just a spiritual reality; it includes a restored physical world. What does the restoration of the physical world signify?,
      options: [It signifies God's commitment to redeem all of creation, not just souls., It signifies that the physical world is not important., It signifies that the physical world will be destroyed.", "It signifies that the physical world is evil.].sort(() => Math.random() - 0.5),
      correctAnswer: It signifies God's commitment to redeem all of creation, not just souls."
    })
  },
  {
    id: "G12-CRE-NEW-03",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The New Creation",
    subtopic: "A New Heaven and a New Earth,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "In the new creation, there will be no more suffering, sorrow, or death. How does this promise of a new creation bring hope to believers who are suffering?,
      options: ["It gives them the assurance that their present suffering is temporary and will be redeemed., It makes them indifferent to suffering.", "It gives them an escape from reality., It makes them focus only on the future."].sort(() => Math.random() - 0.5),
      correctAnswer: "It gives them the assurance that their present suffering is temporary and will be redeemed.
    })
  },
  {
    id: G12-CRE-NEW-04",
    grade: "Grade 12,
    subject: Christian Religious Education",
    topic: "The New Creation,
    subtopic: "A New Heaven and a New Earth",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The new creation will be characterized by the full presence of God. How will the presence of God transform the experience of believers?,
      options: [They will enjoy intimate fellowship with God and experience fullness of joy., They will be separate from God., They will not experience joy.", "They will remain the same.].sort(() => Math.random() - 0.5),
      correctAnswer: They will enjoy intimate fellowship with God and experience fullness of joy."
    })
  },
  {
    id: "G12-CRE-NEW-05",
    grade: "Grade 12",
    subject: "Christian Religious Education",
    topic: "The New Creation",
    subtopic: "A New Heaven and a New Earth,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "The new creation is the culmination of God's redemptive plan and the ultimate hope of believers. How should the hope of the new creation shape the priorities and actions of believers today?,
      options: [They should invest their lives in what has eternal value and live in anticipation of God's coming kingdom., They should focus only on the present., "They should ignore the future., They should live for personal comfort."].sort(() => Math.random() - 0.5),
      correctAnswer: "They should invest their lives in what has eternal value and live in anticipation of God's coming kingdom."
    })
  }

];


