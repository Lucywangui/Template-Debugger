export const environmentalActivitiesTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (KICD ENVIRONMENTAL ACTIVITIES SYLLABUS)
  // =========================================================================

  // --- OUR SCHOOL ENVIRONMENT (5 Materials) ---
  {
    id: "G1-ENV-SCH-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our School Environment",
    subtopic: "The Classroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: "Our classroom is a special place where we learn many things. Which of the following objects is commonly found in a classroom?,
      options: [A desk, A bed, "A kitchen stove, A television"].sort(() => Math.random() - 0.5),
      correctAnswer: "A desk
    })
  },
  {
    id: G1-ENV-SCH-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Our School Environment,
    subtopic: "The Classroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We sit on chairs and write on desks in our classroom. What do we use to write on the blackboard in our classroom?,
      options: [Chalk, A pen, A pencil", "A marker].sort(() => Math.random() - 0.5),
      correctAnswer: Chalk"
    })
  },
  {
    id: "G1-ENV-SCH-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our School Environment",
    subtopic: "The Playground,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The playground is a place where we play and have fun. What activity do we usually do on the playground?,
      options: [Running and playing games, Sleeping, "Eating lunch, Watching TV"].sort(() => Math.random() - 0.5),
      correctAnswer: "Running and playing games
    })
  },
  {
    id: G1-ENV-SCH-04",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Our School Environment,
    subtopic: "The Playground",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " It is important to keep our playground clean. What should we do after playing on the playground?,
      options: [Pick up any rubbish and put it in the bin., Leave the rubbish on the ground., Throw rubbish on the grass.", "Hide the rubbish under the bench.].sort(() => Math.random() - 0.5),
      correctAnswer: Pick up any rubbish and put it in the bin."
    })
  },
  {
    id: "G1-ENV-SCH-05",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our School Environment",
    subtopic: "The School Compound,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Our school compound is the area around the school buildings. How can we make our school compound look beautiful?,
      options: [By planting flowers and trees., By dumping rubbish., "By cutting down trees., By burning leaves."].sort(() => Math.random() - 0.5),
      correctAnswer: "By planting flowers and trees.
    })
  },

  // --- WEATHER AND SEASONS (5 Materials) ---
  {
    id: G1-ENV-WEA-01",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Sunny Weather",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The weather changes from day to day. How do we describe the weather when the sun shines brightly and it is very hot?,
      options: [It is sunny., It is rainy., It is cloudy.", "It is windy.].sort(() => Math.random() - 0.5),
      correctAnswer: It is sunny."
    })
  },
  {
    id: "G1-ENV-WEA-02",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Rainy Weather,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "When it is rainy, we need to protect ourselves. What should we use to stay dry when it is raining?,
      options: [An umbrella, A hat", "A bag, A book"].sort(() => Math.random() - 0.5),
      correctAnswer: "An umbrella
    })
  },
  {
    id: G1-ENV-WEA-03",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Windy Weather",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Sometimes the wind blows strongly, making trees sway and flying objects move. What do we call this kind of weather?,
      options: [Windy, Sunny, Rainy", "Cloudy].sort(() => Math.random() - 0.5),
      correctAnswer: Windy"
    })
  },
  {
    id: "G1-ENV-WEA-04",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Cold Weather,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "During cold weather, we feel chilly and need to wear warm clothes. What should we wear to keep warm on a cold day?,
      options: [A sweater, A t-shirt", "Shorts, Sandals"].sort(() => Math.random() - 0.5),
      correctAnswer: "A sweater
    })
  },
  {
    id: G1-ENV-WEA-05",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Seasons",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Kenya has two main seasons: the rainy season and the dry season. During which season do we see a lot of rain and green plants?,
      options: [The rainy season, The dry season, The cold season", "The hot season].sort(() => Math.random() - 0.5),
      correctAnswer: The rainy season"
    })
  },

  // --- WATER (4 Materials) ---
  {
    id: "G1-ENV-WAT-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "Sources of Water,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Water is essential for life. Where does the water we use in our homes and schools come from?,
      options: [From taps, wells, rivers, and rain., From a shop., "From a factory., From the sea."].sort(() => Math.random() - 0.5),
      correctAnswer: "From taps, wells, rivers, and rain.
    })
  },
  {
    id: G1-ENV-WAT-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Water,
    subtopic: "Sources of Water",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Rain is a natural source of water. What do we use to collect rainwater at home?,
      options: [A bucket, A fork, A spoon", "A cup].sort(() => Math.random() - 0.5),
      correctAnswer: A bucket"
    })
  },
  {
    id: "G1-ENV-WAT-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "Uses of Water,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We use water for many different things every day. Which of the following is a way we use water at home?,
      options: [For drinking, cooking, and bathing., For making bricks., "For building houses., For making clothes."].sort(() => Math.random() - 0.5),
      correctAnswer: "For drinking, cooking, and bathing.
    })
  },
  {
    id: G1-ENV-WAT-04",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Water,
    subtopic: "Uses of Water",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Plants also need water to grow. How do we give water to plants in our garden?,
      options: [By watering them., By covering them., By cutting them.", "By planting them.].sort(() => Math.random() - 0.5),
      correctAnswer: By watering them."
    })
  },

  // --- PLANTS (5 Materials) ---
  {
    id: "G1-ENV-PLA-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Common Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Plants are living things that grow in our environment. Which of the following is a common plant found around us?,
      options: [A mango tree, A stone, "A chair, A book"].sort(() => Math.random() - 0.5),
      correctAnswer: "A mango tree
    })
  },
  {
    id: G1-ENV-PLA-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Common Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Flowers are beautiful parts of some plants. Which of the following is a flower that commonly grows in Kenya?,
      options: [A rose, A stone, A spoon", "A chair].sort(() => Math.random() - 0.5),
      correctAnswer: A rose"
    })
  },
  {
    id: "G1-ENV-PLA-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Common Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Trees are large plants with strong trunks. Which of the following is a famous tree found in Kenya?,
      options: [The baobab tree, Grass, "A shrub, A vine"].sort(() => Math.random() - 0.5),
      correctAnswer: "The baobab tree
    })
  },
  {
    id: G1-ENV-PLA-04",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Common Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Plants give us many things we use in our daily lives. Which of the following comes from a plant?,
      options: [Fruit, Plastic, Glass", "Metal].sort(() => Math.random() - 0.5),
      correctAnswer: Fruit"
    })
  },
  {
    id: "G1-ENV-PLA-05",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Common Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Plants provide us with many essential things, such as food and fresh air. What is the main way that plants help us to breathe?,
      options: [They give us oxygen., They give us carbon dioxide.", "They give us water., They give us sunlight."].sort(() => Math.random() - 0.5),
      correctAnswer: "They give us oxygen.
    })
  },

  // --- ANIMALS (5 Materials) ---
  {
    id: G1-ENV-ANI-01",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Domestic Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Domestic animals are animals that are kept by people. Which of the following is a domestic animal found in many Kenyan homes?,
      options: [A cow, A lion, A giraffe", "A zebra].sort(() => Math.random() - 0.5),
      correctAnswer: A cow"
    })
  },
  {
    id: "G1-ENV-ANI-02",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Animals",
    subtopic: "Domestic Animals,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Some domestic animals provide us with food or help us with work. What does a cow give us that is good for our health?,
      options: [Milk, Meat, "Eggs, Honey"].sort(() => Math.random() - 0.5),
      correctAnswer: "Milk
    })
  },
  {
    id: G1-ENV-ANI-03",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Wild Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Wild animals live in forests, parks, and the wilderness. Which of the following is a wild animal found in Kenya?,
      options: [An elephant, A cow, A goat", "A chicken].sort(() => Math.random() - 0.5),
      correctAnswer: An elephant"
    })
  },
  {
    id: "G1-ENV-ANI-04",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Animals",
    subtopic: "Wild Animals,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Animals such as lions, zebras, and giraffes are often found in national parks in Kenya. Why are wild animals important for Kenya?,
      options: ["They attract tourists and bring revenue., They are dangerous.", "They destroy crops., They eat other animals."].sort(() => Math.random() - 0.5),
      correctAnswer: "They attract tourists and bring revenue.
    })
  },
  {
    id: G1-ENV-ANI-05",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Where Animals Live",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Different animals live in different places. Where do fish and other water creatures live?,
      options: [In water, On land, In the sky", "Underground].sort(() => Math.random() - 0.5),
      correctAnswer: In water"
    })
  },

  // --- SOIL (3 Materials) ---
  {
    id: "G1-ENV-SOI-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Soil",
    subtopic: "Types of Soil,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Soil is the top layer of the earth where plants grow. Which of the following types of soil is best for growing plants?,
      options: [Loam soil, Sandy soil, "Clay soil, Rocky soil"].sort(() => Math.random() - 0.5),
      correctAnswer: "Loam soil
    })
  },
  {
    id: G1-ENV-SOI-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Soil,
    subtopic: "Types of Soil",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Different types of soil have different colors and textures. What color is the dark, fertile soil that is rich in nutrients?,
      options: [Brown or black, Red, Yellow", "White].sort(() => Math.random() - 0.5),
      correctAnswer: Brown or black"
    })
  },
  {
    id: "G1-ENV-SOI-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Soil",
    subtopic: "Uses of Soil,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Soil has many uses in our daily lives. Which of the following is a common use of soil?,
      options: [For growing food crops and building houses., For making electricity., "For making computers., For making clothes."].sort(() => Math.random() - 0.5),
      correctAnswer: "For growing food crops and building houses.
    })
  },

  // --- AIR (3 Materials) ---
  {
    id: G1-ENV-AIR-01",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Air,
    subtopic: "Importance of Air",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Air is invisible, but it is all around us. Why is air important for all living things?,
      options: [We need it to breathe., We need it to sleep., We need it to eat.", "We need it to walk.].sort(() => Math.random() - 0.5),
      correctAnswer: We need it to breathe."
    })
  },
  {
    id: "G1-ENV-AIR-02",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Air",
    subtopic: "Importance of Air,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Air is everywhere around us, even if we cannot see it. How do we know that air is present?,
      options: [We can feel it when the wind blows., We can see it with our eyes.", "We can touch it with our hands., We can taste it with our tongue."].sort(() => Math.random() - 0.5),
      correctAnswer: "We can feel it when the wind blows.
    })
  },
  {
    id: G1-ENV-AIR-03",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Air,
    subtopic: "Importance of Air",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Plants also need air to live. What part of the air do plants take in to make their food?,
      options: [Carbon dioxide, Nitrogen, Oxygen", "Helium].sort(() => Math.random() - 0.5),
      correctAnswer: Carbon dioxide"
    })
  },

  // --- ENERGY (3 Materials) ---
  {
    id: "G1-ENV-ENE-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Energy",
    subtopic: "Sources of Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Energy is the power we use to do work. Which of the following is a natural source of energy?,
      options: [The sun, A car, "A battery, A torch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The sun
    })
  },
  {
    id: G1-ENV-ENE-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Energy,
    subtopic: "Sources of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The sun gives us light and heat. How do we use the sun's energy in our daily lives?,
      options: [We use it to dry our clothes and for warmth., We use it to cook food., We use it to clean our house.", "We use it to wash our clothes.].sort(() => Math.random() - 0.5),
      correctAnswer: We use it to dry our clothes and for warmth."
    })
  },
  {
    id: "G1-ENV-ENE-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Energy",
    subtopic: "Sources of Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Fire is a source of heat and light. Before electricity, people used fire for cooking and to keep warm. What do we need to start a fire?,
      options: [Wood and a spark, Water", "Sand, Stone"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wood and a spark
    })
  },

  // --- WASTE MANAGEMENT (3 Materials) ---
  {
    id: G1-ENV-WAS-01",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Cleaning Our Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Keeping our environment clean is important for our health and happiness. What should we do with the rubbish we find around our school?,
      options: [Put it in the dustbin., Leave it on the ground., Throw it in the river.", "Bury it in the soil.].sort(() => Math.random() - 0.5),
      correctAnswer: Put it in the dustbin."
    })
  },
  {
    id: "G1-ENV-WAS-02",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Waste Management",
    subtopic: "Cleaning Our Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We can also reduce waste by reusing some materials. Which of the following is an example of reusing an item?,
      options: [Using a plastic bag again to carry groceries., Throwing away an old shoe., "Burning old paper., Buying a new pencil every day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Using a plastic bag again to carry groceries.
    })
  },
  {
    id: G1-ENV-WAS-03",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Cleaning Our Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Pollution makes our environment dirty and unhealthy. What is one way we can prevent pollution in our school?,
      options: [By putting rubbish in the proper bins., By burning rubbish., By throwing rubbish into the garden.", "By leaving rubbish under the desks.].sort(() => Math.random() - 0.5),
      correctAnswer: By putting rubbish in the proper bins."
    })
  },

  // --- OUR HOME (3 Materials) ---
  {
    id: "G1-ENV-HOM-01",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Rooms in a House,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "A house has different rooms for different purposes. In which room of the house do we prepare food?,
      options: [The kitchen, The bedroom, "The living room, The bathroom"].sort(() => Math.random() - 0.5),
      correctAnswer: "The kitchen
    })
  },
  {
    id: G1-ENV-HOM-02",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Our Home,
    subtopic: "Rooms in a House",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We sleep and relax in a certain room of the house. Which room is usually used for sleeping?,
      options: [The bedroom, The kitchen, The living room", "The bathroom].sort(() => Math.random() - 0.5),
      correctAnswer: The bedroom"
    })
  },
  {
    id: "G1-ENV-HOM-03",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Family Members,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "In our home, we live with our family members. Who are the family members that usually live together in a Kenyan home?,
      options: [Parents, children, and sometimes grandparents., Only the children.", "Only the parents., Only the grandparents."].sort(() => Math.random() - 0.5),
      correctAnswer: "Parents, children, and sometimes grandparents.
    })
  },

  // --- OUR NEIGHBOURHOOD (2 Materials) ---
  {
    id: G1-ENV-NEI-01",
    grade: "Grade 1,
    subject: Environmental Activities",
    topic: "Our Neighbourhood,
    subtopic: "Places in the Neighbourhood",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Our neighbourhood is the area around our home. Which of the following places can be found in a neighbourhood?,
      options: [A market or a shop, A jungle, A desert", "A mountain].sort(() => Math.random() - 0.5),
      correctAnswer: A market or a shop"
    })
  },
  {
    id: "G1-ENV-NEI-02",
    grade: "Grade 1",
    subject: "Environmental Activities",
    topic: "Our Neighbourhood",
    subtopic: "Places in the Neighbourhood,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The neighbourhood has important places for the community. Where do people go to buy things like food and clothes?,
      options: [The market, The hospital, "The school, The church"].sort(() => Math.random() - 0.5),
      correctAnswer: "The market
    })
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (KICD ENVIRONMENTAL ACTIVITIES SYLLABUS)
  // =========================================================================

  // --- OUR ENVIRONMENT (3 Materials) ---
  {
    id: G2-ENV-ENV-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Our Environment,
    subtopic: "The Environment as a Source of Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The environment provides us with everything we need to live. What are some of the basic things we get from our environment?,
      options: [Food, water, and air., Clothes and shoes., Cars and bicycles.", "Books and pencils.].sort(() => Math.random() - 0.5),
      correctAnswer: Food, water, and air."
    })
  },
  {
    id: "G2-ENV-ENV-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Our Environment",
    subtopic: "The Environment as a Source of Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The environment is the natural world around us. Why is it important to take care of our environment?,
      options: [Because it gives us everything we need to survive., Because it is a place to throw rubbish., "Because it is only for animals., Because it is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "Because it gives us everything we need to survive.
    })
  },
  {
    id: G2-ENV-ENV-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Our Environment,
    subtopic: "The Environment as a Source of Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " All living things depend on the environment for their survival. What is the best way to protect our environment?,
      options: [By planting trees and cleaning up litter., By cutting down all the trees., By polluting the rivers.", "By wasting water.].sort(() => Math.random() - 0.5),
      correctAnswer: By planting trees and cleaning up litter."
    })
  },

  // --- WEATHER AND SEASONS (4 Materials) ---
  {
    id: "G2-ENV-WEA-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Recording Weather Changes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Weather changes from day to day. What do we use to measure the temperature of the air?,
      options: [A thermometer, A ruler, "A scale, A cup"].sort(() => Math.random() - 0.5),
      correctAnswer: "A thermometer
    })
  },
  {
    id: G2-ENV-WEA-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Recording Weather Changes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We can also measure the amount of rain that falls. What instrument is used to measure the amount of rainfall?,
      options: [A rain gauge, A thermometer, A wind vane", "A barometer].sort(() => Math.random() - 0.5),
      correctAnswer: A rain gauge"
    })
  },
  {
    id: "G2-ENV-WEA-03",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Recording Weather Changes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The direction of the wind is important for predicting weather. What instrument tells us the direction of the wind?,
      options: [A wind vane, A thermometer, "A rain gauge, A barometer"].sort(() => Math.random() - 0.5),
      correctAnswer: "A wind vane
    })
  },
  {
    id: G2-ENV-WEA-04",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Recording Weather Changes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Farmers depend on weather patterns to know when to plant their crops. Why is it important to record weather changes?,
      options: [To help farmers plan and prepare for different seasons., To know what to wear., To know when to travel.", "To know when to go to school.].sort(() => Math.random() - 0.5),
      correctAnswer: To help farmers plan and prepare for different seasons."
    })
  },

  // --- WATER (3 Materials) ---
  {
    id: "G2-ENV-WAT-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "Importance and Conservation of Water,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Water is a precious resource that we must use wisely. Why is it important to conserve water?,
      options: [Because water is limited and we need it for survival., Because water is expensive., "Because water is always available., Because we can live without water."].sort(() => Math.random() - 0.5),
      correctAnswer: "Because water is limited and we need it for survival.
    })
  },
  {
    id: G2-ENV-WAT-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Water,
    subtopic: "Importance and Conservation of Water",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " There are many ways we can conserve water at home and at school. What is one way to conserve water when brushing your teeth?,
      options: [Turn off the tap while brushing., Leave the tap running., Use more water than needed.", "Brush without water.].sort(() => Math.random() - 0.5),
      correctAnswer: Turn off the tap while brushing."
    })
  },
  {
    id: "G2-ENV-WAT-03",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "Importance and Conservation of Water,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Rainwater harvesting is a good way to conserve water. How can we harvest rainwater at home?,
      options: [By placing containers outside to collect rain., By letting rainwater run off., "By using a hose pipe., By digging a well."].sort(() => Math.random() - 0.5),
      correctAnswer: "By placing containers outside to collect rain.
    })
  },

  // --- PLANTS (4 Materials) ---
  {
    id: G2-ENV-PLA-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Parts of a Plant",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " A plant is made up of different parts that each have a specific function. Which part of a plant anchors it in the soil and absorbs water?,
      options: [The root, The stem, The leaf", "The flower].sort(() => Math.random() - 0.5),
      correctAnswer: The root"
    })
  },
  {
    id: "G2-ENV-PLA-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Parts of a Plant,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Plants have different parts that help them grow and reproduce. Which part of a plant transports water and nutrients from the roots to the leaves?,
      options: [The stem, The root, "The flower, The fruit"].sort(() => Math.random() - 0.5),
      correctAnswer: "The stem
    })
  },
  {
    id: G2-ENV-PLA-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Parts of a Plant",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Leaves are important parts of a plant that make food through photosynthesis. What do leaves need to make food for the plant?,
      options: [Sunlight, water, and carbon dioxide., Sunlight and soil., Water and oxygen.", "Carbon dioxide and nitrogen.].sort(() => Math.random() - 0.5),
      correctAnswer: Sunlight, water, and carbon dioxide."
    })
  },
  {
    id: "G2-ENV-PLA-04",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Parts of a Plant,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Flowers are colorful parts of a plant that produce seeds. What do we call the process by which flowers produce seeds?,
      options: [Pollination, Germination, "Photosynthesis, Transpiration"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pollination
    })
  },

  // --- ANIMALS (4 Materials) ---
  {
    id: G2-ENV-ANI-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Where Animals Live",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Animals live in different habitats depending on their needs. What do we call the natural home of an animal?,
      options: [A habitat, A house, A building", "A room].sort(() => Math.random() - 0.5),
      correctAnswer: A habitat"
    })
  },
  {
    id: "G2-ENV-ANI-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Animals",
    subtopic: "Food Animals Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Animals have different diets based on what they eat. What do we call animals that eat only plants?,
      options: [Herbivores, Carnivores, "Omnivores, Insectivores"].sort(() => Math.random() - 0.5),
      correctAnswer: "Herbivores
    })
  },
  {
    id: G2-ENV-ANI-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Food Animals Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Some animals eat both plants and other animals. What do we call animals that eat both plants and meat?,
      options: [Omnivores, Herbivores, Carnivores", "Insectivores].sort(() => Math.random() - 0.5),
      correctAnswer: Omnivores"
    })
  },
  {
    id: "G2-ENV-ANI-04",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Animals",
    subtopic: "Food Animals Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Animals such as lions, leopards, and cheetahs eat meat. What do we call animals that only eat meat?,
      options: ["Carnivores, Herbivores", "Omnivores, Insectivores"].sort(() => Math.random() - 0.5),
      correctAnswer: "Carnivores
    })
  },

  // --- SOIL (3 Materials) ---
  {
    id: G2-ENV-SOI-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Soil,
    subtopic: "Components of Soil",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Soil is made up of different components. Which of the following is NOT a component of soil?,
      options: [Plastic, Mineral particles, Organic matter", "Air].sort(() => Math.random() - 0.5),
      correctAnswer: Plastic"
    })
  },
  {
    id: "G2-ENV-SOI-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Soil",
    subtopic: "Components of Soil,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Soil contains living and non-living things. What are the tiny living organisms found in soil that help break down dead matter?,
      options: [Microorganisms, Rocks, "Minerals, Sand"].sort(() => Math.random() - 0.5),
      correctAnswer: "Microorganisms
    })
  },
  {
    id: G2-ENV-SOI-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Soil,
    subtopic: "Uses of Soil",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Soil is very important for many human activities. Which of the following is a use of soil in everyday life?,
      options: [Making pottery and building houses., Making paper., Making clothes.", "Making glass.].sort(() => Math.random() - 0.5),
      correctAnswer: Making pottery and building houses."
    })
  },

  // --- AIR (3 Materials) ---
  {
    id: "G2-ENV-AIR-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Air",
    subtopic: "Air is Everywhere,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Air is present everywhere around us. Which of the following proves that air is all around us?,
      options: [We can feel it when the wind blows., We can see it in the sky., "We can taste it., We can smell it."].sort(() => Math.random() - 0.5),
      correctAnswer: "We can feel it when the wind blows.
    })
  },
  {
    id: G2-ENV-AIR-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Air,
    subtopic: "Air is Everywhere",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Air takes up space even though we cannot see it. What happens when you blow air into a balloon?,
      options: [The balloon expands and becomes larger., The balloon shrinks., The balloon remains the same.", "The balloon bursts.].sort(() => Math.random() - 0.5),
      correctAnswer: The balloon expands and becomes larger."
    })
  },
  {
    id: "G2-ENV-AIR-03",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Air",
    subtopic: "Importance of Air,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Air is essential for life on Earth. What would happen if there was no air on Earth?,
      options: [All living things would die., Life would continue normally., "Only plants would survive., Only animals would survive."].sort(() => Math.random() - 0.5),
      correctAnswer: "All living things would die.
    })
  },

  // --- ENERGY (3 Materials) ---
  {
    id: G2-ENV-ENE-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Energy,
    subtopic: "Uses of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Energy is used for many different purposes in our daily lives. What do we use energy for in our homes?,
      options: [For lighting, cooking, and heating., For playing games., For sleeping.", "For painting.].sort(() => Math.random() - 0.5),
      correctAnswer: For lighting, cooking, and heating."
    })
  },
  {
    id: "G2-ENV-ENE-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Energy",
    subtopic: "Uses of Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The sun is a very important source of energy. How does the sun provide energy for plants?,
      options: [Through photosynthesis., Through respiration., "Through germination., Through pollination."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through photosynthesis.
    })
  },
  {
    id: G2-ENV-ENE-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Energy,
    subtopic: "Uses of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Wind is another source of energy that can be used. How can wind be used to generate energy?,
      options: [By using wind turbines to make electricity., By using the wind to dry clothes., By using the wind to fly kites.", "By using the wind to cool homes.].sort(() => Math.random() - 0.5),
      correctAnswer: By using wind turbines to make electricity."
    })
  },

  // --- WASTE MANAGEMENT (4 Materials) ---
  {
    id: "G2-ENV-WAS-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Waste Management",
    subtopic: "Reducing, Reusing, and Recycling Waste,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We can reduce waste by following the three R's. What do the three R's in waste management stand for?,
      options: [Reduce, Reuse, and Recycle., Reduce, Repair, and Rebuild., "Reuse, Repurpose, and Renew., Recycle, Renew, and Restore."].sort(() => Math.random() - 0.5),
      correctAnswer: "Reduce, Reuse, and Recycle.
    })
  },
  {
    id: G2-ENV-WAS-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Reducing", Reusing, and Recycling Waste",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Recycling helps to conserve resources and reduce waste. Which of the following items can be recycled?,
      options: [Plastic bottles, paper, and glass., Food waste., Old clothes.", "Batteries.].sort(() => Math.random() - 0.5),
      correctAnswer: Plastic bottles, paper, and glass."
    })
  },
  {
    id: "G2-ENV-WAS-03",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Waste Management",
    subtopic: "Reducing, Reusing, and Recycling Waste,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Reducing waste is the best way to manage waste. How can we reduce waste when shopping?,
      options: [By using reusable bags instead of plastic bags., By taking many plastic bags., "By using new plastic bags every time., By not using any bags."].sort(() => Math.random() - 0.5),
      correctAnswer: "By using reusable bags instead of plastic bags.
    })
  },
  {
    id: G2-ENV-WAS-04",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Reducing", Reusing, and Recycling Waste",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Composting is a form of recycling organic waste. What can we use compost for in our garden?,
      options: [To enrich soil and help plants grow., To make plastic., To make glass.", "To build houses.].sort(() => Math.random() - 0.5),
      correctAnswer: To enrich soil and help plants grow."
    })
  },

  // --- OUR HOME (3 Materials) ---
  {
    id: "G2-ENV-HOM-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Furniture and Objects in the Home,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Homes contain many different types of furniture and objects. Which piece of furniture is used for sleeping?,
      options: [A bed, A chair, "A table, A cupboard"].sort(() => Math.random() - 0.5),
      correctAnswer: "A bed
    })
  },
  {
    id: G2-ENV-HOM-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Our Home,
    subtopic: "Furniture and Objects in the Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We keep our food in a special piece of furniture to keep it cool and fresh. What is this piece of furniture called?,
      options: [A refrigerator, A cabinet, A drawer", "A shelf].sort(() => Math.random() - 0.5),
      correctAnswer: A refrigerator"
    })
  },
  {
    id: "G2-ENV-HOM-03",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Furniture and Objects in the Home,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We use various objects to clean our home. Which object is used to sweep the floor?,
      options: [A broom, A mop, "A duster, A vacuum cleaner"].sort(() => Math.random() - 0.5),
      correctAnswer: "A broom
    })
  },

  // --- OUR NEIGHBOURHOOD (3 Materials) ---
  {
    id: G2-ENV-NEI-01",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Our Neighbourhood,
    subtopic: "People and Their Occupations",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " People in our neighbourhood have different jobs and occupations. What does a teacher do in the community?,
      options: [Teaches students at school., Sells food at the market., Treats sick people.", "Builds houses.].sort(() => Math.random() - 0.5),
      correctAnswer: Teaches students at school."
    })
  },
  {
    id: "G2-ENV-NEI-02",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Our Neighbourhood",
    subtopic: "People and Their Occupations,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We have many people who help keep our neighbourhood safe and healthy. What does a police officer do?,
      options: [Maintains law and order., Teaches students., "Treats sick people., Builds roads."].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintains law and order.
    })
  },
  {
    id: G2-ENV-NEI-03",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Our Neighbourhood,
    subtopic: "People and Their Occupations",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We go to the hospital when we are sick. Who is the person that takes care of sick people in a hospital?,
      options: [A doctor, A teacher, A police officer", "A driver].sort(() => Math.random() - 0.5),
      correctAnswer: A doctor"
    })
  },

  // --- ROAD SAFETY (2 Materials) ---
  {
    id: "G2-ENV-ROA-01",
    grade: "Grade 2",
    subject: "Environmental Activities",
    topic: "Road Safety",
    subtopic: "Safe Ways of Crossing the Road,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Road safety is important to prevent accidents. What is the safest way to cross a busy road?,
      options: [Use a zebra crossing with a traffic light., Cross between parked cars., "Run across quickly., Cross with your eyes closed."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a zebra crossing with a traffic light.
    })
  },
  {
    id: G2-ENV-ROA-02",
    grade: "Grade 2,
    subject: Environmental Activities",
    topic: "Road Safety,
    subtopic: "Safe Ways of Crossing the Road",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When crossing the road, we should follow certain safety rules. What is the rule about checking before you cross the road?,
      options: [Stop, look left, right, and left again before crossing., Stop and cross immediately., Look only to the left.", "Look only to the right.].sort(() => Math.random() - 0.5),
      correctAnswer: Stop, look left, right, and left again before crossing."
    })
  },

  // =========================================================================
  // GRADE 3: 35 MATERIALS (KICD ENVIRONMENTAL ACTIVITIES SYLLABUS)
  // =========================================================================

  // --- OUR ENVIRONMENT (3 Materials) ---
  {
    id: "G3-ENV-ENV-01",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Our Environment",
    subtopic: "The Immediate Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The immediate environment is the area around us where we live, learn, and play. What are some of the features you might find in your immediate environment?,
      options: ["Homes, schools, shops, and trees., Only mountains and rivers.", "Only factories and machines., Only fields and farms."].sort(() => Math.random() - 0.5),
      correctAnswer: "Homes, schools, shops, and trees.
    })
  },
  {
    id: G3-ENV-ENV-02",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Our Environment,
    subtopic: "The Immediate Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Our immediate environment is made up of both natural and man-made features. Which of the following is a natural feature in our environment?,
      options: [A river, A road, A building", "A bridge].sort(() => Math.random() - 0.5),
      correctAnswer: A river"
    })
  },
  {
    id: "G3-ENV-ENV-03",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Our Environment",
    subtopic: "The Immediate Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We can observe different things in our immediate environment. How can we tell if our immediate environment is healthy?,
      options: [There is clean air, clean water, and green plants., There is a lot of smoke and dust., "There are many factories., There is too much traffic."].sort(() => Math.random() - 0.5),
      correctAnswer: "There is clean air, clean water, and green plants.
    })
  },

  // --- WEATHER AND SEASONS (4 Materials) ---
  {
    id: G3-ENV-WEA-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Effects of Weather on People and Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Weather affects people and animals in different ways. How does hot, sunny weather affect animals in the wild?,
      options: [Animals seek shade and water to cool down., Animals become more active., Animals migrate to colder areas.", "Animals build nests.].sort(() => Math.random() - 0.5),
      correctAnswer: Animals seek shade and water to cool down."
    })
  },
  {
    id: "G3-ENV-WEA-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Effects of Weather on People and Animals,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Heavy rain can have both positive and negative effects on people. What is one negative effect of heavy rainfall?,
      options: [It can cause floods and destroy property., It helps plants grow., "It fills up rivers., It provides water for farming."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can cause floods and destroy property.
    })
  },
  {
    id: G3-ENV-WEA-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Weather and Seasons,
    subtopic: "Effects of Weather on People and Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " During the dry season, there is little rainfall. How does the dry season affect people and their crops?,
      options: [Crops may dry up and fail to produce food., Crops grow faster., People use less water.", "Crops become cheaper.].sort(() => Math.random() - 0.5),
      correctAnswer: Crops may dry up and fail to produce food."
    })
  },
  {
    id: "G3-ENV-WEA-04",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Weather and Seasons",
    subtopic: "Effects of Weather on People and Animals,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Strong winds can be both helpful and harmful. How can strong winds cause damage to people and property?,
      options: [They can blow roofs off houses and uproot trees., They can help dry clothes., "They can cool the environment., They can help plants spread seeds."].sort(() => Math.random() - 0.5),
      correctAnswer: "They can blow roofs off houses and uproot trees.
    })
  },

  // --- WATER (4 Materials) ---
  {
    id: G3-ENV-WAT-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Water,
    subtopic: "The Water Cycle",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The water cycle describes how water moves through the environment. What is the process called when water changes from a liquid to a gas and rises into the air?,
      options: [Evaporation, Condensation, Precipitation", "Collection].sort(() => Math.random() - 0.5),
      correctAnswer: Evaporation"
    })
  },
  {
    id: "G3-ENV-WAT-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "The Water Cycle,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "When water vapor in the air cools, it changes back into liquid water. What is this process called?,
      options: [Condensation, Evaporation", "Precipitation, Collection"].sort(() => Math.random() - 0.5),
      correctAnswer: "Condensation
    })
  },
  {
    id: G3-ENV-WAT-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Water,
    subtopic: "The Water Cycle",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Water returns to the earth in the form of rain, snow, or hail. What is this process called?,
      options: [Precipitation, Evaporation, Condensation", "Collection].sort(() => Math.random() - 0.5),
      correctAnswer: Precipitation"
    })
  },
  {
    id: "G3-ENV-WAT-04",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Water",
    subtopic: "Water Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Water conservation is important to ensure we have enough water for the future. What is one way we can conserve water in our homes?,
      options: [Fix leaking taps and pipes., Use more water for washing., "Water plants during the hottest part of the day., Keep taps running while brushing teeth."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fix leaking taps and pipes.
    })
  },

  // --- PLANTS (4 Materials) ---
  {
    id: G3-ENV-PLA-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Types of Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Plants can be grouped into different categories based on their characteristics. Which of the following is a flowering plant?,
      options: [A rose, A fern, A moss", "A pine tree].sort(() => Math.random() - 0.5),
      correctAnswer: A rose"
    })
  },
  {
    id: "G3-ENV-PLA-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Types of Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Non-flowering plants reproduce through spores instead of seeds. Which of the following is an example of a non-flowering plant?,
      options: [A fern, A sunflower, "A mango tree, A hibiscus"].sort(() => Math.random() - 0.5),
      correctAnswer: "A fern
    })
  },
  {
    id: G3-ENV-PLA-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Plants,
    subtopic: "Importance of Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Plants are vital for life on Earth. Which of the following is a way that plants are important for human beings?,
      options: [They provide food, medicine, and building materials., They create noise pollution., They cause soil erosion.", "They reduce rainfall.].sort(() => Math.random() - 0.5),
      correctAnswer: They provide food, medicine, and building materials."
    })
  },
  {
    id: "G3-ENV-PLA-04",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Plants",
    subtopic: "Importance of Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Plants play a crucial role in the environment by providing oxygen and improving air quality. How do plants help to reduce climate change?,
      options: [By absorbing carbon dioxide from the atmosphere., By producing more carbon dioxide., "By releasing harmful gases., By blocking sunlight."].sort(() => Math.random() - 0.5),
      correctAnswer: "By absorbing carbon dioxide from the atmosphere.
    })
  },

  // --- ANIMALS (3 Materials) ---
  {
    id: G3-ENV-ANI-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Classification of Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Animals can be classified into different groups based on their characteristics. What is the main difference between vertebrates and invertebrates?,
      options: [Vertebrates have a backbone while invertebrates do not., Vertebrates are small while invertebrates are large., Vertebrates live on land while invertebrates live in water.", "Vertebrates eat meat while invertebrates eat plants.].sort(() => Math.random() - 0.5),
      correctAnswer: Vertebrates have a backbone while invertebrates do not."
    })
  },
  {
    id: "G3-ENV-ANI-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Animals",
    subtopic: "Classification of Animals,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Mammals are one group of vertebrates that share certain characteristics. Which of the following is a characteristic that all mammals share?,
      options: [They have fur or hair and feed their young with milk., They lay eggs., "They have scales., They live in water."].sort(() => Math.random() - 0.5),
      correctAnswer: "They have fur or hair and feed their young with milk.
    })
  },
  {
    id: G3-ENV-ANI-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Animals,
    subtopic: "Classification of Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Insects are the largest group of invertebrates. What characteristic is common to all insects?,
      options: [They have six legs and three body parts., They have four legs., They have wings.", "They have eight legs.].sort(() => Math.random() - 0.5),
      correctAnswer: They have six legs and three body parts."
    })
  },

  // --- SOIL (3 Materials) ---
  {
    id: "G3-ENV-SOI-01",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Soil",
    subtopic: "Soil Formation,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Soil is formed through a process that takes a very long time. What is the process called by which rocks break down to form soil?,
      options: [Weathering, Erosion, "Deposition, Compaction"].sort(() => Math.random() - 0.5),
      correctAnswer: "Weathering
    })
  },
  {
    id: G3-ENV-SOI-02",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Soil,
    subtopic: "Soil Formation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Different agents cause weathering of rocks to form soil. Which of the following is a natural agent that causes weathering?,
      options: [Wind and water, Plastic, Glass", "Metal].sort(() => Math.random() - 0.5),
      correctAnswer: Wind and water"
    })
  },
  {
    id: "G3-ENV-SOI-03",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Soil",
    subtopic: "Importance of Soil,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Soil is important for supporting life on Earth. What is one way that soil supports life on Earth?,
      options: [It provides nutrients for plants to grow., It produces electricity., "It creates rain., It makes plastic."].sort(() => Math.random() - 0.5),
      correctAnswer: "It provides nutrients for plants to grow.
    })
  },

  // --- AIR (3 Materials) ---
  {
    id: G3-ENV-AIR-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Air,
    subtopic: "Air Pollution and Its Effects",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Air pollution occurs when harmful substances are released into the air. What is a common cause of air pollution in cities?,
      options: [Smoke from vehicles and factories., Rainwater., Wind from the sea.", "Soil particles.].sort(() => Math.random() - 0.5),
      correctAnswer: Smoke from vehicles and factories."
    })
  },
  {
    id: "G3-ENV-AIR-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Air",
    subtopic: "Air Pollution and Its Effects,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Air pollution can have serious effects on human health. What is one health problem caused by air pollution?,
      options: [Respiratory problems like asthma and coughing., Broken bones., "Stomach problems., Skin problems."].sort(() => Math.random() - 0.5),
      correctAnswer: "Respiratory problems like asthma and coughing.
    })
  },
  {
    id: G3-ENV-AIR-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Air,
    subtopic: "Air Pollution and Its Effects",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Air pollution also affects the environment and climate. How does air pollution contribute to climate change?,
      options: [By increasing greenhouse gases in the atmosphere., By decreasing the amount of oxygen., By cooling the atmosphere.", "By increasing rainfall.].sort(() => Math.random() - 0.5),
      correctAnswer: By increasing greenhouse gases in the atmosphere."
    })
  },

  // --- ENERGY (3 Materials) ---
  {
    id: "G3-ENV-ENE-01",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Energy",
    subtopic: "Renewable and Non-renewable Energy Sources,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Energy sources can be classified as renewable or non-renewable. Which of the following is a renewable source of energy?,
      options: [Solar energy, Coal, "Oil, Natural gas"].sort(() => Math.random() - 0.5),
      correctAnswer: "Solar energy
    })
  },
  {
    id: G3-ENV-ENE-02",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Energy,
    subtopic: "Renewable and Non-renewable Energy Sources",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fossil fuels are non-renewable energy sources that take millions of years to form. Which of the following is an example of a fossil fuel?,
      options: [Petroleum, Solar power, Wind power", "Hydro power].sort(() => Math.random() - 0.5),
      correctAnswer: Petroleum"
    })
  },
  {
    id: "G3-ENV-ENE-03",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Energy",
    subtopic: "Renewable and Non-renewable Energy Sources,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Using renewable energy sources is better for the environment. Why is solar energy considered a renewable and clean source of energy?,
      options: [It is from the sun and does not produce pollution., It is expensive., "It is available only at night., It produces harmful gases."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is from the sun and does not produce pollution.
    })
  },

  // --- WASTE MANAGEMENT (3 Materials) ---
  {
    id: G3-ENV-WAS-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Proper Disposal of Waste",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Proper disposal of waste is important to keep our environment clean. What is the correct way to dispose of household waste?,
      options: [Separating and disposing of waste in designated bins., Burning all waste., Dumping waste in rivers.", "Burying waste in the garden.].sort(() => Math.random() - 0.5),
      correctAnswer: Separating and disposing of waste in designated bins."
    })
  },
  {
    id: "G3-ENV-WAS-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Waste Management",
    subtopic: "Proper Disposal of Waste,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Hazardous waste, such as batteries and chemicals, needs special disposal methods. Why should hazardous waste not be disposed of with regular household waste?,
      options: ["Because it can harm the environment and human health., Because it is heavy.", "Because it is expensive., Because it is large."].sort(() => Math.random() - 0.5),
      correctAnswer: "Because it can harm the environment and human health.
    })
  },
  {
    id: G3-ENV-WAS-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Waste Management,
    subtopic: "Proper Disposal of Waste",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Composting is an effective way to manage organic waste. What types of waste are suitable for composting?,
      options: [Food scraps, leaves, and grass clippings., Plastic bottles and bags., Glass and metal containers.", "Old electronics and batteries.].sort(() => Math.random() - 0.5),
      correctAnswer: Food scraps, leaves, and grass clippings."
    })
  },

  // --- OUR HOME (3 Materials) ---
  {
    id: "G3-ENV-HOM-01",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Keeping the Home Clean and Safe,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Keeping our home clean is important for good health. What daily practices can keep our home clean?,
      options: [Sweeping floors, dusting surfaces, and washing dishes., Leaving food uncovered., "Forgetting to take out the rubbish., Not washing hands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweeping floors, dusting surfaces, and washing dishes.
    })
  },
  {
    id: G3-ENV-HOM-02",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Our Home,
    subtopic: "Keeping the Home Clean and Safe",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Safety is important in the home to prevent accidents. What safety measure should be taken with harmful substances in the home?,
      options: [Keep them out of reach of children and in labeled containers., Keep them near food., Keep them on the floor.", "Keep them in unlocked cabinets.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep them out of reach of children and in labeled containers."
    })
  },
  {
    id: "G3-ENV-HOM-03",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Our Home",
    subtopic: "Keeping the Home Clean and Safe,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Cleaning the home involves different tasks in different areas. Which room in the home needs special attention to prevent the spread of germs?,
      options: [The kitchen and bathroom., The living room., "The bedroom., The dining room."].sort(() => Math.random() - 0.5),
      correctAnswer: "The kitchen and bathroom.
    })
  },

  // --- OUR NEIGHBOURHOOD (3 Materials) ---
  {
    id: G3-ENV-NEI-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Our Neighbourhood,
    subtopic: "The Community and Its Leaders",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A community is made up of people living in the same area. Who is the traditional leader in many Kenyan communities?,
      options: [The village elder, The president, The teacher", "The priest].sort(() => Math.random() - 0.5),
      correctAnswer: The village elder"
    })
  },
  {
    id: "G3-ENV-NEI-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Our Neighbourhood",
    subtopic: "The Community and Its Leaders,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Government leaders help manage the affairs of the community. Which leader is elected by adults in a particular area to represent them?,
      options: [The area Member of Parliament (MP), The president, "The judge, The chief"].sort(() => Math.random() - 0.5),
      correctAnswer: "The area Member of Parliament (MP)
    })
  },
  {
    id: G3-ENV-NEI-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Our Neighbourhood,
    subtopic: "The Community and Its Leaders",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Religious leaders play an important role in the community. What role do religious leaders typically play in the community?,
      options: [They provide spiritual guidance and moral leadership., They build roads., They teach in schools.", "They arrest criminals.].sort(() => Math.random() - 0.5),
      correctAnswer: They provide spiritual guidance and moral leadership."
    })
  },

  // --- HEALTH AND HYGIENE (3 Materials) ---
  {
    id: "G3-ENV-HEA-01",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Health and Hygiene",
    subtopic: "Prevention of Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Malaria is a common disease in many parts of Kenya. How can we prevent the spread of malaria?,
      options: [By sleeping under insecticide-treated mosquito nets., By drinking clean water., "By washing hands., By eating healthy food."].sort(() => Math.random() - 0.5),
      correctAnswer: "By sleeping under insecticide-treated mosquito nets.
    })
  },
  {
    id: G3-ENV-HEA-02",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Health and Hygiene,
    subtopic: "Prevention of Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Cholera is a disease that can be caused by contaminated water and food. How can we prevent cholera?,
      options: [By drinking clean, treated water and washing hands before eating., By drinking river water., By eating undercooked food.", "By not washing hands.].sort(() => Math.random() - 0.5),
      correctAnswer: By drinking clean, treated water and washing hands before eating."
    })
  },
  {
    id: "G3-ENV-HEA-03",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Health and Hygiene",
    subtopic: "Prevention of Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Vaccination is an important way to prevent diseases. Why are vaccines given to children and adults?,
      options: [To protect them from specific diseases., To give them energy., "To make them taller., To improve their hearing."].sort(() => Math.random() - 0.5),
      correctAnswer: "To protect them from specific diseases.
    })
  },

  // --- ENVIRONMENTAL CONSERVATION (3 Materials) ---
  {
    id: G3-ENV-CON-01",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Environmental Conservation,
    subtopic: "Tree Planting",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tree planting is an important conservation activity. Why is planting trees beneficial for the environment?,
      options: [They provide oxygen, prevent erosion, and provide habitats for animals., They increase air pollution., They use too much water.", "They reduce rainfall.].sort(() => Math.random() - 0.5),
      correctAnswer: They provide oxygen, prevent erosion, and provide habitats for animals."
    })
  },
  {
    id: "G3-ENV-CON-02",
    grade: "Grade 3",
    subject: "Environmental Activities",
    topic: "Environmental Conservation",
    subtopic: "Protecting Water Sources,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Water sources such as rivers, lakes, and springs need to be protected. What is one way to protect water sources from pollution?,
      options: ["Preventing people from washing clothes or dumping waste in rivers., Building more houses near rivers.", "Allowing industries to dispose of waste in rivers., Dumping chemicals into lakes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Preventing people from washing clothes or dumping waste in rivers.
    })
  },
  {
    id: G3-ENV-CON-03",
    grade: "Grade 3,
    subject: Environmental Activities",
    topic: "Environmental Conservation,
    subtopic: "Protecting Water Sources",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Maintaining vegetation around water sources is important for water conservation. How does planting trees near water sources help protect them?,
      options: [Trees prevent soil erosion and keep the water clean., Trees use up all the water., Trees make water unsafe to drink.", "Trees block the water flow.].sort(() => Math.random() - 0.5),
      correctAnswer: Trees prevent soil erosion and keep the water clean."
    })
  }
];


