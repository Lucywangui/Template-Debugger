export const businessStudiesTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD BUSINESS STUDIES SYLLABUS)
  // =========================================================================

  // --- INTRODUCTION TO BUSINESS STUDIES (3 Materials) ---
  {
    id: "G10-BS-IB-01",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Introduction to Business Studies",
    subtopic: "Nature and Purpose of Business",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "Business is defined as any activity that involves the production, distribution, or exchange of goods and services for profit. Which of the following correctly describes the primary purpose of a business enterprise in a market economy?,
      options: [
        "The primary purpose of a business is to create value for customers by satisfying their needs and wants, while generating profit for the owners or shareholders.,
        The primary purpose of a business is to maximize employee salaries and benefits.",
        "The primary purpose of a business is to minimize production costs at all costs.,
        The primary purpose of a business is to reduce competition in the market."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The primary purpose of a business is to create value for customers by satisfying their needs and wants, while generating profit for the owners or shareholders.
    })
  },
  {
    id: G10-BS-IB-02",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Introduction to Business Studies,
    subtopic: "Business Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Businesses engage in various activities to produce and deliver goods and services. Which of the following is considered a primary business activity that directly creates value for customers?,
      options: [
        Production activities that transform raw materials into finished goods or deliver services to customers are considered primary business activities that directly create value.,
        Human resource management is a primary business activity.,
        Financial management is a primary business activity.",
        "Marketing is a secondary business activity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Production activities that transform raw materials into finished goods or deliver services to customers are considered primary business activities that directly create value."
    })
  },
  {
    id: "G10-BS-IB-03",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Introduction to Business Studies",
    subtopic: "Business Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The business environment consists of all external forces that affect a business's operations. Which of the following is an element of the macro-environment that businesses must monitor and adapt to?,
      options: [
        Economic factors such as inflation, interest rates, and economic growth are elements of the macro-environment that significantly impact business operations, costs, and consumer spending.,
        Competitors are part of the macro-environment.,
        "Employees are part of the macro-environment.,
        Suppliers are part of the macro-environment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Economic factors such as inflation, interest rates, and economic growth are elements of the macro-environment that significantly impact business operations, costs, and consumer spending.
    })
  },

  // --- ENTREPRENEURSHIP (5 Materials) ---
  {
    id: G10-BS-EN-01",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Entrepreneurship,
    subtopic: "Entrepreneurial Characteristics",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Entrepreneurs possess certain characteristics that contribute to their success in business. Which of the following is a key characteristic of successful entrepreneurs that enables them to persevere through challenges and setbacks?,
      options: [
        Resilience is a key characteristic of successful entrepreneurs, allowing them to persevere through challenges, learn from failures, and maintain focus on their business goals despite obstacles.,
        Risk aversion is a key characteristic of successful entrepreneurs.,
        Reluctance to change is a key characteristic of successful entrepreneurs.",
        "Avoiding challenges is a key characteristic of successful entrepreneurs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Resilience is a key characteristic of successful entrepreneurs, allowing them to persevere through challenges, learn from failures, and maintain focus on their business goals despite obstacles."
    })
  },
  {
    id: "G10-BS-EN-02",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Entrepreneurship",
    subtopic: "Business Opportunities,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Identifying viable business opportunities is a critical skill for entrepreneurs. Which of the following is the most effective way for an entrepreneur to identify a business opportunity in the market?,
      options: [
        Conducting market research to identify unmet needs, gaps in the market, and emerging trends is the most effective way for entrepreneurs to discover viable business opportunities.,
        Copying existing successful businesses is the most effective way.,
        "Ignoring market trends and customer needs is effective.,
        Relying only on personal interests without market research is effective."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conducting market research to identify unmet needs, gaps in the market, and emerging trends is the most effective way for entrepreneurs to discover viable business opportunities.
    })
  },
  {
    id: G10-BS-EN-03",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Entrepreneurship,
    subtopic: "Startup Process",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Starting a business involves several steps from idea generation to launch. Which of the following is the correct first step an entrepreneur should take when starting a new business?,
      options: [
        Developing a business plan is the first and most important step in starting a business, as it outlines the business concept, target market, financial projections, and operational strategy.,
        Registering the business is the first step in starting a business.,
        Securing funding is the first step in starting a business.",
        "Hiring employees is the first step in starting a business.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Developing a business plan is the first and most important step in starting a business, as it outlines the business concept, target market, financial projections, and operational strategy."
    })
  },
  {
    id: "G10-BS-EN-04",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Entrepreneurship",
    subtopic: "Business Plan,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A business plan is a written document that describes a business's goals and how they will be achieved. Which of the following sections of a business plan provides details about the products or services the business will offer?,
      options: [
        The products and services section of a business plan describes what the business will offer, including the features and benefits of the products or services to customers.,
        The executive summary provides details about products and services.,
        "The marketing plan provides details about products and services.,
        The financial plan provides details about products and services."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The products and services section of a business plan describes what the business will offer, including the features and benefits of the products or services to customers.
    })
  },
  {
    id: G10-BS-EN-05",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Entrepreneurship,
    subtopic: "Feasibility Study",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A feasibility study assesses the viability of a business idea before significant resources are committed. Which of the following is a key component of a feasibility study?,
      options: [
        A market feasibility assessment examines the demand, competition, and customer acceptance of the proposed product or service to determine if there is a viable market opportunity.,
        A feasibility study only examines financial viability.,
        A feasibility study ignores market conditions.",
        "A feasibility study is not necessary before starting a business.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A market feasibility assessment examines the demand, competition, and customer acceptance of the proposed product or service to determine if there is a viable market opportunity."
    })
  },

  // --- BUSINESS OWNERSHIP (5 Materials) ---
  {
    id: "G10-BS-BO-01",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Ownership",
    subtopic: "Sole Proprietorship,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "A sole proprietorship is a business owned and operated by one person. Which of the following is a key advantage of a sole proprietorship compared to other forms of business ownership?,
      options: [
        A key advantage of a sole proprietorship is that it is easy and inexpensive to establish, and the owner has complete control over all business decisions.,
        A sole proprietorship has unlimited liability for the owner.,
        "A sole proprietorship has limited access to capital.,
        A sole proprietorship has limited management expertise."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A key advantage of a sole proprietorship is that it is easy and inexpensive to establish, and the owner has complete control over all business decisions.
    })
  },
  {
    id: G10-BS-BO-02",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Business Ownership,
    subtopic: "Partnerships",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A partnership is a business owned by two or more persons who share profits, losses, and management responsibilities. Which of the following is a disadvantage of a general partnership?,
      options: [
        A disadvantage of a general partnership is that partners have unlimited liability for the debts of the business and can be personally liable for the actions of other partners.,
        A partnership is easy to form.,
        A partnership has access to more capital.",
        "A partnership has combined management skills.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A disadvantage of a general partnership is that partners have unlimited liability for the debts of the business and can be personally liable for the actions of other partners."
    })
  },
  {
    id: "G10-BS-BO-03",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Ownership",
    subtopic: "Companies,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A company (corporation) is a legal entity separate from its owners. Which of the following is a key feature of a public limited company (PLC)?,
      options: [
        A public limited company (PLC) has shares that are traded on a stock exchange, allowing the public to buy and sell shares, and is required to publish its financial statements.,
        A public limited company has unlimited liability for shareholders.,
        "A public limited company cannot raise capital from the public.,
        A public limited company is owned by one individual."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A public limited company (PLC) has shares that are traded on a stock exchange, allowing the public to buy and sell shares, and is required to publish its financial statements.
    })
  },
  {
    id: G10-BS-BO-04",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Business Ownership,
    subtopic: "Cooperatives",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A cooperative is a business owned and operated by its members for their mutual benefit. Which of the following is the guiding principle of a cooperative?,
      options: [
        The guiding principle of a cooperative is democratic control, where each member has one vote regardless of their investment, ensuring equal participation in decision-making.,
        Cooperatives are profit-driven corporations.,
        Cooperatives are owned by external investors.",
        "Cooperatives have hierarchical management structures.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The guiding principle of a cooperative is democratic control, where each member has one vote regardless of their investment, ensuring equal participation in decision-making."
    })
  },
  {
    id: "G10-BS-BO-05",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Ownership",
    subtopic: "Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Different forms of business ownership have different advantages and disadvantages. Which of the following is a key advantage of a private limited company (Ltd) over a sole proprietorship?,
      options: [
        A key advantage of a private limited company is the limited liability of shareholders, meaning they are not personally liable for the company's debts beyond their investment in shares.,
        A private limited company is easier to set up than a sole proprietorship.,
        "A private limited company has no regulatory requirements.,
        A private limited company has unlimited liability for shareholders."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A key advantage of a private limited company is the limited liability of shareholders, meaning they are not personally liable for the company's debts beyond their investment in shares.
    })
  },

  // --- BUSINESS FINANCE (4 Materials) ---
  {
    id: G10-BS-BF-01",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Business Finance,
    subtopic: "Sources of Capital",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Businesses need capital to start operations and grow. Which of the following is an example of equity financing, where the business raises capital by selling ownership shares?,
      options: [
        Equity financing involves raising capital by selling shares of the business to investors, who become owners and have a claim on future profits.,
        Bank loans are a form of equity financing.,
        Trade credit is a form of equity financing.",
        "Leasing is a form of equity financing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Equity financing involves raising capital by selling shares of the business to investors, who become owners and have a claim on future profits."
    })
  },
  {
    id: "G10-BS-BF-02",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Finance",
    subtopic: "Sources of Capital,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Debt financing involves borrowing money that must be repaid with interest. Which of the following is a source of debt financing for a small business?,
      options: [
        A bank loan is a source of debt financing where the business borrows money from a bank and agrees to repay it with interest over a specified period.,
        Venture capital is debt financing.,
        "Angel investors provide debt financing.,
        Retained earnings are debt financing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A bank loan is a source of debt financing where the business borrows money from a bank and agrees to repay it with interest over a specified period.
    })
  },
  {
    id: G10-BS-BF-03",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Business Finance,
    subtopic: "Financial Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Financial management involves planning, organizing, and controlling the financial resources of a business. Which of the following is the primary goal of financial management?,
      options: [
        The primary goal of financial management is to maximize the value of the business and shareholder wealth through effective financial planning and decision-making.,
        The primary goal is to minimize expenses at all costs.,
        The primary goal is to maximize employee benefits.",
        "The primary goal is to avoid any financial risk.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The primary goal of financial management is to maximize the value of the business and shareholder wealth through effective financial planning and decision-making."
    })
  },
  {
    id: "G10-BS-BF-04",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Finance",
    subtopic: "Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Budgeting is the process of estimating and planning future income and expenses. Which of the following is a purpose of preparing a business budget?,
      options: [
        A budget helps businesses plan for the future, control costs, monitor financial performance, and make informed decisions about resource allocation.,
        A budget is only used for tax purposes.,
        "A budget has no role in business planning.,
        A budget is only prepared once a year."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A budget helps businesses plan for the future, control costs, monitor financial performance, and make informed decisions about resource allocation.
    })
  },

  // --- MARKETING (5 Materials) ---
  {
    id: G10-BS-MK-01",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Marketing,
    subtopic: "Marketing Concepts",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Marketing is the process of identifying, anticipating, and satisfying customer needs profitably. Which of the following is the core concept of the marketing concept?,
      options: [
        The marketing concept focuses on understanding and satisfying customer needs and wants as the path to business success, placing the customer at the center of business decisions.,
        The marketing concept focuses only on selling products.,
        The marketing concept ignores customer needs.",
        "The marketing concept focuses only on production efficiency.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The marketing concept focuses on understanding and satisfying customer needs and wants as the path to business success, placing the customer at the center of business decisions."
    })
  },
  {
    id: "G10-BS-MK-02",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Marketing",
    subtopic: "Market Research,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Market research is the systematic collection and analysis of information about the market and customers. Which of the following is a primary data collection method in market research?,
      options: [
        Surveys and questionnaires are primary data collection methods that gather information directly from customers and other stakeholders about their preferences, behaviors, and attitudes.,
        Government reports are primary data sources.,
        "Industry publications are primary data sources.,
        Online articles are primary data sources."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Surveys and questionnaires are primary data collection methods that gather information directly from customers and other stakeholders about their preferences, behaviors, and attitudes.
    })
  },
  {
    id: G10-BS-MK-03",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Marketing,
    subtopic: "Marketing Mix",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The marketing mix consists of the 4Ps: Product, Price, Place, and Promotion. Which of the following elements of the marketing mix involves decisions about the features, design, branding, and packaging of a product?,
      options: [
        Product decisions involve determining the features, design, quality, branding, packaging, and other aspects of the product that will be offered to customers.,
        Price decisions involve product features.,
        Place decisions involve product features.",
        "Promotion decisions involve product features.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Product decisions involve determining the features, design, quality, branding, packaging, and other aspects of the product that will be offered to customers."
    })
  },
  {
    id: "G10-BS-MK-04",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Marketing",
    subtopic: "Marketing Mix,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Promotion is the element of the marketing mix that communicates with customers. Which of the following is an example of above-the-line promotion in marketing?,
      options: [
        Advertising through mass media such as television, radio, newspapers, and magazines is an example of above-the-line promotion that reaches a wide audience.,
        Direct selling is an example of above-the-line promotion.,
        "Sales promotions are above-the-line promotion.,
        Public relations are above-the-line promotion."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Advertising through mass media such as television, radio, newspapers, and magazines is an example of above-the-line promotion that reaches a wide audience.
    })
  },
  {
    id: G10-BS-MK-05",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Marketing,
    subtopic: "Marketing Mix",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Distribution (Place) involves making products available to customers. Which of the following distribution channels involves selling directly from the manufacturer to the consumer without intermediaries?,
      options: [
        Direct distribution involves selling products directly from the manufacturer to the consumer through company-owned stores, online platforms, or direct sales, eliminating intermediaries.,
        Indirect distribution involves selling directly to consumers.,
        Wholesale distribution involves direct distribution.",
        "Retail distribution is a direct channel.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Direct distribution involves selling products directly from the manufacturer to the consumer through company-owned stores, online platforms, or direct sales, eliminating intermediaries."
    })
  },

  // --- HUMAN RESOURCE MANAGEMENT (4 Materials) ---
  {
    id: "G10-BS-HR-01",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Recruitment,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Recruitment is the process of attracting and selecting qualified candidates for employment. Which of the following is the first step in the recruitment process?,
      options: [
        Identifying the need for a new employee and defining the job role and requirements is the first step in the recruitment process, often involving the preparation of a job description.,
        Interviewing candidates is the first step in the recruitment process.,
        "Advertising the position is the first step in the recruitment process.,
        Selecting a candidate is the first step in the recruitment process."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Identifying the need for a new employee and defining the job role and requirements is the first step in the recruitment process, often involving the preparation of a job description.
    })
  },
  {
    id: G10-BS-HR-02",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Selection",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Selection is the process of choosing the most suitable candidate from those who have applied for a job. Which of the following is a selection tool used to assess a candidate's suitability for a position?,
      options: [
        Interviews are a widely used selection tool that allows employers to assess candidates' knowledge, skills, experience, and cultural fit through direct questioning and observation.,
        Reference checks are only used for promotions.,
        Application forms are used after the interview.",
        "Work sample tests are not a selection tool.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Interviews are a widely used selection tool that allows employers to assess candidates' knowledge, skills, experience, and cultural fit through direct questioning and observation."
    })
  },
  {
    id: "G10-BS-HR-03",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Training and Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Training and development aim to improve employees' skills and performance. Which of the following is a benefit of investing in employee training and development?,
      options: [
        Training and development improve employee performance, increase job satisfaction and motivation, reduce turnover, and provide employees with the skills needed for career advancement.,
        Training and development are not beneficial for the business.,
        "Training and development only benefit employees, not the business.,
        Training and development reduce productivity in the short term."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Training and development improve employee performance, increase job satisfaction and motivation, reduce turnover, and provide employees with the skills needed for career advancement.
    })
  },
  {
    id: G10-BS-HR-04",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Motivation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Motivation is the process of encouraging employees to work effectively and achieve organizational goals. Which of the following is a theory of motivation that focuses on the hierarchy of human needs?,
      options: [
        Maslow's Hierarchy of Needs is a theory of motivation that proposes that individuals are motivated by a hierarchy of needs, from basic physiological needs to self-actualization needs.,
        Herzberg's Two-Factor Theory is about the hierarchy of needs.,
        McGregor's Theory X and Theory Y is about the hierarchy of needs.",
        "Vroom's Expectancy Theory is about the hierarchy of needs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maslow's Hierarchy of Needs is a theory of motivation that proposes that individuals are motivated by a hierarchy of needs, from basic physiological needs to self-actualization needs."
    })
  },

  // --- PRODUCTION AND OPERATIONS MANAGEMENT (4 Materials) ---
  {
    id: "G10-BS-PO-01",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Production and Operations Management",
    subtopic: "Types of Production,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Production is the process of converting inputs into outputs. Which of the following types of production involves the continuous production of standardized products in large volumes?,
      options: [
        Mass production involves the continuous production of standardized products in large volumes using assembly lines and specialized machinery, achieving high efficiency and low unit costs.,
        Job production is continuous production.,
        "Batch production is continuous production.,
        Project production is continuous production."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mass production involves the continuous production of standardized products in large volumes using assembly lines and specialized machinery, achieving high efficiency and low unit costs.
    })
  },
  {
    id: G10-BS-PO-02",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Production and Operations Management,
    subtopic: "Productivity",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Productivity measures the efficiency of production by comparing outputs to inputs. Which of the following is a way to improve labor productivity in a business?,
      options: [
        Investing in employee training and providing better tools and equipment can improve labor productivity by enabling employees to produce more output in less time.,
        Reducing employee wages improves labor productivity.,
        Increasing working hours always improves productivity.",
        "Ignoring employee feedback improves productivity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Investing in employee training and providing better tools and equipment can improve labor productivity by enabling employees to produce more output in less time."
    })
  },
  {
    id: "G10-BS-PO-03",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Production and Operations Management",
    subtopic: "Quality Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Quality management ensures that products or services meet customer expectations. Which of the following is a quality management approach that focuses on continuous improvement and involving all employees in quality control?,
      options: [
        Total Quality Management (TQM) is an approach that emphasizes continuous improvement, customer focus, and the involvement of all employees in quality control and decision-making.,
        Quality control is a management approach that involves employee involvement.,
        "Six Sigma is not a quality management approach.,
        Quality assurance is focused only on final inspection."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Total Quality Management (TQM) is an approach that emphasizes continuous improvement, customer focus, and the involvement of all employees in quality control and decision-making.
    })
  },
  {
    id: G10-BS-PO-04",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Production and Operations Management,
    subtopic: "Lean Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Lean production aims to minimize waste while maximizing productivity. Which of the following is a principle of lean production?,
      options: [
        Just-in-time (JIT) production is a lean production principle that focuses on producing goods only when needed to reduce inventory costs and eliminate waste.,
        Mass production is a principle of lean production.,
        Building large inventories is a principle of lean production.",
        "Ignoring customer feedback is a principle of lean production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Just-in-time (JIT) production is a lean production principle that focuses on producing goods only when needed to reduce inventory costs and eliminate waste."
    })
  },

  // --- BUSINESS ETHICS AND SOCIAL RESPONSIBILITY (3 Materials) ---
  {
    id: "G10-BS-ES-01",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Ethics and Social Responsibility",
    subtopic: "Ethical Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Business ethics involves the application of moral principles in business decision-making. Which of the following is an example of unethical business behavior?,
      options: [
        Misleading advertising or making false claims about products to deceive customers is an example of unethical business behavior that violates consumer trust and legal standards.,
        Ensuring product safety is unethical business behavior.,
        "Paying fair wages to employees is unethical business behavior.,
        Being transparent with stakeholders is unethical business behavior."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Misleading advertising or making false claims about products to deceive customers is an example of unethical business behavior that violates consumer trust and legal standards.
    })
  },
  {
    id: G10-BS-ES-02",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Business Ethics and Social Responsibility,
    subtopic: "Corporate Social Responsibility",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Corporate Social Responsibility (CSR) is the commitment of businesses to operate ethically and contribute to sustainable development. Which of the following is an example of CSR activity?,
      options: [
        Implementing environmental sustainability initiatives, such as reducing carbon emissions and promoting recycling, is an example of CSR that benefits society while enhancing the company's reputation.,
        Ignoring environmental concerns is a CSR activity.,
        Maximizing profit at all costs is a CSR activity.",
        "Avoiding community engagement is a CSR activity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Implementing environmental sustainability initiatives, such as reducing carbon emissions and promoting recycling, is an example of CSR that benefits society while enhancing the company's reputation."
    })
  },
  {
    id: "G10-BS-ES-03",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Business Ethics and Social Responsibility",
    subtopic: "Business Ethics,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Ethical business practices are important for building trust and long-term success. Which of the following is a benefit of maintaining high ethical standards in a business?,
      options: [
        Maintaining high ethical standards builds trust with customers, employees, investors, and the community, leading to a positive reputation, customer loyalty, and long-term business success.,
        Ethical standards limit business growth.,
        "Ethical standards reduce profits.,
        Ethical standards are only important for legal compliance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintaining high ethical standards builds trust with customers, employees, investors, and the community, leading to a positive reputation, customer loyalty, and long-term business success.
    })
  },

  // --- INFORMATION TECHNOLOGY IN BUSINESS (2 Materials) ---
  {
    id: G10-BS-IT-01",
    grade: "Grade 10,
    subject: Business Studies",
    topic: "Information Technology in Business,
    subtopic: "Use of ICT",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Information and Communication Technology (ICT) has transformed business operations. Which of the following is a way that ICT has improved business efficiency?,
      options: [
        ICT enables automation of routine tasks, improves communication and collaboration, provides access to data and analytics for decision-making, and facilitates e-commerce and online transactions.,
        ICT reduces communication within businesses.,
        ICT makes data analysis more difficult.",
        "ICT eliminates the need for human workers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: ICT enables automation of routine tasks, improves communication and collaboration, provides access to data and analytics for decision-making, and facilitates e-commerce and online transactions."
    })
  },
  {
    id: "G10-BS-IT-02",
    grade: "Grade 10",
    subject: "Business Studies",
    topic: "Information Technology in Business",
    subtopic: "E-Commerce,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "E-commerce involves buying and selling goods and services online. Which of the following is a benefit of e-commerce for businesses?,
      options: [
        E-commerce provides businesses with access to a global market, reduces operational costs, allows for 24/7 sales, and provides data on customer preferences and buying behavior.,
        E-commerce limits the market reach of businesses.,
        "E-commerce increases operational costs.,
        E-commerce is not beneficial for small businesses."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "E-commerce provides businesses with access to a global market, reduces operational costs, allows for 24/7 sales, and provides data on customer preferences and buying behavior.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD BUSINESS STUDIES SYLLABUS)
  // =========================================================================

  // --- BUSINESS ENVIRONMENT (4 Materials) ---
  {
    id: G11-BS-BE-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Business Environment,
    subtopic: "Micro Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The micro-environment consists of factors within the immediate operating environment of a business. Which of the following is a component of the micro-environment?,
      options: [
        The micro-environment includes the business's customers, suppliers, competitors, stakeholders, and employees who directly influence the business's operations and success.,
        Government regulations are part of the micro-environment.,
        Economic conditions are part of the micro-environment.",
        "Technology trends are part of the micro-environment.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The micro-environment includes the business's customers, suppliers, competitors, stakeholders, and employees who directly influence the business's operations and success."
    })
  },
  {
    id: "G11-BS-BE-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Business Environment",
    subtopic: "Market Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The market environment includes factors that directly influence a business's ability to compete in the market. Which of the following is an element of the market environment?,
      options: [
        The market environment includes the nature and intensity of competition, changes in customer needs and preferences, and the bargaining power of suppliers and buyers.,
        Economic conditions are part of the market environment.,
        "Political factors are part of the market environment.,
        Technological changes are part of the market environment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The market environment includes the nature and intensity of competition, changes in customer needs and preferences, and the bargaining power of suppliers and buyers.
    })
  },
  {
    id: G11-BS-BE-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Business Environment,
    subtopic: "Macro Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The macro-environment consists of broad external forces that affect all businesses. Which of the following is a PESTLE factor that businesses must monitor in the macro-environment?,
      options: [
        Technological factors such as automation, artificial intelligence, and digitalization are macro-environmental factors that businesses must monitor and adapt to remain competitive.,
        Competitor strategies are macro-environmental factors.,
        Supplier relationships are macro-environmental factors.",
        "Customer feedback is a macro-environmental factor.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Technological factors such as automation, artificial intelligence, and digitalization are macro-environmental factors that businesses must monitor and adapt to remain competitive."
    })
  },
  {
    id: "G11-BS-BE-04",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Business Environment",
    subtopic: "SWOT Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "SWOT analysis is a strategic planning tool used to evaluate a business's internal strengths and weaknesses, and external opportunities and threats. Which of the following is a weakness in a SWOT analysis?,
      options: [
        A weakness is an internal factor that hinders a business's performance, such as limited financial resources, lack of expertise, or an outdated technology infrastructure.,
        A weakness is an external factor beyond the business's control.",
        "A weakness is a positive attribute of the business.,
        A weakness is an opportunity for growth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A weakness is an internal factor that hinders a business's performance, such as limited financial resources, lack of expertise, or an outdated technology infrastructure.
    })
  },

  // --- BUSINESS PLANNING (4 Materials) ---
  {
    id: G11-BS-BP-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Business Planning,
    subtopic: "Business Plans",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " A business plan is a formal document that outlines the goals, strategies, and operational plans of a business. Which of the following is the primary purpose of a business plan?,
      options: [
        The primary purpose of a business plan is to provide a roadmap for the business's future, attract investors and lenders, and guide decision-making to achieve strategic objectives.,
        A business plan is only used for legal compliance.,
        A business plan is only useful for large corporations.",
        "A business plan is not important for business success.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The primary purpose of a business plan is to provide a roadmap for the business's future, attract investors and lenders, and guide decision-making to achieve strategic objectives."
    })
  },
  {
    id: "G11-BS-BP-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Business Planning",
    subtopic: "Feasibility Studies,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A feasibility study assesses the viability of a business idea before significant resources are committed. Which of the following is a key aspect of a technical feasibility assessment?,
      options: [
        Technical feasibility assesses whether the business has the necessary technology, equipment, skills, and processes to produce the product or deliver the service effectively.,
        Technical feasibility assesses market demand.,
        "Technical feasibility assesses financial viability.,
        Technical feasibility assesses legal compliance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Technical feasibility assesses whether the business has the necessary technology, equipment, skills, and processes to produce the product or deliver the service effectively.
    })
  },
  {
    id: G11-BS-BP-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Business Planning,
    subtopic: "Business Strategy",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Business strategy involves the long-term plans and actions a business takes to achieve its goals. Which of the following is a market penetration strategy?,
      options: [
        Market penetration involves increasing sales of existing products in existing markets through marketing, pricing, and distribution strategies, without changing the product or entering new markets.,
        Market penetration involves entering new markets with new products.,
        Market penetration involves developing new products for existing markets.",
        "Market penetration involves diversification.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Market penetration involves increasing sales of existing products in existing markets through marketing, pricing, and distribution strategies, without changing the product or entering new markets."
    })
  },
  {
    id: "G11-BS-BP-04",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Business Planning",
    subtopic: "Strategic Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Strategic management involves the formulation, implementation, and evaluation of strategies to achieve organizational goals. Which of the following is the first step in the strategic management process?,
      options: [
        "The first step in the strategic management process is to define the organization's vision, mission, and strategic objectives, which provide the foundation for all subsequent strategic decisions.,
        Implementing strategies is the first step in strategic management.",
        "Evaluating strategies is the first step in strategic management.,
        Analyzing the business environment is the first step."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The first step in the strategic management process is to define the organization's vision, mission, and strategic objectives, which provide the foundation for all subsequent strategic decisions.
    })
  },

  // --- FINANCIAL ACCOUNTING (5 Materials) ---
  {
    id: G11-BS-FA-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Financial Accounting,
    subtopic: "Double-Entry Bookkeeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Double-entry bookkeeping is a system where every transaction is recorded in at least two accounts with equal debit and credit entries. Which of the following is the fundamental principle of double-entry bookkeeping?,
      options: [
        The fundamental principle of double-entry bookkeeping is that for every debit entry, there must be a corresponding credit entry of equal value, ensuring that the accounting equation (Assets = Liabilities + Equity) remains balanced.,
        Double-entry bookkeeping records only one side of a transaction.,
        Double-entry bookkeeping does not require equal debit and credit entries.",
        "Double-entry bookkeeping only records cash transactions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The fundamental principle of double-entry bookkeeping is that for every debit entry, there must be a corresponding credit entry of equal value, ensuring that the accounting equation (Assets = Liabilities + Equity) remains balanced."
    })
  },
  {
    id: "G11-BS-FA-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Financial Accounting",
    subtopic: "Financial Statements,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Financial statements provide a summary of a business's financial performance and position. Which of the following financial statements shows a business's financial position at a specific point in time?,
      options: [
        The balance sheet (statement of financial position) shows a business's assets, liabilities, and equity at a specific point in time, providing a snapshot of its financial position.,
        The income statement shows a business's financial position at a point in time.,
        "The cash flow statement shows financial position at a point in time.,
        The statement of changes in equity shows financial position at a point in time."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The balance sheet (statement of financial position) shows a business's assets, liabilities, and equity at a specific point in time, providing a snapshot of its financial position.
    })
  },
  {
    id: G11-BS-FA-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Financial Accounting,
    subtopic: "Financial Statements",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The income statement (profit and loss statement) shows a business's financial performance over a period of time. Which of the following is calculated by subtracting the cost of goods sold from sales revenue?,
      options: [
        Gross profit is calculated by subtracting the cost of goods sold from sales revenue, indicating the profit from selling goods before deducting operating expenses.,
        Net profit is calculated by subtracting cost of goods sold from sales revenue.,
        Operating profit is calculated by subtracting cost of goods sold from sales revenue.",
        "Gross profit is calculated after all expenses are deducted.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Gross profit is calculated by subtracting the cost of goods sold from sales revenue, indicating the profit from selling goods before deducting operating expenses."
    })
  },
  {
    id: "G11-BS-FA-04",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Financial Accounting",
    subtopic: "Financial Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Financial ratio analysis is used to evaluate a business's performance and financial health. Which of the following ratios measures a business's ability to meet its short-term obligations?,
      options: [
        The current ratio (current assets / current liabilities) measures a business's liquidity and its ability to meet short-term obligations with its current assets.,
        The debt-to-equity ratio measures liquidity.,
        "The gross profit margin measures liquidity.,
        The return on equity measures liquidity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The current ratio (current assets / current liabilities) measures a business's liquidity and its ability to meet short-term obligations with its current assets.
    })
  },
  {
    id: G11-BS-FA-05",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Financial Accounting,
    subtopic: "Financial Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Financial analysis helps stakeholders make informed decisions. Which of the following ratios measures the profitability of a business relative to its sales revenue?,
      options: [
        The net profit margin measures the profitability of a business by showing the net profit as a percentage of sales revenue, indicating how effectively the business controls costs.,
        The current ratio measures profitability.,
        The debt-to-equity ratio measures profitability.",
        "The return on assets measures profitability.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The net profit margin measures the profitability of a business by showing the net profit as a percentage of sales revenue, indicating how effectively the business controls costs."
    })
  },

  // --- MARKETING MANAGEMENT (5 Materials) ---
  {
    id: "G11-BS-MM-01",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Marketing Management",
    subtopic: "Product Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Product development involves creating new products or improving existing ones to meet customer needs. Which of the following is the first stage of the new product development process?,
      options: [
        Idea generation is the first stage of the new product development process, where ideas for new products are collected from various sources such as customers, employees, research, and competitors.,
        Concept testing is the first stage of the new product development process.,
        "Market testing is the first stage of the new product development process.,
        Product launch is the first stage of the new product development process."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Idea generation is the first stage of the new product development process, where ideas for new products are collected from various sources such as customers, employees, research, and competitors.
    })
  },
  {
    id: G11-BS-MM-02",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Marketing Management,
    subtopic: "Pricing Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Pricing strategies determine how a business sets the price of its products. Which of the following pricing strategies involves setting a high price initially and then gradually lowering it over time?,
      options: [
        Skimming pricing involves setting a high price initially to target early adopters and maximize profits, then gradually lowering the price to attract more price-sensitive customers.,
        Penetration pricing involves setting a high initial price.,
        Competitive pricing involves setting prices based on the cost of production.",
        "Psychological pricing involves setting a price ending in 9.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Skimming pricing involves setting a high price initially to target early adopters and maximize profits, then gradually lowering the price to attract more price-sensitive customers."
    })
  },
  {
    id: "G11-BS-MM-03",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Marketing Management",
    subtopic: "Promotion Strategies,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Promotion involves communicating with customers to inform, persuade, and remind them about products. Which of the following is a form of below-the-line promotion?,
      options: [
        "Sales promotions such as coupons, contests, and discounts are below-the-line promotion activities that provide direct incentives to customers to purchase products.,
        Television advertising is below-the-line promotion.",
        "Radio advertising is below-the-line promotion.,
        Public relations are below-the-line promotion."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sales promotions such as coupons, contests, and discounts are below-the-line promotion activities that provide direct incentives to customers to purchase products.
    })
  },
  {
    id: G11-BS-MM-04",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Marketing Management,
    subtopic: "Distribution Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Distribution strategies determine how products are moved from the producer to the consumer. Which of the following distribution channels involves intermediaries such as wholesalers and retailers?,
      options: [
        Indirect distribution involves the use of intermediaries such as wholesalers and retailers to move products from the producer to the consumer, leveraging their established networks and market expertise.,
        Direct distribution involves using intermediaries.,
        Direct distribution is always more cost-effective.",
        "All businesses use indirect distribution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Indirect distribution involves the use of intermediaries such as wholesalers and retailers to move products from the producer to the consumer, leveraging their established networks and market expertise."
    })
  },
  {
    id: "G11-BS-MM-05",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Marketing Management",
    subtopic: "Brand Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Brand management involves building and maintaining a positive brand image. Which of the following is a benefit of strong brand equity for a business?,
      options: [
        Strong brand equity leads to customer loyalty, allows the business to charge premium prices, and provides a competitive advantage that is difficult for competitors to imitate.,
        Brand equity is only important for large businesses.,
        "Brand equity does not affect customer purchasing decisions.,
        Brand equity is the same as product quality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Strong brand equity leads to customer loyalty, allows the business to charge premium prices, and provides a competitive advantage that is difficult for competitors to imitate.
    })
  },

  // --- HUMAN RESOURCE MANAGEMENT (4 Materials) ---
  {
    id: G11-BS-HR-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Performance Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Performance management is the process of setting goals, monitoring performance, and providing feedback to employees. Which of the following is a tool used in performance management?,
      options: [
        Performance appraisals are a tool used in performance management to evaluate employee performance, provide feedback, identify areas for improvement, and make decisions about promotions and compensation.,
        Recruitment is a performance management tool.,
        Training is a performance management tool.",
        "Selection is a performance management tool.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Performance appraisals are a tool used in performance management to evaluate employee performance, provide feedback, identify areas for improvement, and make decisions about promotions and compensation."
    })
  },
  {
    id: "G11-BS-HR-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Employee Relations,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Employee relations involve managing the relationship between employers and employees. Which of the following is a method of resolving workplace disputes between employees and management?,
      options: [
        Mediation and arbitration are methods of resolving workplace disputes where a neutral third party helps the parties reach a mutually acceptable resolution or makes a binding decision.,
        Litigation is always the best method of resolving disputes.,
        "Ignoring the dispute will resolve it over time.,
        Terminating employment is a method of dispute resolution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mediation and arbitration are methods of resolving workplace disputes where a neutral third party helps the parties reach a mutually acceptable resolution or makes a binding decision.
    })
  },
  {
    id: G11-BS-HR-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Labor Laws",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Labor laws regulate the relationship between employers and employees to ensure fair treatment. Which of the following is a key provision of the Employment Act in Kenya?,
      options: [
        The Employment Act provides for minimum standards of employment, including minimum wage, working hours, annual leave, sick leave, and protection against unfair dismissal, ensuring fair treatment of employees.,
        Labor laws only apply to large corporations.,
        Labor laws are optional for employers to follow.",
        "Labor laws do not protect employee rights.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Employment Act provides for minimum standards of employment, including minimum wage, working hours, annual leave, sick leave, and protection against unfair dismissal, ensuring fair treatment of employees."
    })
  },
  {
    id: "G11-BS-HR-04",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Employee Motivation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Employee motivation is crucial for productivity and retention. Which of the following is a non-financial incentive that can motivate employees?,
      options: [
        Recognition and appreciation, career development opportunities, meaningful work, and a positive work environment are non-financial incentives that motivate employees and improve job satisfaction.,
        Bonuses are non-financial incentives.,
        "Salary increases are non-financial incentives.,
        Profit sharing is a non-financial incentive."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Recognition and appreciation, career development opportunities, meaningful work, and a positive work environment are non-financial incentives that motivate employees and improve job satisfaction.
    })
  },

  // --- OPERATIONS MANAGEMENT (4 Materials) ---
  {
    id: G11-BS-OM-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Operations Management,
    subtopic: "Supply Chain Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Supply chain management involves the coordination of all activities from raw material sourcing to the delivery of finished products to customers. Which of the following is a key objective of supply chain management?,
      options: [
        A key objective of supply chain management is to ensure the efficient flow of materials, information, and products through the supply chain, minimizing costs and meeting customer demands.,
        Supply chain management only focuses on transportation.,
        Supply chain management is only concerned with suppliers.",
        "Supply chain management is not important for business success.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A key objective of supply chain management is to ensure the efficient flow of materials, information, and products through the supply chain, minimizing costs and meeting customer demands."
    })
  },
  {
    id: "G11-BS-OM-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Operations Management",
    subtopic: "Inventory Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Inventory management involves controlling the quantity, location, and movement of stock to ensure adequate supply while minimizing costs. Which of the following is a cost associated with holding inventory?,
      options: [
        "Holding costs include the costs of storage, insurance, spoilage, obsolescence, and the opportunity cost of capital tied up in inventory.,
        Holding costs only include the purchase price of items.",
        "Holding costs are the same for all businesses.,
        Holding costs decrease as inventory increases."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Holding costs include the costs of storage, insurance, spoilage, obsolescence, and the opportunity cost of capital tied up in inventory.
    })
  },
  {
    id: G11-BS-OM-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Operations Management,
    subtopic: "Logistics",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Logistics involves the planning, implementation, and control of the efficient flow and storage of goods and services. Which of the following is a component of logistics management?,
      options: [
        Logistics management includes transportation management, warehousing, distribution, order fulfillment, and the management of information flows throughout the supply chain.,
        Logistics only focuses on transportation.,
        Logistics is not important for businesses.",
        "Logistics only involves shipping products.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Logistics management includes transportation management, warehousing, distribution, order fulfillment, and the management of information flows throughout the supply chain."
    })
  },
  {
    id: "G11-BS-OM-04",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Operations Management",
    subtopic: "Quality Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Quality management ensures products and services meet customer expectations. Which of the following is a quality management standard that provides a framework for quality management systems?,
      options: [
        ISO 9001 is an international quality management standard that provides a framework for businesses to establish and maintain effective quality management systems.,
        ISO 14001 is a quality management standard.,
        "Six Sigma is a quality management standard.,
        TQM is a quality management standard."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "ISO 9001 is an international quality management standard that provides a framework for businesses to establish and maintain effective quality management systems.
    })
  },

  // --- ENTREPRENEURSHIP AND INNOVATION (3 Materials) ---
  {
    id: G11-BS-EI-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Entrepreneurship and Innovation,
    subtopic: "Innovation",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Innovation is the process of creating new ideas, products, or processes that bring value. Which of the following is a type of innovation that involves significant changes in how a business operates or the products it offers?,
      options: [
        Radical innovation involves significant changes that create new markets or fundamentally transform existing industries, often through breakthrough technologies or business models.,
        Incremental innovation involves significant changes.,
        Disruptive innovation is always radical.",
        "All innovations are radical.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Radical innovation involves significant changes that create new markets or fundamentally transform existing industries, often through breakthrough technologies or business models."
    })
  },
  {
    id: "G11-BS-EI-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Entrepreneurship and Innovation",
    subtopic: "Creativity,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Creativity is the ability to generate new and useful ideas. Which of the following techniques can be used to enhance creativity in a business setting?,
      options: [
        Brainstorming is a technique that encourages the free generation of ideas in a group setting, promoting creativity and producing a wide range of potential solutions to business challenges.,
        Brainstorming is used only for solving financial problems.,
        "Brainstorming is not effective for business creativity.,
        Brainstorming is a structured analysis method."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Brainstorming is a technique that encourages the free generation of ideas in a group setting, promoting creativity and producing a wide range of potential solutions to business challenges.
    })
  },
  {
    id: G11-BS-EI-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Entrepreneurship and Innovation,
    subtopic: "Business Growth",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Business growth is a key objective for many entrepreneurs. Which of the following is a strategy for business growth that involves expanding into new markets with existing products?,
      options: [
        Market development is a growth strategy that involves entering new markets (new geographic areas or new customer segments) with existing products to increase sales and market reach.,
        Market penetration involves entering new markets with new products.,
        Diversification involves expanding into new markets with existing products.",
        "Product development involves expanding into new markets with existing products.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Market development is a growth strategy that involves entering new markets (new geographic areas or new customer segments) with existing products to increase sales and market reach."
    })
  },

  // --- RISK MANAGEMENT (3 Materials) ---
  {
    id: "G11-BS-RM-01",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Risk Management",
    subtopic: "Types of Risk,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Businesses face various risks that can affect their operations and profitability. Which of the following is a financial risk that a business might face?,
      options: [
        Financial risks include the risk of loss due to changes in interest rates, exchange rates, credit defaults, or inadequate cash flow that affects the business's financial stability and performance.,
        Financial risks include only market competition.,
        "Financial risks are not relevant to most businesses.,
        Financial risks include natural disasters."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Financial risks include the risk of loss due to changes in interest rates, exchange rates, credit defaults, or inadequate cash flow that affects the business's financial stability and performance.
    })
  },
  {
    id: G11-BS-RM-02",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "Risk Management,
    subtopic: "Insurance",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Insurance is a risk transfer mechanism that protects businesses from financial losses. Which of the following types of insurance protects a business against liability claims resulting from injuries to customers or damage to their property?,
      options: [
        Public liability insurance protects businesses against claims from third parties (customers, visitors) for injuries or property damage arising from the business's operations.,
        Public liability insurance covers employee injuries.,
        Public liability insurance covers product defects.",
        "Public liability insurance covers property damage only.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Public liability insurance protects businesses against claims from third parties (customers, visitors) for injuries or property damage arising from the business's operations."
    })
  },
  {
    id: "G11-BS-RM-03",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "Risk Management",
    subtopic: "Risk Mitigation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Risk mitigation involves actions taken to reduce the likelihood or impact of risks. Which of the following is a risk mitigation strategy that reduces the probability of a risk occurring?,
      options: [
        Risk reduction involves implementing measures to reduce the likelihood of a risk occurring, such as improving safety procedures, implementing controls, or investing in security and quality systems.,
        Risk transfer is a risk mitigation strategy that reduces risk probability.,
        "Risk acceptance is a risk mitigation strategy that reduces risk probability.,
        Risk avoidance is the only risk mitigation strategy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Risk reduction involves implementing measures to reduce the likelihood of a risk occurring, such as improving safety procedures, implementing controls, or investing in security and quality systems.
    })
  },

  // --- INTERNATIONAL TRADE (3 Materials) ---
  {
    id: G11-BS-IT-01",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "International Trade,
    subtopic: "Import",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " International trade involves the exchange of goods and services across national borders. Which of the following is an advantage of importing goods for a business?,
      options: [
        Importing allows businesses to access products not available locally, take advantage of lower production costs in other countries, and offer a wider range of products to customers.,
        Importing is always more expensive than producing locally.,
        Importing does not offer any advantages to businesses.",
        "Importing reduces product variety.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Importing allows businesses to access products not available locally, take advantage of lower production costs in other countries, and offer a wider range of products to customers."
    })
  },
  {
    id: "G11-BS-IT-02",
    grade: "Grade 11",
    subject: "Business Studies",
    topic: "International Trade",
    subtopic: "Export,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Exporting involves selling goods and services to other countries. Which of the following is a challenge of exporting for businesses in Kenya?,
      options: [
        Challenges of exporting include navigating complex trade regulations and customs procedures, complying with international standards, managing logistics and shipping, and handling currency exchange risks.,
        Exporting has no challenges for businesses in Kenya.,
        "Exporting is always easy and straightforward.,
        Regulations are not a barrier to exporting."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Challenges of exporting include navigating complex trade regulations and customs procedures, complying with international standards, managing logistics and shipping, and handling currency exchange risks.
    })
  },
  {
    id: G11-BS-IT-03",
    grade: "Grade 11,
    subject: Business Studies",
    topic: "International Trade,
    subtopic: "Global Business",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Global business refers to the interconnected nature of modern economies and the conduct of business across borders. Which of the following is a benefit of globalization for businesses?,
      options: [
        Globalization provides businesses with access to larger markets, lower production costs, a wider talent pool, and the ability to source inputs from the most competitive suppliers worldwide.,
        Globalization only benefits large multinational corporations.,
        Globalization has no benefits for small businesses.",
        "Globalization reduces market access for businesses.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Globalization provides businesses with access to larger markets, lower production costs, a wider talent pool, and the ability to source inputs from the most competitive suppliers worldwide."
    })
  }`nexport const businessStudiesTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD BUSINESS STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: BUSINESS ENVIRONMENT (PESTLE) (4 Materials) ---
  {
    id: "G12-BUS-ENV-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Environment",
    subtopic: "PESTLE Analysis: Political Factors,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The business environment is influenced by various external factors, commonly analyzed using the PESTLE framework. Which of the following is a political factor that can affect a business?,
      options: [Changes in government policy and taxation, Changes in technology", "Changes in consumer preferences, Changes in interest rates"].sort(() => Math.random() - 0.5),
      correctAnswer: "Changes in government policy and taxation
    })
  },
  {
    id: G12-BUS-ENV-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Environment,
    subtopic: "PESTLE Analysis: Economic Factors",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Economic factors play a crucial role in shaping the business environment. Which of the following is an economic factor that affects business operations?,
      options: [Inflation rates and unemployment levels, New laws and regulations, Cultural trends", "Weather conditions].sort(() => Math.random() - 0.5),
      correctAnswer: Inflation rates and unemployment levels"
    })
  },
  {
    id: "G12-BUS-ENV-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Environment",
    subtopic: "PESTLE Analysis: Social Factors,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Social factors influence what products consumers buy and how they behave. Which of the following is a social factor impacting businesses today?,
      options: [Changing lifestyles and population demographics, New government laws, "Technological innovation, Economic recession"].sort(() => Math.random() - 0.5),
      correctAnswer: "Changing lifestyles and population demographics
    })
  },
  {
    id: G12-BUS-ENV-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Environment,
    subtopic: "PESTLE Analysis: Technological Factors",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Technology is rapidly changing the way businesses operate. What is a major technological factor that affects modern businesses?,
      options: [Advances in artificial intelligence and automation, Changes in consumer income, New labor laws", "Shift in political power].sort(() => Math.random() - 0.5),
      correctAnswer: Advances in artificial intelligence and automation"
    })
  },

  // --- MADA: BUSINESS STRATEGY (4 Materials) ---
  {
    id: "G12-BUS-STR-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Strategy",
    subtopic: "Strategic Planning: Vision and Mission,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A business strategy begins with a clear vision and mission statement. What is the main purpose of a mission statement?,
      options: [To define the organization's purpose and primary objectives., To list all the products the company sells., "To describe the building location., To hire new employees."].sort(() => Math.random() - 0.5),
      correctAnswer: "To define the organization's purpose and primary objectives.
    })
  },
  {
    id: G12-BUS-STR-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Strategy,
    subtopic: "Strategic Planning: SWOT Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " SWOT analysis is a key strategic tool used by businesses. What does the 'SW' in SWOT stand for?,
      options: [Strengths and Weaknesses, Strategies and Work, Sales and Wages", "System and Workflow].sort(() => Math.random() - 0.5),
      correctAnswer: Strengths and Weaknesses"
    })
  },
  {
    id: "G12-BUS-STR-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Strategy",
    subtopic: "Strategic Planning: SWOT Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The 'OT' in a SWOT analysis focuses on the external environment. What do the 'O' and 'T' stand for?,
      options: [Opportunities and Threats, Operations and Tasks, "Orders and Targets, Output and Turnover"].sort(() => Math.random() - 0.5),
      correctAnswer: "Opportunities and Threats
    })
  },
  {
    id: G12-BUS-STR-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Strategy,
    subtopic: "Strategic Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Once a business analyzes its internal strengths and weaknesses and external opportunities and threats, what is the next step in strategic planning?,
      options: [Set strategic goals and formulate action plans., Change the business logo., Hire more staff.", "Open new branches immediately.].sort(() => Math.random() - 0.5),
      correctAnswer: Set strategic goals and formulate action plans."
    })
  },

  // --- MADA: BUSINESS GROWTH & EXPANSION (4 Materials) ---
  {
    id: "G12-BUS-GRW-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Growth and Expansion",
    subtopic: "Mergers and Acquisitions,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mergers and acquisitions are common strategies for business growth. What is the difference between a merger and an acquisition?,
      options: [A merger combines two companies into one, while an acquisition is when one company buys another., They are exactly the same., "An acquisition combines two companies, while a merger is a takeover., A merger is a hostile takeover, while an acquisition is friendly."].sort(() => Math.random() - 0.5),
      correctAnswer: "A merger combines two companies into one, while an acquisition is when one company buys another.
    })
  },
  {
    id: G12-BUS-GRW-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Growth and Expansion,
    subtopic: "Takeovers",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A hostile takeover occurs when one company attempts to buy another company against the wishes of the target company's management. How can a company defend itself against a hostile takeover?,
      options: [By implementing a 'poison pill' strategy or seeking a 'white knight' partner., By selling all assets., By closing the business.", "By reducing its share price.].sort(() => Math.random() - 0.5),
      correctAnswer: By implementing a 'poison pill' strategy or seeking a 'white knight' partner."
    })
  },
  {
    id: "G12-BUS-GRW-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Growth and Expansion",
    subtopic: "Franchising,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Franchising is a popular way for businesses to expand rapidly. In a franchising agreement, who is the 'franchisor'?,
      options: [The owner of the original business who grants the right to use their brand., The person who buys the franchise and runs the local outlet.", "The government official., The customer."].sort(() => Math.random() - 0.5),
      correctAnswer: "The owner of the original business who grants the right to use their brand.
    })
  },
  {
    id: G12-BUS-GRW-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Growth and Expansion,
    subtopic: "Franchising",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Franchising offers both benefits and challenges. What is one major benefit of franchising for the franchisee?,
      options: [Access to a proven business model and established brand., Complete freedom to run the business any way they like., No ongoing fees to pay.", "They own the entire business legally.].sort(() => Math.random() - 0.5),
      correctAnswer: Access to a proven business model and established brand."
    })
  },

  // --- MADA: HUMAN RESOURCE MANAGEMENT (4 Materials) ---
  {
    id: "G12-BUS-HRM-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Recruitment and Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Human Resource Management (HRM) involves managing the people within an organization. What is the first step in the recruitment and selection process?,
      options: [Job analysis and creating a job description., Interviewing candidates., "Offering the job to the best candidate., Training the new employee."].sort(() => Math.random() - 0.5),
      correctAnswer: "Job analysis and creating a job description.
    })
  },
  {
    id: G12-BUS-HRM-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Training and Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Once new employees are hired, they need to be trained. What is the difference between 'on-the-job' and 'off-the-job' training?,
      options: [On-the-job training happens at the workplace, while off-the-job training happens away from the workplace., They are the same., On-the-job training is for managers only.", "Off-the-job training is for unskilled workers only.].sort(() => Math.random() - 0.5),
      correctAnswer: On-the-job training happens at the workplace, while off-the-job training happens away from the workplace."
    })
  },
  {
    id: "G12-BUS-HRM-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Human Resource Management",
    subtopic: "Motivation,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Motivating employees is essential for a productive workforce. According to Maslow's Hierarchy of Needs, which need must be satisfied first?,
      options: [Physiological needs (food, water, shelter)., Safety needs.", "Social needs., Self-actualization."].sort(() => Math.random() - 0.5),
      correctAnswer: "Physiological needs (food, water, shelter).
    })
  },
  {
    id: G12-BUS-HRM-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Human Resource Management,
    subtopic: "Performance Appraisal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Performance appraisal is a formal system used to evaluate employees' work performance. Why is performance appraisal important for a business?,
      options: [It provides feedback, identifies training needs, and helps determine promotions and pay raises., It is used to fire employees., It is only used to reduce salaries.", "It is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: It provides feedback, identifies training needs, and helps determine promotions and pay raises."
    })
  },

  // --- MADA: FINANCIAL MANAGEMENT (4 Materials) ---
  {
    id: "G12-BUS-FIN-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Financial Management",
    subtopic: "Capital Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Capital budgeting is the process a business uses to evaluate potential major investments or projects. What is the Payback Period method in capital budgeting?,
      options: [It calculates the time it takes to recover the initial investment., It calculates total profit over the project's life., "It calculates the annual interest rate., It calculates the future value of an asset."].sort(() => Math.random() - 0.5),
      correctAnswer: "It calculates the time it takes to recover the initial investment.
    })
  },
  {
    id: G12-BUS-FIN-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Financial Management,
    subtopic: "Working Capital Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Working capital management is crucial for the day-to-day operations of a business. What is the formula for calculating working capital?,
      options: [Current Assets minus Current Liabilities., Total Assets minus Total Liabilities., Revenue minus Costs.", "Cash minus Debt.].sort(() => Math.random() - 0.5),
      correctAnswer: Current Assets minus Current Liabilities."
    })
  },
  {
    id: "G12-BUS-FIN-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Financial Management",
    subtopic: "Financial Ratios,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Financial ratios are used to analyze a company's financial health. What does the Current Ratio measure?,
      options: [It measures the company's ability to pay short-term debts., It measures profitability., "It measures the company's long-term debt levels., It measures the company's market share."].sort(() => Math.random() - 0.5),
      correctAnswer: "It measures the company's ability to pay short-term debts.
    })
  },
  {
    id: G12-BUS-FIN-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Financial Management,
    subtopic: "Financial Ratios",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Profitability ratios measure a company's ability to generate profit. Which of the following is a profitability ratio?,
      options: [Net Profit Margin, Current Ratio, Quick Ratio", "Debt-to-Equity Ratio].sort(() => Math.random() - 0.5),
      correctAnswer: Net Profit Margin"
    })
  },

  // --- MADA: MARKETING MANAGEMENT (4 Materials) ---
  {
    id: "G12-BUS-MKT-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Marketing Management",
    subtopic: "The Marketing Mix (7Ps),
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The marketing mix is a set of tools used by businesses to achieve their marketing objectives. The original 4Ps were Product, Price, Place, and Promotion. What are the three additional Ps in the extended 7Ps framework?,
      options: ["People, Process, and Physical Evidence., People, Power, and Profit.", "Pricing, Packaging, and Positioning., Productivity, Planning, and Performance."].sort(() => Math.random() - 0.5),
      correctAnswer: "People, Process, and Physical Evidence.
    })
  },
  {
    id: G12-BUS-MKT-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Marketing Management,
    subtopic: "Market Segmentation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Market segmentation involves dividing a broad target market into smaller, more defined groups. Which of the following is a basis for market segmentation?,
      options: [Demographic, geographic, psychographic, and behavioral., Price and promotion., Product and place.", "Only geographic.].sort(() => Math.random() - 0.5),
      correctAnswer: Demographic, geographic, psychographic, and behavioral."
    })
  },
  {
    id: "G12-BUS-MKT-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Marketing Management",
    subtopic: "Targeting and Positioning,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "After identifying market segments, a business must select which segments to target. What is the 'target market'?,
      options: [A group of customers with shared characteristics that a business aims to serve., The entire population.", "Only the high-income earners., Only the elderly."].sort(() => Math.random() - 0.5),
      correctAnswer: "A group of customers with shared characteristics that a business aims to serve.
    })
  },
  {
    id: G12-BUS-MKT-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Marketing Management,
    subtopic: "Targeting and Positioning",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Once a target market is selected, a business needs to position its product in the market. What is 'market positioning'?,
      options: [The process of creating a distinct image and identity for a product in the minds of consumers., The process of setting the product's price., The process of distributing the product.", "The process of building the product.].sort(() => Math.random() - 0.5),
      correctAnswer: The process of creating a distinct image and identity for a product in the minds of consumers."
    })
  },

  // --- MADA: PRODUCTION AND OPERATIONS (4 Materials) ---
  {
    id: "G12-BUS-PRO-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Production and Operations",
    subtopic: "Quality Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Quality control is an essential part of production management. What is the primary goal of quality control in a manufacturing process?,
      options: [To ensure that products meet specific standards and are free from defects., To increase production costs., "To slow down production., To create more waste."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure that products meet specific standards and are free from defects.
    })
  },
  {
    id: G12-BUS-PRO-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Production and Operations,
    subtopic: "Lean Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Lean production is a philosophy that aims to reduce waste and maximize value in the production process. What is 'Kaizen' in lean production?,
      options: [The continuous improvement of processes., The rapid increase of inventory., The elimination of all employees.", "The building of new factories.].sort(() => Math.random() - 0.5),
      correctAnswer: The continuous improvement of processes."
    })
  },
  {
    id: "G12-BUS-PRO-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Production and Operations",
    subtopic: "Just-In-Time (JIT),
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Just-In-Time (JIT) is an inventory management strategy that aligns raw-material orders from suppliers directly with production schedules. What is one major advantage of JIT?,
      options: [It reduces the cost of holding excess inventory., It increases the amount of inventory on hand., "It requires more storage space., It slows down production."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reduces the cost of holding excess inventory.
    })
  },
  {
    id: G12-BUS-PRO-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Production and Operations,
    subtopic: "Production Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Businesses can choose from different production methods depending on the product and scale. What is 'mass production'?,
      options: [The production of large quantities of a standardized product using an assembly line., The production of a unique, one-off product., The production of a small batch of customised products.", "The production of perishable goods.].sort(() => Math.random() - 0.5),
      correctAnswer: The production of large quantities of a standardized product using an assembly line."
    })
  },

  // --- MADA: INTERNATIONAL BUSINESS (4 Materials) ---
  {
    id: "G12-BUS-INT-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "International Business",
    subtopic: "Global Trade,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "International business involves the exchange of goods and services across borders. What is the difference between exports and imports?,
      options: [Exports are goods sold to other countries; imports are goods bought from other countries., They are the same., "Exports are goods bought from other countries; imports are goods sold to other countries., Exports are services; imports are goods."].sort(() => Math.random() - 0.5),
      correctAnswer: "Exports are goods sold to other countries; imports are goods bought from other countries.
    })
  },
  {
    id: G12-BUS-INT-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "International Business,
    subtopic: "Balance of Payments",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The Balance of Payments (BOP) is a record of all economic transactions between a country and the rest of the world. What does a trade surplus indicate?,
      options: [The value of exports exceeds the value of imports., The value of imports exceeds the value of exports., The country is not trading.", "The country has no exports.].sort(() => Math.random() - 0.5),
      correctAnswer: The value of exports exceeds the value of imports."
    })
  },
  {
    id: "G12-BUS-INT-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "International Business",
    subtopic: "Exchange Rates,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Exchange rates are the price of one currency in terms of another. How would a weaker Kenyan Shilling affect Kenyan exports?,
      options: [It makes Kenyan goods cheaper for foreign buyers., It makes Kenyan goods more expensive., "It has no effect., It stops all exports."].sort(() => Math.random() - 0.5),
      correctAnswer: "It makes Kenyan goods cheaper for foreign buyers.
    })
  },
  {
    id: G12-BUS-INT-04",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "International Business,
    subtopic: "Trade Blocs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Trade blocs are agreements between countries to reduce trade barriers. What is one benefit of Kenya joining a trade bloc like the EAC?,
      options: [Access to a wider market and reduced tariffs., Loss of sovereignty., Increased trade barriers.", "Higher taxes.].sort(() => Math.random() - 0.5),
      correctAnswer: Access to a wider market and reduced tariffs."
    })
  },

  // --- MADA: BUSINESS ETHICS AND CSR (3 Materials) ---
  {
    id: "G12-BUS-ETH-01",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Ethics and Social Responsibility",
    subtopic: "Corporate Social Responsibility (CSR),
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Corporate Social Responsibility (CSR) is a concept where businesses voluntarily take actions to benefit society. What is an example of a CSR initiative?,
      options: [A company donating to local charities and reducing its environmental impact., A company increasing its prices., "A company building a new factory., A company focusing only on profits."].sort(() => Math.random() - 0.5),
      correctAnswer: "A company donating to local charities and reducing its environmental impact.
    })
  },
  {
    id: G12-BUS-ETH-02",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Business Ethics and Social Responsibility,
    subtopic: "Ethical Business Practices",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Ethical business practices are essential for long-term success and reputation. What is one unethical practice that some businesses engage in?,
      options: [Misleading advertising and false claims., Providing excellent customer service., Paying fair wages.", "Using sustainable materials.].sort(() => Math.random() - 0.5),
      correctAnswer: Misleading advertising and false claims."
    })
  },
  {
    id: "G12-BUS-ETH-03",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Business Ethics and Social Responsibility",
    subtopic: "Ethical Business Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A business that prioritizes ethical behavior is likely to build trust with its customers and employees. What is a key benefit of acting ethically as a business?,
      options: [It builds long-term customer loyalty and brand reputation., It reduces profits., "It increases legal trouble., It lowers employee morale."].sort(() => Math.random() - 0.5),
      correctAnswer: "It builds long-term customer loyalty and brand reputation.
    })
  },

  // --- MADA: ENTREPRENEURSHIP (4 Materials) ---
  {
    id: G12-BUS-ENT-01",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Entrepreneurship,
    subtopic: "Innovation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Entrepreneurship is the process of starting and running a new business. What is the role of innovation in entrepreneurship?,
      options: [It involves introducing new ideas, products, or methods to solve problems and create value., It is the same as copying existing businesses., It is not important.", "It only applies to technology companies.].sort(() => Math.random() - 0.5),
      correctAnswer: It involves introducing new ideas, products, or methods to solve problems and create value."
    })
  },
  {
    id: "G12-BUS-ENT-02",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Entrepreneurship",
    subtopic: "Risk Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Starting a business involves taking risks. What is 'risk management' in the context of entrepreneurship?,
      options: [Identifying potential risks and taking steps to minimize their impact., Taking the biggest risks possible., "Ignoring all risks., Only taking risks that are guaranteed to succeed."].sort(() => Math.random() - 0.5),
      correctAnswer: "Identifying potential risks and taking steps to minimize their impact.
    })
  },
  {
    id: G12-BUS-ENT-03",
    grade: "Grade 12,
    subject: Business Studies",
    topic: "Entrepreneurship,
    subtopic: "Business Plans",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A business plan is a formal document that outlines a business's goals and how it intends to achieve them. What is a key component of a business plan?,
      options: [A financial forecast and marketing strategy., The business owner's personal biography., A list of all competitors.", "The history of the industry.].sort(() => Math.random() - 0.5),
      correctAnswer: A financial forecast and marketing strategy."
    })
  },
  {
    id: "G12-BUS-ENT-04",
    grade: "Grade 12",
    subject: "Business Studies",
    topic: "Entrepreneurship",
    subtopic: "Sources of Business Finance,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Entrepreneurs need finance to start and grow their businesses. What is the difference between equity finance and debt finance?,
      options: [Equity finance involves selling shares, while debt finance involves borrowing money., They are the same., "Equity finance is borrowing money, while debt finance is selling shares., Equity finance is only for large companies."].sort(() => Math.random() - 0.5),
      correctAnswer: "Equity finance involves selling shares, while debt finance involves borrowing money."
    })
  }

];


