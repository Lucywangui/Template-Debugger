export const integratedScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD INTEGRATED SCIENCE SYLLABUS)
  // =========================================================================

  // --- SCIENTIFIC INVESTIGATION (4 Materials) ---
  {
    id: "G7-IS-SI-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Scientific Method",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "The scientific method is a systematic approach used by scientists to investigate phenomena and acquire new knowledge. Which of the following correctly lists the steps of the scientific method in their proper sequence?,
      options: [
        Observation, Question, Hypothesis, Experiment, Analysis, Conclusion.,
        Hypothesis, Observation, Question, Experiment, Conclusion, Analysis.,
        "Experiment, Observation, Conclusion, Question, Hypothesis, Analysis.,
        Question, Conclusion, Hypothesis, Observation, Analysis, Experiment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Observation, Question, Hypothesis, Experiment, Analysis, Conclusion.
    })
  },
  {
    id: G7-IS-SI-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Laboratory Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Laboratory safety rules are essential to prevent accidents and injuries during scientific experiments. Which of the following is the most important safety practice to follow when handling chemicals in a science laboratory?,
      options: [
        Always wear appropriate protective equipment such as safety goggles, gloves, and a laboratory coat when handling chemicals.,
        Taste small amounts of chemicals to identify them.,
        Use chemicals without reading the labels first.",
        "Leave chemical containers open when not in use.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Always wear appropriate protective equipment such as safety goggles, gloves, and a laboratory coat when handling chemicals."
    })
  },
  {
    id: "G7-IS-SI-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Variables in Experiments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In scientific experiments, variables are factors that can change or be manipulated. What is the term used to describe the variable that is intentionally changed by the experimenter to observe its effect on another variable?,
      options: [
        Independent variable, which is deliberately manipulated by the researcher.,
        Dependent variable, which is measured as the outcome of the experiment.",
        "Control variable, which is kept constant throughout the experiment.,
        Extraneous variable, which may affect the results but is not being studied."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Independent variable, which is deliberately manipulated by the researcher.
    })
  },
  {
    id: G7-IS-SI-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Data Collection and Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Collecting and analyzing data accurately is crucial for drawing valid conclusions from scientific experiments. Which of the following is the most appropriate way to present quantitative data collected from an experiment to show trends and patterns clearly?,
      options: [
        Plotting data on a line graph or bar chart with appropriate labels and scales.,
        Listing all data points in a paragraph without any visual representation.,
        Using only photographs without any numerical analysis.",
        "Storing data in a notebook without any analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plotting data on a line graph or bar chart with appropriate labels and scales."
    })
  },

  // --- CELLS AND MICROSCOPY (4 Materials) ---
  {
    id: "G7-IS-CM-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Cells and Microscopy",
    subtopic: "Cell Structure and Function,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Cells are the basic structural and functional units of all living organisms. Which of the following correctly describes the primary function of the mitochondria in a eukaryotic cell?,
      options: [
        Mitochondria are the powerhouses of the cell where cellular respiration occurs to produce energy (ATP) for the cell's activities.,
        Mitochondria are responsible for protein synthesis in the cell.,
        "Mitochondria store genetic material and control cellular activities.,
        Mitochondria are involved in photosynthesis in plant cells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mitochondria are the powerhouses of the cell where cellular respiration occurs to produce energy (ATP) for the cell's activities.
    })
  },
  {
    id: G7-IS-CM-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Cells and Microscopy,
    subtopic: "Plant vs. Animal Cells",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Plant and animal cells share many common structures but also have distinct differences. Which of the following organelles is found in plant cells but not in animal cells?,
      options: [
        Chloroplasts, which contain chlorophyll and are the site of photosynthesis.,
        Mitochondria, which are responsible for cellular respiration.,
        Nucleus, which controls cell activities.",
        "Ribosomes, which synthesize proteins.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chloroplasts, which contain chlorophyll and are the site of photosynthesis."
    })
  },
  {
    id: "G7-IS-CM-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Cells and Microscopy",
    subtopic: "Microscope Use,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The microscope is an essential tool in biology that allows scientists to view objects that are too small to be seen with the naked eye. When using a compound light microscope, what is the correct procedure for focusing on a specimen?,
      options: [
        Start with the lowest power objective lens, use the coarse adjustment to bring the image into focus, then fine-tune with the fine adjustment knob.,
        Start immediately with the highest power objective lens to get a detailed view.",
        "Use only the fine adjustment knob without using the coarse adjustment at all.,
        Move the microscope constantly while viewing the specimen."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Start with the lowest power objective lens, use the coarse adjustment to bring the image into focus, then fine-tune with the fine adjustment knob.
    })
  },
  {
    id: G7-IS-CM-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Cells and Microscopy,
    subtopic: "Specialized Cells",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Specialized cells have unique structures that enable them to perform specific functions in multicellular organisms. Which of the following describes the adaptation of red blood cells that allows them to efficiently transport oxygen?,
      options: [
        Red blood cells have a biconcave shape that increases surface area for oxygen uptake and lack a nucleus to carry more hemoglobin.,
        Red blood cells have a long tail-like structure for movement through blood vessels.,
        Red blood cells contain large chloroplasts for energy production.",
        "Red blood cells have a thick cell wall for protection.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Red blood cells have a biconcave shape that increases surface area for oxygen uptake and lack a nucleus to carry more hemoglobin."
    })
  },

  // --- NUTRITION IN PLANTS AND ANIMALS (4 Materials) ---
  {
    id: "G7-IS-NP-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Nutrition in Plants and Animals",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Photosynthesis is the process by which green plants manufacture their own food using energy from sunlight. Which of the following is the correct chemical equation for photosynthesis?,
      options: [
        6CO₂ + 6H₂O + Light Energy → C₆H₁₂O₆ + 6O₂,
        C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + Energy,
        "6CO₂ + 6H₂O + Energy → 6O₂ + C₆H₁₂O₆,
        CO₂ + H₂O + Light → C₆H₁₂O₆ + O₂"
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "6CO₂ + 6H₂O + Light Energy → C₆H₁₂O₆ + 6O₂
    })
  },
  {
    id: G7-IS-NP-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Nutrition in Plants and Animals,
    subtopic: "Nutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Nutrients are essential substances that organisms need for growth, energy, and maintenance of health. Which of the following is the main function of carbohydrates in the human diet?,
      options: [
        Carbohydrates are the body's primary source of energy, providing fuel for physical activities and vital body functions.,
        Carbohydrates are responsible for building and repairing body tissues.,
        Carbohydrates regulate body processes and maintain healthy immune function.",
        "Carbohydrates are stored as fat for long-term energy reserves.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates are the body's primary source of energy, providing fuel for physical activities and vital body functions."
    })
  },
  {
    id: "G7-IS-NP-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Nutrition in Plants and Animals",
    subtopic: "The Digestive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The human digestive system breaks down food into simpler substances that can be absorbed and used by the body. In which part of the digestive system is most of the absorption of nutrients from digested food carried out?,
      options: [
        The small intestine, which has villi that increase surface area for efficient absorption of nutrients.,
        The stomach, where food is churned and mixed with gastric juices.,
        "The large intestine, which absorbs water and forms feces.,
        The mouth, where mechanical digestion begins with chewing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The small intestine, which has villi that increase surface area for efficient absorption of nutrients.
    })
  },
  {
    id: G7-IS-NP-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Nutrition in Plants and Animals,
    subtopic: "Balanced Diet",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A balanced diet is essential for maintaining good health and preventing nutrient deficiency diseases. What does a balanced diet include?,
      options: [
        A variety of foods from all food groups in the correct proportions to provide adequate energy, protein, vitamins, minerals, and water.,
        Only proteins and carbohydrates without any fats or vitamins.,
        Only fruits and vegetables without any proteins or carbohydrates.",
        "Large amounts of sugar and fat without other nutrients.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A variety of foods from all food groups in the correct proportions to provide adequate energy, protein, vitamins, minerals, and water."
    })
  },

  // --- TRANSPORT SYSTEMS (3 Materials) ---
  {
    id: "G7-IS-TS-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Transport Systems",
    subtopic: "Circulatory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The circulatory system is responsible for transporting substances such as oxygen, nutrients, and hormones throughout the body. Which of the following describes the role of arteries in the human circulatory system?,
      options: [
        "Arteries carry oxygenated blood away from the heart to the body tissues, except for the pulmonary artery which carries deoxygenated blood to the lungs.,
        Arteries carry deoxygenated blood from the body back to the heart.",
        "Arteries are the sites of exchange of substances between the blood and body tissues.,
        Arteries collect blood from the body tissues and return it to the heart."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Arteries carry oxygenated blood away from the heart to the body tissues, except for the pulmonary artery which carries deoxygenated blood to the lungs.
    })
  },
  {
    id: G7-IS-TS-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Transport Systems,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Plants have transport systems that move water, minerals, and food substances throughout the plant body. Which tissue is responsible for the transport of water and dissolved minerals from the roots to the leaves in vascular plants?,
      options: [
        Xylem, which consists of dead cells forming tubes that transport water and minerals upwards due to transpiration pull.,
        Phloem, which transports sugars and other organic substances from the leaves to other parts of the plant.,
        Epidermis, which provides protection for the plant.",
        "Cambium, which is responsible for secondary growth in plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Xylem, which consists of dead cells forming tubes that transport water and minerals upwards due to transpiration pull."
    })
  },
  {
    id: "G7-IS-TS-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Transport Systems",
    subtopic: "Blood Composition,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Blood is a connective tissue that plays a vital role in transporting substances and defending the body against infections. Which of the following is the primary function of plasma in the blood?,
      options: [
        Plasma is the liquid component of blood that transports dissolved nutrients, hormones, and waste products throughout the body.,
        Plasma is responsible for carrying oxygen from the lungs to body tissues.,
        "Plasma produces antibodies to fight infections.,
        Plasma forms clots to prevent bleeding from wounds."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Plasma is the liquid component of blood that transports dissolved nutrients, hormones, and waste products throughout the body.
    })
  },

  // --- RESPIRATION AND HOMEOSTASIS (3 Materials) ---
  {
    id: G7-IS-RH-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Respiration and Homeostasis,
    subtopic: "Respiration",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Respiration is the process by which living organisms obtain energy from food molecules. What is the difference between aerobic respiration and anaerobic respiration in terms of oxygen requirements and energy production?,
      options: [
        Aerobic respiration requires oxygen and produces more energy (ATP) per glucose molecule, while anaerobic respiration occurs without oxygen and produces less energy.,
        Aerobic respiration occurs without oxygen and produces more energy, while anaerobic respiration requires oxygen.,
        Both aerobic and anaerobic respiration require oxygen but produce the same amount of energy.",
        "Neither aerobic nor anaerobic respiration involves energy production from glucose.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Aerobic respiration requires oxygen and produces more energy (ATP) per glucose molecule, while anaerobic respiration occurs without oxygen and produces less energy."
    })
  },
  {
    id: "G7-IS-RH-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Respiration and Homeostasis",
    subtopic: "Gas Exchange,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Gas exchange is the process by which organisms exchange oxygen and carbon dioxide with their environment. In humans, where does the exchange of gases between the air and the bloodstream primarily occur?,
      options: [
        In the alveoli of the lungs, where oxygen diffuses into the blood and carbon dioxide diffuses out of the blood.,
        In the trachea, where air is filtered and warmed.",
        "In the bronchi, which branch from the trachea.,
        In the bronchioles, which are small passages in the lungs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In the alveoli of the lungs, where oxygen diffuses into the blood and carbon dioxide diffuses out of the blood.
    })
  },
  {
    id: G7-IS-RH-03",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Respiration and Homeostasis,
    subtopic: "Homeostasis",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Homeostasis is the maintenance of a stable internal environment in living organisms despite changes in the external environment. Which of the following is an example of a homeostatic mechanism in the human body?,
      options: [
        Thermoregulation, where the body maintains its temperature within a narrow range through processes such as sweating and shivering.,
        The digestive process that breaks down food into nutrients.,
        The movement of the body during exercise.",
        "The growth and development of a child into an adult.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Thermoregulation, where the body maintains its temperature within a narrow range through processes such as sweating and shivering."
    })
  },

  // --- REPRODUCTION (3 Materials) ---
  {
    id: "G7-IS-REP-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Reproduction",
    subtopic: "Reproduction in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sexual reproduction in flowering plants involves the fusion of male and female gametes to produce seeds. Which of the following correctly describes the process of pollination and fertilization in a flowering plant?,
      options: [
        Pollination is the transfer of pollen from the anther to the stigma, followed by fertilization where the pollen tube grows to deliver sperm cells to the ovule.,
        Fertilization occurs before pollination in all flowering plants.,
        "Pollination is the fusion of male and female gametes.,
        Fertilization is the transfer of pollen from one flower to another."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pollination is the transfer of pollen from the anther to the stigma, followed by fertilization where the pollen tube grows to deliver sperm cells to the ovule.
    })
  },
  {
    id: G7-IS-REP-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Reproduction,
    subtopic: "Reproduction in Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Animals reproduce either sexually or asexually, with sexual reproduction involving the fusion of gametes. Which of the following is an advantage of sexual reproduction over asexual reproduction in animals?,
      options: [
        Sexual reproduction produces genetic variation in offspring, which increases the ability of a population to adapt to changing environments.,
        Sexual reproduction produces offspring that are identical to the parent.,
        Sexual reproduction requires only one parent.",
        "Sexual reproduction is faster and simpler than asexual reproduction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sexual reproduction produces genetic variation in offspring, which increases the ability of a population to adapt to changing environments."
    })
  },
  {
    id: "G7-IS-REP-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Reproduction",
    subtopic: "Human Reproductive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The human reproductive system is specialized for the production of gametes and the continuation of the species. What is the function of the testes in the male reproductive system?,
      options: [
        The testes produce sperm cells and secrete testosterone, the primary male sex hormone.,
        The testes store urine before it is excreted from the body.,
        "The testes produce eggs for reproduction.,
        The testes regulate body temperature in males."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The testes produce sperm cells and secrete testosterone, the primary male sex hormone.
    })
  },

  // --- ECOLOGY AND ENVIRONMENT (3 Materials) ---
  {
    id: G7-IS-EE-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Ecology and Environment,
    subtopic: "Ecosystems",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " An ecosystem consists of all the living organisms in an area interacting with each other and with the non-living environment. Which of the following is an example of an abiotic factor in a terrestrial ecosystem?,
      options: [
        Temperature, rainfall, sunlight, and soil composition.,
        Trees, grass, and animals in the area.,
        Microorganisms and decomposers in the soil.",
        "Predators and prey that interact in the ecosystem.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Temperature, rainfall, sunlight, and soil composition."
    })
  },
  {
    id: "G7-IS-EE-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Ecology and Environment",
    subtopic: "Food Chains and Food Webs,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "A food chain shows the flow of energy from one organism to another in an ecosystem. In a typical grassland food chain, which of the following organisms occupies the position of a primary consumer?,
      options: [
        Herbivores such as grasshoppers or cattle that feed directly on producers (plants).,
        Carnivores such as lions or eagles that feed on other animals.",
        "Decomposers such as bacteria and fungi that break down dead organisms.,
        Producers such as grasses and trees that make their own food."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Herbivores such as grasshoppers or cattle that feed directly on producers (plants).
    })
  },
  {
    id: G7-IS-EE-03",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Ecology and Environment,
    subtopic: "Environmental Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Environmental conservation involves the sustainable use and management of natural resources to protect the environment. Which of the following human activities most significantly contributes to the conservation of forest ecosystems?,
      options: [
        Tree planting, sustainable forest harvesting, and protection of forest habitats.,
        Clearing forests for agricultural expansion and settlement.,
        Cutting trees without replanting for timber production.",
        "Burning forests to create pasture for livestock.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Tree planting, sustainable forest harvesting, and protection of forest habitats."
    })
  },

  // --- MATTER AND ATOMIC STRUCTURE (3 Materials) ---
  {
    id: "G7-IS-MA-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Matter and Atomic Structure",
    subtopic: "States of Matter,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Matter exists in three main states: solid, liquid, and gas. Which of the following correctly describes the arrangement and movement of particles in a solid?,
      options: [
        "Particles are tightly packed in a fixed arrangement with limited vibration, giving solids a definite shape and volume.,
        Particles are loosely packed and can slide past each other, allowing liquids to flow and take the shape of their container.",
        "Particles are widely spaced and move freely, allowing gases to expand and fill any container.,
        Particles are completely stationary with no movement at all."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Particles are tightly packed in a fixed arrangement with limited vibration, giving solids a definite shape and volume.
    })
  },
  {
    id: G7-IS-MA-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Matter and Atomic Structure,
    subtopic: "Atomic Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Atoms are the basic building blocks of matter and consist of subatomic particles. Which of the following correctly describes the structure of an atom and the charges of its subatomic particles?,
      options: [
        An atom consists of a positively charged nucleus containing protons and neutrons, with negatively charged electrons orbiting around the nucleus.,
        An atom consists of a negatively charged nucleus with positively charged electrons orbiting around it.,
        An atom consists of a nucleus with equal numbers of protons and electrons, and neutrons that carry a negative charge.",
        "An atom has no charged particles and is completely neutral throughout.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: An atom consists of a positively charged nucleus containing protons and neutrons, with negatively charged electrons orbiting around the nucleus."
    })
  },
  {
    id: "G7-IS-MA-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Matter and Atomic Structure",
    subtopic: "Elements and Compounds,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Elements are pure substances made of only one type of atom, while compounds are substances formed when two or more elements chemically combine. Which of the following is a compound commonly found in the kitchen?,
      options: [
        Sodium chloride (NaCl), also known as table salt, which is formed from sodium and chlorine atoms.,
        Oxygen gas (O₂), which is an element made of oxygen atoms.",
        "Gold (Au), which is a pure element.,
        Copper wire (Cu), which consists of copper atoms."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sodium chloride (NaCl), also known as table salt, which is formed from sodium and chlorine atoms.
    })
  },

  // --- ACIDS, BASES, AND SALTS (2 Materials) ---
  {
    id: G7-IS-ABS-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Acids, Bases, and Salts,
    subtopic: "Properties of Acids and Bases",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Acids and bases are two classes of chemical substances with distinct properties. Which of the following is a characteristic property of an acid?,
      options: [
        Acids have a sour taste, turn blue litmus paper red, and react with metals to produce hydrogen gas.,
        Acids have a bitter taste, turn red litmus paper blue, and are slippery to touch.,
        Acids have a salty taste and react with bases to produce oxygen gas.",
        "Acids have no taste and do not react with other substances.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Acids have a sour taste, turn blue litmus paper red, and react with metals to produce hydrogen gas."
    })
  },
  {
    id: "G7-IS-ABS-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Acids", Bases, and Salts",
    subtopic: "pH Scale and Neutralization,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The pH scale is used to measure the acidity or alkalinity of a solution. What is the pH value of a neutral solution such as pure water at room temperature?,
      options: [
        pH 7, which indicates that the solution is neither acidic nor basic.,
        pH 0, which indicates a highly acidic solution.,
        "pH 14, which indicates a highly basic solution.,
        pH 3, which indicates a moderately acidic solution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "pH 7, which indicates that the solution is neither acidic nor basic.
    })
  },

  // --- FORCES AND PRESSURE (2 Materials) ---
  {
    id: G7-IS-FP-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Forces and Pressure,
    subtopic: "Types of Forces",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Forces are pushes or pulls that can cause objects to move, stop, or change direction. Which of the following correctly describes the force of gravity?,
      options: [
        Gravity is the force of attraction between objects with mass, causing objects to fall toward the center of the Earth.,
        Gravity is the force that resists the movement of objects through air.,
        Gravity is the force between two magnets.",
        "Gravity is the force that causes objects to float on water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Gravity is the force of attraction between objects with mass, causing objects to fall toward the center of the Earth."
    })
  },
  {
    id: "G7-IS-FP-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Forces and Pressure",
    subtopic: "Pressure,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pressure is the force applied per unit area. Which of the following real-world examples demonstrates how pressure is affected by the surface area over which a force is distributed?,
      options: [
        A sharp knife cuts easily because the force is concentrated over a small surface area, creating high pressure.,
        A blunt knife cuts more easily than a sharp knife because it has a larger surface area.,
        "Pressure is not affected by surface area at all.,
        A person lying on a bed creates more pressure than a person standing on one foot."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A sharp knife cuts easily because the force is concentrated over a small surface area, creating high pressure.
    })
  },

  // --- HEALTH AND DISEASE (2 Materials) ---
  {
    id: G7-IS-HD-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Pathogens and Disease Transmission",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pathogens are disease-causing microorganisms that can be transmitted through various routes. Which of the following is the most effective way to prevent the transmission of airborne diseases such as tuberculosis and COVID-19?,
      options: [
        Wearing masks, maintaining physical distance, ensuring good ventilation, and practicing cough etiquette.,
        Taking antibiotics without prescription.,
        Ignoring symptoms and continuing regular activities.",
        "Avoiding all contact with other people completely.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Wearing masks, maintaining physical distance, ensuring good ventilation, and practicing cough etiquette."
    })
  },
  {
    id: "G7-IS-HD-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Health and Disease",
    subtopic: "Immunity and Vaccination,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Vaccination is an important public health measure that helps prevent the spread of infectious diseases. How does vaccination work to protect the body against specific diseases?,
      options: [
        Vaccination introduces weakened or inactive pathogens (antigens) to stimulate the immune system to produce antibodies without causing the disease.,
        Vaccination kills all pathogens in the body immediately after administration.,
        "Vaccination replaces the need for any other health measures.,
        Vaccination has no effect on the body's immune response."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vaccination introduces weakened or inactive pathogens (antigens) to stimulate the immune system to produce antibodies without causing the disease.
    })
  },

  // --- ELECTRICITY (2 Materials) ---
  {
    id: G7-IS-EL-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Electricity,
    subtopic: "Electric Circuits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " An electric circuit is a complete path through which electricity can flow. Which of the following is required for a simple electric circuit to function properly?,
      options: [
        A power source (such as a battery), a conductor (such as wires), and a load (such as a bulb) connected in a complete loop.,
        Only a battery without any wires or components.,
        Only a bulb connected to a broken wire.",
        "A switch that is always open to prevent electricity from flowing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A power source (such as a battery), a conductor (such as wires), and a load (such as a bulb) connected in a complete loop."
    })
  },
  {
    id: "G7-IS-EL-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Electricity",
    subtopic: "Conductors and Insulators,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Materials can be classified as conductors or insulators based on their ability to allow the flow of electric current. Which of the following materials is an example of a good electrical conductor?,
      options: [
        Copper, which is a metal with free electrons that move easily to conduct electricity.,
        Rubber, which is an insulator that prevents the flow of electricity.,
        "Plastic, which does not allow electricity to pass through.,
        Wood, which is a poor conductor of electricity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Copper, which is a metal with free electrons that move easily to conduct electricity.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD INTEGRATED SCIENCE SYLLABUS)
  // =========================================================================

  // --- CHEMICAL REACTIONS (4 Materials) ---
  {
    id: G8-IS-CR-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Chemical Reactions,
    subtopic: "Types of Chemical Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chemical reactions can be classified into different types based on how reactants combine or break apart. Which type of reaction occurs when a compound breaks down into two or more simpler substances?,
      options: [
        Decomposition reaction, where a single compound breaks down into two or more products.,
        Synthesis reaction, where two or more substances combine to form a single product.,
        Displacement reaction, where one element replaces another in a compound.",
        "Combustion reaction, where a substance burns in oxygen to produce heat and light.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Decomposition reaction, where a single compound breaks down into two or more products."
    })
  },
  {
    id: "G8-IS-CR-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Chemical Reactions",
    subtopic: "Chemical Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Chemical equations represent chemical reactions using symbols and formulas. What does the Law of Conservation of Mass state about chemical reactions?,
      options: [
        Mass is neither created nor destroyed in a chemical reaction; the total mass of reactants equals the total mass of products.,
        Mass is always increased in chemical reactions.,
        "Mass is always decreased in chemical reactions.,
        Mass is converted to energy in all chemical reactions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mass is neither created nor destroyed in a chemical reaction; the total mass of reactants equals the total mass of products.
    })
  },
  {
    id: G8-IS-CR-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Chemical Reactions,
    subtopic: "Oxidation and Reduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Oxidation and reduction are important types of chemical reactions that occur in many processes. Which of the following describes oxidation in terms of oxygen and electrons?,
      options: [
        Oxidation is the gain of oxygen or loss of hydrogen by a substance, or the loss of electrons (increase in oxidation state).,
        Oxidation is the loss of oxygen or gain of hydrogen by a substance, or the gain of electrons (decrease in oxidation state).,
        Oxidation only involves the addition of water to a substance.",
        "Oxidation has no effect on the composition of a substance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Oxidation is the gain of oxygen or loss of hydrogen by a substance, or the loss of electrons (increase in oxidation state)."
    })
  },
  {
    id: "G8-IS-CR-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Chemical Reactions",
    subtopic: "Factors Affecting Reaction Rate,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The rate of a chemical reaction can be influenced by various factors. Which of the following factors would most increase the rate of a reaction between a solid and a liquid?,
      options: [
        Increasing the surface area of the solid by grinding it into powder, increasing temperature, or increasing concentration of the liquid.,
        Decreasing the temperature of the reaction mixture.,
        "Using a larger volume of the liquid with the same concentration.,
        Using a single large piece of the solid instead of smaller pieces."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Increasing the surface area of the solid by grinding it into powder, increasing temperature, or increasing concentration of the liquid.
    })
  },

  // --- WORK, ENERGY, AND POWER (4 Materials) ---
  {
    id: G8-IS-WEP-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Work, Energy, and Power,
    subtopic: "Forms of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Energy exists in various forms and can be transformed from one form to another. Which of the following correctly describes the transformation of energy when a person eats food and uses it to run?,
      options: [
        Chemical energy in food is converted to kinetic energy (movement) and thermal energy (heat) during running.,
        Kinetic energy in food is converted to potential energy during running.,
        Solar energy in food is converted to electrical energy during running.",
        "Potential energy in food is converted to light energy during running.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical energy in food is converted to kinetic energy (movement) and thermal energy (heat) during running."
    })
  },
  {
    id: "G8-IS-WEP-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Work", Energy, and Power",
    subtopic: "Work and Mechanical Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Work is done when a force causes an object to move in the direction of the applied force. Which of the following situations represents work being done according to the scientific definition of work?,
      options: [
        Pushing a box across the floor, where the force moves the box in the direction of the push.,
        Holding a heavy book stationary above your head without moving it.,
        "Pushing against a wall that does not move.,
        Carrying a bag of groceries while walking horizontally on a flat surface."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pushing a box across the floor, where the force moves the box in the direction of the push.
    })
  },
  {
    id: G8-IS-WEP-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Work, Energy, and Power,
    subtopic: "Potential and Kinetic Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Potential energy is stored energy, while kinetic energy is the energy of motion. Which of the following correctly describes the relationship between potential and kinetic energy as an object falls from a height?,
      options: [
        As the object falls, its potential energy decreases while its kinetic energy increases, keeping total mechanical energy constant (neglecting air resistance).,
        As the object falls, both potential and kinetic energy increase.,
        As the object falls, both potential and kinetic energy decrease.",
        "As the object falls, potential energy increases and kinetic energy decreases.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: As the object falls, its potential energy decreases while its kinetic energy increases, keeping total mechanical energy constant (neglecting air resistance)."
    })
  },
  {
    id: "G8-IS-WEP-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Work", Energy, and Power",
    subtopic: "Power Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Power is the rate at which work is done or energy is transferred. In the formula Power = Work done / Time taken, if the work done is constant, how does the power change when the time taken to do the work increases?,
      options: [
        "Power decreases when the time taken increases, as less work is done per unit of time.,
        Power increases when the time taken increases.",
        "Power remains constant regardless of the time taken.,
        Power is not affected by time in this formula."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Power decreases when the time taken increases, as less work is done per unit of time.
    })
  },

  // --- ELECTRICITY AND MAGNETISM (4 Materials) ---
  {
    id: G8-IS-EM-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Electricity and Magnetism,
    subtopic: "Electromagnetism",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Electromagnetism is the relationship between electricity and magnetism, where electric current can create magnetic fields. Which of the following correctly describes the magnetic field produced around a straight current-carrying conductor?,
      options: [
        The magnetic field consists of concentric circular loops around the conductor, with the direction determined by the direction of the current (right-hand rule).,
        The magnetic field is a straight line extending from the conductor.,
        The magnetic field only exists inside the conductor.",
        "The magnetic field is perpendicular to the conductor and points outward in all directions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The magnetic field consists of concentric circular loops around the conductor, with the direction determined by the direction of the current (right-hand rule)."
    })
  },
  {
    id: "G8-IS-EM-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Electricity and Magnetism",
    subtopic: "Electromagnetic Induction,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Electromagnetic induction is the process of generating an electric current by changing a magnetic field. In a generator, which of the following movements is required to produce electricity through electromagnetic induction?,
      options: [
        Rotating a coil of wire within a magnetic field or moving a magnet near a coil of wire.,
        Keeping the coil of wire stationary inside a magnetic field.",
        "Moving the coil of wire away from the magnetic field.,
        Removing the magnet from the area entirely."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Rotating a coil of wire within a magnetic field or moving a magnet near a coil of wire.
    })
  },
  {
    id: G8-IS-EM-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Electricity and Magnetism,
    subtopic: "Electric Circuits and Power",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The relationship between voltage (V), current (I), and resistance (R) in an electric circuit is described by Ohm's Law. What is the formula for calculating power (P) in an electrical circuit?,
      options: [
        P = V × I, where power is the product of voltage and current.,
        P = V / I, where power is voltage divided by current.,
        P = I² × R, where power is the square of current times resistance.",
        "P = V² / R, where power is the square of voltage divided by resistance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: P = V × I, where power is the product of voltage and current."
    })
  },
  {
    id: "G8-IS-EM-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Electricity and Magnetism",
    subtopic: "Applications of Electromagnetism,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Electromagnetism has numerous practical applications in modern technology. Which of the following devices uses electromagnetism to convert electrical energy into mechanical energy?,
      options: [
        An electric motor, which uses the interaction between magnetic fields and current-carrying conductors to produce rotation.,
        A light bulb, which converts electrical energy to light and heat.,
        "A battery, which stores chemical energy and converts it to electrical energy.,
        A resistor, which limits the flow of current in a circuit."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An electric motor, which uses the interaction between magnetic fields and current-carrying conductors to produce rotation.
    })
  },

  // --- WAVES AND SOUND (3 Materials) ---
  {
    id: G8-IS-WS-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Waves and Sound,
    subtopic: "Wave Properties",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Waves are disturbances that transfer energy from one place to another without transferring matter. Which of the following correctly describes the difference between transverse and longitudinal waves?,
      options: [
        In transverse waves, particles vibrate perpendicular to the direction of wave propagation, while in longitudinal waves, particles vibrate parallel to the direction of wave propagation.,
        In transverse waves, particles vibrate parallel to the direction of wave propagation, while in longitudinal waves, particles vibrate perpendicular to the direction of wave propagation.,
        Both transverse and longitudinal waves have particles vibrating in the same direction as wave propagation.",
        "Both transverse and longitudinal waves have particles vibrating perpendicular to wave propagation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: In transverse waves, particles vibrate perpendicular to the direction of wave propagation, while in longitudinal waves, particles vibrate parallel to the direction of wave propagation."
    })
  },
  {
    id: "G8-IS-WS-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Waves and Sound",
    subtopic: "Sound Production and Propagation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sound waves are mechanical waves that require a medium to travel through. In which of the following mediums does sound travel the fastest, and why?,
      options: [
        Sound travels fastest in solids because particles are closely packed, allowing vibrations to be transmitted more quickly.,
        Sound travels fastest in gases because particles are far apart and move freely.",
        "Sound travels fastest in liquids because particles are in a fluid state.,
        Sound travels at the same speed in all mediums."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sound travels fastest in solids because particles are closely packed, allowing vibrations to be transmitted more quickly.
    })
  },
  {
    id: G8-IS-WS-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Waves and Sound,
    subtopic: "Sound Applications",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sound waves have various applications in medicine, communication, and navigation. Which technology uses sound waves with frequencies above the human hearing range to create images of internal body structures?,
      options: [
        Ultrasound, which uses high-frequency sound waves (ultrasonic waves) to produce images of internal organs and tissues.,
        X-ray imaging, which uses radiation to create images of bones.,
        MRI scanning, which uses magnetic fields to create images of soft tissues.",
        "ECG, which measures the electrical activity of the heart.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ultrasound, which uses high-frequency sound waves (ultrasonic waves) to produce images of internal organs and tissues."
    })
  },

  // --- LIGHT AND OPTICS (3 Materials) ---
  {
    id: "G8-IS-LO-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Light and Optics",
    subtopic: "Reflection of Light,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Reflection is the bouncing back of light rays when they strike a surface. According to the law of reflection, what is the relationship between the angle of incidence and the angle of reflection?,
      options: [
        The angle of incidence is equal to the angle of reflection when measured from the normal (perpendicular) to the reflecting surface.,
        The angle of incidence is always greater than the angle of reflection.",
        "The angle of incidence is always less than the angle of reflection.,
        The angle of incidence and the angle of reflection are unrelated."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The angle of incidence is equal to the angle of reflection when measured from the normal (perpendicular) to the reflecting surface.
    })
  },
  {
    id: G8-IS-LO-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Light and Optics,
    subtopic: "Refraction of Light",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refraction is the bending of light as it passes from one medium to another. When light travels from air into water, what happens to its speed and direction?,
      options: [
        Light slows down as it enters water and bends toward the normal (refracts) due to the change in the speed of light in different media.,
        Light speeds up as it enters water and bends away from the normal.,
        Light maintains the same speed and does not change direction.",
        "Light is completely reflected at the surface of the water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Light slows down as it enters water and bends toward the normal (refracts) due to the change in the speed of light in different media."
    })
  },
  {
    id: "G8-IS-LO-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Light and Optics",
    subtopic: "Lenses and Applications,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Lenses are optical devices that refract light to form images. Which type of lens is thicker at the center than at the edges and converges light rays to a focal point?,
      options: [
        A convex lens (converging lens), which bends parallel light rays so they meet at a focal point.,
        A concave lens (diverging lens), which spreads light rays away from a focal point.,
        "A cylindrical lens, which focuses light in only one direction.,
        A Fresnel lens, which is flat but acts like a convex lens."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A convex lens (converging lens), which bends parallel light rays so they meet at a focal point.
    })
  },

  // --- GENETICS AND EVOLUTION (3 Materials) ---
  {
    id: G8-IS-GE-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "Heredity and Genetics",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Genetics is the study of heredity and how traits are passed from parents to offspring. According to Mendelian genetics, which of the following correctly describes the principle of segregation?,
      options: [
        The principle of segregation states that during the formation of gametes, the two alleles for a trait separate (segregate) so that each gamete receives only one allele.,
        The principle of segregation states that alleles always blend together to produce intermediate traits.,
        The principle of segregation states that both alleles for a trait are always expressed in an individual.",
        "The principle of segregation states that traits are inherited from only one parent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The principle of segregation states that during the formation of gametes, the two alleles for a trait separate (segregate) so that each gamete receives only one allele."
    })
  },
  {
    id: "G8-IS-GE-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Genetics and Evolution",
    subtopic: "Variation and Natural Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Natural selection is the mechanism of evolution proposed by Charles Darwin. Which of the following describes how natural selection leads to the evolution of populations over time?,
      options: [
        Individuals with traits that provide advantages in their environment are more likely to survive and reproduce, passing these favorable traits to their offspring.,
        All individuals in a population have an equal chance of survival regardless of their traits.,
        "Environmental changes cause all individuals in a population to develop the same traits.,
        Natural selection only occurs in small populations with no genetic variation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Individuals with traits that provide advantages in their environment are more likely to survive and reproduce, passing these favorable traits to their offspring.
    })
  },
  {
    id: G8-IS-GE-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "Genetic Variation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Genetic variation within a population is essential for evolution and adaptation. Which of the following is the primary source of new genetic variation in a population?,
      options: [
        Mutations, which are random changes in the DNA sequence that introduce new alleles into the gene pool.,
        Artificial selection, where humans selectively breed organisms for desired traits.,
        Genetic drift, where allele frequencies change due to random events.",
        "Migration, where individuals move between populations.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mutations, which are random changes in the DNA sequence that introduce new alleles into the gene pool."
    })
  },

  // --- EARTH SCIENCE (3 Materials) ---
  {
    id: "G8-IS-ES-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Earth Science",
    subtopic: "Rocks and Minerals,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Rocks are classified into three main types based on their formation process. Which type of rock is formed from the cooling and solidification of magma or lava?,
      options: [
        Igneous rock, which forms from the crystallization of molten material (magma or lava).,
        Sedimentary rock, which forms from the compaction and cementation of sediments.,
        "Metamorphic rock, which forms from the transformation of existing rocks under heat and pressure.,
        Soil, which is formed from weathered rock and organic matter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Igneous rock, which forms from the crystallization of molten material (magma or lava).
    })
  },
  {
    id: G8-IS-ES-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Earth Science,
    subtopic: "Geological Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The Earth's surface is constantly changing due to various geological processes. Which of the following geological processes is responsible for the movement of the Earth's tectonic plates and the occurrence of earthquakes?,
      options: [
        Plate tectonics, where the Earth's lithosphere is divided into plates that move over the asthenosphere, causing earthquakes at plate boundaries.,
        Volcanic activity, which is caused by magma rising to the Earth's surface.,
        Weathering, which breaks down rocks at the Earth's surface.",
        "Erosion, which transports weathered materials from one place to another.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plate tectonics, where the Earth's lithosphere is divided into plates that move over the asthenosphere, causing earthquakes at plate boundaries."
    })
  },
  {
    id: "G8-IS-ES-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Earth Science",
    subtopic: "Weather and Climate,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Weather and climate are related but different concepts in Earth Science. Which of the following correctly distinguishes weather from climate?,
      options: [
        Weather is the short-term condition of the atmosphere at a specific time and place, while climate is the average weather conditions over a long period (typically 30 years or more).,
        Weather is the average conditions over a long period, while climate is the current atmospheric condition.,
        "Weather and climate are the same thing and can be used interchangeably.,
        Weather only refers to temperature, while climate only refers to precipitation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Weather is the short-term condition of the atmosphere at a specific time and place, while climate is the average weather conditions over a long period (typically 30 years or more).
    })
  },

  // --- SPACE SCIENCE (3 Materials) ---
  {
    id: G8-IS-SS-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Space Science,
    subtopic: "The Solar System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The solar system consists of the Sun and all the celestial bodies that orbit around it. Which of the following correctly describes the orbital relationship between the Sun, Earth, and Moon?,
      options: [
        The Earth orbits the Sun, and the Moon orbits the Earth, with the Moon's orbit around the Earth taking approximately one month.,
        The Sun orbits the Earth, and the Moon orbits the Sun.,
        The Earth and Moon both orbit the Sun independently.",
        "The Moon orbits the Sun directly, and the Earth is stationary.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Earth orbits the Sun, and the Moon orbits the Earth, with the Moon's orbit around the Earth taking approximately one month."
    })
  },
  {
    id: "G8-IS-SS-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Space Science",
    subtopic: "Stars and Galaxies,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Stars are massive, luminous spheres of plasma that produce energy through nuclear fusion. What is the primary source of energy produced in stars like the Sun?,
      options: [
        Nuclear fusion of hydrogen atoms into helium in the star's core, releasing vast amounts of energy.,
        Nuclear fission of heavy elements in the star's core.",
        "Chemical combustion of gases on the star's surface.,
        Reflection of light from other stars and celestial bodies."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nuclear fusion of hydrogen atoms into helium in the star's core, releasing vast amounts of energy.
    })
  },
  {
    id: G8-IS-SS-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Space Science,
    subtopic: "Space Exploration",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Space exploration has expanded human understanding of the universe and its phenomena. Which of the following was a significant achievement of the Apollo space missions?,
      options: [
        The Apollo 11 mission successfully landed the first humans on the Moon in 1969.,
        The Apollo missions sent the first satellite into Earth orbit.,
        The Apollo missions landed the first spacecraft on Mars.",
        "The Apollo missions established a permanent space station on the Moon.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Apollo 11 mission successfully landed the first humans on the Moon in 1969."
    })
  },

  // --- SUSTAINABLE DEVELOPMENT (3 Materials) ---
  {
    id: "G8-IS-SD-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Sustainable Development",
    subtopic: "Environmental Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable development aims to meet the needs of the present without compromising the ability of future generations to meet their own needs. Which of the following practices best promotes sustainable development in agriculture?,
      options: [
        Agroforestry, conservation agriculture, and organic farming that maintain soil health and biodiversity.,
        Intensive monoculture farming with heavy use of chemical fertilizers and pesticides.,
        "Clearing all natural vegetation for agricultural expansion without regard for environmental impact.,
        Using only traditional methods without incorporating modern sustainable techniques."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry, conservation agriculture, and organic farming that maintain soil health and biodiversity.
    })
  },
  {
    id: G8-IS-SD-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Sustainable Development,
    subtopic: "Renewable Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Renewable energy sources are important for reducing dependence on fossil fuels and mitigating climate change. Which of the following is an example of a renewable energy source that uses the Earth's internal heat?,
      options: [
        Geothermal energy, which harnesses heat from the Earth's interior for electricity generation and heating.,
        Solar energy, which uses sunlight to generate electricity.,
        Wind energy, which uses wind to turn turbines and generate electricity.",
        "Hydroelectric energy, which uses flowing water to generate electricity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Geothermal energy, which harnesses heat from the Earth's interior for electricity generation and heating."
    })
  },
  {
    id: "G8-IS-SD-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Sustainable Development",
    subtopic: "Waste Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper waste management is essential for environmental sustainability and human health. Which of the following waste management practices follows the principles of reduce, reuse, and recycle (the 3Rs)?,
      options: [
        "Reducing the amount of waste produced, reusing items instead of discarding them, and recycling materials to make new products.,
        Burning all waste materials to reduce their volume.",
        "Dumping all waste in landfills without any treatment or sorting.,
        Exporting waste to other countries for disposal."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Reducing the amount of waste produced, reusing items instead of discarding them, and recycling materials to make new products.
    })
  },

  // --- HEALTH AND DISEASE (3 Materials) ---
  {
    id: G8-IS-HD-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Chronic Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chronic diseases such as heart disease, diabetes, and cancer are leading causes of death worldwide. Which of the following lifestyle choices can significantly reduce the risk of developing type 2 diabetes?,
      options: [
        Maintaining a healthy weight, exercising regularly, eating a balanced diet, and limiting sugar and processed foods.,
        Eating large amounts of sugar and fatty foods regularly.,
        Living a sedentary lifestyle with little or no physical activity.",
        "Smoking and consuming alcohol on a regular basis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maintaining a healthy weight, exercising regularly, eating a balanced diet, and limiting sugar and processed foods."
    })
  },
  {
    id: "G8-IS-HD-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Health and Disease",
    subtopic: "Non-Communicable Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Non-communicable diseases (NCDs) are not caused by infectious agents and are often linked to lifestyle factors. Which of the following is a major risk factor for both cardiovascular disease and certain types of cancer?,
      options: [
        Tobacco use, which damages blood vessels, increases blood pressure, and contains carcinogens.,
        Regular physical exercise, which improves overall health.,
        "Consumption of fruits and vegetables, which provides essential vitamins.,
        Getting adequate sleep, which allows the body to recover."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tobacco use, which damages blood vessels, increases blood pressure, and contains carcinogens.
    })
  },
  {
    id: G8-IS-HD-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Public Health Measures",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Public health measures aim to prevent disease and promote health at the community level. Which of the following is an example of a primary prevention measure that addresses the root causes of disease?,
      options: [
        Health education campaigns that promote healthy eating and discourage smoking and excessive alcohol consumption.,
        Screening programs that detect diseases at an early stage.,
        Medical treatment of diseases after they have developed.",
        "Rehabilitation programs for people recovering from illness.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Health education campaigns that promote healthy eating and discourage smoking and excessive alcohol consumption."
    })
  },

  // --- SCIENTIFIC INVESTIGATION (2 Materials) ---
  {
    id: "G8-IS-SI-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Advanced Scientific Skills,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Advanced scientific investigation requires careful planning, precise measurement, and thorough data analysis. What is the purpose of using a control group in a scientific experiment?,
      options: [
        "To serve as a baseline for comparison to determine whether the independent variable had an effect on the dependent variable.,
        To ensure that all variables are changed simultaneously during the experiment.",
        "To provide a subject that receives the maximum treatment.,
        To eliminate the need for replication of the experiment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "To serve as a baseline for comparison to determine whether the independent variable had an effect on the dependent variable.
    })
  },
  {
    id: G8-IS-SI-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Data Interpretation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Interpreting experimental data requires understanding patterns, relationships, and potential sources of error. When analyzing data from an experiment, how should outliers (extreme values that differ significantly from other observations) be treated?,
      options: [
        Outliers should be examined carefully to determine if they resulted from experimental errors or represent meaningful data, and reported honestly in the results.,
        Outliers should always be removed from the data set without explanation.,
        Outliers should be ignored as they cannot affect the overall results.",
        "Outliers should be replaced with the average value of the other data points.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Outliers should be examined carefully to determine if they resulted from experimental errors or represent meaningful data, and reported honestly in the results."
    })
  }`nexport const integratedScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD INTEGRATED SCIENCE SYLLABUS)
  // =========================================================================
  {
    id: "G7-IS-SI-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Scientific Method",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "The scientific method is a systematic approach used by scientists to investigate phenomena and acquire new knowledge. Which of the following correctly lists the steps of the scientific method in their proper sequence?,
      options: [
        Observation, Question, Hypothesis, Experiment, Analysis, Conclusion.,
        Hypothesis, Observation, Question, Experiment, Conclusion, Analysis.,
        "Experiment, Observation, Conclusion, Question, Hypothesis, Analysis.,
        Question, Conclusion, Hypothesis, Observation, Analysis, Experiment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Observation, Question, Hypothesis, Experiment, Analysis, Conclusion.
    })
  },
  {
    id: G7-IS-SI-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Laboratory Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Laboratory safety rules are essential to prevent accidents and injuries during scientific experiments. Which of the following is the most important safety practice to follow when handling chemicals in a science laboratory?,
      options: [
        Always wear appropriate protective equipment such as safety goggles, gloves, and a laboratory coat when handling chemicals.,
        Taste small amounts of chemicals to identify them.,
        Use chemicals without reading the labels first.",
        "Leave chemical containers open when not in use.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Always wear appropriate protective equipment such as safety goggles, gloves, and a laboratory coat when handling chemicals."
    })
  },
  {
    id: "G7-IS-SI-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Variables in Experiments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In scientific experiments, variables are factors that can change or be manipulated. What is the term used to describe the variable that is intentionally changed by the experimenter to observe its effect on another variable?,
      options: [
        Independent variable, which is deliberately manipulated by the researcher.,
        Dependent variable, which is measured as the outcome of the experiment.",
        "Control variable, which is kept constant throughout the experiment.,
        Extraneous variable, which may affect the results but is not being studied."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Independent variable, which is deliberately manipulated by the researcher.
    })
  },
  {
    id: G7-IS-SI-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Data Collection and Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Collecting and analyzing data accurately is crucial for drawing valid conclusions from scientific experiments. Which of the following is the most appropriate way to present quantitative data collected from an experiment to show trends and patterns clearly?,
      options: [
        Plotting data on a line graph or bar chart with appropriate labels and scales.,
        Listing all data points in a paragraph without any visual representation.,
        Using only photographs without any numerical analysis.",
        "Storing data in a notebook without any analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plotting data on a line graph or bar chart with appropriate labels and scales."
    })
  },
  {
    id: "G7-IS-CM-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Cells and Microscopy",
    subtopic: "Cell Structure and Function,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Cells are the basic structural and functional units of all living organisms. Which of the following correctly describes the primary function of the mitochondria in a eukaryotic cell?,
      options: [
        Mitochondria are the powerhouses of the cell where cellular respiration occurs to produce energy (ATP) for the cell's activities.,
        Mitochondria are responsible for protein synthesis in the cell.,
        "Mitochondria store genetic material and control cellular activities.,
        Mitochondria are involved in photosynthesis in plant cells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mitochondria are the powerhouses of the cell where cellular respiration occurs to produce energy (ATP) for the cell's activities.
    })
  },
  {
    id: G7-IS-CM-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Cells and Microscopy,
    subtopic: "Plant vs. Animal Cells",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Plant and animal cells share many common structures but also have distinct differences. Which of the following organelles is found in plant cells but not in animal cells?,
      options: [
        Chloroplasts, which contain chlorophyll and are the site of photosynthesis.,
        Mitochondria, which are responsible for cellular respiration.,
        Nucleus, which controls cell activities.",
        "Ribosomes, which synthesize proteins.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chloroplasts, which contain chlorophyll and are the site of photosynthesis."
    })
  },
  {
    id: "G7-IS-CM-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Cells and Microscopy",
    subtopic: "Microscope Use,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The microscope is an essential tool in biology that allows scientists to view objects that are too small to be seen with the naked eye. When using a compound light microscope, what is the correct procedure for focusing on a specimen?,
      options: [
        Start with the lowest power objective lens, use the coarse adjustment to bring the image into focus, then fine-tune with the fine adjustment knob.,
        Start immediately with the highest power objective lens to get a detailed view.",
        "Use only the fine adjustment knob without using the coarse adjustment at all.,
        Move the microscope constantly while viewing the specimen."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Start with the lowest power objective lens, use the coarse adjustment to bring the image into focus, then fine-tune with the fine adjustment knob.
    })
  },
  {
    id: G7-IS-CM-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Cells and Microscopy,
    subtopic: "Specialized Cells",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Specialized cells have unique structures that enable them to perform specific functions in multicellular organisms. Which of the following describes the adaptation of red blood cells that allows them to efficiently transport oxygen?,
      options: [
        Red blood cells have a biconcave shape that increases surface area for oxygen uptake and lack a nucleus to carry more hemoglobin.,
        Red blood cells have a long tail-like structure for movement through blood vessels.,
        Red blood cells contain large chloroplasts for energy production.",
        "Red blood cells have a thick cell wall for protection.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Red blood cells have a biconcave shape that increases surface area for oxygen uptake and lack a nucleus to carry more hemoglobin."
    })
  },
  {
    id: "G7-IS-NP-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Nutrition in Plants and Animals",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Photosynthesis is the process by which green plants manufacture their own food using energy from sunlight. Which of the following is the correct chemical equation for photosynthesis?,
      options: [
        6CO₂ + 6H₂O + Light Energy → C₆H₁₂O₆ + 6O₂,
        C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + Energy,
        "6CO₂ + 6H₂O + Energy → 6O₂ + C₆H₁₂O₆,
        CO₂ + H₂O + Light → C₆H₁₂O₆ + O₂"
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "6CO₂ + 6H₂O + Light Energy → C₆H₁₂O₆ + 6O₂
    })
  },
  {
    id: G7-IS-NP-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Nutrition in Plants and Animals,
    subtopic: "Nutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Nutrients are essential substances that organisms need for growth, energy, and maintenance of health. Which of the following is the main function of carbohydrates in the human diet?,
      options: [
        Carbohydrates are the body's primary source of energy, providing fuel for physical activities and vital body functions.,
        Carbohydrates are responsible for building and repairing body tissues.,
        Carbohydrates regulate body processes and maintain healthy immune function.",
        "Carbohydrates are stored as fat for long-term energy reserves.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates are the body's primary source of energy, providing fuel for physical activities and vital body functions."
    })
  },
  {
    id: "G7-IS-NP-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Nutrition in Plants and Animals",
    subtopic: "The Digestive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The human digestive system breaks down food into simpler substances that can be absorbed and used by the body. In which part of the digestive system is most of the absorption of nutrients from digested food carried out?,
      options: [
        The small intestine, which has villi that increase surface area for efficient absorption of nutrients.,
        The stomach, where food is churned and mixed with gastric juices.,
        "The large intestine, which absorbs water and forms feces.,
        The mouth, where mechanical digestion begins with chewing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The small intestine, which has villi that increase surface area for efficient absorption of nutrients.
    })
  },
  {
    id: G7-IS-NP-04",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Nutrition in Plants and Animals,
    subtopic: "Balanced Diet",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A balanced diet is essential for maintaining good health and preventing nutrient deficiency diseases. What does a balanced diet include?,
      options: [
        A variety of foods from all food groups in the correct proportions to provide adequate energy, protein, vitamins, minerals, and water.,
        Only proteins and carbohydrates without any fats or vitamins.,
        Only fruits and vegetables without any proteins or carbohydrates.",
        "Large amounts of sugar and fat without other nutrients.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A variety of foods from all food groups in the correct proportions to provide adequate energy, protein, vitamins, minerals, and water."
    })
  },
  {
    id: "G7-IS-TS-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Transport Systems",
    subtopic: "Circulatory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The circulatory system is responsible for transporting substances such as oxygen, nutrients, and hormones throughout the body. Which of the following describes the role of arteries in the human circulatory system?,
      options: [
        "Arteries carry oxygenated blood away from the heart to the body tissues, except for the pulmonary artery which carries deoxygenated blood to the lungs.,
        Arteries carry deoxygenated blood from the body back to the heart.",
        "Arteries are the sites of exchange of substances between the blood and body tissues.,
        Arteries collect blood from the body tissues and return it to the heart."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Arteries carry oxygenated blood away from the heart to the body tissues, except for the pulmonary artery which carries deoxygenated blood to the lungs.
    })
  },
  {
    id: G7-IS-TS-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Transport Systems,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Plants have transport systems that move water, minerals, and food substances throughout the plant body. Which tissue is responsible for the transport of water and dissolved minerals from the roots to the leaves in vascular plants?,
      options: [
        Xylem, which consists of dead cells forming tubes that transport water and minerals upwards due to transpiration pull.,
        Phloem, which transports sugars and other organic substances from the leaves to other parts of the plant.,
        Epidermis, which provides protection for the plant.",
        "Cambium, which is responsible for secondary growth in plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Xylem, which consists of dead cells forming tubes that transport water and minerals upwards due to transpiration pull."
    })
  },
  {
    id: "G7-IS-TS-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Transport Systems",
    subtopic: "Blood Composition,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Blood is a connective tissue that plays a vital role in transporting substances and defending the body against infections. Which of the following is the primary function of plasma in the blood?,
      options: [
        Plasma is the liquid component of blood that transports dissolved nutrients, hormones, and waste products throughout the body.,
        Plasma is responsible for carrying oxygen from the lungs to body tissues.,
        "Plasma produces antibodies to fight infections.,
        Plasma forms clots to prevent bleeding from wounds."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Plasma is the liquid component of blood that transports dissolved nutrients, hormones, and waste products throughout the body.
    })
  },
  {
    id: G7-IS-RH-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Respiration and Homeostasis,
    subtopic: "Respiration",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Respiration is the process by which living organisms obtain energy from food molecules. What is the difference between aerobic respiration and anaerobic respiration in terms of oxygen requirements and energy production?,
      options: [
        Aerobic respiration requires oxygen and produces more energy (ATP) per glucose molecule, while anaerobic respiration occurs without oxygen and produces less energy.,
        Aerobic respiration occurs without oxygen and produces more energy, while anaerobic respiration requires oxygen.,
        Both aerobic and anaerobic respiration require oxygen but produce the same amount of energy.",
        "Neither aerobic nor anaerobic respiration involves energy production from glucose.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Aerobic respiration requires oxygen and produces more energy (ATP) per glucose molecule, while anaerobic respiration occurs without oxygen and produces less energy."
    })
  },
  {
    id: "G7-IS-RH-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Respiration and Homeostasis",
    subtopic: "Gas Exchange,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Gas exchange is the process by which organisms exchange oxygen and carbon dioxide with their environment. In humans, where does the exchange of gases between the air and the bloodstream primarily occur?,
      options: [
        In the alveoli of the lungs, where oxygen diffuses into the blood and carbon dioxide diffuses out of the blood.,
        In the trachea, where air is filtered and warmed.",
        "In the bronchi, which branch from the trachea.,
        In the bronchioles, which are small passages in the lungs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In the alveoli of the lungs, where oxygen diffuses into the blood and carbon dioxide diffuses out of the blood.
    })
  },
  {
    id: G7-IS-RH-03",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Respiration and Homeostasis,
    subtopic: "Homeostasis",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Homeostasis is the maintenance of a stable internal environment in living organisms despite changes in the external environment. Which of the following is an example of a homeostatic mechanism in the human body?,
      options: [
        Thermoregulation, where the body maintains its temperature within a narrow range through processes such as sweating and shivering.,
        The digestive process that breaks down food into nutrients.,
        The movement of the body during exercise.",
        "The growth and development of a child into an adult.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Thermoregulation, where the body maintains its temperature within a narrow range through processes such as sweating and shivering."
    })
  },
  {
    id: "G7-IS-REP-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Reproduction",
    subtopic: "Reproduction in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sexual reproduction in flowering plants involves the fusion of male and female gametes to produce seeds. Which of the following correctly describes the process of pollination and fertilization in a flowering plant?,
      options: [
        Pollination is the transfer of pollen from the anther to the stigma, followed by fertilization where the pollen tube grows to deliver sperm cells to the ovule.,
        Fertilization occurs before pollination in all flowering plants.,
        "Pollination is the fusion of male and female gametes.,
        Fertilization is the transfer of pollen from one flower to another."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pollination is the transfer of pollen from the anther to the stigma, followed by fertilization where the pollen tube grows to deliver sperm cells to the ovule.
    })
  },
  {
    id: G7-IS-REP-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Reproduction,
    subtopic: "Reproduction in Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Animals reproduce either sexually or asexually, with sexual reproduction involving the fusion of gametes. Which of the following is an advantage of sexual reproduction over asexual reproduction in animals?,
      options: [
        Sexual reproduction produces genetic variation in offspring, which increases the ability of a population to adapt to changing environments.,
        Sexual reproduction produces offspring that are identical to the parent.,
        Sexual reproduction requires only one parent.",
        "Sexual reproduction is faster and simpler than asexual reproduction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sexual reproduction produces genetic variation in offspring, which increases the ability of a population to adapt to changing environments."
    })
  },
  {
    id: "G7-IS-REP-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Reproduction",
    subtopic: "Human Reproductive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The human reproductive system is specialized for the production of gametes and the continuation of the species. What is the function of the testes in the male reproductive system?,
      options: [
        The testes produce sperm cells and secrete testosterone, the primary male sex hormone.,
        The testes store urine before it is excreted from the body.,
        "The testes produce eggs for reproduction.,
        The testes regulate body temperature in males."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The testes produce sperm cells and secrete testosterone, the primary male sex hormone.
    })
  },
  {
    id: G7-IS-EE-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Ecology and Environment,
    subtopic: "Ecosystems",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " An ecosystem consists of all the living organisms in an area interacting with each other and with the non-living environment. Which of the following is an example of an abiotic factor in a terrestrial ecosystem?,
      options: [
        Temperature, rainfall, sunlight, and soil composition.,
        Trees, grass, and animals in the area.,
        Microorganisms and decomposers in the soil.",
        "Predators and prey that interact in the ecosystem.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Temperature, rainfall, sunlight, and soil composition."
    })
  },
  {
    id: "G7-IS-EE-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Ecology and Environment",
    subtopic: "Food Chains and Food Webs,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "A food chain shows the flow of energy from one organism to another in an ecosystem. In a typical grassland food chain, which of the following organisms occupies the position of a primary consumer?,
      options: [
        Herbivores such as grasshoppers or cattle that feed directly on producers (plants).,
        Carnivores such as lions or eagles that feed on other animals.",
        "Decomposers such as bacteria and fungi that break down dead organisms.,
        Producers such as grasses and trees that make their own food."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Herbivores such as grasshoppers or cattle that feed directly on producers (plants).
    })
  },
  {
    id: G7-IS-EE-03",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Ecology and Environment,
    subtopic: "Environmental Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Environmental conservation involves the sustainable use and management of natural resources to protect the environment. Which of the following human activities most significantly contributes to the conservation of forest ecosystems?,
      options: [
        Tree planting, sustainable forest harvesting, and protection of forest habitats.,
        Clearing forests for agricultural expansion and settlement.,
        Cutting trees without replanting for timber production.",
        "Burning forests to create pasture for livestock.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Tree planting, sustainable forest harvesting, and protection of forest habitats."
    })
  },
  {
    id: "G7-IS-MA-01",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Matter and Atomic Structure",
    subtopic: "States of Matter,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Matter exists in three main states: solid, liquid, and gas. Which of the following correctly describes the arrangement and movement of particles in a solid?,
      options: [
        "Particles are tightly packed in a fixed arrangement with limited vibration, giving solids a definite shape and volume.,
        Particles are loosely packed and can slide past each other, allowing liquids to flow and take the shape of their container.",
        "Particles are widely spaced and move freely, allowing gases to expand and fill any container.,
        Particles are completely stationary with no movement at all."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Particles are tightly packed in a fixed arrangement with limited vibration, giving solids a definite shape and volume.
    })
  },
  {
    id: G7-IS-MA-02",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Matter and Atomic Structure,
    subtopic: "Atomic Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Atoms are the basic building blocks of matter and consist of subatomic particles. Which of the following correctly describes the structure of an atom and the charges of its subatomic particles?,
      options: [
        An atom consists of a positively charged nucleus containing protons and neutrons, with negatively charged electrons orbiting around the nucleus.,
        An atom consists of a negatively charged nucleus with positively charged electrons orbiting around it.,
        An atom consists of a nucleus with equal numbers of protons and electrons, and neutrons that carry a negative charge.",
        "An atom has no charged particles and is completely neutral throughout.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: An atom consists of a positively charged nucleus containing protons and neutrons, with negatively charged electrons orbiting around the nucleus."
    })
  },
  {
    id: "G7-IS-MA-03",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Matter and Atomic Structure",
    subtopic: "Elements and Compounds,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Elements are pure substances made of only one type of atom, while compounds are substances formed when two or more elements chemically combine. Which of the following is a compound commonly found in the kitchen?,
      options: [
        Sodium chloride (NaCl), also known as table salt, which is formed from sodium and chlorine atoms.,
        Oxygen gas (O₂), which is an element made of oxygen atoms.",
        "Gold (Au), which is a pure element.,
        Copper wire (Cu), which consists of copper atoms."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sodium chloride (NaCl), also known as table salt, which is formed from sodium and chlorine atoms.
    })
  },
  {
    id: G7-IS-ABS-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Acids, Bases, and Salts,
    subtopic: "Properties of Acids and Bases",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Acids and bases are two classes of chemical substances with distinct properties. Which of the following is a characteristic property of an acid?,
      options: [
        Acids have a sour taste, turn blue litmus paper red, and react with metals to produce hydrogen gas.,
        Acids have a bitter taste, turn red litmus paper blue, and are slippery to touch.,
        Acids have a salty taste and react with bases to produce oxygen gas.",
        "Acids have no taste and do not react with other substances.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Acids have a sour taste, turn blue litmus paper red, and react with metals to produce hydrogen gas."
    })
  },
  {
    id: "G7-IS-ABS-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Acids", Bases, and Salts",
    subtopic: "pH Scale and Neutralization,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The pH scale is used to measure the acidity or alkalinity of a solution. What is the pH value of a neutral solution such as pure water at room temperature?,
      options: [
        pH 7, which indicates that the solution is neither acidic nor basic.,
        pH 0, which indicates a highly acidic solution.,
        "pH 14, which indicates a highly basic solution.,
        pH 3, which indicates a moderately acidic solution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "pH 7, which indicates that the solution is neither acidic nor basic.
    })
  },
  {
    id: G7-IS-FP-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Forces and Pressure,
    subtopic: "Types of Forces",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Forces are pushes or pulls that can cause objects to move, stop, or change direction. Which of the following correctly describes the force of gravity?,
      options: [
        Gravity is the force of attraction between objects with mass, causing objects to fall toward the center of the Earth.,
        Gravity is the force that resists the movement of objects through air.,
        Gravity is the force between two magnets.",
        "Gravity is the force that causes objects to float on water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Gravity is the force of attraction between objects with mass, causing objects to fall toward the center of the Earth."
    })
  },
  {
    id: "G7-IS-FP-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Forces and Pressure",
    subtopic: "Pressure,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pressure is the force applied per unit area. Which of the following real-world examples demonstrates how pressure is affected by the surface area over which a force is distributed?,
      options: [
        A sharp knife cuts easily because the force is concentrated over a small surface area, creating high pressure.,
        A blunt knife cuts more easily than a sharp knife because it has a larger surface area.,
        "Pressure is not affected by surface area at all.,
        A person lying on a bed creates more pressure than a person standing on one foot."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A sharp knife cuts easily because the force is concentrated over a small surface area, creating high pressure.
    })
  },
  {
    id: G7-IS-HD-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Pathogens and Disease Transmission",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pathogens are disease-causing microorganisms that can be transmitted through various routes. Which of the following is the most effective way to prevent the transmission of airborne diseases such as tuberculosis and COVID-19?,
      options: [
        Wearing masks, maintaining physical distance, ensuring good ventilation, and practicing cough etiquette.,
        Taking antibiotics without prescription.,
        Ignoring symptoms and continuing regular activities.",
        "Avoiding all contact with other people completely.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Wearing masks, maintaining physical distance, ensuring good ventilation, and practicing cough etiquette."
    })
  },
  {
    id: "G7-IS-HD-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Health and Disease",
    subtopic: "Immunity and Vaccination,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Vaccination is an important public health measure that helps prevent the spread of infectious diseases. How does vaccination work to protect the body against specific diseases?,
      options: [
        Vaccination introduces weakened or inactive pathogens (antigens) to stimulate the immune system to produce antibodies without causing the disease.,
        Vaccination kills all pathogens in the body immediately after administration.,
        "Vaccination replaces the need for any other health measures.,
        Vaccination has no effect on the body's immune response."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vaccination introduces weakened or inactive pathogens (antigens) to stimulate the immune system to produce antibodies without causing the disease.
    })
  },
  {
    id: G7-IS-EL-01",
    grade: "Grade 7,
    subject: Integrated Science",
    topic: "Electricity,
    subtopic: "Electric Circuits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " An electric circuit is a complete path through which electricity can flow. Which of the following is required for a simple electric circuit to function properly?,
      options: [
        A power source (such as a battery), a conductor (such as wires), and a load (such as a bulb) connected in a complete loop.,
        Only a battery without any wires or components.,
        Only a bulb connected to a broken wire.",
        "A switch that is always open to prevent electricity from flowing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A power source (such as a battery), a conductor (such as wires), and a load (such as a bulb) connected in a complete loop."
    })
  },
  {
    id: "G7-IS-EL-02",
    grade: "Grade 7",
    subject: "Integrated Science",
    topic: "Electricity",
    subtopic: "Conductors and Insulators,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Materials can be classified as conductors or insulators based on their ability to allow the flow of electric current. Which of the following materials is an example of a good electrical conductor?,
      options: [
        Copper, which is a metal with free electrons that move easily to conduct electricity.,
        Rubber, which is an insulator that prevents the flow of electricity.,
        "Plastic, which does not allow electricity to pass through.,
        Wood, which is a poor conductor of electricity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Copper, which is a metal with free electrons that move easily to conduct electricity.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD INTEGRATED SCIENCE SYLLABUS)
  // =========================================================================
  {
    id: G8-IS-CR-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Chemical Reactions,
    subtopic: "Types of Chemical Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chemical reactions can be classified into different types based on how reactants combine or break apart. Which type of reaction occurs when a compound breaks down into two or more simpler substances?,
      options: [
        Decomposition reaction, where a single compound breaks down into two or more products.,
        Synthesis reaction, where two or more substances combine to form a single product.,
        Displacement reaction, where one element replaces another in a compound.",
        "Combustion reaction, where a substance burns in oxygen to produce heat and light.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Decomposition reaction, where a single compound breaks down into two or more products."
    })
  },
  {
    id: "G8-IS-CR-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Chemical Reactions",
    subtopic: "Chemical Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Chemical equations represent chemical reactions using symbols and formulas. What does the Law of Conservation of Mass state about chemical reactions?,
      options: [
        Mass is neither created nor destroyed in a chemical reaction; the total mass of reactants equals the total mass of products.,
        Mass is always increased in chemical reactions.,
        "Mass is always decreased in chemical reactions.,
        Mass is converted to energy in all chemical reactions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mass is neither created nor destroyed in a chemical reaction; the total mass of reactants equals the total mass of products.
    })
  },
  {
    id: G8-IS-CR-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Chemical Reactions,
    subtopic: "Oxidation and Reduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Oxidation and reduction are important types of chemical reactions that occur in many processes. Which of the following describes oxidation in terms of oxygen and electrons?,
      options: [
        Oxidation is the gain of oxygen or loss of hydrogen by a substance, or the loss of electrons (increase in oxidation state).,
        Oxidation is the loss of oxygen or gain of hydrogen by a substance, or the gain of electrons (decrease in oxidation state).,
        Oxidation only involves the addition of water to a substance.",
        "Oxidation has no effect on the composition of a substance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Oxidation is the gain of oxygen or loss of hydrogen by a substance, or the loss of electrons (increase in oxidation state)."
    })
  },
  {
    id: "G8-IS-CR-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Chemical Reactions",
    subtopic: "Factors Affecting Reaction Rate,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The rate of a chemical reaction can be influenced by various factors. Which of the following factors would most increase the rate of a reaction between a solid and a liquid?,
      options: [
        Increasing the surface area of the solid by grinding it into powder, increasing temperature, or increasing concentration of the liquid.,
        Decreasing the temperature of the reaction mixture.,
        "Using a larger volume of the liquid with the same concentration.,
        Using a single large piece of the solid instead of smaller pieces."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Increasing the surface area of the solid by grinding it into powder, increasing temperature, or increasing concentration of the liquid.
    })
  },
  {
    id: G8-IS-WEP-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Work, Energy, and Power,
    subtopic: "Forms of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Energy exists in various forms and can be transformed from one form to another. Which of the following correctly describes the transformation of energy when a person eats food and uses it to run?,
      options: [
        Chemical energy in food is converted to kinetic energy (movement) and thermal energy (heat) during running.,
        Kinetic energy in food is converted to potential energy during running.,
        Solar energy in food is converted to electrical energy during running.",
        "Potential energy in food is converted to light energy during running.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical energy in food is converted to kinetic energy (movement) and thermal energy (heat) during running."
    })
  },
  {
    id: "G8-IS-WEP-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Work", Energy, and Power",
    subtopic: "Work and Mechanical Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Work is done when a force causes an object to move in the direction of the applied force. Which of the following situations represents work being done according to the scientific definition of work?,
      options: [
        Pushing a box across the floor, where the force moves the box in the direction of the push.,
        Holding a heavy book stationary above your head without moving it.,
        "Pushing against a wall that does not move.,
        Carrying a bag of groceries while walking horizontally on a flat surface."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pushing a box across the floor, where the force moves the box in the direction of the push.
    })
  },
  {
    id: G8-IS-WEP-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Work, Energy, and Power,
    subtopic: "Potential and Kinetic Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Potential energy is stored energy, while kinetic energy is the energy of motion. Which of the following correctly describes the relationship between potential and kinetic energy as an object falls from a height?,
      options: [
        As the object falls, its potential energy decreases while its kinetic energy increases, keeping total mechanical energy constant (neglecting air resistance).,
        As the object falls, both potential and kinetic energy increase.,
        As the object falls, both potential and kinetic energy decrease.",
        "As the object falls, potential energy increases and kinetic energy decreases.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: As the object falls, its potential energy decreases while its kinetic energy increases, keeping total mechanical energy constant (neglecting air resistance)."
    })
  },
  {
    id: "G8-IS-WEP-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Work", Energy, and Power",
    subtopic: "Power Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Power is the rate at which work is done or energy is transferred. In the formula Power = Work done / Time taken, if the work done is constant, how does the power change when the time taken to do the work increases?,
      options: [
        "Power decreases when the time taken increases, as less work is done per unit of time.,
        Power increases when the time taken increases.",
        "Power remains constant regardless of the time taken.,
        Power is not affected by time in this formula."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Power decreases when the time taken increases, as less work is done per unit of time.
    })
  },
  {
    id: G8-IS-EM-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Electricity and Magnetism,
    subtopic: "Electromagnetism",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Electromagnetism is the relationship between electricity and magnetism, where electric current can create magnetic fields. Which of the following correctly describes the magnetic field produced around a straight current-carrying conductor?,
      options: [
        The magnetic field consists of concentric circular loops around the conductor, with the direction determined by the direction of the current (right-hand rule).,
        The magnetic field is a straight line extending from the conductor.,
        The magnetic field only exists inside the conductor.",
        "The magnetic field is perpendicular to the conductor and points outward in all directions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The magnetic field consists of concentric circular loops around the conductor, with the direction determined by the direction of the current (right-hand rule)."
    })
  },
  {
    id: "G8-IS-EM-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Electricity and Magnetism",
    subtopic: "Electromagnetic Induction,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Electromagnetic induction is the process of generating an electric current by changing a magnetic field. In a generator, which of the following movements is required to produce electricity through electromagnetic induction?,
      options: [
        Rotating a coil of wire within a magnetic field or moving a magnet near a coil of wire.,
        Keeping the coil of wire stationary inside a magnetic field.",
        "Moving the coil of wire away from the magnetic field.,
        Removing the magnet from the area entirely."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Rotating a coil of wire within a magnetic field or moving a magnet near a coil of wire.
    })
  },
  {
    id: G8-IS-EM-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Electricity and Magnetism,
    subtopic: "Electric Circuits and Power",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The relationship between voltage (V), current (I), and resistance (R) in an electric circuit is described by Ohm's Law. What is the formula for calculating power (P) in an electrical circuit?,
      options: [
        P = V × I, where power is the product of voltage and current.,
        P = V / I, where power is voltage divided by current.,
        P = I² × R, where power is the square of current times resistance.",
        "P = V² / R, where power is the square of voltage divided by resistance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: P = V × I, where power is the product of voltage and current."
    })
  },
  {
    id: "G8-IS-EM-04",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Electricity and Magnetism",
    subtopic: "Applications of Electromagnetism,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Electromagnetism has numerous practical applications in modern technology. Which of the following devices uses electromagnetism to convert electrical energy into mechanical energy?,
      options: [
        An electric motor, which uses the interaction between magnetic fields and current-carrying conductors to produce rotation.,
        A light bulb, which converts electrical energy to light and heat.,
        "A battery, which stores chemical energy and converts it to electrical energy.,
        A resistor, which limits the flow of current in a circuit."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An electric motor, which uses the interaction between magnetic fields and current-carrying conductors to produce rotation.
    })
  },
  {
    id: G8-IS-WS-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Waves and Sound,
    subtopic: "Wave Properties",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Waves are disturbances that transfer energy from one place to another without transferring matter. Which of the following correctly describes the difference between transverse and longitudinal waves?,
      options: [
        In transverse waves, particles vibrate perpendicular to the direction of wave propagation, while in longitudinal waves, particles vibrate parallel to the direction of wave propagation.,
        In transverse waves, particles vibrate parallel to the direction of wave propagation, while in longitudinal waves, particles vibrate perpendicular to the direction of wave propagation.,
        Both transverse and longitudinal waves have particles vibrating in the same direction as wave propagation.",
        "Both transverse and longitudinal waves have particles vibrating perpendicular to wave propagation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: In transverse waves, particles vibrate perpendicular to the direction of wave propagation, while in longitudinal waves, particles vibrate parallel to the direction of wave propagation."
    })
  },
  {
    id: "G8-IS-WS-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Waves and Sound",
    subtopic: "Sound Production and Propagation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sound waves are mechanical waves that require a medium to travel through. In which of the following mediums does sound travel the fastest, and why?,
      options: [
        Sound travels fastest in solids because particles are closely packed, allowing vibrations to be transmitted more quickly.,
        Sound travels fastest in gases because particles are far apart and move freely.",
        "Sound travels fastest in liquids because particles are in a fluid state.,
        Sound travels at the same speed in all mediums."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sound travels fastest in solids because particles are closely packed, allowing vibrations to be transmitted more quickly.
    })
  },
  {
    id: G8-IS-WS-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Waves and Sound,
    subtopic: "Sound Applications",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sound waves have various applications in medicine, communication, and navigation. Which technology uses sound waves with frequencies above the human hearing range to create images of internal body structures?,
      options: [
        Ultrasound, which uses high-frequency sound waves (ultrasonic waves) to produce images of internal organs and tissues.,
        X-ray imaging, which uses radiation to create images of bones.,
        MRI scanning, which uses magnetic fields to create images of soft tissues.",
        "ECG, which measures the electrical activity of the heart.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ultrasound, which uses high-frequency sound waves (ultrasonic waves) to produce images of internal organs and tissues."
    })
  },
  {
    id: "G8-IS-LO-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Light and Optics",
    subtopic: "Reflection of Light,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Reflection is the bouncing back of light rays when they strike a surface. According to the law of reflection, what is the relationship between the angle of incidence and the angle of reflection?,
      options: [
        The angle of incidence is equal to the angle of reflection when measured from the normal (perpendicular) to the reflecting surface.,
        The angle of incidence is always greater than the angle of reflection.",
        "The angle of incidence is always less than the angle of reflection.,
        The angle of incidence and the angle of reflection are unrelated."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The angle of incidence is equal to the angle of reflection when measured from the normal (perpendicular) to the reflecting surface.
    })
  },
  {
    id: G8-IS-LO-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Light and Optics,
    subtopic: "Refraction of Light",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refraction is the bending of light as it passes from one medium to another. When light travels from air into water, what happens to its speed and direction?,
      options: [
        Light slows down as it enters water and bends toward the normal (refracts) due to the change in the speed of light in different media.,
        Light speeds up as it enters water and bends away from the normal.,
        Light maintains the same speed and does not change direction.",
        "Light is completely reflected at the surface of the water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Light slows down as it enters water and bends toward the normal (refracts) due to the change in the speed of light in different media."
    })
  },
  {
    id: "G8-IS-LO-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Light and Optics",
    subtopic: "Lenses and Applications,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Lenses are optical devices that refract light to form images. Which type of lens is thicker at the center than at the edges and converges light rays to a focal point?,
      options: [
        A convex lens (converging lens), which bends parallel light rays so they meet at a focal point.,
        A concave lens (diverging lens), which spreads light rays away from a focal point.,
        "A cylindrical lens, which focuses light in only one direction.,
        A Fresnel lens, which is flat but acts like a convex lens."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A convex lens (converging lens), which bends parallel light rays so they meet at a focal point.
    })
  },
  {
    id: G8-IS-GE-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "Heredity and Genetics",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Genetics is the study of heredity and how traits are passed from parents to offspring. According to Mendelian genetics, which of the following correctly describes the principle of segregation?,
      options: [
        The principle of segregation states that during the formation of gametes, the two alleles for a trait separate (segregate) so that each gamete receives only one allele.,
        The principle of segregation states that alleles always blend together to produce intermediate traits.,
        The principle of segregation states that both alleles for a trait are always expressed in an individual.",
        "The principle of segregation states that traits are inherited from only one parent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The principle of segregation states that during the formation of gametes, the two alleles for a trait separate (segregate) so that each gamete receives only one allele."
    })
  },
  {
    id: "G8-IS-GE-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Genetics and Evolution",
    subtopic: "Variation and Natural Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Natural selection is the mechanism of evolution proposed by Charles Darwin. Which of the following describes how natural selection leads to the evolution of populations over time?,
      options: [
        Individuals with traits that provide advantages in their environment are more likely to survive and reproduce, passing these favorable traits to their offspring.,
        All individuals in a population have an equal chance of survival regardless of their traits.,
        "Environmental changes cause all individuals in a population to develop the same traits.,
        Natural selection only occurs in small populations with no genetic variation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Individuals with traits that provide advantages in their environment are more likely to survive and reproduce, passing these favorable traits to their offspring.
    })
  },
  {
    id: G8-IS-GE-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "Genetic Variation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Genetic variation within a population is essential for evolution and adaptation. Which of the following is the primary source of new genetic variation in a population?,
      options: [
        Mutations, which are random changes in the DNA sequence that introduce new alleles into the gene pool.,
        Artificial selection, where humans selectively breed organisms for desired traits.,
        Genetic drift, where allele frequencies change due to random events.",
        "Migration, where individuals move between populations.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mutations, which are random changes in the DNA sequence that introduce new alleles into the gene pool."
    })
  },
  {
    id: "G8-IS-ES-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Earth Science",
    subtopic: "Rocks and Minerals,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Rocks are classified into three main types based on their formation process. Which type of rock is formed from the cooling and solidification of magma or lava?,
      options: [
        Igneous rock, which forms from the crystallization of molten material (magma or lava).,
        Sedimentary rock, which forms from the compaction and cementation of sediments.,
        "Metamorphic rock, which forms from the transformation of existing rocks under heat and pressure.,
        Soil, which is formed from weathered rock and organic matter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Igneous rock, which forms from the crystallization of molten material (magma or lava).
    })
  },
  {
    id: G8-IS-ES-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Earth Science,
    subtopic: "Geological Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The Earth's surface is constantly changing due to various geological processes. Which of the following geological processes is responsible for the movement of the Earth's tectonic plates and the occurrence of earthquakes?,
      options: [
        Plate tectonics, where the Earth's lithosphere is divided into plates that move over the asthenosphere, causing earthquakes at plate boundaries.,
        Volcanic activity, which is caused by magma rising to the Earth's surface.,
        Weathering, which breaks down rocks at the Earth's surface.",
        "Erosion, which transports weathered materials from one place to another.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plate tectonics, where the Earth's lithosphere is divided into plates that move over the asthenosphere, causing earthquakes at plate boundaries."
    })
  },
  {
    id: "G8-IS-ES-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Earth Science",
    subtopic: "Weather and Climate,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Weather and climate are related but different concepts in Earth Science. Which of the following correctly distinguishes weather from climate?,
      options: [
        Weather is the short-term condition of the atmosphere at a specific time and place, while climate is the average weather conditions over a long period (typically 30 years or more).,
        Weather is the average conditions over a long period, while climate is the current atmospheric condition.,
        "Weather and climate are the same thing and can be used interchangeably.,
        Weather only refers to temperature, while climate only refers to precipitation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Weather is the short-term condition of the atmosphere at a specific time and place, while climate is the average weather conditions over a long period (typically 30 years or more).
    })
  },
  {
    id: G8-IS-SS-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Space Science,
    subtopic: "The Solar System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The solar system consists of the Sun and all the celestial bodies that orbit around it. Which of the following correctly describes the orbital relationship between the Sun, Earth, and Moon?,
      options: [
        The Earth orbits the Sun, and the Moon orbits the Earth, with the Moon's orbit around the Earth taking approximately one month.,
        The Sun orbits the Earth, and the Moon orbits the Sun.,
        The Earth and Moon both orbit the Sun independently.",
        "The Moon orbits the Sun directly, and the Earth is stationary.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Earth orbits the Sun, and the Moon orbits the Earth, with the Moon's orbit around the Earth taking approximately one month."
    })
  },
  {
    id: "G8-IS-SS-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Space Science",
    subtopic: "Stars and Galaxies,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Stars are massive, luminous spheres of plasma that produce energy through nuclear fusion. What is the primary source of energy produced in stars like the Sun?,
      options: [
        Nuclear fusion of hydrogen atoms into helium in the star's core, releasing vast amounts of energy.,
        Nuclear fission of heavy elements in the star's core.",
        "Chemical combustion of gases on the star's surface.,
        Reflection of light from other stars and celestial bodies."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nuclear fusion of hydrogen atoms into helium in the star's core, releasing vast amounts of energy.
    })
  },
  {
    id: G8-IS-SS-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Space Science,
    subtopic: "Space Exploration",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Space exploration has expanded human understanding of the universe and its phenomena. Which of the following was a significant achievement of the Apollo space missions?,
      options: [
        The Apollo 11 mission successfully landed the first humans on the Moon in 1969.,
        The Apollo missions sent the first satellite into Earth orbit.,
        The Apollo missions landed the first spacecraft on Mars.",
        "The Apollo missions established a permanent space station on the Moon.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Apollo 11 mission successfully landed the first humans on the Moon in 1969."
    })
  },
  {
    id: "G8-IS-SD-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Sustainable Development",
    subtopic: "Environmental Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable development aims to meet the needs of the present without compromising the ability of future generations to meet their own needs. Which of the following practices best promotes sustainable development in agriculture?,
      options: [
        Agroforestry, conservation agriculture, and organic farming that maintain soil health and biodiversity.,
        Intensive monoculture farming with heavy use of chemical fertilizers and pesticides.,
        "Clearing all natural vegetation for agricultural expansion without regard for environmental impact.,
        Using only traditional methods without incorporating modern sustainable techniques."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry, conservation agriculture, and organic farming that maintain soil health and biodiversity.
    })
  },
  {
    id: G8-IS-SD-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Sustainable Development,
    subtopic: "Renewable Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Renewable energy sources are important for reducing dependence on fossil fuels and mitigating climate change. Which of the following is an example of a renewable energy source that uses the Earth's internal heat?,
      options: [
        Geothermal energy, which harnesses heat from the Earth's interior for electricity generation and heating.,
        Solar energy, which uses sunlight to generate electricity.,
        Wind energy, which uses wind to turn turbines and generate electricity.",
        "Hydroelectric energy, which uses flowing water to generate electricity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Geothermal energy, which harnesses heat from the Earth's interior for electricity generation and heating."
    })
  },
  {
    id: "G8-IS-SD-03",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Sustainable Development",
    subtopic: "Waste Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper waste management is essential for environmental sustainability and human health. Which of the following waste management practices follows the principles of reduce, reuse, and recycle (the 3Rs)?,
      options: [
        "Reducing the amount of waste produced, reusing items instead of discarding them, and recycling materials to make new products.,
        Burning all waste materials to reduce their volume.",
        "Dumping all waste in landfills without any treatment or sorting.,
        Exporting waste to other countries for disposal."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Reducing the amount of waste produced, reusing items instead of discarding them, and recycling materials to make new products.
    })
  },
  {
    id: G8-IS-HD-01",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Chronic Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chronic diseases such as heart disease, diabetes, and cancer are leading causes of death worldwide. Which of the following lifestyle choices can significantly reduce the risk of developing type 2 diabetes?,
      options: [
        Maintaining a healthy weight, exercising regularly, eating a balanced diet, and limiting sugar and processed foods.,
        Eating large amounts of sugar and fatty foods regularly.,
        Living a sedentary lifestyle with little or no physical activity.",
        "Smoking and consuming alcohol on a regular basis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maintaining a healthy weight, exercising regularly, eating a balanced diet, and limiting sugar and processed foods."
    })
  },
  {
    id: "G8-IS-HD-02",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Health and Disease",
    subtopic: "Non-Communicable Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Non-communicable diseases (NCDs) are not caused by infectious agents and are often linked to lifestyle factors. Which of the following is a major risk factor for both cardiovascular disease and certain types of cancer?,
      options: [
        Tobacco use, which damages blood vessels, increases blood pressure, and contains carcinogens.,
        Regular physical exercise, which improves overall health.,
        "Consumption of fruits and vegetables, which provides essential vitamins.,
        Getting adequate sleep, which allows the body to recover."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tobacco use, which damages blood vessels, increases blood pressure, and contains carcinogens.
    })
  },
  {
    id: G8-IS-HD-03",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Health and Disease,
    subtopic: "Public Health Measures",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Public health measures aim to prevent disease and promote health at the community level. Which of the following is an example of a primary prevention measure that addresses the root causes of disease?,
      options: [
        Health education campaigns that promote healthy eating and discourage smoking and excessive alcohol consumption.,
        Screening programs that detect diseases at an early stage.,
        Medical treatment of diseases after they have developed.",
        "Rehabilitation programs for people recovering from illness.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Health education campaigns that promote healthy eating and discourage smoking and excessive alcohol consumption."
    })
  },
  {
    id: "G8-IS-SI-01",
    grade: "Grade 8",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Advanced Scientific Skills,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Advanced scientific investigation requires careful planning, precise measurement, and thorough data analysis. What is the purpose of using a control group in a scientific experiment?,
      options: [
        "To serve as a baseline for comparison to determine whether the independent variable had an effect on the dependent variable.,
        To ensure that all variables are changed simultaneously during the experiment.",
        "To provide a subject that receives the maximum treatment.,
        To eliminate the need for replication of the experiment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "To serve as a baseline for comparison to determine whether the independent variable had an effect on the dependent variable.
    })
  },
  {
    id: G8-IS-SI-02",
    grade: "Grade 8,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Data Interpretation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Interpreting experimental data requires understanding patterns, relationships, and potential sources of error. When analyzing data from an experiment, how should outliers (extreme values that differ significantly from other observations) be treated?,
      options: [
        Outliers should be examined carefully to determine if they resulted from experimental errors or represent meaningful data, and reported honestly in the results.,
        Outliers should always be removed from the data set without explanation.,
        Outliers should be ignored as they cannot affect the overall results.",
        "Outliers should be replaced with the average value of the other data points.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Outliers should be examined carefully to determine if they resulted from experimental errors or represent meaningful data, and reported honestly in the results."
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD INTEGRATED SCIENCE SYLLABUS)
  // =========================================================================

  // --- SCIENTIFIC INVESTIGATION (3 Materials) ---
  {
    id: "G9-IS-SI-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Scientific Methodology,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Scientific investigation requires rigorous methodology to ensure reliable and valid results. Which of the following is the most important characteristic of a well-designed scientific experiment that allows the researcher to draw meaningful conclusions?,
      options: [
        The experiment must have a clear research question, a testable hypothesis, controlled variables, sufficient replication, and appropriate data analysis methods.,
        The experiment should be completed as quickly as possible without attention to detail.,
        "The experiment should only use complex equipment regardless of the research question.,
        The experiment should rely on personal opinions rather than empirical evidence."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The experiment must have a clear research question, a testable hypothesis, controlled variables, sufficient replication, and appropriate data analysis methods.
    })
  },
  {
    id: G9-IS-SI-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Scientific Investigation,
    subtopic: "Experimental Design",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Experimental design involves planning the structure of an investigation to test a hypothesis effectively. In a randomized controlled trial, what is the primary purpose of randomly assigning participants to experimental and control groups?,
      options: [
        To minimize bias and ensure that the groups are comparable at the start of the experiment, so that any observed differences can be attributed to the treatment.,
        To make the experiment easier to conduct without concern for group composition.,
        To ensure that all participants receive the same treatment regardless of group assignment.",
        "To increase the number of variables that can be studied simultaneously.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: To minimize bias and ensure that the groups are comparable at the start of the experiment, so that any observed differences can be attributed to the treatment."
    })
  },
  {
    id: "G9-IS-SI-03",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Scientific Investigation",
    subtopic: "Data Analysis and Presentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Data analysis and presentation are crucial steps in scientific investigation that allow researchers to communicate their findings clearly. Which of the following statistical measures is most appropriate for describing the central tendency of a data set that contains outliers?,
      options: [
        The median, which is less affected by extreme values than the mean, provides a better measure of central tendency for skewed distributions.,
        The mean, which is always the best measure regardless of the data distribution.,
        "The mode, which identifies the most frequently occurring value.,
        The range, which measures the spread of the data."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The median, which is less affected by extreme values than the mean, provides a better measure of central tendency for skewed distributions.
    })
  },

  // --- CELL BIOLOGY (3 Materials) ---
  {
    id: G9-IS-CB-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Cell Biology,
    subtopic: "Cell Membrane Transport",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The cell membrane is selectively permeable, controlling the movement of substances into and out of the cell. Which of the following describes the process of osmosis and its importance to living cells?,
      options: [
        Osmosis is the net movement of water molecules from a region of higher water concentration to a region of lower water concentration through a selectively permeable membrane, essential for maintaining cellular hydration and turgor pressure.,
        Osmosis is the movement of solute molecules from a region of higher concentration to a region of lower concentration.,
        Osmosis is the active transport of ions across the cell membrane using energy from ATP.",
        "Osmosis is the process by which cells engulf large particles through the cell membrane.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Osmosis is the net movement of water molecules from a region of higher water concentration to a region of lower water concentration through a selectively permeable membrane, essential for maintaining cellular hydration and turgor pressure."
    })
  },
  {
    id: "G9-IS-CB-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Cell Biology",
    subtopic: "Cell Division - Mitosis,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Mitosis is a type of cell division that results in two genetically identical daughter cells. Which of the following correctly describes the role of mitosis in growth and repair in multicellular organisms?,
      options: [
        Mitosis produces new cells for growth, tissue repair, and replacement of worn-out cells, maintaining the genetic stability of the organism.,
        Mitosis produces gametes (sperm and egg cells) for sexual reproduction.,
        "Mitosis results in cells with half the number of chromosomes as the parent cell.,
        Mitosis only occurs in plants and is not found in animals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mitosis produces new cells for growth, tissue repair, and replacement of worn-out cells, maintaining the genetic stability of the organism.
    })
  },
  {
    id: G9-IS-CB-03",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Cell Biology,
    subtopic: "Cell Division - Meiosis",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Meiosis is a specialized form of cell division that produces gametes for sexual reproduction. How does meiosis contribute to genetic diversity in a population?,
      options: [
        Meiosis introduces genetic variation through crossing over (exchange of genetic material between homologous chromosomes) and independent assortment of chromosomes during gamete formation.,
        Meiosis produces identical copies of the parent cell, maintaining genetic uniformity.,
        Meiosis prevents any genetic recombination from occurring.",
        "Meiosis only occurs in somatic (body) cells and does not affect genetic diversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Meiosis introduces genetic variation through crossing over (exchange of genetic material between homologous chromosomes) and independent assortment of chromosomes during gamete formation."
    })
  },

  // --- NUTRITION AND DIGESTION (3 Materials) ---
  {
    id: "G9-IS-ND-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Nutrition and Digestion",
    subtopic: "Macronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Macronutrients are nutrients required in large amounts by the body for energy and growth. Which of the following correctly describes the role of proteins as macronutrients in the human body?,
      options: [
        Proteins are essential for building and repairing tissues, producing enzymes and hormones, and supporting immune function. They are made up of amino acids and provide 4 calories per gram.,
        Proteins are the body's primary source of quick energy and are stored as glycogen.,
        "Proteins are only needed in small amounts and are not essential for growth.,
        Proteins provide 9 calories per gram and are primarily used for energy storage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Proteins are essential for building and repairing tissues, producing enzymes and hormones, and supporting immune function. They are made up of amino acids and provide 4 calories per gram.
    })
  },
  {
    id: G9-IS-ND-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Nutrition and Digestion,
    subtopic: "Micronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Micronutrients are essential vitamins and minerals required in small amounts for proper body function. Which of the following is the primary function of vitamin D in the human body?,
      options: [
        Vitamin D promotes the absorption of calcium and phosphorus from food, which is essential for bone health and calcium homeostasis.,
        Vitamin D acts as an antioxidant and protects cells from damage.,
        Vitamin D is necessary for blood clotting and wound healing.",
        "Vitamin D is involved in the synthesis of neurotransmitters.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Vitamin D promotes the absorption of calcium and phosphorus from food, which is essential for bone health and calcium homeostasis."
    })
  },
  {
    id: "G9-IS-ND-03",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Nutrition and Digestion",
    subtopic: "The Digestive Process,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Digestion involves both mechanical and chemical processes that break down food into absorbable nutrients. Which of the following correctly describes the role of bile in the digestion of lipids (fats)?,
      options: [
        Bile, produced by the liver and stored in the gallbladder, emulsifies fats by breaking them into smaller droplets, increasing the surface area for lipase enzymes to act on them.,
        Bile directly breaks down fats into fatty acids and glycerol.,
        "Bile neutralizes stomach acid in the small intestine.,
        Bile is an enzyme that digests proteins in the stomach."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bile, produced by the liver and stored in the gallbladder, emulsifies fats by breaking them into smaller droplets, increasing the surface area for lipase enzymes to act on them.
    })
  },

  // --- TRANSPORT AND RESPIRATION (3 Materials) ---
  {
    id: G9-IS-TR-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Transport and Respiration,
    subtopic: "The Circulatory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The circulatory system transports oxygen, nutrients, and waste products throughout the body. Which of the following describes the function of red blood cells and the role of hemoglobin in oxygen transport?,
      options: [
        Red blood cells contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport.,
        Red blood cells are responsible for defending the body against infections.,
        Red blood cells produce antibodies against pathogens.",
        "Red blood cells transport carbon dioxide from the lungs to the body tissues.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Red blood cells contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport."
    })
  },
  {
    id: "G9-IS-TR-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Transport and Respiration",
    subtopic: "The Respiratory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The respiratory system facilitates gas exchange between the body and the environment. In which part of the respiratory system does gas exchange occur, and what structural features make it efficient?,
      options: [
        Gas exchange occurs in the alveoli, which are thin-walled, highly vascularized air sacs with a large surface area, allowing efficient diffusion of oxygen into the blood and carbon dioxide out of the blood.,
        Gas exchange occurs in the trachea, where air is filtered and moistened.",
        "Gas exchange occurs in the bronchi, which are large air passages leading to the lungs.,
        Gas exchange occurs in the nasal cavity, where air is warmed and humidified."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gas exchange occurs in the alveoli, which are thin-walled, highly vascularized air sacs with a large surface area, allowing efficient diffusion of oxygen into the blood and carbon dioxide out of the blood.
    })
  },
  {
    id: G9-IS-TR-03",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Transport and Respiration,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Plants have specialized transport tissues that move water, minerals, and nutrients throughout the plant. What is the driving force for the movement of water up the xylem vessels from the roots to the leaves?,
      options: [
        Transpiration pull, created by the evaporation of water from the leaves, generates a negative pressure that draws water up through the xylem vessels from the roots.,
        Active transport, which uses energy to pump water against gravity.,
        Root pressure, which pushes water up the stem from the roots.",
        "Capillary action alone, which moves water through narrow tubes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Transpiration pull, created by the evaporation of water from the leaves, generates a negative pressure that draws water up through the xylem vessels from the roots."
    })
  },

  // --- HOMEOSTASIS (2 Materials) ---
  {
    id: "G9-IS-HO-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Homeostasis",
    subtopic: "Thermoregulation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Thermoregulation is the ability of an organism to maintain its body temperature within a narrow range despite changes in environmental temperature. Which of the following mechanisms is used by the human body to cool down when core body temperature rises above normal?,
      options: [
        Vasodilation of blood vessels near the skin surface to increase heat loss, sweating to remove heat through evaporation, and decreased metabolic heat production.,
        Vasoconstriction of blood vessels to reduce heat loss to the environment.,
        "Shivering to generate additional heat through muscle contraction.,
        Piloerection (goosebumps) to trap a layer of warm air near the skin."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vasodilation of blood vessels near the skin surface to increase heat loss, sweating to remove heat through evaporation, and decreased metabolic heat production.
    })
  },
  {
    id: G9-IS-HO-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Homeostasis,
    subtopic: "Osmoregulation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Osmoregulation is the control of water and salt balance in the body. Which of the following describes the role of the kidney and antidiuretic hormone (ADH) in regulating water balance in the human body?,
      options: [
        When the body is dehydrated, ADH is released to increase water reabsorption in the kidneys, producing concentrated urine to conserve water.,
        When the body is dehydrated, ADH decreases water reabsorption, producing dilute urine.,
        The kidneys produce ADH to regulate salt concentration in the blood.",
        "The kidneys have no role in water balance regulation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: When the body is dehydrated, ADH is released to increase water reabsorption in the kidneys, producing concentrated urine to conserve water."
    })
  },

  // --- REPRODUCTION AND GROWTH (3 Materials) ---
  {
    id: "G9-IS-RG-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Reproduction and Growth",
    subtopic: "Human Reproduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Human reproduction involves the fusion of male and female gametes to form a zygote. Which of the following correctly describes the path of a sperm cell from its production to fertilization?,
      options: [
        Sperm cells are produced in the testes, stored in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to meet an egg cell in the fallopian tube for fertilization.,
        Sperm cells are produced in the ovaries and travel directly to the fallopian tubes.,
        "Sperm cells are produced in the prostate gland and released through the urethra.,
        Sperm cells are produced in the seminal vesicles and travel to the uterus for fertilization."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sperm cells are produced in the testes, stored in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to meet an egg cell in the fallopian tube for fertilization.
    })
  },
  {
    id: G9-IS-RG-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Reproduction and Growth,
    subtopic: "Fertilization and Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Fertilization is the fusion of a sperm and an egg to form a zygote, which then undergoes development. In which part of the female reproductive system does fertilization typically occur?,
      options: [
        Fertilization typically occurs in the fallopian tube (ampulla), where the sperm and egg meet and fuse to form a zygote.,
        Fertilization occurs in the uterus, where the embryo implants.,
        Fertilization occurs in the ovary, where the egg is released.",
        "Fertilization occurs in the vagina, where sperm are deposited.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Fertilization typically occurs in the fallopian tube (ampulla), where the sperm and egg meet and fuse to form a zygote."
    })
  },
  {
    id: "G9-IS-RG-03",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Reproduction and Growth",
    subtopic: "Growth and Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Growth and development in humans occur in distinct stages with characteristic changes. Which of the following best describes the changes that occur during adolescence (puberty)?,
      options: [
        Adolescence is marked by significant physical changes, including growth spurts, development of secondary sexual characteristics, hormonal changes, and cognitive development.,
        Adolescence is characterized by no significant physical changes.,
        "Adolescence is a period where physical growth slows down compared to childhood.,
        Adolescence occurs only in males and involves no significant hormonal changes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Adolescence is marked by significant physical changes, including growth spurts, development of secondary sexual characteristics, hormonal changes, and cognitive development.
    })
  },

  // --- GENETICS AND EVOLUTION (3 Materials) ---
  {
    id: G9-IS-GE-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "DNA Structure and Function",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " DNA (deoxyribonucleic acid) is the hereditary material that carries genetic information in all living organisms. Which of the following correctly describes the structure of DNA and the pairing of its nitrogenous bases?,
      options: [
        DNA has a double helix structure with complementary base pairing: adenine pairs with thymine (A-T) and guanine pairs with cytosine (G-C) via hydrogen bonds.,
        DNA is a single-stranded molecule with base pairing: adenine pairs with guanine (A-G) and thymine pairs with cytosine (T-C).,
        DNA has a triple helix structure with base pairing: adenine pairs with uracil (A-U) and cytosine pairs with guanine (C-G).",
        "DNA is a linear molecule with no specific base pairing rules.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: DNA has a double helix structure with complementary base pairing: adenine pairs with thymine (A-T) and guanine pairs with cytosine (G-C) via hydrogen bonds."
    })
  },
  {
    id: "G9-IS-GE-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Genetics and Evolution",
    subtopic: "Inheritance Patterns,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Inheritance patterns describe how traits are passed from parents to offspring through genes. In a monohybrid cross between two heterozygous organisms (Aa × Aa), what is the expected phenotypic ratio of dominant to recessive traits in the offspring, according to Mendelian genetics?,
      options: [
        "The expected phenotypic ratio is 3:1, with three offspring showing the dominant trait for every one offspring showing the recessive trait.,
        The expected phenotypic ratio is 1:1, with equal numbers of dominant and recessive phenotypes.",
        "The expected phenotypic ratio is 9:3:3:1, typical of dihybrid crosses.,
        The expected phenotypic ratio is 1:2:1, representing the genotype ratio."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The expected phenotypic ratio is 3:1, with three offspring showing the dominant trait for every one offspring showing the recessive trait.
    })
  },
  {
    id: G9-IS-GE-03",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Genetics and Evolution,
    subtopic: "Evolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Evolution is the process by which species change over time through natural selection and other mechanisms. Which of the following provides the strongest evidence for evolution through natural selection?,
      options: [
        Fossil records that show gradual changes in organisms over geological time, along with the observation of natural selection in action in real-time (e.g., antibiotic resistance in bacteria, peppered moth color changes).,
        The existence of identical species in all parts of the world.,
        The lack of any changes in species over long periods of time.",
        "The theory that all organisms were created in their current form and have not changed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Fossil records that show gradual changes in organisms over geological time, along with the observation of natural selection in action in real-time (e.g., antibiotic resistance in bacteria, peppered moth color changes)."
    })
  },

  // --- ECOLOGY AND CONSERVATION (2 Materials) ---
  {
    id: "G9-IS-EC-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Ecology and Conservation",
    subtopic: "Ecosystems,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Ecosystems are complex communities of organisms interacting with their environment. Which of the following correctly describes the flow of energy through an ecosystem and the role of decomposers in nutrient cycling?,
      options: [
        Energy flows through an ecosystem from producers to consumers to decomposers, with decomposers breaking down dead organic matter and returning nutrients to the soil for reuse by producers.,
        Energy flows in a circular pattern within an ecosystem with no loss.,
        "Energy is destroyed as it moves through the ecosystem.,
        Decomposers are not part of the energy flow in an ecosystem."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Energy flows through an ecosystem from producers to consumers to decomposers, with decomposers breaking down dead organic matter and returning nutrients to the soil for reuse by producers.
    })
  },
  {
    id: G9-IS-EC-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Ecology and Conservation,
    subtopic: "Conservation Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Biodiversity conservation is essential for maintaining ecosystem services and ecological resilience. Which of the following conservation strategies is most effective for protecting biodiversity in both terrestrial and aquatic ecosystems?,
      options: [
        Establishing protected areas such as national parks and marine reserves, enforcing anti-poaching laws, promoting habitat restoration, and engaging local communities in conservation efforts.,
        Removing all human presence from conservation areas.,
        Only focusing on protecting a single species without consideration of its habitat.",
        "Promoting unsustainable resource extraction to benefit local economies.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Establishing protected areas such as national parks and marine reserves, enforcing anti-poaching laws, promoting habitat restoration, and engaging local communities in conservation efforts."
    })
  },

  // --- CHEMISTRY BASICS (3 Materials) ---
  {
    id: "G9-IS-CB-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Chemistry Basics",
    subtopic: "Atomic Structure,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Atomic structure forms the foundation of chemistry and explains how elements interact. Which of the following correctly describes the arrangement of electrons in an atom and the concept of electron shells or energy levels?,
      options: [
        Electrons are arranged in shells (energy levels) around the nucleus, with the outermost shell determining the chemical reactivity of the atom (valence electrons).,
        Electrons are randomly distributed throughout the atom without any specific arrangement.,
        "Electrons are all located in the nucleus along with protons and neutrons.,
        Electrons are arranged in shells with no relationship to chemical reactivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Electrons are arranged in shells (energy levels) around the nucleus, with the outermost shell determining the chemical reactivity of the atom (valence electrons).
    })
  },
  {
    id: G9-IS-CB-02",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Chemistry Basics,
    subtopic: "Chemical Bonding",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Chemical bonding involves the formation of bonds between atoms to achieve stability. Which of the following correctly describes the difference between ionic and covalent bonds?,
      options: [
        Ionic bonds form when electrons are transferred from one atom to another, creating oppositely charged ions that attract each other, while covalent bonds form when atoms share electrons to achieve a stable electron configuration.,
        Ionic bonds involve sharing of electrons, while covalent bonds involve electron transfer.,
        Ionic and covalent bonds are the same type of chemical bond.",
        "Ionic bonds only occur in elements with similar electronegativity values.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ionic bonds form when electrons are transferred from one atom to another, creating oppositely charged ions that attract each other, while covalent bonds form when atoms share electrons to achieve a stable electron configuration."
    })
  },
  {
    id: "G9-IS-CB-03",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Chemistry Basics",
    subtopic: "The Periodic Table,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The Periodic Table organizes elements by their atomic number and chemical properties. Elements in the same group (vertical column) of the Periodic Table have similar chemical properties because they have the same number of what?,
      options: [
        Elements in the same group have the same number of valence electrons, which determines their chemical reactivity and bonding behavior.,
        Elements in the same group have the same number of protons.,
        "Elements in the same group have the same atomic mass.,
        Elements in the same group have the same number of electron shells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Elements in the same group have the same number of valence electrons, which determines their chemical reactivity and bonding behavior.
    })
  },

  // --- CHEMICAL REACTIONS (2 Materials) ---
  {
    id: G9-IS-CR-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Chemical Reactions,
    subtopic: "Reaction Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chemical reactions can be classified based on the changes that occur during the reaction. Which of the following is an example of a displacement reaction, and what happens during this type of reaction?,
      options: [
        A displacement reaction occurs when a more reactive element displaces a less reactive element from its compound, such as iron displacing copper from copper sulfate solution (Fe + CuSO₄ → FeSO₄ + Cu).,
        A displacement reaction involves the combination of two elements to form a single compound.,
        A displacement reaction results in the decomposition of a compound into its elements.",
        "A displacement reaction is the burning of a substance in oxygen.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A displacement reaction occurs when a more reactive element displaces a less reactive element from its compound, such as iron displacing copper from copper sulfate solution (Fe + CuSO₄ → FeSO₄ + Cu)."
    })
  },
  {
    id: "G9-IS-CR-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Chemical Reactions",
    subtopic: "Energy Changes,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Chemical reactions involve energy changes, either releasing or absorbing energy. What is the difference between exothermic and endothermic reactions in terms of energy exchange with the surroundings?,
      options: [
        Exothermic reactions release energy to the surroundings (often as heat), while endothermic reactions absorb energy from the surroundings.,
        Exothermic reactions absorb energy from the surroundings, while endothermic reactions release energy.",
        "Both exothermic and endothermic reactions release the same amount of energy.,
        Exothermic reactions convert matter to energy, while endothermic reactions convert energy to matter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Exothermic reactions release energy to the surroundings (often as heat), while endothermic reactions absorb energy from the surroundings.
    })
  },

  // --- ACIDS, BASES, AND SALTS (2 Materials) ---
  {
    id: G9-IS-ABS-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Acids, Bases, and Salts,
    subtopic: "Properties",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Acids and bases have distinct properties that determine their behavior and applications. Which of the following correctly describes the pH scale and the relationship between pH and the concentration of hydrogen ions (H⁺) in a solution?,
      options: [
        The pH scale ranges from 0 to 14, with lower pH values indicating higher H⁺ concentration (more acidic) and higher pH values indicating lower H⁺ concentration (more basic/alkaline).,
        The pH scale ranges from 0 to 14, with higher pH values indicating higher H⁺ concentration.,
        The pH scale is unrelated to H⁺ concentration.",
        "The pH scale only measures the concentration of hydroxide ions (OH⁻).
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The pH scale ranges from 0 to 14, with lower pH values indicating higher H⁺ concentration (more acidic) and higher pH values indicating lower H⁺ concentration (more basic/alkaline)."
    })
  },
  {
    id: "G9-IS-ABS-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Acids", Bases, and Salts",
    subtopic: "Preparation and Uses,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Salts are formed through reactions between acids and bases (neutralization reactions). Which of the following describes the preparation of a salt by the reaction of an acid with a base (neutralization), and what are the products of this reaction?,
      options: [
        Neutralization is the reaction of an acid with a base to produce a salt and water, such as HCl + NaOH → NaCl + H₂O.,
        Neutralization produces a salt and carbon dioxide.",
        "Neutralization produces a salt and hydrogen gas.,
        Neutralization produces a salt and oxygen gas."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Neutralization is the reaction of an acid with a base to produce a salt and water, such as HCl + NaOH → NaCl + H₂O.
    })
  },

  // --- FORCES AND MOTION (2 Materials) ---
  {
    id: G9-IS-FM-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Forces and Motion,
    subtopic: "Newton's Laws of Motion",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Newton's laws of motion describe the relationship between forces and the motion of objects. Which of the following correctly states Newton's Second Law of Motion and its mathematical representation?,
      options: [
        Newton's Second Law states that the acceleration of an object is directly proportional to the net force applied and inversely proportional to its mass (F = ma).,
        Newton's Second Law states that an object will remain at rest or in uniform motion unless acted upon by an external force.,
        Newton's Second Law states that for every action, there is an equal and opposite reaction.",
        "Newton's Second Law states that the velocity of an object is constant regardless of forces applied.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Newton's Second Law states that the acceleration of an object is directly proportional to the net force applied and inversely proportional to its mass (F = ma)."
    })
  },
  {
    id: "G9-IS-FM-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Forces and Motion",
    subtopic: "Applications,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Newton's laws have numerous applications in everyday life and technology. Which of the following applications correctly uses Newton's Third Law (action and reaction)?,
      options: [
        A rocket launches upward because the exhaust gases are pushed downward (action), and the rocket is pushed upward by an equal and opposite force (reaction).,
        A car travels at constant speed because no forces are acting on it.,
        "An apple falls from a tree because of gravity alone.,
        A book rests on a table because the table applies a force greater than the book's weight."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A rocket launches upward because the exhaust gases are pushed downward (action), and the rocket is pushed upward by an equal and opposite force (reaction).
    })
  },

  // --- WORK, ENERGY, AND POWER (2 Materials) ---
  {
    id: G9-IS-WEP-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Work, Energy, and Power,
    subtopic: "Energy Conversions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Energy conversion is the transformation of energy from one form to another. Which of the following correctly describes the series of energy conversions that occur in a hydroelectric power station?,
      options: [
        Potential energy of water stored in a dam → Kinetic energy of flowing water → Mechanical energy of turbine → Electrical energy in the generator.,
        Kinetic energy of water → Electrical energy directly without mechanical energy.,
        Chemical energy of water → Electrical energy → Mechanical energy.",
        "Nuclear energy of water → Thermal energy → Electrical energy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Potential energy of water stored in a dam → Kinetic energy of flowing water → Mechanical energy of turbine → Electrical energy in the generator."
    })
  },
  {
    id: "G9-IS-WEP-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Work", Energy, and Power",
    subtopic: "Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Power is the rate at which work is done or energy is transferred. If a motor lifts a load of 500 N to a height of 10 m in 5 seconds, what is the power output of the motor? (Use g = 10 m/s² and the formula Power = Work/Time.),
      options: [
        Power = 1000 W (1 kW), because Work = Force × Distance = 500 N × 10 m = 5000 J, and Power = 5000 J/5 s = 1000 W.,
        Power = 500 W, because Work = 2500 J divided by 5 seconds.",
        "Power = 2000 W, because Work = 10,000 J divided by 5 seconds.,
        Power = 100 W, because Work = 500 J divided by 5 seconds."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Power = 1000 W (1 kW), because Work = Force × Distance = 500 N × 10 m = 5000 J, and Power = 5000 J/5 s = 1000 W.
    })
  },

  // --- ELECTRICITY AND MAGNETISM (2 Materials) ---
  {
    id: G9-IS-EM-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Electricity and Magnetism,
    subtopic: "Ohm's Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Ohm's Law describes the relationship between voltage, current, and resistance in an electrical circuit. If a circuit has a voltage of 12 V and a resistance of 4 Ω, what is the current flowing through the circuit according to Ohm's Law (V = IR)?,
      options: [
        Current = 3 A, because I = V/R = 12 V / 4 Ω = 3 A.,
        Current = 48 A, because I = V × R = 12 V × 4 Ω = 48 A.,
        Current = 0.33 A, because I = R/V = 4 Ω / 12 V = 0.33 A.",
        "Current = 16 A, because I = V + R = 12 V + 4 Ω = 16 A.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Current = 3 A, because I = V/R = 12 V / 4 Ω = 3 A."
    })
  },
  {
    id: "G9-IS-EM-02",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Electricity and Magnetism",
    subtopic: "Magnetism,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Magnetism is a fundamental force that results from the movement of electric charges. Which of the following correctly describes the magnetic field of a bar magnet and how it affects magnetic materials?,
      options: [
        A bar magnet has a magnetic field that forms continuous loops from the north pole to the south pole outside the magnet and from south to north inside the magnet, attracting magnetic materials such as iron, nickel, and cobalt.,
        A bar magnet has magnetic field lines that are straight and parallel.,
        "A bar magnet only attracts materials that are charged with electricity.,
        A bar magnet has no effect on any materials near it."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A bar magnet has a magnetic field that forms continuous loops from the north pole to the south pole outside the magnet and from south to north inside the magnet, attracting magnetic materials such as iron, nickel, and cobalt.
    })
  },

  // --- WAVES AND SOUND (1 Material) ---
  {
    id: G9-IS-WS-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Waves and Sound,
    subtopic: "Wave Properties",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Wave properties such as frequency, wavelength, and speed are interconnected through the wave equation. If a sound wave has a frequency of 440 Hz and a wavelength of 0.78 m, what is the speed of the sound wave, and how is it calculated using the wave equation (v = f × λ)?,
      options: [
        Speed = 343.2 m/s, because v = 440 Hz × 0.78 m = 343.2 m/s.,
        Speed = 564.1 m/s, because v = 440 Hz / 0.78 m = 564.1 m/s.,
        Speed = 339.2 m/s, because v = 0.78 m × 440 Hz = 339.2 m/s.",
        "Speed = 220 m/s, because v = 440 Hz / 2 = 220 m/s.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Speed = 343.2 m/s, because v = 440 Hz × 0.78 m = 343.2 m/s."
    })
  },

  // --- LIGHT AND OPTICS (1 Material) ---
  {
    id: "G9-IS-LO-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Light and Optics",
    subtopic: "Optical Devices,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Optical devices use lenses and mirrors to manipulate light for various applications. Which of the following correctly describes how a compound microscope uses multiple lenses to produce a magnified image of a small specimen?,
      options: [
        A compound microscope uses two convex lenses: the objective lens forms a magnified real image, which is further magnified by the eyepiece lens to produce a virtual image.,
        A compound microscope uses one concave lens and one convex lens.,
        "A compound microscope uses mirrors only without any lenses.,
        A compound microscope produces a reduced, inverted image of the specimen."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A compound microscope uses two convex lenses: the objective lens forms a magnified real image, which is further magnified by the eyepiece lens to produce a virtual image.
    })
  },

  // --- EARTH AND SPACE SCIENCE (1 Material) ---
  {
    id: G9-IS-ESS-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Earth and Space Science,
    subtopic: "Geological Time",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The geological time scale organizes Earth's history into time periods based on significant geological and biological events. Which of the following correctly describes the relationship between eras, periods, and epochs in the geological time scale?,
      options: [
        Eras are divided into periods, and periods are further divided into epochs, with each division representing a significant stage in Earth's geological and biological history.,
        Epochs are the largest units and contain eras within them.,
        Periods and eras are the same thing in the geological time scale.",
        "The geological time scale is not divided into any sub-units.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Eras are divided into periods, and periods are further divided into epochs, with each division representing a significant stage in Earth's geological and biological history."
    })
  },

  // --- HEALTH AND DISEASE (1 Material) ---
  {
    id: "G9-IS-HD-01",
    grade: "Grade 9",
    subject: "Integrated Science",
    topic: "Health and Disease",
    subtopic: "Disease Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Preventing the spread of infectious diseases requires a multi-faceted approach. Which of the following represents the most comprehensive strategy for controlling the transmission of infectious diseases such as cholera and typhoid that are transmitted through contaminated water?,
      options: [
        Ensuring access to clean water, proper sanitation and hygiene, promoting handwashing, providing education on safe water handling, and implementing vaccination programs where available.,
        Only taking antibiotics after getting sick.,
        "Avoiding all contact with other people.,
        Only relying on natural immunity without any preventive measures."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ensuring access to clean water, proper sanitation and hygiene, promoting handwashing, providing education on safe water handling, and implementing vaccination programs where available.
    })
  },

  // --- SUSTAINABLE DEVELOPMENT (1 Material) ---
  {
    id: G9-IS-SD-01",
    grade: "Grade 9,
    subject: Integrated Science",
    topic: "Sustainable Development,
    subtopic: "Environmental Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Environmental management involves the sustainable use and protection of natural resources. Which of the following best describes the concept of the circular economy and its application to waste management?,
      options: [
        The circular economy is a model that aims to eliminate waste by designing products for reuse, repair, and recycling, keeping materials in use for as long as possible and regenerating natural systems.,
        The circular economy is a linear model where materials are used once and discarded.,
        The circular economy focuses on maximizing waste generation.",
        "The circular economy only applies to plastic products.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The circular economy is a model that aims to eliminate waste by designing products for reuse, repair, and recycling, keeping materials in use for as long as possible and regenerating natural systems."
    })
  }

];


