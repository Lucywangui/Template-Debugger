export const hygieneAndNutritionTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (KICD HYGIENE AND NUTRITION SYLLABUS)
  // =========================================================================

  // --- STRAND 1: HEALTHY PRACTICES ---

  // --- 1.1 HEALTHY HABITS (4 Materials) ---
  {
    id: "G1-HN-HAB-01",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Healthy Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: "Healthy habits help us stay strong and avoid getting sick. Which of the following is a healthy habit that we should practice every day?,
      options: [Washing our hands., Playing in the mud., "Eating dirty food., Not sleeping."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing our hands.
    })
  },
  {
    id: G1-HN-HAB-02",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Healthy Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We should always wash our hands at certain times to stay healthy. When is the best time to wash our hands?,
      options: [Before eating and after using the toilet., Only when our hands look dirty., Once a week.", "Only in the morning.].sort(() => Math.random() - 0.5),
      correctAnswer: Before eating and after using the toilet."
    })
  },
  {
    id: "G1-HN-HAB-03",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Healthy Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: "We need to take care of our bodies to stay healthy. Which of the following is a way to take care of our body?,
      options: [Taking a bath every day., Not washing our hair., "Wearing dirty clothes., Not brushing teeth."].sort(() => Math.random() - 0.5),
      correctAnswer: "Taking a bath every day.
    })
  },
  {
    id: G1-HN-HAB-04",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Healthy Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should drink water to stay healthy. Why is it important to drink clean water?,
      options: [It keeps us healthy and prevents diseases., It makes us thirsty., It gives us bad dreams.", "It makes us sleepy.].sort(() => Math.random() - 0.5),
      correctAnswer: It keeps us healthy and prevents diseases."
    })
  },

  // --- 1.2 SAFETY EDUCATION (4 Materials) ---
  {
    id: "G1-HN-SAF-01",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Safety is important to protect us from getting hurt. Which of the following is a safety rule?,
      options: [Do not play with fire., Run on the road., "Play with sharp objects., Climb on chairs."].sort(() => Math.random() - 0.5),
      correctAnswer: "Do not play with fire.
    })
  },
  {
    id: G1-HN-SAF-02",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We should be careful when walking on the road. What is the safest way to cross the road?,
      options: [Use a zebra crossing with an adult., Run across quickly., Cross between parked cars.", "Cross with your eyes closed.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a zebra crossing with an adult."
    })
  },
  {
    id: "G1-HN-SAF-03",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We should be careful with sharp objects at home. What should we do if we find a sharp knife on the floor?,
      options: [Tell an adult immediately., Pick it up and play with it., "Leave it on the floor., Hide it under a chair."].sort(() => Math.random() - 0.5),
      correctAnswer: "Tell an adult immediately.
    })
  },
  {
    id: G1-HN-SAF-04",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should be safe in the kitchen. Which of the following is NOT safe to do in the kitchen?,
      options: [Touching a hot stove., Washing hands before cooking., Wearing an apron.", "Watching an adult cook.].sort(() => Math.random() - 0.5),
      correctAnswer: Touching a hot stove."
    })
  },

  // --- STRAND 2: PERSONAL HYGIENE ---

  // --- 2.1 CARE FOR THE PARTS OF THE BODY (5 Materials) ---
  {
    id: "G1-HN-BOD-01",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "We need to take care of every part of our body. Which part of the body helps us to see?,
      options: [Eyes, Ears, "Nose, Mouth"].sort(() => Math.random() - 0.5),
      correctAnswer: "Eyes
    })
  },
  {
    id: G1-HN-BOD-02",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We should clean our body parts to keep them healthy. What do we use to clean our ears?,
      options: [A soft cloth, A sharp object, A pen", "A pencil].sort(() => Math.random() - 0.5),
      correctAnswer: A soft cloth"
    })
  },
  {
    id: "G1-HN-BOD-03",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Our teeth help us to eat food properly. How should we take care of our teeth?,
      options: [Brush them twice a day., Eat sweets all day., "Do not brush them., Use a needle to clean them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Brush them twice a day.
    })
  },
  {
    id: G1-HN-BOD-04",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Our skin protects our body from germs. How can we keep our skin clean and healthy?,
      options: [Take a bath with soap and water., Rub dirt on our skin., Never take a bath.", "Wear dirty clothes.].sort(() => Math.random() - 0.5),
      correctAnswer: Take a bath with soap and water."
    })
  },
  {
    id: "G1-HN-BOD-05",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Our hair needs to be clean and well-groomed. How can we keep our hair clean?,
      options: [Wash it with shampoo and water., Rub mud in it., "Leave it dirty., Cut it with scissors."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash it with shampoo and water.
    })
  },

  // --- 2.2 ITEMS USED FOR CLEANING THE BODY (4 Materials) ---
  {
    id: G1-HN-CLE-01",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " We use different items to clean our bodies. What do we use to brush our teeth?,
      options: [A toothbrush, A fork, A spoon", "A pencil].sort(() => Math.random() - 0.5),
      correctAnswer: A toothbrush"
    })
  },
  {
    id: "G1-HN-CLE-02",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We need soap for washing our bodies. What is the purpose of soap?,
      options: [To remove dirt and germs., To make us smell bad., "To make our skin dirty., To make us sick."].sort(() => Math.random() - 0.5),
      correctAnswer: "To remove dirt and germs.
    })
  },
  {
    id: G1-HN-CLE-03",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We use a towel after bathing. What is the purpose of using a towel?,
      options: [To dry our body., To make us wet., To clean our clothes.", "To brush our teeth.].sort(() => Math.random() - 0.5),
      correctAnswer: To dry our body."
    })
  },
  {
    id: "G1-HN-CLE-04",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should use our own personal items for cleaning. Why should we not share our toothbrush with others?,
      options: [To prevent the spread of germs., It is not important., "To save money., To make friends."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the spread of germs.
    })
  },

  // --- STRAND 3: FOODS ---

  // --- 3.1 SOURCES OF FOOD (4 Materials) ---
  {
    id: G1-HN-FOO-01",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Food comes from different sources. Which of the following is a source of food?,
      options: [Plants, Rocks, Plastic", "Metal].sort(() => Math.random() - 0.5),
      correctAnswer: Plants"
    })
  },
  {
    id: "G1-HN-FOO-02",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Animals also provide us with food. Which of the following comes from animals?,
      options: [Milk, Maize, "Beans, Potatoes"].sort(() => Math.random() - 0.5),
      correctAnswer: "Milk
    })
  },
  {
    id: G1-HN-FOO-03",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Plants give us many types of food. Which of the following is a food that comes from plants?,
      options: [Fruits, Milk, Eggs", "Meat].sort(() => Math.random() - 0.5),
      correctAnswer: Fruits"
    })
  },
  {
    id: "G1-HN-FOO-04",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We get food from both plants and animals. Which of the following is NOT a source of food?,
      options: [A stone, A cow, "A maize plant, A chicken"].sort(() => Math.random() - 0.5),
      correctAnswer: "A stone
    })
  },

  // --- 3.2 EATING HABITS (4 Materials) ---
  {
    id: G1-HN-EAT-01",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " We should eat different types of foods to stay healthy. What is the term for eating a variety of foods from different food groups?,
      options: [A balanced diet, Junk food, Snacking", "Fasting].sort(() => Math.random() - 0.5),
      correctAnswer: A balanced diet"
    })
  },
  {
    id: "G1-HN-EAT-02",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We should eat food at the right time. Which is the best time to eat breakfast?,
      options: [In the morning before going to school., In the afternoon., "At night., When we are very hungry."].sort(() => Math.random() - 0.5),
      correctAnswer: "In the morning before going to school.
    })
  },
  {
    id: G1-HN-EAT-03",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We should wash our hands before eating. Why is this important?,
      options: [To remove germs from our hands., To make our hands wet., To make food taste better.", "To make our hands warm.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove germs from our hands."
    })
  },
  {
    id: "G1-HN-EAT-04",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should eat slowly and chew our food well. What is the benefit of chewing food well?,
      options: [It helps with digestion., It makes us eat faster., "It makes us eat more., It makes food taste better."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps with digestion.
    })
  },

  // --- 3.3 CLEANING OF FRUITS (4 Materials) ---
  {
    id: G1-HN-FRU-01",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " We should clean fruits before eating them. Why should we wash fruits?,
      options: [To remove dirt and germs., To make them sweet., To make them soft.", "To change their color.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove dirt and germs."
    })
  },
  {
    id: "G1-HN-FRU-02",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "What do we use to wash fruits before eating them?,
      options: [Clean water, Oil, "Salt, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean water
    })
  },
  {
    id: G1-HN-FRU-03",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Fruits that we eat should be washed and peeled. Which fruit do you peel before eating?,
      options: [Banana, Apple, Orange", "Pineapple].sort(() => Math.random() - 0.5),
      correctAnswer: Orange"
    })
  },
  {
    id: "G1-HN-FRU-04",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Some fruits can be eaten without peeling after washing. Which fruit can you eat with the skin after washing it?,
      options: [Apple, Banana, "Orange, Pineapple"].sort(() => Math.random() - 0.5),
      correctAnswer: "Apple
    })
  },

  // --- 3.4 WHY WE EAT (3 Materials) ---
  {
    id: G1-HN-WHY-01",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Why We Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " We eat food for many reasons. Why do we need to eat food?,
      options: [To grow and stay healthy., To make us unhappy., To make us sick.", "To waste time.].sort(() => Math.random() - 0.5),
      correctAnswer: To grow and stay healthy."
    })
  },
  {
    id: "G1-HN-WHY-02",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Why We Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Food gives us energy to play and work. Which of the following foods gives us the most energy?,
      options: [Maize and rice, Water, "Salt, Oil"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maize and rice
    })
  },
  {
    id: G1-HN-WHY-03",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Why We Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Our bodies need different nutrients to function properly. What helps to build our bones and teeth?,
      options: [Calcium from milk, Water, Fats", "Sugars].sort(() => Math.random() - 0.5),
      correctAnswer: Calcium from milk"
    })
  },

  // --- 3.5 GOOD BEHAVIOR DURING MEAL TIMES (3 Materials) ---
  {
    id: "G1-HN-BEH-01",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Good Behavior During Meal Times,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "We should behave well during meal times. Which of the following is good behavior during meal times?,
      options: [Sitting down while eating., Running around while eating., "Talking with food in the mouth., Eating with dirty hands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sitting down while eating.
    })
  },
  {
    id: G1-HN-BEH-02",
    grade: "Grade 1,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Good Behavior During Meal Times",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We should say a prayer or thank someone before eating. Why is this important?,
      options: [It shows gratitude for the food we have., It makes the food taste better., It makes us eat faster.", "It is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: It shows gratitude for the food we have."
    })
  },
  {
    id: "G1-HN-BEH-03",
    grade: "Grade 1",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Good Behavior During Meal Times,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should not waste food during meal times. What should you do if you cannot finish your food?,
      options: [Save it for later or share with someone., Throw it on the floor., "Put it in the bin., Leave it on the table."].sort(() => Math.random() - 0.5),
      correctAnswer: "Save it for later or share with someone.
    })
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (KICD HYGIENE AND NUTRITION SYLLABUS)
  // =========================================================================

  // --- STRAND 1: HEALTHY PRACTICES ---

  // --- 1.1 HEALTH HABITS (4 Materials) ---
  {
    id: G2-HN-HAB-01",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Health Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Health habits help us to prevent diseases and stay healthy. Which of the following is a good health habit?,
      options: [Washing hands before eating., Playing in dirty water., Eating unwashed fruits.", "Sleeping on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Washing hands before eating."
    })
  },
  {
    id: "G2-HN-HAB-02",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Health Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should practice good health habits every day. What is a good health habit for protecting ourselves from germs?,
      options: [Washing hands with soap and water., Sharing towels with others., "Not covering our mouth when sneezing., Eating with dirty hands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing hands with soap and water.
    })
  },
  {
    id: G2-HN-HAB-03",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Health Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should sleep enough to keep our bodies healthy. How many hours of sleep do young children need every night?,
      options: [8-10 hours, 2-3 hours, 15 hours", "30 minutes].sort(() => Math.random() - 0.5),
      correctAnswer: 8-10 hours"
    })
  },
  {
    id: "G2-HN-HAB-04",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Health Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should exercise regularly to stay healthy. Which of the following is a good exercise for young children?,
      options: [Running and playing games., Sitting all day., "Watching TV for long hours., Sleeping all day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Running and playing games.
    })
  },

  // --- 1.2 SAFETY EDUCATION (4 Materials) ---
  {
    id: G2-HN-SAF-01",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Safety rules protect us from danger. Which of the following is a safety rule at home?,
      options: [Keep sharp objects out of reach., Play with matches., Touch electrical sockets.", "Run on wet floors.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep sharp objects out of reach."
    })
  },
  {
    id: "G2-HN-SAF-02",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should be safe when walking to school. What is the safest way to walk on the road?,
      options: [Walk on the footpath or pavement., Walk in the middle of the road., "Play on the road., Run across the road."].sort(() => Math.random() - 0.5),
      correctAnswer: "Walk on the footpath or pavement.
    })
  },
  {
    id: G2-HN-SAF-03",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should be careful with electrical appliances. What should you do if you see a broken wire?,
      options: [Tell an adult., Touch it., Play with it.", "Hide it.].sort(() => Math.random() - 0.5),
      correctAnswer: Tell an adult."
    })
  },
  {
    id: "G2-HN-SAF-04",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should stay safe when playing outside. Which of the following is NOT safe to do when playing?,
      options: [Playing near a busy road., Playing in the playground., "Playing with friends., Playing football in a field."].sort(() => Math.random() - 0.5),
      correctAnswer: "Playing near a busy road.
    })
  },

  // --- STRAND 2: PERSONAL HYGIENE ---

  // --- 2.1 CARE FOR THE PARTS OF THE BODY (5 Materials) ---
  {
    id: G2-HN-BOD-01",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " We need to take care of our bodies to stay healthy. How often should we take a bath?,
      options: [Every day, Once a week, Once a month", "Only when dirty].sort(() => Math.random() - 0.5),
      correctAnswer: Every day"
    })
  },
  {
    id: "G2-HN-BOD-02",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Our feet need special care to keep them healthy. What should you do to take care of your feet?,
      options: [Wash them, dry them well, and wear clean socks., Wear dirty socks., "Never wash them., Wear shoes without socks."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them, dry them well, and wear clean socks.
    })
  },
  {
    id: G2-HN-BOD-03",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Our nails should be kept clean and short. Why is it important to keep our nails short?,
      options: [To prevent germs from hiding under them., To make them look nice., To play better.", "To eat better.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent germs from hiding under them."
    })
  },
  {
    id: "G2-HN-BOD-04",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Our eyes are very important. How should we take care of our eyes?,
      options: [Wash them with clean water and protect them from dust., Rub them with dirty hands., "Stare at the sun., Watch TV all day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them with clean water and protect them from dust.
    })
  },
  {
    id: G2-HN-BOD-05",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should cover our mouths when coughing or sneezing. Why is this important?,
      options: [To prevent spreading germs to others., It is not important., To make a loud sound.", "To show respect.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent spreading germs to others."
    })
  },

  // --- 2.2 ITEMS USED FOR CLEANING THE BODY (4 Materials) ---
  {
    id: "G2-HN-CLE-01",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We use different items to clean our bodies. Which item is used to clean between our teeth?,
      options: [Dental floss, A toothbrush, "A comb, A towel"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dental floss
    })
  },
  {
    id: G2-HN-CLE-02",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should keep our cleaning items clean. How should you store your toothbrush?,
      options: [In a dry and clean place., On the floor., In a dirty cup.", "In water.].sort(() => Math.random() - 0.5),
      correctAnswer: In a dry and clean place."
    })
  },
  {
    id: "G2-HN-CLE-03",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should use different towels for different purposes. Which towel should you use to dry your face?,
      options: [A face towel, A floor towel, "A dish towel, A table towel"].sort(() => Math.random() - 0.5),
      correctAnswer: "A face towel
    })
  },
  {
    id: G2-HN-CLE-04",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should change our underwear every day. Why is it important to wear clean underwear?,
      options: [To prevent germs and stay fresh., To look fashionable., To keep warm.", "To save money.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent germs and stay fresh."
    })
  },

  // --- STRAND 3: FOODS ---

  // --- 3.1 SOURCES OF FOOD (4 Materials) ---
  {
    id: "G2-HN-FOO-01",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Food comes from plants and animals. Which of the following is a food that comes from animals?,
      options: [Eggs, Maize, "Beans, Rice"].sort(() => Math.random() - 0.5),
      correctAnswer: "Eggs
    })
  },
  {
    id: G2-HN-FOO-02",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Plants provide us with many different foods. Which of the following comes from a plant?,
      options: [Meat, Fish, Beans", "Milk].sort(() => Math.random() - 0.5),
      correctAnswer: Beans"
    })
  },
  {
    id: "G2-HN-FOO-03",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Different foods grow in different places. Which of the following foods grows on a tree?,
      options: [Mangoes, Potatoes, "Carrots, Beans"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mangoes
    })
  },
  {
    id: G2-HN-FOO-04",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Some foods come from the ground. Which of the following vegetables grows under the ground?,
      options: [Carrots, Spinach, Kale", "Cabbage].sort(() => Math.random() - 0.5),
      correctAnswer: Carrots"
    })
  },

  // --- 3.2 EATING HABITS (4 Materials) ---
  {
    id: "G2-HN-EAT-01",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We should eat a balanced diet. What is a balanced diet?,
      options: [Eating foods from all food groups in the right amounts., Eating only one type of food., "Eating whenever we want., Eating only fruits."].sort(() => Math.random() - 0.5),
      correctAnswer: "Eating foods from all food groups in the right amounts.
    })
  },
  {
    id: G2-HN-EAT-02",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should eat three main meals a day. What are the three main meals of the day?,
      options: [Breakfast, lunch, and dinner., Snacks, lunch, and dinner., Breakfast, tea, and supper.", "Lunch, tea, and dinner.].sort(() => Math.random() - 0.5),
      correctAnswer: Breakfast, lunch, and dinner."
    })
  },
  {
    id: "G2-HN-EAT-03",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should drink water during meals. Why is it important to drink water with meals?,
      options: [It helps with digestion., It makes us full., "It cools the food., It adds flavor."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps with digestion.
    })
  },
  {
    id: G2-HN-EAT-04",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should avoid eating too many sweets and sugary foods. What can too much sugar do to our bodies?,
      options: [Cause tooth decay and weight problems., Make us stronger., Make us taller.", "Improve our eyesight.].sort(() => Math.random() - 0.5),
      correctAnswer: Cause tooth decay and weight problems."
    })
  },

  // --- 3.3 CLEANING OF FRUITS AND VEGETABLES (4 Materials) ---
  {
    id: "G2-HN-CLV-01",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits and Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We should wash fruits and vegetables before eating or cooking them. What should we use to wash fruits and vegetables?,
      options: [Clean running water, Dirty water, "Soap, Salt water"].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean running water
    })
  },
  {
    id: G2-HN-CLV-02",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits and Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Some vegetables need to be peeled before cooking. Which vegetable should be peeled before cooking?,
      options: [Potatoes, Spinach, Kale", "Cabbage].sort(() => Math.random() - 0.5),
      correctAnswer: Potatoes"
    })
  },
  {
    id: "G2-HN-CLV-03",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits and Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should wash our hands before handling fruits and vegetables. Why is this important?,
      options: [To prevent transferring germs to the food., To make the food taste better., "To make the food softer., To change the color."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent transferring germs to the food.
    })
  },
  {
    id: G2-HN-CLV-04",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits and Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should store washed fruits and vegetables properly. Where should we store washed fruits and vegetables?,
      options: [In a clean, dry place or refrigerator., On the floor., In the sun.", "In dirty containers.].sort(() => Math.random() - 0.5),
      correctAnswer: In a clean, dry place or refrigerator."
    })
  },

  // --- 3.4 WHY WE EAT (3 Materials) ---
  {
    id: "G2-HN-WHY-01",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Why We Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We eat food to stay alive and grow. What happens if we do not eat enough food?,
      options: [We become weak and sick., We become stronger., "We grow taller., We sleep better."].sort(() => Math.random() - 0.5),
      correctAnswer: "We become weak and sick.
    })
  },
  {
    id: G2-HN-WHY-02",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Why We Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Different foods help our bodies in different ways. Which food helps to build muscles?,
      options: [Meat and beans, Fruits, Rice", "Sugar].sort(() => Math.random() - 0.5),
      correctAnswer: Meat and beans"
    })
  },
  {
    id: "G2-HN-WHY-03",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Why We Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Fruits and vegetables protect our bodies from disease. What nutrient do fruits and vegetables provide?,
      options: [Vitamins, Protein, "Carbohydrates, Fats"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins
    })
  },

  // --- 3.5 GOOD BEHAVIOR DURING MEAL TIMES (3 Materials) ---
  {
    id: G2-HN-BEH-01",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Good Behavior During Meal Times",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Good behavior during meal times shows respect and politeness. Which of the following is a good manner at the table?,
      options: [Using a spoon or fork to eat., Eating with your mouth open., Reaching across the table.", "Talking loudly.].sort(() => Math.random() - 0.5),
      correctAnswer: Using a spoon or fork to eat."
    })
  },
  {
    id: "G2-HN-BEH-02",
    grade: "Grade 2",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Good Behavior During Meal Times,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should thank the person who prepared the food. Why is it important to say thank you?,
      options: [To show appreciation and gratitude., It is not important., "To get more food., To be polite."].sort(() => Math.random() - 0.5),
      correctAnswer: "To show appreciation and gratitude.
    })
  },
  {
    id: G2-HN-BEH-03",
    grade: "Grade 2,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Good Behavior During Meal Times",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should eat slowly and not talk with food in our mouth. What is the reason for this good behavior?,
      options: [To avoid choking and show good manners., It is not important., To eat faster.", "To talk more.].sort(() => Math.random() - 0.5),
      correctAnswer: To avoid choking and show good manners."
    })
  }`n// =========================================================================
// GRADE 3: 35 MATERIALS (KICD HYGIENE AND NUTRITION SYLLABUS)
// =========================================================================

  // --- STRAND 1: HEALTHY PRACTICES ---

  // --- 1.1 HEALTH HABITS (4 Materials) ---
  {
    id: "G3-HN-HAB-01",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Health Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should practice good health habits to prevent diseases. What is a healthy habit that helps prevent the spread of germs?,
      options: [Washing hands with soap and water regularly., Not covering your mouth when coughing., "Sharing personal items like toothbrushes., Eating food that has fallen on the floor."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing hands with soap and water regularly.
    })
  },
  {
    id: G3-HN-HAB-02",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Health Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Proper disposal of waste is important for community health. What is the correct way to dispose of household waste?,
      options: [Put it in a designated dustbin or garbage bag., Throw it in the river., Burn it near houses.", "Bury it in the garden.].sort(() => Math.random() - 0.5),
      correctAnswer: Put it in a designated dustbin or garbage bag."
    })
  },
  {
    id: "G3-HN-HAB-03",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Health Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should protect ourselves from insect bites to prevent diseases. Which of the following prevents mosquito bites?,
      options: [Sleeping under a mosquito net., Playing outside at night., "Leaving windows open., Standing near stagnant water."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sleeping under a mosquito net.
    })
  },
  {
    id: G3-HN-HAB-04",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Health Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " We should drink clean water to stay healthy. What is the best way to ensure drinking water is safe?,
      options: [Boil the water or use a water purifier., Drink water from any source., Drink untreated river water.", "Add sugar to the water.].sort(() => Math.random() - 0.5),
      correctAnswer: Boil the water or use a water purifier."
    })
  },

  // --- 1.2 SAFETY EDUCATION (4 Materials) ---
  {
    id: "G3-HN-SAF-01",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should know what to do in case of an emergency. What is the first thing to do if someone is injured?,
      options: [Call an adult or a person who can help., Run away., "Ignore the person., Panic and scream."].sort(() => Math.random() - 0.5),
      correctAnswer: "Call an adult or a person who can help.
    })
  },
  {
    id: G3-HN-SAF-02",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Poisonous substances can be found in our homes. Which of the following is NOT a safe practice with dangerous substances?,
      options: [Keeping medicines and chemicals locked away., Labeling containers with poisonous substances., Storing poison near food.", "Keeping poison out of children's reach.].sort(() => Math.random() - 0.5),
      correctAnswer: Storing poison near food."
    })
  },
  {
    id: "G3-HN-SAF-03",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Safety Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should be safe when playing sports and games. What is a safety rule when playing active games?,
      options: [Wear appropriate protective gear like helmets., Play with sharp objects., "Push other players., Play on hard, uneven surfaces."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wear appropriate protective gear like helmets.
    })
  },
  {
    id: G3-HN-SAF-04",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Safety Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " We should know important emergency numbers. Which of the following is an emergency number to call in case of fire?,
      options: [999, 911, 112", "119].sort(() => Math.random() - 0.5),
      correctAnswer: 999"
    })
  },

  // --- 1.3 WASHING OF HANDS AND FOOD (4 Materials) ---
  {
    id: "G3-HN-WAS-01",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Washing of Hands and Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Proper hand washing is important to prevent the spread of diseases. Which of the following is the correct order for washing hands?,
      options: [Wet hands, apply soap, scrub for 20 seconds, rinse, dry., Apply soap, wet hands, dry, scrub., "Rinse hands, apply soap, dry, scrub., Wet hands, rinse, dry, apply soap."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wet hands, apply soap, scrub for 20 seconds, rinse, dry.
    })
  },
  {
    id: G3-HN-WAS-02",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Washing of Hands and Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should wash our hands at specific times. Which of the following is a time you should ALWAYS wash your hands?,
      options: [After using the toilet, After eating, Before sleeping", "After waking up].sort(() => Math.random() - 0.5),
      correctAnswer: After using the toilet"
    })
  },
  {
    id: "G3-HN-WAS-03",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Healthy Practices",
    subtopic: "Washing of Hands and Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should wash fruits and vegetables before eating them. What is the best way to wash leafy vegetables like spinach?,
      options: [Wash them under running water to remove dirt., Soak them in soapy water., "Wash them in salty water., Do not wash them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them under running water to remove dirt.
    })
  },
  {
    id: G3-HN-WAS-04",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Healthy Practices,
    subtopic: "Washing of Hands and Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clean water is essential for washing hands and food. What should you do if you do not have clean running water?,
      options: [Use a water filter or tablet to purify water., Use any water available., Do not wash at all.", "Wash with muddy water.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a water filter or tablet to purify water."
    })
  },

  // --- STRAND 2: PERSONAL HYGIENE ---

  // --- 2.1 CARE FOR THE PARTS OF THE BODY (5 Materials) ---
  {
    id: "G3-HN-BOD-01",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should take care of our skin to prevent rashes and infections. What is a good practice for skin care?,
      options: [Apply sunscreen or moisturizer to protect the skin., Prick pimples or spots., "Share towels with others., Use harsh chemicals on the skin."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply sunscreen or moisturizer to protect the skin.
    })
  },
  {
    id: G3-HN-BOD-02",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Dental hygiene is important for healthy teeth and gums. What is the recommended time to brush your teeth?,
      options: [Twice a day, in the morning and before bed., Once a week., After every meal only.", "Only in the morning.].sort(() => Math.random() - 0.5),
      correctAnswer: Twice a day, in the morning and before bed."
    })
  },
  {
    id: "G3-HN-BOD-03",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should protect our ears from damage. Which of the following is NOT a safe practice for ear care?,
      options: [Inserting sharp objects into the ear., Cleaning the outer ear with a soft cloth., "Protecting ears from loud noise., Wearing earplugs when in noisy places."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inserting sharp objects into the ear.
    })
  },
  {
    id: G3-HN-BOD-04",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Care for the Parts of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " We need to take care of our hair to keep it clean and healthy. What is a good practice for hair care?,
      options: [Wash hair regularly with shampoo., Use dirty combs on your hair., Wear dirty hats.", "Do not comb or brush your hair.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly with shampoo."
    })
  },
  {
    id: "G3-HN-BOD-05",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Care for the Parts of the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We should also take care of our nails. How should we trim our nails to avoid injuries?,
      options: [Use proper nail clippers and trim them straight., Bite them off., "Break them with your hands., Use sharp knives to cut them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use proper nail clippers and trim them straight.
    })
  },

  // --- 2.2 ITEMS USED FOR CLEANING THE BODY (4 Materials) ---
  {
    id: G3-HN-CLE-01",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We use different items to clean different parts of our body. Which item should be used for washing the body?,
      options: [A washcloth or sponge, A knife, A pen", "A pencil].sort(() => Math.random() - 0.5),
      correctAnswer: A washcloth or sponge"
    })
  },
  {
    id: "G3-HN-CLE-02",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should use the correct type of soap for our skin. Which type of soap is gentle and suitable for children?,
      options: [Mild soap, Strong chemical soap, "Detergent, Harsh soap"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mild soap
    })
  },
  {
    id: G3-HN-CLE-03",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Personal Hygiene,
    subtopic: "Items Used for Cleaning the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should use a clean towel after bathing. How often should we wash our bath towel?,
      options: [After every 2-3 uses, Once a month, Once a year", "Never].sort(() => Math.random() - 0.5),
      correctAnswer: After every 2-3 uses"
    })
  },
  {
    id: "G3-HN-CLE-04",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Personal Hygiene",
    subtopic: "Items Used for Cleaning the Body,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We should not share personal hygiene items. Why is it important not to share things like toothbrushes and towels?,
      options: [To prevent the spread of germs and diseases., It saves money., "It is not important., To avoid arguments."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the spread of germs and diseases.
    })
  },

  // --- STRAND 3: FOODS ---

  // --- 3.1 SOURCES OF FOOD (4 Materials) ---
  {
    id: G3-HN-FOO-01",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We get food from different sources. Which of the following is a food source that comes from farming?,
      options: [Maize, Stone, Plastic", "Metal].sort(() => Math.random() - 0.5),
      correctAnswer: Maize"
    })
  },
  {
    id: "G3-HN-FOO-02",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We also get food from animals. Which of the following is a food that comes from animals?,
      options: [Fish, Beans, "Rice, Potatoes"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fish
    })
  },
  {
    id: G3-HN-FOO-03",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Sources of Food",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Processed foods are foods that have been changed from their natural state. Which of the following is a processed food?,
      options: [Flour, Maize, Sugar cane", "Mango].sort(() => Math.random() - 0.5),
      correctAnswer: Flour"
    })
  },
  {
    id: "G3-HN-FOO-04",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Sources of Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Foods can be classified as perishable or non-perishable. Which of the following is a perishable food that spoils quickly?,
      options: [Milk, Beans, "Rice, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Milk
    })
  },

  // --- 3.2 EATING HABITS (4 Materials) ---
  {
    id: G3-HN-EAT-01",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We need to eat the right amount of food for our age and activity level. What is the term for eating too much food?,
      options: [Overeating, Undereating, Fasting", "Dieting].sort(() => Math.random() - 0.5),
      correctAnswer: Overeating"
    })
  },
  {
    id: "G3-HN-EAT-02",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should eat snacks that are healthy. Which of the following is a healthy snack option?,
      options: [Fresh fruits like oranges or bananas., Candy, "Chips, Soda"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fresh fruits like oranges or bananas.
    })
  },
  {
    id: G3-HN-EAT-03",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Eating Habits",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should limit our intake of sugary and fatty foods. Why is it important to limit these foods?,
      options: [They can cause health problems like obesity and tooth decay., They are expensive., They are hard to find.", "They are not tasty.].sort(() => Math.random() - 0.5),
      correctAnswer: They can cause health problems like obesity and tooth decay."
    })
  },
  {
    id: "G3-HN-EAT-04",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We should include different colors of fruits and vegetables in our diet. What do different colors represent in fruits and vegetables?,
      options: [Different nutrients and vitamins., Different prices., "Different sizes., Different flavors."].sort(() => Math.random() - 0.5),
      correctAnswer: "Different nutrients and vitamins.
    })
  },

  // --- 3.3 CLEANING OF FRUITS AND VEGETABLES (4 Materials) ---
  {
    id: G3-HN-CLV-01",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits and Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We should clean fruits and vegetables properly before eating. What is the purpose of adding salt or vinegar to water when washing produce?,
      options: [To help remove pesticides and germs., To make them taste better., To change their color.", "To make them softer.].sort(() => Math.random() - 0.5),
      correctAnswer: To help remove pesticides and germs."
    })
  },
  {
    id: "G3-HN-CLV-02",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits and Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We should remove wilted or spoiled leaves from vegetables. What is the best way to prepare vegetables for cooking?,
      options: [Wash, sort, and cut them as needed., Cook them without washing., "Throw away all the leaves., Eat them raw without washing."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash, sort, and cut them as needed.
    })
  },
  {
    id: G3-HN-CLV-03",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Cleaning of Fruits and Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should clean our cutting board after preparing fruits and vegetables. Why is this important?,
      options: [To prevent cross-contamination and spread of germs., To make it look clean., To save space.", "To reuse the water.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent cross-contamination and spread of germs."
    })
  },
  {
    id: "G3-HN-CLV-04",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Cleaning of Fruits and Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Some fruits and vegetables have edible peels. Which of the following is a fruit with an edible peel?,
      options: [Apple, Orange, "Banana, Pineapple"].sort(() => Math.random() - 0.5),
      correctAnswer: "Apple
    })
  },

  // --- 3.4 WHY WE EAT (3 Materials) ---
  {
    id: G3-HN-WHY-01",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Why We Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We eat food to get energy and stay healthy. What nutrient gives us the most energy?,
      options: [Carbohydrates, Proteins, Vitamins", "Minerals].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates"
    })
  },
  {
    id: "G3-HN-WHY-02",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Why We Eat,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We need protein to build and repair our body tissues. Which of the following foods is rich in protein?,
      options: [Beans, Rice, "Potatoes, Sugar"].sort(() => Math.random() - 0.5),
      correctAnswer: "Beans
    })
  },
  {
    id: G3-HN-WHY-03",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Why We Eat",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Water is essential for our body to function properly. What is the main function of water in our body?,
      options: [To keep us hydrated and help with body functions., To give us energy., To make us grow.", "To build muscles.].sort(() => Math.random() - 0.5),
      correctAnswer: To keep us hydrated and help with body functions."
    })
  },

  // --- 3.5 GOOD BEHAVIOR DURING MEAL TIMES (3 Materials) ---
  {
    id: "G3-HN-BEH-01",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Good Behavior During Meal Times,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "We should show good manners at the table. Which of the following is an example of a good table manner?,
      options: [Waiting for everyone to be served before eating., Eating before everyone is seated., "Talking while chewing., Reaching across the table."].sort(() => Math.random() - 0.5),
      correctAnswer: "Waiting for everyone to be served before eating.
    })
  },
  {
    id: G3-HN-BEH-02",
    grade: "Grade 3,
    subject: Hygiene and Nutrition",
    topic: "Foods,
    subtopic: "Good Behavior During Meal Times",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We should set the table properly before meals. What is the purpose of setting the table?,
      options: [To make meal time orderly and pleasant., To make more work., To show off.", "To waste time.].sort(() => Math.random() - 0.5),
      correctAnswer: To make meal time orderly and pleasant."
    })
  },
  {
    id: "G3-HN-BEH-03",
    grade: "Grade 3",
    subject: "Hygiene and Nutrition",
    topic: "Foods",
    subtopic: "Good Behavior During Meal Times,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We should clear the table after eating. What should you do with leftover food after a meal?,
      options: [Store it properly or dispose of it appropriately., Leave it on the table., "Throw it on the floor., Hide it under the table."].sort(() => Math.random() - 0.5),
      correctAnswer: "Store it properly or dispose of it appropriately."
    })
  }

];




