export const homeScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G4-HS-PH-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "Keeping our bodies clean is essential for good health and prevents the spread of germs. Which of the following is the most important practice for maintaining good personal hygiene?,
      options: [Bathing daily with soap and water., Bathing once a week., "Using perfume instead of bathing., Wearing clean clothes but not bathing."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water.
    })
  },
  {
    id: G4-HS-PH-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Hair",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Healthy hair requires proper care and regular maintenance. What is the correct way to care for your hair to keep it clean and healthy?,
      options: [Wash hair regularly with shampoo and comb it gently., Wash hair with soap only., Never wash hair to keep it strong.", "Use oil without washing.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly with shampoo and comb it gently."
    })
  },
  {
    id: "G4-HS-PH-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Teeth,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Dental hygiene is important to prevent cavities and bad breath. According to dental health guidelines, how often should you brush your teeth?,
      options: [At least twice a day, morning and before bed., Once a week.", "Only when they feel dirty., Once a month."].sort(() => Math.random() - 0.5),
      correctAnswer: "At least twice a day, morning and before bed.
    })
  },
  {
    id: G4-HS-PH-04",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Nails",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Dirty and long nails can harbor germs that cause infections. What is the proper way to care for your nails?,
      options: [Cut them short and clean under them regularly., Let them grow long and paint them., Bite them to keep them short.", "Never cut them.].sort(() => Math.random() - 0.5),
      correctAnswer: Cut them short and clean under them regularly."
    })
  },
  {
    id: "G4-HS-PH-05",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Overall Body Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Good personal hygiene involves more than just bathing and includes caring for all parts of the body. Which of the following is part of a complete personal hygiene routine?,
      options: [Bathing, brushing teeth, washing hands, and caring for hair and nails., Only bathing., "Only wearing clean clothes., Only brushing hair."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing, brushing teeth, washing hands, and caring for hair and nails.
    })
  },

  // --- HOME HYGIENE (4 Materials) ---
  {
    id: G4-HS-HH-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the House",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A clean home prevents the spread of diseases and creates a comfortable living environment. What is the most effective way to keep your house clean?,
      options: [Sweep and mop floors daily, dust furniture, and clean surfaces., Clean only when visitors come., Just remove visible dirt.", "Clean only the kitchen.].sort(() => Math.random() - 0.5),
      correctAnswer: Sweep and mop floors daily, dust furniture, and clean surfaces."
    })
  },
  {
    id: "G4-HS-HH-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Cleaning the Kitchen,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The kitchen is where food is prepared, so it must be kept especially clean to prevent food contamination. Which area of the kitchen requires the most frequent cleaning?,
      options: [Food preparation surfaces and utensils after each use., The floor once a week.", "The ceiling every month., The windows once a year."].sort(() => Math.random() - 0.5),
      correctAnswer: "Food preparation surfaces and utensils after each use.
    })
  },
  {
    id: G4-HS-HH-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the Bathroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Bathrooms can be a breeding ground for bacteria and mold. What is the proper way to maintain bathroom hygiene?,
      options: [Clean the toilet, sink, and bathtub regularly with disinfectant., Only clean when it looks dirty., Rinse with water only.", "Never clean it.].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the toilet, sink, and bathtub regularly with disinfectant."
    })
  },
  {
    id: "G4-HS-HH-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper waste disposal is essential to prevent diseases and keep the environment clean. What should you do with household waste to maintain hygiene?,
      options: [Separate waste and dispose of it in designated bins regularly., Throw it outside the compound., "Burn it in the house., Bury it in the garden."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate waste and dispose of it in designated bins regularly.
    })
  },

  // --- CARE OF CLOTHING (4 Materials) ---
  {
    id: G4-HS-CC-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Washing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Proper washing keeps clothes clean, fresh, and long-lasting. What is the first step you should take before washing any clothes?,
      options: [Sort clothes by color and fabric type., Put all clothes in the water., Use hot water for all clothes.", "Add detergent without checking.].sort(() => Math.random() - 0.5),
      correctAnswer: Sort clothes by color and fabric type."
    })
  },
  {
    id: "G4-HS-CC-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Washing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Delicate fabrics require special care during washing to prevent damage. How should you wash delicate clothes like silk or wool?,
      options: [Wash them gently by hand with mild detergent in cool water., Wash them in a washing machine with hot water., "Soak them in bleach., Scrub them vigorously."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them gently by hand with mild detergent in cool water.
    })
  },
  {
    id: G4-HS-CC-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Ironing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Ironing removes wrinkles and makes clothes look neat and professional. What safety precaution should you take when using an electric iron?,
      options: [Keep the iron away from children and use it on an ironing board., Leave the iron on when not in use., Use it without water in the boiler.", "Iron clothes on the bed.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the iron away from children and use it on an ironing board."
    })
  },
  {
    id: "G4-HS-CC-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Storing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Proper storage protects clothes from damage and keeps them ready to wear. What is the best way to store clothes in a wardrobe?,
      options: [Fold them neatly or hang them, and keep the wardrobe clean and dry., Throw them in a pile., "Store wet clothes., Keep them in the sun."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fold them neatly or hang them, and keep the wardrobe clean and dry.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G4-HS-FN-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A balanced diet contains foods from all food groups to provide essential nutrients. Which of the following correctly lists the main food groups?,
      options: [Carbohydrates, proteins, vitamins, minerals, fats, and water., Rice, meat, and fruits only., Only proteins and carbohydrates.", "Only vegetables and fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vitamins, minerals, fats, and water."
    })
  },
  {
    id: "G4-HS-FN-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Balanced Diet,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A balanced diet is essential for growth, energy, and good health. What does a balanced diet consist of?,
      options: ["The right combination of foods from all food groups in the correct proportions., Eating only fruits and vegetables.", "Eating only carbohydrates., Eating whatever is available."].sort(() => Math.random() - 0.5),
      correctAnswer: "The right combination of foods from all food groups in the correct proportions.
    })
  },
  {
    id: G4-HS-FN-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Meal planning helps families eat nutritious meals and manage their food budget. When planning meals for a family, what should you consider?,
      options: [Nutritional needs, budget, preferences, and availability of food., Only the cost of food., Only the taste of food.", "Only what is available in the market.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional needs, budget, preferences, and availability of food."
    })
  },
  {
    id: "G4-HS-FN-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Food Groups,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different foods provide different nutrients needed by the body. Which food group is the main source of energy for the body?,
      options: [Carbohydrates like rice, bread, and potatoes., Proteins like meat and beans., "Vitamins from fruits and vegetables., Fats and oils."].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbohydrates like rice, bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G4-HS-FP-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kitchen safety is crucial to prevent accidents and injuries while cooking. What is the most important rule to follow in the kitchen?,
      options: [Never leave cooking food unattended and handle sharp tools carefully., Run around the kitchen., Use wet hands near electrical appliances.", "Leave all utensils on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Never leave cooking food unattended and handle sharp tools carefully."
    })
  },
  {
    id: "G4-HS-FP-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different cooking methods affect the taste, texture, and nutritional value of food. Which of the following is a healthy cooking method that preserves nutrients?,
      options: ["Steaming or boiling with minimal water., Deep frying in oil.", "Cooking for a very long time., Adding lots of salt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or boiling with minimal water.
    })
  },
  {
    id: G4-HS-FP-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Food can become contaminated if proper hygiene is not observed in the kitchen. What should you always do before handling food?,
      options: [Wash your hands thoroughly with soap and running water., Just rinse your hands., Wear gloves without washing hands.", "Wipe your hands on a cloth.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash your hands thoroughly with soap and running water."
    })
  },
  {
    id: "G4-HS-FP-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Boiling and steaming are common cooking methods in Kenyan homes. What is a disadvantage of boiling vegetables?,
      options: [Some water-soluble vitamins may be lost in the water., It takes too long., "It uses too much oil., It makes food too crispy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Some water-soluble vitamins may be lost in the water.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G4-HS-BEV-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Tea",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tea is a popular beverage in Kenya enjoyed by many families. What are the basic ingredients needed to prepare a cup of tea?,
      options: [Tea leaves, hot water, milk, and sugar., Coffee, milk, and sugar., Tea leaves and hot water only.", "Juice and water.].sort(() => Math.random() - 0.5),
      correctAnswer: Tea leaves, hot water, milk, and sugar."
    })
  },
  {
    id: "G4-HS-BEV-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Tea,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Tea can be prepared in different ways depending on preference. How is Kenyan tea traditionally prepared?,
      options: [Boiled with milk and sugar to make a creamy drink., Served with lemon and honey., "Served cold with ice., Mixed with soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiled with milk and sugar to make a creamy drink.
    })
  },
  {
    id: G4-HS-BEV-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Coffee",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Coffee is another popular beverage enjoyed in Kenya and around the world. What equipment is commonly used to brew coffee?,
      options: [A coffee maker or a traditional pot called a jebena., A pressure cooker., A microwave.", "A frying pan.].sort(() => Math.random() - 0.5),
      correctAnswer: A coffee maker or a traditional pot called a jebena."
    })
  },

  // --- SEWING AND NEEDLEWORK (3 Materials) ---
  {
    id: "G4-HS-SEW-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sewing is a valuable skill that allows you to mend and create clothes. What is the most basic and commonly used sewing stitch?,
      options: [The running stitch, The zigzag stitch, "The blanket stitch, The chain stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The running stitch
    })
  },
  {
    id: G4-HS-SEW-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Sewing and Needlework,
    subtopic: "Threading a Needle",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Before you can start sewing, you need to thread the needle correctly. What is the correct way to thread a needle?,
      options: [Wet the thread tip, pass it through the eye of the needle, and pull through., Push the needle through the thread., Tie the thread around the needle.", "Use a thick thread.].sort(() => Math.random() - 0.5),
      correctAnswer: Wet the thread tip, pass it through the eye of the needle, and pull through."
    })
  },
  {
    id: "G4-HS-SEW-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The backstitch is a strong stitch used for seams. How does a backstitch differ from a running stitch?,
      options: [The needle goes backward to create a continuous line of stitches., It is the same as a running stitch., "It uses a knot at every stitch., It is done with a machine."].sort(() => Math.random() - 0.5),
      correctAnswer: "The needle goes backward to create a continuous line of stitches.
    })
  },

  // --- HOME FURNISHINGS (3 Materials) ---
  {
    id: G4-HS-HF-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Arrangement of Furniture",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The arrangement of furniture affects how comfortable and functional a room is. What should you consider when arranging furniture in a room?,
      options: [The flow of movement, room size, and purpose of the room., Only the color of the furniture., Only the cost of the furniture.", "Put everything against the wall.].sort(() => Math.random() - 0.5),
      correctAnswer: The flow of movement, room size, and purpose of the room."
    })
  },
  {
    id: "G4-HS-HF-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Furnishings",
    subtopic: "Care of Home Items,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Furniture and furnishings need regular care to maintain their appearance and longevity. How should wooden furniture be cared for?,
      options: [Dust regularly and polish with appropriate wood polish., Wash with soap and water., "Leave them in the sun., Scrub with steel wool."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust regularly and polish with appropriate wood polish.
    })
  },
  {
    id: G4-HS-HF-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Care of Home Items",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Cushions, curtains, and carpets add comfort and beauty to a home. How should fabric furnishings be maintained?,
      options: [Vacuum regularly and clean spills immediately., Ignore stains., Wash them with harsh chemicals.", "Shake them outside only.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly and clean spills immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G4-HS-HS-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who is injured or suddenly becomes ill. What is the first thing you should do in an emergency?,
      options: [Stay calm and assess the situation, then call for help if needed., Run away from the scene., "Panic and scream., Ignore the person."].sort(() => Math.random() - 0.5),
      correctAnswer: "Stay calm and assess the situation, then call for help if needed.
    })
  },
  {
    id: G4-HS-HS-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Accidents at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Accidents can happen at home, especially in the kitchen and bathroom. What is a common cause of accidents in the kitchen?,
      options: [Slippery floors, handling hot items, and using knives carelessly., Eating too much., Talking while eating.", "Using the microwave.].sort(() => Math.random() - 0.5),
      correctAnswer: Slippery floors, handling hot items, and using knives carelessly."
    })
  },
  {
    id: "G4-HS-HS-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Knowing basic first aid can save lives in emergency situations. What should you do if someone gets a burn?,
      options: [Run cool water over the burn for several minutes and cover with a clean cloth., Put butter on the burn., "Pop any blisters., Ignore it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool water over the burn for several minutes and cover with a clean cloth.
    })
  },

  // --- TIME AND MONEY MANAGEMENT (2 Materials) ---
  {
    id: G4-HS-TM-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Time and Money Management,
    subtopic: "Planning Daily Chores",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Planning daily chores helps you use your time efficiently and keeps the home running smoothly. What is the best way to manage daily chores?,
      options: [Make a schedule or checklist and allocate time for each task., Do everything at the last minute., Only do chores on weekends.", "Let others do everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Make a schedule or checklist and allocate time for each task."
    })
  },
  {
    id: "G4-HS-TM-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Time and Money Management",
    subtopic: "Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Budgeting helps a family manage its money and ensure that all needs are met. What is the first step in creating a family budget?,
      options: [List all income and track all expenses., Buy whatever you want., "Only buy food., Save all money without spending."].sort(() => Math.random() - 0.5),
      correctAnswer: "List all income and track all expenses.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL GROOMING (4 Materials) ---
  {
    id: G5-HS-PG-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Skin Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Skin care is important for maintaining healthy skin and preventing skin conditions. What is the most important daily practice for healthy skin?,
      options: [Washing your face and body with soap and water daily., Using makeup every day., Scrubbing your skin roughly.", "Never moisturizing.].sort(() => Math.random() - 0.5),
      correctAnswer: Washing your face and body with soap and water daily."
    })
  },
  {
    id: "G5-HS-PG-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Well-groomed nails are a sign of good hygiene and personal care. How should you properly care for your nails?,
      options: [Keep them clean, trimmed, and filed regularly., Paint them with dark polish., "Bite them to keep them short., Never cut them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keep them clean, trimmed, and filed regularly.
    })
  },
  {
    id: G5-HS-PG-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Healthy hair requires proper care to prevent breakage and keep it looking good. What should you do to prevent dandruff and keep your scalp healthy?,
      options: [Wash hair regularly and use a gentle shampoo., Use hot oil every day., Never wash your hair.", "Use harsh chemicals.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly and use a gentle shampoo."
    })
  },
  {
    id: "G5-HS-PG-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Overall Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Good grooming involves taking care of your entire appearance and hygiene. Which of the following is a key element of good personal grooming?,
      options: [Wearing clean clothes, having neat hair, and practicing good hygiene., Wearing expensive clothes., "Using a lot of perfume., Having the latest hairstyle."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wearing clean clothes, having neat hair, and practicing good hygiene.
    })
  },

  // --- HOME CLEANING (4 Materials) ---
  {
    id: G5-HS-HC-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Different cleaning agents are used for different surfaces and purposes. What cleaning agent is used for cleaning glass and windows?,
      options: [Glass cleaner or vinegar solution., Bleach, Abrasive powder", "Dish soap].sort(() => Math.random() - 0.5),
      correctAnswer: Glass cleaner or vinegar solution."
    })
  },
  {
    id: "G5-HS-HC-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Sweeping and Mopping,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sweeping and mopping are essential for keeping floors clean and hygienic. What is the correct order for cleaning a floor?,
      options: [Sweep first to remove dirt and debris, then mop., Mop first, then sweep., "Only mop without sweeping., Only sweep without mopping."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweep first to remove dirt and debris, then mop.
    })
  },
  {
    id: G5-HS-HC-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Bleach is a strong cleaning agent that kills germs and removes stains. What safety precaution should be taken when using bleach?,
      options: [Use it in a well-ventilated area and never mix with other cleaners., Mix it with vinegar for more power., Use it on all surfaces.", "Use it without gloves.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it in a well-ventilated area and never mix with other cleaners."
    })
  },
  {
    id: "G5-HS-HC-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Cleaning Different Surfaces,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Different surfaces require different cleaning methods to avoid damage. How should wooden surfaces be cleaned?,
      options: [Dust with a soft cloth and use appropriate wood polish., Use water and soap., "Scrub with a hard brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust with a soft cloth and use appropriate wood polish.
    })
  },

  // --- LAUNDRY WORK (4 Materials) ---
  {
    id: G5-HS-LW-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Sorting Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Sorting clothes before washing prevents color bleeding and ensures proper care for different fabrics. How should you sort clothes before washing?,
      options: [Separate whites from colors and sort by fabric type., Wash all clothes together., Only sort by size.", "Only sort by owner.].sort(() => Math.random() - 0.5),
      correctAnswer: Separate whites from colors and sort by fabric type."
    })
  },
  {
    id: "G5-HS-LW-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Hand Washing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hand washing is a gentle method of washing clothes that is suitable for delicate fabrics. What is the correct water temperature for hand washing delicate clothes?,
      options: [Cold or lukewarm water., Very hot water., "Boiling water., Water of any temperature."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cold or lukewarm water.
    })
  },
  {
    id: G5-HS-LW-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Machine Washing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Washing machines make laundry work easier but require proper use. How can you prevent clothes from getting damaged in a washing machine?,
      options: [Use the correct cycle and load size for different fabrics., Overload the machine to save time., Use the hottest setting for all clothes.", "Use a lot of detergent.].sort(() => Math.random() - 0.5),
      correctAnswer: Use the correct cycle and load size for different fabrics."
    })
  },
  {
    id: "G5-HS-LW-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Drying Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper drying of clothes prevents damage and keeps them looking fresh. What is the best way to dry clothes to prevent shrinkage and damage?,
      options: [Air dry on a clothesline away from direct harsh sunlight., Tumble dry on high heat., "Iron them wet., Leave them in a pile."].sort(() => Math.random() - 0.5),
      correctAnswer: "Air dry on a clothesline away from direct harsh sunlight.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G5-HS-NU-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutrients and Their Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proteins are essential nutrients that the body needs for growth and repair. Which of the following foods is a rich source of protein?,
      options: [Beans, eggs, meat, and fish., Rice and bread., Fruits and vegetables.", "Sugar and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, eggs, meat, and fish."
    })
  },
  {
    id: "G5-HS-NU-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vitamins and minerals are important micronutrients that support various body functions. Which vitamin is important for healthy eyesight and is found in carrots and orange fruits?,
      options: [Vitamin A, Vitamin B, "Vitamin C, Vitamin D"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamin A
    })
  },
  {
    id: G5-HS-NU-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A balanced meal should contain foods from different food groups to provide all essential nutrients. What should be included in a balanced meal?,
      options: [Carbohydrates, proteins, vegetables, and fruits., Only meat and rice., Only vegetables.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vegetables, and fruits."
    })
  },
  {
    id: "G5-HS-NU-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Carbohydrates provide energy for the body to function. Which of the following is a healthy source of complex carbohydrates?,
      options: [Brown rice, whole grain bread, and potatoes., White sugar and sweets., "Cakes and pastries., Fizzy drinks."].sort(() => Math.random() - 0.5),
      correctAnswer: "Brown rice, whole grain bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G5-HS-FP-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vegetables provide essential vitamins and minerals and should be prepared properly to preserve their nutrients. What is the best way to cook vegetables to preserve their nutrients?,
      options: [Steam or stir-fry them quickly with minimal water., Boil them for a long time., Deep fry them.", "Microwave them for 30 minutes.].sort(() => Math.random() - 0.5),
      correctAnswer: Steam or stir-fry them quickly with minimal water."
    })
  },
  {
    id: "G5-HS-FP-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Preparing Soups,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Soup is a nutritious and comforting meal that can be made with various ingredients. What are the basic ingredients for making a vegetable soup?,
      options: [Vegetables, water or stock, and seasoning., Meat and flour., "Rice and tomatoes., Beans and coconut milk."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vegetables, water or stock, and seasoning.
    })
  },
  {
    id: G5-HS-FP-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Stews",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stews are hearty meals made by slowly cooking meat or vegetables in liquid. Which of the following is an important step when making a stew?,
      options: [Brown the meat first to add flavor, then add liquid and simmer., Just add everything to cold water., Cook on high heat for 10 minutes.", "Add all ingredients at once.].sort(() => Math.random() - 0.5),
      correctAnswer: Brown the meat first to add flavor, then add liquid and simmer."
    })
  },
  {
    id: "G5-HS-FP-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Kitchen Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kitchen hygiene is essential to prevent food poisoning and cross-contamination. What is the best way to prevent cross-contamination in the kitchen?,
      options: [Use separate chopping boards for raw meat and other foods., Use the same board for everything., "Wash the board only at the end of the day., Never wash cutting boards."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate chopping boards for raw meat and other foods.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G5-HS-BEV-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Fresh Juices",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh fruit juices are healthy and refreshing beverages rich in vitamins. What is the correct way to prepare fresh fruit juice?,
      options: [Wash fruits, peel if necessary, blend, and strain if desired., Add sugar and leave it overnight., Boil the fruits first.", "Use dried fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash fruits, peel if necessary, blend, and strain if desired."
    })
  },
  {
    id: "G5-HS-BEV-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Fresh Juices,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Smoothies are thicker than juices and often include milk or yogurt. What is a key ingredient that makes smoothies thick and creamy?,
      options: [Banana or yogurt, Water, "Oil, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Banana or yogurt
    })
  },
  {
    id: G5-HS-BEV-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Beverage Preparation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh juices are best consumed immediately after preparation. Why is it important to drink fresh juice soon after making it?,
      options: [To get the full nutritional benefits before vitamins are lost., To keep it from spoiling., To save time.", "To reduce sugar content.].sort(() => Math.random() - 0.5),
      correctAnswer: To get the full nutritional benefits before vitamins are lost."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G5-HS-NW-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Running Stitch,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The running stitch is one of the most basic and versatile hand stitches. What is the running stitch commonly used for?,
      options: [Basting, gathering fabric, and simple seams., Buttonholes., "Zipper insertion., Stitching leather."].sort(() => Math.random() - 0.5),
      correctAnswer: "Basting, gathering fabric, and simple seams.
    })
  },
  {
    id: G5-HS-NW-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Stitches - Backstitch",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The backstitch creates a strong and secure seam. How does the backstitch compare to the running stitch?,
      options: [The backstitch is stronger because each stitch overlaps the previous one., The backstitch is weaker., They are exactly the same.", "The backstitch is faster.].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch is stronger because each stitch overlaps the previous one."
    })
  },
  {
    id: "G5-HS-NW-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Hemming,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hemming is a finishing technique used to create a neat edge on garments and other fabric items. What is the purpose of hemming?,
      options: [To prevent the fabric from fraying and create a finished look., To make the garment longer., "To add decoration only., To make the garment tighter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and create a finished look.
    })
  },

  // --- HOME MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-HM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Windows",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clean windows allow natural light to enter and improve the appearance of a home. How should glass windows be cleaned to avoid streaks?,
      options: [Use a glass cleaner and a squeegee or microfiber cloth., Use soap and water with a sponge., Scrub with an abrasive pad.", "Use newspaper alone.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a glass cleaner and a squeegee or microfiber cloth."
    })
  },
  {
    id: "G5-HS-HM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Polishing Furniture,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Polishing wood furniture restores its shine and protects it from damage. What is the proper way to apply polish to wooden furniture?,
      options: [Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine., Pour polish directly on the furniture., "Use water instead of polish., Use a rough cloth to apply it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine.
    })
  },
  {
    id: G5-HS-HM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Maintaining Home Equipment",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Regular maintenance of home equipment extends their lifespan and ensures safety. Why is it important to regularly clean and service electrical appliances?,
      options: [To prevent accidents, save energy, and ensure they work efficiently., To keep them looking new., To avoid buying new ones.", "To reduce the electricity bill only.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent accidents, save energy, and ensure they work efficiently."
    })
  },

  // --- SAFETY IN THE HOME (3 Materials) ---
  {
    id: "G5-HS-SH-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Fire can be dangerous and cause serious injuries and property damage. What should you do if there is a small fire in the kitchen?,
      options: [Use a fire extinguisher or cover the fire with a lid to smother it., Pour water on a grease fire., "Run away and call for help., Blow on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a fire extinguisher or cover the fire with a lid to smother it.
    })
  },
  {
    id: G5-HS-SH-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Safety in the Home,
    subtopic: "Poison Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Many household products can be poisonous if ingested or misused. What is the best way to prevent poisoning in the home?,
      options: [Store cleaning products and medicines out of reach of children and in original containers., Keep them under the sink., Transfer them to unlabeled bottles.", "Leave them on the counter.].sort(() => Math.random() - 0.5),
      correctAnswer: Store cleaning products and medicines out of reach of children and in original containers."
    })
  },
  {
    id: "G5-HS-SH-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Prevention is better than cure when it comes to fire safety. Which of the following is a fire safety measure in the home?,
      options: [Have a working smoke detector and a fire escape plan., Leave candles burning when you leave the house., "Overload electrical sockets., Keep flammable materials near the stove."].sort(() => Math.random() - 0.5),
      correctAnswer: "Have a working smoke detector and a fire escape plan.
    })
  },

  // --- RESOURCE MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-RM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Using Resources Wisely",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Using resources wisely helps save money and protect the environment. What is one way to conserve water in the home?,
      options: [Repair leaking taps and use water sparingly., Leave taps running., Fill the bathtub completely.", "Use a hose to water the garden every day.].sort(() => Math.random() - 0.5),
      correctAnswer: Repair leaking taps and use water sparingly."
    })
  },
  {
    id: "G5-HS-RM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Resource Management",
    subtopic: "Using Resources Wisely,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Energy conservation reduces household bills and helps the environment. Which of the following is a way to save electricity at home?,
      options: [Turn off lights and appliances when not in use., Leave lights on all day., "Use old, inefficient appliances., Keep the refrigerator door open."].sort(() => Math.random() - 0.5),
      correctAnswer: "Turn off lights and appliances when not in use.
    })
  },
  {
    id: G5-HS-RM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Saving Money",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Saving money is an important habit that helps families prepare for emergencies and future needs. What is a simple way to start saving money at home?,
      options: [Set aside a small amount regularly in a savings box or bank account., Spend all money as soon as you get it., Borrow money for unnecessary items.", "Keep all money in a wallet.].sort(() => Math.random() - 0.5),
      correctAnswer: Set aside a small amount regularly in a savings box or bank account."
    })
  }`nexport const homeScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G4-HS-PH-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "Keeping our bodies clean is essential for good health and prevents the spread of germs. Which of the following is the most important practice for maintaining good personal hygiene?,
      options: [Bathing daily with soap and water., Bathing once a week., "Using perfume instead of bathing., Wearing clean clothes but not bathing."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water.
    })
  },
  {
    id: G4-HS-PH-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Hair",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Healthy hair requires proper care and regular maintenance. What is the correct way to care for your hair to keep it clean and healthy?,
      options: [Wash hair regularly with shampoo and comb it gently., Wash hair with soap only., Never wash hair to keep it strong.", "Use oil without washing.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly with shampoo and comb it gently."
    })
  },
  {
    id: "G4-HS-PH-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Teeth,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Dental hygiene is important to prevent cavities and bad breath. According to dental health guidelines, how often should you brush your teeth?,
      options: [At least twice a day, morning and before bed., Once a week.", "Only when they feel dirty., Once a month."].sort(() => Math.random() - 0.5),
      correctAnswer: "At least twice a day, morning and before bed.
    })
  },
  {
    id: G4-HS-PH-04",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Nails",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Dirty and long nails can harbor germs that cause infections. What is the proper way to care for your nails?,
      options: [Cut them short and clean under them regularly., Let them grow long and paint them., Bite them to keep them short.", "Never cut them.].sort(() => Math.random() - 0.5),
      correctAnswer: Cut them short and clean under them regularly."
    })
  },
  {
    id: "G4-HS-PH-05",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Overall Body Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Good personal hygiene involves more than just bathing and includes caring for all parts of the body. Which of the following is part of a complete personal hygiene routine?,
      options: [Bathing, brushing teeth, washing hands, and caring for hair and nails., Only bathing., "Only wearing clean clothes., Only brushing hair."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing, brushing teeth, washing hands, and caring for hair and nails.
    })
  },

  // --- HOME HYGIENE (4 Materials) ---
  {
    id: G4-HS-HH-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the House",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A clean home prevents the spread of diseases and creates a comfortable living environment. What is the most effective way to keep your house clean?,
      options: [Sweep and mop floors daily, dust furniture, and clean surfaces., Clean only when visitors come., Just remove visible dirt.", "Clean only the kitchen.].sort(() => Math.random() - 0.5),
      correctAnswer: Sweep and mop floors daily, dust furniture, and clean surfaces."
    })
  },
  {
    id: "G4-HS-HH-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Cleaning the Kitchen,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The kitchen is where food is prepared, so it must be kept especially clean to prevent food contamination. Which area of the kitchen requires the most frequent cleaning?,
      options: [Food preparation surfaces and utensils after each use., The floor once a week.", "The ceiling every month., The windows once a year."].sort(() => Math.random() - 0.5),
      correctAnswer: "Food preparation surfaces and utensils after each use.
    })
  },
  {
    id: G4-HS-HH-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the Bathroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Bathrooms can be a breeding ground for bacteria and mold. What is the proper way to maintain bathroom hygiene?,
      options: [Clean the toilet, sink, and bathtub regularly with disinfectant., Only clean when it looks dirty., Rinse with water only.", "Never clean it.].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the toilet, sink, and bathtub regularly with disinfectant."
    })
  },
  {
    id: "G4-HS-HH-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper waste disposal is essential to prevent diseases and keep the environment clean. What should you do with household waste to maintain hygiene?,
      options: [Separate waste and dispose of it in designated bins regularly., Throw it outside the compound., "Burn it in the house., Bury it in the garden."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate waste and dispose of it in designated bins regularly.
    })
  },

  // --- CARE OF CLOTHING (4 Materials) ---
  {
    id: G4-HS-CC-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Washing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Proper washing keeps clothes clean, fresh, and long-lasting. What is the first step you should take before washing any clothes?,
      options: [Sort clothes by color and fabric type., Put all clothes in the water., Use hot water for all clothes.", "Add detergent without checking.].sort(() => Math.random() - 0.5),
      correctAnswer: Sort clothes by color and fabric type."
    })
  },
  {
    id: "G4-HS-CC-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Washing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Delicate fabrics require special care during washing to prevent damage. How should you wash delicate clothes like silk or wool?,
      options: [Wash them gently by hand with mild detergent in cool water., Wash them in a washing machine with hot water., "Soak them in bleach., Scrub them vigorously."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them gently by hand with mild detergent in cool water.
    })
  },
  {
    id: G4-HS-CC-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Ironing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Ironing removes wrinkles and makes clothes look neat and professional. What safety precaution should you take when using an electric iron?,
      options: [Keep the iron away from children and use it on an ironing board., Leave the iron on when not in use., Use it without water in the boiler.", "Iron clothes on the bed.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the iron away from children and use it on an ironing board."
    })
  },
  {
    id: "G4-HS-CC-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Storing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Proper storage protects clothes from damage and keeps them ready to wear. What is the best way to store clothes in a wardrobe?,
      options: [Fold them neatly or hang them, and keep the wardrobe clean and dry., Throw them in a pile., "Store wet clothes., Keep them in the sun."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fold them neatly or hang them, and keep the wardrobe clean and dry.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G4-HS-FN-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A balanced diet contains foods from all food groups to provide essential nutrients. Which of the following correctly lists the main food groups?,
      options: [Carbohydrates, proteins, vitamins, minerals, fats, and water., Rice, meat, and fruits only., Only proteins and carbohydrates.", "Only vegetables and fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vitamins, minerals, fats, and water."
    })
  },
  {
    id: "G4-HS-FN-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Balanced Diet,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A balanced diet is essential for growth, energy, and good health. What does a balanced diet consist of?,
      options: ["The right combination of foods from all food groups in the correct proportions., Eating only fruits and vegetables.", "Eating only carbohydrates., Eating whatever is available."].sort(() => Math.random() - 0.5),
      correctAnswer: "The right combination of foods from all food groups in the correct proportions.
    })
  },
  {
    id: G4-HS-FN-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Meal planning helps families eat nutritious meals and manage their food budget. When planning meals for a family, what should you consider?,
      options: [Nutritional needs, budget, preferences, and availability of food., Only the cost of food., Only the taste of food.", "Only what is available in the market.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional needs, budget, preferences, and availability of food."
    })
  },
  {
    id: "G4-HS-FN-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Food Groups,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different foods provide different nutrients needed by the body. Which food group is the main source of energy for the body?,
      options: [Carbohydrates like rice, bread, and potatoes., Proteins like meat and beans., "Vitamins from fruits and vegetables., Fats and oils."].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbohydrates like rice, bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G4-HS-FP-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kitchen safety is crucial to prevent accidents and injuries while cooking. What is the most important rule to follow in the kitchen?,
      options: [Never leave cooking food unattended and handle sharp tools carefully., Run around the kitchen., Use wet hands near electrical appliances.", "Leave all utensils on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Never leave cooking food unattended and handle sharp tools carefully."
    })
  },
  {
    id: "G4-HS-FP-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different cooking methods affect the taste, texture, and nutritional value of food. Which of the following is a healthy cooking method that preserves nutrients?,
      options: ["Steaming or boiling with minimal water., Deep frying in oil.", "Cooking for a very long time., Adding lots of salt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or boiling with minimal water.
    })
  },
  {
    id: G4-HS-FP-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Food can become contaminated if proper hygiene is not observed in the kitchen. What should you always do before handling food?,
      options: [Wash your hands thoroughly with soap and running water., Just rinse your hands., Wear gloves without washing hands.", "Wipe your hands on a cloth.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash your hands thoroughly with soap and running water."
    })
  },
  {
    id: "G4-HS-FP-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Boiling and steaming are common cooking methods in Kenyan homes. What is a disadvantage of boiling vegetables?,
      options: [Some water-soluble vitamins may be lost in the water., It takes too long., "It uses too much oil., It makes food too crispy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Some water-soluble vitamins may be lost in the water.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G4-HS-BEV-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Tea",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tea is a popular beverage in Kenya enjoyed by many families. What are the basic ingredients needed to prepare a cup of tea?,
      options: [Tea leaves, hot water, milk, and sugar., Coffee, milk, and sugar., Tea leaves and hot water only.", "Juice and water.].sort(() => Math.random() - 0.5),
      correctAnswer: Tea leaves, hot water, milk, and sugar."
    })
  },
  {
    id: "G4-HS-BEV-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Tea,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Tea can be prepared in different ways depending on preference. How is Kenyan tea traditionally prepared?,
      options: [Boiled with milk and sugar to make a creamy drink., Served with lemon and honey., "Served cold with ice., Mixed with soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiled with milk and sugar to make a creamy drink.
    })
  },
  {
    id: G4-HS-BEV-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Coffee",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Coffee is another popular beverage enjoyed in Kenya and around the world. What equipment is commonly used to brew coffee?,
      options: [A coffee maker or a traditional pot called a jebena., A pressure cooker., A microwave.", "A frying pan.].sort(() => Math.random() - 0.5),
      correctAnswer: A coffee maker or a traditional pot called a jebena."
    })
  },

  // --- SEWING AND NEEDLEWORK (3 Materials) ---
  {
    id: "G4-HS-SEW-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sewing is a valuable skill that allows you to mend and create clothes. What is the most basic and commonly used sewing stitch?,
      options: [The running stitch, The zigzag stitch, "The blanket stitch, The chain stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The running stitch
    })
  },
  {
    id: G4-HS-SEW-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Sewing and Needlework,
    subtopic: "Threading a Needle",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Before you can start sewing, you need to thread the needle correctly. What is the correct way to thread a needle?,
      options: [Wet the thread tip, pass it through the eye of the needle, and pull through., Push the needle through the thread., Tie the thread around the needle.", "Use a thick thread.].sort(() => Math.random() - 0.5),
      correctAnswer: Wet the thread tip, pass it through the eye of the needle, and pull through."
    })
  },
  {
    id: "G4-HS-SEW-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The backstitch is a strong stitch used for seams. How does a backstitch differ from a running stitch?,
      options: [The needle goes backward to create a continuous line of stitches., It is the same as a running stitch., "It uses a knot at every stitch., It is done with a machine."].sort(() => Math.random() - 0.5),
      correctAnswer: "The needle goes backward to create a continuous line of stitches.
    })
  },

  // --- HOME FURNISHINGS (3 Materials) ---
  {
    id: G4-HS-HF-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Arrangement of Furniture",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The arrangement of furniture affects how comfortable and functional a room is. What should you consider when arranging furniture in a room?,
      options: [The flow of movement, room size, and purpose of the room., Only the color of the furniture., Only the cost of the furniture.", "Put everything against the wall.].sort(() => Math.random() - 0.5),
      correctAnswer: The flow of movement, room size, and purpose of the room."
    })
  },
  {
    id: "G4-HS-HF-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Furnishings",
    subtopic: "Care of Home Items,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Furniture and furnishings need regular care to maintain their appearance and longevity. How should wooden furniture be cared for?,
      options: [Dust regularly and polish with appropriate wood polish., Wash with soap and water., "Leave them in the sun., Scrub with steel wool."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust regularly and polish with appropriate wood polish.
    })
  },
  {
    id: G4-HS-HF-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Care of Home Items",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Cushions, curtains, and carpets add comfort and beauty to a home. How should fabric furnishings be maintained?,
      options: [Vacuum regularly and clean spills immediately., Ignore stains., Wash them with harsh chemicals.", "Shake them outside only.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly and clean spills immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G4-HS-HS-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who is injured or suddenly becomes ill. What is the first thing you should do in an emergency?,
      options: [Stay calm and assess the situation, then call for help if needed., Run away from the scene., "Panic and scream., Ignore the person."].sort(() => Math.random() - 0.5),
      correctAnswer: "Stay calm and assess the situation, then call for help if needed.
    })
  },
  {
    id: G4-HS-HS-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Accidents at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Accidents can happen at home, especially in the kitchen and bathroom. What is a common cause of accidents in the kitchen?,
      options: [Slippery floors, handling hot items, and using knives carelessly., Eating too much., Talking while eating.", "Using the microwave.].sort(() => Math.random() - 0.5),
      correctAnswer: Slippery floors, handling hot items, and using knives carelessly."
    })
  },
  {
    id: "G4-HS-HS-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Knowing basic first aid can save lives in emergency situations. What should you do if someone gets a burn?,
      options: [Run cool water over the burn for several minutes and cover with a clean cloth., Put butter on the burn., "Pop any blisters., Ignore it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool water over the burn for several minutes and cover with a clean cloth.
    })
  },

  // --- TIME AND MONEY MANAGEMENT (2 Materials) ---
  {
    id: G4-HS-TM-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Time and Money Management,
    subtopic: "Planning Daily Chores",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Planning daily chores helps you use your time efficiently and keeps the home running smoothly. What is the best way to manage daily chores?,
      options: [Make a schedule or checklist and allocate time for each task., Do everything at the last minute., Only do chores on weekends.", "Let others do everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Make a schedule or checklist and allocate time for each task."
    })
  },
  {
    id: "G4-HS-TM-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Time and Money Management",
    subtopic: "Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Budgeting helps a family manage its money and ensure that all needs are met. What is the first step in creating a family budget?,
      options: [List all income and track all expenses., Buy whatever you want., "Only buy food., Save all money without spending."].sort(() => Math.random() - 0.5),
      correctAnswer: "List all income and track all expenses.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL GROOMING (4 Materials) ---
  {
    id: G5-HS-PG-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Skin Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Skin care is important for maintaining healthy skin and preventing skin conditions. What is the most important daily practice for healthy skin?,
      options: [Washing your face and body with soap and water daily., Using makeup every day., Scrubbing your skin roughly.", "Never moisturizing.].sort(() => Math.random() - 0.5),
      correctAnswer: Washing your face and body with soap and water daily."
    })
  },
  {
    id: "G5-HS-PG-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Well-groomed nails are a sign of good hygiene and personal care. How should you properly care for your nails?,
      options: [Keep them clean, trimmed, and filed regularly., Paint them with dark polish., "Bite them to keep them short., Never cut them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keep them clean, trimmed, and filed regularly.
    })
  },
  {
    id: G5-HS-PG-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Healthy hair requires proper care to prevent breakage and keep it looking good. What should you do to prevent dandruff and keep your scalp healthy?,
      options: [Wash hair regularly and use a gentle shampoo., Use hot oil every day., Never wash your hair.", "Use harsh chemicals.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly and use a gentle shampoo."
    })
  },
  {
    id: "G5-HS-PG-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Overall Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Good grooming involves taking care of your entire appearance and hygiene. Which of the following is a key element of good personal grooming?,
      options: [Wearing clean clothes, having neat hair, and practicing good hygiene., Wearing expensive clothes., "Using a lot of perfume., Having the latest hairstyle."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wearing clean clothes, having neat hair, and practicing good hygiene.
    })
  },

  // --- HOME CLEANING (4 Materials) ---
  {
    id: G5-HS-HC-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Different cleaning agents are used for different surfaces and purposes. What cleaning agent is used for cleaning glass and windows?,
      options: [Glass cleaner or vinegar solution., Bleach, Abrasive powder", "Dish soap].sort(() => Math.random() - 0.5),
      correctAnswer: Glass cleaner or vinegar solution."
    })
  },
  {
    id: "G5-HS-HC-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Sweeping and Mopping,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sweeping and mopping are essential for keeping floors clean and hygienic. What is the correct order for cleaning a floor?,
      options: [Sweep first to remove dirt and debris, then mop., Mop first, then sweep., "Only mop without sweeping., Only sweep without mopping."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweep first to remove dirt and debris, then mop.
    })
  },
  {
    id: G5-HS-HC-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Bleach is a strong cleaning agent that kills germs and removes stains. What safety precaution should be taken when using bleach?,
      options: [Use it in a well-ventilated area and never mix with other cleaners., Mix it with vinegar for more power., Use it on all surfaces.", "Use it without gloves.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it in a well-ventilated area and never mix with other cleaners."
    })
  },
  {
    id: "G5-HS-HC-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Cleaning Different Surfaces,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Different surfaces require different cleaning methods to avoid damage. How should wooden surfaces be cleaned?,
      options: [Dust with a soft cloth and use appropriate wood polish., Use water and soap., "Scrub with a hard brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust with a soft cloth and use appropriate wood polish.
    })
  },

  // --- LAUNDRY WORK (4 Materials) ---
  {
    id: G5-HS-LW-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Sorting Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Sorting clothes before washing prevents color bleeding and ensures proper care for different fabrics. How should you sort clothes before washing?,
      options: [Separate whites from colors and sort by fabric type., Wash all clothes together., Only sort by size.", "Only sort by owner.].sort(() => Math.random() - 0.5),
      correctAnswer: Separate whites from colors and sort by fabric type."
    })
  },
  {
    id: "G5-HS-LW-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Hand Washing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hand washing is a gentle method of washing clothes that is suitable for delicate fabrics. What is the correct water temperature for hand washing delicate clothes?,
      options: [Cold or lukewarm water., Very hot water., "Boiling water., Water of any temperature."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cold or lukewarm water.
    })
  },
  {
    id: G5-HS-LW-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Machine Washing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Washing machines make laundry work easier but require proper use. How can you prevent clothes from getting damaged in a washing machine?,
      options: [Use the correct cycle and load size for different fabrics., Overload the machine to save time., Use the hottest setting for all clothes.", "Use a lot of detergent.].sort(() => Math.random() - 0.5),
      correctAnswer: Use the correct cycle and load size for different fabrics."
    })
  },
  {
    id: "G5-HS-LW-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Drying Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper drying of clothes prevents damage and keeps them looking fresh. What is the best way to dry clothes to prevent shrinkage and damage?,
      options: [Air dry on a clothesline away from direct harsh sunlight., Tumble dry on high heat., "Iron them wet., Leave them in a pile."].sort(() => Math.random() - 0.5),
      correctAnswer: "Air dry on a clothesline away from direct harsh sunlight.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G5-HS-NU-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutrients and Their Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proteins are essential nutrients that the body needs for growth and repair. Which of the following foods is a rich source of protein?,
      options: [Beans, eggs, meat, and fish., Rice and bread., Fruits and vegetables.", "Sugar and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, eggs, meat, and fish."
    })
  },
  {
    id: "G5-HS-NU-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vitamins and minerals are important micronutrients that support various body functions. Which vitamin is important for healthy eyesight and is found in carrots and orange fruits?,
      options: [Vitamin A, Vitamin B, "Vitamin C, Vitamin D"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamin A
    })
  },
  {
    id: G5-HS-NU-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A balanced meal should contain foods from different food groups to provide all essential nutrients. What should be included in a balanced meal?,
      options: [Carbohydrates, proteins, vegetables, and fruits., Only meat and rice., Only vegetables.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vegetables, and fruits."
    })
  },
  {
    id: "G5-HS-NU-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Carbohydrates provide energy for the body to function. Which of the following is a healthy source of complex carbohydrates?,
      options: [Brown rice, whole grain bread, and potatoes., White sugar and sweets., "Cakes and pastries., Fizzy drinks."].sort(() => Math.random() - 0.5),
      correctAnswer: "Brown rice, whole grain bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G5-HS-FP-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vegetables provide essential vitamins and minerals and should be prepared properly to preserve their nutrients. What is the best way to cook vegetables to preserve their nutrients?,
      options: [Steam or stir-fry them quickly with minimal water., Boil them for a long time., Deep fry them.", "Microwave them for 30 minutes.].sort(() => Math.random() - 0.5),
      correctAnswer: Steam or stir-fry them quickly with minimal water."
    })
  },
  {
    id: "G5-HS-FP-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Preparing Soups,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Soup is a nutritious and comforting meal that can be made with various ingredients. What are the basic ingredients for making a vegetable soup?,
      options: [Vegetables, water or stock, and seasoning., Meat and flour., "Rice and tomatoes., Beans and coconut milk."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vegetables, water or stock, and seasoning.
    })
  },
  {
    id: G5-HS-FP-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Stews",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stews are hearty meals made by slowly cooking meat or vegetables in liquid. Which of the following is an important step when making a stew?,
      options: [Brown the meat first to add flavor, then add liquid and simmer., Just add everything to cold water., Cook on high heat for 10 minutes.", "Add all ingredients at once.].sort(() => Math.random() - 0.5),
      correctAnswer: Brown the meat first to add flavor, then add liquid and simmer."
    })
  },
  {
    id: "G5-HS-FP-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Kitchen Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kitchen hygiene is essential to prevent food poisoning and cross-contamination. What is the best way to prevent cross-contamination in the kitchen?,
      options: [Use separate chopping boards for raw meat and other foods., Use the same board for everything., "Wash the board only at the end of the day., Never wash cutting boards."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate chopping boards for raw meat and other foods.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G5-HS-BEV-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Fresh Juices",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh fruit juices are healthy and refreshing beverages rich in vitamins. What is the correct way to prepare fresh fruit juice?,
      options: [Wash fruits, peel if necessary, blend, and strain if desired., Add sugar and leave it overnight., Boil the fruits first.", "Use dried fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash fruits, peel if necessary, blend, and strain if desired."
    })
  },
  {
    id: "G5-HS-BEV-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Fresh Juices,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Smoothies are thicker than juices and often include milk or yogurt. What is a key ingredient that makes smoothies thick and creamy?,
      options: [Banana or yogurt, Water, "Oil, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Banana or yogurt
    })
  },
  {
    id: G5-HS-BEV-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Beverage Preparation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh juices are best consumed immediately after preparation. Why is it important to drink fresh juice soon after making it?,
      options: [To get the full nutritional benefits before vitamins are lost., To keep it from spoiling., To save time.", "To reduce sugar content.].sort(() => Math.random() - 0.5),
      correctAnswer: To get the full nutritional benefits before vitamins are lost."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G5-HS-NW-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Running Stitch,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The running stitch is one of the most basic and versatile hand stitches. What is the running stitch commonly used for?,
      options: [Basting, gathering fabric, and simple seams., Buttonholes., "Zipper insertion., Stitching leather."].sort(() => Math.random() - 0.5),
      correctAnswer: "Basting, gathering fabric, and simple seams.
    })
  },
  {
    id: G5-HS-NW-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Stitches - Backstitch",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The backstitch creates a strong and secure seam. How does the backstitch compare to the running stitch?,
      options: [The backstitch is stronger because each stitch overlaps the previous one., The backstitch is weaker., They are exactly the same.", "The backstitch is faster.].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch is stronger because each stitch overlaps the previous one."
    })
  },
  {
    id: "G5-HS-NW-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Hemming,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hemming is a finishing technique used to create a neat edge on garments and other fabric items. What is the purpose of hemming?,
      options: [To prevent the fabric from fraying and create a finished look., To make the garment longer., "To add decoration only., To make the garment tighter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and create a finished look.
    })
  },

  // --- HOME MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-HM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Windows",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clean windows allow natural light to enter and improve the appearance of a home. How should glass windows be cleaned to avoid streaks?,
      options: [Use a glass cleaner and a squeegee or microfiber cloth., Use soap and water with a sponge., Scrub with an abrasive pad.", "Use newspaper alone.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a glass cleaner and a squeegee or microfiber cloth."
    })
  },
  {
    id: "G5-HS-HM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Polishing Furniture,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Polishing wood furniture restores its shine and protects it from damage. What is the proper way to apply polish to wooden furniture?,
      options: [Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine., Pour polish directly on the furniture., "Use water instead of polish., Use a rough cloth to apply it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine.
    })
  },
  {
    id: G5-HS-HM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Maintaining Home Equipment",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Regular maintenance of home equipment extends their lifespan and ensures safety. Why is it important to regularly clean and service electrical appliances?,
      options: [To prevent accidents, save energy, and ensure they work efficiently., To keep them looking new., To avoid buying new ones.", "To reduce the electricity bill only.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent accidents, save energy, and ensure they work efficiently."
    })
  },

  // --- SAFETY IN THE HOME (3 Materials) ---
  {
    id: "G5-HS-SH-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Fire can be dangerous and cause serious injuries and property damage. What should you do if there is a small fire in the kitchen?,
      options: [Use a fire extinguisher or cover the fire with a lid to smother it., Pour water on a grease fire., "Run away and call for help., Blow on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a fire extinguisher or cover the fire with a lid to smother it.
    })
  },
  {
    id: G5-HS-SH-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Safety in the Home,
    subtopic: "Poison Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Many household products can be poisonous if ingested or misused. What is the best way to prevent poisoning in the home?,
      options: [Store cleaning products and medicines out of reach of children and in original containers., Keep them under the sink., Transfer them to unlabeled bottles.", "Leave them on the counter.].sort(() => Math.random() - 0.5),
      correctAnswer: Store cleaning products and medicines out of reach of children and in original containers."
    })
  },
  {
    id: "G5-HS-SH-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Prevention is better than cure when it comes to fire safety. Which of the following is a fire safety measure in the home?,
      options: [Have a working smoke detector and a fire escape plan., Leave candles burning when you leave the house., "Overload electrical sockets., Keep flammable materials near the stove."].sort(() => Math.random() - 0.5),
      correctAnswer: "Have a working smoke detector and a fire escape plan.
    })
  },

  // --- RESOURCE MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-RM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Using Resources Wisely",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Using resources wisely helps save money and protect the environment. What is one way to conserve water in the home?,
      options: [Repair leaking taps and use water sparingly., Leave taps running., Fill the bathtub completely.", "Use a hose to water the garden every day.].sort(() => Math.random() - 0.5),
      correctAnswer: Repair leaking taps and use water sparingly."
    })
  },
  {
    id: "G5-HS-RM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Resource Management",
    subtopic: "Using Resources Wisely,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Energy conservation reduces household bills and helps the environment. Which of the following is a way to save electricity at home?,
      options: [Turn off lights and appliances when not in use., Leave lights on all day., "Use old, inefficient appliances., Keep the refrigerator door open."].sort(() => Math.random() - 0.5),
      correctAnswer: "Turn off lights and appliances when not in use.
    })
  },
  {
    id: G5-HS-RM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Saving Money",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Saving money is an important habit that helps families prepare for emergencies and future needs. What is a simple way to start saving money at home?,
      options: [Set aside a small amount regularly in a savings box or bank account., Spend all money as soon as you get it., Borrow money for unnecessary items.", "Keep all money in a wallet.].sort(() => Math.random() - 0.5),
      correctAnswer: Set aside a small amount regularly in a savings box or bank account."
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HEALTH AND HYGIENE (5 Materials) ---
  {
    id: "G6-HS-PH-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Body Odor,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Body odor is caused by bacteria breaking down sweat on the skin. What is the most effective way to prevent body odor?,
      options: [Bathing daily with soap and using an antiperspirant or deodorant., Using perfume only., "Wearing the same clothes for days., Avoiding physical activity."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and using an antiperspirant or deodorant.
    })
  },
  {
    id: G6-HS-PH-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Dental Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Good dental hygiene prevents cavities, gum disease, and bad breath. What is the recommended technique for effective teeth brushing?,
      options: [Brush in circular motions for at least two minutes, covering all tooth surfaces., Brush back and forth quickly., Brush only the front teeth.", "Brush once a day.].sort(() => Math.random() - 0.5),
      correctAnswer: Brush in circular motions for at least two minutes, covering all tooth surfaces."
    })
  },
  {
    id: "G6-HS-PH-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Dental Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Flossing is an important part of dental hygiene that complements brushing. Why is flossing important for dental health?,
      options: [It removes plaque and food particles from between teeth where brushes cannot reach., It whitens teeth., "It replaces brushing., It strengthens tooth enamel."].sort(() => Math.random() - 0.5),
      correctAnswer: "It removes plaque and food particles from between teeth where brushes cannot reach.
    })
  },
  {
    id: G6-HS-PH-04",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper grooming involves maintaining a neat and clean appearance. Which of the following is an important aspect of personal grooming for adolescents?,
      options: [Regular bathing, hair care, nail care, and wearing clean clothes., Using expensive cosmetics., Following fashion trends blindly.", "Wearing heavy makeup.].sort(() => Math.random() - 0.5),
      correctAnswer: Regular bathing, hair care, nail care, and wearing clean clothes."
    })
  },
  {
    id: "G6-HS-PH-05",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Hygiene During Adolescence,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Adolescence brings physical changes that require extra attention to hygiene. What additional hygiene practices are important during adolescence?,
      options: [Washing face twice daily, using deodorant, and changing undergarments regularly., Bathing once a week., "Ignoring skin changes., Using adult products without guidance."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing face twice daily, using deodorant, and changing undergarments regularly.
    })
  },

  // --- HOME SANITATION (4 Materials) ---
  {
    id: G6-HS-HS-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Waste Disposal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper waste disposal is crucial for maintaining a healthy home environment. What is the recommended way to dispose of organic kitchen waste?,
      options: [Use it to make compost for gardening., Mix it with plastic waste., Burn it in the compound.", "Throw it in the toilet.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it to make compost for gardening."
    })
  },
  {
    id: "G6-HS-HS-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Improper waste disposal can lead to environmental pollution and health problems. What is the proper way to dispose of plastic and non-biodegradable waste?,
      options: [Separate for recycling or dispose of in designated bins., Burn it., "Bury it in the garden., Throw it in the river."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate for recycling or dispose of in designated bins.
    })
  },
  {
    id: G6-HS-HS-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pests like cockroaches, rats, and mosquitoes can spread diseases in the home. What is an effective way to control pests?,
      options: [Keep the home clean, seal food containers, and use appropriate pest control methods., Use insecticides without cleaning., Ignore them.", "Leave food uncovered.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the home clean, seal food containers, and use appropriate pest control methods."
    })
  },
  {
    id: "G6-HS-HS-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Pest Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mosquitoes are common pests that transmit diseases like malaria and dengue fever. How can you prevent mosquito breeding in and around the home?,
      options: [Eliminate standing water and use mosquito nets or repellents., Leave water containers open., "Use strong perfumes., Ignore puddles."].sort(() => Math.random() - 0.5),
      correctAnswer: "Eliminate standing water and use mosquito nets or repellents.
    })
  },

  // --- CLOTHING CARE (4 Materials) ---
  {
    id: G6-HS-CC-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Stain Removal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stains on clothes can be difficult to remove if not treated properly. What is the first step in removing a fresh stain from clothing?,
      options: [Treat it immediately by blotting and applying appropriate stain remover., Wait until it dries., Rub it with soap.", "Ignore it.].sort(() => Math.random() - 0.5),
      correctAnswer: Treat it immediately by blotting and applying appropriate stain remover."
    })
  },
  {
    id: "G6-HS-CC-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Stain Removal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Different stains require different treatment methods. How should you treat a grease or oil stain on a garment?,
      options: [Apply a small amount of dish soap or stain remover and wash in warm water., Use hot water immediately., "Rub with a cloth., Apply bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply a small amount of dish soap or stain remover and wash in warm water.
    })
  },
  {
    id: G6-HS-CC-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Mending Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Mending clothes extends their lifespan and saves money. What is the best way to mend a small tear in a garment?,
      options: [Use a needle and thread to stitch it neatly, matching the fabric., Use glue or tape., Ignore the tear.", "Cut the garment.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a needle and thread to stitch it neatly, matching the fabric."
    })
  },
  {
    id: "G6-HS-CC-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Pressing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pressing clothes properly gives them a neat, crisp appearance. What temperature setting should you use when ironing synthetic fabrics?,
      options: [A low to medium temperature setting to prevent melting or scorching., The highest setting.", "No heat., Steam only."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low to medium temperature setting to prevent melting or scorching.
    })
  },

  // --- ADVANCED NUTRITION (4 Materials) ---
  {
    id: G6-HS-AN-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Meal Planning for Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meal planning for a family should consider the nutritional needs of all members. What factors should be considered when planning meals for a family with members of different ages?,
      options: [Nutritional requirements of different age groups, preferences, and budget., Only the preference of adults., Only the cost.", "Only one type of food.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional requirements of different age groups, preferences, and budget."
    })
  },
  {
    id: "G6-HS-AN-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Meal Planning for Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Special diets may be needed for people with certain health conditions. What is an example of a special diet that may be recommended by a doctor?,
      options: [A low-sodium diet for high blood pressure., A high-sugar diet., "A food-free diet., A non-vegetarian diet."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low-sodium diet for high blood pressure.
    })
  },
  {
    id: G6-HS-AN-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Nutritional Needs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Children in their growth years require extra nutrients for proper development. Which nutrients are particularly important for growing children?,
      options: [Calcium, iron, and protein for bone growth and muscle development., Only fat., Only sugar.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Calcium, iron, and protein for bone growth and muscle development."
    })
  },
  {
    id: "G6-HS-AN-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Nutritional Needs,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pregnant and breastfeeding mothers have increased nutritional requirements. Which nutrients are especially important during pregnancy?,
      options: [Folic acid, iron, calcium, and protein., Only carbohydrates., "Only fats., Only sugar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Folic acid, iron, calcium, and protein.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G6-HS-FP-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Boiling",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Boiling is a common cooking method that uses water or liquid to cook food. What is a disadvantage of boiling vegetables for too long?,
      options: [It can destroy heat-sensitive vitamins like Vitamin C., It makes them too hard., It makes them too sweet.", "It adds too much oil.].sort(() => Math.random() - 0.5),
      correctAnswer: It can destroy heat-sensitive vitamins like Vitamin C."
    })
  },
  {
    id: "G6-HS-FP-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods - Frying,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Frying involves cooking food in hot oil or fat. What is a health concern associated with deep frying foods?,
      options: [The food absorbs a lot of fat, increasing calorie content., It makes food dry., "It removes all nutrients., It takes too long."].sort(() => Math.random() - 0.5),
      correctAnswer: "The food absorbs a lot of fat, increasing calorie content.
    })
  },
  {
    id: G6-HS-FP-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Roasting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Roasting is a dry-heat cooking method that is often used for meat and vegetables. What is a benefit of roasting food?,
      options: [It enhances the natural flavor without adding extra fat., It preserves all nutrients., It is the fastest method.", "It requires no preparation.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances the natural flavor without adding extra fat."
    })
  },
  {
    id: "G6-HS-FP-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Food safety involves proper handling, cooking, and storage of food to prevent foodborne illness. What is the recommended internal temperature for cooking poultry to ensure it is safe to eat?,
      options: ["74°C (165°F), 50°C", "100°C, 25°C"].sort(() => Math.random() - 0.5),
      correctAnswer: "74°C (165°F)
    })
  },

  // --- KITCHEN MANAGEMENT (3 Materials) ---
  {
    id: G6-HS-KM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Organizing the Kitchen",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " An organized kitchen makes cooking easier and more efficient. What is the principle of organizing kitchen items based on frequency of use?,
      options: [Store frequently used items at eye level and within easy reach., Store everything randomly., Keep all items in cupboards.", "Store items on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Store frequently used items at eye level and within easy reach."
    })
  },
  {
    id: "G6-HS-KM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Kitchen Management",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper food storage prevents spoilage and reduces waste. How should perishable foods like meat and dairy be stored?,
      options: [In the refrigerator at temperatures below 5°C (41°F)., On the kitchen counter., "In a cupboard., In direct sunlight."].sort(() => Math.random() - 0.5),
      correctAnswer: "In the refrigerator at temperatures below 5°C (41°F).
    })
  },
  {
    id: G6-HS-KM-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Food Storage",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Dry goods like grains, cereals, and legumes should be stored properly to prevent infestation. What is the best way to store dry goods?,
      options: [Store in airtight containers in a cool, dry place., Store in paper bags., Store in the refrigerator.", "Store in sunlight.].sort(() => Math.random() - 0.5),
      correctAnswer: Store in airtight containers in a cool, dry place."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G6-HS-NW-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Decorative stitches can add beauty and personal touch to garments and crafts. Which of the following is a decorative stitch used in embroidery?,
      options: [The chain stitch, The running stitch, "The tacking stitch, The stay stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The chain stitch
    })
  },
  {
    id: G6-HS-NW-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Repairing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Repairing clothes saves money and reduces waste. What stitch would you use to repair a seam that has come undone?,
      options: [The backstitch, The running stitch, The blanket stitch", "The chain stitch].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch"
    })
  },
  {
    id: "G6-HS-NW-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The blanket stitch is a decorative and functional stitch used for edges. Where is the blanket stitch commonly used?,
      options: [On blankets, tablecloths, and fabric edges to prevent fraying., For sewing buttons., "For hemming curtains., For attaching zippers."].sort(() => Math.random() - 0.5),
      correctAnswer: "On blankets, tablecloths, and fabric edges to prevent fraying.
    })
  },

  // --- HOME DECORATION (3 Materials) ---
  {
    id: G6-HS-HD-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Arranging Rooms",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper room arrangement creates a comfortable and functional living space. What principle should guide the arrangement of furniture in a living room?,
      options: [Create conversation areas and maintain easy traffic flow., Push all furniture against the walls., Fill every space with furniture.", "Place furniture randomly.].sort(() => Math.random() - 0.5),
      correctAnswer: Create conversation areas and maintain easy traffic flow."
    })
  },
  {
    id: "G6-HS-HD-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Decoration",
    subtopic: "Color Coordination,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Color coordination creates harmony and mood in a room. What colors create a calm and relaxing atmosphere?,
      options: [Cool colors like blue, green, and soft neutrals., Bright red and orange., "Neon colors., Dark brown and black."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cool colors like blue, green, and soft neutrals.
    })
  },
  {
    id: G6-HS-HD-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Color Coordination",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Warm colors like red, orange, and yellow create a lively and energetic atmosphere. In which room would warm colors be most appropriate?,
      options: [In the living room or dining room to create a welcoming feel., In the bedroom to promote rest., In the study to aid concentration.", "In the bathroom.].sort(() => Math.random() - 0.5),
      correctAnswer: In the living room or dining room to create a welcoming feel."
    })
  },

  // --- FIRST AID (3 Materials) ---
  {
    id: "G6-HS-FA-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Cuts,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Cuts and wounds can become infected if not treated properly. What is the correct procedure for treating a minor cut?,
      options: [Clean with soap and water, apply an antiseptic, and cover with a clean bandage., Ignore it., "Apply butter., Rub with dirt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean with soap and water, apply an antiseptic, and cover with a clean bandage.
    })
  },
  {
    id: G6-HS-FA-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "First Aid,
    subtopic: "Treating Burns",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Burns can be painful and cause serious damage to the skin. What should you do immediately after a minor burn?,
      options: [Place the burn under cool running water for several minutes., Apply ice directly to the burn., Apply oil or butter.", "Pop any blisters.].sort(() => Math.random() - 0.5),
      correctAnswer: Place the burn under cool running water for several minutes."
    })
  },
  {
    id: "G6-HS-FA-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Minor Injuries,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sprains and strains are common injuries that can occur at home or during physical activity. What is the RICE method for treating sprains?,
      options: [Rest, Ice, Compression, Elevation, Run, Ice, Compression, Exercise, "Rest, Ice, Cool, Exercise, Raise, Ice, Compress, Elevate"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rest, Ice, Compression, Elevation
    })
  },

  // --- FINANCIAL MANAGEMENT (2 Materials) ---
  {
    id: G6-HS-FM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Financial Management,
    subtopic: "Saving",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Saving money is an important financial habit that helps achieve goals and provides security. What is the recommended percentage of income to save?,
      options: [At least 10-20% of income should be saved regularly., Save all income., Save nothing.", "Save only when there is extra.].sort(() => Math.random() - 0.5),
      correctAnswer: At least 10-20% of income should be saved regularly."
    })
  },
  {
    id: "G6-HS-FM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Financial Management",
    subtopic: "Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Entrepreneurship involves creating a business to generate income. What is a simple home-based business idea that a family could start?,
      options: [Baking and selling cakes, catering services, or making crafts., Buying expensive cars., "Investing in stocks without research., Borrowing money without a plan."].sort(() => Math.random() - 0.5),
      correctAnswer: "Baking and selling cakes, catering services, or making crafts.
    })
  },

  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL DEVELOPMENT (4 Materials) ---
  {
    id: G7-HS-PD-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Personal grooming reflects self-respect and creates a positive impression. What is the importance of proper grooming in daily life?,
      options: [It enhances self-confidence and shows respect for oneself and others., It is only for formal occasions., It is unnecessary.", "It takes too much time.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances self-confidence and shows respect for oneself and others."
    })
  },
  {
    id: "G7-HS-PD-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Posture,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Good posture is important for health and appearance. What are the benefits of maintaining good posture?,
      options: [Prevents back pain, improves breathing, and creates a confident appearance., Causes back pain., "Has no effect., Is only important for athletes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Prevents back pain, improves breathing, and creates a confident appearance.
    })
  },
  {
    id: G7-HS-PD-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Personal hygiene is essential for maintaining health and preventing disease. Why is it important to wash hands frequently?,
      options: [To prevent the spread of germs and reduce the risk of infectious diseases., To keep hands soft., To avoid using gloves.", "To save water.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent the spread of germs and reduce the risk of infectious diseases."
    })
  },
  {
    id: "G7-HS-PD-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Choosing appropriate clothing for different occasions is part of good grooming. What should you consider when selecting clothes for different occasions?,
      options: [Dress code, weather, comfort, and cultural appropriateness., Only the latest fashion., "Only bright colors., Only expensive brands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dress code, weather, comfort, and cultural appropriateness.
    })
  },

  // --- HOME CARE (4 Materials) ---
  {
    id: G7-HS-HC-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Cleaning Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different cleaning methods are suitable for different surfaces and materials. What cleaning method is appropriate for cleaning tile floors?,
      options: [Mop with warm water and a suitable floor cleaner., Scrub with a wire brush., Use dry sweeping only.", "Use bleach without water.].sort(() => Math.random() - 0.5),
      correctAnswer: Mop with warm water and a suitable floor cleaner."
    })
  },
  {
    id: "G7-HS-HC-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Carpets and rugs require special care to maintain their appearance and hygiene. How should carpets be cleaned regularly?,
      options: [Vacuum regularly and have them professionally cleaned periodically., Wash with a hose., "Scrub with a brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vacuum regularly and have them professionally cleaned periodically.
    })
  },
  {
    id: G7-HS-HC-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Disinfectants",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Disinfectants are chemicals used to kill germs and bacteria on surfaces. What is the difference between a cleaner and a disinfectant?,
      options: [Cleaners remove dirt, while disinfectants kill germs and bacteria., They are the same thing., Cleaners are stronger.", "Disinfectants are not safe to use.].sort(() => Math.random() - 0.5),
      correctAnswer: Cleaners remove dirt, while disinfectants kill germs and bacteria."
    })
  },
  {
    id: "G7-HS-HC-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Natural cleaning agents like vinegar, lemon, and baking soda are effective and eco-friendly. What can vinegar be used for in household cleaning?,
      options: ["Removing limescale, glass cleaning, and deodorizing., Polishing wood.", "Cleaning carpets., Washing clothes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Removing limescale, glass cleaning, and deodorizing.
    })
  },

  // --- LAUNDRY AND TEXTILE CARE (4 Materials) ---
  {
    id: G7-HS-LT-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Fabric Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Different fabrics require different care methods. Which of the following is a natural fiber commonly used in clothing?,
      options: [Cotton, Polyester, Nylon", "Spandex].sort(() => Math.random() - 0.5),
      correctAnswer: Cotton"
    })
  },
  {
    id: "G7-HS-LT-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Fabric Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Synthetic fabrics like polyester and nylon are made from petroleum-based materials. What is an advantage of synthetic fabrics over natural fibers?,
      options: [They are often more durable and wrinkle-resistant., They breathe better., "They are more absorbent., They are all biodegradable."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are often more durable and wrinkle-resistant.
    })
  },
  {
    id: G7-HS-LT-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Laundry Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different laundry agents are used for different purposes in washing. What is the function of fabric softener in laundry?,
      options: [Softens fabrics and reduces static electricity., Removes stains., Whitens clothes.", "Kills germs.].sort(() => Math.random() - 0.5),
      correctAnswer: Softens fabrics and reduces static electricity."
    })
  },
  {
    id: "G7-HS-LT-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Laundry Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bleach is a strong chemical agent used in laundry for whitening and disinfecting. What is the proper way to use bleach?,
      options: [Dilute as directed and use only on white fabrics, avoiding colored clothes., Use on all fabrics., "Pour directly on clothes., Mix with vinegar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dilute as directed and use only on white fabrics, avoiding colored clothes.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G7-HS-FN-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Macronutrients are nutrients required in large amounts by the body. Which of the following are the three main macronutrients?,
      options: [Carbohydrates, proteins, and fats., Vitamins, minerals, and water., Carbohydrates, vitamins, and minerals.", "Proteins, minerals, and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, and fats."
    })
  },
  {
    id: "G7-HS-FN-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Micronutrients are essential nutrients required in small amounts. What is the difference between vitamins and minerals?,
      options: [Vitamins are organic compounds, while minerals are inorganic elements., Vitamins are inorganic, minerals are organic., "They are the same., Vitamins are only found in meat."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins are organic compounds, while minerals are inorganic elements.
    })
  },
  {
    id: G7-HS-FN-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proteins are essential for building and repairing body tissues. What is a complete protein source that contains all essential amino acids?,
      options: [Animal products like meat, eggs, and dairy., Beans and lentils., Grains.", "Vegetables.].sort(() => Math.random() - 0.5),
      correctAnswer: Animal products like meat, eggs, and dairy."
    })
  },
  {
    id: "G7-HS-FN-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Iron is an important mineral that plays a key role in oxygen transport in the blood. What is a common sign of iron deficiency?,
      options: [Fatigue, weakness, and pale skin., High energy levels., "Weight gain., Good eyesight."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fatigue, weakness, and pale skin.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G7-HS-FP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Meat",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meat must be cooked thoroughly to kill harmful bacteria and ensure safety. What is the recommended cooking method for tough cuts of meat?,
      options: [Slow cooking with moisture, like stewing or braising., Quick frying., Grilling for a short time.", "Microwaving.].sort(() => Math.random() - 0.5),
      correctAnswer: Slow cooking with moisture, like stewing or braising."
    })
  },
  {
    id: "G7-HS-FP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Fish,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fish is a nutritious food that is quick and easy to cook. What cooking method preserves the delicate texture of fish?,
      options: [Steaming or grilling gently., Deep frying., "Boiling for hours., Pressure cooking."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or grilling gently.
    })
  },
  {
    id: G7-HS-FP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Poultry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Chicken is a commonly consumed poultry meat that requires proper handling and cooking. What is the safe internal temperature for cooked chicken?,
      options: [74°C (165°F), 60°C, 80°C", "50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 74°C (165°F)"
    })
  },
  {
    id: "G7-HS-FP-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Cross-contamination is a major cause of foodborne illness. How can cross-contamination be prevented in the kitchen?,
      options: [Use separate cutting boards and utensils for raw meat and ready-to-eat foods., Use the same board for everything., "Wash hands only after cooking., Store raw meat above cooked food."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate cutting boards and utensils for raw meat and ready-to-eat foods.
    })
  },

  // --- BEVERAGE PREPARATION (3 Materials) ---
  {
    id: G7-HS-BP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Traditional drinks are an important part of Kenyan culture. What is a traditional Kenyan drink made from fermented dairy?,
      options: [Maziwa lala (fermented milk), Coffee, Tea", "Juice].sort(() => Math.random() - 0.5),
      correctAnswer: Maziwa lala (fermented milk)"
    })
  },
  {
    id: "G7-HS-BP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Beverage Preparation",
    subtopic: "Modern Drinks,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Smoothies are popular modern drinks that can be made with various fruits and liquids. What is a healthy ingredient that can be added to smoothies for extra nutrition?,
      options: [Oats, chia seeds, or spirulina., Sugar., "Ice cream., Soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Oats, chia seeds, or spirulina.
    })
  },
  {
    id: G7-HS-BP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fruit and vegetable juices can be combined to create nutritious beverages. Which combination of fruits and vegetables creates a nutrient-rich juice?,
      options: [Carrot, ginger, and orange., Soda and syrup., Coffee and cream.", "Tea and sugar.].sort(() => Math.random() - 0.5),
      correctAnswer: Carrot, ginger, and orange."
    })
  },

  // --- SEWING TECHNIQUES (3 Materials) ---
  {
    id: "G7-HS-ST-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Darts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Darts are used in garment construction to shape fabric to the body. Where are darts commonly placed in garments?,
      options: [At the bust, waist, and shoulder to create shape and fit., On the hem., "At the collar., On the cuffs."].sort(() => Math.random() - 0.5),
      correctAnswer: "At the bust, waist, and shoulder to create shape and fit.
    })
  },
  {
    id: G7-HS-ST-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Sewing Techniques,
    subtopic: "Gathers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Gathers are used to create fullness in garments and add decorative detail. What is the technique used to create gathers in fabric?,
      options: [Use a long running stitch and pull the thread to gather the fabric., Use a backstitch., Use a buttonhole stitch.", "Use a zigzag stitch.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a long running stitch and pull the thread to gather the fabric."
    })
  },
  {
    id: "G7-HS-ST-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Seams,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Seams are the lines of stitching that join pieces of fabric together. What is the purpose of finishing a seam?,
      options: [To prevent the fabric from fraying and give a professional finish., To make the seam stronger., "To add color., To make the garment heavier."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and give a professional finish.
    })
  },

  // --- HOME ENVIRONMENT (3 Materials) ---
  {
    id: G7-HS-HE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Ventilation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Good ventilation is important for maintaining a healthy indoor environment. Why is proper ventilation important in the home?,
      options: [To remove stale air, control humidity, and reduce the spread of airborne diseases., To keep the house cold., To save energy.", "To block outside air.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove stale air, control humidity, and reduce the spread of airborne diseases."
    })
  },
  {
    id: "G7-HS-HE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Environment",
    subtopic: "Lighting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper lighting in the home is important for safety and comfort. What are the three types of lighting used in interior design?,
      options: [Ambient, task, and accent lighting., Natural, artificial, and candle., "Indoor, outdoor, and emergency., Direct, indirect, and reflected."].sort(() => Math.random() - 0.5),
      correctAnswer: "Ambient, task, and accent lighting.
    })
  },
  {
    id: G7-HS-HE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Furniture Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Regular furniture care extends its lifespan and maintains its appearance. What is the correct way to care for upholstered furniture?,
      options: [Vacuum regularly, rotate cushions, and treat stains immediately., Use water on all fabrics., Scrub harshly.", "Ignore spills.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly, rotate cushions, and treat stains immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G7-HS-HS-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kitchen safety is essential to prevent accidents and injuries. What safety measure should be taken when using sharp knives?,
      options: [Cut away from the body and keep knives sharp for better control., Use dull knives., "Cut toward the body., Leave knives in the sink."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cut away from the body and keep knives sharp for better control.
    })
  },
  {
    id: G7-HS-HS-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Food Poisoning Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Food poisoning is caused by consuming contaminated food. What is the recommended temperature range for refrigerating perishable foods?,
      options: [0-5°C (32-41°F), 10-20°C, 25-30°C", "40-50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 0-5°C (32-41°F)"
    })
  },
  {
    id: "G7-HS-HS-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Accidents in the kitchen can be caused by burns from hot liquids and surfaces. What should you do if you spill hot liquid on yourself?,
      options: [Quickly remove the clothing from the area and run cool water over the burn., Ignore it., "Apply heat., Put butter on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Quickly remove the clothing from the area and run cool water over the burn.
    })
  },

  // --- CONSUMER EDUCATION (3 Materials) ---
  {
    id: G7-HS-CE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Wise Buying",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Wise buying involves making informed purchasing decisions. What should a consumer check when comparing products before buying?,
      options: [Quality, price, quantity, and expiry date., Only the price., Only the brand.", "Only the color.].sort(() => Math.random() - 0.5),
      correctAnswer: Quality, price, quantity, and expiry date."
    })
  },
  {
    id: "G7-HS-CE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Consumer Education",
    subtopic: "Wise Buying,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Understanding food labels helps consumers make informed choices about the food they buy. What information is required on a food label?,
      options: [List of ingredients, expiry date, and nutritional information., Only the price., "Only the brand name., Only the weight."].sort(() => Math.random() - 0.5),
      correctAnswer: "List of ingredients, expiry date, and nutritional information.
    })
  },
  {
    id: G7-HS-CE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Advertising",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Advertising influences consumer choices and can sometimes be misleading. What should a savvy consumer do when evaluating advertisements?,
      options: [Compare information from different sources and avoid impulse buying., Believe every advertisement., Buy immediately.", "Ignore all advertising.].sort(() => Math.random() - 0.5),
      correctAnswer: Compare information from different sources and avoid impulse buying."
    })
  }`nexport const homeScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G4-HS-PH-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "Keeping our bodies clean is essential for good health and prevents the spread of germs. Which of the following is the most important practice for maintaining good personal hygiene?,
      options: [Bathing daily with soap and water., Bathing once a week., "Using perfume instead of bathing., Wearing clean clothes but not bathing."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water.
    })
  },
  {
    id: G4-HS-PH-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Hair",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Healthy hair requires proper care and regular maintenance. What is the correct way to care for your hair to keep it clean and healthy?,
      options: [Wash hair regularly with shampoo and comb it gently., Wash hair with soap only., Never wash hair to keep it strong.", "Use oil without washing.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly with shampoo and comb it gently."
    })
  },
  {
    id: "G4-HS-PH-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Teeth,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Dental hygiene is important to prevent cavities and bad breath. According to dental health guidelines, how often should you brush your teeth?,
      options: [At least twice a day, morning and before bed., Once a week.", "Only when they feel dirty., Once a month."].sort(() => Math.random() - 0.5),
      correctAnswer: "At least twice a day, morning and before bed.
    })
  },
  {
    id: G4-HS-PH-04",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Nails",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Dirty and long nails can harbor germs that cause infections. What is the proper way to care for your nails?,
      options: [Cut them short and clean under them regularly., Let them grow long and paint them., Bite them to keep them short.", "Never cut them.].sort(() => Math.random() - 0.5),
      correctAnswer: Cut them short and clean under them regularly."
    })
  },
  {
    id: "G4-HS-PH-05",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Overall Body Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Good personal hygiene involves more than just bathing and includes caring for all parts of the body. Which of the following is part of a complete personal hygiene routine?,
      options: [Bathing, brushing teeth, washing hands, and caring for hair and nails., Only bathing., "Only wearing clean clothes., Only brushing hair."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing, brushing teeth, washing hands, and caring for hair and nails.
    })
  },

  // --- HOME HYGIENE (4 Materials) ---
  {
    id: G4-HS-HH-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the House",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A clean home prevents the spread of diseases and creates a comfortable living environment. What is the most effective way to keep your house clean?,
      options: [Sweep and mop floors daily, dust furniture, and clean surfaces., Clean only when visitors come., Just remove visible dirt.", "Clean only the kitchen.].sort(() => Math.random() - 0.5),
      correctAnswer: Sweep and mop floors daily, dust furniture, and clean surfaces."
    })
  },
  {
    id: "G4-HS-HH-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Cleaning the Kitchen,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The kitchen is where food is prepared, so it must be kept especially clean to prevent food contamination. Which area of the kitchen requires the most frequent cleaning?,
      options: [Food preparation surfaces and utensils after each use., The floor once a week.", "The ceiling every month., The windows once a year."].sort(() => Math.random() - 0.5),
      correctAnswer: "Food preparation surfaces and utensils after each use.
    })
  },
  {
    id: G4-HS-HH-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the Bathroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Bathrooms can be a breeding ground for bacteria and mold. What is the proper way to maintain bathroom hygiene?,
      options: [Clean the toilet, sink, and bathtub regularly with disinfectant., Only clean when it looks dirty., Rinse with water only.", "Never clean it.].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the toilet, sink, and bathtub regularly with disinfectant."
    })
  },
  {
    id: "G4-HS-HH-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper waste disposal is essential to prevent diseases and keep the environment clean. What should you do with household waste to maintain hygiene?,
      options: [Separate waste and dispose of it in designated bins regularly., Throw it outside the compound., "Burn it in the house., Bury it in the garden."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate waste and dispose of it in designated bins regularly.
    })
  },

  // --- CARE OF CLOTHING (4 Materials) ---
  {
    id: G4-HS-CC-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Washing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Proper washing keeps clothes clean, fresh, and long-lasting. What is the first step you should take before washing any clothes?,
      options: [Sort clothes by color and fabric type., Put all clothes in the water., Use hot water for all clothes.", "Add detergent without checking.].sort(() => Math.random() - 0.5),
      correctAnswer: Sort clothes by color and fabric type."
    })
  },
  {
    id: "G4-HS-CC-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Washing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Delicate fabrics require special care during washing to prevent damage. How should you wash delicate clothes like silk or wool?,
      options: [Wash them gently by hand with mild detergent in cool water., Wash them in a washing machine with hot water., "Soak them in bleach., Scrub them vigorously."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them gently by hand with mild detergent in cool water.
    })
  },
  {
    id: G4-HS-CC-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Ironing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Ironing removes wrinkles and makes clothes look neat and professional. What safety precaution should you take when using an electric iron?,
      options: [Keep the iron away from children and use it on an ironing board., Leave the iron on when not in use., Use it without water in the boiler.", "Iron clothes on the bed.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the iron away from children and use it on an ironing board."
    })
  },
  {
    id: "G4-HS-CC-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Storing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Proper storage protects clothes from damage and keeps them ready to wear. What is the best way to store clothes in a wardrobe?,
      options: [Fold them neatly or hang them, and keep the wardrobe clean and dry., Throw them in a pile., "Store wet clothes., Keep them in the sun."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fold them neatly or hang them, and keep the wardrobe clean and dry.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G4-HS-FN-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A balanced diet contains foods from all food groups to provide essential nutrients. Which of the following correctly lists the main food groups?,
      options: [Carbohydrates, proteins, vitamins, minerals, fats, and water., Rice, meat, and fruits only., Only proteins and carbohydrates.", "Only vegetables and fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vitamins, minerals, fats, and water."
    })
  },
  {
    id: "G4-HS-FN-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Balanced Diet,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A balanced diet is essential for growth, energy, and good health. What does a balanced diet consist of?,
      options: ["The right combination of foods from all food groups in the correct proportions., Eating only fruits and vegetables.", "Eating only carbohydrates., Eating whatever is available."].sort(() => Math.random() - 0.5),
      correctAnswer: "The right combination of foods from all food groups in the correct proportions.
    })
  },
  {
    id: G4-HS-FN-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Meal planning helps families eat nutritious meals and manage their food budget. When planning meals for a family, what should you consider?,
      options: [Nutritional needs, budget, preferences, and availability of food., Only the cost of food., Only the taste of food.", "Only what is available in the market.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional needs, budget, preferences, and availability of food."
    })
  },
  {
    id: "G4-HS-FN-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Food Groups,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different foods provide different nutrients needed by the body. Which food group is the main source of energy for the body?,
      options: [Carbohydrates like rice, bread, and potatoes., Proteins like meat and beans., "Vitamins from fruits and vegetables., Fats and oils."].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbohydrates like rice, bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G4-HS-FP-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kitchen safety is crucial to prevent accidents and injuries while cooking. What is the most important rule to follow in the kitchen?,
      options: [Never leave cooking food unattended and handle sharp tools carefully., Run around the kitchen., Use wet hands near electrical appliances.", "Leave all utensils on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Never leave cooking food unattended and handle sharp tools carefully."
    })
  },
  {
    id: "G4-HS-FP-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different cooking methods affect the taste, texture, and nutritional value of food. Which of the following is a healthy cooking method that preserves nutrients?,
      options: ["Steaming or boiling with minimal water., Deep frying in oil.", "Cooking for a very long time., Adding lots of salt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or boiling with minimal water.
    })
  },
  {
    id: G4-HS-FP-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Food can become contaminated if proper hygiene is not observed in the kitchen. What should you always do before handling food?,
      options: [Wash your hands thoroughly with soap and running water., Just rinse your hands., Wear gloves without washing hands.", "Wipe your hands on a cloth.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash your hands thoroughly with soap and running water."
    })
  },
  {
    id: "G4-HS-FP-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Boiling and steaming are common cooking methods in Kenyan homes. What is a disadvantage of boiling vegetables?,
      options: [Some water-soluble vitamins may be lost in the water., It takes too long., "It uses too much oil., It makes food too crispy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Some water-soluble vitamins may be lost in the water.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G4-HS-BEV-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Tea",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tea is a popular beverage in Kenya enjoyed by many families. What are the basic ingredients needed to prepare a cup of tea?,
      options: [Tea leaves, hot water, milk, and sugar., Coffee, milk, and sugar., Tea leaves and hot water only.", "Juice and water.].sort(() => Math.random() - 0.5),
      correctAnswer: Tea leaves, hot water, milk, and sugar."
    })
  },
  {
    id: "G4-HS-BEV-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Tea,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Tea can be prepared in different ways depending on preference. How is Kenyan tea traditionally prepared?,
      options: [Boiled with milk and sugar to make a creamy drink., Served with lemon and honey., "Served cold with ice., Mixed with soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiled with milk and sugar to make a creamy drink.
    })
  },
  {
    id: G4-HS-BEV-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Coffee",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Coffee is another popular beverage enjoyed in Kenya and around the world. What equipment is commonly used to brew coffee?,
      options: [A coffee maker or a traditional pot called a jebena., A pressure cooker., A microwave.", "A frying pan.].sort(() => Math.random() - 0.5),
      correctAnswer: A coffee maker or a traditional pot called a jebena."
    })
  },

  // --- SEWING AND NEEDLEWORK (3 Materials) ---
  {
    id: "G4-HS-SEW-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sewing is a valuable skill that allows you to mend and create clothes. What is the most basic and commonly used sewing stitch?,
      options: [The running stitch, The zigzag stitch, "The blanket stitch, The chain stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The running stitch
    })
  },
  {
    id: G4-HS-SEW-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Sewing and Needlework,
    subtopic: "Threading a Needle",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Before you can start sewing, you need to thread the needle correctly. What is the correct way to thread a needle?,
      options: [Wet the thread tip, pass it through the eye of the needle, and pull through., Push the needle through the thread., Tie the thread around the needle.", "Use a thick thread.].sort(() => Math.random() - 0.5),
      correctAnswer: Wet the thread tip, pass it through the eye of the needle, and pull through."
    })
  },
  {
    id: "G4-HS-SEW-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The backstitch is a strong stitch used for seams. How does a backstitch differ from a running stitch?,
      options: [The needle goes backward to create a continuous line of stitches., It is the same as a running stitch., "It uses a knot at every stitch., It is done with a machine."].sort(() => Math.random() - 0.5),
      correctAnswer: "The needle goes backward to create a continuous line of stitches.
    })
  },

  // --- HOME FURNISHINGS (3 Materials) ---
  {
    id: G4-HS-HF-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Arrangement of Furniture",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The arrangement of furniture affects how comfortable and functional a room is. What should you consider when arranging furniture in a room?,
      options: [The flow of movement, room size, and purpose of the room., Only the color of the furniture., Only the cost of the furniture.", "Put everything against the wall.].sort(() => Math.random() - 0.5),
      correctAnswer: The flow of movement, room size, and purpose of the room."
    })
  },
  {
    id: "G4-HS-HF-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Furnishings",
    subtopic: "Care of Home Items,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Furniture and furnishings need regular care to maintain their appearance and longevity. How should wooden furniture be cared for?,
      options: [Dust regularly and polish with appropriate wood polish., Wash with soap and water., "Leave them in the sun., Scrub with steel wool."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust regularly and polish with appropriate wood polish.
    })
  },
  {
    id: G4-HS-HF-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Care of Home Items",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Cushions, curtains, and carpets add comfort and beauty to a home. How should fabric furnishings be maintained?,
      options: [Vacuum regularly and clean spills immediately., Ignore stains., Wash them with harsh chemicals.", "Shake them outside only.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly and clean spills immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G4-HS-HS-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who is injured or suddenly becomes ill. What is the first thing you should do in an emergency?,
      options: [Stay calm and assess the situation, then call for help if needed., Run away from the scene., "Panic and scream., Ignore the person."].sort(() => Math.random() - 0.5),
      correctAnswer: "Stay calm and assess the situation, then call for help if needed.
    })
  },
  {
    id: G4-HS-HS-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Accidents at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Accidents can happen at home, especially in the kitchen and bathroom. What is a common cause of accidents in the kitchen?,
      options: [Slippery floors, handling hot items, and using knives carelessly., Eating too much., Talking while eating.", "Using the microwave.].sort(() => Math.random() - 0.5),
      correctAnswer: Slippery floors, handling hot items, and using knives carelessly."
    })
  },
  {
    id: "G4-HS-HS-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Knowing basic first aid can save lives in emergency situations. What should you do if someone gets a burn?,
      options: [Run cool water over the burn for several minutes and cover with a clean cloth., Put butter on the burn., "Pop any blisters., Ignore it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool water over the burn for several minutes and cover with a clean cloth.
    })
  },

  // --- TIME AND MONEY MANAGEMENT (2 Materials) ---
  {
    id: G4-HS-TM-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Time and Money Management,
    subtopic: "Planning Daily Chores",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Planning daily chores helps you use your time efficiently and keeps the home running smoothly. What is the best way to manage daily chores?,
      options: [Make a schedule or checklist and allocate time for each task., Do everything at the last minute., Only do chores on weekends.", "Let others do everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Make a schedule or checklist and allocate time for each task."
    })
  },
  {
    id: "G4-HS-TM-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Time and Money Management",
    subtopic: "Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Budgeting helps a family manage its money and ensure that all needs are met. What is the first step in creating a family budget?,
      options: [List all income and track all expenses., Buy whatever you want., "Only buy food., Save all money without spending."].sort(() => Math.random() - 0.5),
      correctAnswer: "List all income and track all expenses.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL GROOMING (4 Materials) ---
  {
    id: G5-HS-PG-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Skin Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Skin care is important for maintaining healthy skin and preventing skin conditions. What is the most important daily practice for healthy skin?,
      options: [Washing your face and body with soap and water daily., Using makeup every day., Scrubbing your skin roughly.", "Never moisturizing.].sort(() => Math.random() - 0.5),
      correctAnswer: Washing your face and body with soap and water daily."
    })
  },
  {
    id: "G5-HS-PG-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Well-groomed nails are a sign of good hygiene and personal care. How should you properly care for your nails?,
      options: [Keep them clean, trimmed, and filed regularly., Paint them with dark polish., "Bite them to keep them short., Never cut them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keep them clean, trimmed, and filed regularly.
    })
  },
  {
    id: G5-HS-PG-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Healthy hair requires proper care to prevent breakage and keep it looking good. What should you do to prevent dandruff and keep your scalp healthy?,
      options: [Wash hair regularly and use a gentle shampoo., Use hot oil every day., Never wash your hair.", "Use harsh chemicals.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly and use a gentle shampoo."
    })
  },
  {
    id: "G5-HS-PG-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Overall Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Good grooming involves taking care of your entire appearance and hygiene. Which of the following is a key element of good personal grooming?,
      options: [Wearing clean clothes, having neat hair, and practicing good hygiene., Wearing expensive clothes., "Using a lot of perfume., Having the latest hairstyle."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wearing clean clothes, having neat hair, and practicing good hygiene.
    })
  },

  // --- HOME CLEANING (4 Materials) ---
  {
    id: G5-HS-HC-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Different cleaning agents are used for different surfaces and purposes. What cleaning agent is used for cleaning glass and windows?,
      options: [Glass cleaner or vinegar solution., Bleach, Abrasive powder", "Dish soap].sort(() => Math.random() - 0.5),
      correctAnswer: Glass cleaner or vinegar solution."
    })
  },
  {
    id: "G5-HS-HC-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Sweeping and Mopping,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sweeping and mopping are essential for keeping floors clean and hygienic. What is the correct order for cleaning a floor?,
      options: [Sweep first to remove dirt and debris, then mop., Mop first, then sweep., "Only mop without sweeping., Only sweep without mopping."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweep first to remove dirt and debris, then mop.
    })
  },
  {
    id: G5-HS-HC-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Bleach is a strong cleaning agent that kills germs and removes stains. What safety precaution should be taken when using bleach?,
      options: [Use it in a well-ventilated area and never mix with other cleaners., Mix it with vinegar for more power., Use it on all surfaces.", "Use it without gloves.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it in a well-ventilated area and never mix with other cleaners."
    })
  },
  {
    id: "G5-HS-HC-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Cleaning Different Surfaces,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Different surfaces require different cleaning methods to avoid damage. How should wooden surfaces be cleaned?,
      options: [Dust with a soft cloth and use appropriate wood polish., Use water and soap., "Scrub with a hard brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust with a soft cloth and use appropriate wood polish.
    })
  },

  // --- LAUNDRY WORK (4 Materials) ---
  {
    id: G5-HS-LW-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Sorting Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Sorting clothes before washing prevents color bleeding and ensures proper care for different fabrics. How should you sort clothes before washing?,
      options: [Separate whites from colors and sort by fabric type., Wash all clothes together., Only sort by size.", "Only sort by owner.].sort(() => Math.random() - 0.5),
      correctAnswer: Separate whites from colors and sort by fabric type."
    })
  },
  {
    id: "G5-HS-LW-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Hand Washing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hand washing is a gentle method of washing clothes that is suitable for delicate fabrics. What is the correct water temperature for hand washing delicate clothes?,
      options: [Cold or lukewarm water., Very hot water., "Boiling water., Water of any temperature."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cold or lukewarm water.
    })
  },
  {
    id: G5-HS-LW-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Machine Washing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Washing machines make laundry work easier but require proper use. How can you prevent clothes from getting damaged in a washing machine?,
      options: [Use the correct cycle and load size for different fabrics., Overload the machine to save time., Use the hottest setting for all clothes.", "Use a lot of detergent.].sort(() => Math.random() - 0.5),
      correctAnswer: Use the correct cycle and load size for different fabrics."
    })
  },
  {
    id: "G5-HS-LW-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Drying Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper drying of clothes prevents damage and keeps them looking fresh. What is the best way to dry clothes to prevent shrinkage and damage?,
      options: [Air dry on a clothesline away from direct harsh sunlight., Tumble dry on high heat., "Iron them wet., Leave them in a pile."].sort(() => Math.random() - 0.5),
      correctAnswer: "Air dry on a clothesline away from direct harsh sunlight.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G5-HS-NU-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutrients and Their Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proteins are essential nutrients that the body needs for growth and repair. Which of the following foods is a rich source of protein?,
      options: [Beans, eggs, meat, and fish., Rice and bread., Fruits and vegetables.", "Sugar and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, eggs, meat, and fish."
    })
  },
  {
    id: "G5-HS-NU-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vitamins and minerals are important micronutrients that support various body functions. Which vitamin is important for healthy eyesight and is found in carrots and orange fruits?,
      options: [Vitamin A, Vitamin B, "Vitamin C, Vitamin D"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamin A
    })
  },
  {
    id: G5-HS-NU-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A balanced meal should contain foods from different food groups to provide all essential nutrients. What should be included in a balanced meal?,
      options: [Carbohydrates, proteins, vegetables, and fruits., Only meat and rice., Only vegetables.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vegetables, and fruits."
    })
  },
  {
    id: "G5-HS-NU-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Carbohydrates provide energy for the body to function. Which of the following is a healthy source of complex carbohydrates?,
      options: [Brown rice, whole grain bread, and potatoes., White sugar and sweets., "Cakes and pastries., Fizzy drinks."].sort(() => Math.random() - 0.5),
      correctAnswer: "Brown rice, whole grain bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G5-HS-FP-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vegetables provide essential vitamins and minerals and should be prepared properly to preserve their nutrients. What is the best way to cook vegetables to preserve their nutrients?,
      options: [Steam or stir-fry them quickly with minimal water., Boil them for a long time., Deep fry them.", "Microwave them for 30 minutes.].sort(() => Math.random() - 0.5),
      correctAnswer: Steam or stir-fry them quickly with minimal water."
    })
  },
  {
    id: "G5-HS-FP-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Preparing Soups,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Soup is a nutritious and comforting meal that can be made with various ingredients. What are the basic ingredients for making a vegetable soup?,
      options: [Vegetables, water or stock, and seasoning., Meat and flour., "Rice and tomatoes., Beans and coconut milk."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vegetables, water or stock, and seasoning.
    })
  },
  {
    id: G5-HS-FP-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Stews",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stews are hearty meals made by slowly cooking meat or vegetables in liquid. Which of the following is an important step when making a stew?,
      options: [Brown the meat first to add flavor, then add liquid and simmer., Just add everything to cold water., Cook on high heat for 10 minutes.", "Add all ingredients at once.].sort(() => Math.random() - 0.5),
      correctAnswer: Brown the meat first to add flavor, then add liquid and simmer."
    })
  },
  {
    id: "G5-HS-FP-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Kitchen Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kitchen hygiene is essential to prevent food poisoning and cross-contamination. What is the best way to prevent cross-contamination in the kitchen?,
      options: [Use separate chopping boards for raw meat and other foods., Use the same board for everything., "Wash the board only at the end of the day., Never wash cutting boards."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate chopping boards for raw meat and other foods.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G5-HS-BEV-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Fresh Juices",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh fruit juices are healthy and refreshing beverages rich in vitamins. What is the correct way to prepare fresh fruit juice?,
      options: [Wash fruits, peel if necessary, blend, and strain if desired., Add sugar and leave it overnight., Boil the fruits first.", "Use dried fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash fruits, peel if necessary, blend, and strain if desired."
    })
  },
  {
    id: "G5-HS-BEV-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Fresh Juices,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Smoothies are thicker than juices and often include milk or yogurt. What is a key ingredient that makes smoothies thick and creamy?,
      options: [Banana or yogurt, Water, "Oil, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Banana or yogurt
    })
  },
  {
    id: G5-HS-BEV-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Beverage Preparation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh juices are best consumed immediately after preparation. Why is it important to drink fresh juice soon after making it?,
      options: [To get the full nutritional benefits before vitamins are lost., To keep it from spoiling., To save time.", "To reduce sugar content.].sort(() => Math.random() - 0.5),
      correctAnswer: To get the full nutritional benefits before vitamins are lost."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G5-HS-NW-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Running Stitch,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The running stitch is one of the most basic and versatile hand stitches. What is the running stitch commonly used for?,
      options: [Basting, gathering fabric, and simple seams., Buttonholes., "Zipper insertion., Stitching leather."].sort(() => Math.random() - 0.5),
      correctAnswer: "Basting, gathering fabric, and simple seams.
    })
  },
  {
    id: G5-HS-NW-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Stitches - Backstitch",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The backstitch creates a strong and secure seam. How does the backstitch compare to the running stitch?,
      options: [The backstitch is stronger because each stitch overlaps the previous one., The backstitch is weaker., They are exactly the same.", "The backstitch is faster.].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch is stronger because each stitch overlaps the previous one."
    })
  },
  {
    id: "G5-HS-NW-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Hemming,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hemming is a finishing technique used to create a neat edge on garments and other fabric items. What is the purpose of hemming?,
      options: [To prevent the fabric from fraying and create a finished look., To make the garment longer., "To add decoration only., To make the garment tighter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and create a finished look.
    })
  },

  // --- HOME MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-HM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Windows",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clean windows allow natural light to enter and improve the appearance of a home. How should glass windows be cleaned to avoid streaks?,
      options: [Use a glass cleaner and a squeegee or microfiber cloth., Use soap and water with a sponge., Scrub with an abrasive pad.", "Use newspaper alone.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a glass cleaner and a squeegee or microfiber cloth."
    })
  },
  {
    id: "G5-HS-HM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Polishing Furniture,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Polishing wood furniture restores its shine and protects it from damage. What is the proper way to apply polish to wooden furniture?,
      options: [Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine., Pour polish directly on the furniture., "Use water instead of polish., Use a rough cloth to apply it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine.
    })
  },
  {
    id: G5-HS-HM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Maintaining Home Equipment",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Regular maintenance of home equipment extends their lifespan and ensures safety. Why is it important to regularly clean and service electrical appliances?,
      options: [To prevent accidents, save energy, and ensure they work efficiently., To keep them looking new., To avoid buying new ones.", "To reduce the electricity bill only.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent accidents, save energy, and ensure they work efficiently."
    })
  },

  // --- SAFETY IN THE HOME (3 Materials) ---
  {
    id: "G5-HS-SH-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Fire can be dangerous and cause serious injuries and property damage. What should you do if there is a small fire in the kitchen?,
      options: [Use a fire extinguisher or cover the fire with a lid to smother it., Pour water on a grease fire., "Run away and call for help., Blow on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a fire extinguisher or cover the fire with a lid to smother it.
    })
  },
  {
    id: G5-HS-SH-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Safety in the Home,
    subtopic: "Poison Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Many household products can be poisonous if ingested or misused. What is the best way to prevent poisoning in the home?,
      options: [Store cleaning products and medicines out of reach of children and in original containers., Keep them under the sink., Transfer them to unlabeled bottles.", "Leave them on the counter.].sort(() => Math.random() - 0.5),
      correctAnswer: Store cleaning products and medicines out of reach of children and in original containers."
    })
  },
  {
    id: "G5-HS-SH-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Prevention is better than cure when it comes to fire safety. Which of the following is a fire safety measure in the home?,
      options: [Have a working smoke detector and a fire escape plan., Leave candles burning when you leave the house., "Overload electrical sockets., Keep flammable materials near the stove."].sort(() => Math.random() - 0.5),
      correctAnswer: "Have a working smoke detector and a fire escape plan.
    })
  },

  // --- RESOURCE MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-RM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Using Resources Wisely",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Using resources wisely helps save money and protect the environment. What is one way to conserve water in the home?,
      options: [Repair leaking taps and use water sparingly., Leave taps running., Fill the bathtub completely.", "Use a hose to water the garden every day.].sort(() => Math.random() - 0.5),
      correctAnswer: Repair leaking taps and use water sparingly."
    })
  },
  {
    id: "G5-HS-RM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Resource Management",
    subtopic: "Using Resources Wisely,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Energy conservation reduces household bills and helps the environment. Which of the following is a way to save electricity at home?,
      options: [Turn off lights and appliances when not in use., Leave lights on all day., "Use old, inefficient appliances., Keep the refrigerator door open."].sort(() => Math.random() - 0.5),
      correctAnswer: "Turn off lights and appliances when not in use.
    })
  },
  {
    id: G5-HS-RM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Saving Money",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Saving money is an important habit that helps families prepare for emergencies and future needs. What is a simple way to start saving money at home?,
      options: [Set aside a small amount regularly in a savings box or bank account., Spend all money as soon as you get it., Borrow money for unnecessary items.", "Keep all money in a wallet.].sort(() => Math.random() - 0.5),
      correctAnswer: Set aside a small amount regularly in a savings box or bank account."
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HEALTH AND HYGIENE (5 Materials) ---
  {
    id: "G6-HS-PH-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Body Odor,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Body odor is caused by bacteria breaking down sweat on the skin. What is the most effective way to prevent body odor?,
      options: [Bathing daily with soap and using an antiperspirant or deodorant., Using perfume only., "Wearing the same clothes for days., Avoiding physical activity."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and using an antiperspirant or deodorant.
    })
  },
  {
    id: G6-HS-PH-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Dental Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Good dental hygiene prevents cavities, gum disease, and bad breath. What is the recommended technique for effective teeth brushing?,
      options: [Brush in circular motions for at least two minutes, covering all tooth surfaces., Brush back and forth quickly., Brush only the front teeth.", "Brush once a day.].sort(() => Math.random() - 0.5),
      correctAnswer: Brush in circular motions for at least two minutes, covering all tooth surfaces."
    })
  },
  {
    id: "G6-HS-PH-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Dental Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Flossing is an important part of dental hygiene that complements brushing. Why is flossing important for dental health?,
      options: [It removes plaque and food particles from between teeth where brushes cannot reach., It whitens teeth., "It replaces brushing., It strengthens tooth enamel."].sort(() => Math.random() - 0.5),
      correctAnswer: "It removes plaque and food particles from between teeth where brushes cannot reach.
    })
  },
  {
    id: G6-HS-PH-04",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper grooming involves maintaining a neat and clean appearance. Which of the following is an important aspect of personal grooming for adolescents?,
      options: [Regular bathing, hair care, nail care, and wearing clean clothes., Using expensive cosmetics., Following fashion trends blindly.", "Wearing heavy makeup.].sort(() => Math.random() - 0.5),
      correctAnswer: Regular bathing, hair care, nail care, and wearing clean clothes."
    })
  },
  {
    id: "G6-HS-PH-05",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Hygiene During Adolescence,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Adolescence brings physical changes that require extra attention to hygiene. What additional hygiene practices are important during adolescence?,
      options: [Washing face twice daily, using deodorant, and changing undergarments regularly., Bathing once a week., "Ignoring skin changes., Using adult products without guidance."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing face twice daily, using deodorant, and changing undergarments regularly.
    })
  },

  // --- HOME SANITATION (4 Materials) ---
  {
    id: G6-HS-HS-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Waste Disposal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper waste disposal is crucial for maintaining a healthy home environment. What is the recommended way to dispose of organic kitchen waste?,
      options: [Use it to make compost for gardening., Mix it with plastic waste., Burn it in the compound.", "Throw it in the toilet.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it to make compost for gardening."
    })
  },
  {
    id: "G6-HS-HS-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Improper waste disposal can lead to environmental pollution and health problems. What is the proper way to dispose of plastic and non-biodegradable waste?,
      options: [Separate for recycling or dispose of in designated bins., Burn it., "Bury it in the garden., Throw it in the river."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate for recycling or dispose of in designated bins.
    })
  },
  {
    id: G6-HS-HS-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pests like cockroaches, rats, and mosquitoes can spread diseases in the home. What is an effective way to control pests?,
      options: [Keep the home clean, seal food containers, and use appropriate pest control methods., Use insecticides without cleaning., Ignore them.", "Leave food uncovered.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the home clean, seal food containers, and use appropriate pest control methods."
    })
  },
  {
    id: "G6-HS-HS-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Pest Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mosquitoes are common pests that transmit diseases like malaria and dengue fever. How can you prevent mosquito breeding in and around the home?,
      options: [Eliminate standing water and use mosquito nets or repellents., Leave water containers open., "Use strong perfumes., Ignore puddles."].sort(() => Math.random() - 0.5),
      correctAnswer: "Eliminate standing water and use mosquito nets or repellents.
    })
  },

  // --- CLOTHING CARE (4 Materials) ---
  {
    id: G6-HS-CC-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Stain Removal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stains on clothes can be difficult to remove if not treated properly. What is the first step in removing a fresh stain from clothing?,
      options: [Treat it immediately by blotting and applying appropriate stain remover., Wait until it dries., Rub it with soap.", "Ignore it.].sort(() => Math.random() - 0.5),
      correctAnswer: Treat it immediately by blotting and applying appropriate stain remover."
    })
  },
  {
    id: "G6-HS-CC-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Stain Removal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Different stains require different treatment methods. How should you treat a grease or oil stain on a garment?,
      options: [Apply a small amount of dish soap or stain remover and wash in warm water., Use hot water immediately., "Rub with a cloth., Apply bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply a small amount of dish soap or stain remover and wash in warm water.
    })
  },
  {
    id: G6-HS-CC-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Mending Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Mending clothes extends their lifespan and saves money. What is the best way to mend a small tear in a garment?,
      options: [Use a needle and thread to stitch it neatly, matching the fabric., Use glue or tape., Ignore the tear.", "Cut the garment.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a needle and thread to stitch it neatly, matching the fabric."
    })
  },
  {
    id: "G6-HS-CC-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Pressing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pressing clothes properly gives them a neat, crisp appearance. What temperature setting should you use when ironing synthetic fabrics?,
      options: [A low to medium temperature setting to prevent melting or scorching., The highest setting.", "No heat., Steam only."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low to medium temperature setting to prevent melting or scorching.
    })
  },

  // --- ADVANCED NUTRITION (4 Materials) ---
  {
    id: G6-HS-AN-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Meal Planning for Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meal planning for a family should consider the nutritional needs of all members. What factors should be considered when planning meals for a family with members of different ages?,
      options: [Nutritional requirements of different age groups, preferences, and budget., Only the preference of adults., Only the cost.", "Only one type of food.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional requirements of different age groups, preferences, and budget."
    })
  },
  {
    id: "G6-HS-AN-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Meal Planning for Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Special diets may be needed for people with certain health conditions. What is an example of a special diet that may be recommended by a doctor?,
      options: [A low-sodium diet for high blood pressure., A high-sugar diet., "A food-free diet., A non-vegetarian diet."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low-sodium diet for high blood pressure.
    })
  },
  {
    id: G6-HS-AN-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Nutritional Needs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Children in their growth years require extra nutrients for proper development. Which nutrients are particularly important for growing children?,
      options: [Calcium, iron, and protein for bone growth and muscle development., Only fat., Only sugar.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Calcium, iron, and protein for bone growth and muscle development."
    })
  },
  {
    id: "G6-HS-AN-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Nutritional Needs,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pregnant and breastfeeding mothers have increased nutritional requirements. Which nutrients are especially important during pregnancy?,
      options: [Folic acid, iron, calcium, and protein., Only carbohydrates., "Only fats., Only sugar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Folic acid, iron, calcium, and protein.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G6-HS-FP-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Boiling",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Boiling is a common cooking method that uses water or liquid to cook food. What is a disadvantage of boiling vegetables for too long?,
      options: [It can destroy heat-sensitive vitamins like Vitamin C., It makes them too hard., It makes them too sweet.", "It adds too much oil.].sort(() => Math.random() - 0.5),
      correctAnswer: It can destroy heat-sensitive vitamins like Vitamin C."
    })
  },
  {
    id: "G6-HS-FP-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods - Frying,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Frying involves cooking food in hot oil or fat. What is a health concern associated with deep frying foods?,
      options: [The food absorbs a lot of fat, increasing calorie content., It makes food dry., "It removes all nutrients., It takes too long."].sort(() => Math.random() - 0.5),
      correctAnswer: "The food absorbs a lot of fat, increasing calorie content.
    })
  },
  {
    id: G6-HS-FP-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Roasting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Roasting is a dry-heat cooking method that is often used for meat and vegetables. What is a benefit of roasting food?,
      options: [It enhances the natural flavor without adding extra fat., It preserves all nutrients., It is the fastest method.", "It requires no preparation.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances the natural flavor without adding extra fat."
    })
  },
  {
    id: "G6-HS-FP-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Food safety involves proper handling, cooking, and storage of food to prevent foodborne illness. What is the recommended internal temperature for cooking poultry to ensure it is safe to eat?,
      options: ["74°C (165°F), 50°C", "100°C, 25°C"].sort(() => Math.random() - 0.5),
      correctAnswer: "74°C (165°F)
    })
  },

  // --- KITCHEN MANAGEMENT (3 Materials) ---
  {
    id: G6-HS-KM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Organizing the Kitchen",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " An organized kitchen makes cooking easier and more efficient. What is the principle of organizing kitchen items based on frequency of use?,
      options: [Store frequently used items at eye level and within easy reach., Store everything randomly., Keep all items in cupboards.", "Store items on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Store frequently used items at eye level and within easy reach."
    })
  },
  {
    id: "G6-HS-KM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Kitchen Management",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper food storage prevents spoilage and reduces waste. How should perishable foods like meat and dairy be stored?,
      options: [In the refrigerator at temperatures below 5°C (41°F)., On the kitchen counter., "In a cupboard., In direct sunlight."].sort(() => Math.random() - 0.5),
      correctAnswer: "In the refrigerator at temperatures below 5°C (41°F).
    })
  },
  {
    id: G6-HS-KM-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Food Storage",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Dry goods like grains, cereals, and legumes should be stored properly to prevent infestation. What is the best way to store dry goods?,
      options: [Store in airtight containers in a cool, dry place., Store in paper bags., Store in the refrigerator.", "Store in sunlight.].sort(() => Math.random() - 0.5),
      correctAnswer: Store in airtight containers in a cool, dry place."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G6-HS-NW-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Decorative stitches can add beauty and personal touch to garments and crafts. Which of the following is a decorative stitch used in embroidery?,
      options: [The chain stitch, The running stitch, "The tacking stitch, The stay stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The chain stitch
    })
  },
  {
    id: G6-HS-NW-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Repairing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Repairing clothes saves money and reduces waste. What stitch would you use to repair a seam that has come undone?,
      options: [The backstitch, The running stitch, The blanket stitch", "The chain stitch].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch"
    })
  },
  {
    id: "G6-HS-NW-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The blanket stitch is a decorative and functional stitch used for edges. Where is the blanket stitch commonly used?,
      options: [On blankets, tablecloths, and fabric edges to prevent fraying., For sewing buttons., "For hemming curtains., For attaching zippers."].sort(() => Math.random() - 0.5),
      correctAnswer: "On blankets, tablecloths, and fabric edges to prevent fraying.
    })
  },

  // --- HOME DECORATION (3 Materials) ---
  {
    id: G6-HS-HD-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Arranging Rooms",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper room arrangement creates a comfortable and functional living space. What principle should guide the arrangement of furniture in a living room?,
      options: [Create conversation areas and maintain easy traffic flow., Push all furniture against the walls., Fill every space with furniture.", "Place furniture randomly.].sort(() => Math.random() - 0.5),
      correctAnswer: Create conversation areas and maintain easy traffic flow."
    })
  },
  {
    id: "G6-HS-HD-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Decoration",
    subtopic: "Color Coordination,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Color coordination creates harmony and mood in a room. What colors create a calm and relaxing atmosphere?,
      options: [Cool colors like blue, green, and soft neutrals., Bright red and orange., "Neon colors., Dark brown and black."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cool colors like blue, green, and soft neutrals.
    })
  },
  {
    id: G6-HS-HD-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Color Coordination",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Warm colors like red, orange, and yellow create a lively and energetic atmosphere. In which room would warm colors be most appropriate?,
      options: [In the living room or dining room to create a welcoming feel., In the bedroom to promote rest., In the study to aid concentration.", "In the bathroom.].sort(() => Math.random() - 0.5),
      correctAnswer: In the living room or dining room to create a welcoming feel."
    })
  },

  // --- FIRST AID (3 Materials) ---
  {
    id: "G6-HS-FA-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Cuts,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Cuts and wounds can become infected if not treated properly. What is the correct procedure for treating a minor cut?,
      options: [Clean with soap and water, apply an antiseptic, and cover with a clean bandage., Ignore it., "Apply butter., Rub with dirt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean with soap and water, apply an antiseptic, and cover with a clean bandage.
    })
  },
  {
    id: G6-HS-FA-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "First Aid,
    subtopic: "Treating Burns",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Burns can be painful and cause serious damage to the skin. What should you do immediately after a minor burn?,
      options: [Place the burn under cool running water for several minutes., Apply ice directly to the burn., Apply oil or butter.", "Pop any blisters.].sort(() => Math.random() - 0.5),
      correctAnswer: Place the burn under cool running water for several minutes."
    })
  },
  {
    id: "G6-HS-FA-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Minor Injuries,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sprains and strains are common injuries that can occur at home or during physical activity. What is the RICE method for treating sprains?,
      options: [Rest, Ice, Compression, Elevation, Run, Ice, Compression, Exercise, "Rest, Ice, Cool, Exercise, Raise, Ice, Compress, Elevate"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rest, Ice, Compression, Elevation
    })
  },

  // --- FINANCIAL MANAGEMENT (2 Materials) ---
  {
    id: G6-HS-FM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Financial Management,
    subtopic: "Saving",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Saving money is an important financial habit that helps achieve goals and provides security. What is the recommended percentage of income to save?,
      options: [At least 10-20% of income should be saved regularly., Save all income., Save nothing.", "Save only when there is extra.].sort(() => Math.random() - 0.5),
      correctAnswer: At least 10-20% of income should be saved regularly."
    })
  },
  {
    id: "G6-HS-FM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Financial Management",
    subtopic: "Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Entrepreneurship involves creating a business to generate income. What is a simple home-based business idea that a family could start?,
      options: [Baking and selling cakes, catering services, or making crafts., Buying expensive cars., "Investing in stocks without research., Borrowing money without a plan."].sort(() => Math.random() - 0.5),
      correctAnswer: "Baking and selling cakes, catering services, or making crafts.
    })
  },

  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL DEVELOPMENT (4 Materials) ---
  {
    id: G7-HS-PD-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Personal grooming reflects self-respect and creates a positive impression. What is the importance of proper grooming in daily life?,
      options: [It enhances self-confidence and shows respect for oneself and others., It is only for formal occasions., It is unnecessary.", "It takes too much time.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances self-confidence and shows respect for oneself and others."
    })
  },
  {
    id: "G7-HS-PD-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Posture,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Good posture is important for health and appearance. What are the benefits of maintaining good posture?,
      options: [Prevents back pain, improves breathing, and creates a confident appearance., Causes back pain., "Has no effect., Is only important for athletes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Prevents back pain, improves breathing, and creates a confident appearance.
    })
  },
  {
    id: G7-HS-PD-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Personal hygiene is essential for maintaining health and preventing disease. Why is it important to wash hands frequently?,
      options: [To prevent the spread of germs and reduce the risk of infectious diseases., To keep hands soft., To avoid using gloves.", "To save water.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent the spread of germs and reduce the risk of infectious diseases."
    })
  },
  {
    id: "G7-HS-PD-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Choosing appropriate clothing for different occasions is part of good grooming. What should you consider when selecting clothes for different occasions?,
      options: [Dress code, weather, comfort, and cultural appropriateness., Only the latest fashion., "Only bright colors., Only expensive brands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dress code, weather, comfort, and cultural appropriateness.
    })
  },

  // --- HOME CARE (4 Materials) ---
  {
    id: G7-HS-HC-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Cleaning Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different cleaning methods are suitable for different surfaces and materials. What cleaning method is appropriate for cleaning tile floors?,
      options: [Mop with warm water and a suitable floor cleaner., Scrub with a wire brush., Use dry sweeping only.", "Use bleach without water.].sort(() => Math.random() - 0.5),
      correctAnswer: Mop with warm water and a suitable floor cleaner."
    })
  },
  {
    id: "G7-HS-HC-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Carpets and rugs require special care to maintain their appearance and hygiene. How should carpets be cleaned regularly?,
      options: [Vacuum regularly and have them professionally cleaned periodically., Wash with a hose., "Scrub with a brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vacuum regularly and have them professionally cleaned periodically.
    })
  },
  {
    id: G7-HS-HC-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Disinfectants",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Disinfectants are chemicals used to kill germs and bacteria on surfaces. What is the difference between a cleaner and a disinfectant?,
      options: [Cleaners remove dirt, while disinfectants kill germs and bacteria., They are the same thing., Cleaners are stronger.", "Disinfectants are not safe to use.].sort(() => Math.random() - 0.5),
      correctAnswer: Cleaners remove dirt, while disinfectants kill germs and bacteria."
    })
  },
  {
    id: "G7-HS-HC-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Natural cleaning agents like vinegar, lemon, and baking soda are effective and eco-friendly. What can vinegar be used for in household cleaning?,
      options: ["Removing limescale, glass cleaning, and deodorizing., Polishing wood.", "Cleaning carpets., Washing clothes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Removing limescale, glass cleaning, and deodorizing.
    })
  },

  // --- LAUNDRY AND TEXTILE CARE (4 Materials) ---
  {
    id: G7-HS-LT-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Fabric Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Different fabrics require different care methods. Which of the following is a natural fiber commonly used in clothing?,
      options: [Cotton, Polyester, Nylon", "Spandex].sort(() => Math.random() - 0.5),
      correctAnswer: Cotton"
    })
  },
  {
    id: "G7-HS-LT-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Fabric Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Synthetic fabrics like polyester and nylon are made from petroleum-based materials. What is an advantage of synthetic fabrics over natural fibers?,
      options: [They are often more durable and wrinkle-resistant., They breathe better., "They are more absorbent., They are all biodegradable."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are often more durable and wrinkle-resistant.
    })
  },
  {
    id: G7-HS-LT-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Laundry Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different laundry agents are used for different purposes in washing. What is the function of fabric softener in laundry?,
      options: [Softens fabrics and reduces static electricity., Removes stains., Whitens clothes.", "Kills germs.].sort(() => Math.random() - 0.5),
      correctAnswer: Softens fabrics and reduces static electricity."
    })
  },
  {
    id: "G7-HS-LT-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Laundry Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bleach is a strong chemical agent used in laundry for whitening and disinfecting. What is the proper way to use bleach?,
      options: [Dilute as directed and use only on white fabrics, avoiding colored clothes., Use on all fabrics., "Pour directly on clothes., Mix with vinegar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dilute as directed and use only on white fabrics, avoiding colored clothes.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G7-HS-FN-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Macronutrients are nutrients required in large amounts by the body. Which of the following are the three main macronutrients?,
      options: [Carbohydrates, proteins, and fats., Vitamins, minerals, and water., Carbohydrates, vitamins, and minerals.", "Proteins, minerals, and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, and fats."
    })
  },
  {
    id: "G7-HS-FN-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Micronutrients are essential nutrients required in small amounts. What is the difference between vitamins and minerals?,
      options: [Vitamins are organic compounds, while minerals are inorganic elements., Vitamins are inorganic, minerals are organic., "They are the same., Vitamins are only found in meat."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins are organic compounds, while minerals are inorganic elements.
    })
  },
  {
    id: G7-HS-FN-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proteins are essential for building and repairing body tissues. What is a complete protein source that contains all essential amino acids?,
      options: [Animal products like meat, eggs, and dairy., Beans and lentils., Grains.", "Vegetables.].sort(() => Math.random() - 0.5),
      correctAnswer: Animal products like meat, eggs, and dairy."
    })
  },
  {
    id: "G7-HS-FN-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Iron is an important mineral that plays a key role in oxygen transport in the blood. What is a common sign of iron deficiency?,
      options: [Fatigue, weakness, and pale skin., High energy levels., "Weight gain., Good eyesight."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fatigue, weakness, and pale skin.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G7-HS-FP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Meat",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meat must be cooked thoroughly to kill harmful bacteria and ensure safety. What is the recommended cooking method for tough cuts of meat?,
      options: [Slow cooking with moisture, like stewing or braising., Quick frying., Grilling for a short time.", "Microwaving.].sort(() => Math.random() - 0.5),
      correctAnswer: Slow cooking with moisture, like stewing or braising."
    })
  },
  {
    id: "G7-HS-FP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Fish,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fish is a nutritious food that is quick and easy to cook. What cooking method preserves the delicate texture of fish?,
      options: [Steaming or grilling gently., Deep frying., "Boiling for hours., Pressure cooking."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or grilling gently.
    })
  },
  {
    id: G7-HS-FP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Poultry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Chicken is a commonly consumed poultry meat that requires proper handling and cooking. What is the safe internal temperature for cooked chicken?,
      options: [74°C (165°F), 60°C, 80°C", "50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 74°C (165°F)"
    })
  },
  {
    id: "G7-HS-FP-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Cross-contamination is a major cause of foodborne illness. How can cross-contamination be prevented in the kitchen?,
      options: [Use separate cutting boards and utensils for raw meat and ready-to-eat foods., Use the same board for everything., "Wash hands only after cooking., Store raw meat above cooked food."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate cutting boards and utensils for raw meat and ready-to-eat foods.
    })
  },

  // --- BEVERAGE PREPARATION (3 Materials) ---
  {
    id: G7-HS-BP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Traditional drinks are an important part of Kenyan culture. What is a traditional Kenyan drink made from fermented dairy?,
      options: [Maziwa lala (fermented milk), Coffee, Tea", "Juice].sort(() => Math.random() - 0.5),
      correctAnswer: Maziwa lala (fermented milk)"
    })
  },
  {
    id: "G7-HS-BP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Beverage Preparation",
    subtopic: "Modern Drinks,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Smoothies are popular modern drinks that can be made with various fruits and liquids. What is a healthy ingredient that can be added to smoothies for extra nutrition?,
      options: [Oats, chia seeds, or spirulina., Sugar., "Ice cream., Soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Oats, chia seeds, or spirulina.
    })
  },
  {
    id: G7-HS-BP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fruit and vegetable juices can be combined to create nutritious beverages. Which combination of fruits and vegetables creates a nutrient-rich juice?,
      options: [Carrot, ginger, and orange., Soda and syrup., Coffee and cream.", "Tea and sugar.].sort(() => Math.random() - 0.5),
      correctAnswer: Carrot, ginger, and orange."
    })
  },

  // --- SEWING TECHNIQUES (3 Materials) ---
  {
    id: "G7-HS-ST-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Darts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Darts are used in garment construction to shape fabric to the body. Where are darts commonly placed in garments?,
      options: [At the bust, waist, and shoulder to create shape and fit., On the hem., "At the collar., On the cuffs."].sort(() => Math.random() - 0.5),
      correctAnswer: "At the bust, waist, and shoulder to create shape and fit.
    })
  },
  {
    id: G7-HS-ST-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Sewing Techniques,
    subtopic: "Gathers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Gathers are used to create fullness in garments and add decorative detail. What is the technique used to create gathers in fabric?,
      options: [Use a long running stitch and pull the thread to gather the fabric., Use a backstitch., Use a buttonhole stitch.", "Use a zigzag stitch.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a long running stitch and pull the thread to gather the fabric."
    })
  },
  {
    id: "G7-HS-ST-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Seams,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Seams are the lines of stitching that join pieces of fabric together. What is the purpose of finishing a seam?,
      options: [To prevent the fabric from fraying and give a professional finish., To make the seam stronger., "To add color., To make the garment heavier."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and give a professional finish.
    })
  },

  // --- HOME ENVIRONMENT (3 Materials) ---
  {
    id: G7-HS-HE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Ventilation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Good ventilation is important for maintaining a healthy indoor environment. Why is proper ventilation important in the home?,
      options: [To remove stale air, control humidity, and reduce the spread of airborne diseases., To keep the house cold., To save energy.", "To block outside air.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove stale air, control humidity, and reduce the spread of airborne diseases."
    })
  },
  {
    id: "G7-HS-HE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Environment",
    subtopic: "Lighting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper lighting in the home is important for safety and comfort. What are the three types of lighting used in interior design?,
      options: [Ambient, task, and accent lighting., Natural, artificial, and candle., "Indoor, outdoor, and emergency., Direct, indirect, and reflected."].sort(() => Math.random() - 0.5),
      correctAnswer: "Ambient, task, and accent lighting.
    })
  },
  {
    id: G7-HS-HE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Furniture Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Regular furniture care extends its lifespan and maintains its appearance. What is the correct way to care for upholstered furniture?,
      options: [Vacuum regularly, rotate cushions, and treat stains immediately., Use water on all fabrics., Scrub harshly.", "Ignore spills.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly, rotate cushions, and treat stains immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G7-HS-HS-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kitchen safety is essential to prevent accidents and injuries. What safety measure should be taken when using sharp knives?,
      options: [Cut away from the body and keep knives sharp for better control., Use dull knives., "Cut toward the body., Leave knives in the sink."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cut away from the body and keep knives sharp for better control.
    })
  },
  {
    id: G7-HS-HS-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Food Poisoning Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Food poisoning is caused by consuming contaminated food. What is the recommended temperature range for refrigerating perishable foods?,
      options: [0-5°C (32-41°F), 10-20°C, 25-30°C", "40-50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 0-5°C (32-41°F)"
    })
  },
  {
    id: "G7-HS-HS-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Accidents in the kitchen can be caused by burns from hot liquids and surfaces. What should you do if you spill hot liquid on yourself?,
      options: [Quickly remove the clothing from the area and run cool water over the burn., Ignore it., "Apply heat., Put butter on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Quickly remove the clothing from the area and run cool water over the burn.
    })
  },

  // --- CONSUMER EDUCATION (3 Materials) ---
  {
    id: G7-HS-CE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Wise Buying",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Wise buying involves making informed purchasing decisions. What should a consumer check when comparing products before buying?,
      options: [Quality, price, quantity, and expiry date., Only the price., Only the brand.", "Only the color.].sort(() => Math.random() - 0.5),
      correctAnswer: Quality, price, quantity, and expiry date."
    })
  },
  {
    id: "G7-HS-CE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Consumer Education",
    subtopic: "Wise Buying,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Understanding food labels helps consumers make informed choices about the food they buy. What information is required on a food label?,
      options: [List of ingredients, expiry date, and nutritional information., Only the price., "Only the brand name., Only the weight."].sort(() => Math.random() - 0.5),
      correctAnswer: "List of ingredients, expiry date, and nutritional information.
    })
  },
  {
    id: G7-HS-CE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Advertising",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Advertising influences consumer choices and can sometimes be misleading. What should a savvy consumer do when evaluating advertisements?,
      options: [Compare information from different sources and avoid impulse buying., Believe every advertisement., Buy immediately.", "Ignore all advertising.].sort(() => Math.random() - 0.5),
      correctAnswer: Compare information from different sources and avoid impulse buying."
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G8-HS-PH-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The skin is the body's largest organ and requires proper care to stay healthy. What is the recommended daily routine for maintaining healthy skin?,
      options: [Cleanse, tone, and moisturize using products suitable for your skin type., Wash with soap only., "Apply makeup daily., Never use sunscreen."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleanse, tone, and moisturize using products suitable for your skin type.
    })
  },
  {
    id: G8-HS-PH-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different hair types require different care methods to maintain health and appearance. How should you care for natural African hair to prevent breakage?,
      options: [Keep it moisturized, avoid harsh chemicals, and use protective styles., Wash with harsh shampoo daily., Use a lot of heat.", "Comb when dry.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep it moisturized, avoid harsh chemicals, and use protective styles."
    })
  },
  {
    id: "G8-HS-PH-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Proper nail care prevents infections and keeps nails looking neat. What tool should be used to gently push back cuticles?,
      options: [A cuticle pusher or orange stick., A knife., "A pair of scissors., Your teeth."].sort(() => Math.random() - 0.5),
      correctAnswer: "A cuticle pusher or orange stick.
    })
  },
  {
    id: G8-HS-PH-04",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Foot Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Feet carry the weight of the body and require special care to prevent problems. What is the best practice for maintaining healthy feet?,
      options: [Wash feet daily, dry thoroughly between toes, and wear comfortable shoes., Wear tight shoes., Ignore foot odor.", "Never wash feet.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash feet daily, dry thoroughly between toes, and wear comfortable shoes."
    })
  },
  {
    id: "G8-HS-PH-05",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Acne is a common skin condition that affects many adolescents. What is an effective way to manage acne?,
      options: [Wash face gently twice daily with a mild cleanser and use appropriate acne treatments., Pop pimples., "Use harsh scrubs., Never wash the face."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash face gently twice daily with a mild cleanser and use appropriate acne treatments.
    })
  },

  // --- HOUSEHOLD HYGIENE (4 Materials) ---
  {
    id: G8-HS-HH-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Household Hygiene,
    subtopic: "Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Different cleaning agents have specific uses and safety requirements. What is the appropriate cleaning agent for removing soap scum in the bathroom?,
      options: [A bathroom cleaner with mild acid or vinegar solution., Bleach., Dish soap.", "Furniture polish.].sort(() => Math.random() - 0.5),
      correctAnswer: A bathroom cleaner with mild acid or vinegar solution."
    })
  },
  {
    id: "G8-HS-HH-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Household Hygiene",
    subtopic: "Cleaning Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sanitization reduces the number of germs on surfaces to a safe level. What is the difference between cleaning, sanitizing, and disinfecting?,
      options: ["Cleaning removes dirt, sanitizing reduces germs, and disinfecting kills germs., They are all the same.", "Disinfecting is the only important one., Sanitizing is for floors only."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning removes dirt, sanitizing reduces germs, and disinfecting kills germs.
    })
  },
  {
    id: G8-HS-HH-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Household Hygiene,
    subtopic: "Sanitation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Good sanitation practices in the home prevent the spread of diseases. Which area of the home is most critical to keep sanitary?,
      options: [The kitchen and bathroom where germs are most likely to spread., The bedroom., The living room.", "The garage.].sort(() => Math.random() - 0.5),
      correctAnswer: The kitchen and bathroom where germs are most likely to spread."
    })
  },
  {
    id: "G8-HS-HH-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Household Hygiene",
    subtopic: "Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ventilation helps remove indoor air pollutants and moisture that can lead to mold growth. Why is proper ventilation important in the bathroom?,
      options: [To reduce humidity and prevent mold and mildew growth., To make it colder., "To save water., To allow insects to enter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To reduce humidity and prevent mold and mildew growth.
    })
  },

  // --- CLOTHING CONSTRUCTION (4 Materials) ---
  {
    id: G8-HS-CC-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Clothing Construction,
    subtopic: "Pattern Drafting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pattern drafting is the process of creating a blueprint for a garment. What is the first step in pattern drafting?,
      options: [Taking accurate body measurements., Cutting fabric., Drawing the design.", "Sewing the seams.].sort(() => Math.random() - 0.5),
      correctAnswer: Taking accurate body measurements."
    })
  },
  {
    id: "G8-HS-CC-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Clothing Construction",
    subtopic: "Cutting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper cutting ensures that the fabric pieces fit together correctly. What should you do before cutting fabric with a pattern?,
      options: [Press the fabric and the pattern, and pin the pattern securely., Cut immediately., "Fold the fabric randomly., Use dull scissors."].sort(() => Math.random() - 0.5),
      correctAnswer: "Press the fabric and the pattern, and pin the pattern securely.
    })
  },
  {
    id: G8-HS-CC-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Clothing Construction,
    subtopic: "Sewing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sewing machine stitches come in various types for different purposes. What type of stitch is used for seam construction on a sewing machine?,
      options: [A straight stitch or a lockstitch., A zigzag stitch., A buttonhole stitch.", "A stretch stitch.].sort(() => Math.random() - 0.5),
      correctAnswer: A straight stitch or a lockstitch."
    })
  },
  {
    id: "G8-HS-CC-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Clothing Construction",
    subtopic: "Sewing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Seam finishing prevents fraying and gives garments a professional look. Which seam finish is suitable for lightweight fabrics?,
      options: [A French seam or overlock stitch., A flat-felled seam., "A bound seam., A hand-stitched seam."].sort(() => Math.random() - 0.5),
      correctAnswer: "A French seam or overlock stitch.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G8-HS-NU-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutritional Deficiencies",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Nutritional deficiencies occur when the body does not get enough of certain nutrients. What condition is caused by a deficiency of Vitamin C?,
      options: [Scurvy, Rickets, Anemia", "Osteoporosis].sort(() => Math.random() - 0.5),
      correctAnswer: Scurvy"
    })
  },
  {
    id: "G8-HS-NU-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutritional Deficiencies,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Iron deficiency is a common nutritional problem worldwide. What are the symptoms of iron deficiency anemia?,
      options: [Fatigue, pale skin, shortness of breath, and dizziness., Excessive energy., "Weight loss., Good eyesight."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fatigue, pale skin, shortness of breath, and dizziness.
    })
  },
  {
    id: G8-HS-NU-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Balanced Meals",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A balanced meal should provide a variety of nutrients to support overall health. What is the recommended proportion of a plate that should be filled with vegetables?,
      options: [About half the plate., One quarter., One eighth.", "The entire plate.].sort(() => Math.random() - 0.5),
      correctAnswer: About half the plate."
    })
  },
  {
    id: "G8-HS-NU-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Balanced Meals,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Water is an essential nutrient that is often overlooked. Why is adequate water intake important for the body?,
      options: [It regulates body temperature, transports nutrients, and removes waste., It is not important., "It only helps with thirst., It causes weight gain."].sort(() => Math.random() - 0.5),
      correctAnswer: "It regulates body temperature, transports nutrients, and removes waste.
    })
  },

  // --- FOOD PRESERVATION (4 Materials) ---
  {
    id: G8-HS-FP-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Food Preservation,
    subtopic: "Drying",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Drying is one of the oldest methods of food preservation. What is the principle behind drying as a preservation method?,
      options: [Removing moisture prevents the growth of microorganisms., Adding heat kills bacteria., Adding salt preserves food.", "Freezing stops spoilage.].sort(() => Math.random() - 0.5),
      correctAnswer: Removing moisture prevents the growth of microorganisms."
    })
  },
  {
    id: "G8-HS-FP-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Food Preservation",
    subtopic: "Canning,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Canning involves sealing food in jars and heating them to kill microorganisms. What is the purpose of the vacuum seal created in canning?,
      options: [To prevent air and microorganisms from entering the jar., To make the food taste better., "To change the color of the food., To add nutrients."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent air and microorganisms from entering the jar.
    })
  },
  {
    id: G8-HS-FP-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Food Preservation,
    subtopic: "Refrigeration",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refrigeration slows down the growth of microorganisms that cause food spoilage. What is the recommended temperature for a refrigerator?,
      options: [Below 4°C (40°F), Above 20°C, 15°C", "Room temperature].sort(() => Math.random() - 0.5),
      correctAnswer: Below 4°C (40°F)"
    })
  },
  {
    id: "G8-HS-FP-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Food Preservation",
    subtopic: "Food Preservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Freezing is a convenient method of food preservation that preserves nutrients well. What is a disadvantage of freezing food?,
      options: [It can change the texture of some foods due to ice crystal formation., It destroys all nutrients., "It takes too long., It requires no energy."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can change the texture of some foods due to ice crystal formation.
    })
  },

  // --- TABLE MANNERS (3 Materials) ---
  {
    id: G8-HS-TM-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Table Manners,
    subtopic: "Setting the Table",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proper table setting enhances the dining experience and shows respect for guests. What is the correct placement of a fork in a formal table setting?,
      options: [To the left of the dinner plate., To the right of the dinner plate., Above the dinner plate.", "On the dinner plate.].sort(() => Math.random() - 0.5),
      correctAnswer: To the left of the dinner plate."
    })
  },
  {
    id: "G8-HS-TM-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Table Manners",
    subtopic: "Dining Etiquette,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Dining etiquette involves a set of rules for polite behavior while eating. What should you do if you need to leave the table during a meal?,
      options: [Excuse yourself and place your napkin on your chair or to the left of your plate., Leave without saying anything., "Take your plate with you., Yell across the table."].sort(() => Math.random() - 0.5),
      correctAnswer: "Excuse yourself and place your napkin on your chair or to the left of your plate.
    })
  },
  {
    id: G8-HS-TM-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Table Manners,
    subtopic: "Dining Etiquette",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Dining etiquette varies across cultures. What is considered proper behavior when eating in a Kenyan cultural setting?,
      options: [Wash hands before eating, eat with right hand if using hands, and wait for elders., Eat with left hand., Start eating before others are served.", "Talk loudly while eating.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hands before eating, eat with right hand if using hands, and wait for elders."
    })
  },

  // --- SEWING PROJECTS (3 Materials) ---
  {
    id: "G8-HS-SP-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Sewing Projects",
    subtopic: "Making an Apron,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "An apron is a practical and simple sewing project for beginners. What is the main purpose of an apron?,
      options: [To protect clothing from stains and dirt while working or cooking., To keep warm., "To make a fashion statement., To carry tools."].sort(() => Math.random() - 0.5),
      correctAnswer: "To protect clothing from stains and dirt while working or cooking.
    })
  },
  {
    id: G8-HS-SP-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Sewing Projects,
    subtopic: "Making a Bag",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A simple tote bag is a useful sewing project that can be customized in many ways. What is a common material used for making a sturdy tote bag?,
      options: [Canvas or cotton fabric., Silk., Lace.", "Paper.].sort(() => Math.random() - 0.5),
      correctAnswer: Canvas or cotton fabric."
    })
  },
  {
    id: "G8-HS-SP-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Sewing Projects",
    subtopic: "Simple Sewing Projects,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pillow covers are another simple sewing project that can enhance home decor. What is the easiest closure method for a pillow cover?,
      options: [An envelope closure where the back flaps overlap., A zipper., "Buttons., Snaps."].sort(() => Math.random() - 0.5),
      correctAnswer: "An envelope closure where the back flaps overlap.
    })
  },

  // --- HOME MAINTENANCE (3 Materials) ---
  {
    id: G8-HS-HM-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Maintenance,
    subtopic: "Simple Repairs",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Simple home repairs can save money and keep the home in good condition. What tool is commonly used to fix a leaking tap?,
      options: [A wrench and replacement washers., A hammer., A screwdriver.", "A saw.].sort(() => Math.random() - 0.5),
      correctAnswer: A wrench and replacement washers."
    })
  },
  {
    id: "G8-HS-HM-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Home Maintenance",
    subtopic: "Home Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular home maintenance prevents accidents and protects property value. What is an important safety check that should be done on electrical appliances?,
      options: [Check for frayed wires and have appliances serviced regularly., Ignore small issues., "Use appliances with damaged cords., Keep appliances in wet areas."].sort(() => Math.random() - 0.5),
      correctAnswer: "Check for frayed wires and have appliances serviced regularly.
    })
  },
  {
    id: G8-HS-HM-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Maintenance,
    subtopic: "Simple Repairs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A clogged sink or drain is a common household problem. What is a safe method to unclog a sink before using chemical products?,
      options: [Use a plunger or a plumber's snake., Pour boiling water and baking soda., Ignore the clog.", "Use a knife to scrape.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a plunger or a plumber's snake."
    })
  },

  // --- FIRST AID (3 Materials) ---
  {
    id: "G8-HS-FA-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Emergency Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Knowing emergency care procedures can save lives in critical situations. What is the first step in providing emergency care to an unconscious person?,
      options: [Check responsiveness and call for emergency help if there is no response., Perform CPR immediately., "Move the person., Give water."].sort(() => Math.random() - 0.5),
      correctAnswer: "Check responsiveness and call for emergency help if there is no response.
    })
  },
  {
    id: G8-HS-FA-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "First Aid,
    subtopic: "CPR Basics",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " CPR (Cardiopulmonary Resuscitation) is a life-saving technique used in emergencies. What is the compression to ventilation ratio for adult CPR?,
      options: [30 compressions to 2 breaths., 5 compressions to 1 breath., 15 compressions to 2 breaths.", "10 compressions to 1 breath.].sort(() => Math.random() - 0.5),
      correctAnswer: 30 compressions to 2 breaths."
    })
  },
  {
    id: "G8-HS-FA-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Emergency Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Choking can be life-threatening and requires immediate action. What is the Heimlich maneuver used for?,
      options: [To dislodge an object from a choking person's airway., To treat burns., "To stop bleeding., To perform CPR."].sort(() => Math.random() - 0.5),
      correctAnswer: "To dislodge an object from a choking person's airway.
    })
  },

  // --- HOME ECONOMICS (2 Materials) ---
  {
    id: G8-HS-HE-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Economics,
    subtopic: "Budgeting",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A family budget helps plan spending and saving for financial stability. What is the difference between fixed and variable expenses in a budget?,
      options: [Fixed expenses stay the same, while variable expenses change from month to month., Fixed expenses change, variable expenses stay the same., They are the same.", "Fixed expenses are only for food.].sort(() => Math.random() - 0.5),
      correctAnswer: Fixed expenses stay the same, while variable expenses change from month to month."
    })
  },
  {
    id: "G8-HS-HE-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Home Economics",
    subtopic: "Record Keeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Record keeping helps families track their financial activities and plan for the future. What is the purpose of keeping a household spending diary?,
      options: [To track all expenses and identify areas where money can be saved., To show off to others., "To increase spending., To hide money."].sort(() => Math.random() - 0.5),
      correctAnswer: "To track all expenses and identify areas where money can be saved.
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL DEVELOPMENT (4 Materials) ---
  {
    id: G9-HS-PD-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Self-Esteem",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Self-esteem affects how individuals perceive themselves and interact with others. What is a healthy way to build and maintain self-esteem?,
      options: [Practice positive self-talk, set realistic goals, and accept personal strengths and weaknesses., Compare yourself to others constantly., Criticize yourself harshly.", "Ignore personal achievements.].sort(() => Math.random() - 0.5),
      correctAnswer: Practice positive self-talk, set realistic goals, and accept personal strengths and weaknesses."
    })
  },
  {
    id: "G9-HS-PD-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Professional grooming is important in the workplace and contributes to career success. What is the recommended dress code for a professional environment?,
      options: [Clean, well-fitting clothes that are appropriate for the workplace culture., Casual clothes only., "Extravagant fashion., The same clothes worn every day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean, well-fitting clothes that are appropriate for the workplace culture.
    })
  },
  {
    id: G9-HS-PD-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Social Skills",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Social skills are essential for building and maintaining relationships. What is an important social skill that helps in communication?,
      options: [Active listening and showing empathy., Talking constantly., Interrupting others.", "Ignoring others' feelings.].sort(() => Math.random() - 0.5),
      correctAnswer: Active listening and showing empathy."
    })
  },
  {
    id: "G9-HS-PD-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Self-Esteem,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Positive body image is an important part of self-esteem. What is a healthy way to develop a positive body image?,
      options: [Appreciate your body for what it can do rather than just how it looks., Compare your body to models., "Criticize your body., Never exercise."].sort(() => Math.random() - 0.5),
      correctAnswer: "Appreciate your body for what it can do rather than just how it looks.
    })
  },

  // --- HOME MANAGEMENT (4 Materials) ---
  {
    id: G9-HS-HM-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Schedules",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A cleaning schedule helps maintain a clean and organized home without feeling overwhelmed. What is the recommended frequency for deep cleaning the kitchen?,
      options: [Weekly or bi-weekly, depending on use., Every year., Once a month.", "Never.].sort(() => Math.random() - 0.5),
      correctAnswer: Weekly or bi-weekly, depending on use."
    })
  },
  {
    id: "G9-HS-HM-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Organization,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Decluttering is the process of removing unnecessary items to create an organized space. Why is decluttering beneficial for the home environment?,
      options: [It reduces stress, saves time, and creates a more functional living space., It fills the house with more items., "It is a waste of time., It makes cleaning harder."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reduces stress, saves time, and creates a more functional living space.
    })
  },
  {
    id: G9-HS-HM-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Organization",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Time management skills are important for balancing work, home, and personal life. What is a time management technique that can help people be more productive?,
      options: [Prioritizing tasks and creating a to-do list., Doing everything at once., Procrastinating.", "Saying yes to everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Prioritizing tasks and creating a to-do list."
    })
  },
  {
    id: "G9-HS-HM-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Cleaning Schedules,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Seasonal cleaning involves tasks that are done less frequently, such as twice a year. Which of the following is an example of a seasonal cleaning task?,
      options: [Cleaning windows, curtains, and carpets., Daily dishwashing.", "Sweeping the floor., Taking out the trash."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning windows, curtains, and carpets.
    })
  },

  // --- TEXTILE TECHNOLOGY (4 Materials) ---
  {
    id: G9-HS-TT-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Textile Technology,
    subtopic: "Fabric Finishing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Fabric finishing processes give textiles their final properties and appearance. What is the purpose of mercerization in cotton fabric finishing?,
      options: [To add strength, luster, and dye affinity to the fabric., To make fabric shrink., To weaken the fabric.", "To change the color.].sort(() => Math.random() - 0.5),
      correctAnswer: To add strength, luster, and dye affinity to the fabric."
    })
  },
  {
    id: "G9-HS-TT-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Textile Technology",
    subtopic: "Care Labels,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Care labels on clothing provide important information about how to wash and maintain the garment. What does the symbol of a hand in a basin indicate on a care label?,
      options: [Hand wash only., Machine wash., "Dry clean only., Do not wash."].sort(() => Math.random() - 0.5),
      correctAnswer: "Hand wash only.
    })
  },
  {
    id: G9-HS-TT-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Textile Technology,
    subtopic: "Care Labels",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Drying symbols on care labels indicate how to dry a garment safely. What does a square with a circle inside mean on a care label?,
      options: [Tumble dry., Air dry., Dry flat.", "Do not dry.].sort(() => Math.random() - 0.5),
      correctAnswer: Tumble dry."
    })
  },
  {
    id: "G9-HS-TT-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Textile Technology",
    subtopic: "Fabric Finishing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Waterproof and stain-resistant finishes are common on outdoor and performance fabrics. What is the name of the chemical often used for waterproofing fabric?,
      options: [Durable Water Repellent (DWR), Bleach, "Fabric softener, Starch"].sort(() => Math.random() - 0.5),
      correctAnswer: "Durable Water Repellent (DWR)
    })
  },

  // --- FOOD SCIENCE (4 Materials) ---
  {
    id: G9-HS-FS-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Food Science,
    subtopic: "Food Preservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fermentation is a food preservation method that also changes the flavor and texture of food. What is the principle of fermentation?,
      options: [Microorganisms like bacteria or yeast break down food components., Adding heat kills bacteria., Freezing stops spoilage.", "Drying removes moisture.].sort(() => Math.random() - 0.5),
      correctAnswer: Microorganisms like bacteria or yeast break down food components."
    })
  },
  {
    id: "G9-HS-FS-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Food Science",
    subtopic: "Fermentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Uji and other Kenyan fermented foods are examples of traditional food preservation. What is the nutritional benefit of fermentation in foods?,
      options: [It can increase the availability of nutrients and improve digestion., It removes all nutrients., "It adds harmful bacteria., It reduces protein content."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can increase the availability of nutrients and improve digestion.
    })
  },
  {
    id: G9-HS-FS-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Food Science,
    subtopic: "Food Preservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sugaring is a food preservation method that uses sugar to prevent microbial growth. What is an example of food preserved using sugar?,
      options: [Jam, jelly, and fruit preserves., Canned vegetables., Dried meat.", "Fermented milk.].sort(() => Math.random() - 0.5),
      correctAnswer: Jam, jelly, and fruit preserves."
    })
  },
  {
    id: "G9-HS-FS-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Food Science",
    subtopic: "Fermentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fermented foods like yogurt and sauerkraut contain probiotics that benefit gut health. What are the health benefits of consuming fermented foods?,
      options: [They support gut health, boost immunity, and improve digestion., They cause illness., "They have no benefits., They are only for flavor."].sort(() => Math.random() - 0.5),
      correctAnswer: "They support gut health, boost immunity, and improve digestion.
    })
  },

  // --- ADVANCED FOOD PREPARATION (4 Materials) ---
  {
    id: G9-HS-AF-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Advanced Food Preparation,
    subtopic: "Baking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Baking is a dry-heat cooking method that uses an enclosed oven. What leavening agent is commonly used in baking to make baked goods rise?,
      options: [Baking powder or yeast., Salt., Sugar.", "Oil.].sort(() => Math.random() - 0.5),
      correctAnswer: Baking powder or yeast."
    })
  },
  {
    id: "G9-HS-AF-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Advanced Food Preparation",
    subtopic: "Pastry Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pastry making requires precise measurements and techniques to achieve the right texture. What is the key to making a flaky pastry?,
      options: [Keeping the fat cold and not overworking the dough., Using hot water., "Adding more flour., Baking at low heat."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keeping the fat cold and not overworking the dough.
    })
  },
  {
    id: G9-HS-AF-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Advanced Food Preparation,
    subtopic: "Baking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Bread making involves kneading and rising to develop gluten. What is the purpose of kneading bread dough?,
      options: [To develop gluten and create a smooth, elastic texture., To add flavor., To make it soft.", "To dry it out.].sort(() => Math.random() - 0.5),
      correctAnswer: To develop gluten and create a smooth, elastic texture."
    })
  },
  {
    id: "G9-HS-AF-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Advanced Food Preparation",
    subtopic: "Pastry Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Shortcrust pastry is used for pies and tarts and has a crumbly texture. What fat is traditionally used in shortcrust pastry?,
      options: [Butter or vegetable shortening., Olive oil., "Lard only., Margarine."].sort(() => Math.random() - 0.5),
      correctAnswer: "Butter or vegetable shortening.
    })
  },

  // --- NUTRITION AND HEALTH (3 Materials) ---
  {
    id: G9-HS-NH-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Nutrition and Health,
    subtopic: "Diet-Related Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Diet-related diseases are often caused by poor eating habits and lifestyle choices. What is a common diet-related disease associated with high salt intake?,
      options: [High blood pressure (hypertension)., Anemia., Rickets.", "Scurvy.].sort(() => Math.random() - 0.5),
      correctAnswer: High blood pressure (hypertension)."
    })
  },
  {
    id: "G9-HS-NH-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Nutrition and Health",
    subtopic: "Diet-Related Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Obesity is a major health concern in Kenya and worldwide. What are the health risks associated with obesity?,
      options: [Heart disease, type 2 diabetes, and joint problems., Strong immune system., "Better eyesight., Increased energy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Heart disease, type 2 diabetes, and joint problems.
    })
  },
  {
    id: G9-HS-NH-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Nutrition and Health,
    subtopic: "Healthy Eating",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Healthy eating habits can prevent many diet-related diseases. Which of the following is recommended for maintaining a healthy weight?,
      options: [Eating a balanced diet with appropriate portion sizes and regular physical activity., Skipping meals., Eating only one type of food.", "Consuming a lot of sugar.].sort(() => Math.random() - 0.5),
      correctAnswer: Eating a balanced diet with appropriate portion sizes and regular physical activity."
    })
  },

  // --- GARMENT MAKING (3 Materials) ---
  {
    id: "G9-HS-GM-01",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Garment Making",
    subtopic: "Fitting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Garment fitting ensures that clothes fit the body properly and look good. What is the purpose of making a toile or muslin mock-up before cutting the final fabric?,
      options: [To test the fit and make any adjustments before cutting the final fabric., To waste fabric., "To make a pattern., To save time."].sort(() => Math.random() - 0.5),
      correctAnswer: "To test the fit and make any adjustments before cutting the final fabric.
    })
  },
  {
    id: G9-HS-GM-02",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Garment Making,
    subtopic: "Finishing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A well-finished garment has neat edges and a professional appearance. What is a finishing technique used to neaten the raw edges of seams?,
      options: [Overcasting, pinking, or binding the edges., Leaving them raw., Using glue.", "Taping them.].sort(() => Math.random() - 0.5),
      correctAnswer: Overcasting, pinking, or binding the edges."
    })
  },
  {
    id: "G9-HS-GM-03",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Garment Making",
    subtopic: "Embellishments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Embellishments add decorative details to garments and crafts. Which of the following is an example of an embellishment technique?,
      options: [Embroidery, beading, and appliqué., Ironing., "Washing., Folding."].sort(() => Math.random() - 0.5),
      correctAnswer: "Embroidery, beading, and appliqué.
    })
  },

  // --- INTERIOR DESIGN (3 Materials) ---
  {
    id: G9-HS-ID-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Interior Design,
    subtopic: "Color Schemes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Color schemes create harmony and visual appeal in interior spaces. What is a monochromatic color scheme?,
      options: [Using different shades and tints of a single color., Using two complementary colors., Using three colors in a triangle.", "Using primary colors.].sort(() => Math.random() - 0.5),
      correctAnswer: Using different shades and tints of a single color."
    })
  },
  {
    id: "G9-HS-ID-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Interior Design",
    subtopic: "Furniture Arrangement,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The arrangement of furniture should consider the function of the room and the flow of traffic. What is a common mistake in furniture arrangement?,
      options: [Blocking pathways and overcrowding the room., Leaving enough space., "Creating conversation areas., Using the right scale."].sort(() => Math.random() - 0.5),
      correctAnswer: "Blocking pathways and overcrowding the room.
    })
  },
  {
    id: G9-HS-ID-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Interior Design,
    subtopic: "Color Schemes",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Complementary colors are opposite each other on the color wheel and create a dynamic contrast. Which of the following is a pair of complementary colors?,
      options: [Red and green, Blue and green, Yellow and orange", "Purple and pink].sort(() => Math.random() - 0.5),
      correctAnswer: Red and green"
    })
  },

  // --- HOME SAFETY (3 Materials) ---
  {
    id: "G9-HS-HS-01",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Safety",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fire safety measures in the home can save lives and prevent property damage. What is an essential fire safety device that every home should have?,
      options: [A smoke detector and a fire extinguisher., A television., "A vacuum cleaner., A microwave."].sort(() => Math.random() - 0.5),
      correctAnswer: "A smoke detector and a fire extinguisher.
    })
  },
  {
    id: G9-HS-HS-02",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Safety,
    subtopic: "Electrical Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Electrical safety is important to prevent shocks and fires. What should you do if an electrical appliance feels hot or produces a burning smell?,
      options: [Turn it off immediately and have it checked by a professional., Continue using it., Cover it with a cloth.", "Pour water on it.].sort(() => Math.random() - 0.5),
      correctAnswer: Turn it off immediately and have it checked by a professional."
    })
  },
  {
    id: "G9-HS-HS-03",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Safety",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Creating a fire escape plan is essential for home safety. What should a fire escape plan include?,
      options: [Two ways out of every room and a meeting place outside the home., Only one way out., "No meeting place., Leaving through the window only."].sort(() => Math.random() - 0.5),
      correctAnswer: "Two ways out of every room and a meeting place outside the home.
    })
  },

  // --- FINANCIAL LITERACY (3 Materials) ---
  {
    id: G9-HS-FL-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Financial Literacy,
    subtopic: "Savings",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Saving is a key component of financial literacy and helps build wealth over time. What is the rule of thumb for saving a portion of income?,
      options: [The 50-30-20 rule: 50% needs, 30% wants, 20% savings., Save all income., Save nothing.", "Save 5% of income.].sort(() => Math.random() - 0.5),
      correctAnswer: The 50-30-20 rule: 50% needs, 30% wants, 20% savings."
    })
  },
  {
    id: "G9-HS-FL-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Financial Literacy",
    subtopic: "Investments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Investing is a way to grow money over time for future goals. What is the difference between saving and investing?,
      options: [Saving is for short-term goals, while investing is for long-term growth with risk., They are the same., "Investing is safer., Saving has higher returns."].sort(() => Math.random() - 0.5),
      correctAnswer: "Saving is for short-term goals, while investing is for long-term growth with risk.
    })
  },
  {
    id: G9-HS-FL-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Financial Literacy,
    subtopic: "Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Entrepreneurship can provide income and independence. What is an essential skill for a successful entrepreneur?,
      options: [Financial management, marketing, and customer service skills., Only technical skills., Only creativity.", "Ignoring competition.].sort(() => Math.random() - 0.5),
      correctAnswer: Financial management, marketing, and customer service skills."
    })
  }`nexport const homeScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G4-HS-PH-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Body",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "Keeping our bodies clean is essential for good health and prevents the spread of germs. Which of the following is the most important practice for maintaining good personal hygiene?,
      options: [Bathing daily with soap and water., Bathing once a week., "Using perfume instead of bathing., Wearing clean clothes but not bathing."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water.
    })
  },
  {
    id: G4-HS-PH-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Hair",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Healthy hair requires proper care and regular maintenance. What is the correct way to care for your hair to keep it clean and healthy?,
      options: [Wash hair regularly with shampoo and comb it gently., Wash hair with soap only., Never wash hair to keep it strong.", "Use oil without washing.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly with shampoo and comb it gently."
    })
  },
  {
    id: "G4-HS-PH-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Care of the Teeth,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Dental hygiene is important to prevent cavities and bad breath. According to dental health guidelines, how often should you brush your teeth?,
      options: [At least twice a day, morning and before bed., Once a week.", "Only when they feel dirty., Once a month."].sort(() => Math.random() - 0.5),
      correctAnswer: "At least twice a day, morning and before bed.
    })
  },
  {
    id: G4-HS-PH-04",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Care of the Nails",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Dirty and long nails can harbor germs that cause infections. What is the proper way to care for your nails?,
      options: [Cut them short and clean under them regularly., Let them grow long and paint them., Bite them to keep them short.", "Never cut them.].sort(() => Math.random() - 0.5),
      correctAnswer: Cut them short and clean under them regularly."
    })
  },
  {
    id: "G4-HS-PH-05",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Overall Body Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Good personal hygiene involves more than just bathing and includes caring for all parts of the body. Which of the following is part of a complete personal hygiene routine?,
      options: [Bathing, brushing teeth, washing hands, and caring for hair and nails., Only bathing., "Only wearing clean clothes., Only brushing hair."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing, brushing teeth, washing hands, and caring for hair and nails.
    })
  },

  // --- HOME HYGIENE (4 Materials) ---
  {
    id: G4-HS-HH-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the House",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A clean home prevents the spread of diseases and creates a comfortable living environment. What is the most effective way to keep your house clean?,
      options: [Sweep and mop floors daily, dust furniture, and clean surfaces., Clean only when visitors come., Just remove visible dirt.", "Clean only the kitchen.].sort(() => Math.random() - 0.5),
      correctAnswer: Sweep and mop floors daily, dust furniture, and clean surfaces."
    })
  },
  {
    id: "G4-HS-HH-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Cleaning the Kitchen,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The kitchen is where food is prepared, so it must be kept especially clean to prevent food contamination. Which area of the kitchen requires the most frequent cleaning?,
      options: [Food preparation surfaces and utensils after each use., The floor once a week.", "The ceiling every month., The windows once a year."].sort(() => Math.random() - 0.5),
      correctAnswer: "Food preparation surfaces and utensils after each use.
    })
  },
  {
    id: G4-HS-HH-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Hygiene,
    subtopic: "Cleaning the Bathroom",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Bathrooms can be a breeding ground for bacteria and mold. What is the proper way to maintain bathroom hygiene?,
      options: [Clean the toilet, sink, and bathtub regularly with disinfectant., Only clean when it looks dirty., Rinse with water only.", "Never clean it.].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the toilet, sink, and bathtub regularly with disinfectant."
    })
  },
  {
    id: "G4-HS-HH-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Hygiene",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper waste disposal is essential to prevent diseases and keep the environment clean. What should you do with household waste to maintain hygiene?,
      options: [Separate waste and dispose of it in designated bins regularly., Throw it outside the compound., "Burn it in the house., Bury it in the garden."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate waste and dispose of it in designated bins regularly.
    })
  },

  // --- CARE OF CLOTHING (4 Materials) ---
  {
    id: G4-HS-CC-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Washing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Proper washing keeps clothes clean, fresh, and long-lasting. What is the first step you should take before washing any clothes?,
      options: [Sort clothes by color and fabric type., Put all clothes in the water., Use hot water for all clothes.", "Add detergent without checking.].sort(() => Math.random() - 0.5),
      correctAnswer: Sort clothes by color and fabric type."
    })
  },
  {
    id: "G4-HS-CC-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Washing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Delicate fabrics require special care during washing to prevent damage. How should you wash delicate clothes like silk or wool?,
      options: [Wash them gently by hand with mild detergent in cool water., Wash them in a washing machine with hot water., "Soak them in bleach., Scrub them vigorously."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash them gently by hand with mild detergent in cool water.
    })
  },
  {
    id: G4-HS-CC-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Care of Clothing,
    subtopic: "Ironing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Ironing removes wrinkles and makes clothes look neat and professional. What safety precaution should you take when using an electric iron?,
      options: [Keep the iron away from children and use it on an ironing board., Leave the iron on when not in use., Use it without water in the boiler.", "Iron clothes on the bed.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the iron away from children and use it on an ironing board."
    })
  },
  {
    id: "G4-HS-CC-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Care of Clothing",
    subtopic: "Storing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Proper storage protects clothes from damage and keeps them ready to wear. What is the best way to store clothes in a wardrobe?,
      options: [Fold them neatly or hang them, and keep the wardrobe clean and dry., Throw them in a pile., "Store wet clothes., Keep them in the sun."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fold them neatly or hang them, and keep the wardrobe clean and dry.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G4-HS-FN-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A balanced diet contains foods from all food groups to provide essential nutrients. Which of the following correctly lists the main food groups?,
      options: [Carbohydrates, proteins, vitamins, minerals, fats, and water., Rice, meat, and fruits only., Only proteins and carbohydrates.", "Only vegetables and fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vitamins, minerals, fats, and water."
    })
  },
  {
    id: "G4-HS-FN-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Balanced Diet,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A balanced diet is essential for growth, energy, and good health. What does a balanced diet consist of?,
      options: ["The right combination of foods from all food groups in the correct proportions., Eating only fruits and vegetables.", "Eating only carbohydrates., Eating whatever is available."].sort(() => Math.random() - 0.5),
      correctAnswer: "The right combination of foods from all food groups in the correct proportions.
    })
  },
  {
    id: G4-HS-FN-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Meal planning helps families eat nutritious meals and manage their food budget. When planning meals for a family, what should you consider?,
      options: [Nutritional needs, budget, preferences, and availability of food., Only the cost of food., Only the taste of food.", "Only what is available in the market.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional needs, budget, preferences, and availability of food."
    })
  },
  {
    id: "G4-HS-FN-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Food Groups,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different foods provide different nutrients needed by the body. Which food group is the main source of energy for the body?,
      options: [Carbohydrates like rice, bread, and potatoes., Proteins like meat and beans., "Vitamins from fruits and vegetables., Fats and oils."].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbohydrates like rice, bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G4-HS-FP-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kitchen safety is crucial to prevent accidents and injuries while cooking. What is the most important rule to follow in the kitchen?,
      options: [Never leave cooking food unattended and handle sharp tools carefully., Run around the kitchen., Use wet hands near electrical appliances.", "Leave all utensils on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Never leave cooking food unattended and handle sharp tools carefully."
    })
  },
  {
    id: "G4-HS-FP-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different cooking methods affect the taste, texture, and nutritional value of food. Which of the following is a healthy cooking method that preserves nutrients?,
      options: ["Steaming or boiling with minimal water., Deep frying in oil.", "Cooking for a very long time., Adding lots of salt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or boiling with minimal water.
    })
  },
  {
    id: G4-HS-FP-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Kitchen Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Food can become contaminated if proper hygiene is not observed in the kitchen. What should you always do before handling food?,
      options: [Wash your hands thoroughly with soap and running water., Just rinse your hands., Wear gloves without washing hands.", "Wipe your hands on a cloth.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash your hands thoroughly with soap and running water."
    })
  },
  {
    id: "G4-HS-FP-04",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Boiling and steaming are common cooking methods in Kenyan homes. What is a disadvantage of boiling vegetables?,
      options: [Some water-soluble vitamins may be lost in the water., It takes too long., "It uses too much oil., It makes food too crispy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Some water-soluble vitamins may be lost in the water.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G4-HS-BEV-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Tea",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tea is a popular beverage in Kenya enjoyed by many families. What are the basic ingredients needed to prepare a cup of tea?,
      options: [Tea leaves, hot water, milk, and sugar., Coffee, milk, and sugar., Tea leaves and hot water only.", "Juice and water.].sort(() => Math.random() - 0.5),
      correctAnswer: Tea leaves, hot water, milk, and sugar."
    })
  },
  {
    id: "G4-HS-BEV-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Tea,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Tea can be prepared in different ways depending on preference. How is Kenyan tea traditionally prepared?,
      options: [Boiled with milk and sugar to make a creamy drink., Served with lemon and honey., "Served cold with ice., Mixed with soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiled with milk and sugar to make a creamy drink.
    })
  },
  {
    id: G4-HS-BEV-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Coffee",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Coffee is another popular beverage enjoyed in Kenya and around the world. What equipment is commonly used to brew coffee?,
      options: [A coffee maker or a traditional pot called a jebena., A pressure cooker., A microwave.", "A frying pan.].sort(() => Math.random() - 0.5),
      correctAnswer: A coffee maker or a traditional pot called a jebena."
    })
  },

  // --- SEWING AND NEEDLEWORK (3 Materials) ---
  {
    id: "G4-HS-SEW-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sewing is a valuable skill that allows you to mend and create clothes. What is the most basic and commonly used sewing stitch?,
      options: [The running stitch, The zigzag stitch, "The blanket stitch, The chain stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The running stitch
    })
  },
  {
    id: G4-HS-SEW-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Sewing and Needlework,
    subtopic: "Threading a Needle",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Before you can start sewing, you need to thread the needle correctly. What is the correct way to thread a needle?,
      options: [Wet the thread tip, pass it through the eye of the needle, and pull through., Push the needle through the thread., Tie the thread around the needle.", "Use a thick thread.].sort(() => Math.random() - 0.5),
      correctAnswer: Wet the thread tip, pass it through the eye of the needle, and pull through."
    })
  },
  {
    id: "G4-HS-SEW-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Sewing and Needlework",
    subtopic: "Basic Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The backstitch is a strong stitch used for seams. How does a backstitch differ from a running stitch?,
      options: [The needle goes backward to create a continuous line of stitches., It is the same as a running stitch., "It uses a knot at every stitch., It is done with a machine."].sort(() => Math.random() - 0.5),
      correctAnswer: "The needle goes backward to create a continuous line of stitches.
    })
  },

  // --- HOME FURNISHINGS (3 Materials) ---
  {
    id: G4-HS-HF-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Arrangement of Furniture",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The arrangement of furniture affects how comfortable and functional a room is. What should you consider when arranging furniture in a room?,
      options: [The flow of movement, room size, and purpose of the room., Only the color of the furniture., Only the cost of the furniture.", "Put everything against the wall.].sort(() => Math.random() - 0.5),
      correctAnswer: The flow of movement, room size, and purpose of the room."
    })
  },
  {
    id: "G4-HS-HF-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Home Furnishings",
    subtopic: "Care of Home Items,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Furniture and furnishings need regular care to maintain their appearance and longevity. How should wooden furniture be cared for?,
      options: [Dust regularly and polish with appropriate wood polish., Wash with soap and water., "Leave them in the sun., Scrub with steel wool."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust regularly and polish with appropriate wood polish.
    })
  },
  {
    id: G4-HS-HF-03",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Home Furnishings,
    subtopic: "Care of Home Items",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Cushions, curtains, and carpets add comfort and beauty to a home. How should fabric furnishings be maintained?,
      options: [Vacuum regularly and clean spills immediately., Ignore stains., Wash them with harsh chemicals.", "Shake them outside only.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly and clean spills immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G4-HS-HS-01",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who is injured or suddenly becomes ill. What is the first thing you should do in an emergency?,
      options: [Stay calm and assess the situation, then call for help if needed., Run away from the scene., "Panic and scream., Ignore the person."].sort(() => Math.random() - 0.5),
      correctAnswer: "Stay calm and assess the situation, then call for help if needed.
    })
  },
  {
    id: G4-HS-HS-02",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Accidents at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Accidents can happen at home, especially in the kitchen and bathroom. What is a common cause of accidents in the kitchen?,
      options: [Slippery floors, handling hot items, and using knives carelessly., Eating too much., Talking while eating.", "Using the microwave.].sort(() => Math.random() - 0.5),
      correctAnswer: Slippery floors, handling hot items, and using knives carelessly."
    })
  },
  {
    id: "G4-HS-HS-03",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Knowing basic first aid can save lives in emergency situations. What should you do if someone gets a burn?,
      options: [Run cool water over the burn for several minutes and cover with a clean cloth., Put butter on the burn., "Pop any blisters., Ignore it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool water over the burn for several minutes and cover with a clean cloth.
    })
  },

  // --- TIME AND MONEY MANAGEMENT (2 Materials) ---
  {
    id: G4-HS-TM-01",
    grade: "Grade 4,
    subject: Home Science",
    topic: "Time and Money Management,
    subtopic: "Planning Daily Chores",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Planning daily chores helps you use your time efficiently and keeps the home running smoothly. What is the best way to manage daily chores?,
      options: [Make a schedule or checklist and allocate time for each task., Do everything at the last minute., Only do chores on weekends.", "Let others do everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Make a schedule or checklist and allocate time for each task."
    })
  },
  {
    id: "G4-HS-TM-02",
    grade: "Grade 4",
    subject: "Home Science",
    topic: "Time and Money Management",
    subtopic: "Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Budgeting helps a family manage its money and ensure that all needs are met. What is the first step in creating a family budget?,
      options: [List all income and track all expenses., Buy whatever you want., "Only buy food., Save all money without spending."].sort(() => Math.random() - 0.5),
      correctAnswer: "List all income and track all expenses.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL GROOMING (4 Materials) ---
  {
    id: G5-HS-PG-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Skin Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Skin care is important for maintaining healthy skin and preventing skin conditions. What is the most important daily practice for healthy skin?,
      options: [Washing your face and body with soap and water daily., Using makeup every day., Scrubbing your skin roughly.", "Never moisturizing.].sort(() => Math.random() - 0.5),
      correctAnswer: Washing your face and body with soap and water daily."
    })
  },
  {
    id: "G5-HS-PG-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Well-groomed nails are a sign of good hygiene and personal care. How should you properly care for your nails?,
      options: [Keep them clean, trimmed, and filed regularly., Paint them with dark polish., "Bite them to keep them short., Never cut them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keep them clean, trimmed, and filed regularly.
    })
  },
  {
    id: G5-HS-PG-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Personal Grooming,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Healthy hair requires proper care to prevent breakage and keep it looking good. What should you do to prevent dandruff and keep your scalp healthy?,
      options: [Wash hair regularly and use a gentle shampoo., Use hot oil every day., Never wash your hair.", "Use harsh chemicals.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hair regularly and use a gentle shampoo."
    })
  },
  {
    id: "G5-HS-PG-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Personal Grooming",
    subtopic: "Overall Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Good grooming involves taking care of your entire appearance and hygiene. Which of the following is a key element of good personal grooming?,
      options: [Wearing clean clothes, having neat hair, and practicing good hygiene., Wearing expensive clothes., "Using a lot of perfume., Having the latest hairstyle."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wearing clean clothes, having neat hair, and practicing good hygiene.
    })
  },

  // --- HOME CLEANING (4 Materials) ---
  {
    id: G5-HS-HC-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Different cleaning agents are used for different surfaces and purposes. What cleaning agent is used for cleaning glass and windows?,
      options: [Glass cleaner or vinegar solution., Bleach, Abrasive powder", "Dish soap].sort(() => Math.random() - 0.5),
      correctAnswer: Glass cleaner or vinegar solution."
    })
  },
  {
    id: "G5-HS-HC-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Sweeping and Mopping,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sweeping and mopping are essential for keeping floors clean and hygienic. What is the correct order for cleaning a floor?,
      options: [Sweep first to remove dirt and debris, then mop., Mop first, then sweep., "Only mop without sweeping., Only sweep without mopping."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweep first to remove dirt and debris, then mop.
    })
  },
  {
    id: G5-HS-HC-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Cleaning,
    subtopic: "Using Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Bleach is a strong cleaning agent that kills germs and removes stains. What safety precaution should be taken when using bleach?,
      options: [Use it in a well-ventilated area and never mix with other cleaners., Mix it with vinegar for more power., Use it on all surfaces.", "Use it without gloves.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it in a well-ventilated area and never mix with other cleaners."
    })
  },
  {
    id: "G5-HS-HC-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Cleaning",
    subtopic: "Cleaning Different Surfaces,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Different surfaces require different cleaning methods to avoid damage. How should wooden surfaces be cleaned?,
      options: [Dust with a soft cloth and use appropriate wood polish., Use water and soap., "Scrub with a hard brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dust with a soft cloth and use appropriate wood polish.
    })
  },

  // --- LAUNDRY WORK (4 Materials) ---
  {
    id: G5-HS-LW-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Sorting Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Sorting clothes before washing prevents color bleeding and ensures proper care for different fabrics. How should you sort clothes before washing?,
      options: [Separate whites from colors and sort by fabric type., Wash all clothes together., Only sort by size.", "Only sort by owner.].sort(() => Math.random() - 0.5),
      correctAnswer: Separate whites from colors and sort by fabric type."
    })
  },
  {
    id: "G5-HS-LW-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Hand Washing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hand washing is a gentle method of washing clothes that is suitable for delicate fabrics. What is the correct water temperature for hand washing delicate clothes?,
      options: [Cold or lukewarm water., Very hot water., "Boiling water., Water of any temperature."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cold or lukewarm water.
    })
  },
  {
    id: G5-HS-LW-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Laundry Work,
    subtopic: "Machine Washing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Washing machines make laundry work easier but require proper use. How can you prevent clothes from getting damaged in a washing machine?,
      options: [Use the correct cycle and load size for different fabrics., Overload the machine to save time., Use the hottest setting for all clothes.", "Use a lot of detergent.].sort(() => Math.random() - 0.5),
      correctAnswer: Use the correct cycle and load size for different fabrics."
    })
  },
  {
    id: "G5-HS-LW-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Laundry Work",
    subtopic: "Drying Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Proper drying of clothes prevents damage and keeps them looking fresh. What is the best way to dry clothes to prevent shrinkage and damage?,
      options: [Air dry on a clothesline away from direct harsh sunlight., Tumble dry on high heat., "Iron them wet., Leave them in a pile."].sort(() => Math.random() - 0.5),
      correctAnswer: "Air dry on a clothesline away from direct harsh sunlight.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G5-HS-NU-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutrients and Their Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proteins are essential nutrients that the body needs for growth and repair. Which of the following foods is a rich source of protein?,
      options: [Beans, eggs, meat, and fish., Rice and bread., Fruits and vegetables.", "Sugar and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, eggs, meat, and fish."
    })
  },
  {
    id: "G5-HS-NU-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vitamins and minerals are important micronutrients that support various body functions. Which vitamin is important for healthy eyesight and is found in carrots and orange fruits?,
      options: [Vitamin A, Vitamin B, "Vitamin C, Vitamin D"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamin A
    })
  },
  {
    id: G5-HS-NU-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Meal Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A balanced meal should contain foods from different food groups to provide all essential nutrients. What should be included in a balanced meal?,
      options: [Carbohydrates, proteins, vegetables, and fruits., Only meat and rice., Only vegetables.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, vegetables, and fruits."
    })
  },
  {
    id: "G5-HS-NU-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Carbohydrates provide energy for the body to function. Which of the following is a healthy source of complex carbohydrates?,
      options: [Brown rice, whole grain bread, and potatoes., White sugar and sweets., "Cakes and pastries., Fizzy drinks."].sort(() => Math.random() - 0.5),
      correctAnswer: "Brown rice, whole grain bread, and potatoes.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G5-HS-FP-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Vegetables",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vegetables provide essential vitamins and minerals and should be prepared properly to preserve their nutrients. What is the best way to cook vegetables to preserve their nutrients?,
      options: [Steam or stir-fry them quickly with minimal water., Boil them for a long time., Deep fry them.", "Microwave them for 30 minutes.].sort(() => Math.random() - 0.5),
      correctAnswer: Steam or stir-fry them quickly with minimal water."
    })
  },
  {
    id: "G5-HS-FP-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Preparing Soups,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Soup is a nutritious and comforting meal that can be made with various ingredients. What are the basic ingredients for making a vegetable soup?,
      options: [Vegetables, water or stock, and seasoning., Meat and flour., "Rice and tomatoes., Beans and coconut milk."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vegetables, water or stock, and seasoning.
    })
  },
  {
    id: G5-HS-FP-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Preparing Stews",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stews are hearty meals made by slowly cooking meat or vegetables in liquid. Which of the following is an important step when making a stew?,
      options: [Brown the meat first to add flavor, then add liquid and simmer., Just add everything to cold water., Cook on high heat for 10 minutes.", "Add all ingredients at once.].sort(() => Math.random() - 0.5),
      correctAnswer: Brown the meat first to add flavor, then add liquid and simmer."
    })
  },
  {
    id: "G5-HS-FP-04",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Kitchen Hygiene,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kitchen hygiene is essential to prevent food poisoning and cross-contamination. What is the best way to prevent cross-contamination in the kitchen?,
      options: [Use separate chopping boards for raw meat and other foods., Use the same board for everything., "Wash the board only at the end of the day., Never wash cutting boards."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate chopping boards for raw meat and other foods.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G5-HS-BEV-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Preparing Fresh Juices",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh fruit juices are healthy and refreshing beverages rich in vitamins. What is the correct way to prepare fresh fruit juice?,
      options: [Wash fruits, peel if necessary, blend, and strain if desired., Add sugar and leave it overnight., Boil the fruits first.", "Use dried fruits.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash fruits, peel if necessary, blend, and strain if desired."
    })
  },
  {
    id: "G5-HS-BEV-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Preparing Fresh Juices,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Smoothies are thicker than juices and often include milk or yogurt. What is a key ingredient that makes smoothies thick and creamy?,
      options: [Banana or yogurt, Water, "Oil, Flour"].sort(() => Math.random() - 0.5),
      correctAnswer: "Banana or yogurt
    })
  },
  {
    id: G5-HS-BEV-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Beverage Preparation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Fresh juices are best consumed immediately after preparation. Why is it important to drink fresh juice soon after making it?,
      options: [To get the full nutritional benefits before vitamins are lost., To keep it from spoiling., To save time.", "To reduce sugar content.].sort(() => Math.random() - 0.5),
      correctAnswer: To get the full nutritional benefits before vitamins are lost."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G5-HS-NW-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Running Stitch,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The running stitch is one of the most basic and versatile hand stitches. What is the running stitch commonly used for?,
      options: [Basting, gathering fabric, and simple seams., Buttonholes., "Zipper insertion., Stitching leather."].sort(() => Math.random() - 0.5),
      correctAnswer: "Basting, gathering fabric, and simple seams.
    })
  },
  {
    id: G5-HS-NW-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Stitches - Backstitch",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The backstitch creates a strong and secure seam. How does the backstitch compare to the running stitch?,
      options: [The backstitch is stronger because each stitch overlaps the previous one., The backstitch is weaker., They are exactly the same.", "The backstitch is faster.].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch is stronger because each stitch overlaps the previous one."
    })
  },
  {
    id: "G5-HS-NW-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Stitches - Hemming,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Hemming is a finishing technique used to create a neat edge on garments and other fabric items. What is the purpose of hemming?,
      options: [To prevent the fabric from fraying and create a finished look., To make the garment longer., "To add decoration only., To make the garment tighter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and create a finished look.
    })
  },

  // --- HOME MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-HM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Windows",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clean windows allow natural light to enter and improve the appearance of a home. How should glass windows be cleaned to avoid streaks?,
      options: [Use a glass cleaner and a squeegee or microfiber cloth., Use soap and water with a sponge., Scrub with an abrasive pad.", "Use newspaper alone.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a glass cleaner and a squeegee or microfiber cloth."
    })
  },
  {
    id: "G5-HS-HM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Polishing Furniture,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Polishing wood furniture restores its shine and protects it from damage. What is the proper way to apply polish to wooden furniture?,
      options: [Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine., Pour polish directly on the furniture., "Use water instead of polish., Use a rough cloth to apply it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply polish with a soft cloth, rub in the direction of the grain, and buff to shine.
    })
  },
  {
    id: G5-HS-HM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Maintaining Home Equipment",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Regular maintenance of home equipment extends their lifespan and ensures safety. Why is it important to regularly clean and service electrical appliances?,
      options: [To prevent accidents, save energy, and ensure they work efficiently., To keep them looking new., To avoid buying new ones.", "To reduce the electricity bill only.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent accidents, save energy, and ensure they work efficiently."
    })
  },

  // --- SAFETY IN THE HOME (3 Materials) ---
  {
    id: "G5-HS-SH-01",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Fire can be dangerous and cause serious injuries and property damage. What should you do if there is a small fire in the kitchen?,
      options: [Use a fire extinguisher or cover the fire with a lid to smother it., Pour water on a grease fire., "Run away and call for help., Blow on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a fire extinguisher or cover the fire with a lid to smother it.
    })
  },
  {
    id: G5-HS-SH-02",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Safety in the Home,
    subtopic: "Poison Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Many household products can be poisonous if ingested or misused. What is the best way to prevent poisoning in the home?,
      options: [Store cleaning products and medicines out of reach of children and in original containers., Keep them under the sink., Transfer them to unlabeled bottles.", "Leave them on the counter.].sort(() => Math.random() - 0.5),
      correctAnswer: Store cleaning products and medicines out of reach of children and in original containers."
    })
  },
  {
    id: "G5-HS-SH-03",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Safety in the Home",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Prevention is better than cure when it comes to fire safety. Which of the following is a fire safety measure in the home?,
      options: [Have a working smoke detector and a fire escape plan., Leave candles burning when you leave the house., "Overload electrical sockets., Keep flammable materials near the stove."].sort(() => Math.random() - 0.5),
      correctAnswer: "Have a working smoke detector and a fire escape plan.
    })
  },

  // --- RESOURCE MANAGEMENT (3 Materials) ---
  {
    id: G5-HS-RM-01",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Using Resources Wisely",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Using resources wisely helps save money and protect the environment. What is one way to conserve water in the home?,
      options: [Repair leaking taps and use water sparingly., Leave taps running., Fill the bathtub completely.", "Use a hose to water the garden every day.].sort(() => Math.random() - 0.5),
      correctAnswer: Repair leaking taps and use water sparingly."
    })
  },
  {
    id: "G5-HS-RM-02",
    grade: "Grade 5",
    subject: "Home Science",
    topic: "Resource Management",
    subtopic: "Using Resources Wisely,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Energy conservation reduces household bills and helps the environment. Which of the following is a way to save electricity at home?,
      options: [Turn off lights and appliances when not in use., Leave lights on all day., "Use old, inefficient appliances., Keep the refrigerator door open."].sort(() => Math.random() - 0.5),
      correctAnswer: "Turn off lights and appliances when not in use.
    })
  },
  {
    id: G5-HS-RM-03",
    grade: "Grade 5,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Saving Money",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Saving money is an important habit that helps families prepare for emergencies and future needs. What is a simple way to start saving money at home?,
      options: [Set aside a small amount regularly in a savings box or bank account., Spend all money as soon as you get it., Borrow money for unnecessary items.", "Keep all money in a wallet.].sort(() => Math.random() - 0.5),
      correctAnswer: Set aside a small amount regularly in a savings box or bank account."
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HEALTH AND HYGIENE (5 Materials) ---
  {
    id: "G6-HS-PH-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Body Odor,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Body odor is caused by bacteria breaking down sweat on the skin. What is the most effective way to prevent body odor?,
      options: [Bathing daily with soap and using an antiperspirant or deodorant., Using perfume only., "Wearing the same clothes for days., Avoiding physical activity."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and using an antiperspirant or deodorant.
    })
  },
  {
    id: G6-HS-PH-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Dental Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Good dental hygiene prevents cavities, gum disease, and bad breath. What is the recommended technique for effective teeth brushing?,
      options: [Brush in circular motions for at least two minutes, covering all tooth surfaces., Brush back and forth quickly., Brush only the front teeth.", "Brush once a day.].sort(() => Math.random() - 0.5),
      correctAnswer: Brush in circular motions for at least two minutes, covering all tooth surfaces."
    })
  },
  {
    id: "G6-HS-PH-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Dental Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Flossing is an important part of dental hygiene that complements brushing. Why is flossing important for dental health?,
      options: [It removes plaque and food particles from between teeth where brushes cannot reach., It whitens teeth., "It replaces brushing., It strengthens tooth enamel."].sort(() => Math.random() - 0.5),
      correctAnswer: "It removes plaque and food particles from between teeth where brushes cannot reach.
    })
  },
  {
    id: G6-HS-PH-04",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Personal Health and Hygiene,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper grooming involves maintaining a neat and clean appearance. Which of the following is an important aspect of personal grooming for adolescents?,
      options: [Regular bathing, hair care, nail care, and wearing clean clothes., Using expensive cosmetics., Following fashion trends blindly.", "Wearing heavy makeup.].sort(() => Math.random() - 0.5),
      correctAnswer: Regular bathing, hair care, nail care, and wearing clean clothes."
    })
  },
  {
    id: "G6-HS-PH-05",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Personal Health and Hygiene",
    subtopic: "Hygiene During Adolescence,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Adolescence brings physical changes that require extra attention to hygiene. What additional hygiene practices are important during adolescence?,
      options: [Washing face twice daily, using deodorant, and changing undergarments regularly., Bathing once a week., "Ignoring skin changes., Using adult products without guidance."].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing face twice daily, using deodorant, and changing undergarments regularly.
    })
  },

  // --- HOME SANITATION (4 Materials) ---
  {
    id: G6-HS-HS-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Waste Disposal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper waste disposal is crucial for maintaining a healthy home environment. What is the recommended way to dispose of organic kitchen waste?,
      options: [Use it to make compost for gardening., Mix it with plastic waste., Burn it in the compound.", "Throw it in the toilet.].sort(() => Math.random() - 0.5),
      correctAnswer: Use it to make compost for gardening."
    })
  },
  {
    id: "G6-HS-HS-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Waste Disposal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Improper waste disposal can lead to environmental pollution and health problems. What is the proper way to dispose of plastic and non-biodegradable waste?,
      options: [Separate for recycling or dispose of in designated bins., Burn it., "Bury it in the garden., Throw it in the river."].sort(() => Math.random() - 0.5),
      correctAnswer: "Separate for recycling or dispose of in designated bins.
    })
  },
  {
    id: G6-HS-HS-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pests like cockroaches, rats, and mosquitoes can spread diseases in the home. What is an effective way to control pests?,
      options: [Keep the home clean, seal food containers, and use appropriate pest control methods., Use insecticides without cleaning., Ignore them.", "Leave food uncovered.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the home clean, seal food containers, and use appropriate pest control methods."
    })
  },
  {
    id: "G6-HS-HS-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Pest Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mosquitoes are common pests that transmit diseases like malaria and dengue fever. How can you prevent mosquito breeding in and around the home?,
      options: [Eliminate standing water and use mosquito nets or repellents., Leave water containers open., "Use strong perfumes., Ignore puddles."].sort(() => Math.random() - 0.5),
      correctAnswer: "Eliminate standing water and use mosquito nets or repellents.
    })
  },

  // --- CLOTHING CARE (4 Materials) ---
  {
    id: G6-HS-CC-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Stain Removal",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Stains on clothes can be difficult to remove if not treated properly. What is the first step in removing a fresh stain from clothing?,
      options: [Treat it immediately by blotting and applying appropriate stain remover., Wait until it dries., Rub it with soap.", "Ignore it.].sort(() => Math.random() - 0.5),
      correctAnswer: Treat it immediately by blotting and applying appropriate stain remover."
    })
  },
  {
    id: "G6-HS-CC-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Stain Removal,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Different stains require different treatment methods. How should you treat a grease or oil stain on a garment?,
      options: [Apply a small amount of dish soap or stain remover and wash in warm water., Use hot water immediately., "Rub with a cloth., Apply bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply a small amount of dish soap or stain remover and wash in warm water.
    })
  },
  {
    id: G6-HS-CC-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Clothing Care,
    subtopic: "Mending Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Mending clothes extends their lifespan and saves money. What is the best way to mend a small tear in a garment?,
      options: [Use a needle and thread to stitch it neatly, matching the fabric., Use glue or tape., Ignore the tear.", "Cut the garment.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a needle and thread to stitch it neatly, matching the fabric."
    })
  },
  {
    id: "G6-HS-CC-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Clothing Care",
    subtopic: "Pressing Clothes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pressing clothes properly gives them a neat, crisp appearance. What temperature setting should you use when ironing synthetic fabrics?,
      options: [A low to medium temperature setting to prevent melting or scorching., The highest setting.", "No heat., Steam only."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low to medium temperature setting to prevent melting or scorching.
    })
  },

  // --- ADVANCED NUTRITION (4 Materials) ---
  {
    id: G6-HS-AN-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Meal Planning for Family",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meal planning for a family should consider the nutritional needs of all members. What factors should be considered when planning meals for a family with members of different ages?,
      options: [Nutritional requirements of different age groups, preferences, and budget., Only the preference of adults., Only the cost.", "Only one type of food.].sort(() => Math.random() - 0.5),
      correctAnswer: Nutritional requirements of different age groups, preferences, and budget."
    })
  },
  {
    id: "G6-HS-AN-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Meal Planning for Family,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Special diets may be needed for people with certain health conditions. What is an example of a special diet that may be recommended by a doctor?,
      options: [A low-sodium diet for high blood pressure., A high-sugar diet., "A food-free diet., A non-vegetarian diet."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low-sodium diet for high blood pressure.
    })
  },
  {
    id: G6-HS-AN-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Nutritional Needs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Children in their growth years require extra nutrients for proper development. Which nutrients are particularly important for growing children?,
      options: [Calcium, iron, and protein for bone growth and muscle development., Only fat., Only sugar.", "Only carbohydrates.].sort(() => Math.random() - 0.5),
      correctAnswer: Calcium, iron, and protein for bone growth and muscle development."
    })
  },
  {
    id: "G6-HS-AN-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Nutritional Needs,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Pregnant and breastfeeding mothers have increased nutritional requirements. Which nutrients are especially important during pregnancy?,
      options: [Folic acid, iron, calcium, and protein., Only carbohydrates., "Only fats., Only sugar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Folic acid, iron, calcium, and protein.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G6-HS-FP-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Boiling",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Boiling is a common cooking method that uses water or liquid to cook food. What is a disadvantage of boiling vegetables for too long?,
      options: [It can destroy heat-sensitive vitamins like Vitamin C., It makes them too hard., It makes them too sweet.", "It adds too much oil.].sort(() => Math.random() - 0.5),
      correctAnswer: It can destroy heat-sensitive vitamins like Vitamin C."
    })
  },
  {
    id: "G6-HS-FP-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Methods - Frying,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Frying involves cooking food in hot oil or fat. What is a health concern associated with deep frying foods?,
      options: [The food absorbs a lot of fat, increasing calorie content., It makes food dry., "It removes all nutrients., It takes too long."].sort(() => Math.random() - 0.5),
      correctAnswer: "The food absorbs a lot of fat, increasing calorie content.
    })
  },
  {
    id: G6-HS-FP-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Methods - Roasting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Roasting is a dry-heat cooking method that is often used for meat and vegetables. What is a benefit of roasting food?,
      options: [It enhances the natural flavor without adding extra fat., It preserves all nutrients., It is the fastest method.", "It requires no preparation.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances the natural flavor without adding extra fat."
    })
  },
  {
    id: "G6-HS-FP-04",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Food safety involves proper handling, cooking, and storage of food to prevent foodborne illness. What is the recommended internal temperature for cooking poultry to ensure it is safe to eat?,
      options: ["74°C (165°F), 50°C", "100°C, 25°C"].sort(() => Math.random() - 0.5),
      correctAnswer: "74°C (165°F)
    })
  },

  // --- KITCHEN MANAGEMENT (3 Materials) ---
  {
    id: G6-HS-KM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Organizing the Kitchen",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " An organized kitchen makes cooking easier and more efficient. What is the principle of organizing kitchen items based on frequency of use?,
      options: [Store frequently used items at eye level and within easy reach., Store everything randomly., Keep all items in cupboards.", "Store items on the floor.].sort(() => Math.random() - 0.5),
      correctAnswer: Store frequently used items at eye level and within easy reach."
    })
  },
  {
    id: "G6-HS-KM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Kitchen Management",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper food storage prevents spoilage and reduces waste. How should perishable foods like meat and dairy be stored?,
      options: [In the refrigerator at temperatures below 5°C (41°F)., On the kitchen counter., "In a cupboard., In direct sunlight."].sort(() => Math.random() - 0.5),
      correctAnswer: "In the refrigerator at temperatures below 5°C (41°F).
    })
  },
  {
    id: G6-HS-KM-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Kitchen Management,
    subtopic: "Food Storage",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Dry goods like grains, cereals, and legumes should be stored properly to prevent infestation. What is the best way to store dry goods?,
      options: [Store in airtight containers in a cool, dry place., Store in paper bags., Store in the refrigerator.", "Store in sunlight.].sort(() => Math.random() - 0.5),
      correctAnswer: Store in airtight containers in a cool, dry place."
    })
  },

  // --- NEEDLEWORK (3 Materials) ---
  {
    id: "G6-HS-NW-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Decorative stitches can add beauty and personal touch to garments and crafts. Which of the following is a decorative stitch used in embroidery?,
      options: [The chain stitch, The running stitch, "The tacking stitch, The stay stitch"].sort(() => Math.random() - 0.5),
      correctAnswer: "The chain stitch
    })
  },
  {
    id: G6-HS-NW-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Needlework,
    subtopic: "Repairing Clothes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Repairing clothes saves money and reduces waste. What stitch would you use to repair a seam that has come undone?,
      options: [The backstitch, The running stitch, The blanket stitch", "The chain stitch].sort(() => Math.random() - 0.5),
      correctAnswer: The backstitch"
    })
  },
  {
    id: "G6-HS-NW-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Needlework",
    subtopic: "Decorative Stitches,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The blanket stitch is a decorative and functional stitch used for edges. Where is the blanket stitch commonly used?,
      options: [On blankets, tablecloths, and fabric edges to prevent fraying., For sewing buttons., "For hemming curtains., For attaching zippers."].sort(() => Math.random() - 0.5),
      correctAnswer: "On blankets, tablecloths, and fabric edges to prevent fraying.
    })
  },

  // --- HOME DECORATION (3 Materials) ---
  {
    id: G6-HS-HD-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Arranging Rooms",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Proper room arrangement creates a comfortable and functional living space. What principle should guide the arrangement of furniture in a living room?,
      options: [Create conversation areas and maintain easy traffic flow., Push all furniture against the walls., Fill every space with furniture.", "Place furniture randomly.].sort(() => Math.random() - 0.5),
      correctAnswer: Create conversation areas and maintain easy traffic flow."
    })
  },
  {
    id: "G6-HS-HD-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Home Decoration",
    subtopic: "Color Coordination,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Color coordination creates harmony and mood in a room. What colors create a calm and relaxing atmosphere?,
      options: [Cool colors like blue, green, and soft neutrals., Bright red and orange., "Neon colors., Dark brown and black."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cool colors like blue, green, and soft neutrals.
    })
  },
  {
    id: G6-HS-HD-03",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Home Decoration,
    subtopic: "Color Coordination",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Warm colors like red, orange, and yellow create a lively and energetic atmosphere. In which room would warm colors be most appropriate?,
      options: [In the living room or dining room to create a welcoming feel., In the bedroom to promote rest., In the study to aid concentration.", "In the bathroom.].sort(() => Math.random() - 0.5),
      correctAnswer: In the living room or dining room to create a welcoming feel."
    })
  },

  // --- FIRST AID (3 Materials) ---
  {
    id: "G6-HS-FA-01",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Cuts,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Cuts and wounds can become infected if not treated properly. What is the correct procedure for treating a minor cut?,
      options: [Clean with soap and water, apply an antiseptic, and cover with a clean bandage., Ignore it., "Apply butter., Rub with dirt."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean with soap and water, apply an antiseptic, and cover with a clean bandage.
    })
  },
  {
    id: G6-HS-FA-02",
    grade: "Grade 6,
    subject: Home Science",
    topic: "First Aid,
    subtopic: "Treating Burns",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Burns can be painful and cause serious damage to the skin. What should you do immediately after a minor burn?,
      options: [Place the burn under cool running water for several minutes., Apply ice directly to the burn., Apply oil or butter.", "Pop any blisters.].sort(() => Math.random() - 0.5),
      correctAnswer: Place the burn under cool running water for several minutes."
    })
  },
  {
    id: "G6-HS-FA-03",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Treating Minor Injuries,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sprains and strains are common injuries that can occur at home or during physical activity. What is the RICE method for treating sprains?,
      options: [Rest, Ice, Compression, Elevation, Run, Ice, Compression, Exercise, "Rest, Ice, Cool, Exercise, Raise, Ice, Compress, Elevate"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rest, Ice, Compression, Elevation
    })
  },

  // --- FINANCIAL MANAGEMENT (2 Materials) ---
  {
    id: G6-HS-FM-01",
    grade: "Grade 6,
    subject: Home Science",
    topic: "Financial Management,
    subtopic: "Saving",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Saving money is an important financial habit that helps achieve goals and provides security. What is the recommended percentage of income to save?,
      options: [At least 10-20% of income should be saved regularly., Save all income., Save nothing.", "Save only when there is extra.].sort(() => Math.random() - 0.5),
      correctAnswer: At least 10-20% of income should be saved regularly."
    })
  },
  {
    id: "G6-HS-FM-02",
    grade: "Grade 6",
    subject: "Home Science",
    topic: "Financial Management",
    subtopic: "Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Entrepreneurship involves creating a business to generate income. What is a simple home-based business idea that a family could start?,
      options: [Baking and selling cakes, catering services, or making crafts., Buying expensive cars., "Investing in stocks without research., Borrowing money without a plan."].sort(() => Math.random() - 0.5),
      correctAnswer: "Baking and selling cakes, catering services, or making crafts.
    })
  },

  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL DEVELOPMENT (4 Materials) ---
  {
    id: G7-HS-PD-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Personal grooming reflects self-respect and creates a positive impression. What is the importance of proper grooming in daily life?,
      options: [It enhances self-confidence and shows respect for oneself and others., It is only for formal occasions., It is unnecessary.", "It takes too much time.].sort(() => Math.random() - 0.5),
      correctAnswer: It enhances self-confidence and shows respect for oneself and others."
    })
  },
  {
    id: "G7-HS-PD-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Posture,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Good posture is important for health and appearance. What are the benefits of maintaining good posture?,
      options: [Prevents back pain, improves breathing, and creates a confident appearance., Causes back pain., "Has no effect., Is only important for athletes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Prevents back pain, improves breathing, and creates a confident appearance.
    })
  },
  {
    id: G7-HS-PD-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Personal hygiene is essential for maintaining health and preventing disease. Why is it important to wash hands frequently?,
      options: [To prevent the spread of germs and reduce the risk of infectious diseases., To keep hands soft., To avoid using gloves.", "To save water.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent the spread of germs and reduce the risk of infectious diseases."
    })
  },
  {
    id: "G7-HS-PD-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Choosing appropriate clothing for different occasions is part of good grooming. What should you consider when selecting clothes for different occasions?,
      options: [Dress code, weather, comfort, and cultural appropriateness., Only the latest fashion., "Only bright colors., Only expensive brands."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dress code, weather, comfort, and cultural appropriateness.
    })
  },

  // --- HOME CARE (4 Materials) ---
  {
    id: G7-HS-HC-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Cleaning Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different cleaning methods are suitable for different surfaces and materials. What cleaning method is appropriate for cleaning tile floors?,
      options: [Mop with warm water and a suitable floor cleaner., Scrub with a wire brush., Use dry sweeping only.", "Use bleach without water.].sort(() => Math.random() - 0.5),
      correctAnswer: Mop with warm water and a suitable floor cleaner."
    })
  },
  {
    id: "G7-HS-HC-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Carpets and rugs require special care to maintain their appearance and hygiene. How should carpets be cleaned regularly?,
      options: [Vacuum regularly and have them professionally cleaned periodically., Wash with a hose., "Scrub with a brush., Use bleach."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vacuum regularly and have them professionally cleaned periodically.
    })
  },
  {
    id: G7-HS-HC-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Care,
    subtopic: "Disinfectants",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Disinfectants are chemicals used to kill germs and bacteria on surfaces. What is the difference between a cleaner and a disinfectant?,
      options: [Cleaners remove dirt, while disinfectants kill germs and bacteria., They are the same thing., Cleaners are stronger.", "Disinfectants are not safe to use.].sort(() => Math.random() - 0.5),
      correctAnswer: Cleaners remove dirt, while disinfectants kill germs and bacteria."
    })
  },
  {
    id: "G7-HS-HC-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Care",
    subtopic: "Cleaning Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Natural cleaning agents like vinegar, lemon, and baking soda are effective and eco-friendly. What can vinegar be used for in household cleaning?,
      options: ["Removing limescale, glass cleaning, and deodorizing., Polishing wood.", "Cleaning carpets., Washing clothes."].sort(() => Math.random() - 0.5),
      correctAnswer: "Removing limescale, glass cleaning, and deodorizing.
    })
  },

  // --- LAUNDRY AND TEXTILE CARE (4 Materials) ---
  {
    id: G7-HS-LT-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Fabric Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Different fabrics require different care methods. Which of the following is a natural fiber commonly used in clothing?,
      options: [Cotton, Polyester, Nylon", "Spandex].sort(() => Math.random() - 0.5),
      correctAnswer: Cotton"
    })
  },
  {
    id: "G7-HS-LT-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Fabric Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Synthetic fabrics like polyester and nylon are made from petroleum-based materials. What is an advantage of synthetic fabrics over natural fibers?,
      options: [They are often more durable and wrinkle-resistant., They breathe better., "They are more absorbent., They are all biodegradable."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are often more durable and wrinkle-resistant.
    })
  },
  {
    id: G7-HS-LT-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Laundry and Textile Care,
    subtopic: "Laundry Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different laundry agents are used for different purposes in washing. What is the function of fabric softener in laundry?,
      options: [Softens fabrics and reduces static electricity., Removes stains., Whitens clothes.", "Kills germs.].sort(() => Math.random() - 0.5),
      correctAnswer: Softens fabrics and reduces static electricity."
    })
  },
  {
    id: "G7-HS-LT-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Laundry and Textile Care",
    subtopic: "Laundry Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bleach is a strong chemical agent used in laundry for whitening and disinfecting. What is the proper way to use bleach?,
      options: [Dilute as directed and use only on white fabrics, avoiding colored clothes., Use on all fabrics., "Pour directly on clothes., Mix with vinegar."].sort(() => Math.random() - 0.5),
      correctAnswer: "Dilute as directed and use only on white fabrics, avoiding colored clothes.
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: G7-HS-FN-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Macronutrients are nutrients required in large amounts by the body. Which of the following are the three main macronutrients?,
      options: [Carbohydrates, proteins, and fats., Vitamins, minerals, and water., Carbohydrates, vitamins, and minerals.", "Proteins, minerals, and fats.].sort(() => Math.random() - 0.5),
      correctAnswer: Carbohydrates, proteins, and fats."
    })
  },
  {
    id: "G7-HS-FN-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Micronutrients are essential nutrients required in small amounts. What is the difference between vitamins and minerals?,
      options: [Vitamins are organic compounds, while minerals are inorganic elements., Vitamins are inorganic, minerals are organic., "They are the same., Vitamins are only found in meat."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins are organic compounds, while minerals are inorganic elements.
    })
  },
  {
    id: G7-HS-FN-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Macronutrients",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proteins are essential for building and repairing body tissues. What is a complete protein source that contains all essential amino acids?,
      options: [Animal products like meat, eggs, and dairy., Beans and lentils., Grains.", "Vegetables.].sort(() => Math.random() - 0.5),
      correctAnswer: Animal products like meat, eggs, and dairy."
    })
  },
  {
    id: "G7-HS-FN-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Micronutrients,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Iron is an important mineral that plays a key role in oxygen transport in the blood. What is a common sign of iron deficiency?,
      options: [Fatigue, weakness, and pale skin., High energy levels., "Weight gain., Good eyesight."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fatigue, weakness, and pale skin.
    })
  },

  // --- FOOD PREPARATION (4 Materials) ---
  {
    id: G7-HS-FP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Meat",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Meat must be cooked thoroughly to kill harmful bacteria and ensure safety. What is the recommended cooking method for tough cuts of meat?,
      options: [Slow cooking with moisture, like stewing or braising., Quick frying., Grilling for a short time.", "Microwaving.].sort(() => Math.random() - 0.5),
      correctAnswer: Slow cooking with moisture, like stewing or braising."
    })
  },
  {
    id: "G7-HS-FP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Cooking Fish,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fish is a nutritious food that is quick and easy to cook. What cooking method preserves the delicate texture of fish?,
      options: [Steaming or grilling gently., Deep frying., "Boiling for hours., Pressure cooking."].sort(() => Math.random() - 0.5),
      correctAnswer: "Steaming or grilling gently.
    })
  },
  {
    id: G7-HS-FP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Food Preparation,
    subtopic: "Cooking Poultry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Chicken is a commonly consumed poultry meat that requires proper handling and cooking. What is the safe internal temperature for cooked chicken?,
      options: [74°C (165°F), 60°C, 80°C", "50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 74°C (165°F)"
    })
  },
  {
    id: "G7-HS-FP-04",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Food Preparation",
    subtopic: "Food Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Cross-contamination is a major cause of foodborne illness. How can cross-contamination be prevented in the kitchen?,
      options: [Use separate cutting boards and utensils for raw meat and ready-to-eat foods., Use the same board for everything., "Wash hands only after cooking., Store raw meat above cooked food."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use separate cutting boards and utensils for raw meat and ready-to-eat foods.
    })
  },

  // --- BEVERAGE PREPARATION (3 Materials) ---
  {
    id: G7-HS-BP-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Traditional drinks are an important part of Kenyan culture. What is a traditional Kenyan drink made from fermented dairy?,
      options: [Maziwa lala (fermented milk), Coffee, Tea", "Juice].sort(() => Math.random() - 0.5),
      correctAnswer: Maziwa lala (fermented milk)"
    })
  },
  {
    id: "G7-HS-BP-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Beverage Preparation",
    subtopic: "Modern Drinks,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Smoothies are popular modern drinks that can be made with various fruits and liquids. What is a healthy ingredient that can be added to smoothies for extra nutrition?,
      options: [Oats, chia seeds, or spirulina., Sugar., "Ice cream., Soda."].sort(() => Math.random() - 0.5),
      correctAnswer: "Oats, chia seeds, or spirulina.
    })
  },
  {
    id: G7-HS-BP-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Beverage Preparation,
    subtopic: "Traditional Drinks",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fruit and vegetable juices can be combined to create nutritious beverages. Which combination of fruits and vegetables creates a nutrient-rich juice?,
      options: [Carrot, ginger, and orange., Soda and syrup., Coffee and cream.", "Tea and sugar.].sort(() => Math.random() - 0.5),
      correctAnswer: Carrot, ginger, and orange."
    })
  },

  // --- SEWING TECHNIQUES (3 Materials) ---
  {
    id: "G7-HS-ST-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Darts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Darts are used in garment construction to shape fabric to the body. Where are darts commonly placed in garments?,
      options: [At the bust, waist, and shoulder to create shape and fit., On the hem., "At the collar., On the cuffs."].sort(() => Math.random() - 0.5),
      correctAnswer: "At the bust, waist, and shoulder to create shape and fit.
    })
  },
  {
    id: G7-HS-ST-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Sewing Techniques,
    subtopic: "Gathers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Gathers are used to create fullness in garments and add decorative detail. What is the technique used to create gathers in fabric?,
      options: [Use a long running stitch and pull the thread to gather the fabric., Use a backstitch., Use a buttonhole stitch.", "Use a zigzag stitch.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a long running stitch and pull the thread to gather the fabric."
    })
  },
  {
    id: "G7-HS-ST-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Sewing Techniques",
    subtopic: "Seams,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Seams are the lines of stitching that join pieces of fabric together. What is the purpose of finishing a seam?,
      options: [To prevent the fabric from fraying and give a professional finish., To make the seam stronger., "To add color., To make the garment heavier."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent the fabric from fraying and give a professional finish.
    })
  },

  // --- HOME ENVIRONMENT (3 Materials) ---
  {
    id: G7-HS-HE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Ventilation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Good ventilation is important for maintaining a healthy indoor environment. Why is proper ventilation important in the home?,
      options: [To remove stale air, control humidity, and reduce the spread of airborne diseases., To keep the house cold., To save energy.", "To block outside air.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove stale air, control humidity, and reduce the spread of airborne diseases."
    })
  },
  {
    id: "G7-HS-HE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Home Environment",
    subtopic: "Lighting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper lighting in the home is important for safety and comfort. What are the three types of lighting used in interior design?,
      options: [Ambient, task, and accent lighting., Natural, artificial, and candle., "Indoor, outdoor, and emergency., Direct, indirect, and reflected."].sort(() => Math.random() - 0.5),
      correctAnswer: "Ambient, task, and accent lighting.
    })
  },
  {
    id: G7-HS-HE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Home Environment,
    subtopic: "Furniture Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Regular furniture care extends its lifespan and maintains its appearance. What is the correct way to care for upholstered furniture?,
      options: [Vacuum regularly, rotate cushions, and treat stains immediately., Use water on all fabrics., Scrub harshly.", "Ignore spills.].sort(() => Math.random() - 0.5),
      correctAnswer: Vacuum regularly, rotate cushions, and treat stains immediately."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G7-HS-HS-01",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kitchen safety is essential to prevent accidents and injuries. What safety measure should be taken when using sharp knives?,
      options: [Cut away from the body and keep knives sharp for better control., Use dull knives., "Cut toward the body., Leave knives in the sink."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cut away from the body and keep knives sharp for better control.
    })
  },
  {
    id: G7-HS-HS-02",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Food Poisoning Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Food poisoning is caused by consuming contaminated food. What is the recommended temperature range for refrigerating perishable foods?,
      options: [0-5°C (32-41°F), 10-20°C, 25-30°C", "40-50°C].sort(() => Math.random() - 0.5),
      correctAnswer: 0-5°C (32-41°F)"
    })
  },
  {
    id: "G7-HS-HS-03",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Kitchen Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Accidents in the kitchen can be caused by burns from hot liquids and surfaces. What should you do if you spill hot liquid on yourself?,
      options: [Quickly remove the clothing from the area and run cool water over the burn., Ignore it., "Apply heat., Put butter on it."].sort(() => Math.random() - 0.5),
      correctAnswer: "Quickly remove the clothing from the area and run cool water over the burn.
    })
  },

  // --- CONSUMER EDUCATION (3 Materials) ---
  {
    id: G7-HS-CE-01",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Wise Buying",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Wise buying involves making informed purchasing decisions. What should a consumer check when comparing products before buying?,
      options: [Quality, price, quantity, and expiry date., Only the price., Only the brand.", "Only the color.].sort(() => Math.random() - 0.5),
      correctAnswer: Quality, price, quantity, and expiry date."
    })
  },
  {
    id: "G7-HS-CE-02",
    grade: "Grade 7",
    subject: "Home Science",
    topic: "Consumer Education",
    subtopic: "Wise Buying,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Understanding food labels helps consumers make informed choices about the food they buy. What information is required on a food label?,
      options: [List of ingredients, expiry date, and nutritional information., Only the price., "Only the brand name., Only the weight."].sort(() => Math.random() - 0.5),
      correctAnswer: "List of ingredients, expiry date, and nutritional information.
    })
  },
  {
    id: G7-HS-CE-03",
    grade: "Grade 7,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Advertising",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Advertising influences consumer choices and can sometimes be misleading. What should a savvy consumer do when evaluating advertisements?,
      options: [Compare information from different sources and avoid impulse buying., Believe every advertisement., Buy immediately.", "Ignore all advertising.].sort(() => Math.random() - 0.5),
      correctAnswer: Compare information from different sources and avoid impulse buying."
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HYGIENE (5 Materials) ---
  {
    id: "G8-HS-PH-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The skin is the body's largest organ and requires proper care to stay healthy. What is the recommended daily routine for maintaining healthy skin?,
      options: [Cleanse, tone, and moisturize using products suitable for your skin type., Wash with soap only., "Apply makeup daily., Never use sunscreen."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleanse, tone, and moisturize using products suitable for your skin type.
    })
  },
  {
    id: G8-HS-PH-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Hair Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different hair types require different care methods to maintain health and appearance. How should you care for natural African hair to prevent breakage?,
      options: [Keep it moisturized, avoid harsh chemicals, and use protective styles., Wash with harsh shampoo daily., Use a lot of heat.", "Comb when dry.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep it moisturized, avoid harsh chemicals, and use protective styles."
    })
  },
  {
    id: "G8-HS-PH-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Nail Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Proper nail care prevents infections and keeps nails looking neat. What tool should be used to gently push back cuticles?,
      options: [A cuticle pusher or orange stick., A knife., "A pair of scissors., Your teeth."].sort(() => Math.random() - 0.5),
      correctAnswer: "A cuticle pusher or orange stick.
    })
  },
  {
    id: G8-HS-PH-04",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Personal Hygiene,
    subtopic: "Foot Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Feet carry the weight of the body and require special care to prevent problems. What is the best practice for maintaining healthy feet?,
      options: [Wash feet daily, dry thoroughly between toes, and wear comfortable shoes., Wear tight shoes., Ignore foot odor.", "Never wash feet.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash feet daily, dry thoroughly between toes, and wear comfortable shoes."
    })
  },
  {
    id: "G8-HS-PH-05",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Acne is a common skin condition that affects many adolescents. What is an effective way to manage acne?,
      options: [Wash face gently twice daily with a mild cleanser and use appropriate acne treatments., Pop pimples., "Use harsh scrubs., Never wash the face."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wash face gently twice daily with a mild cleanser and use appropriate acne treatments.
    })
  },

  // --- HOUSEHOLD HYGIENE (4 Materials) ---
  {
    id: G8-HS-HH-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Household Hygiene,
    subtopic: "Cleaning Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Different cleaning agents have specific uses and safety requirements. What is the appropriate cleaning agent for removing soap scum in the bathroom?,
      options: [A bathroom cleaner with mild acid or vinegar solution., Bleach., Dish soap.", "Furniture polish.].sort(() => Math.random() - 0.5),
      correctAnswer: A bathroom cleaner with mild acid or vinegar solution."
    })
  },
  {
    id: "G8-HS-HH-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Household Hygiene",
    subtopic: "Cleaning Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sanitization reduces the number of germs on surfaces to a safe level. What is the difference between cleaning, sanitizing, and disinfecting?,
      options: ["Cleaning removes dirt, sanitizing reduces germs, and disinfecting kills germs., They are all the same.", "Disinfecting is the only important one., Sanitizing is for floors only."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning removes dirt, sanitizing reduces germs, and disinfecting kills germs.
    })
  },
  {
    id: G8-HS-HH-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Household Hygiene,
    subtopic: "Sanitation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Good sanitation practices in the home prevent the spread of diseases. Which area of the home is most critical to keep sanitary?,
      options: [The kitchen and bathroom where germs are most likely to spread., The bedroom., The living room.", "The garage.].sort(() => Math.random() - 0.5),
      correctAnswer: The kitchen and bathroom where germs are most likely to spread."
    })
  },
  {
    id: "G8-HS-HH-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Household Hygiene",
    subtopic: "Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ventilation helps remove indoor air pollutants and moisture that can lead to mold growth. Why is proper ventilation important in the bathroom?,
      options: [To reduce humidity and prevent mold and mildew growth., To make it colder., "To save water., To allow insects to enter."].sort(() => Math.random() - 0.5),
      correctAnswer: "To reduce humidity and prevent mold and mildew growth.
    })
  },

  // --- CLOTHING CONSTRUCTION (4 Materials) ---
  {
    id: G8-HS-CC-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Clothing Construction,
    subtopic: "Pattern Drafting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pattern drafting is the process of creating a blueprint for a garment. What is the first step in pattern drafting?,
      options: [Taking accurate body measurements., Cutting fabric., Drawing the design.", "Sewing the seams.].sort(() => Math.random() - 0.5),
      correctAnswer: Taking accurate body measurements."
    })
  },
  {
    id: "G8-HS-CC-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Clothing Construction",
    subtopic: "Cutting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper cutting ensures that the fabric pieces fit together correctly. What should you do before cutting fabric with a pattern?,
      options: [Press the fabric and the pattern, and pin the pattern securely., Cut immediately., "Fold the fabric randomly., Use dull scissors."].sort(() => Math.random() - 0.5),
      correctAnswer: "Press the fabric and the pattern, and pin the pattern securely.
    })
  },
  {
    id: G8-HS-CC-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Clothing Construction,
    subtopic: "Sewing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sewing machine stitches come in various types for different purposes. What type of stitch is used for seam construction on a sewing machine?,
      options: [A straight stitch or a lockstitch., A zigzag stitch., A buttonhole stitch.", "A stretch stitch.].sort(() => Math.random() - 0.5),
      correctAnswer: A straight stitch or a lockstitch."
    })
  },
  {
    id: "G8-HS-CC-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Clothing Construction",
    subtopic: "Sewing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Seam finishing prevents fraying and gives garments a professional look. Which seam finish is suitable for lightweight fabrics?,
      options: [A French seam or overlock stitch., A flat-felled seam., "A bound seam., A hand-stitched seam."].sort(() => Math.random() - 0.5),
      correctAnswer: "A French seam or overlock stitch.
    })
  },

  // --- NUTRITION (4 Materials) ---
  {
    id: G8-HS-NU-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Nutritional Deficiencies",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Nutritional deficiencies occur when the body does not get enough of certain nutrients. What condition is caused by a deficiency of Vitamin C?,
      options: [Scurvy, Rickets, Anemia", "Osteoporosis].sort(() => Math.random() - 0.5),
      correctAnswer: Scurvy"
    })
  },
  {
    id: "G8-HS-NU-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Nutritional Deficiencies,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Iron deficiency is a common nutritional problem worldwide. What are the symptoms of iron deficiency anemia?,
      options: [Fatigue, pale skin, shortness of breath, and dizziness., Excessive energy., "Weight loss., Good eyesight."].sort(() => Math.random() - 0.5),
      correctAnswer: "Fatigue, pale skin, shortness of breath, and dizziness.
    })
  },
  {
    id: G8-HS-NU-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Nutrition,
    subtopic: "Balanced Meals",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A balanced meal should provide a variety of nutrients to support overall health. What is the recommended proportion of a plate that should be filled with vegetables?,
      options: [About half the plate., One quarter., One eighth.", "The entire plate.].sort(() => Math.random() - 0.5),
      correctAnswer: About half the plate."
    })
  },
  {
    id: "G8-HS-NU-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Nutrition",
    subtopic: "Balanced Meals,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Water is an essential nutrient that is often overlooked. Why is adequate water intake important for the body?,
      options: [It regulates body temperature, transports nutrients, and removes waste., It is not important., "It only helps with thirst., It causes weight gain."].sort(() => Math.random() - 0.5),
      correctAnswer: "It regulates body temperature, transports nutrients, and removes waste.
    })
  },

  // --- FOOD PRESERVATION (4 Materials) ---
  {
    id: G8-HS-FP-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Food Preservation,
    subtopic: "Drying",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Drying is one of the oldest methods of food preservation. What is the principle behind drying as a preservation method?,
      options: [Removing moisture prevents the growth of microorganisms., Adding heat kills bacteria., Adding salt preserves food.", "Freezing stops spoilage.].sort(() => Math.random() - 0.5),
      correctAnswer: Removing moisture prevents the growth of microorganisms."
    })
  },
  {
    id: "G8-HS-FP-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Food Preservation",
    subtopic: "Canning,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Canning involves sealing food in jars and heating them to kill microorganisms. What is the purpose of the vacuum seal created in canning?,
      options: [To prevent air and microorganisms from entering the jar., To make the food taste better., "To change the color of the food., To add nutrients."].sort(() => Math.random() - 0.5),
      correctAnswer: "To prevent air and microorganisms from entering the jar.
    })
  },
  {
    id: G8-HS-FP-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Food Preservation,
    subtopic: "Refrigeration",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refrigeration slows down the growth of microorganisms that cause food spoilage. What is the recommended temperature for a refrigerator?,
      options: [Below 4°C (40°F), Above 20°C, 15°C", "Room temperature].sort(() => Math.random() - 0.5),
      correctAnswer: Below 4°C (40°F)"
    })
  },
  {
    id: "G8-HS-FP-04",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Food Preservation",
    subtopic: "Food Preservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Freezing is a convenient method of food preservation that preserves nutrients well. What is a disadvantage of freezing food?,
      options: [It can change the texture of some foods due to ice crystal formation., It destroys all nutrients., "It takes too long., It requires no energy."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can change the texture of some foods due to ice crystal formation.
    })
  },

  // --- TABLE MANNERS (3 Materials) ---
  {
    id: G8-HS-TM-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Table Manners,
    subtopic: "Setting the Table",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proper table setting enhances the dining experience and shows respect for guests. What is the correct placement of a fork in a formal table setting?,
      options: [To the left of the dinner plate., To the right of the dinner plate., Above the dinner plate.", "On the dinner plate.].sort(() => Math.random() - 0.5),
      correctAnswer: To the left of the dinner plate."
    })
  },
  {
    id: "G8-HS-TM-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Table Manners",
    subtopic: "Dining Etiquette,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Dining etiquette involves a set of rules for polite behavior while eating. What should you do if you need to leave the table during a meal?,
      options: [Excuse yourself and place your napkin on your chair or to the left of your plate., Leave without saying anything., "Take your plate with you., Yell across the table."].sort(() => Math.random() - 0.5),
      correctAnswer: "Excuse yourself and place your napkin on your chair or to the left of your plate.
    })
  },
  {
    id: G8-HS-TM-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Table Manners,
    subtopic: "Dining Etiquette",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Dining etiquette varies across cultures. What is considered proper behavior when eating in a Kenyan cultural setting?,
      options: [Wash hands before eating, eat with right hand if using hands, and wait for elders., Eat with left hand., Start eating before others are served.", "Talk loudly while eating.].sort(() => Math.random() - 0.5),
      correctAnswer: Wash hands before eating, eat with right hand if using hands, and wait for elders."
    })
  },

  // --- SEWING PROJECTS (3 Materials) ---
  {
    id: "G8-HS-SP-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Sewing Projects",
    subtopic: "Making an Apron,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "An apron is a practical and simple sewing project for beginners. What is the main purpose of an apron?,
      options: [To protect clothing from stains and dirt while working or cooking., To keep warm., "To make a fashion statement., To carry tools."].sort(() => Math.random() - 0.5),
      correctAnswer: "To protect clothing from stains and dirt while working or cooking.
    })
  },
  {
    id: G8-HS-SP-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Sewing Projects,
    subtopic: "Making a Bag",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A simple tote bag is a useful sewing project that can be customized in many ways. What is a common material used for making a sturdy tote bag?,
      options: [Canvas or cotton fabric., Silk., Lace.", "Paper.].sort(() => Math.random() - 0.5),
      correctAnswer: Canvas or cotton fabric."
    })
  },
  {
    id: "G8-HS-SP-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Sewing Projects",
    subtopic: "Simple Sewing Projects,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pillow covers are another simple sewing project that can enhance home decor. What is the easiest closure method for a pillow cover?,
      options: [An envelope closure where the back flaps overlap., A zipper., "Buttons., Snaps."].sort(() => Math.random() - 0.5),
      correctAnswer: "An envelope closure where the back flaps overlap.
    })
  },

  // --- HOME MAINTENANCE (3 Materials) ---
  {
    id: G8-HS-HM-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Maintenance,
    subtopic: "Simple Repairs",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Simple home repairs can save money and keep the home in good condition. What tool is commonly used to fix a leaking tap?,
      options: [A wrench and replacement washers., A hammer., A screwdriver.", "A saw.].sort(() => Math.random() - 0.5),
      correctAnswer: A wrench and replacement washers."
    })
  },
  {
    id: "G8-HS-HM-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Home Maintenance",
    subtopic: "Home Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular home maintenance prevents accidents and protects property value. What is an important safety check that should be done on electrical appliances?,
      options: [Check for frayed wires and have appliances serviced regularly., Ignore small issues., "Use appliances with damaged cords., Keep appliances in wet areas."].sort(() => Math.random() - 0.5),
      correctAnswer: "Check for frayed wires and have appliances serviced regularly.
    })
  },
  {
    id: G8-HS-HM-03",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Maintenance,
    subtopic: "Simple Repairs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A clogged sink or drain is a common household problem. What is a safe method to unclog a sink before using chemical products?,
      options: [Use a plunger or a plumber's snake., Pour boiling water and baking soda., Ignore the clog.", "Use a knife to scrape.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a plunger or a plumber's snake."
    })
  },

  // --- FIRST AID (3 Materials) ---
  {
    id: "G8-HS-FA-01",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Emergency Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Knowing emergency care procedures can save lives in critical situations. What is the first step in providing emergency care to an unconscious person?,
      options: [Check responsiveness and call for emergency help if there is no response., Perform CPR immediately., "Move the person., Give water."].sort(() => Math.random() - 0.5),
      correctAnswer: "Check responsiveness and call for emergency help if there is no response.
    })
  },
  {
    id: G8-HS-FA-02",
    grade: "Grade 8,
    subject: Home Science",
    topic: "First Aid,
    subtopic: "CPR Basics",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " CPR (Cardiopulmonary Resuscitation) is a life-saving technique used in emergencies. What is the compression to ventilation ratio for adult CPR?,
      options: [30 compressions to 2 breaths., 5 compressions to 1 breath., 15 compressions to 2 breaths.", "10 compressions to 1 breath.].sort(() => Math.random() - 0.5),
      correctAnswer: 30 compressions to 2 breaths."
    })
  },
  {
    id: "G8-HS-FA-03",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "First Aid",
    subtopic: "Emergency Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Choking can be life-threatening and requires immediate action. What is the Heimlich maneuver used for?,
      options: [To dislodge an object from a choking person's airway., To treat burns., "To stop bleeding., To perform CPR."].sort(() => Math.random() - 0.5),
      correctAnswer: "To dislodge an object from a choking person's airway.
    })
  },

  // --- HOME ECONOMICS (2 Materials) ---
  {
    id: G8-HS-HE-01",
    grade: "Grade 8,
    subject: Home Science",
    topic: "Home Economics,
    subtopic: "Budgeting",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A family budget helps plan spending and saving for financial stability. What is the difference between fixed and variable expenses in a budget?,
      options: [Fixed expenses stay the same, while variable expenses change from month to month., Fixed expenses change, variable expenses stay the same., They are the same.", "Fixed expenses are only for food.].sort(() => Math.random() - 0.5),
      correctAnswer: Fixed expenses stay the same, while variable expenses change from month to month."
    })
  },
  {
    id: "G8-HS-HE-02",
    grade: "Grade 8",
    subject: "Home Science",
    topic: "Home Economics",
    subtopic: "Record Keeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Record keeping helps families track their financial activities and plan for the future. What is the purpose of keeping a household spending diary?,
      options: [To track all expenses and identify areas where money can be saved., To show off to others., "To increase spending., To hide money."].sort(() => Math.random() - 0.5),
      correctAnswer: "To track all expenses and identify areas where money can be saved.
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL DEVELOPMENT (4 Materials) ---
  {
    id: G9-HS-PD-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Self-Esteem",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Self-esteem affects how individuals perceive themselves and interact with others. What is a healthy way to build and maintain self-esteem?,
      options: [Practice positive self-talk, set realistic goals, and accept personal strengths and weaknesses., Compare yourself to others constantly., Criticize yourself harshly.", "Ignore personal achievements.].sort(() => Math.random() - 0.5),
      correctAnswer: Practice positive self-talk, set realistic goals, and accept personal strengths and weaknesses."
    })
  },
  {
    id: "G9-HS-PD-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Grooming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Professional grooming is important in the workplace and contributes to career success. What is the recommended dress code for a professional environment?,
      options: [Clean, well-fitting clothes that are appropriate for the workplace culture., Casual clothes only., "Extravagant fashion., The same clothes worn every day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clean, well-fitting clothes that are appropriate for the workplace culture.
    })
  },
  {
    id: G9-HS-PD-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Personal Development,
    subtopic: "Social Skills",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Social skills are essential for building and maintaining relationships. What is an important social skill that helps in communication?,
      options: [Active listening and showing empathy., Talking constantly., Interrupting others.", "Ignoring others' feelings.].sort(() => Math.random() - 0.5),
      correctAnswer: Active listening and showing empathy."
    })
  },
  {
    id: "G9-HS-PD-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Personal Development",
    subtopic: "Self-Esteem,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Positive body image is an important part of self-esteem. What is a healthy way to develop a positive body image?,
      options: [Appreciate your body for what it can do rather than just how it looks., Compare your body to models., "Criticize your body., Never exercise."].sort(() => Math.random() - 0.5),
      correctAnswer: "Appreciate your body for what it can do rather than just how it looks.
    })
  },

  // --- HOME MANAGEMENT (4 Materials) ---
  {
    id: G9-HS-HM-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Cleaning Schedules",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A cleaning schedule helps maintain a clean and organized home without feeling overwhelmed. What is the recommended frequency for deep cleaning the kitchen?,
      options: [Weekly or bi-weekly, depending on use., Every year., Once a month.", "Never.].sort(() => Math.random() - 0.5),
      correctAnswer: Weekly or bi-weekly, depending on use."
    })
  },
  {
    id: "G9-HS-HM-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Organization,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Decluttering is the process of removing unnecessary items to create an organized space. Why is decluttering beneficial for the home environment?,
      options: [It reduces stress, saves time, and creates a more functional living space., It fills the house with more items., "It is a waste of time., It makes cleaning harder."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reduces stress, saves time, and creates a more functional living space.
    })
  },
  {
    id: G9-HS-HM-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Management,
    subtopic: "Organization",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Time management skills are important for balancing work, home, and personal life. What is a time management technique that can help people be more productive?,
      options: [Prioritizing tasks and creating a to-do list., Doing everything at once., Procrastinating.", "Saying yes to everything.].sort(() => Math.random() - 0.5),
      correctAnswer: Prioritizing tasks and creating a to-do list."
    })
  },
  {
    id: "G9-HS-HM-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Management",
    subtopic: "Cleaning Schedules,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Seasonal cleaning involves tasks that are done less frequently, such as twice a year. Which of the following is an example of a seasonal cleaning task?,
      options: [Cleaning windows, curtains, and carpets., Daily dishwashing.", "Sweeping the floor., Taking out the trash."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning windows, curtains, and carpets.
    })
  },

  // --- TEXTILE TECHNOLOGY (4 Materials) ---
  {
    id: G9-HS-TT-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Textile Technology,
    subtopic: "Fabric Finishing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Fabric finishing processes give textiles their final properties and appearance. What is the purpose of mercerization in cotton fabric finishing?,
      options: [To add strength, luster, and dye affinity to the fabric., To make fabric shrink., To weaken the fabric.", "To change the color.].sort(() => Math.random() - 0.5),
      correctAnswer: To add strength, luster, and dye affinity to the fabric."
    })
  },
  {
    id: "G9-HS-TT-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Textile Technology",
    subtopic: "Care Labels,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Care labels on clothing provide important information about how to wash and maintain the garment. What does the symbol of a hand in a basin indicate on a care label?,
      options: [Hand wash only., Machine wash., "Dry clean only., Do not wash."].sort(() => Math.random() - 0.5),
      correctAnswer: "Hand wash only.
    })
  },
  {
    id: G9-HS-TT-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Textile Technology,
    subtopic: "Care Labels",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Drying symbols on care labels indicate how to dry a garment safely. What does a square with a circle inside mean on a care label?,
      options: [Tumble dry., Air dry., Dry flat.", "Do not dry.].sort(() => Math.random() - 0.5),
      correctAnswer: Tumble dry."
    })
  },
  {
    id: "G9-HS-TT-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Textile Technology",
    subtopic: "Fabric Finishing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Waterproof and stain-resistant finishes are common on outdoor and performance fabrics. What is the name of the chemical often used for waterproofing fabric?,
      options: [Durable Water Repellent (DWR), Bleach, "Fabric softener, Starch"].sort(() => Math.random() - 0.5),
      correctAnswer: "Durable Water Repellent (DWR)
    })
  },

  // --- FOOD SCIENCE (4 Materials) ---
  {
    id: G9-HS-FS-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Food Science,
    subtopic: "Food Preservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fermentation is a food preservation method that also changes the flavor and texture of food. What is the principle of fermentation?,
      options: [Microorganisms like bacteria or yeast break down food components., Adding heat kills bacteria., Freezing stops spoilage.", "Drying removes moisture.].sort(() => Math.random() - 0.5),
      correctAnswer: Microorganisms like bacteria or yeast break down food components."
    })
  },
  {
    id: "G9-HS-FS-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Food Science",
    subtopic: "Fermentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Uji and other Kenyan fermented foods are examples of traditional food preservation. What is the nutritional benefit of fermentation in foods?,
      options: [It can increase the availability of nutrients and improve digestion., It removes all nutrients., "It adds harmful bacteria., It reduces protein content."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can increase the availability of nutrients and improve digestion.
    })
  },
  {
    id: G9-HS-FS-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Food Science,
    subtopic: "Food Preservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sugaring is a food preservation method that uses sugar to prevent microbial growth. What is an example of food preserved using sugar?,
      options: [Jam, jelly, and fruit preserves., Canned vegetables., Dried meat.", "Fermented milk.].sort(() => Math.random() - 0.5),
      correctAnswer: Jam, jelly, and fruit preserves."
    })
  },
  {
    id: "G9-HS-FS-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Food Science",
    subtopic: "Fermentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fermented foods like yogurt and sauerkraut contain probiotics that benefit gut health. What are the health benefits of consuming fermented foods?,
      options: [They support gut health, boost immunity, and improve digestion., They cause illness., "They have no benefits., They are only for flavor."].sort(() => Math.random() - 0.5),
      correctAnswer: "They support gut health, boost immunity, and improve digestion.
    })
  },

  // --- ADVANCED FOOD PREPARATION (4 Materials) ---
  {
    id: G9-HS-AF-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Advanced Food Preparation,
    subtopic: "Baking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Baking is a dry-heat cooking method that uses an enclosed oven. What leavening agent is commonly used in baking to make baked goods rise?,
      options: [Baking powder or yeast., Salt., Sugar.", "Oil.].sort(() => Math.random() - 0.5),
      correctAnswer: Baking powder or yeast."
    })
  },
  {
    id: "G9-HS-AF-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Advanced Food Preparation",
    subtopic: "Pastry Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pastry making requires precise measurements and techniques to achieve the right texture. What is the key to making a flaky pastry?,
      options: [Keeping the fat cold and not overworking the dough., Using hot water., "Adding more flour., Baking at low heat."].sort(() => Math.random() - 0.5),
      correctAnswer: "Keeping the fat cold and not overworking the dough.
    })
  },
  {
    id: G9-HS-AF-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Advanced Food Preparation,
    subtopic: "Baking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Bread making involves kneading and rising to develop gluten. What is the purpose of kneading bread dough?,
      options: [To develop gluten and create a smooth, elastic texture., To add flavor., To make it soft.", "To dry it out.].sort(() => Math.random() - 0.5),
      correctAnswer: To develop gluten and create a smooth, elastic texture."
    })
  },
  {
    id: "G9-HS-AF-04",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Advanced Food Preparation",
    subtopic: "Pastry Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Shortcrust pastry is used for pies and tarts and has a crumbly texture. What fat is traditionally used in shortcrust pastry?,
      options: [Butter or vegetable shortening., Olive oil., "Lard only., Margarine."].sort(() => Math.random() - 0.5),
      correctAnswer: "Butter or vegetable shortening.
    })
  },

  // --- NUTRITION AND HEALTH (3 Materials) ---
  {
    id: G9-HS-NH-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Nutrition and Health,
    subtopic: "Diet-Related Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Diet-related diseases are often caused by poor eating habits and lifestyle choices. What is a common diet-related disease associated with high salt intake?,
      options: [High blood pressure (hypertension)., Anemia., Rickets.", "Scurvy.].sort(() => Math.random() - 0.5),
      correctAnswer: High blood pressure (hypertension)."
    })
  },
  {
    id: "G9-HS-NH-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Nutrition and Health",
    subtopic: "Diet-Related Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Obesity is a major health concern in Kenya and worldwide. What are the health risks associated with obesity?,
      options: [Heart disease, type 2 diabetes, and joint problems., Strong immune system., "Better eyesight., Increased energy."].sort(() => Math.random() - 0.5),
      correctAnswer: "Heart disease, type 2 diabetes, and joint problems.
    })
  },
  {
    id: G9-HS-NH-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Nutrition and Health,
    subtopic: "Healthy Eating",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Healthy eating habits can prevent many diet-related diseases. Which of the following is recommended for maintaining a healthy weight?,
      options: [Eating a balanced diet with appropriate portion sizes and regular physical activity., Skipping meals., Eating only one type of food.", "Consuming a lot of sugar.].sort(() => Math.random() - 0.5),
      correctAnswer: Eating a balanced diet with appropriate portion sizes and regular physical activity."
    })
  },

  // --- GARMENT MAKING (3 Materials) ---
  {
    id: "G9-HS-GM-01",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Garment Making",
    subtopic: "Fitting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Garment fitting ensures that clothes fit the body properly and look good. What is the purpose of making a toile or muslin mock-up before cutting the final fabric?,
      options: [To test the fit and make any adjustments before cutting the final fabric., To waste fabric., "To make a pattern., To save time."].sort(() => Math.random() - 0.5),
      correctAnswer: "To test the fit and make any adjustments before cutting the final fabric.
    })
  },
  {
    id: G9-HS-GM-02",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Garment Making,
    subtopic: "Finishing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A well-finished garment has neat edges and a professional appearance. What is a finishing technique used to neaten the raw edges of seams?,
      options: [Overcasting, pinking, or binding the edges., Leaving them raw., Using glue.", "Taping them.].sort(() => Math.random() - 0.5),
      correctAnswer: Overcasting, pinking, or binding the edges."
    })
  },
  {
    id: "G9-HS-GM-03",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Garment Making",
    subtopic: "Embellishments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Embellishments add decorative details to garments and crafts. Which of the following is an example of an embellishment technique?,
      options: [Embroidery, beading, and appliqué., Ironing., "Washing., Folding."].sort(() => Math.random() - 0.5),
      correctAnswer: "Embroidery, beading, and appliqué.
    })
  },

  // --- INTERIOR DESIGN (3 Materials) ---
  {
    id: G9-HS-ID-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Interior Design,
    subtopic: "Color Schemes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Color schemes create harmony and visual appeal in interior spaces. What is a monochromatic color scheme?,
      options: [Using different shades and tints of a single color., Using two complementary colors., Using three colors in a triangle.", "Using primary colors.].sort(() => Math.random() - 0.5),
      correctAnswer: Using different shades and tints of a single color."
    })
  },
  {
    id: "G9-HS-ID-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Interior Design",
    subtopic: "Furniture Arrangement,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The arrangement of furniture should consider the function of the room and the flow of traffic. What is a common mistake in furniture arrangement?,
      options: [Blocking pathways and overcrowding the room., Leaving enough space., "Creating conversation areas., Using the right scale."].sort(() => Math.random() - 0.5),
      correctAnswer: "Blocking pathways and overcrowding the room.
    })
  },
  {
    id: G9-HS-ID-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Interior Design,
    subtopic: "Color Schemes",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Complementary colors are opposite each other on the color wheel and create a dynamic contrast. Which of the following is a pair of complementary colors?,
      options: [Red and green, Blue and green, Yellow and orange", "Purple and pink].sort(() => Math.random() - 0.5),
      correctAnswer: Red and green"
    })
  },

  // --- HOME SAFETY (3 Materials) ---
  {
    id: "G9-HS-HS-01",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Safety",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fire safety measures in the home can save lives and prevent property damage. What is an essential fire safety device that every home should have?,
      options: [A smoke detector and a fire extinguisher., A television., "A vacuum cleaner., A microwave."].sort(() => Math.random() - 0.5),
      correctAnswer: "A smoke detector and a fire extinguisher.
    })
  },
  {
    id: G9-HS-HS-02",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Home Safety,
    subtopic: "Electrical Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Electrical safety is important to prevent shocks and fires. What should you do if an electrical appliance feels hot or produces a burning smell?,
      options: [Turn it off immediately and have it checked by a professional., Continue using it., Cover it with a cloth.", "Pour water on it.].sort(() => Math.random() - 0.5),
      correctAnswer: Turn it off immediately and have it checked by a professional."
    })
  },
  {
    id: "G9-HS-HS-03",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Home Safety",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Creating a fire escape plan is essential for home safety. What should a fire escape plan include?,
      options: [Two ways out of every room and a meeting place outside the home., Only one way out., "No meeting place., Leaving through the window only."].sort(() => Math.random() - 0.5),
      correctAnswer: "Two ways out of every room and a meeting place outside the home.
    })
  },

  // --- FINANCIAL LITERACY (3 Materials) ---
  {
    id: G9-HS-FL-01",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Financial Literacy,
    subtopic: "Savings",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Saving is a key component of financial literacy and helps build wealth over time. What is the rule of thumb for saving a portion of income?,
      options: [The 50-30-20 rule: 50% needs, 30% wants, 20% savings., Save all income., Save nothing.", "Save 5% of income.].sort(() => Math.random() - 0.5),
      correctAnswer: The 50-30-20 rule: 50% needs, 30% wants, 20% savings."
    })
  },
  {
    id: "G9-HS-FL-02",
    grade: "Grade 9",
    subject: "Home Science",
    topic: "Financial Literacy",
    subtopic: "Investments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Investing is a way to grow money over time for future goals. What is the difference between saving and investing?,
      options: [Saving is for short-term goals, while investing is for long-term growth with risk., They are the same., "Investing is safer., Saving has higher returns."].sort(() => Math.random() - 0.5),
      correctAnswer: "Saving is for short-term goals, while investing is for long-term growth with risk.
    })
  },
  {
    id: G9-HS-FL-03",
    grade: "Grade 9,
    subject: Home Science",
    topic: "Financial Literacy,
    subtopic: "Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Entrepreneurship can provide income and independence. What is an essential skill for a successful entrepreneur?,
      options: [Financial management, marketing, and customer service skills., Only technical skills., Only creativity.", "Ignoring competition.].sort(() => Math.random() - 0.5),
      correctAnswer: Financial management, marketing, and customer service skills."
    })
  },

  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL GROOMING AND ETIQUETTE (5 Materials) ---
  {
    id: "G10-HS-PG-01",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Personal Grooming and Etiquette",
    subtopic: "Professional Appearance,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Professional appearance in the workplace influences first impressions and career success. What is the most important aspect of professional grooming?,
      options: [Cleanliness, neat attire, and appropriate personal hygiene., Expensive clothing., "Following fashion trends., Wearing heavy makeup."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleanliness, neat attire, and appropriate personal hygiene.
    })
  },
  {
    id: G10-HS-PG-02",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Personal Grooming and Etiquette,
    subtopic: "Professional Appearance",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Dressing appropriately for the workplace shows professionalism and respect for the job. Which of the following is appropriate business formal attire for an interview?,
      options: [A suit or blazer with dress pants or a skirt, and polished shoes., Jeans and a t-shirt., Sportswear.", "Evening gown.].sort(() => Math.random() - 0.5),
      correctAnswer: A suit or blazer with dress pants or a skirt, and polished shoes."
    })
  },
  {
    id: "G10-HS-PG-03",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Personal Grooming and Etiquette",
    subtopic: "Etiquette,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Workplace etiquette involves behavior that promotes a positive and professional environment. What is an example of good workplace etiquette?,
      options: [Respecting colleagues' time, maintaining confidentiality, and communicating professionally., Gossiping about coworkers., "Coming late to meetings., Interrupting others."].sort(() => Math.random() - 0.5),
      correctAnswer: "Respecting colleagues' time, maintaining confidentiality, and communicating professionally.
    })
  },
  {
    id: G10-HS-PG-04",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Personal Grooming and Etiquette,
    subtopic: "Etiquette",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Email etiquette is important in professional communication. What is a best practice when sending professional emails?,
      options: [Use a clear subject line, be concise, and use appropriate salutations and closings., Use all caps., Send without proofreading.", "Use informal language.].sort(() => Math.random() - 0.5),
      correctAnswer: Use a clear subject line, be concise, and use appropriate salutations and closings."
    })
  },
  {
    id: "G10-HS-PG-05",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Personal Grooming and Etiquette",
    subtopic: "Professional Appearance,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Personal hygiene in the workplace is essential for comfort and professionalism. What daily hygiene practices are important for the workplace?,
      options: [Bathing, brushing teeth, using deodorant, and wearing clean clothes., Avoiding all hygiene products., "Only wearing perfume., Bathing weekly."].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing, brushing teeth, using deodorant, and wearing clean clothes.
    })
  },

  // --- HOME SANITATION (4 Materials) ---
  {
    id: G10-HS-HS-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Advanced Cleaning Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Advanced cleaning techniques go beyond daily cleaning to maintain a healthy home. What is the purpose of deep cleaning carpets professionally?,
      options: [To remove embedded dirt, allergens, and bacteria that regular vacuuming cannot reach., To change the color., To make the carpet heavier.", "To remove the carpet.].sort(() => Math.random() - 0.5),
      correctAnswer: To remove embedded dirt, allergens, and bacteria that regular vacuuming cannot reach."
    })
  },
  {
    id: "G10-HS-HS-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Advanced Cleaning Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Steam cleaning is an effective method for sanitizing surfaces without chemicals. What is a benefit of steam cleaning?,
      options: [It kills bacteria and removes dirt using high-temperature steam., It is expensive., "It requires a lot of chemicals., It damages surfaces."].sort(() => Math.random() - 0.5),
      correctAnswer: "It kills bacteria and removes dirt using high-temperature steam.
    })
  },
  {
    id: G10-HS-HS-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Home Sanitation,
    subtopic: "Sanitation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Mold and mildew can cause health problems and damage to the home. What conditions promote mold growth in the home?,
      options: [High humidity, poor ventilation, and moisture leaks., Dry conditions., Low temperatures.", "Good lighting.].sort(() => Math.random() - 0.5),
      correctAnswer: High humidity, poor ventilation, and moisture leaks."
    })
  },
  {
    id: "G10-HS-HS-04",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Home Sanitation",
    subtopic: "Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Water damage in the home can lead to serious structural issues and health problems. What should you do immediately after discovering a water leak?,
      options: [Turn off the water source, dry the area, and call a professional if needed., Ignore it., "Wait for it to dry on its own., Cover it with a cloth."].sort(() => Math.random() - 0.5),
      correctAnswer: "Turn off the water source, dry the area, and call a professional if needed.
    })
  },

  // --- TEXTILE SCIENCE (4 Materials) ---
  {
    id: G10-HS-TS-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Textile Science,
    subtopic: "Fiber Properties",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The properties of textile fibers determine their suitability for different uses. What is a key difference between natural and synthetic fibers?,
      options: [Natural fibers are biodegradable and absorbent, while synthetic fibers are usually more durable and water-resistant., They are exactly the same., Synthetic fibers are always better.", "Natural fibers are only for clothing.].sort(() => Math.random() - 0.5),
      correctAnswer: Natural fibers are biodegradable and absorbent, while synthetic fibers are usually more durable and water-resistant."
    })
  },
  {
    id: "G10-HS-TS-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Textile Science",
    subtopic: "Fiber Properties,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Fabric testing ensures quality and performance of textiles. What is the purpose of a fabric flammability test?,
      options: [To determine how easily the fabric catches fire and how quickly it burns., To check the color., "To measure the thickness., To test the smell."].sort(() => Math.random() - 0.5),
      correctAnswer: "To determine how easily the fabric catches fire and how quickly it burns.
    })
  },
  {
    id: G10-HS-TS-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Textile Science,
    subtopic: "Fabric Testing",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Fabric shrinkage can affect the fit and appearance of garments. What test is used to measure the shrinkage of fabric?,
      options: [A shrinkage test where fabric is measured before and after washing., A color fastness test., A tensile strength test.", "A flammability test.].sort(() => Math.random() - 0.5),
      correctAnswer: A shrinkage test where fabric is measured before and after washing."
    })
  },
  {
    id: "G10-HS-TS-04",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Textile Science",
    subtopic: "Fabric Testing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Color fastness is an important property that indicates how well a fabric retains its color. What causes color fading in fabrics?,
      options: [Exposure to sunlight, washing with harsh detergents, and friction., Oxygen exposure., "Cold water washing., Indoor lighting."].sort(() => Math.random() - 0.5),
      correctAnswer: "Exposure to sunlight, washing with harsh detergents, and friction.
    })
  },

  // --- ADVANCED NUTRITION (4 Materials) ---
  {
    id: G10-HS-AN-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Diet Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Diet planning involves creating a nutritionally adequate and enjoyable eating pattern. What factors should be considered when planning a diet for an individual?,
      options: [Age, activity level, health conditions, food preferences, and cultural background., Only calorie count., Only taste.", "Only the food available.].sort(() => Math.random() - 0.5),
      correctAnswer: Age, activity level, health conditions, food preferences, and cultural background."
    })
  },
  {
    id: "G10-HS-AN-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Sports Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sports nutrition focuses on fueling the body for athletic performance and recovery. What is the recommended nutrient focus for an athlete's pre-exercise meal?,
      options: [Complex carbohydrates for sustained energy., High fat foods., "High protein only., No food before exercise."].sort(() => Math.random() - 0.5),
      correctAnswer: "Complex carbohydrates for sustained energy.
    })
  },
  {
    id: G10-HS-AN-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Advanced Nutrition,
    subtopic: "Sports Nutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Hydration is critical for athletic performance and preventing dehydration. How much water should an athlete drink during exercise?,
      options: [Regularly in small amounts to prevent dehydration, varying with intensity and duration., Once at the beginning., Only at the end.", "As much as possible in one go.].sort(() => Math.random() - 0.5),
      correctAnswer: Regularly in small amounts to prevent dehydration, varying with intensity and duration."
    })
  },
  {
    id: "G10-HS-AN-04",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Advanced Nutrition",
    subtopic: "Diet Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Special dietary needs may arise from medical conditions, religious practices, or personal choices. What is an example of a therapeutic diet prescribed for a medical condition?,
      options: ["A low-sodium diet for hypertension or a diabetic diet for diabetes., A high-sugar diet.", "A fast-food diet., An all-protein diet."].sort(() => Math.random() - 0.5),
      correctAnswer: "A low-sodium diet for hypertension or a diabetic diet for diabetes.
    })
  },

  // --- CULINARY ARTS (4 Materials) ---
  {
    id: G10-HS-CA-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Culinary Arts,
    subtopic: "International Cuisines",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " International cuisines incorporate distinct ingredients and cooking techniques from different cultures. What is a characteristic ingredient used in Italian cuisine?,
      options: [Tomatoes, olive oil, basil, and pasta., Soy sauce and miso., Coconut milk and curry.", "Cumin and coriander.].sort(() => Math.random() - 0.5),
      correctAnswer: Tomatoes, olive oil, basil, and pasta."
    })
  },
  {
    id: "G10-HS-CA-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Culinary Arts",
    subtopic: "International Cuisines,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Asian cuisines are diverse and use a variety of flavorings and ingredients. What is a staple food in many Asian cuisines?,
      options: [Rice, noodles, and soy-based products., Bread and potatoes., "Corn and beans., Cheese and cream."].sort(() => Math.random() - 0.5),
      correctAnswer: "Rice, noodles, and soy-based products.
    })
  },
  {
    id: G10-HS-CA-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Culinary Arts,
    subtopic: "Food Presentation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Food presentation enhances the dining experience and makes dishes more appealing. What is the principle of food plating that uses the 'rule of thirds'?,
      options: [Arranging food in a way that follows a golden ratio for visual appeal., Dividing the plate into three equal sections., Using three colors only.", "Serving three portions.].sort(() => Math.random() - 0.5),
      correctAnswer: Arranging food in a way that follows a golden ratio for visual appeal."
    })
  },
  {
    id: "G10-HS-CA-04",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Culinary Arts",
    subtopic: "Food Presentation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Garnishes add color, texture, and flavor to a dish. What is the purpose of using a garnish in food presentation?,
      options: ["To enhance visual appeal and complement the flavors of the dish., To add extra calories.", "To hide mistakes., To make the plate heavier."].sort(() => Math.random() - 0.5),
      correctAnswer: "To enhance visual appeal and complement the flavors of the dish.
    })
  },

  // --- BEVERAGES (3 Materials) ---
  {
    id: G10-HS-BEV-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Coffee Appreciation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Coffee appreciation involves understanding the characteristics of different coffee beans and brewing methods. What is the difference between Arabica and Robusta coffee beans?,
      options: [Arabica has a smoother, more complex flavor, while Robusta is stronger and more bitter., They are exactly the same., Robusta is smoother.", "Arabica is only grown in Kenya.].sort(() => Math.random() - 0.5),
      correctAnswer: Arabica has a smoother, more complex flavor, while Robusta is stronger and more bitter."
    })
  },
  {
    id: "G10-HS-BEV-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Beverages",
    subtopic: "Tea Appreciation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Tea appreciation involves understanding the different types of tea and their characteristics. What is the difference between black tea and green tea processing?,
      options: [Black tea is fully oxidized, while green tea is unoxidized., Green tea is fully oxidized., "They are processed the same., Black tea is unoxidized."].sort(() => Math.random() - 0.5),
      correctAnswer: "Black tea is fully oxidized, while green tea is unoxidized.
    })
  },
  {
    id: G10-HS-BEV-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Beverages,
    subtopic: "Coffee Appreciation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Coffee brewing methods affect the flavor and strength of the final beverage. What is a characteristic of the French press brewing method?,
      options: [Coffee grounds steep in hot water and are separated by a plunger filter., Water is dripped through coffee slowly., High pressure is used to extract coffee.", "Coffee is boiled in water.].sort(() => Math.random() - 0.5),
      correctAnswer: Coffee grounds steep in hot water and are separated by a plunger filter."
    })
  },

  // --- FASHION AND DESIGN (3 Materials) ---
  {
    id: "G10-HS-FD-01",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Fashion and Design",
    subtopic: "Pattern Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pattern making is the foundation of garment construction. What is the purpose of manipulating a basic pattern block?,
      options: [To create different designs and style variations while maintaining proper fit., To make the pattern smaller., "To use less fabric., To make the garment simpler."].sort(() => Math.random() - 0.5),
      correctAnswer: "To create different designs and style variations while maintaining proper fit.
    })
  },
  {
    id: G10-HS-FD-02",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Fashion and Design,
    subtopic: "Garment Construction",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Professional garment construction involves techniques that ensure durability and a polished appearance. What is the purpose of stay stitching in garment construction?,
      options: [To prevent curved areas from stretching during the sewing process., To make the seam stronger., To add decoration.", "To shorten the garment.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent curved areas from stretching during the sewing process."
    })
  },
  {
    id: "G10-HS-FD-03",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Fashion and Design",
    subtopic: "Garment Construction,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Understitching is a technique used in garment construction to create a neat finish. Where is understitching typically applied?,
      options: [On facings and linings to keep them from rolling to the outside., On hems., "On seams., On sleeves."].sort(() => Math.random() - 0.5),
      correctAnswer: "On facings and linings to keep them from rolling to the outside.
    })
  },

  // --- HOME FURNISHING (3 Materials) ---
  {
    id: G10-HS-HF-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Home Furnishing,
    subtopic: "Upholstery",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Upholstery involves covering furniture with fabric and padding. What is the purpose of the webbing used in upholstered furniture?,
      options: [To provide support and structure for the cushioning., To add color., To make the furniture lighter.", "To cover the wood.].sort(() => Math.random() - 0.5),
      correctAnswer: To provide support and structure for the cushioning."
    })
  },
  {
    id: "G10-HS-HF-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Home Furnishing",
    subtopic: "Curtains,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Curtains serve both functional and decorative purposes in the home. What is the purpose of thermal or blackout curtain lining?,
      options: [To block light, provide insulation, and reduce energy costs., To make the curtains heavier., "To add color., To hide stains."].sort(() => Math.random() - 0.5),
      correctAnswer: "To block light, provide insulation, and reduce energy costs.
    })
  },
  {
    id: G10-HS-HF-03",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Home Furnishing,
    subtopic: "Floor Coverings",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Floor coverings affect the comfort, safety, and appearance of a room. What is the difference between carpet and area rugs?,
      options: [Carpet covers the entire floor and is installed, while area rugs are moveable and cover a portion., They are the same., Area rugs are permanent.", "Carpet is only for bedrooms.].sort(() => Math.random() - 0.5),
      correctAnswer: Carpet covers the entire floor and is installed, while area rugs are moveable and cover a portion."
    })
  },

  // --- HEALTH AND SAFETY (3 Materials) ---
  {
    id: "G10-HS-HS-01",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Occupational Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Occupational health focuses on preventing workplace injuries and illnesses. What is the purpose of conducting a risk assessment in the workplace?,
      options: [To identify potential hazards and implement measures to control them., To increase paperwork., "To make the workplace slower., To reduce productivity."].sort(() => Math.random() - 0.5),
      correctAnswer: "To identify potential hazards and implement measures to control them.
    })
  },
  {
    id: G10-HS-HS-02",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Health and Safety,
    subtopic: "Occupational Health",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Good posture and ergonomics in the workplace prevent musculoskeletal disorders. What is a recommended ergonomic practice for computer users?,
      options: [Keep the monitor at eye level and use a supportive chair., Use the computer on the floor., Slouch in the chair.", "Keep the monitor below the desk.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep the monitor at eye level and use a supportive chair."
    })
  },
  {
    id: "G10-HS-HS-03",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Health and Safety",
    subtopic: "Safety Standards,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Safety standards protect workers and consumers from harm. Why are product safety standards important in the home science industry?,
      options: [To ensure products are safe for use and meet quality requirements., To make products expensive., "To limit choices., To confuse consumers."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure products are safe for use and meet quality requirements.
    })
  },

  // --- RESOURCE MANAGEMENT (2 Materials) ---
  {
    id: G10-HS-RM-01",
    grade: "Grade 10,
    subject: Home Science",
    topic: "Resource Management,
    subtopic: "Family Budgeting",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Family budgeting involves planning income and expenses to meet financial goals. What is the purpose of tracking expenses in a family budget?,
      options: [To identify spending patterns and find opportunities to save., To increase stress., To spend more money.", "To hide money from the family.].sort(() => Math.random() - 0.5),
      correctAnswer: To identify spending patterns and find opportunities to save."
    })
  },
  {
    id: "G10-HS-RM-02",
    grade: "Grade 10",
    subject: "Home Science",
    topic: "Resource Management",
    subtopic: "Investment,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Investing is a strategy for growing wealth over the long term. What is a low-risk investment option suitable for families?,
      options: [Savings accounts, treasury bonds, or money market funds., Cryptocurrency., "Penny stocks., Starting a business without research."].sort(() => Math.random() - 0.5),
      correctAnswer: "Savings accounts, treasury bonds, or money market funds.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- PERSONAL HEALTH AND WELLNESS (4 Materials) ---
  {
    id: G11-HS-PH-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Personal Health and Wellness,
    subtopic: "Lifestyle",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Healthy lifestyle choices contribute to physical, mental, and emotional well-being. Which of the following is a key component of a healthy lifestyle?,
      options: [Regular physical activity, balanced nutrition, adequate sleep, and stress management., Staying inactive., Eating junk food.", "Sleeping 4 hours a night.].sort(() => Math.random() - 0.5),
      correctAnswer: Regular physical activity, balanced nutrition, adequate sleep, and stress management."
    })
  },
  {
    id: "G11-HS-PH-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Personal Health and Wellness",
    subtopic: "Stress Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stress management is important for maintaining mental health. What is an effective stress management technique?,
      options: [Deep breathing, meditation, exercise, and talking to someone., Ignoring stress., "Eating large amounts of food., Watching TV all day."].sort(() => Math.random() - 0.5),
      correctAnswer: "Deep breathing, meditation, exercise, and talking to someone.
    })
  },
  {
    id: G11-HS-PH-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Personal Health and Wellness,
    subtopic: "Lifestyle",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Work-life balance is important for maintaining mental health and relationships. What is a strategy for achieving work-life balance?,
      options: [Set clear boundaries, prioritize tasks, and make time for family and rest., Work all the time., Never take breaks.", "Ignore family needs.].sort(() => Math.random() - 0.5),
      correctAnswer: Set clear boundaries, prioritize tasks, and make time for family and rest."
    })
  },
  {
    id: "G11-HS-PH-04",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Personal Health and Wellness",
    subtopic: "Stress Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Mental health is as important as physical health. What should you do if you experience persistent feelings of sadness, anxiety, or overwhelm?,
      options: ["Seek professional help from a counselor or mental health professional., Ignore the feelings.", "Self-medicate with alcohol., Keep it to yourself."].sort(() => Math.random() - 0.5),
      correctAnswer: "Seek professional help from a counselor or mental health professional.
    })
  },

  // --- ENVIRONMENTAL HYGIENE (4 Materials) ---
  {
    id: G11-HS-EH-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Environmental Hygiene,
    subtopic: "Waste Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Waste management involves the collection, transport, processing, and disposal of waste. What are the benefits of the 3Rs (Reduce, Reuse, Recycle) in waste management?,
      options: [They reduce the amount of waste sent to landfills and conserve natural resources., They increase waste., They are not effective.", "They only apply to plastic.].sort(() => Math.random() - 0.5),
      correctAnswer: They reduce the amount of waste sent to landfills and conserve natural resources."
    })
  },
  {
    id: "G11-HS-EH-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Environmental Hygiene",
    subtopic: "Waste Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Composting is a sustainable method of managing organic waste. What is the benefit of composting kitchen waste?,
      options: [It turns organic waste into nutrient-rich fertilizer for gardens., It creates methane., "It produces harmful gases., It attracts pests."].sort(() => Math.random() - 0.5),
      correctAnswer: "It turns organic waste into nutrient-rich fertilizer for gardens.
    })
  },
  {
    id: G11-HS-EH-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Environmental Hygiene,
    subtopic: "Pollution Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Indoor air pollution can be caused by household chemicals, smoke, and poor ventilation. What is a way to reduce indoor air pollution?,
      options: [Ventilate rooms regularly, use natural cleaning products, and avoid smoking indoors., Seal all windows., Use air fresheners.", "Burn incense all day.].sort(() => Math.random() - 0.5),
      correctAnswer: Ventilate rooms regularly, use natural cleaning products, and avoid smoking indoors."
    })
  },
  {
    id: "G11-HS-EH-04",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Environmental Hygiene",
    subtopic: "Pollution Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Water pollution affects both human health and ecosystems. What is a common cause of water pollution in Kenyan communities?,
      options: [Improper disposal of waste, agricultural runoff, and untreated sewage., Natural causes only., "Boiling water., Rainwater."].sort(() => Math.random() - 0.5),
      correctAnswer: "Improper disposal of waste, agricultural runoff, and untreated sewage.
    })
  },

  // --- TEXTILE DESIGN (4 Materials) ---
  {
    id: G11-HS-TD-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Textile Design,
    subtopic: "Weaving",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Weaving is a textile production technique that involves interlacing two sets of threads. What is the difference between a loom and a weaving frame?,
      options: [A loom is a larger, more complex machine for weaving, while a frame is a simpler, handheld device., They are the same., A frame is for knitting.", "A loom is only used in Kenya.].sort(() => Math.random() - 0.5),
      correctAnswer: A loom is a larger, more complex machine for weaving, while a frame is a simpler, handheld device."
    })
  },
  {
    id: "G11-HS-TD-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Textile Design",
    subtopic: "Knitting,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Knitting creates a stretchy, comfortable fabric using yarn and needles. What is the difference between knit and purl stitches?,
      options: [Knit stitches create a smooth 'V' pattern, while purl stitches create a bumpy texture., They are the same.", "Purling is done only by machines., Knitting is only done by hand."].sort(() => Math.random() - 0.5),
      correctAnswer: "Knit stitches create a smooth 'V' pattern, while purl stitches create a bumpy texture.
    })
  },
  {
    id: G11-HS-TD-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Textile Design,
    subtopic: "Embroidery",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Embroidery is a decorative textile art that uses needle and thread to create patterns. What is the purpose of using an embroidery hoop?,
      options: [To keep the fabric taut and prevent puckering while stitching., To hold needles., To store thread.", "To cut fabric.].sort(() => Math.random() - 0.5),
      correctAnswer: To keep the fabric taut and prevent puckering while stitching."
    })
  },
  {
    id: "G11-HS-TD-04",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Textile Design",
    subtopic: "Embroidery,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Different embroidery stitches create different textures and effects. What stitch is commonly used for outlining designs in embroidery?,
      options: [The stem stitch or backstitch., The French knot., "The chain stitch., The satin stitch."].sort(() => Math.random() - 0.5),
      correctAnswer: "The stem stitch or backstitch.
    })
  },

  // --- NUTRITIONAL SCIENCE (4 Materials) ---
  {
    id: G11-HS-NS-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Nutritional Science,
    subtopic: "Metabolism",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Metabolism refers to the chemical processes that occur in the body to maintain life. What is the relationship between basal metabolic rate (BMR) and weight management?,
      options: [A higher BMR means the body burns more calories at rest, which supports weight management., BMR has no effect., BMR decreases with exercise.", "Only exercise affects BMR.].sort(() => Math.random() - 0.5),
      correctAnswer: A higher BMR means the body burns more calories at rest, which supports weight management."
    })
  },
  {
    id: "G11-HS-NS-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Nutritional Science",
    subtopic: "Metabolism,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Dietetics involves the application of nutritional science to promote health and treat disease. What is the role of a dietitian?,
      options: [To assess nutritional needs and create individualized meal plans for health or disease management., To cook food., "To prescribe medication., To exercise with patients."].sort(() => Math.random() - 0.5),
      correctAnswer: "To assess nutritional needs and create individualized meal plans for health or disease management.
    })
  },
  {
    id: G11-HS-NS-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Nutritional Science,
    subtopic: "Dietetics",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Understanding food composition is essential for nutritional science. What is the function of dietary fiber in the diet?,
      options: [It aids digestion, prevents constipation, and may help prevent certain diseases., It provides energy., It builds muscle.", "It stores fat.].sort(() => Math.random() - 0.5),
      correctAnswer: It aids digestion, prevents constipation, and may help prevent certain diseases."
    })
  },
  {
    id: "G11-HS-NS-04",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Nutritional Science",
    subtopic: "Dietetics,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The glycemic index (GI) ranks foods based on how they affect blood sugar levels. Why might a dietitian recommend low-GI foods to a diabetic patient?,
      options: [They help maintain stable blood sugar levels., They taste better., "They are cheaper., They are always organic."].sort(() => Math.random() - 0.5),
      correctAnswer: "They help maintain stable blood sugar levels.
    })
  },

  // --- FOOD TECHNOLOGY (4 Materials) ---
  {
    id: G11-HS-FT-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Food Technology,
    subtopic: "Processing",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Food processing involves transforming raw ingredients into food products. What is the purpose of pasteurization in food processing?,
      options: [To kill harmful bacteria while preserving the quality of the food., To add flavor., To change the color.", "To remove nutrients.].sort(() => Math.random() - 0.5),
      correctAnswer: To kill harmful bacteria while preserving the quality of the food."
    })
  },
  {
    id: "G11-HS-FT-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Food Technology",
    subtopic: "Preservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Food preservation extends the shelf life of food and reduces waste. What is the principle behind vacuum packaging as a preservation method?,
      options: [Removing oxygen prevents the growth of aerobic microorganisms., Adding heat kills bacteria., "Freezing stops spoilage., Adding salt preserves food."].sort(() => Math.random() - 0.5),
      correctAnswer: "Removing oxygen prevents the growth of aerobic microorganisms.
    })
  },
  {
    id: G11-HS-FT-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Food Technology,
    subtopic: "Packaging",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Food packaging serves to protect food and provide information to consumers. What is the purpose of modified atmosphere packaging (MAP)?,
      options: [To extend shelf life by modifying the gas composition inside the package., To make the package look bigger., To increase weight.", "To add flavor to the food.].sort(() => Math.random() - 0.5),
      correctAnswer: To extend shelf life by modifying the gas composition inside the package."
    })
  },
  {
    id: "G11-HS-FT-04",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Food Technology",
    subtopic: "Packaging,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sustainable packaging is becoming increasingly important in the food industry. Which of the following is an example of sustainable food packaging?,
      options: [Biodegradable or compostable materials, and recycled content packaging., Plastic foam., "Non-recyclable plastic., Metallic containers."].sort(() => Math.random() - 0.5),
      correctAnswer: "Biodegradable or compostable materials, and recycled content packaging.
    })
  },

  // --- CATERING (3 Materials) ---
  {
    id: G11-HS-CA-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Catering,
    subtopic: "Menu Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Menu planning is a key part of catering and event management. What factors should be considered when planning a menu for an event?,
      options: [Guest preferences, dietary restrictions, budget, and theme of the event., Only the cost., Only the food available.", "Only the chef's preference.].sort(() => Math.random() - 0.5),
      correctAnswer: Guest preferences, dietary restrictions, budget, and theme of the event."
    })
  },
  {
    id: "G11-HS-CA-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Catering",
    subtopic: "Event Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Event management involves coordinating all aspects of an event to ensure its success. What is the purpose of creating a catering timeline?,
      options: [To ensure all tasks are completed on time and the event runs smoothly., To complicate things., "To increase costs., To confuse the staff."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure all tasks are completed on time and the event runs smoothly.
    })
  },
  {
    id: G11-HS-CA-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Catering,
    subtopic: "Event Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Food safety in catering is crucial to prevent food poisoning. What is the temperature danger zone for food storage?,
      options: [4°C to 60°C (40°F to 140°F) where bacteria grow rapidly., Below 0°C., Above 100°C.", "Room temperature.].sort(() => Math.random() - 0.5),
      correctAnswer: 4°C to 60°C (40°F to 140°F) where bacteria grow rapidly."
    })
  },

  // --- ADVANCED GARMENT CONSTRUCTION (3 Materials) ---
  {
    id: "G11-HS-GC-01",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Advanced Garment Construction",
    subtopic: "Tailoring,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Tailoring involves creating custom-fit garments for individuals. What is the main difference between tailoring and ready-to-wear clothing?,
      options: [Tailored clothing is made to individual measurements, while ready-to-wear is mass-produced in standard sizes., They are the same., "Ready-to-wear fits better., Tailoring is only for suits."].sort(() => Math.random() - 0.5),
      correctAnswer: "Tailored clothing is made to individual measurements, while ready-to-wear is mass-produced in standard sizes.
    })
  },
  {
    id: G11-HS-GC-02",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Advanced Garment Construction,
    subtopic: "Alterations",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Garment alterations adjust the fit of existing clothing. What is a common alteration made to trousers?,
      options: [Hemming the length, taking in the waist, or tapering the legs., Adding pockets., Changing the color.", "Replacing the fabric.].sort(() => Math.random() - 0.5),
      correctAnswer: Hemming the length, taking in the waist, or tapering the legs."
    })
  },
  {
    id: "G11-HS-GC-03",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Advanced Garment Construction",
    subtopic: "Tailoring,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Professional tailoring requires precision and skill. What is the purpose of a fitting session during garment construction?,
      options: [To check the fit and make adjustments before the garment is completed., To decide the color., "To choose the fabric., To select the buttons."].sort(() => Math.random() - 0.5),
      correctAnswer: "To check the fit and make adjustments before the garment is completed.
    })
  },

  // --- INTERIOR DECORATION (3 Materials) ---
  {
    id: G11-HS-ID-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Interior Decoration,
    subtopic: "Lighting",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Lighting plays a crucial role in interior decoration and atmosphere. What is the difference between ambient, task, and accent lighting?,
      options: [Ambient lighting provides general illumination, task lighting focuses on specific activities, and accent lighting highlights features., They are the same., Task lighting is for decoration only.", "Accent lighting is for reading.].sort(() => Math.random() - 0.5),
      correctAnswer: Ambient lighting provides general illumination, task lighting focuses on specific activities, and accent lighting highlights features."
    })
  },
  {
    id: "G11-HS-ID-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Interior Decoration",
    subtopic: "Window Treatments,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Window treatments serve both functional and decorative purposes. What is the purpose of using blinds or shades in a room?,
      options: [To control light, provide privacy, and reduce energy costs., To make the room darker only., "To add color., To block all natural light."].sort(() => Math.random() - 0.5),
      correctAnswer: "To control light, provide privacy, and reduce energy costs.
    })
  },
  {
    id: G11-HS-ID-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Interior Decoration,
    subtopic: "Lighting",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Energy-efficient lighting is becoming increasingly important in interior design. What is an advantage of LED lighting over traditional incandescent bulbs?,
      options: [LED bulbs use less energy, last longer, and produce less heat., They are the same., LED bulbs are cheaper to buy.", "LED bulbs produce more light.].sort(() => Math.random() - 0.5),
      correctAnswer: LED bulbs use less energy, last longer, and produce less heat."
    })
  },

  // --- FIRST AID AND EMERGENCY CARE (3 Materials) ---
  {
    id: "G11-HS-FA-01",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "First Aid and Emergency Care",
    subtopic: "Advanced First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Advanced first aid includes more complex skills for emergency situations. What is the purpose of a tourniquet in emergency care?,
      options: [To stop severe bleeding from a limb that cannot be controlled with direct pressure., To treat burns., "To fix broken bones., To give medication."].sort(() => Math.random() - 0.5),
      correctAnswer: "To stop severe bleeding from a limb that cannot be controlled with direct pressure.
    })
  },
  {
    id: G11-HS-FA-02",
    grade: "Grade 11,
    subject: Home Science",
    topic: "First Aid and Emergency Care,
    subtopic: "Advanced First Aid",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The recovery position is used to place an unconscious but breathing person. What is the purpose of the recovery position?,
      options: [To keep the airway clear and prevent choking., To wake the person up., To stop bleeding.", "To check for a pulse.].sort(() => Math.random() - 0.5),
      correctAnswer: To keep the airway clear and prevent choking."
    })
  },
  {
    id: "G11-HS-FA-03",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "First Aid and Emergency Care",
    subtopic: "Emergency Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Seizures can be alarming and require specific first aid management. What should you do if someone is having a seizure?,
      options: [Clear the area of hazards and protect the head, and do not restrain the person., Hold the person down., "Put something in their mouth., Give water."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clear the area of hazards and protect the head, and do not restrain the person.
    })
  },

  // --- ENTREPRENEURSHIP (3 Materials) ---
  {
    id: G11-HS-EN-01",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Entrepreneurship,
    subtopic: "Home Science Business Ventures",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Home science offers many business opportunities for entrepreneurs. What is a home science-related business idea that can be started with minimal capital?,
      options: [Baking and selling cakes, homemade soaps, or tailoring services., Buying expensive equipment., Opening a large restaurant.", "Importing luxury goods.].sort(() => Math.random() - 0.5),
      correctAnswer: Baking and selling cakes, homemade soaps, or tailoring services."
    })
  },
  {
    id: "G11-HS-EN-02",
    grade: "Grade 11",
    subject: "Home Science",
    topic: "Entrepreneurship",
    subtopic: "Home Science Business Ventures,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "A business plan is essential for starting and running a successful business. What should a business plan include?,
      options: [Executive summary, market analysis, business strategy, and financial projections., Only the price list., "Only the product description., Only the location."].sort(() => Math.random() - 0.5),
      correctAnswer: "Executive summary, market analysis, business strategy, and financial projections.
    })
  },
  {
    id: G11-HS-EN-03",
    grade: "Grade 11,
    subject: Home Science",
    topic: "Entrepreneurship,
    subtopic: "Home Science Business Ventures",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Marketing is essential for attracting customers to a home science business. What is an effective low-cost marketing strategy for a home-based business?,
      options: [Social media marketing, word of mouth, and offering samples., Expensive television ads., Billboard advertising.", "Celebrity endorsements.].sort(() => Math.random() - 0.5),
      correctAnswer: Social media marketing, word of mouth, and offering samples."
    })
  }`nexport const homeScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD HOME SCIENCE SYLLABUS)
  // =========================================================================

  // --- FAMILY RESOURCE MANAGEMENT (4 Materials) ---
  {
    id: "G12-HS-FRM-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Family Resource Management",
    subtopic: "Budgeting and Financial Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Effective family resource management requires careful planning and allocation of available resources. In preparing a family budget, which of the following steps is the most critical for ensuring financial stability and meeting all basic needs?,
      options: [
        Prioritizing essential expenses like food, shelter, and health before allocating funds to other wants.,
        Spending all available income on entertainment and leisure activities.",
        "Only budgeting for unexpected emergencies without considering regular expenses.,
        Allocating equal amounts of money to every expense category regardless of priority."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Prioritizing essential expenses like food, shelter, and health before allocating funds to other wants.
    })
  },
  {
    id: G12-HS-FRM-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Family Resource Management,
    subtopic: "Resource Allocation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Families have limited resources that must be managed wisely to meet their needs and goals. According to principles of resource management, what is the most effective approach to allocating scarce family resources among competing needs?,
      options: [
        Assessing all needs, setting priorities based on urgency and importance, then distributing resources accordingly.,
        Using all resources to satisfy wants without considering needs.,
        Saving all resources without spending on any current needs.",
        "Spending resources only on the most expensive items first.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Assessing all needs, setting priorities based on urgency and importance, then distributing resources accordingly."
    })
  },
  {
    id: "G12-HS-FRM-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Family Resource Management",
    subtopic: "Decision-Making Process,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Decision-making is a key aspect of family resource management that affects the well-being of all family members. Which of the following correctly describes the logical sequence of steps in the family decision-making process?,
      options: [
        Identify the problem, gather information, evaluate alternatives, make a decision, and implement the decision.,
        Make a decision immediately and implement it without any prior consideration.,
        "Gather information first, then identify the problem, and finally make a decision.,
        Evaluate alternatives before identifying the problem."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Identify the problem, gather information, evaluate alternatives, make a decision, and implement the decision.
    })
  },
  {
    id: G12-HS-FRM-04",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Family Resource Management,
    subtopic: "Time Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Time is a valuable resource that families must manage effectively to balance work, education, and leisure activities. What is the most effective strategy for a family to manage their time efficiently and reduce stress?,
      options: [
        Creating a schedule that prioritizes essential tasks, allocates time for rest, and involves all family members in responsibilities.,
        Spending time on tasks without any planning or organization.,
        Focusing only on work-related activities and ignoring family time.",
        "Leaving all household tasks to one person while others engage in leisure.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Creating a schedule that prioritizes essential tasks, allocates time for rest, and involves all family members in responsibilities."
    })
  },

  // --- FOOD AND NUTRITION (4 Materials) ---
  {
    id: "G12-HS-FN-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Nutritional Needs Across the Lifecycle,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Nutritional requirements vary significantly across different stages of the human lifecycle, from infancy to old age. Which of the following accurately describes the nutritional needs of adolescents compared to other age groups?,
      options: [
        Adolescents require increased energy, protein, calcium, and iron to support rapid growth and development during puberty.,
        Adolescents have the same nutritional needs as children under five years old.",
        "Adolescents need less calcium than adults because their bones have stopped growing.,
        Adolescents require fewer calories than elderly persons."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Adolescents require increased energy, protein, calcium, and iron to support rapid growth and development during puberty.
    })
  },
  {
    id: G12-HS-FN-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Meal Planning for Special Diets",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Certain medical conditions require special dietary modifications to manage symptoms and maintain health. When planning meals for a person with diabetes mellitus, which of the following dietary considerations is most important?,
      options: [
        Controlling carbohydrate intake and choosing complex carbohydrates that have a lower glycemic index.,
        Eliminating all fruits and vegetables from the diet to reduce sugar intake.,
        Increasing consumption of simple sugars to provide quick energy.",
        "Avoiding all fats and oils completely.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Controlling carbohydrate intake and choosing complex carbohydrates that have a lower glycemic index."
    })
  },
  {
    id: "G12-HS-FN-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Food and Nutrition",
    subtopic: "Dietary Guidelines,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Kenya Nutrition and Dietetics Institute provides dietary guidelines to promote health and prevent chronic diseases. Based on these guidelines, what proportion of daily energy intake should come from carbohydrates in a balanced diet?,
      options: [
        Carbohydrates should contribute 45-65% of total daily energy intake, emphasizing whole grains and fiber-rich sources.,
        Carbohydrates should contribute less than 10% of total daily energy intake.",
        "Carbohydrates should provide 70-80% of daily energy intake.,
        Carbohydrates should be completely avoided in a healthy diet."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbohydrates should contribute 45-65% of total daily energy intake, emphasizing whole grains and fiber-rich sources.
    })
  },
  {
    id: G12-HS-FN-04",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Food and Nutrition,
    subtopic: "Nutritional Deficiencies",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Micronutrient deficiencies remain a significant public health concern in Kenya, particularly among vulnerable populations. Which of the following deficiencies is most commonly associated with impaired vision and increased susceptibility to infections in children?,
      options: [
        Vitamin A deficiency, which can lead to night blindness and weakened immune function.,
        Iron deficiency, which causes anemia and fatigue.,
        Iodine deficiency, which leads to goiter and cognitive impairment.",
        "Calcium deficiency, which results in weak bones and teeth.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Vitamin A deficiency, which can lead to night blindness and weakened immune function."
    })
  },

  // --- CLOTHING AND TEXTILES (4 Materials) ---
  {
    id: "G12-HS-CT-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Clothing and Textiles",
    subtopic: "Fabric Selection and Properties,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The selection of appropriate fabric is crucial in garment construction as it determines the comfort, durability, and appearance of the finished garment. Which of the following fabric characteristics should be considered when selecting material for a summer dress that will be worn in hot, humid weather?,
      options: [
        "Lightweight, breathable natural fibers like cotton or linen that absorb moisture and allow air circulation.,
        Heavy synthetic fabrics that provide warmth and insulation.",
        "Water-resistant materials that trap heat and prevent sweating.,
        Wool fabrics that are thick and durable regardless of weather conditions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Lightweight, breathable natural fibers like cotton or linen that absorb moisture and allow air circulation.
    })
  },
  {
    id: G12-HS-CT-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Clothing and Textiles,
    subtopic: "Garment Construction Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Proper garment construction techniques ensure the durability and professional appearance of finished clothing items. When constructing a tailored jacket, which of the following techniques is most important for maintaining the garment's shape and structure over time?,
      options: [
        Using appropriate interfacing, interlinings, and properly placed seams to provide support and prevent stretching.,
        Stitching all seams with a straight stitch without any finishing techniques.,
        Using the same fabric for all components without any reinforcement materials.",
        "Skipping pressing steps to save time during construction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using appropriate interfacing, interlinings, and properly placed seams to provide support and prevent stretching."
    })
  },
  {
    id: "G12-HS-CT-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Clothing and Textiles",
    subtopic: "Textile Science,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Understanding textile science helps consumers make informed decisions about fabric care and durability. What is the chemical composition of synthetic fibers such as polyester and nylon, and how does this affect their care requirements?,
      options: [
        Synthetic fibers are made from petroleum-based polymers that are resistant to moisture, mildew, and moths, but can be damaged by high heat during ironing.,
        Synthetic fibers are derived from plant cellulose and require delicate washing with cold water.",
        "Synthetic fibers are animal-based proteins that must be dry-cleaned exclusively.,
        Synthetic fibers are naturally occurring minerals that are highly absorbent and require special care."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Synthetic fibers are made from petroleum-based polymers that are resistant to moisture, mildew, and moths, but can be damaged by high heat during ironing.
    })
  },
  {
    id: G12-HS-CT-04",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Clothing and Textiles,
    subtopic: "Textile Finishing and Dyeing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Textile finishing processes enhance the appearance, performance, and durability of fabrics. Which of the following finishing treatments is applied to fabrics to make them wrinkle-resistant and reduce the need for ironing?,
      options: [
        Resin finishing or permanent press treatment that cross-links cellulose molecules to prevent wrinkling.,
        Mercerization, which increases luster and strength of cotton fibers.,
        Calendering, which presses fabrics between heated rollers to produce a smooth surface.",
        "Sanforization, which reduces shrinkage by preshrinking the fabric.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Resin finishing or permanent press treatment that cross-links cellulose molecules to prevent wrinkling."
    })
  },

  // --- HOME FURNISHINGS AND INTERIOR DESIGN (4 Materials) ---
  {
    id: "G12-HS-HF-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Home Furnishings and Interior Design",
    subtopic: "Space Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Effective space planning is essential in interior design to create functional and aesthetically pleasing living environments. When planning the layout of a small living room that serves multiple purposes, which of the following approaches would most effectively maximize the available space?,
      options: [
        Using multifunctional furniture, creating distinct activity zones, and ensuring clear traffic flow throughout the room.,
        Placing all furniture against the walls to create a large empty space in the center.",
        "Filling every available space with furniture regardless of function.,
        Using only large, oversized furniture pieces regardless of room size."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using multifunctional furniture, creating distinct activity zones, and ensuring clear traffic flow throughout the room.
    })
  },
  {
    id: G12-HS-HF-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Home Furnishings and Interior Design,
    subtopic: "Principles of Design",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The principles of design guide the arrangement of elements in interior spaces to achieve visual harmony and balance. Which principle of design is demonstrated when furniture and decorative elements are arranged so that the visual weight is equally distributed on both sides of a central axis?,
      options: [
        Symmetrical balance, where identical or similar objects are placed on opposite sides of a central point.,
        Asymmetrical balance, where different objects of equal visual weight are used on each side.,
        Radial balance, where elements radiate from a central point.",
        "Proportion, which relates the size of elements to each other and to the space.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Symmetrical balance, where identical or similar objects are placed on opposite sides of a central point."
    })
  },
  {
    id: "G12-HS-HF-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Home Furnishings and Interior Design",
    subtopic: "Selection of Home Furnishings,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Selecting appropriate furnishings for a home requires consideration of functionality, aesthetics, durability, and cost. When choosing curtains or window treatments for a bedroom, which of the following factors should be given the highest priority?,
      options: [
        "Light control, privacy, and thermal insulation, as these directly affect comfort and sleep quality.,
        The latest fashion trends and color patterns regardless of functionality.",
        "Only the cost of the materials without considering other factors.,
        The weight of the fabric, as heavier curtains are always better."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Light control, privacy, and thermal insulation, as these directly affect comfort and sleep quality.
    })
  },
  {
    id: G12-HS-HF-04",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Home Furnishings and Interior Design,
    subtopic: "Color Theory and Application",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Color theory is fundamental to interior design, as colors influence mood, perception of space, and overall aesthetic appeal. In a small room with limited natural light, which of the following color schemes would be most effective in making the space appear larger and brighter?,
      options: [
        Light, cool colors such as pale blues, greens, and whites that reflect light and create an airy feel.,
        Dark, warm colors like deep reds and browns that absorb light and create a cozy atmosphere.,
        Bright, bold primary colors that draw attention to the walls.",
        "Monochromatic dark shades that create a dramatic and sophisticated look.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Light, cool colors such as pale blues, greens, and whites that reflect light and create an airy feel."
    })
  },

  // --- HOUSING (3 Materials) ---
  {
    id: "G12-HS-HOU-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Housing",
    subtopic: "Types of Housing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Different types of housing are available to meet the diverse needs of families and individuals. Which of the following correctly describes the characteristics of a detached single-family house compared to multi-family housing options?,
      options: [
        A detached house is a standalone structure with its own land, offering more privacy and space, while multi-family housing shares walls and common areas with other units.,
        A detached house is always more expensive to maintain than apartment living.,
        "Multi-family housing always provides more privacy than detached houses.,
        Detached houses and apartments have the exact same characteristics and features."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A detached house is a standalone structure with its own land, offering more privacy and space, while multi-family housing shares walls and common areas with other units.
    })
  },
  {
    id: G12-HS-HOU-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Housing,
    subtopic: "Housing Needs and Standards",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Adequate housing is a fundamental human right that must meet certain standards to ensure the health, safety, and well-being of occupants. According to WHO housing standards, which of the following is an essential requirement for healthy housing?,
      options: [
        Adequate ventilation, proper sanitation, sufficient space, protection from the elements, and access to clean water.,
        Large rooms and expensive finishes regardless of sanitation standards.,
        A house located far from any services or infrastructure.",
        "Housing that does not require any maintenance or repairs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Adequate ventilation, proper sanitation, sufficient space, protection from the elements, and access to clean water."
    })
  },
  {
    id: "G12-HS-HOU-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Housing",
    subtopic: "Home Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Regular home maintenance is essential to preserve the value of a property and ensure the safety and comfort of its occupants. Which of the following maintenance activities should be performed most frequently to prevent major structural problems?,
      options: [
        Inspecting and cleaning gutters, repairing roof leaks, and checking for dampness and pest infestation at least twice a year.,
        Repainting the entire house every month.,
        "Replacing all windows annually.,
        Redesigning the landscaping every season."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Inspecting and cleaning gutters, repairing roof leaks, and checking for dampness and pest infestation at least twice a year.
    })
  },

  // --- CONSUMER EDUCATION (3 Materials) ---
  {
    id: G12-HS-CE-01",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Consumer Rights and Responsibilities",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Consumer education empowers individuals to make informed choices in the marketplace and exercise their rights effectively. According to the Kenya Bureau of Standards (KEBS), what is the consumer's right to information about products and services?,
      options: [
        The right to accurate and complete information about product composition, usage, safety, and pricing to make informed purchasing decisions.,
        The right to purchase any product without price disclosure.,
        The right to receive information only about expensive products.",
        "The right to refuse information about product ingredients.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The right to accurate and complete information about product composition, usage, safety, and pricing to make informed purchasing decisions."
    })
  },
  {
    id: "G12-HS-CE-02",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Consumer Education",
    subtopic: "Consumer Protection Mechanisms,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Various mechanisms exist to protect consumers from unfair trade practices and unsafe products in the Kenyan market. Which of the following is the primary consumer protection agency in Kenya that ensures products meet safety and quality standards?,
      options: [
        The Kenya Bureau of Standards (KEBS), which sets standards, tests products, and certifies quality for goods sold in Kenya.,
        The Ministry of Education, which oversees consumer protection in schools.,
        "The Kenya Revenue Authority (KRA), which collects taxes on consumer products.,
        The National Environment Management Authority (NEMA), which monitors environmental impact of products."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Kenya Bureau of Standards (KEBS), which sets standards, tests products, and certifies quality for goods sold in Kenya.
    })
  },
  {
    id: G12-HS-CE-03",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Consumer Education,
    subtopic: "Consumer Decision-Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Making informed consumer decisions requires evaluating products and services against established criteria. When comparing similar products before purchase, which of the following sets of factors should a rational consumer consider?,
      options: [
        Quality, price, durability, warranty, brand reputation, and the product's suitability for the intended purpose.,
        Only the price of the product without considering other factors.,
        Only the brand name without evaluating product features.",
        "The attractiveness of the packaging regardless of product quality.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Quality, price, durability, warranty, brand reputation, and the product's suitability for the intended purpose."
    })
  },

  // --- HOME CARE AND MAINTENANCE (3 Materials) ---
  {
    id: "G12-HS-HCM-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Home Care and Maintenance",
    subtopic: "Cleaning and Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Maintaining high standards of cleanliness in the home is essential for preventing the spread of infectious diseases. Which of the following cleaning practices is most important in preventing the spread of foodborne illnesses in the kitchen?,
      options: [
        Regular disinfection of food preparation surfaces, cooking utensils, and proper handwashing before and after handling food.,
        Cleaning only visible dirt from the kitchen floor.,
        "Wiping surfaces with a dry cloth only.,
        Cleaning the kitchen only when food has been spilled."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular disinfection of food preparation surfaces, cooking utensils, and proper handwashing before and after handling food.
    })
  },
  {
    id: G12-HS-HCM-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Home Care and Maintenance,
    subtopic: "Repairs and Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Minor home repairs should be addressed promptly to prevent them from becoming major problems. Which of the following is the most appropriate action to take when a water pipe develops a small leak in the house?,
      options: [
        Turn off the water supply, locate the leak, and temporarily seal it with a patch or tape while arranging for a professional plumber to make permanent repairs.,
        Ignore the leak and continue using water normally.,
        Wait several months before addressing the problem.",
        "Cover the leak with paint to hide it without fixing it.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Turn off the water supply, locate the leak, and temporarily seal it with a patch or tape while arranging for a professional plumber to make permanent repairs."
    })
  },
  {
    id: "G12-HS-HCM-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Home Care and Maintenance",
    subtopic: "Preventive Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Preventive maintenance involves regular activities that prevent equipment failure and extend the lifespan of household appliances. Which of the following is the best preventive maintenance practice for a refrigerator?,
      options: [
        Regularly cleaning the condenser coils, checking door seals, and ensuring proper ventilation around the appliance.,
        Overloading the refrigerator with items to maximize space use.,
        "Never defrosting or cleaning the refrigerator.,
        Placing the refrigerator directly against the wall without ventilation space."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regularly cleaning the condenser coils, checking door seals, and ensuring proper ventilation around the appliance.
    })
  },

  // --- CHILD DEVELOPMENT AND CARE (3 Materials) ---
  {
    id: G12-HS-CDC-01",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Child Development and Care,
    subtopic: "Growth and Development Stages",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Understanding the stages of child development helps caregivers provide appropriate support and stimulation. According to developmental milestones, which of the following describes the typical physical development of a child between the ages of three and five years?,
      options: [
        Improved gross motor skills such as running and jumping, and developing fine motor skills like drawing and using utensils.,
        Complete physical independence from caregivers without any developmental milestones.,
        No significant changes in physical or motor development during this period.",
        "Regression of motor skills and loss of previously acquired abilities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Improved gross motor skills such as running and jumping, and developing fine motor skills like drawing and using utensils."
    })
  },
  {
    id: "G12-HS-CDC-02",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Child Development and Care",
    subtopic: "Child Nutrition and Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Proper nutrition during the first years of life is critical for the physical and cognitive development of children. Which of the following is the recommended feeding practice for a six-month-old infant who is beginning complementary feeding?,
      options: [
        Introducing iron-rich foods such as fortified cereals and pureed meats while continuing breastfeeding or formula feeding.,
        Giving only cow's milk without any additional foods.,
        "Introducing solid foods with large amounts of sugar and salt.,
        Stopping breastfeeding completely and feeding only solid foods."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Introducing iron-rich foods such as fortified cereals and pureed meats while continuing breastfeeding or formula feeding.
    })
  },
  {
    id: G12-HS-CDC-03",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Child Development and Care,
    subtopic: "Childcare Practices",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Positive childcare practices contribute to the healthy development and well-being of children. Which of the following practices most effectively supports the social development of a preschool-aged child?,
      options: [
        Providing opportunities for play with other children, teaching sharing and cooperation, and modeling positive social interactions.,
        Keeping the child isolated from other children to avoid conflicts.,
        Allowing the child to watch television for long hours every day.",
        "Discouraging any interaction with peers to promote independence.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing opportunities for play with other children, teaching sharing and cooperation, and modeling positive social interactions."
    })
  },

  // --- FOOD PRESERVATION AND STORAGE (3 Materials) ---
  {
    id: "G12-HS-FPS-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Food Preservation and Storage",
    subtopic: "Traditional and Modern Preservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Food preservation techniques help extend the shelf life of perishable foods and reduce food waste. Which of the following preservation methods works by removing moisture from the food to inhibit the growth of microorganisms?,
      options: [
        Drying or dehydration, which reduces the water content of food to a level that prevents microbial growth.,
        Canning, which uses heat and sealing to preserve food.,
        "Refrigeration, which slows microbial activity by lowering temperature.,
        Pickling, which uses acid to create an environment where microbes cannot survive."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drying or dehydration, which reduces the water content of food to a level that prevents microbial growth.
    })
  },
  {
    id: G12-HS-FPS-02",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Food Preservation and Storage,
    subtopic: "Food Storage Conditions",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Proper storage conditions are essential for maintaining the nutritional quality and safety of preserved foods. Which of the following conditions is most critical for the long-term storage of dry foods such as cereals, legumes, and flour?,
      options: [
        A cool, dry, dark, and well-ventilated area with protection from insects, rodents, and moisture.,
        Storage in a warm, humid area to prevent hardening of the foods.,
        Storage in direct sunlight to kill any insects that may be present.",
        "Storage in open containers without any covering.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A cool, dry, dark, and well-ventilated area with protection from insects, rodents, and moisture."
    })
  },
  {
    id: "G12-HS-FPS-03",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Food Preservation and Storage",
    subtopic: "Food Spoilage Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Food spoilage is caused by various factors including microorganisms, enzymes, and physical processes. Which of the following is the most effective way to slow down enzymatic browning in cut fruits such as apples and bananas?,
      options: [
        "Applying lemon juice or ascorbic acid (vitamin C) to the cut surfaces, which acts as an antioxidant and prevents oxidation.,
        Leaving the fruit exposed to air for long periods.",
        "Sprinkling sugar on the cut surfaces.,
        Placing the fruit in a warm, bright area."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Applying lemon juice or ascorbic acid (vitamin C) to the cut surfaces, which acts as an antioxidant and prevents oxidation.
    })
  },

  // --- HYGIENE AND SANITATION (3 Materials) ---
  {
    id: G12-HS-HS-01",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Hygiene and Sanitation,
    subtopic: "Personal Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Personal hygiene practices are fundamental to preventing disease transmission and maintaining overall health. Which of the following is the most critical personal hygiene practice that should be performed at critical times such as after using the toilet and before handling food?,
      options: [
        Thorough handwashing with soap and running water for at least 20 seconds.,
        Rinsing hands with water only without using soap.,
        Using hand sanitizer only without washing with water.",
        "Wiping hands on a cloth without any cleaning agent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Thorough handwashing with soap and running water for at least 20 seconds."
    })
  },
  {
    id: "G12-HS-HS-02",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Hygiene and Sanitation",
    subtopic: "Water and Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Access to clean water and proper sanitation facilities is essential for preventing waterborne diseases. According to public health guidelines, what is the recommended practice for ensuring the safety of drinking water in areas where the water source may be contaminated?,
      options: [
        Boiling water for at least one minute or treating it with appropriate water purification chemicals.,
        Using water directly from the source without any treatment.",
        "Filtering water through a cloth only, without boiling or chemical treatment.,
        Allowing water to stand for several days before drinking."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiling water for at least one minute or treating it with appropriate water purification chemicals.
    })
  },
  {
    id: G12-HS-HS-03",
    grade: "Grade 12,
    subject: Home Science",
    topic: "Hygiene and Sanitation,
    subtopic: "Disease Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Understanding the chain of infection helps in implementing effective prevention strategies in the home and community. Which of the following interventions is most effective in breaking the transmission cycle of diarrheal diseases in a household setting?,
      options: [
        Ensuring proper handwashing, safe water handling, proper food storage, and maintaining a clean home environment.,
        Taking medication only when symptoms appear.,
        Ignoring hygiene practices until someone gets sick.",
        "Visiting a hospital after everyone has already been infected.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ensuring proper handwashing, safe water handling, proper food storage, and maintaining a clean home environment."
    })
  },

  // --- ENTREPRENEURSHIP IN HOME SCIENCE (1 Material) ---
  {
    id: "G12-HS-ENT-01",
    grade: "Grade 12",
    subject: "Home Science",
    topic: "Entrepreneurship in Home Science",
    subtopic: "Business Opportunities,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Home Science skills can be leveraged to create sustainable business opportunities and income-generating activities. Which of the following is the most viable small-scale enterprise that can be established by a home science graduate with limited capital in a Kenyan community?,
      options: [
        A home-based catering service that provides nutritious meals for working families and schools, utilizing culinary and nutrition skills.,
        Opening a large supermarket with substantial capital investment.,
        "Starting a multinational clothing manufacturing company with no experience.,
        Creating a real estate development company without construction knowledge."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A home-based catering service that provides nutritious meals for working families and schools, utilizing culinary and nutrition skills."
    })
  }

];


