export const creativeArtsTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
  // =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: "G1-CA-MUS-01",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: "When we listen to music, we can hear different sounds. Which of the following is a way we use our body to respond to music we are listening to?,
      options: [Clapping our hands., Closing our eyes.", "Sitting very still., Talking loudly."].sort(() => Math.random() - 0.5),
      correctAnswer: "Clapping our hands.
    })
  },
  {
    id: G1-CA-MUS-02",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Different types of music make us feel different emotions. How does slow, soft music usually make people feel?,
      options: [Calm and relaxed., Excited and happy., Angry and upset.", "Tired and sleepy.].sort(() => Math.random() - 0.5),
      correctAnswer: Calm and relaxed."
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: "G1-CA-MUS-03",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Singing is a wonderful way to express ourselves and have fun. What is the best way to produce a clear and beautiful singing voice?,
      options: [Take a deep breath and sing from your chest., Shout as loudly as possible., "Whisper the words., Hum without opening your mouth."].sort(() => Math.random() - 0.5),
      correctAnswer: "Take a deep breath and sing from your chest.
    })
  },
  {
    id: G1-CA-MUS-04",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Songs often have repeated words or phrases that make them easy to remember. What do we call a group of words that are repeated in a song?,
      options: [A chorus, A verse, A bridge", "An intro].sort(() => Math.random() - 0.5),
      correctAnswer: A chorus"
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: "G1-CA-MUS-05",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Musical instruments make sounds that we can enjoy. Which of the following is an instrument that is commonly played by hitting it with sticks?,
      options: [A drum, A guitar, "A flute, A violin"].sort(() => Math.random() - 0.5),
      correctAnswer: "A drum
    })
  },
  {
    id: G1-CA-MUS-06",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Shakers are simple instruments that make sound when shaken. Which of the following is a common shaker used in Kenyan music?,
      options: [A kayamba, A trumpet, A piano", "A saxophone].sort(() => Math.random() - 0.5),
      correctAnswer: A kayamba"
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: "G1-CA-MUS-07",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Dancing is a way to express ourselves through movement. What do we call the rhythm or beat that helps us move our bodies to music?,
      options: [The tempo, The melody, "The harmony, The lyrics"].sort(() => Math.random() - 0.5),
      correctAnswer: "The tempo
    })
  },
  {
    id: G1-CA-MUS-08",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Traditional Kenyan dances often tell stories and celebrate culture. Which of the following is a well-known traditional dance from Kenya?,
      options: [The Isikuti dance, The waltz, The salsa", "The tango].sort(() => Math.random() - 0.5),
      correctAnswer: The Isikuti dance"
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: "G1-CA-VIS-01",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Drawing is a way to create pictures using different tools. Which of the following tools is commonly used for drawing?,
      options: [A pencil, A paintbrush, "A scissors, A glue stick"].sort(() => Math.random() - 0.5),
      correctAnswer: "A pencil
    })
  },
  {
    id: G1-CA-VIS-02",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We can draw different shapes to create pictures. What shape has three sides and three corners?,
      options: [A triangle, A square, A circle", "A rectangle].sort(() => Math.random() - 0.5),
      correctAnswer: A triangle"
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: "G1-CA-VIS-03",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Painting allows us to add color to our artwork. What do we use to apply paint to a surface?,
      options: [A paintbrush, A pencil, "A crayon, A marker"].sort(() => Math.random() - 0.5),
      correctAnswer: "A paintbrush
    })
  },
  {
    id: G1-CA-VIS-04",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We can mix colors to create new colors. What do you get when you mix red and yellow paint together?,
      options: [Orange, Green, Purple", "Blue].sort(() => Math.random() - 0.5),
      correctAnswer: Orange"
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: "G1-CA-VIS-05",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Modelling is a way to create three-dimensional artwork. What material is commonly used for modelling?,
      options: [Clay, Paper, "Paint, Glue"].sort(() => Math.random() - 0.5),
      correctAnswer: "Clay
    })
  },
  {
    id: G1-CA-VIS-06",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " When we model with clay, we use our hands to shape it. What technique is used to join two pieces of clay together?,
      options: [Scoring and slipping, Cutting, Rolling", "Pressing].sort(() => Math.random() - 0.5),
      correctAnswer: Scoring and slipping"
    })
  },

  // --- VISUAL ARTS: CRAFT MAKING (2 Materials) ---
  {
    id: "G1-CA-VIS-07",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Craft Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Craft making involves creating useful or decorative items by hand. Which of the following is an example of a craft item?,
      options: [A beaded necklace, A painting, "A drawing, A photograph"].sort(() => Math.random() - 0.5),
      correctAnswer: "A beaded necklace
    })
  },
  {
    id: G1-CA-VIS-08",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Craft Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Many Kenyan communities create beautiful crafts using local materials. What material is commonly used to make woven baskets in Kenya?,
      options: [Sisal or reeds, Plastic, Metal", "Glass].sort(() => Math.random() - 0.5),
      correctAnswer: Sisal or reeds"
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: "G1-CA-DRA-01",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Storytelling is a way to share ideas and entertain others. What do we call the person who tells a story?,
      options: [A storyteller, A reader, "A writer, A dancer"].sort(() => Math.random() - 0.5),
      correctAnswer: "A storyteller
    })
  },
  {
    id: G1-CA-DRA-02",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Stories often have a message or a lesson. What is the lesson we learn from a story called?,
      options: [The moral, The plot, The setting", "The character].sort(() => Math.random() - 0.5),
      correctAnswer: The moral"
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: "G1-CA-DRA-03",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Dramatization is when we act out a story or scene. What is a person who acts in a dramatization called?,
      options: [An actor, A dancer, "A singer, A puppeteer"].sort(() => Math.random() - 0.5),
      correctAnswer: "An actor
    })
  },
  {
    id: G1-CA-DRA-04",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When we dramatize a story, we need to show emotions. How can we show that a character is happy in a dramatization?,
      options: [By smiling and laughing., By frowning and crying., By shouting and yelling.", "By standing still.].sort(() => Math.random() - 0.5),
      correctAnswer: By smiling and laughing."
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: "G1-CA-DRA-05",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Puppetry is a way of storytelling using puppets. What is a puppet that is controlled by a hand called?,
      options: [A hand puppet, A marionette, "A shadow puppet, A finger puppet"].sort(() => Math.random() - 0.5),
      correctAnswer: "A hand puppet
    })
  },
  {
    id: G1-CA-DRA-06",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Puppets can be made from many different materials. Which of the following can be used to make a simple puppet?,
      options: [A sock, A stone, A book", "A chair].sort(() => Math.random() - 0.5),
      correctAnswer: A sock"
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: "G1-CA-DRA-07",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Role Play,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Role play is when we pretend to be someone else. What is it called when you pretend to be someone you are not?,
      options: [Role play, Singing, "Drawing, Reading"].sort(() => Math.random() - 0.5),
      correctAnswer: "Role play
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: G1-CA-EXP-01",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Patterns are made by repeating shapes or colors. What do we call a design that is made up of repeating elements?,
      options: [A pattern, A drawing, A painting", "A sculpture].sort(() => Math.random() - 0.5),
      correctAnswer: A pattern"
    })
  },
  {
    id: "G1-CA-EXP-02",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Traditional Kenyan art often features beautiful patterns and designs. Which of the following is a common pattern found in Kenyan art?,
      options: [Chevron or zigzag patterns, Checkerboard patterns, "Polka dots, Stripe patterns"].sort(() => Math.random() - 0.5),
      correctAnswer: "Chevron or zigzag patterns
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: G1-CA-EXP-03",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Creative writing is a way to express our imagination using words. What is a short story that teaches a moral lesson called?,
      options: [A fable, A poem, A letter", "A report].sort(() => Math.random() - 0.5),
      correctAnswer: A fable"
    })
  },
  {
    id: "G1-CA-EXP-04",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Poems use words and sounds in special ways. What do we call a group of lines in a poem?,
      options: [A stanza, A paragraph, "A chapter, A sentence"].sort(() => Math.random() - 0.5),
      correctAnswer: "A stanza
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (2 Materials) ---
  {
    id: G1-CA-APP-01",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Nature",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Nature provides us with many beautiful sights and sounds. Which of the following is a natural sight that artists often appreciate and paint?,
      options: [A sunset, A building, A car", "A computer].sort(() => Math.random() - 0.5),
      correctAnswer: A sunset"
    })
  },
  {
    id: "G1-CA-APP-02",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Many songs and poems are inspired by nature. What natural element is often praised in Kenyan songs and poems?,
      options: [The beauty of Mount Kenya, A car, "A television, A mobile phone"].sort(() => Math.random() - 0.5),
      correctAnswer: "The beauty of Mount Kenya
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: G1-CA-APP-03",
    grade: "Grade 1,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We can show appreciation for artwork that we see. What is the best way to show appreciation for a piece of art?,
      options: [To look at it carefully and talk about what we like., To touch it roughly., To ignore it.", "To draw on it.].sort(() => Math.random() - 0.5),
      correctAnswer: To look at it carefully and talk about what we like."
    })
  },
  {
    id: "G1-CA-APP-04",
    grade: "Grade 1",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Artwork can make us feel different emotions. If a painting makes you feel happy, what should you do to show appreciation?,
      options: [Smile and compliment the artist., Laugh at the painting.", "Walk away quickly., Cover the painting."].sort(() => Math.random() - 0.5),
      correctAnswer: "Smile and compliment the artist.
    })
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
  // =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: G2-CA-MUS-01",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " When we listen to music, we can identify different elements such as rhythm and melody. What is the main tune of a song called?,
      options: [The melody, The rhythm, The beat", "The harmony].sort(() => Math.random() - 0.5),
      correctAnswer: The melody"
    })
  },
  {
    id: "G2-CA-MUS-02",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: "Music can be fast or slow, which is called tempo. How does fast, energetic music usually make people feel?,
      options: ["Excited and full of energy., Calm and relaxed.", "Sad and lonely., Angry and upset."].sort(() => Math.random() - 0.5),
      correctAnswer: "Excited and full of energy.
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: G2-CA-MUS-03",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We can sing many different types of songs from Kenya and around the world. What is a song that is sung during a ceremony or celebration called?,
      options: [A ceremonial song, A lullaby, A folk song", "A nursery rhyme].sort(() => Math.random() - 0.5),
      correctAnswer: A ceremonial song"
    })
  },
  {
    id: "G2-CA-MUS-04",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Some songs are sung by groups of people together. What do we call a group of people singing together?,
      options: [A choir, A band, "An orchestra, A duet"].sort(() => Math.random() - 0.5),
      correctAnswer: "A choir
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: G2-CA-MUS-05",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Traditional Kenyan instruments are made from local materials. Which of the following is a stringed instrument found in Kenya?,
      options: [A nyatiti, A drum, A shaker", "A horn].sort(() => Math.random() - 0.5),
      correctAnswer: A nyatiti"
    })
  },
  {
    id: "G2-CA-MUS-06",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We can make music with instruments using different actions like hitting, blowing, or plucking. How do you play a drum to make sound?,
      options: ["By hitting it with sticks or hands., By blowing into it.", "By plucking strings., By shaking it."].sort(() => Math.random() - 0.5),
      correctAnswer: "By hitting it with sticks or hands.
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: G2-CA-MUS-07",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Dance is a form of creative expression that uses body movements. What is a dance that tells a story through movements called?,
      options: [A narrative dance, A fast dance, A slow dance", "A group dance].sort(() => Math.random() - 0.5),
      correctAnswer: A narrative dance"
    })
  },
  {
    id: "G2-CA-MUS-08",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different Kenyan communities have unique dances that reflect their culture. Which community in Kenya is known for the energetic Mwomboko dance?,
      options: [The Kikuyu community, The Luo community, "The Maasai community, The Swahili community"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Kikuyu community
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: G2-CA-VIS-01",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " We can draw pictures of things we see in our environment. What is the technique of drawing where you show one side of an object as if you are looking at it from the side?,
      options: [Side view drawing, Front view drawing, Top view drawing", "Back view drawing].sort(() => Math.random() - 0.5),
      correctAnswer: Side view drawing"
    })
  },
  {
    id: "G2-CA-VIS-02",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We can create texture in our drawings by using different lines. What type of line is used to show a rough surface?,
      options: [Curved lines, Straight lines, "Dotted lines, Wavy lines"].sort(() => Math.random() - 0.5),
      correctAnswer: "Curved lines
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: G2-CA-VIS-03",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Different types of paint are used for different surfaces. What type of paint is commonly used for painting on paper?,
      options: [Poster paint, Oil paint, Enamel paint", "Acrylic paint].sort(() => Math.random() - 0.5),
      correctAnswer: Poster paint"
    })
  },
  {
    id: "G2-CA-VIS-04",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We can create different tones by mixing paint with water. What do we call a painting technique where water is used to thin the paint?,
      options: [Watercolor painting, Oil painting, "Acrylic painting, Spray painting"].sort(() => Math.random() - 0.5),
      correctAnswer: "Watercolor painting
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: G2-CA-VIS-05",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We can model different objects using clay and other materials. What is it called when you shape clay by pulling and squeezing it with your hands?,
      options: [Hand modelling, Moulding, Carving", "Casting].sort(() => Math.random() - 0.5),
      correctAnswer: Hand modelling"
    })
  },
  {
    id: "G2-CA-VIS-06",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Modelling with clay allows us to create three-dimensional sculptures. What is a sculpture that represents a person called?,
      options: [A figurine, A building, "A tree, A car"].sort(() => Math.random() - 0.5),
      correctAnswer: "A figurine
    })
  },

  // --- VISUAL ARTS: CRAFT MAKING (2 Materials) ---
  {
    id: G2-CA-VIS-07",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Craft Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Craft making can create both decorative and functional items. Which of the following is a functional item that can be made through craft making?,
      options: [A woven basket, A painting, A drawing", "A photograph].sort(() => Math.random() - 0.5),
      correctAnswer: A woven basket"
    })
  },
  {
    id: "G2-CA-VIS-08",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Craft Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Beadwork is a popular craft in many Kenyan communities. What is beadwork commonly used to make in Kenya?,
      options: [Jewelry and ornaments, Houses, "Cars, Books"].sort(() => Math.random() - 0.5),
      correctAnswer: "Jewelry and ornaments
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: G2-CA-DRA-01",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Storytelling is an important art form that preserves culture and traditions. Why is storytelling important in Kenyan culture?,
      options: [It passes on knowledge and traditions from generation to generation., It is only for entertainment., It is a new practice.", "It is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: It passes on knowledge and traditions from generation to generation."
    })
  },
  {
    id: "G2-CA-DRA-02",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Stories have different parts that make them interesting. What is the beginning of a story called where we meet the characters?,
      options: [The introduction, The climax, "The resolution, The ending"].sort(() => Math.random() - 0.5),
      correctAnswer: "The introduction
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: G2-CA-DRA-03",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Dramatization brings stories to life through acting. What is the place where a dramatization takes place called?,
      options: [A stage, A classroom, A field", "A room].sort(() => Math.random() - 0.5),
      correctAnswer: A stage"
    })
  },
  {
    id: "G2-CA-DRA-04",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Costumes and props help make dramatizations more realistic. What is the purpose of using costumes in a dramatization?,
      options: [To help actors look like the characters they are playing., To make the actors comfortable., "To distract the audience., To make the play longer."].sort(() => Math.random() - 0.5),
      correctAnswer: "To help actors look like the characters they are playing.
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: G2-CA-DRA-05",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Puppetry is a special way to tell stories using puppets. What is a puppet that is controlled by strings from above called?,
      options: [A marionette, A hand puppet, A shadow puppet", "A finger puppet].sort(() => Math.random() - 0.5),
      correctAnswer: A marionette"
    })
  },
  {
    id: "G2-CA-DRA-06",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Puppets can be used to teach important messages. What is the person who operates a puppet called?,
      options: [A puppeteer, A puppeteer, "An actor, A dancer"].sort(() => Math.random() - 0.5),
      correctAnswer: "A puppeteer
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: G2-CA-DRA-07",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Role Play",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Role play helps us understand different perspectives. Why is role play a useful activity in learning?,
      options: [It helps us understand how others think and feel., It is just for fun., It is only for games.", "It is not educational.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps us understand how others think and feel."
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: "G2-CA-EXP-01",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Designs can be created by combining different shapes and colors. What is a design that is created by repeating shapes in a planned way called?,
      options: [A pattern, A picture, "A drawing, A painting"].sort(() => Math.random() - 0.5),
      correctAnswer: "A pattern
    })
  },
  {
    id: G2-CA-EXP-02",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Many traditional Kenyan fabrics use repeating patterns. What is the colorful patterned fabric that is popular in Kenya called?,
      options: [Kitenge, Kente, Mud cloth", "Bogolan].sort(() => Math.random() - 0.5),
      correctAnswer: Kitenge"
    })
  },

  // --- CREATIVE EXPRESSION: COLLAGE MAKING (2 Materials) ---
  {
    id: "G2-CA-EXP-03",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Collage Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Collage is a way of creating art by sticking different materials together. What is the main tool used to stick materials together in a collage?,
      options: [Glue, Paint, "Pencil, Scissors"].sort(() => Math.random() - 0.5),
      correctAnswer: "Glue
    })
  },
  {
    id: G2-CA-EXP-04",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Collage Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Many different materials can be used to make a collage. Which of the following materials is commonly used in a collage?,
      options: [Paper, fabric, and leaves., Metal and glass., Plastic and rubber.", "Wood and stone.].sort(() => Math.random() - 0.5),
      correctAnswer: Paper, fabric, and leaves."
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: "G2-CA-EXP-05",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "We can write different types of creative texts. What is a short piece of writing that expresses personal thoughts and feelings called?,
      options: [A diary entry, A poem, "A story, A letter"].sort(() => Math.random() - 0.5),
      correctAnswer: "A diary entry
    })
  },
  {
    id: G2-CA-EXP-06",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Writing stories allows us to be creative and imagine new worlds. What do we call the people or animals in a story?,
      options: [Characters, Settings, Plots", "Themes].sort(() => Math.random() - 0.5),
      correctAnswer: Characters"
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (2 Materials) ---
  {
    id: "G2-CA-APP-01",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Nature inspires many artists and their work. What is a natural landscape that can inspire artists to create beautiful paintings?,
      options: [The Great Rift Valley, A city skyline, "A market place, A shopping mall"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Great Rift Valley
    })
  },
  {
    id: G2-CA-APP-02",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Nature",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Wildlife is a source of inspiration for many Kenyan artists. Which of the following is a majestic African animal that is often depicted in art?,
      options: [A lion, A dog, A goat", "A chicken].sort(() => Math.random() - 0.5),
      correctAnswer: A lion"
    })
  },

  // --- APPRECIATION: APPRECIATING CULTURE (1 Material) ---
  {
    id: "G2-CA-APP-03",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Culture,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya has a rich and diverse culture that is expressed through art. What is one way that Kenyan culture is expressed through creative arts?,
      options: [Through traditional songs, dances, and crafts., Only through paintings., "Only through writing., Only through photography."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through traditional songs, dances, and crafts.
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: G2-CA-APP-04",
    grade: "Grade 2,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We can appreciate artwork by using art vocabulary. What is the way to talk about the arrangement of objects in a painting?,
      options: [The composition, The color, The shape", "The line].sort(() => Math.random() - 0.5),
      correctAnswer: The composition"
    })
  },
  {
    id: "G2-CA-APP-05",
    grade: "Grade 2",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "When we look at art, we can identify different elements. What are the three primary colors in art?,
      options: [Red, blue, and yellow, Red, green, and blue", "Orange, green, and purple, Yellow, purple, and red"].sort(() => Math.random() - 0.5),
      correctAnswer: "Red, blue, and yellow
    })
  }`n// =========================================================================
// GRADE 3: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
// =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: G3-CA-MUS-01",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When we listen to music, we can identify different instruments and sounds. What is the term for the pattern of sounds and silences in music?,
      options: [Rhythm, Melody, Harmony", "Dynamics].sort(() => Math.random() - 0.5),
      correctAnswer: Rhythm"
    })
  },
  {
    id: "G3-CA-MUS-02",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: "Music can be loud or soft, which is called dynamics. What is the term for very loud in music?,
      options: [Fortissimo, Pianissimo", "Crescendo, Decrescendo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fortissimo
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: G3-CA-MUS-03",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " We can improve our singing by using proper techniques. What is the correct way to breathe when singing?,
      options: [Take deep breaths from the diaphragm., Take shallow breaths from the chest., Hold your breath.", "Breathe only through your nose.].sort(() => Math.random() - 0.5),
      correctAnswer: Take deep breaths from the diaphragm."
    })
  },
  {
    id: "G3-CA-MUS-04",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Folk songs are traditional songs that tell stories about a community. Why are folk songs important in preserving culture?,
      options: [They pass down history and traditions through generations., They are only for entertainment., "They are sung only by children., They have no meaning."].sort(() => Math.random() - 0.5),
      correctAnswer: "They pass down history and traditions through generations.
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: G3-CA-MUS-05",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Musical instruments are grouped into families based on how they produce sound. Which family of instruments includes the flute and trumpet?,
      options: [Wind instruments, String instruments, Percussion instruments", "Keyboard instruments].sort(() => Math.random() - 0.5),
      correctAnswer: Wind instruments"
    })
  },
  {
    id: "G3-CA-MUS-06",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "String instruments produce sound when their strings vibrate. Which of the following is a traditional Kenyan string instrument?,
      options: [The orutu, The drum, "The kayamba, The horn"].sort(() => Math.random() - 0.5),
      correctAnswer: "The orutu
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: G3-CA-MUS-07",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Dance is an important part of creative arts that combines movement and music. What is the dance of the Maasai community that involves jumping called?,
      options: [The adumu, The mwomboko, The isikuti", "The chakacha].sort(() => Math.random() - 0.5),
      correctAnswer: The adumu"
    })
  },
  {
    id: "G3-CA-MUS-08",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Choreography is the art of designing dance movements. What is the person who creates dance movements called?,
      options: [A choreographer, A dancer, "A singer, A musician"].sort(() => Math.random() - 0.5),
      correctAnswer: "A choreographer
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: G3-CA-VIS-01",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Shading adds depth and dimension to drawings. What is the technique of using different values of pencil to create light and dark areas?,
      options: [Shading, Outlining, Sketching", "Coloring].sort(() => Math.random() - 0.5),
      correctAnswer: Shading"
    })
  },
  {
    id: "G3-CA-VIS-02",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "We can draw from observation by looking carefully at objects. What do we call a drawing of a person in which the artist focuses on capturing a likeness?,
      options: [A portrait, A landscape, "A still life, An abstract"].sort(() => Math.random() - 0.5),
      correctAnswer: "A portrait
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: G3-CA-VIS-03",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When painting, we use a color wheel to understand color relationships. What are colors that are opposite each other on the color wheel called?,
      options: [Complementary colors, Primary colors, Secondary colors", "Analogous colors].sort(() => Math.random() - 0.5),
      correctAnswer: Complementary colors"
    })
  },
  {
    id: "G3-CA-VIS-04",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different painting techniques can create different effects. What is the technique of applying small dots of color that blend together when viewed from a distance?,
      options: [Pointillism, Impressionism, "Expressionism, Abstract"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pointillism
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: G3-CA-VIS-05",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Clay modelling involves many techniques to create different forms. What technique involves rolling clay into long snake-like shapes?,
      options: [Coiling, Slab building, Pinch pottery", "Wheel throwing].sort(() => Math.random() - 0.5),
      correctAnswer: Coiling"
    })
  },
  {
    id: "G3-CA-VIS-06",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Drying and firing clay makes it permanent and durable. What is the process of heating clay in an oven called?,
      options: [Firing, Drying, "Glazing, Moulding"].sort(() => Math.random() - 0.5),
      correctAnswer: "Firing
    })
  },

  // --- VISUAL ARTS: CRAFT MAKING (2 Materials) ---
  {
    id: G3-CA-VIS-07",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Craft Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Many communities in Kenya are known for specific crafts. Which community in Kenya is famous for their beautiful Kiondoo baskets?,
      options: [The Kikuyu community, The Luo community, The Maasai community", "The Swahili community].sort(() => Math.random() - 0.5),
      correctAnswer: The Kikuyu community"
    })
  },
  {
    id: "G3-CA-VIS-08",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Craft Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Leather craft is another important Kenyan traditional craft. What is leather used to make in traditional Kenyan communities?,
      options: [Sandals, bags, and shields., Plates and cups., "Tables and chairs., Pens and pencils."].sort(() => Math.random() - 0.5),
      correctAnswer: "Sandals, bags, and shields.
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: G3-CA-DRA-01",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kenyan traditional stories often teach important values. Which of the following is a character that commonly appears in Kenyan folktales?,
      options: [A clever hare, A fierce lion, A wise elephant", "A cunning snake].sort(() => Math.random() - 0.5),
      correctAnswer: A clever hare"
    })
  },
  {
    id: "G3-CA-DRA-02",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Trickster tales are common in African storytelling. What is the role of the trickster character in African stories?,
      options: [To teach lessons through cleverness and wit., To defeat the hero., "To destroy the village., To steal from the people."].sort(() => Math.random() - 0.5),
      correctAnswer: "To teach lessons through cleverness and wit.
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: G3-CA-DRA-03",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Dramatization requires various skills and techniques. What is the ability to speak clearly and be heard by the audience called?,
      options: [Voice projection, Articulation, Inflection", "Pacing].sort(() => Math.random() - 0.5),
      correctAnswer: Voice projection"
    })
  },
  {
    id: "G3-CA-DRA-04",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Actors use their bodies and voices to portray characters. What is the technique of changing your voice to sound like a different character called?,
      options: [Voice modulation, Voice projection, "Voice rest, Voice training"].sort(() => Math.random() - 0.5),
      correctAnswer: "Voice modulation
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: G3-CA-DRA-05",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Puppets can be made from many different materials. Which of the following materials is commonly used to make shadow puppets?,
      options: [Cardboard or leather, Clay, Metal", "Glass].sort(() => Math.random() - 0.5),
      correctAnswer: Cardboard or leather"
    })
  },
  {
    id: "G3-CA-DRA-06",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Shadow puppetry involves creating stories with shadows on a screen. What is the light source used behind the screen in shadow puppetry called?,
      options: [A spotlight, A lamp, "A candle, A torch"].sort(() => Math.random() - 0.5),
      correctAnswer: "A spotlight
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: G3-CA-DRA-07",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Role Play",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Role play helps to develop empathy and understanding. Why is role play beneficial for building social skills?,
      options: [It helps us understand others' perspectives and practice communication., It is only for performance., It is a way to avoid reality.", "It is just a game.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps us understand others' perspectives and practice communication."
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: "G3-CA-EXP-01",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Symmetry is an important principle of design. What do we call a design where one half is a mirror image of the other?,
      options: [Symmetric design, Asymmetric design, "Abstract design, Organic design"].sort(() => Math.random() - 0.5),
      correctAnswer: "Symmetric design
    })
  },
  {
    id: G3-CA-EXP-02",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Repetition and rhythm create visual interest in designs. What is the principle of design where different elements are placed to create a sense of movement?,
      options: [Rhythm, Balance, Unity", "Variety].sort(() => Math.random() - 0.5),
      correctAnswer: Rhythm"
    })
  },

  // --- CREATIVE EXPRESSION: COLLAGE MAKING (2 Materials) ---
  {
    id: "G3-CA-EXP-03",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Collage Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Collages can have different textures by using various materials. What type of collage is made from cutting and pasting paper shapes?,
      options: [Paper collage, Fabric collage, "Mixed media collage, Digital collage"].sort(() => Math.random() - 0.5),
      correctAnswer: "Paper collage
    })
  },
  {
    id: G3-CA-EXP-04",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Collage Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Collage is a form of creative expression that allows for endless possibilities. Why is collage a versatile art medium?,
      options: [It uses many materials to create textures, layers, and visual interest., It only uses one material., It cannot be used with other art forms.", "It is only for children.].sort(() => Math.random() - 0.5),
      correctAnswer: It uses many materials to create textures, layers, and visual interest."
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: "G3-CA-EXP-05",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Creative writing uses literary devices to make the text more interesting. What is the comparison that uses like or as to describe something?,
      options: [Simile, Metaphor, "Personification, Alliteration"].sort(() => Math.random() - 0.5),
      correctAnswer: "Simile
    })
  },
  {
    id: G3-CA-EXP-06",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A story has a structure with a beginning, middle, and end. What is the most exciting part of a story called?,
      options: [The climax, The introduction, The resolution", "The ending].sort(() => Math.random() - 0.5),
      correctAnswer: The climax"
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (2 Materials) ---
  {
    id: "G3-CA-APP-01",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Natural phenomena like sunsets and sunrises inspire beautiful artwork. What color palette often appears during a Kenyan sunset?,
      options: [Orange, red, and purple, Blue and green, "Yellow and white, Black and white"].sort(() => Math.random() - 0.5),
      correctAnswer: "Orange, red, and purple
    })
  },
  {
    id: G3-CA-APP-02",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Nature",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Mountains and hills in Kenya are often featured in art. Which mountain is the highest in Kenya and often appears in paintings?,
      options: [Mount Kenya, Mount Kilimanjaro, Mount Elgon", "Mount Longonot].sort(() => Math.random() - 0.5),
      correctAnswer: Mount Kenya"
    })
  },

  // --- APPRECIATION: APPRECIATING CULTURE (1 Material) ---
  {
    id: "G3-CA-APP-03",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Culture,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenyan cultures have unique artistic traditions. What is the traditional Maasai beading style that is recognized globally?,
      options: [Colorful geometric patterns, Animal designs, "Floral patterns, Abstract art"].sort(() => Math.random() - 0.5),
      correctAnswer: "Colorful geometric patterns
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: G3-CA-APP-04",
    grade: "Grade 3,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Art has different purposes and meanings. What is the term for art that aims to communicate a message or story?,
      options: [Narrative art, Decorative art, Abstract art", "Functional art].sort(() => Math.random() - 0.5),
      correctAnswer: Narrative art"
    })
  },
  {
    id: "G3-CA-APP-05",
    grade: "Grade 3",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kenya has many talented artists who have gained international recognition. What is the name of the Kenyan artist known for his sculpting skills?,
      options: [Elijah Kwato, John Wanjau, "Samuel Kariuki, David Mwangi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Elijah Kwato
    })
  },

// =========================================================================
// GRADE 4: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
// =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: G4-CA-MUS-01",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Active listening involves paying close attention to all the elements of music. What is the element of music that describes the speed of the music?,
      options: [Tempo, Dynamics, Timbre", "Pitch].sort(() => Math.random() - 0.5),
      correctAnswer: Tempo"
    })
  },
  {
    id: "G4-CA-MUS-02",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: "Different genres of music have distinct characteristics. What is the genre of music from Kenya that blends traditional rhythms with modern sounds?,
      options: [Benga, Reggae, "Jazz, Classical"].sort(() => Math.random() - 0.5),
      correctAnswer: "Benga
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: G4-CA-MUS-03",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Vocal warm-ups are important before singing. Which of the following is a benefit of vocal warm-ups before singing?,
      options: [They prepare your voice and prevent straining., They make your voice louder., They change your pitch.", "They make you sing faster.].sort(() => Math.random() - 0.5),
      correctAnswer: They prepare your voice and prevent straining."
    })
  },
  {
    id: "G4-CA-MUS-04",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Part singing involves different singers performing different melodies. What is the term for a song sung by two people with different melodies?,
      options: [Duet, Solo, "Choir, Quartet"].sort(() => Math.random() - 0.5),
      correctAnswer: "Duet
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: G4-CA-MUS-05",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The arrangement of notes in a musical scale forms the foundation of music. What is the major scale pattern in terms of steps?,
      options: [Whole, whole, half, whole, whole, whole, half, Whole, half, whole, whole, whole, half, whole, Half, whole, half, whole, whole, half, whole", "Whole, whole, whole, half, whole, whole, half].sort(() => Math.random() - 0.5),
      correctAnswer: Whole, whole, half, whole, whole, whole, half"
    })
  },
  {
    id: "G4-CA-MUS-06",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Intervals are the distance between notes in music. What is the distance of eight notes called in music?,
      options: [An octave, A fifth, "A third, A sixth"].sort(() => Math.random() - 0.5),
      correctAnswer: "An octave
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: G4-CA-MUS-07",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Dance forms from around the world have different styles and techniques. What is the name of the traditional dance from the coastal region of Kenya?,
      options: [Chakacha, Mwomboko, Isikuti", "Adumu].sort(() => Math.random() - 0.5),
      correctAnswer: Chakacha"
    })
  },
  {
    id: "G4-CA-MUS-08",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Contemporary dance combines elements from various styles. What is the term for dance that tells a story through movements without words?,
      options: [Expressive dance, Ballet, "Jazz, Hip-hop"].sort(() => Math.random() - 0.5),
      correctAnswer: "Expressive dance
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: G4-CA-VIS-01",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Linear perspective is a technique used to create depth in drawing. What is the point where all lines converge in a perspective drawing called?,
      options: [Vanishing point, Focus point, Center point", "Horizon point].sort(() => Math.random() - 0.5),
      correctAnswer: Vanishing point"
    })
  },
  {
    id: "G4-CA-VIS-02",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Cross-hatching is a technique used to create shading in drawings. How is cross-hatching different from regular hatching?,
      options: [Cross-hatching uses lines that go in multiple directions., Cross-hatching uses only straight lines., "Cross-hatching uses only curved lines., Cross-hatching uses dots."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cross-hatching uses lines that go in multiple directions.
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: G4-CA-VIS-03",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Acrylic paint is a versatile medium for painting. What is a key advantage of using acrylic paint over other types of paint?,
      options: [It dries quickly and can be used on many surfaces., It is very expensive., It takes a long time to dry.", "It is only for professionals.].sort(() => Math.random() - 0.5),
      correctAnswer: It dries quickly and can be used on many surfaces."
    })
  },
  {
    id: "G4-CA-VIS-04",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Oil painting allows for blending and layering of colors. What is the solvent commonly used to thin oil paint?,
      options: [Turpentine, Water, "Alcohol, Vinegar"].sort(() => Math.random() - 0.5),
      correctAnswer: "Turpentine
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: G4-CA-VIS-05",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Modelling materials can be natural or synthetic. What is a synthetic modelling material that hardens when heated or dried?,
      options: [Polymer clay, Terracotta, Stoneware", "Earthenware].sort(() => Math.random() - 0.5),
      correctAnswer: Polymer clay"
    })
  },
  {
    id: "G4-CA-VIS-06",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Armatures are used to support large or complex clay sculptures. What material is commonly used to make an armature?,
      options: [Wire, Paper, "Plastic, Wood"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wire
    })
  },

  // --- VISUAL ARTS: CRAFT MAKING (2 Materials) ---
  {
    id: G4-CA-VIS-07",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Craft Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Wood carving is an important craft in many Kenyan communities. What is the traditional wood carving from the Swahili coast called?,
      options: [Mahogany carvings, Acacia carvings, Ebony carvings", "Teak carvings].sort(() => Math.random() - 0.5),
      correctAnswer: Mahogany carvings"
    })
  },
  {
    id: "G4-CA-VIS-08",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Craft Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Recycling and craft making can go together to create beautiful art. Why is it beneficial to use recycled materials in craft making?,
      options: [It is environmentally friendly and encourages creativity., It is cheaper., "It is easier., It is faster."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is environmentally friendly and encourages creativity.
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: G4-CA-DRA-01",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Oral storytelling in Kenya is a tradition passed down through generations. What is the role of the 'griot' in many West African cultures?,
      options: [A storyteller who preserves history and traditions., A drummer, A dancer", "A singer].sort(() => Math.random() - 0.5),
      correctAnswer: A storyteller who preserves history and traditions."
    })
  },
  {
    id: "G4-CA-DRA-02",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Stories can be told through different techniques and formats. What is a story that is written in the form of a letter or diary called?,
      options: [Epistolary, Narrative, "Memoir, Biography"].sort(() => Math.random() - 0.5),
      correctAnswer: "Epistolary
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: G4-CA-DRA-03",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Stage directions in a play tell actors what to do. What is the term for the description of the setting and character actions in a play script?,
      options: [Stage directions, Dialogue, Monologue", "Scene].sort(() => Math.random() - 0.5),
      correctAnswer: Stage directions"
    })
  },
  {
    id: "G4-CA-DRA-04",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Blocking is the term for an actor's movement on stage. Why is blocking important in a dramatization?,
      options: [It ensures actors are visible and the story is clear to the audience., It makes the play longer., "It confuses the actors., It is only for professional actors."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures actors are visible and the story is clear to the audience.
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: G4-CA-DRA-05",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Rod puppets are controlled by rods attached to the puppet's limbs. What is a special feature of rod puppets that makes them versatile?,
      options: [They allow for complex movements and gestures., They are very heavy., They are invisible.", "They are very small.].sort(() => Math.random() - 0.5),
      correctAnswer: They allow for complex movements and gestures."
    })
  },
  {
    id: "G4-CA-DRA-06",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bunraku is a traditional form of puppetry from Japan. What is unique about Bunraku puppets?,
      options: [They are large and operated by multiple puppeteers., They are very small., "They are operated by one person., They are made of paper."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are large and operated by multiple puppeteers.
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: G4-CA-DRA-07",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Role Play",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Improvisation is a key skill in role play. What is the skill of performing without preparation or a script called?,
      options: [Improvisation, Memorization, Interpretation", "Recitation].sort(() => Math.random() - 0.5),
      correctAnswer: Improvisation"
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: "G4-CA-EXP-01",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Tessellation is a pattern created with shapes that fit together without gaps. Which famous Dutch artist is known for his tessellation designs?,
      options: [M.C. Escher, Pablo Picasso, "Vincent van Gogh, Claude Monet"].sort(() => Math.random() - 0.5),
      correctAnswer: "M.C. Escher
    })
  },
  {
    id: G4-CA-EXP-02",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fractals are repeating patterns found in nature and mathematics. Which of the following is a natural example of a fractal pattern?,
      options: [A fern leaf, A square, A circle", "A rectangle].sort(() => Math.random() - 0.5),
      correctAnswer: A fern leaf"
    })
  },

  // --- CREATIVE EXPRESSION: COLLAGE MAKING (2 Materials) ---
  {
    id: "G4-CA-EXP-03",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Collage Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Mixed media collage combines different art techniques. What is mixed media collage in art?,
      options: [Combining two or more art mediums in a single artwork., Using only paper., "Using only paint., Using only digital tools."].sort(() => Math.random() - 0.5),
      correctAnswer: "Combining two or more art mediums in a single artwork.
    })
  },
  {
    id: G4-CA-EXP-04",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Collage Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Matting and framing are important for preserving and displaying collages. Why is a collage matted and framed?,
      options: [To protect it, enhance its appearance, and display it professionally., To make it smaller., To hide the edges.", "To change the colors.].sort(() => Math.random() - 0.5),
      correctAnswer: To protect it, enhance its appearance, and display it professionally."
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: "G4-CA-EXP-05",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different genres of writing have distinct characteristics. What genre of writing uses imagination to create stories that are not based on real events?,
      options: [Fiction, Non-fiction, "Biography, Poetry"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fiction
    })
  },
  {
    id: G4-CA-EXP-06",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Poetry uses rhythm and rhyme to express ideas. What is the pattern of rhymes at the end of lines in a poem called?,
      options: [Rhyme scheme, Rhythm pattern, Meter", "Verse].sort(() => Math.random() - 0.5),
      correctAnswer: Rhyme scheme"
    })
  },

  // --- MEDIA ARTS: DIGITAL ART (2 Materials) ---
  {
    id: "G4-CA-MED-01",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Digital Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Digital art involves creating images using computer software. Which of the following is a popular software used for digital art and illustration?,
      options: [Adobe Photoshop, Microsoft Word, "Google Docs, Excel"].sort(() => Math.random() - 0.5),
      correctAnswer: "Adobe Photoshop
    })
  },
  {
    id: G4-CA-MED-02",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Digital Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vector graphics are a type of digital art that use mathematical equations. What is a key advantage of vector graphics over raster images?,
      options: [They can be scaled without losing quality., They are more colorful., They are easier to create.", "They are faster to render.].sort(() => Math.random() - 0.5),
      correctAnswer: They can be scaled without losing quality."
    })
  },

  // --- MEDIA ARTS: PHOTOGRAPHY (2 Materials) ---
  {
    id: "G4-CA-MED-03",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Photography,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Photography is the art of capturing images with a camera. What is the part of a camera that controls the amount of light reaching the sensor called?,
      options: [Aperture, Shutter, "Lens, Flash"].sort(() => Math.random() - 0.5),
      correctAnswer: "Aperture
    })
  },
  {
    id: G4-CA-MED-04",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Photography",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Composition is an important principle in photography. What is the rule that suggests dividing an image into thirds to place your subject at intersections?,
      options: [Rule of thirds, Rule of balance, Rule of lines", "Rule of symmetry].sort(() => Math.random() - 0.5),
      correctAnswer: Rule of thirds"
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (1 Material) ---
  {
    id: "G4-CA-APP-01",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Nature offers endless inspiration for artists and photographers. What is the term for art that is created using natural materials found in nature?,
      options: [Land art, Abstract art, "Portrait art, Still life"].sort(() => Math.random() - 0.5),
      correctAnswer: "Land art
    })
  },

  // --- APPRECIATION: APPRECIATING CULTURE (1 Material) ---
  {
    id: G4-CA-APP-02",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Culture",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Artistic expressions across different cultures share common themes. Why is it important to appreciate and respect art from different cultures?,
      options: [It builds cultural awareness, understanding, and appreciation of diversity., It makes us better artists., It is required in school.", "It is popular.].sort(() => Math.random() - 0.5),
      correctAnswer: It builds cultural awareness, understanding, and appreciation of diversity."
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: "G4-CA-APP-03",
    grade: "Grade 4",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Art criticism involves analyzing and evaluating artworks. What are the four steps of art criticism in order?,
      options: [Description, Analysis, Interpretation, Judgment, Judgment, Description, Analysis, Interpretation, "Analysis, Description, Judgment, Interpretation, Interpretation, Judgment, Analysis, Description"].sort(() => Math.random() - 0.5),
      correctAnswer: "Description, Analysis, Interpretation, Judgment
    })
  },
  {
    id: G4-CA-APP-04",
    grade: "Grade 4,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Art has different functions and purposes in society. What is the function of art when it is used to record historical events?,
      options: [Historical documentation, Visual pleasure, Social commentary", "Decoration].sort(() => Math.random() - 0.5),
      correctAnswer: Historical documentation"
    })
  }`n// =========================================================================
// GRADE 5: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
// =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: "G5-CA-MUS-01",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: "Music can be analyzed through its different elements to understand its structure. What is the term for the quality of sound that distinguishes one instrument or voice from another?,
      options: [Timbre, Pitch, "Dynamics, Tempo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Timbre
    })
  },
  {
    id: G5-CA-MUS-02",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " African music has distinct characteristics that set it apart from other music traditions. What is a common feature of many African musical styles?,
      options: [Polyrhythms and call-and-response patterns, Simple melodies only, No instruments", "Single rhythm only].sort(() => Math.random() - 0.5),
      correctAnswer: Polyrhythms and call-and-response patterns"
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: "G5-CA-MUS-03",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sight-reading is an important skill for musicians and singers. What does it mean to sight-read a piece of music?,
      options: [To read and perform a piece at first sight without preparation., To memorize a piece., "To listen and repeat a piece., To write down a piece."].sort(() => Math.random() - 0.5),
      correctAnswer: "To read and perform a piece at first sight without preparation.
    })
  },
  {
    id: G5-CA-MUS-04",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vocal harmony involves multiple voices singing different notes together. What is a group of singers who perform together with multiple vocal parts called?,
      options: [A choir, A band, An orchestra", "A soloist].sort(() => Math.random() - 0.5),
      correctAnswer: A choir"
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: "G5-CA-MUS-05",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Playing a musical instrument requires understanding of music notation. What are the five lines on which music is written called?,
      options: [The stave, The staff, "The scale, The clef"].sort(() => Math.random() - 0.5),
      correctAnswer: "The stave
    })
  },
  {
    id: G5-CA-MUS-06",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The guitar is a popular instrument worldwide, including in Kenya. What is the technique of plucking the strings of a guitar with individual fingers called?,
      options: [Fingerpicking, Strumming, Tapping", "Sliding].sort(() => Math.random() - 0.5),
      correctAnswer: Fingerpicking"
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: "G5-CA-MUS-07",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Dance notation is a way to record dance movements. What is the best known system for notating dance movements?,
      options: [Labanotation, Benesh notation, "Eshkol-Wachman, Conté notation"].sort(() => Math.random() - 0.5),
      correctAnswer: "Labanotation
    })
  },
  {
    id: G5-CA-MUS-08",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " African dance often has cultural and social significance. What is the traditional dance of the Luo community in Kenya characterized by?,
      options: [Rhythmic hip movements and expressive gestures., High jumping., Slow graceful movements.", "Fast spinning.].sort(() => Math.random() - 0.5),
      correctAnswer: Rhythmic hip movements and expressive gestures."
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: "G5-CA-VIS-01",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Different drawing techniques can create different effects. What is the technique of creating a drawing by using dots to form an image called?,
      options: [Stippling, Hatching, "Cross-hatching, Scumbling"].sort(() => Math.random() - 0.5),
      correctAnswer: "Stippling
    })
  },
  {
    id: G5-CA-VIS-02",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Gesture drawing is a technique used to capture movement and form quickly. What is the primary purpose of gesture drawing?,
      options: [To capture the essence of a figure's movement and pose., To create a detailed portrait., To draw a landscape.", "To copy a photograph.].sort(() => Math.random() - 0.5),
      correctAnswer: To capture the essence of a figure's movement and pose."
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: "G5-CA-VIS-03",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Watercolor painting is known for its transparent and fluid effects. What is a key characteristic of watercolor painting?,
      options: [The transparency of the paint allows light to reflect through layers., It is very thick and opaque., "It dries very slowly., It is only for professionals."].sort(() => Math.random() - 0.5),
      correctAnswer: "The transparency of the paint allows light to reflect through layers.
    })
  },
  {
    id: G5-CA-VIS-04",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Impressionism was an art movement that focused on capturing light and movement. Which famous artist is associated with Impressionism?,
      options: [Claude Monet, Pablo Picasso, Vincent van Gogh", "Salvador Dali].sort(() => Math.random() - 0.5),
      correctAnswer: Claude Monet"
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: "G5-CA-VIS-05",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bronze is a common material used for casting sculptures. What is the process of creating a sculpture by pouring liquid bronze into a mold called?,
      options: [Bronze casting, Carving, "Modelling, Assembling"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bronze casting
    })
  },
  {
    id: G5-CA-VIS-06",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ceramic sculpture involves creating art with clay and firing it. What is the term for the glaze applied to ceramics to make it smooth and sometimes colorful?,
      options: [Ceramic glaze, Clay slip, Engobe", "Underglaze].sort(() => Math.random() - 0.5),
      correctAnswer: Ceramic glaze"
    })
  },

  // --- VISUAL ARTS: PRINT MAKING (2 Materials) ---
  {
    id: "G5-CA-VIS-07",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Print Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Print making is a versatile art form that allows for multiple copies of an image. What is the technique where ink is applied to a raised surface and printed?,
      options: [Relief printing, Intaglio printing, "Lithography, Screen printing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Relief printing
    })
  },
  {
    id: G5-CA-VIS-08",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Print Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Screen printing uses a stencil to create designs on fabric or paper. Why is screen printing popular for t-shirt designs?,
      options: [It allows for quick reproduction of the same design., It is expensive., It only works on paper.", "It takes a long time.].sort(() => Math.random() - 0.5),
      correctAnswer: It allows for quick reproduction of the same design."
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: "G5-CA-DRA-01",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Oral storytelling is a tradition that has been practiced for centuries. What are some techniques that storytellers use to engage their audience?,
      options: [Voice modulation, gestures, and dramatic pauses., Reading from a book., "Looking at the floor., Speaking monotonously."].sort(() => Math.random() - 0.5),
      correctAnswer: "Voice modulation, gestures, and dramatic pauses.
    })
  },
  {
    id: G5-CA-DRA-02",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Storytelling is a way to preserve cultural heritage. Why is it important to keep oral storytelling traditions alive in modern times?,
      options: [It preserves cultural identity and passes down wisdom., It is only for entertainment., It is not relevant today.", "It is easier to write stories.].sort(() => Math.random() - 0.5),
      correctAnswer: It preserves cultural identity and passes down wisdom."
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: "G5-CA-DRA-03",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "In a play, the script provides the dialogue and structure. What is a long speech by one character in a play called?,
      options: [Monologue, Dialogue", "Aside, Soliloquy"].sort(() => Math.random() - 0.5),
      correctAnswer: "Monologue
    })
  },
  {
    id: G5-CA-DRA-04",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Props and costumes enhance a dramatization by making it more realistic. Which department in a theater production is responsible for creating the costumes and props?,
      options: [The design department, The writing department, The acting department", "The lighting department].sort(() => Math.random() - 0.5),
      correctAnswer: The design department"
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: "G5-CA-DRA-05",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Puppet theater combines puppetry with other art forms to create performances. What elements are often included in a puppet theater performance?,
      options: [Music, dialogue, and visual effects., Only puppets., "Only music., Only dialogue."].sort(() => Math.random() - 0.5),
      correctAnswer: "Music, dialogue, and visual effects.
    })
  },
  {
    id: G5-CA-DRA-06",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " In some forms of puppetry, the puppeteers are visible to the audience. What is the term for a puppet that is operated from below or from the side by a puppeteer who is visible?,
      options: [Muppet, Marionette, Shadow puppet", "Finger puppet].sort(() => Math.random() - 0.5),
      correctAnswer: Muppet"
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: "G5-CA-DRA-07",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Role Play,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Role play can be used in many contexts beyond just performing. How is role play used in education and training?,
      options: [To practice real-life situations and develop skills., To confuse students., "To waste time., To avoid real learning."].sort(() => Math.random() - 0.5),
      correctAnswer: "To practice real-life situations and develop skills.
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: G5-CA-EXP-01",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " African textile designs are known for their vibrant colors and patterns. What is the fabric from West Africa that uses a resist-dyeing technique to create intricate patterns?,
      options: [Mud cloth, Kente, Kitenge", "Bogolan].sort(() => Math.random() - 0.5),
      correctAnswer: Mud cloth"
    })
  },
  {
    id: "G5-CA-EXP-02",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Islamic art is famous for its geometric patterns and arabesque designs. What is the significance of geometric patterns in Islamic art?,
      options: [They represent the infinite nature of the universe and spirituality., They are just decorative., "They show animals., They are only for buildings."].sort(() => Math.random() - 0.5),
      correctAnswer: "They represent the infinite nature of the universe and spirituality.
    })
  },

  // --- CREATIVE EXPRESSION: COLLAGE MAKING (2 Materials) ---
  {
    id: G5-CA-EXP-03",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Collage Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Collage can be used to create powerful visual statements. What is a collage that uses photographs cut from magazines and books called?,
      options: [Photomontage, Paper collage, Mixed media", "Digital collage].sort(() => Math.random() - 0.5),
      correctAnswer: Photomontage"
    })
  },
  {
    id: "G5-CA-EXP-04",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Collage Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Decoupage is a form of collage that involves decorating objects with paper cutouts. What is the traditional decoupage technique from Italy called?,
      options: [Decoupage, Collage, "Papier-mâché, Quilling"].sort(() => Math.random() - 0.5),
      correctAnswer: "Decoupage
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: G5-CA-EXP-05",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The hero's journey is a common narrative pattern in storytelling. Who is the scholar who first identified the hero's journey narrative pattern?,
      options: [Joseph Campbell, Carl Jung, Sigmund Freud", "Vladimir Propp].sort(() => Math.random() - 0.5),
      correctAnswer: Joseph Campbell"
    })
  },
  {
    id: "G5-CA-EXP-06",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Plot structure is important for creating a compelling story. What are the five main stages of a story's plot called?,
      options: [Exposition, Rising Action, Climax, Falling Action, Resolution, Introduction, Body, Conclusion, Climax, "Beginning, Middle, End, Setup, Conflict, Resolution"].sort(() => Math.random() - 0.5),
      correctAnswer: "Exposition, Rising Action, Climax, Falling Action, Resolution
    })
  },

  // --- MEDIA ARTS: DIGITAL ART (2 Materials) ---
  {
    id: G5-CA-MED-01",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Digital Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pixel art is a form of digital art where images are created on a pixel-by-pixel basis. In what context did pixel art first become popular?,
      options: [In early video games and computer graphics., In printing., In photography.", "In painting.].sort(() => Math.random() - 0.5),
      correctAnswer: In early video games and computer graphics."
    })
  },
  {
    id: "G5-CA-MED-02",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Digital Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Digital art has grown to include many different styles and techniques. What is a popular platform among digital artists for creating art on tablets and computers?,
      options: [Procreate, Photoshop, "Illustrator, Paint.NET"].sort(() => Math.random() - 0.5),
      correctAnswer: "Procreate
    })
  },

  // --- MEDIA ARTS: PHOTOGRAPHY AND VIDEOGRAPHY (2 Materials) ---
  {
    id: G5-CA-MED-03",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Photography and Videography",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Videography involves capturing moving images and sound. What is the term for a single continuous recording in video production called?,
      options: [A take, A shot, A scene", "A clip].sort(() => Math.random() - 0.5),
      correctAnswer: A take"
    })
  },
  {
    id: "G5-CA-MED-04",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Photography and Videography,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Lighting is crucial in photography and videography to create the desired effect. What is the technique of lighting a subject from the side to create shadows called?,
      options: [Side lighting, Front lighting, "Back lighting, Top lighting"].sort(() => Math.random() - 0.5),
      correctAnswer: "Side lighting
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (1 Material) ---
  {
    id: G5-CA-APP-01",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Nature",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Nature has influenced artists for centuries, inspiring countless masterpieces. How has nature influenced the work of many Kenyan artists?,
      options: [They draw inspiration from the landscape, wildlife, and cultural connection to the land., They ignore nature., They only paint portraits.", "They only work in cities.].sort(() => Math.random() - 0.5),
      correctAnswer: They draw inspiration from the landscape, wildlife, and cultural connection to the land."
    })
  },

  // --- APPRECIATION: APPRECIATING CULTURE (1 Material) ---
  {
    id: "G5-CA-APP-02",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Culture,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Cultural festivals are important for preserving and promoting artistic traditions. Which Kenyan festival celebrates the Swahili culture and history of the coast?,
      options: [The Lamu Cultural Festival, The Mombasa Carnival, "The Lake Turkana Festival, The Maralal Camel Derby"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Lamu Cultural Festival
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: G5-CA-APP-03",
    grade: "Grade 5,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Art museums and galleries play an important role in preserving and displaying art. What is the largest museum in Kenya that houses a significant art collection?,
      options: [The Nairobi National Museum, The Mombasa Museum, The Kisumu Museum", "The Garissa Museum].sort(() => Math.random() - 0.5),
      correctAnswer: The Nairobi National Museum"
    })
  },
  {
    id: "G5-CA-APP-04",
    grade: "Grade 5",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Art can be viewed and appreciated in many different contexts. Why is it important to see art in person rather than just in photographs?,
      options: [To appreciate the scale, texture, and details that photos don't show., It is more expensive., "It is only for artists., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "To appreciate the scale, texture, and details that photos don't show.
    })
  },

// =========================================================================
// GRADE 6: 35 MATERIALS (KICD CREATIVE ARTS SYLLABUS)
// =========================================================================

  // --- MUSIC: LISTENING TO MUSIC (2 Materials) ---
  {
    id: G6-CA-MUS-01",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Music theory helps us understand the structure and elements of music. What is the term for a group of notes played together in a chord?,
      options: [Harmony, Melody, Rhythm", "Tempo].sort(() => Math.random() - 0.5),
      correctAnswer: Harmony"
    })
  },
  {
    id: "G6-CA-MUS-02",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Listening to Music",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "World music includes styles from different cultures around the globe. Which Kenyan music style is characterized by a fast tempo and intricate guitar melodies?,
      options: [Benga music, Reggae, "Soukous, Jazz"].sort(() => Math.random() - 0.5),
      correctAnswer: "Benga music
    })
  },

  // --- MUSIC: SINGING SONGS (2 Materials) ---
  {
    id: G6-CA-MUS-03",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Singing Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vocal range describes the notes a singer can comfortably sing. What are the four primary vocal ranges from highest to lowest?,
      options: [Soprano, Alto, Tenor, Bass, Tenor, Bass, Soprano, Alto, Alto, Soprano, Bass, Tenor", "Bass, Tenor, Alto, Soprano].sort(() => Math.random() - 0.5),
      correctAnswer: Soprano, Alto, Tenor, Bass"
    })
  },
  {
    id: "G6-CA-MUS-04",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Singing Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A cappella singing involves vocal music without instrumental accompaniment. What is a type of a cappella singing that originated in the United States?,
      options: [Barbershop, Gregorian chant, "Folk singing, Opera"].sort(() => Math.random() - 0.5),
      correctAnswer: "Barbershop
    })
  },

  // --- MUSIC: PLAYING INSTRUMENTS (2 Materials) ---
  {
    id: G6-CA-MUS-05",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Playing Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Musical scales are the building blocks of melody and harmony. What is the term for a scale with five notes per octave, commonly found in African and Asian music?,
      options: [Pentatonic scale, Major scale, Minor scale", "Chromatic scale].sort(() => Math.random() - 0.5),
      correctAnswer: Pentatonic scale"
    })
  },
  {
    id: "G6-CA-MUS-06",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Playing Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The piano is one of the most versatile instruments in music. What is the system used to indicate which notes to play with which fingers on the piano called?,
      options: [Finger numbering, Chord notation, "Staff notation, Tablature"].sort(() => Math.random() - 0.5),
      correctAnswer: "Finger numbering
    })
  },

  // --- MUSIC: MOVEMENT AND DANCE (2 Materials) ---
  {
    id: G6-CA-MUS-07",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Music,
    subtopic: "Movement and Dance",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Contemporary dance draws from various styles and techniques. Which of the following dance pioneers is known for developing the Graham technique?,
      options: [Martha Graham, Merce Cunningham, Isadora Duncan", "Bob Fosse].sort(() => Math.random() - 0.5),
      correctAnswer: Martha Graham"
    })
  },
  {
    id: "G6-CA-MUS-08",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Music",
    subtopic: "Movement and Dance,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Dance can be a form of communication and storytelling. What is the traditional dance form that originated in the Central Province of Kenya, known for its energetic jumps?,
      options: [The Mwomboko dance, The Isikuti dance", "The Adumu dance, The Chakacha dance"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Mwomboko dance
    })
  },

  // --- VISUAL ARTS: DRAWING (2 Materials) ---
  {
    id: G6-CA-VIS-01",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Foreshortening is a technique used to create the illusion of depth by shortening an object's length. Why is foreshortening important in drawing?,
      options: [It creates the illusion of three-dimensionality., It makes drawing simpler., It is used only for landscapes.", "It is a new technique.].sort(() => Math.random() - 0.5),
      correctAnswer: It creates the illusion of three-dimensionality."
    })
  },
  {
    id: "G6-CA-VIS-02",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Still life drawing involves drawing inanimate objects arranged in a composition. Why is still life drawing a good practice for learning about composition?,
      options: [It allows you to practice arranging and drawing shapes, light, and shadow., It is the easiest form of drawing., "It only uses one object., It requires no planning."].sort(() => Math.random() - 0.5),
      correctAnswer: "It allows you to practice arranging and drawing shapes, light, and shadow.
    })
  },

  // --- VISUAL ARTS: PAINTING (2 Materials) ---
  {
    id: G6-CA-VIS-03",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Painting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Encaustic painting is an ancient technique using heated wax. What is the main component of encaustic paint?,
      options: [Beeswax, Water, Oil", "Egg yolk].sort(() => Math.random() - 0.5),
      correctAnswer: Beeswax"
    })
  },
  {
    id: "G6-CA-VIS-04",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Painting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Cubism was an art movement that revolutionized painting. Which artist is known for co-founding the Cubist movement?,
      options: [Pablo Picasso, Henri Matisse, "Paul Cézanne, Georges Seurat"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pablo Picasso
    })
  },

  // --- VISUAL ARTS: MODELLING (2 Materials) ---
  {
    id: G6-CA-VIS-05",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Modelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Kinetic sculpture is a type of sculpture that moves. What is the term for a sculpture that has moving parts and is often powered by wind or motors?,
      options: [Kinetic sculpture, Static sculpture, Abstract sculpture", "Figure sculpture].sort(() => Math.random() - 0.5),
      correctAnswer: Kinetic sculpture"
    })
  },
  {
    id: "G6-CA-VIS-06",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Modelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Installation art creates immersive experiences in a space. What is the term for a three-dimensional artwork that transforms a space and engages the viewer?,
      options: [Installation art, Sculpture, "Painting, Drawing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Installation art
    })
  },

  // --- VISUAL ARTS: PRINT MAKING (2 Materials) ---
  {
    id: G6-CA-VIS-07",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Visual Arts,
    subtopic: "Print Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Linocut is a printmaking technique that involves carving into linoleum. What material is traditionally used in linocut printmaking?,
      options: [Linoleum, Wood, Metal", "Glass].sort(() => Math.random() - 0.5),
      correctAnswer: Linoleum"
    })
  },
  {
    id: "G6-CA-VIS-08",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Visual Arts",
    subtopic: "Print Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Monoprint is a printmaking technique that produces unique images. How is monoprint different from other printmaking techniques?,
      options: [It creates unique, one-of-a-kind prints that cannot be exactly reproduced., It is easier., "It uses more colors., It is more expensive."].sort(() => Math.random() - 0.5),
      correctAnswer: "It creates unique, one-of-a-kind prints that cannot be exactly reproduced.
    })
  },

  // --- DRAMA AND STORYTELLING: STORYTELLING (2 Materials) ---
  {
    id: G6-CA-DRA-01",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Storytelling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Storytelling can be adapted to different media and platforms. What are the common elements of an effective story told through film?,
      options: [Visual storytelling, dialogue, and a compelling narrative structure., Only dialogue., Only music.", "Only visual effects.].sort(() => Math.random() - 0.5),
      correctAnswer: Visual storytelling, dialogue, and a compelling narrative structure."
    })
  },
  {
    id: "G6-CA-DRA-02",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Digital storytelling combines traditional storytelling with multimedia tools. What are the benefits of using digital tools for storytelling?,
      options: [It can reach a wider audience and incorporate multimedia elements., It is only for professionals., "It takes longer., It removes creativity."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can reach a wider audience and incorporate multimedia elements.
    })
  },

  // --- DRAMA AND STORYTELLING: DRAMATIZATION (2 Materials) ---
  {
    id: G6-CA-DRA-03",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Dramatization",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Theatrical plays can be categorized into different genres. What are the main genres of theatrical plays?,
      options: [Tragedy, Comedy, and Drama, Musical, Drama, Horror, Comedy", "Action, Adventure].sort(() => Math.random() - 0.5),
      correctAnswer: Tragedy, Comedy, and Drama"
    })
  },
  {
    id: "G6-CA-DRA-04",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Dramatization,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Lighting design is crucial for creating mood and atmosphere in a performance. What is the term for a lighting instrument that creates a sharp, focused beam of light?,
      options: [A spotlight, A floodlight", "A wash light, A strobe light"].sort(() => Math.random() - 0.5),
      correctAnswer: "A spotlight
    })
  },

  // --- DRAMA AND STORYTELLING: PUPPETRY (2 Materials) ---
  {
    id: G6-CA-DRA-05",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Puppetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Puppetry is used in many cultures for both entertainment and education. In which country did the art of puppetry known as 'Wayang Kulit' originate?,
      options: [Indonesia, China, Italy", "France].sort(() => Math.random() - 0.5),
      correctAnswer: Indonesia"
    })
  },
  {
    id: "G6-CA-DRA-06",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Drama and Storytelling",
    subtopic: "Puppetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Puppet construction involves many skills and techniques. What is the technique of attaching strings or rods to a puppet to control its movement called?,
      options: [Puppet rigging, Puppet casting, "Puppet carving, Puppet sewing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Puppet rigging
    })
  },

  // --- DRAMA AND STORYTELLING: ROLE PLAY (1 Material) ---
  {
    id: G6-CA-DRA-07",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Drama and Storytelling,
    subtopic: "Role Play",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Role play can be used to explore complex social issues. How can role play help students understand social issues?,
      options: [It allows them to experience different perspectives and build empathy., It is only for games., It avoids real issues.", "It is not educational.].sort(() => Math.random() - 0.5),
      correctAnswer: It allows them to experience different perspectives and build empathy."
    })
  },

  // --- CREATIVE EXPRESSION: PATTERNS AND DESIGNS (2 Materials) ---
  {
    id: "G6-CA-EXP-01",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Patterns and Designs,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mandalas are intricate geometric patterns used in meditation. What is the term for a circular geometric design that represents the universe?,
      options: [A mandala, A tessellation, "A fractal, A mosaic"].sort(() => Math.random() - 0.5),
      correctAnswer: "A mandala
    })
  },
  {
    id: G6-CA-EXP-02",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Patterns and Designs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " African masks use symbols and patterns to communicate cultural meaning. What is the purpose of patterns in African masks?,
      options: [To represent spiritual beliefs, social status, and cultural identity., Only for decoration., To scare people.", "To show wealth.].sort(() => Math.random() - 0.5),
      correctAnswer: To represent spiritual beliefs, social status, and cultural identity."
    })
  },

  // --- CREATIVE EXPRESSION: TEXTILE ART (2 Materials) ---
  {
    id: "G6-CA-EXP-03",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Textile Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Textile art is a form of creative expression that uses fibers and fabrics. What is the technique of using a needle and thread to create decorative designs on fabric called?,
      options: [Embroidery, Weaving, "Knitting, Crocheting"].sort(() => Math.random() - 0.5),
      correctAnswer: "Embroidery
    })
  },
  {
    id: G6-CA-EXP-04",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Textile Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Beadwork is a form of textile art that involves stringing beads together. Which Kenyan community is particularly known for their intricate beadwork?,
      options: [The Maasai, The Luo, The Kikuyu", "The Swahili].sort(() => Math.random() - 0.5),
      correctAnswer: The Maasai"
    })
  },

  // --- CREATIVE EXPRESSION: CREATIVE WRITING (2 Materials) ---
  {
    id: "G6-CA-EXP-05",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Creative Expression",
    subtopic: "Creative Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Point of view is a crucial element of storytelling. What is the term for a story told from the perspective of 'I'?,
      options: [First-person point of view, Second-person point of view, "Third-person point of view, Omniscient point of view"].sort(() => Math.random() - 0.5),
      correctAnswer: "First-person point of view
    })
  },
  {
    id: G6-CA-EXP-06",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Creative Expression,
    subtopic: "Creative Writing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Imagery is a literary device that uses descriptive language to create visual pictures. What is the term for a literary device that uses extreme exaggeration?,
      options: [Hyperbole, Simile, Metaphor", "Personification].sort(() => Math.random() - 0.5),
      correctAnswer: Hyperbole"
    })
  },

  // --- MEDIA ARTS: DIGITAL ART AND ANIMATION (2 Materials) ---
  {
    id: "G6-CA-MED-01",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Digital Art and Animation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Animation brings still images to life through motion. What is the term for the technique of creating the illusion of movement by showing a sequence of images?,
      options: [Animation, Videography, "Photography, Digital art"].sort(() => Math.random() - 0.5),
      correctAnswer: "Animation
    })
  },
  {
    id: G6-CA-MED-02",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Digital Art and Animation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Stop-motion animation involves manipulating objects frame by frame. What is a popular material used in stop-motion animation?,
      options: [Clay, Paper, Metal", "Glass].sort(() => Math.random() - 0.5),
      correctAnswer: Clay"
    })
  },

  // --- MEDIA ARTS: FILM AND MULTIMEDIA (2 Materials) ---
  {
    id: "G6-CA-MED-03",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Media Arts",
    subtopic: "Film and Multimedia,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Film editing is a crucial part of movie-making. What is the term for the process of selecting and arranging shots to create a continuous sequence?,
      options: [Editing, Directing, "Producing, Screenwriting"].sort(() => Math.random() - 0.5),
      correctAnswer: "Editing
    })
  },
  {
    id: G6-CA-MED-04",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Media Arts,
    subtopic: "Film and Multimedia",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Sound design enhances the experience of a film or multimedia production. What are the different types of sounds used in film production?,
      options: [Dialogue, sound effects, and background music., Only dialogue., Only music.", "Only sound effects.].sort(() => Math.random() - 0.5),
      correctAnswer: Dialogue, sound effects, and background music."
    })
  },

  // --- APPRECIATION: APPRECIATING NATURE (1 Material) ---
  {
    id: "G6-CA-APP-01",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kenya's biodiversity offers endless inspiration for artists. Which Kenyan national park is often depicted in nature photography and paintings?,
      options: [Maasai Mara National Reserve, Hell's Gate National Park, "Lake Nakuru National Park, Tsavo National Park"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maasai Mara National Reserve
    })
  },

  // --- APPRECIATION: APPRECIATING CULTURE (1 Material) ---
  {
    id: G6-CA-APP-02",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Culture",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Cultural appropriation is an important concept in the appreciation of other cultures' arts. What is the difference between cultural appreciation and cultural appropriation?,
      options: [Appreciation respects and acknowledges the source culture; appropriation takes without permission., They are the same thing., Appreciation is bad.", "Appropriation is respectful.].sort(() => Math.random() - 0.5),
      correctAnswer: Appreciation respects and acknowledges the source culture; appropriation takes without permission."
    })
  },

  // --- APPRECIATION: APPRECIATING ARTWORK (2 Materials) ---
  {
    id: "G6-CA-APP-03",
    grade: "Grade 6",
    subject: "Creative Arts",
    topic: "Appreciation",
    subtopic: "Appreciating Artwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The value of art can be both monetary and cultural. Why is it difficult to assign monetary value to some artworks?,
      options: [Art's value is subjective and determined by many factors., All art has the same value., "Art has no value., Value is only based on size."].sort(() => Math.random() - 0.5),
      correctAnswer: "Art's value is subjective and determined by many factors.
    })
  },
  {
    id: G6-CA-APP-04",
    grade: "Grade 6,
    subject: Creative Arts",
    topic: "Appreciation,
    subtopic: "Appreciating Artwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Art can be a powerful tool for social change and expression. How has art been used to bring attention to social issues?,
      options: [Through provocative imagery, performances, and visual statements., It is not effective., It is only for entertainment.", "It avoids controversial topics.].sort(() => Math.random() - 0.5),
      correctAnswer: Through provocative imagery, performances, and visual statements."
    })
  }

];


