export const preTechnicalTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD PRE-TECHNICAL STUDIES SYLLABUS)
  // =========================================================================

  // --- STRAND 1: FOUNDATIONS OF PRE-TECHNICAL STUDIES ---

  // --- 1.1 INTRODUCTION TO PRE-TECHNICAL STUDIES (4 Materials) ---
  {
    id: "G7-PTS-INT-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Introduction to Pre-Technical Studies",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Pre-Technical Studies is an integrated learning area in Junior Secondary School. Which of the following subjects is NOT part of Pre-Technical Studies?,
      options: [Mathematics, Business Studies, "Computer Studies, Technical Studies"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mathematics
    })
  },
  {
    id: G7-PTS-INT-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Introduction to Pre-Technical Studies",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Pre-Technical Studies aims to develop essential skills in learners. What is one of the main goals of Pre-Technical Studies?,
      options: [To prepare learners for careers in technical fields., To teach only business skills., To focus only on computer studies.", "To replace all other subjects.].sort(() => Math.random() - 0.5),
      correctAnswer: To prepare learners for careers in technical fields."
    })
  },
  {
    id: "G7-PTS-INT-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Introduction to Pre-Technical Studies",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Pre-Technical Studies helps learners develop practical skills. Which career pathway can Pre-Technical Studies lead to?,
      options: [Engineering, Law, "Medicine, Teaching"].sort(() => Math.random() - 0.5),
      correctAnswer: "Engineering
    })
  },
  {
    id: G7-PTS-INT-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Introduction to Pre-Technical Studies",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Pre-Technical Studies is built on competencies from Upper Primary. Which subject in Upper Primary lays the foundation for Pre-Technical Studies?,
      options: [Science and Technology, English, Mathematics", "Social Studies].sort(() => Math.random() - 0.5),
      correctAnswer: Science and Technology"
    })
  },

  // --- 1.2 SAFETY IN THE IMMEDIATE ENVIRONMENT (4 Materials) ---
  {
    id: "G7-PTS-SAF-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Safety in the Immediate Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Safety is important in every environment to prevent accidents. What is the term for the process of identifying potential hazards and taking action to prevent harm?,
      options: [Risk assessment, Safety audit, "Hazard identification, Emergency plan"].sort(() => Math.random() - 0.5),
      correctAnswer: "Risk assessment
    })
  },
  {
    id: G7-PTS-SAF-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Safety in the Immediate Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Safety in the immediate environment involves protecting people from harm. Which of the following is a safety measure in a workshop or laboratory?,
      options: [Wearing personal protective equipment (PPE)., Keeping the area untidy., Running in the workshop.", "Ignoring warning signs.].sort(() => Math.random() - 0.5),
      correctAnswer: Wearing personal protective equipment (PPE)."
    })
  },
  {
    id: "G7-PTS-SAF-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Safety in the Immediate Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Personal protective equipment (PPE) protects people from workplace hazards. Which of the following is an example of PPE?,
      options: [Safety goggles, Uniform, "School bag, Lunch box"].sort(() => Math.random() - 0.5),
      correctAnswer: "Safety goggles
    })
  },
  {
    id: G7-PTS-SAF-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Safety in the Immediate Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A clean and organized environment is essential for safety. Why is it important to keep the workshop or computer lab clean?,
      options: [To prevent accidents and maintain a safe working environment., To make it look beautiful., To keep pests away.", "To save money.].sort(() => Math.random() - 0.5),
      correctAnswer: To prevent accidents and maintain a safe working environment."
    })
  },

  // --- 1.3 COMPUTER CONCEPTS (4 Materials) ---
  {
    id: "G7-PTS-COM-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Computer Concepts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A computer is an electronic device used to process data. What is the term for the physical components of a computer that you can touch?,
      options: [Hardware, Software, "Firmware, Data"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hardware
    })
  },
  {
    id: G7-PTS-COM-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Computer Concepts",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Computer software refers to programs that tell the computer what to do. Which of the following is an example of computer software?,
      options: [Microsoft Windows, Motherboard, Monitor", "Keyboard].sort(() => Math.random() - 0.5),
      correctAnswer: Microsoft Windows"
    })
  },
  {
    id: "G7-PTS-COM-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Computer Concepts,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Data is the raw information that computers process. What is the term for processed data that has meaning?,
      options: [Information, Facts, "Numbers, Symbols"].sort(() => Math.random() - 0.5),
      correctAnswer: "Information
    })
  },
  {
    id: G7-PTS-COM-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Computer Concepts",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Computers use binary code to process information. What is the term for the two numbers used in binary code?,
      options: [0 and 1, 1 and 2, A and B", "Yes and No].sort(() => Math.random() - 0.5),
      correctAnswer: 0 and 1"
    })
  },

  // --- STRAND 2: COMMUNICATION IN PRE-TECHNICAL STUDIES ---

  // --- 2.1 INTRODUCTION TO DRAWING (4 Materials) ---
  {
    id: "G7-PTS-DRW-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "Introduction to Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Technical drawing is a universal language used to communicate ideas. What is the term for drawing created using specialized instruments?,
      options: [Technical drawing, Freehand sketching, "Art drawing, Abstract drawing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Technical drawing
    })
  },
  {
    id: G7-PTS-DRW-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "Introduction to Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Drawing instruments are used to create accurate technical drawings. Which of the following is a drawing instrument used to draw straight lines?,
      options: [A T-square, A compass, A protractor", "A set square].sort(() => Math.random() - 0.5),
      correctAnswer: A T-square"
    })
  },
  {
    id: "G7-PTS-DRW-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "Introduction to Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Drawing paper comes in different sizes for different purposes. What is the most common size for technical drawing paper?,
      options: [A4, A3, "A5, A2"].sort(() => Math.random() - 0.5),
      correctAnswer: "A4
    })
  },
  {
    id: G7-PTS-DRW-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "Introduction to Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Drawing board is used as a surface for technical drawing. Why is a drawing board used for technical drawing?,
      options: [To provide a smooth and stable surface for accurate drawing., To make the drawing look good., To protect the drawing paper.", "To store drawing instruments.].sort(() => Math.random() - 0.5),
      correctAnswer: To provide a smooth and stable surface for accurate drawing."
    })
  },

  // --- 2.2 FREE-HAND SKETCHING (4 Materials) ---
  {
    id: "G7-PTS-FHS-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "Free-hand Sketching,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Freehand sketching is a quick way to communicate ideas without instruments. What is the advantage of freehand sketching in technical communication?,
      options: [It is fast and can be done anywhere without equipment., It is always accurate., "It requires no skill., It is only for artists."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is fast and can be done anywhere without equipment.
    })
  },
  {
    id: G7-PTS-FHS-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "Free-hand Sketching",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " There are different types of lines used in freehand sketching. What type of line is used to represent visible edges of an object?,
      options: [Continuous thick line, Dashed line, Dotted line", "Chain line].sort(() => Math.random() - 0.5),
      correctAnswer: Continuous thick line"
    })
  },
  {
    id: "G7-PTS-FHS-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "Free-hand Sketching,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Geometric shapes are the basis of technical drawings. Which of the following is a regular geometric shape?,
      options: [Square, Rectangle, "Triangle, Circle"].sort(() => Math.random() - 0.5),
      correctAnswer: "Circle
    })
  },
  {
    id: G7-PTS-FHS-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "Free-hand Sketching",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Isometric projection is a method of creating 3D drawings on 2D paper. What angle is used in isometric projection drawing?,
      options: [30°, 45°, 60°", "90°].sort(() => Math.random() - 0.5),
      correctAnswer: 30°"
    })
  },

  // --- 2.3 ICT TOOLS IN COMMUNICATION (4 Materials) ---
  {
    id: "G7-PTS-ICT-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "ICT Tools in Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "ICT tools are used to communicate information effectively. Which of the following is an example of an ICT communication tool?,
      options: [Email, Pen, "Paper, Chalkboard"].sort(() => Math.random() - 0.5),
      correctAnswer: "Email
    })
  },
  {
    id: G7-PTS-ICT-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "ICT Tools in Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The internet has revolutionized how we communicate. What is the term for the network that connects computers globally?,
      options: [The Internet, The Intranet, The Network", "The Server].sort(() => Math.random() - 0.5),
      correctAnswer: The Internet"
    })
  },
  {
    id: "G7-PTS-ICT-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies",
    subtopic: "ICT Tools in Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Presentation software is used to create visual presentations. Which of the following is a popular presentation software?,
      options: [Microsoft PowerPoint, Microsoft Word, "Microsoft Excel, Microsoft Access"].sort(() => Math.random() - 0.5),
      correctAnswer: "Microsoft PowerPoint
    })
  },
  {
    id: G7-PTS-ICT-04",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Communication in Pre-Technical Studies,
    subtopic: "ICT Tools in Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " ICT tools can be used to create and share information. What is the term for the process of creating, sharing, and using information effectively?,
      options: [Information literacy, Communication skills, Digital literacy", "Technology literacy].sort(() => Math.random() - 0.5),
      correctAnswer: Information literacy"
    })
  },

  // --- STRAND 3: MATERIALS FOR PRODUCTION ---

  // --- 3.1 INTRODUCTION TO MATERIALS (3 Materials) ---
  {
    id: "G7-PTS-MAT-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Introduction to Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Materials are the substances used to create products. What is the term for the classification of materials based on where they come from?,
      options: [Natural and synthetic, Hard and soft, "Heavy and light, Expensive and cheap"].sort(() => Math.random() - 0.5),
      correctAnswer: "Natural and synthetic
    })
  },
  {
    id: G7-PTS-MAT-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Introduction to Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Materials have different properties that determine their use. Which of the following is a property of metals that makes them good for making tools?,
      options: [Strength and durability, Softness, Brittleness", "Transparency].sort(() => Math.random() - 0.5),
      correctAnswer: Strength and durability"
    })
  },
  {
    id: "G7-PTS-MAT-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Introduction to Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Choosing the right material for a job is important. Why is it important to select the right material for a specific production task?,
      options: [To ensure the product is functional, durable, and cost-effective., To make it look good., "To use the most expensive material., To follow tradition."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure the product is functional, durable, and cost-effective.
    })
  },

  // --- 3.2 METALLIC MATERIALS (3 Materials) ---
  {
    id: G7-PTS-MET-01",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Metallic Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Metals are important materials used in many industries. Which of the following is a naturally occurring mineral from which metals are extracted?,
      options: [Ore, Rock, Sand", "Clay].sort(() => Math.random() - 0.5),
      correctAnswer: Ore"
    })
  },
  {
    id: "G7-PTS-MET-02",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Metallic Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ferrous metals contain iron while non-ferrous metals do not. Which of the following is a non-ferrous metal?,
      options: [Aluminum, Steel, "Iron, Cast iron"].sort(() => Math.random() - 0.5),
      correctAnswer: "Aluminum
    })
  },
  {
    id: G7-PTS-MET-03",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Metallic Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Alloys are mixtures of metals with other elements to improve properties. What is the term for an alloy made from copper and tin?,
      options: [Bronze, Brass, Steel", "Cast iron].sort(() => Math.random() - 0.5),
      correctAnswer: Bronze"
    })
  },

  // --- 3.3 NON-METALLIC MATERIALS (3 Materials) ---
  {
    id: "G7-PTS-NON-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Non-Metallic Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Non-metallic materials are substances that do not contain metal. Which of the following is a non-metallic material?,
      options: [Wood, Steel, "Aluminum, Bronze"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wood
    })
  },
  {
    id: G7-PTS-NON-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Non-Metallic Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Polymers are non-metallic materials made from long chains of molecules. Which of the following is an example of a polymer?,
      options: [Plastic, Glass, Wood", "Ceramic].sort(() => Math.random() - 0.5),
      correctAnswer: Plastic"
    })
  },
  {
    id: "G7-PTS-NON-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Non-Metallic Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Ceramics are non-metallic materials made from clay and other minerals. Which of the following products is made from ceramics?,
      options: [Bricks, Glass bottles, "Plastic bags, Wooden chairs"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bricks
    })
  },

  // --- STRAND 4: TOOLS AND PRODUCTION ---

  // --- 4.1 MEASURING AND MARKING OUT TOOLS (4 Materials) ---
  {
    id: G7-PTS-MEA-01",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Measuring and Marking Out Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Measuring tools are used to measure length, width, and height accurately. Which of the following is a tool used to measure length?,
      options: [A tape measure, A compass, A protractor", "A set square].sort(() => Math.random() - 0.5),
      correctAnswer: A tape measure"
    })
  },
  {
    id: "G7-PTS-MEA-02",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Measuring and Marking Out Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Marking out tools are used to indicate where cuts or holes should be made. Which of the following is a marking out tool?,
      options: [A scriber, A hammer, "A screwdriver, A wrench"].sort(() => Math.random() - 0.5),
      correctAnswer: "A scriber
    })
  },
  {
    id: G7-PTS-MEA-03",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Measuring and Marking Out Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A try square is used for marking and measuring right angles. What is the angle of a right angle?,
      options: [90°, 45°, 60°", "180°].sort(() => Math.random() - 0.5),
      correctAnswer: 90°"
    })
  },
  {
    id: "G7-PTS-MEA-04",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Measuring and Marking Out Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Using measuring and marking out tools requires skill and precision. Why is it important to use measuring tools correctly?,
      options: [To ensure accuracy and prevent waste., To make work faster., "To use more materials., To save energy."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure accuracy and prevent waste.
    })
  },

  // --- 4.2 COMPUTER HARDWARE (3 Materials) ---
  {
    id: G7-PTS-HAR-01",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Hardware",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Computer hardware refers to the physical components of a computer. Which of the following is an input device?,
      options: [A keyboard, A monitor, A printer", "A speaker].sort(() => Math.random() - 0.5),
      correctAnswer: A keyboard"
    })
  },
  {
    id: "G7-PTS-HAR-02",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Computer Hardware,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Output devices display or present information to the user. Which of the following is an output device?,
      options: [A monitor, A mouse, "A scanner, A webcam"].sort(() => Math.random() - 0.5),
      correctAnswer: "A monitor
    })
  },
  {
    id: G7-PTS-HAR-03",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Hardware",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The CPU is the brain of the computer. What does CPU stand for?,
      options: [Central Processing Unit, Central Program Unit, Computer Processing Unit", "Central Process Unit].sort(() => Math.random() - 0.5),
      correctAnswer: Central Processing Unit"
    })
  },

  // --- STRAND 5: ENTREPRENEURSHIP ---

  // --- 5.1 INTRODUCTION TO ENTREPRENEURSHIP (3 Materials) ---
  {
    id: "G7-PTS-ENT-01",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Introduction to Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Entrepreneurship is the process of starting and running a business. What is the term for a person who starts and runs a business?,
      options: [An entrepreneur, A manager, "An employee, A customer"].sort(() => Math.random() - 0.5),
      correctAnswer: "An entrepreneur
    })
  },
  {
    id: G7-PTS-ENT-02",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Introduction to Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Entrepreneurs play an important role in the economy. What is one way entrepreneurs contribute to society?,
      options: [Creating jobs and providing goods and services., Taking money from people., Only making money for themselves.", "Ignoring customers.].sort(() => Math.random() - 0.5),
      correctAnswer: Creating jobs and providing goods and services."
    })
  },
  {
    id: "G7-PTS-ENT-03",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Introduction to Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Successful entrepreneurs have certain qualities and skills. Which of the following is a quality of a successful entrepreneur?,
      options: [Perseverance and risk-taking, Laziness, "Giving up easily, Being afraid of challenges"].sort(() => Math.random() - 0.5),
      correctAnswer: "Perseverance and risk-taking
    })
  },

  // --- 5.2 PRODUCTION UNIT (4 Materials) ---
  {
    id: G7-PTS-PRO-01",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Production Unit",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A production unit is a place where goods are made or services are provided. Which of the following is an example of a production unit?,
      options: [A bakery, A church, A school", "A bank].sort(() => Math.random() - 0.5),
      correctAnswer: A bakery"
    })
  },
  {
    id: "G7-PTS-PRO-02",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Production Unit,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Production units require resources to operate effectively. Which of the following is a factor of production?,
      options: [Land, Time, "Energy, Information"].sort(() => Math.random() - 0.5),
      correctAnswer: "Land
    })
  },
  {
    id: G7-PTS-PRO-03",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Production Unit",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Entrepreneurs need to plan their production process carefully. What is the term for the sequence of steps followed to produce a product?,
      options: [Production process, Business plan, Marketing strategy", "Financial plan].sort(() => Math.random() - 0.5),
      correctAnswer: Production process"
    })
  },
  {
    id: "G7-PTS-PRO-04",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Production Unit,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Quality control is important in production. Why is quality control important in a production unit?,
      options: [To ensure products meet standards and customer expectations., To waste materials., "To increase costs., To slow down production."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure products meet standards and customer expectations.
    })
  },

  // --- 5.3 FINANCIAL GOALS (4 Materials) ---
  {
    id: G7-PTS-FIN-01",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Financial Goals",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Financial goals are targets for earning and spending money. What is the term for a financial goal that is set for a short period of time?,
      options: [Short-term goal, Long-term goal, Medium-term goal", "Lifelong goal].sort(() => Math.random() - 0.5),
      correctAnswer: Short-term goal"
    })
  },
  {
    id: "G7-PTS-FIN-02",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Financial Goals,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Saving money is important for achieving financial goals. What is the benefit of saving money regularly?,
      options: [It helps to achieve financial goals and handle emergencies., It makes you rich overnight., "It reduces your income., It increases your expenses."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps to achieve financial goals and handle emergencies.
    })
  },
  {
    id: G7-PTS-FIN-03",
    grade: "Grade 7,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Financial Goals",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Budgeting is a key skill for managing finances. What is the term for a plan for how money will be spent?,
      options: [A budget, A receipt, An invoice", "A statement].sort(() => Math.random() - 0.5),
      correctAnswer: A budget"
    })
  },
  {
    id: "G7-PTS-FIN-04",
    grade: "Grade 7",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Financial Goals,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Entrepreneurs need to set financial goals for their businesses. What is the term for the money left over after paying all business expenses?,
      options: [Profit, Revenue, "Capital, Loss"].sort(() => Math.random() - 0.5),
      correctAnswer: "Profit
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD PRE-TECHNICAL STUDIES SYLLABUS)
  // =========================================================================

  // --- STRAND 1: FOUNDATIONS OF PRE-TECHNICAL STUDIES ---

  // --- 1.1 FIRE SAFETY (4 Materials) ---
  {
    id: G8-PTS-FIR-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Fire Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fire safety is important in homes, schools, and workplaces. What is the fire triangle composed of?,
      options: [Heat, Fuel, and Oxygen, Heat, Water, and Smoke, Fuel, Carbon Dioxide, and Heat", "Oxygen, Nitrogen, and Heat].sort(() => Math.random() - 0.5),
      correctAnswer: Heat, Fuel, and Oxygen"
    })
  },
  {
    id: "G8-PTS-FIR-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Different classes of fire require different extinguishers. Which class of fire involves electrical equipment?,
      options: [Class C, Class A, "Class B, Class D"].sort(() => Math.random() - 0.5),
      correctAnswer: "Class C
    })
  },
  {
    id: G8-PTS-FIR-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Fire Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fire extinguishers are used to put out fires. Which type of fire extinguisher is safe to use on electrical and flammable liquid fires?,
      options: [CO2 extinguisher, Water extinguisher, Foam extinguisher", "Powder extinguisher].sort(() => Math.random() - 0.5),
      correctAnswer: CO2 extinguisher"
    })
  },
  {
    id: "G8-PTS-FIR-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Fire Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fire safety procedures help prevent and respond to fires. Which of the following is a fire safety measure?,
      options: [Have a fire escape plan and practice it regularly., Keep flammable materials near heat sources., "Block fire exits., Ignore fire alarms."].sort(() => Math.random() - 0.5),
      correctAnswer: "Have a fire escape plan and practice it regularly.
    })
  },

  // --- 1.2 DATA SAFETY (4 Materials) ---
  {
    id: G8-PTS-DAT-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Data Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Data safety is important for protecting information. What is the term for the practice of protecting data from unauthorized access?,
      options: [Data security, Data storage, Data processing", "Data transmission].sort(() => Math.random() - 0.5),
      correctAnswer: Data security"
    })
  },
  {
    id: "G8-PTS-DAT-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Data Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Passwords are used to protect computer data. What is a good practice for creating strong passwords?,
      options: [Use a combination of letters, numbers, and symbols., Use your birthday., "Use your name., Use simple words."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a combination of letters, numbers, and symbols.
    })
  },
  {
    id: G8-PTS-DAT-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Data Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Backing up data is important for protecting information. What is the term for making a copy of data in case the original is lost?,
      options: [Data backup, Data transfer, Data storage", "Data encryption].sort(() => Math.random() - 0.5),
      correctAnswer: Data backup"
    })
  },
  {
    id: "G8-PTS-DAT-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Data Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Antivirus software helps protect computers from threats. What is the purpose of antivirus software?,
      options: [To detect and remove malicious software., To make the computer faster., "To connect to the internet., To store files."].sort(() => Math.random() - 0.5),
      correctAnswer: "To detect and remove malicious software.
    })
  },

  // --- STRAND 2: COMMUNICATION ---

  // --- 2.1 PLANE GEOMETRY (4 Materials) ---
  {
    id: G8-PTS-GEO-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Plane Geometry",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Plane geometry involves shapes and lines on a flat surface. What is the term for a line that has a starting point but no ending point?,
      options: [A ray, A line segment, A line", "A curve].sort(() => Math.random() - 0.5),
      correctAnswer: A ray"
    })
  },
  {
    id: "G8-PTS-GEO-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Plane Geometry,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Angles are formed when two lines meet. What is the term for an angle that measures exactly 90 degrees?,
      options: [Right angle, Acute angle, "Obtuse angle, Reflex angle"].sort(() => Math.random() - 0.5),
      correctAnswer: "Right angle
    })
  },
  {
    id: G8-PTS-GEO-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Plane Geometry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Triangles are three-sided shapes with different properties. Which type of triangle has all sides and angles equal?,
      options: [Equilateral triangle, Isosceles triangle, Scalene triangle", "Right-angled triangle].sort(() => Math.random() - 0.5),
      correctAnswer: Equilateral triangle"
    })
  },
  {
    id: "G8-PTS-GEO-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Plane Geometry,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Quadrilaterals are four-sided shapes with different properties. Which of the following is NOT a type of quadrilateral?,
      options: [Triangle, Square, "Rectangle, Rhombus"].sort(() => Math.random() - 0.5),
      correctAnswer: "Triangle
    })
  },

  // --- 2.2 DIMENSIONING (4 Materials) ---
  {
    id: G8-PTS-DIM-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Dimensioning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Dimensioning is used to show the size of objects in technical drawings. What is the term for the line that indicates the extent of a dimension?,
      options: [Dimension line, Extension line, Leader line", "Center line].sort(() => Math.random() - 0.5),
      correctAnswer: Dimension line"
    })
  },
  {
    id: "G8-PTS-DIM-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Dimensioning,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Units of measurement are important in dimensioning. Which system of measurement is commonly used in technical drawings in Kenya?,
      options: [Metric system, Imperial system, "US customary system, Chinese system"].sort(() => Math.random() - 0.5),
      correctAnswer: "Metric system
    })
  },
  {
    id: G8-PTS-DIM-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Dimensioning",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Dimensions should be placed correctly on technical drawings. What is the rule for placing dimensions on technical drawings?,
      options: [Dimensions should be clear, accurate, and placed away from drawing lines., Dimensions should overlap with drawing lines., Dimensions should be placed randomly.", "Dimensions are not needed.].sort(() => Math.random() - 0.5),
      correctAnswer: Dimensions should be clear, accurate, and placed away from drawing lines."
    })
  },
  {
    id: "G8-PTS-DIM-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Dimensioning,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "ISO standards guide dimensioning in technical drawings. What does ISO stand for?,
      options: [International Organization for Standardization, International Standards Office, "International System of Operations, Industrial Standards Organization"].sort(() => Math.random() - 0.5),
      correctAnswer: "International Organization for Standardization
    })
  },

  // --- 2.3 PLANE SCALE DRAWING (4 Materials) ---
  {
    id: G8-PTS-SCA-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Plane Scale Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Scale drawings are used to represent objects at a different size. What is the term for the ratio between the drawing size and the actual size?,
      options: [Scale, Ratio, Proportion", "Measurement].sort(() => Math.random() - 0.5),
      correctAnswer: Scale"
    })
  },
  {
    id: "G8-PTS-SCA-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Plane Scale Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Scale is expressed as a ratio in technical drawings. What does a scale of 1:100 mean?,
      options: [1 unit on drawing equals 100 units in reality., 100 units on drawing equals 1 unit in reality., "1 unit on drawing equals 1 unit in reality., 100 units on drawing equals 100 units in reality."].sort(() => Math.random() - 0.5),
      correctAnswer: "1 unit on drawing equals 100 units in reality.
    })
  },
  {
    id: G8-PTS-SCA-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Plane Scale Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Scale drawings are used in many fields including architecture and engineering. Why are scale drawings important in construction?,
      options: [They allow accurate representation of large objects on smaller paper., They are only for architects., They are not important.", "They are expensive.].sort(() => Math.random() - 0.5),
      correctAnswer: They allow accurate representation of large objects on smaller paper."
    })
  },
  {
    id: "G8-PTS-SCA-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Plane Scale Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Reducing and enlarging scales are used for different purposes. Which scale would be used to draw a map of Kenya on an A4 paper?,
      options: [A small scale like 1:1,000,000, A large scale like 1:100, "A scale of 1:1, A scale of 10:1"].sort(() => Math.random() - 0.5),
      correctAnswer: "A small scale like 1:1,000,000
    })
  },

  // --- 2.4 VISUAL PROGRAMMING (4 Materials) ---
  {
    id: G8-PTS-VIS-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Visual Programming",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Visual programming uses visual elements to create programs. Which of the following is a popular visual programming language?,
      options: [Scratch, Python, Java", "C++].sort(() => Math.random() - 0.5),
      correctAnswer: Scratch"
    })
  },
  {
    id: "G8-PTS-VIS-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Visual Programming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Scratch uses blocks to create programs. What color are the event blocks in Scratch?,
      options: [Yellow, Blue, "Green, Orange"].sort(() => Math.random() - 0.5),
      correctAnswer: "Yellow
    })
  },
  {
    id: G8-PTS-VIS-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Visual Programming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Loops are used in programming to repeat actions. Which block is used to create a loop in Scratch?,
      options: [Repeat, If, When", "Move].sort(() => Math.random() - 0.5),
      correctAnswer: Repeat"
    })
  },
  {
    id: "G8-PTS-VIS-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Visual Programming,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Visual programming helps learners understand coding concepts. What is the advantage of using visual programming for beginners?,
      options: [It is easier to understand and doesn't require typing code., It is more difficult., "It is only for experts., It is not useful."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is easier to understand and doesn't require typing code.
    })
  },

  // --- STRAND 3: MATERIALS FOR PRODUCTION ---

  // --- 3.1 COMPOSITE MATERIALS (3 Materials) ---
  {
    id: G8-PTS-COM-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Composite Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Composite materials are made from two or more materials. Which of the following is an example of a composite material?,
      options: [Fiberglass, Steel, Aluminum", "Copper].sort(() => Math.random() - 0.5),
      correctAnswer: Fiberglass"
    })
  },
  {
    id: "G8-PTS-COM-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Composite Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Composite materials are designed to have improved properties. What is the term for the material that holds the reinforcement together in a composite?,
      options: [Matrix, Reinforcement, "Filler, Binder"].sort(() => Math.random() - 0.5),
      correctAnswer: "Matrix
    })
  },
  {
    id: G8-PTS-COM-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Composite Materials",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Carbon fiber composites are used in many high-performance products. Why is carbon fiber composite used in aerospace and sports equipment?,
      options: [It is strong, lightweight, and resistant to heat and chemicals., It is cheap., It is heavy.", "It is easy to produce.].sort(() => Math.random() - 0.5),
      correctAnswer: It is strong, lightweight, and resistant to heat and chemicals."
    })
  },

  // --- 3.2 CERAMICS (3 Materials) ---
  {
    id: "G8-PTS-CER-01",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Ceramics,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ceramics are materials made from clay and other minerals. Which of the following is a ceramic product commonly used in homes?,
      options: [A glass cup, A plastic bowl, "A wooden spoon, A metal pot"].sort(() => Math.random() - 0.5),
      correctAnswer: "A glass cup
    })
  },
  {
    id: G8-PTS-CER-02",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Ceramics",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ceramics are used for various industrial applications. Which of the following is a common use of ceramics in electrical engineering?,
      options: [Electrical insulators, Conductors, Switches", "Wires].sort(() => Math.random() - 0.5),
      correctAnswer: Electrical insulators"
    })
  },
  {
    id: "G8-PTS-CER-03",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Ceramics,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Ceramics are made through a specific process. What is the term for the process of heating clay in a high-temperature oven to harden it?,
      options: [Firing, Drying, "Glazing, Moulding"].sort(() => Math.random() - 0.5),
      correctAnswer: "Firing
    })
  },

  // --- STRAND 4: TOOLS AND PRODUCTION ---

  // --- 4.1 CUTTING TOOLS (4 Materials) ---
  {
    id: G8-PTS-CUT-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Cutting Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Cutting tools are used to cut materials into desired shapes. Which of the following is a cutting tool used for cutting metal?,
      options: [Hacksaw, Hand saw, Knife", "Scissors].sort(() => Math.random() - 0.5),
      correctAnswer: Hacksaw"
    })
  },
  {
    id: "G8-PTS-CUT-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Cutting Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Chisels are used for cutting and shaping materials. Which of the following is a chisel used for woodworking?,
      options: [Wood chisel, Cold chisel, "Paring chisel, Mortise chisel"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wood chisel
    })
  },
  {
    id: G8-PTS-CUT-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Cutting Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Drills are used to make holes in materials. Which type of drill is commonly used with a power drill machine?,
      options: [Twist drill, Flat drill, Center drill", "Reamer].sort(() => Math.random() - 0.5),
      correctAnswer: Twist drill"
    })
  },
  {
    id: "G8-PTS-CUT-04",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Cutting Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Safety is important when using cutting tools. Which of the following is a safety precaution when using cutting tools?,
      options: [Always wear safety goggles and use tools correctly., Run with cutting tools in your hand., "Use tools for purposes they were not designed for., Ignore safety instructions."].sort(() => Math.random() - 0.5),
      correctAnswer: "Always wear safety goggles and use tools correctly.
    })
  },

  // --- 4.2 COMPUTER SOFTWARE (3 Materials) ---
  {
    id: G8-PTS-SOF-01",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Computer software is divided into system software and application software. Which of the following is an example of application software?,
      options: [Microsoft Word, Windows, Linux", "MacOS].sort(() => Math.random() - 0.5),
      correctAnswer: Microsoft Word"
    })
  },
  {
    id: "G8-PTS-SOF-02",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Computer Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Word processors are used to create and edit text documents. What is the extension of a Microsoft Word document?,
      options: [.docx, .txt, ".pdf, .xlsx"].sort(() => Math.random() - 0.5),
      correctAnswer: ".docx
    })
  },
  {
    id: G8-PTS-SOF-03",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Spreadsheets are used for organizing and analyzing data. What is the term for the intersection of a row and column in a spreadsheet?,
      options: [A cell, A sheet, A chart", "A formula].sort(() => Math.random() - 0.5),
      correctAnswer: A cell"
    })
  },

  // --- STRAND 5: ENTREPRENEURSHIP ---

  // --- 5.1 BOOKKEEPING (4 Materials) ---
  {
    id: "G8-PTS-BOO-01",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Bookkeeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Bookkeeping is the recording of financial transactions. What is the term for a record of all money received and paid by a business?,
      options: [Cash book, Sales book, "Purchase book, Ledger"].sort(() => Math.random() - 0.5),
      correctAnswer: "Cash book
    })
  },
  {
    id: G8-PTS-BOO-02",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Bookkeeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " In bookkeeping, every transaction has two effects. What is the term for the bookkeeping system that records two effects for each transaction?,
      options: [Double-entry bookkeeping, Single-entry bookkeeping, Triple-entry bookkeeping", "Simple bookkeeping].sort(() => Math.random() - 0.5),
      correctAnswer: Double-entry bookkeeping"
    })
  },
  {
    id: "G8-PTS-BOO-03",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Bookkeeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A balance sheet shows the financial position of a business. What does a balance sheet show?,
      options: [Assets, liabilities, and equity, Income and expenses, "Sales and purchases, Profit and loss"].sort(() => Math.random() - 0.5),
      correctAnswer: "Assets, liabilities, and equity
    })
  },
  {
    id: G8-PTS-BOO-04",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Bookkeeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Keeping accurate records is important for business success. Why is bookkeeping important for a business?,
      options: [It helps track income and expenses and make informed decisions., It makes the business look professional., It is required by law only.", "It is only for large businesses.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps track income and expenses and make informed decisions."
    })
  },

  // --- 5.2 INCOME AND BUDGETING (4 Materials) ---
  {
    id: "G8-PTS-INC-01",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Income and Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Income is money received from various sources. Which of the following is a source of income for an entrepreneur?,
      options: [Sales revenue, Gifts, "Loans, Savings"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sales revenue
    })
  },
  {
    id: G8-PTS-INC-02",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Income and Budgeting",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A budget helps manage income and expenses. What is the term for the plan for spending and saving money?,
      options: [Budget, Savings plan, Investment plan", "Business plan].sort(() => Math.random() - 0.5),
      correctAnswer: Budget"
    })
  },
  {
    id: "G8-PTS-INC-03",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Income and Budgeting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Saving money helps achieve financial goals. Which of the following is a benefit of saving money?,
      options: [It provides financial security and helps achieve future goals., It makes you poor., "It increases expenses., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It provides financial security and helps achieve future goals.
    })
  },
  {
    id: G8-PTS-INC-04",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Income and Budgeting",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Prioritizing expenses is important when budgeting. What is the term for expenses that must be paid for basic needs?,
      options: [Essential expenses, Non-essential expenses, Luxury expenses", "Discretionary expenses].sort(() => Math.random() - 0.5),
      correctAnswer: Essential expenses"
    })
  },

  // --- 5.3 MARKETING GOODS AND SERVICES (4 Materials) ---
  {
    id: "G8-PTS-MAR-01",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Marketing Goods and Services,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Marketing involves promoting and selling products. What is the term for the four elements of marketing?,
      options: [Product, Price, Place, and Promotion, People, Process, Physical, and Promotion, "Product, Price, Promotion, and People, Place, Price, Promotion, and People"].sort(() => Math.random() - 0.5),
      correctAnswer: "Product, Price, Place, and Promotion
    })
  },
  {
    id: G8-PTS-MAR-02",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Marketing Goods and Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Advertising is a way of promoting products. Which of the following is a form of advertising?,
      options: [Social media ads, Word of mouth, Packaging", "Prices].sort(() => Math.random() - 0.5),
      correctAnswer: Social media ads"
    })
  },
  {
    id: "G8-PTS-MAR-03",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Marketing Goods and Services,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Pricing is important for product success. Which pricing strategy involves setting prices lower than competitors?,
      options: [Penetration pricing, Skimming pricing, "Premium pricing, Loss leader pricing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Penetration pricing
    })
  },
  {
    id: G8-PTS-MAR-04",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Marketing Goods and Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Understanding the target market is important in marketing. What is the term for the group of people a business wants to sell to?,
      options: [Target market, Customer base, Consumer group", "Audience].sort(() => Math.random() - 0.5),
      correctAnswer: Target market"
    })
  },

  // --- 5.4 DISTRIBUTION OF GOODS AND SERVICES (4 Materials) ---
  {
    id: "G8-PTS-DIS-01",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Distribution of Goods and Services,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Distribution is the process of getting products to customers. Which of the following is a distribution channel?,
      options: [Wholesalers, Advertising, "Pricing, Promotion"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wholesalers
    })
  },
  {
    id: G8-PTS-DIS-02",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Distribution of Goods and Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Retailers sell products directly to consumers. What is the term for a business that sells products in small quantities to consumers?,
      options: [Retailer, Wholesaler, Distributor", "Supplier].sort(() => Math.random() - 0.5),
      correctAnswer: Retailer"
    })
  },
  {
    id: "G8-PTS-DIS-03",
    grade: "Grade 8",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Distribution of Goods and Services,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Logistics is the management of the flow of goods. What is the term for the movement of goods from one place to another?,
      options: [Transportation, Storage, "Inventory, Order processing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Transportation
    })
  },
  {
    id: G8-PTS-DIS-04",
    grade: "Grade 8,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Distribution of Goods and Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Choosing the right distribution channel is important for business success. Why is it important to choose the right distribution channel?,
      options: [It ensures products reach customers efficiently and cost-effectively., It makes the product look better., It increases production costs.", "It reduces product quality.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures products reach customers efficiently and cost-effectively."
    })
  }`n// =========================================================================
// GRADE 9: 35 MATERIALS (KICD PRE-TECHNICAL STUDIES SYLLABUS)
// =========================================================================

  // --- STRAND 1: FOUNDATIONS OF PRE-TECHNICAL STUDIES ---

  // --- 1.1 PRE-TECHNICAL STUDIES IN SOCIETY (4 Materials) ---
  {
    id: "G9-PTS-SOC-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Pre-Technical Studies in Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Pre-Technical Studies plays an important role in society and economic development. How does Pre-Technical Studies contribute to national development?,
      options: [It equips learners with technical skills for careers in engineering, technology, and business., It only teaches theory., "It focuses only on entertainment., It has no impact on development."].sort(() => Math.random() - 0.5),
      correctAnswer: "It equips learners with technical skills for careers in engineering, technology, and business.
    })
  },
  {
    id: G9-PTS-SOC-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Pre-Technical Studies in Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Pre-Technical Studies helps address unemployment by creating entrepreneurs. What skill does Pre-Technical Studies develop that helps reduce unemployment?,
      options: [Entrepreneurial and technical skills, Only reading skills, Only writing skills", "Only listening skills].sort(() => Math.random() - 0.5),
      correctAnswer: Entrepreneurial and technical skills"
    })
  },
  {
    id: "G9-PTS-SOC-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Pre-Technical Studies in Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Pre-Technical Studies promotes technological advancement in society. What is the importance of technology in modern society?,
      options: [It improves efficiency, communication, and quality of life., It only creates problems., "It is not important., It slows down development."].sort(() => Math.random() - 0.5),
      correctAnswer: "It improves efficiency, communication, and quality of life.
    })
  },
  {
    id: G9-PTS-SOC-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Pre-Technical Studies in Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Pre-Technical Studies prepares learners for the world of work. Which of the following career pathways does Pre-Technical Studies prepare learners for?,
      options: [Technical, business, and engineering careers, Only medical careers, Only teaching careers", "Only legal careers].sort(() => Math.random() - 0.5),
      correctAnswer: Technical, business, and engineering careers"
    })
  },

  // --- 1.2 SAFETY IN THE WORKPLACE (4 Materials) ---
  {
    id: "G9-PTS-SAF-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Safety in the Workplace,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Workplace safety is essential to prevent accidents and injuries. What is the term for the condition of being protected from physical, social, and emotional harm in the workplace?,
      options: ["Workplace safety, Workplace efficiency", "Workplace productivity, Workplace morale"].sort(() => Math.random() - 0.5),
      correctAnswer: "Workplace safety
    })
  },
  {
    id: G9-PTS-SAF-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Safety in the Workplace",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Personal Protective Equipment (PPE) protects workers from workplace hazards. Which of the following is an example of PPE used in a workshop?,
      options: [Safety boots, School uniform, T-shirt", "Sandals].sort(() => Math.random() - 0.5),
      correctAnswer: Safety boots"
    })
  },
  {
    id: "G9-PTS-SAF-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies",
    subtopic: "Safety in the Workplace,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Workplace hazards can cause injury or illness. What is the term for a potential source of harm in the workplace?,
      options: [Hazard, Risk, "Accident, Incident"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hazard
    })
  },
  {
    id: G9-PTS-SAF-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Foundations of Pre-Technical Studies,
    subtopic: "Safety in the Workplace",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Fire safety in the workplace requires proper planning and equipment. What is the first thing you should do if you discover a fire in the workplace?,
      options: [Sound the fire alarm and evacuate immediately., Try to put it out yourself., Ignore it.", "Wait for someone else to act.].sort(() => Math.random() - 0.5),
      correctAnswer: Sound the fire alarm and evacuate immediately."
    })
  },

  // --- STRAND 2: COMMUNICATION ---

  // --- 2.1 TECHNICAL DRAWING (4 Materials) ---
  {
    id: "G9-PTS-TEC-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Technical Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Technical drawing uses standardized symbols and conventions. What is the term for the drawing that shows the front, top, and side views of an object?,
      options: ["Orthographic projection, Isometric projection", "Perspective drawing, Oblique drawing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Orthographic projection
    })
  },
  {
    id: G9-PTS-TEC-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Technical Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different types of lines are used in technical drawings. What type of line is used to show hidden edges of an object?,
      options: [Dashed line, Continuous thick line, Chain line", "Continuous thin line].sort(() => Math.random() - 0.5),
      correctAnswer: Dashed line"
    })
  },
  {
    id: "G9-PTS-TEC-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Technical Drawing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sectional views are used to show internal features of an object. What is the term for the pattern of lines used to indicate cut surfaces in a sectional view?,
      options: [Hatching, Cross-hatching, "Stippling, Shading"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hatching
    })
  },
  {
    id: G9-PTS-TEC-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Technical Drawing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Drawing instruments are essential for creating accurate technical drawings. Which instrument is used to draw circles and arcs?,
      options: [Compass, T-square, Protractor", "Set square].sort(() => Math.random() - 0.5),
      correctAnswer: Compass"
    })
  },

  // --- 2.2 3D DRAWING AND MODELING (4 Materials) ---
  {
    id: "G9-PTS-3D-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "3D Drawing and Modeling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "3D drawing and modeling represent objects in three dimensions. What is the term for the software used to create 3D models?,
      options: [CAD software, Word processor, "Spreadsheet software, Presentation software"].sort(() => Math.random() - 0.5),
      correctAnswer: "CAD software
    })
  },
  {
    id: G9-PTS-3D-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "3D Drawing and Modeling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " 3D models are used in many industries for design and visualization. Which of the following is an advantage of using 3D modeling in design?,
      options: [It allows visualization of designs before production., It is more expensive., It takes more time.", "It is not accurate.].sort(() => Math.random() - 0.5),
      correctAnswer: It allows visualization of designs before production."
    })
  },
  {
    id: "G9-PTS-3D-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "3D Drawing and Modeling,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "3D printers can produce physical models from digital designs. What is the term for the process of creating a physical object from a digital 3D model?,
      options: [3D printing, CNC machining, "Injection molding, Casting"].sort(() => Math.random() - 0.5),
      correctAnswer: "3D printing
    })
  },
  {
    id: G9-PTS-3D-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "3D Drawing and Modeling",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " 3D modeling is used in various industries. Which industry uses 3D modeling for architectural designs?,
      options: [Architecture, Fashion, Food", "Music].sort(() => Math.random() - 0.5),
      correctAnswer: Architecture"
    })
  },

  // --- 2.3 COMPUTER NETWORKING (4 Materials) ---
  {
    id: "G9-PTS-NET-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Computer Networking,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Computer networks connect devices to share resources. What is the term for a network that connects computers in a small area like a school?,
      options: [LAN, WAN, "MAN, PAN"].sort(() => Math.random() - 0.5),
      correctAnswer: "LAN
    })
  },
  {
    id: G9-PTS-NET-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Computer Networking",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Network topologies describe how devices are connected. Which network topology connects all devices to a central hub or switch?,
      options: [Star topology, Bus topology, Ring topology", "Mesh topology].sort(() => Math.random() - 0.5),
      correctAnswer: Star topology"
    })
  },
  {
    id: "G9-PTS-NET-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Communication",
    subtopic: "Computer Networking,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Wireless networking uses radio waves to connect devices. What is the term for the standard used for wireless networking?,
      options: [Wi-Fi, Ethernet, "Bluetooth, USB"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wi-Fi
    })
  },
  {
    id: G9-PTS-NET-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Communication,
    subtopic: "Computer Networking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The internet is a global network of networks. What is the term for the unique address that identifies a device on a network?,
      options: [IP address, MAC address, Domain name", "URL].sort(() => Math.random() - 0.5),
      correctAnswer: IP address"
    })
  },

  // --- STRAND 3: MATERIALS FOR PRODUCTION ---

  // --- 3.1 TIMBER AND WOOD PRODUCTS (4 Materials) ---
  {
    id: "G9-PTS-TIM-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Timber and Wood Products,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Timber is wood that has been processed for construction and manufacturing. What is the term for the wood that comes from trees that lose their leaves annually?,
      options: [Hardwood, Softwood, "Engineered wood, Plywood"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hardwood
    })
  },
  {
    id: G9-PTS-TIM-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Timber and Wood Products",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Wood products are used in many applications. Which of the following is an engineered wood product made by gluing thin layers of wood together?,
      options: [Plywood, Solid wood, Timber", "Lumber].sort(() => Math.random() - 0.5),
      correctAnswer: Plywood"
    })
  },
  {
    id: "G9-PTS-TIM-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Timber and Wood Products,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The quality of timber depends on how it is processed. What is the term for the process of drying timber to remove moisture?,
      options: [Seasoning, Felling, "Sawing, Planing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Seasoning
    })
  },
  {
    id: G9-PTS-TIM-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Timber and Wood Products",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Wood is a versatile material with many uses. Which of the following is NOT a common use of timber?,
      options: [Making plastics, Furniture making, Construction", "Paper production].sort(() => Math.random() - 0.5),
      correctAnswer: Making plastics"
    })
  },

  // --- 3.2 POLYMERS AND PLASTICS (4 Materials) ---
  {
    id: "G9-PTS-POL-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Polymers and Plastics,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Polymers are large molecules made from repeating units. What is the term for the process of creating polymers from smaller units called monomers?,
      options: [Polymerization, Compounding, "Recycling, Extrusion"].sort(() => Math.random() - 0.5),
      correctAnswer: "Polymerization
    })
  },
  {
    id: G9-PTS-POL-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Polymers and Plastics",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Plastics can be classified based on their properties. Which type of plastic can be reheated and reshaped multiple times?,
      options: [Thermoplastics, Thermosetting plastics, Elastomers", "Composites].sort(() => Math.random() - 0.5),
      correctAnswer: Thermoplastics"
    })
  },
  {
    id: "G9-PTS-POL-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Materials for Production",
    subtopic: "Polymers and Plastics,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Plastics are used extensively in packaging and manufacturing. Which of the following is a common plastic material?,
      options: [Polyethylene, Steel, "Glass, Aluminum"].sort(() => Math.random() - 0.5),
      correctAnswer: "Polyethylene
    })
  },
  {
    id: G9-PTS-POL-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Materials for Production,
    subtopic: "Polymers and Plastics",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Plastic pollution is a major environmental concern. What is the term for the process of converting waste plastics into new products?,
      options: [Recycling, Burning, Landfilling", "Composting].sort(() => Math.random() - 0.5),
      correctAnswer: Recycling"
    })
  },

  // --- STRAND 4: TOOLS AND PRODUCTION ---

  // --- 4.1 JOINING TOOLS (4 Materials) ---
  {
    id: "G9-PTS-JOI-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Joining Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Joining tools are used to connect materials together. Which of the following is a mechanical joining method?,
      options: [Nut and bolt, Welding, "Soldering, Gluing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nut and bolt
    })
  },
  {
    id: G9-PTS-JOI-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Joining Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Nails and screws are common joining tools used in woodworking. What type of screw has a flat head and is driven by a screwdriver?,
      options: [Flathead screw, Phillips head screw, Torx screw", "Hex screw].sort(() => Math.random() - 0.5),
      correctAnswer: Flathead screw"
    })
  },
  {
    id: "G9-PTS-JOI-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Joining Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Adhesives are used to bond materials together. Which of the following is an example of a strong adhesive used for wood?,
      options: [Wood glue, School glue, "Hot glue, Super glue"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wood glue
    })
  },
  {
    id: G9-PTS-JOI-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Joining Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Welding is a permanent joining method used for metals. What is the term for the process of joining metals by melting them together?,
      options: [Welding, Soldering, Brazing", "Riveting].sort(() => Math.random() - 0.5),
      correctAnswer: Welding"
    })
  },

  // --- 4.2 COMPUTER SYSTEMS AND SECURITY (4 Materials) ---
  {
    id: "G9-PTS-SYS-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Computer Systems and Security,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Computer systems consist of hardware and software working together. What is the term for the software that manages hardware and runs applications?,
      options: [Operating system, Application software, "System software, Utility software"].sort(() => Math.random() - 0.5),
      correctAnswer: "Operating system
    })
  },
  {
    id: G9-PTS-SYS-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Systems and Security",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Computer security protects systems from threats. What is the term for malicious software designed to harm a computer system?,
      options: [Malware, Virus, Spyware", "Trojan].sort(() => Math.random() - 0.5),
      correctAnswer: Malware"
    })
  },
  {
    id: "G9-PTS-SYS-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Tools and Production",
    subtopic: "Computer Systems and Security,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Firewalls protect networks from unauthorized access. What is the term for a system that monitors and controls incoming and outgoing network traffic?,
      options: [Firewall, Antivirus, "Proxy server, Router"].sort(() => Math.random() - 0.5),
      correctAnswer: "Firewall
    })
  },
  {
    id: G9-PTS-SYS-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Tools and Production,
    subtopic: "Computer Systems and Security",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Data security involves protecting data from unauthorized access. What is the term for the process of converting data into a coded form to protect it?,
      options: [Encryption, Decryption, Encoding", "Hashing].sort(() => Math.random() - 0.5),
      correctAnswer: Encryption"
    })
  },

  // --- STRAND 5: ENTREPRENEURSHIP ---

  // --- 5.1 RECORD KEEPING (4 Materials) ---
  {
    id: "G9-PTS-REC-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Record Keeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Record keeping is the process of storing and organizing business information. Which of the following is a financial record kept by a business?,
      options: [Sales ledger, Staff roster, "Customer list, Price list"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sales ledger
    })
  },
  {
    id: G9-PTS-REC-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Record Keeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Business records can be kept manually or digitally. What is the advantage of using digital records over manual records?,
      options: [They are easier to store and retrieve., They are always accurate., They are cheaper.", "They are more secure.].sort(() => Math.random() - 0.5),
      correctAnswer: They are easier to store and retrieve."
    })
  },
  {
    id: "G9-PTS-REC-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Record Keeping,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Accurate records are essential for business success. Why is it important for a business to keep accurate records?,
      options: [To make informed decisions and comply with legal requirements., To look professional., "To spend money., To hire more staff."].sort(() => Math.random() - 0.5),
      correctAnswer: "To make informed decisions and comply with legal requirements.
    })
  },
  {
    id: G9-PTS-REC-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Record Keeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Different types of records are kept for different purposes. Which record shows all the money received and paid by a business?,
      options: [Cash book, Sales ledger, Purchase ledger", "Balance sheet].sort(() => Math.random() - 0.5),
      correctAnswer: Cash book"
    })
  },

  // --- 5.2 PROFIT AND LOSS (4 Materials) ---
  {
    id: "G9-PTS-PRO-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Profit and Loss,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Profit is the financial gain from business activities. What is the term for the total amount of money received from sales?,
      options: [Revenue, Profit, "Income, Earnings"].sort(() => Math.random() - 0.5),
      correctAnswer: "Revenue
    })
  },
  {
    id: G9-PTS-PRO-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Profit and Loss",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A profit and loss statement shows business performance over time. What does it mean when a business has a loss?,
      options: [Expenses are greater than revenue., Revenue is greater than expenses., Revenue equals expenses.", "There is no revenue.].sort(() => Math.random() - 0.5),
      correctAnswer: Expenses are greater than revenue."
    })
  },
  {
    id: "G9-PTS-PRO-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Profit and Loss,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Calculating profit helps business owners make decisions. How is profit calculated?,
      options: [Profit = Revenue - Expenses, Profit = Revenue + Expenses, "Profit = Revenue × Expenses, Profit = Revenue ÷ Expenses"].sort(() => Math.random() - 0.5),
      correctAnswer: "Profit = Revenue - Expenses
    })
  },
  {
    id: G9-PTS-PRO-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Profit and Loss",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Analyzing profit and loss helps in business planning. Which of the following is a way to increase profit?,
      options: [Increasing sales or reducing expenses., Decreasing sales., Increasing expenses.", "Reducing quality.].sort(() => Math.random() - 0.5),
      correctAnswer: Increasing sales or reducing expenses."
    })
  },

  // --- 5.3 CREDIT AND LOANS (4 Materials) ---
  {
    id: "G9-PTS-CRE-01",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Credit and Loans,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Credit allows businesses to buy now and pay later. What is the term for the ability to obtain goods or services before payment?,
      options: [Credit, Loan, "Debt, Savings"].sort(() => Math.random() - 0.5),
      correctAnswer: "Credit
    })
  },
  {
    id: G9-PTS-CRE-02",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Credit and Loans",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Loans are a common source of financing for businesses. What is the term for the amount charged by lenders for borrowing money?,
      options: [Interest, Principal, Deposit", "Installment].sort(() => Math.random() - 0.5),
      correctAnswer: Interest"
    })
  },
  {
    id: "G9-PTS-CRE-03",
    grade: "Grade 9",
    subject: "Pre-Technical Studies",
    topic: "Entrepreneurship",
    subtopic: "Credit and Loans,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "There are different types of loans available for businesses. Which type of loan requires collateral?,
      options: [Secured loan, Unsecured loan, "Short-term loan, Long-term loan"].sort(() => Math.random() - 0.5),
      correctAnswer: "Secured loan
    })
  },
  {
    id: G9-PTS-CRE-04",
    grade: "Grade 9,
    subject: Pre-Technical Studies",
    topic: "Entrepreneurship,
    subtopic: "Credit and Loans",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Managing debt is important for business survival. What is the term for the ability to repay loans on time and in full?,
      options: [Creditworthiness, Credit score, Financial health", "Liquidity].sort(() => Math.random() - 0.5),
      correctAnswer: Creditworthiness"
    })
  }

];


