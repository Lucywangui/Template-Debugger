export const literatureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD LITERATURE SYLLABUS)
  // =========================================================================

  // --- INTRODUCTION TO LITERATURE (4 Materials) ---
  {
    id: "G10-LIT-IL-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Introduction to Literature",
    subtopic: "Definition of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "Literature is a body of written, spoken, or performed works that express human experiences, emotions, and ideas. Which of the following best defines literature as an art form?,
      options: [
        "Literature is the artistic expression of human experiences through language, encompassing various genres such as prose, poetry, and drama, and reflecting the cultural, social, and historical contexts in which it is created.,
        Literature is any written text without artistic merit.",
        "Literature is the study of grammar and language rules.,
        Literature is only poetry and does not include prose."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literature is the artistic expression of human experiences through language, encompassing various genres such as prose, poetry, and drama, and reflecting the cultural, social, and historical contexts in which it is created.
    })
  },
  {
    id: G10-LIT-IL-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Introduction to Literature,
    subtopic: "Genres of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Literature is broadly divided into genres, each with distinct characteristics. Which of the following is NOT a major genre of literature?,
      options: [
        Prose, poetry, and drama are the three major genres of literature, with prose including novels and short stories, poetry using rhythmic and figurative language, and drama written for performance.,
        Prose is a major genre of literature.,
        Poetry is a major genre of literature.",
        "Drama is a major genre of literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Prose, poetry, and drama are the three major genres of literature, with prose including novels and short stories, poetry using rhythmic and figurative language, and drama written for performance."
    })
  },
  {
    id: "G10-LIT-IL-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Introduction to Literature",
    subtopic: "Literary Appreciation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Literary appreciation involves understanding and enjoying literary works. Which of the following is an important aspect of literary appreciation?,
      options: [
        Literary appreciation involves analyzing the themes, characters, plot, language, and style of a literary work, as well as understanding its cultural and historical context and the author's purpose.,
        Literary appreciation only involves reading the text once.,
        "Literary appreciation does not require analysis of themes.,
        Literary appreciation is only about memorizing facts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literary appreciation involves analyzing the themes, characters, plot, language, and style of a literary work, as well as understanding its cultural and historical context and the author's purpose.
    })
  },
  {
    id: G10-LIT-IL-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Introduction to Literature,
    subtopic: "Purpose of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Literature serves various purposes in society. Which of the following is a purpose of literature?,
      options: [
        Literature serves to entertain, educate, inform, challenge societal norms, preserve culture, and enable readers to explore human experiences, emotions, and perspectives from different viewpoints.,
        Literature only serves to entertain.,
        Literature has no educational value.",
        "Literature does not preserve culture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Literature serves to entertain, educate, inform, challenge societal norms, preserve culture, and enable readers to explore human experiences, emotions, and perspectives from different viewpoints."
    })
  },

  // --- THE NOVEL (5 Materials) ---
  {
    id: "G10-LIT-NV-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Elements of the Novel,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "A novel is a long work of prose fiction that tells a story. Which of the following is a key element of a novel?,
      options: [
        The key elements of a novel include plot (the sequence of events), characters (the people in the story), setting (the time and place), theme (the central idea), point of view (the perspective from which the story is told), and style (the author's use of language).,
        A novel only has characters and a plot.,
        "Setting is not an element of a novel.,
        Point of view is not an element of a novel."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The key elements of a novel include plot (the sequence of events), characters (the people in the story), setting (the time and place), theme (the central idea), point of view (the perspective from which the story is told), and style (the author's use of language).
    })
  },
  {
    id: G10-LIT-NV-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "The Novel,
    subtopic: "Plot Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The plot of a novel follows a specific structure that creates narrative tension and resolution. Which of the following correctly describes the parts of a plot structure in a novel?,
      options: [
        A plot typically follows the structure: exposition (introduction), rising action (building conflict), climax (the turning point), falling action (resolving conflict), and resolution (the conclusion).,
        A plot structure has only two parts: beginning and end.,
        The climax is not part of a plot structure.",
        "Falling action occurs before the rising action.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A plot typically follows the structure: exposition (introduction), rising action (building conflict), climax (the turning point), falling action (resolving conflict), and resolution (the conclusion)."
    })
  },
  {
    id: "G10-LIT-NV-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Characterization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Characterization is the process by which an author reveals the personality of a character. Which of the following is a method of characterization in a novel?,
      options: [
        Methods of characterization include direct characterization (the author directly describes the character) and indirect characterization (revealing the character through their actions, speech, thoughts, appearance, and how others react to them).,
        Characterization is only done through direct description.,
        "Indirect characterization does not occur in novels.,
        Characters' actions do not reveal their personality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Methods of characterization include direct characterization (the author directly describes the character) and indirect characterization (revealing the character through their actions, speech, thoughts, appearance, and how others react to them).
    })
  },
  {
    id: G10-LIT-NV-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "The Novel,
    subtopic: "Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Theme is the central idea or underlying message of a novel. Which of the following is an example of a common theme in African novels?,
      options: [
        Common themes in African novels include colonialism and its effects, identity and belonging, tradition versus modernity, corruption, power and leadership, social injustice, and the struggle for freedom and self-determination.,
        African novels only address traditional African culture.,
        Colonialism is not a theme in African novels.",
        "African novels do not address contemporary issues.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African novels include colonialism and its effects, identity and belonging, tradition versus modernity, corruption, power and leadership, social injustice, and the struggle for freedom and self-determination."
    })
  },
  {
    id: "G10-LIT-NV-05",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Point of View,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Point of view is the perspective from which a story is told. Which of the following describes a first-person point of view in a novel?,
      options: [
        A first-person point of view uses the pronoun 'I' and the narrator is a character in the story, telling the events from their personal perspective and sharing their thoughts and feelings.,
        First-person point of view is told from the perspective of an omniscient narrator.,
        "First-person point of view uses the pronoun 'he' or 'she'.,
        First-person point of view only focuses on external events."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A first-person point of view uses the pronoun 'I' and the narrator is a character in the story, telling the events from their personal perspective and sharing their thoughts and feelings.
    })
  },

  // --- SHORT STORIES (5 Materials) ---
  {
    id: G10-LIT-SS-01",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Elements of Short Stories",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A short story is a brief work of fiction that focuses on a single incident or character. Which of the following distinguishes a short story from a novel?,
      options: [
        A short story is shorter in length, focuses on a single incident or character, has a limited number of characters, and typically develops a single theme or idea, whereas a novel is longer and more complex.,
        Short stories are always more complex than novels.,
        Short stories have multiple themes.",
        "Short stories are not works of fiction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A short story is shorter in length, focuses on a single incident or character, has a limited number of characters, and typically develops a single theme or idea, whereas a novel is longer and more complex."
    })
  },
  {
    id: "G10-LIT-SS-02",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Short Stories",
    subtopic: "Plot in Short Stories,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The plot of a short story is usually simple and focused on a single conflict. Which of the following is a characteristic of plot in short stories?,
      options: [
        Short stories typically have a simple plot structure that focuses on a single incident or conflict, with a clear beginning, middle, and end, and often ends with a twist or a moment of realization.,
        Short stories have complex, multi-layered plots.,
        "Short stories do not have a resolution.,
        Short stories have many subplots."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Short stories typically have a simple plot structure that focuses on a single incident or conflict, with a clear beginning, middle, and end, and often ends with a twist or a moment of realization.
    })
  },
  {
    id: G10-LIT-SS-03",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Characterization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Characterization in short stories is often economical and focused. Which of the following is a technique used to develop characters in a short story?,
      options: [
        Authors develop characters in short stories through selective detail, dialogue, actions, and thoughts, often revealing key traits quickly to create vivid and memorable characters in limited space.,
        Characterization in short stories requires extensive description.,
        Short stories do not focus on character development.",
        "Dialogue is not used for characterization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Authors develop characters in short stories through selective detail, dialogue, actions, and thoughts, often revealing key traits quickly to create vivid and memorable characters in limited space."
    })
  },
  {
    id: "G10-LIT-SS-04",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Short Stories",
    subtopic: "Themes,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Short stories often explore universal themes in a concise form. Which of the following is a common theme in short stories?,
      options: [
        Common themes in short stories include love, loss, identity, morality, conflict, cultural clashes, betrayal, forgiveness, and the human condition, often presented with clarity and impact.,
        Short stories only explore political themes.,
        "Short stories do not have themes.,
        Short stories only explore supernatural themes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Common themes in short stories include love, loss, identity, morality, conflict, cultural clashes, betrayal, forgiveness, and the human condition, often presented with clarity and impact.
    })
  },
  {
    id: G10-LIT-SS-05",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Setting",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Setting includes the time, place, and social environment in which a story takes place. Which of the following is a function of setting in a short story?,
      options: [
        Setting functions to create atmosphere and mood, influence characters' actions and beliefs, symbolize themes, and provide historical and cultural context, helping readers understand the story more deeply.,
        Setting has no effect on a story's meaning.,
        Setting only refers to the physical location.",
        "Setting does not influence characters.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Setting functions to create atmosphere and mood, influence characters' actions and beliefs, symbolize themes, and provide historical and cultural context, helping readers understand the story more deeply."
    })
  },

  // --- POETRY (5 Materials) ---
  {
    id: "G10-LIT-PO-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Elements of Poetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Poetry is a form of literature that uses aesthetic and rhythmic qualities of language. Which of the following is a key element of poetry?,
      options: [
        Key elements of poetry include rhyme, rhythm, meter, imagery, figurative language, symbolism, tone, and structure, all of which work together to create meaning and evoke emotion.,
        Poetry does not have structure.,
        "Rhyme is not an element of poetry.,
        Poetry does not use figurative language."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Key elements of poetry include rhyme, rhythm, meter, imagery, figurative language, symbolism, tone, and structure, all of which work together to create meaning and evoke emotion.
    })
  },
  {
    id: G10-LIT-PO-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Poetry,
    subtopic: "Forms of Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Poetry exists in various forms with distinct structures. Which of the following is a form of poetry that consists of fourteen lines and follows a specific rhyme scheme?,
      options: [
        A sonnet is a poem of fourteen lines with a specific rhyme scheme, usually in iambic pentameter, with the Shakespearean sonnet having three quatrains and a couplet (ABAB CDCD EFEF GG).,
        An epic is a fourteen-line poem.,
        A haiku is a fourteen-line poem.",
        "A villanelle is a fourteen-line poem.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A sonnet is a poem of fourteen lines with a specific rhyme scheme, usually in iambic pentameter, with the Shakespearean sonnet having three quatrains and a couplet (ABAB CDCD EFEF GG)."
    })
  },
  {
    id: "G10-LIT-PO-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Imagery,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Imagery is a vital element of poetry that appeals to the senses. Which of the following is an example of visual imagery in poetry?,
      options: [
        Visual imagery appeals to the sense of sight, creating pictures in the reader's mind, such as 'The golden sun sank slowly behind the purple hills,' evoking a vivid visual image.,
        Visual imagery appeals to the sense of hearing.,
        "Visual imagery is not used in poetry.,
        Visual imagery describes tastes and smells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Visual imagery appeals to the sense of sight, creating pictures in the reader's mind, such as 'The golden sun sank slowly behind the purple hills,' evoking a vivid visual image.
    })
  },
  {
    id: G10-LIT-PO-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Poetry,
    subtopic: "Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Figurative language is used extensively in poetry to create meaning and effect. Which of the following is a metaphor?,
      options: [
        A metaphor is a figure of speech that compares two unlike things by stating that one thing is the other, without using 'like' or 'as,' such as 'The world is a stage'.,
        A metaphor uses 'like' or 'as' to compare things.,
        A metaphor is a comparison of similar things.",
        "A metaphor is a personification.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A metaphor is a figure of speech that compares two unlike things by stating that one thing is the other, without using 'like' or 'as,' such as 'The world is a stage'."
    })
  },
  {
    id: "G10-LIT-PO-05",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Tone and Mood,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Tone and mood are important aspects of poetry that affect the reader's experience. Which of the following describes the difference between tone and mood in a poem?,
      options: [
        Tone is the poet's attitude toward the subject or audience (revealed through word choice and style), while mood is the emotional atmosphere that the poem creates for the reader.,
        Tone and mood are the same thing.,
        "Tone is created by the reader's emotions.,
        Mood is the author's attitude."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tone is the poet's attitude toward the subject or audience (revealed through word choice and style), while mood is the emotional atmosphere that the poem creates for the reader.
    })
  },

  // --- DRAMA (5 Materials) ---
  {
    id: G10-LIT-DR-01",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Elements of Drama",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Drama is a genre of literature intended for performance. Which of the following is a key element of drama?,
      options: [
        Key elements of drama include plot, characters, dialogue, setting, stage directions, conflict, and theme, all of which contribute to the performance and meaning of the play.,
        Drama does not require dialogue.,
        Stage directions are not part of drama.",
        "Conflict is not an element of drama.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Key elements of drama include plot, characters, dialogue, setting, stage directions, conflict, and theme, all of which contribute to the performance and meaning of the play."
    })
  },
  {
    id: "G10-LIT-DR-02",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Drama",
    subtopic: "Types of Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Drama can be classified into different types based on its content and tone. Which of the following is a type of drama that addresses serious and often tragic themes, typically involving a noble protagonist who experiences a downfall?,
      options: [
        A tragedy is a type of drama that deals with serious themes and ends in disaster or downfall for the protagonist, often due to a tragic flaw or circumstances beyond their control.,
        A comedy is a tragedy.",
        "A tragedy has a happy ending.,
        A tragedy only features comic elements."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A tragedy is a type of drama that deals with serious themes and ends in disaster or downfall for the protagonist, often due to a tragic flaw or circumstances beyond their control.
    })
  },
  {
    id: G10-LIT-DR-03",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Dialogue",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Dialogue is a fundamental element of drama that reveals character and advances the plot. Which of the following is a function of dialogue in a play?,
      options: [
        Dialogue functions to reveal character traits and relationships, advance the plot, create conflict and tension, provide exposition and background information, and create dramatic effect.,
        Dialogue is only used for entertainment.,
        Dialogue does not reveal character.",
        "Dialogue does not advance the plot.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dialogue functions to reveal character traits and relationships, advance the plot, create conflict and tension, provide exposition and background information, and create dramatic effect."
    })
  },
  {
    id: "G10-LIT-DR-04",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Drama",
    subtopic: "Stage Directions,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Stage directions are instructions in a play that guide the performance. Which of the following is provided by stage directions in a play?,
      options: [
        Stage directions provide information about the setting, characters' movements, gestures, facial expressions, tone of voice, and other aspects of the performance that are not conveyed through dialogue.,
        Stage directions are only for the audience.,
        "Stage directions are the same as dialogue.,
        Stage directions are not important in drama."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Stage directions provide information about the setting, characters' movements, gestures, facial expressions, tone of voice, and other aspects of the performance that are not conveyed through dialogue.
    })
  },
  {
    id: G10-LIT-DR-05",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Drama explores various themes relevant to human experience. Which of the following is a common theme in African drama?,
      options: [
        Common themes in African drama include the clash between tradition and modernity, the impact of colonialism and post-colonialism, corruption and the abuse of power, identity and belonging, social justice, and the struggle for independence and freedom.,
        African drama only explores historical themes.,
        Corruption is not a theme in African drama.",
        "African drama does not address social justice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African drama include the clash between tradition and modernity, the impact of colonialism and post-colonialism, corruption and the abuse of power, identity and belonging, social justice, and the struggle for independence and freedom."
    })
  },

  // --- ORAL LITERATURE (4 Materials) ---
  {
    id: "G10-LIT-OL-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Oral Literature",
    subtopic: "Genres of Oral Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Oral literature refers to stories, poems, and performances that are passed down through word of mouth. Which of the following is a genre of oral literature?,
      options: [
        "Genres of oral literature include folktales, myths, legends, proverbs, riddles, oral poetry, songs, and oral narratives, which are transmitted through speech and performance across generations.,
        Oral literature only includes written texts.",
        "Proverbs are not part of oral literature.,
        Oral literature does not include songs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Genres of oral literature include folktales, myths, legends, proverbs, riddles, oral poetry, songs, and oral narratives, which are transmitted through speech and performance across generations.
    })
  },
  {
    id: G10-LIT-OL-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Oral Literature,
    subtopic: "Features of Oral Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Oral literature has distinct features that reflect its oral and performative nature. Which of the following is a feature of oral literature?,
      options: [
        Features of oral literature include the use of repetition, parallelism, formulaic language, call-and-response patterns, performance and audience participation, and variation in transmission from one teller to another.,
        Oral literature is always fixed and unchanging.,
        Repetition is not a feature of oral literature.",
        "Performance is not part of oral literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Features of oral literature include the use of repetition, parallelism, formulaic language, call-and-response patterns, performance and audience participation, and variation in transmission from one teller to another."
    })
  },
  {
    id: "G10-LIT-OL-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Oral Literature",
    subtopic: "Function of Oral Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Oral literature serves important functions in African communities. Which of the following is a function of oral literature?,
      options: [
        Oral literature functions to educate and pass on knowledge, entertain, preserve culture and traditions, convey moral values, provide social commentary, and foster community cohesion and identity.,
        Oral literature only serves to entertain.,
        "Oral literature does not pass on knowledge.,
        Oral literature does not preserve culture."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Oral literature functions to educate and pass on knowledge, entertain, preserve culture and traditions, convey moral values, provide social commentary, and foster community cohesion and identity.
    })
  },
  {
    id: G10-LIT-OL-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Oral Literature,
    subtopic: "Performance",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Performance is integral to oral literature. Which of the following is an element of performance in oral literature?,
      options: [
        Performance in oral literature includes aspects such as voice modulation, gestures, facial expressions, movement, audience participation, and the use of music and dance to enhance the delivery and impact of the narrative.,
        Performance is not part of oral literature.,
        Oral literature does not involve audience participation.",
        "Music is not used in oral literature performance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Performance in oral literature includes aspects such as voice modulation, gestures, facial expressions, movement, audience participation, and the use of music and dance to enhance the delivery and impact of the narrative."
    })
  },

  // --- LITERARY DEVICES (4 Materials) ---
  {
    id: "G10-LIT-LD-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Literary Devices",
    subtopic: "Simile and Metaphor,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Similes and metaphors are important figures of speech used in literature. Which of the following is the difference between a simile and a metaphor?,
      options: [
        A simile compares two unlike things using 'like' or 'as' (e.g., 'Her eyes are like stars'), while a metaphor states that one thing is another (e.g., 'Her eyes are stars').,
        A simile and metaphor are the same.,
        "A simile does not use 'like' or 'as'.,
        A metaphor uses 'like' or 'as'."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A simile compares two unlike things using 'like' or 'as' (e.g., 'Her eyes are like stars'), while a metaphor states that one thing is another (e.g., 'Her eyes are stars').
    })
  },
  {
    id: G10-LIT-LD-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Literary Devices,
    subtopic: "Personification",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Personification is a literary device that gives human qualities to non-human things. Which of the following is an example of personification in literature?,
      options: [
        Personification gives human qualities to inanimate objects or abstract concepts, such as 'The wind whispered through the trees' or 'The sun smiled down on the children,' where the wind and sun are described as human-like.,
        Personification describes animals.,
        Personification is the same as simile.",
        "Personification does not involve human qualities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Personification gives human qualities to inanimate objects or abstract concepts, such as 'The wind whispered through the trees' or 'The sun smiled down on the children,' where the wind and sun are described as human-like."
    })
  },
  {
    id: "G10-LIT-LD-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Literary Devices",
    subtopic: "Symbolism,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Symbolism is a literary device where objects, characters, or events represent abstract ideas. Which of the following is an example of symbolism in literature?,
      options: [
        "Symbolism uses objects, colors, or events to represent deeper meanings, such as a dove symbolizing peace, a red rose symbolizing love, or a storm symbolizing conflict or turmoil in a narrative.,
        Symbolism is the same as metaphor.",
        "Symbolism uses literal meanings only.,
        A dove is never used as a symbol."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Symbolism uses objects, colors, or events to represent deeper meanings, such as a dove symbolizing peace, a red rose symbolizing love, or a storm symbolizing conflict or turmoil in a narrative.
    })
  },
  {
    id: G10-LIT-LD-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Literary Devices,
    subtopic: "Irony",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Irony is a literary device where the intended meaning is opposite to the literal meaning. Which of the following is an example of dramatic irony in literature?,
      options: [
        Dramatic irony occurs when the audience knows something that the characters do not, such as in a tragedy where the audience knows a character is doomed, but the character remains unaware.,
        Dramatic irony is the same as verbal irony.,
        In dramatic irony, the characters know more than the audience.",
        "Dramatic irony does not involve the audience.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dramatic irony occurs when the audience knows something that the characters do not, such as in a tragedy where the audience knows a character is doomed, but the character remains unaware."
    })
  },

  // --- CREATIVE WRITING (3 Materials) ---
  {
    id: "G10-LIT-CW-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Writing Narratives,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Creative writing involves expressing ideas and emotions in an imaginative way. Which of the following is an important element of narrative writing?,
      options: [
        Key elements of narrative writing include a clear plot structure, well-developed characters, vivid setting, engaging dialogue, and a central theme or message that gives the story meaning.,
        Narrative writing does not require a plot.,
        "Dialogue is not important in narrative writing.,
        Characters are not essential in narrative writing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Key elements of narrative writing include a clear plot structure, well-developed characters, vivid setting, engaging dialogue, and a central theme or message that gives the story meaning.
    })
  },
  {
    id: G10-LIT-CW-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Writing Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Writing poetry requires attention to language and form. Which of the following is an important consideration when writing a poem?,
      options: [
        Important considerations in writing poetry include the use of imagery and figurative language, attention to rhythm and sound (rhyme, alliteration), careful word choice to convey meaning concisely, and structure (line breaks, stanzas).,
        Poetry does not require attention to rhythm.,
        Figurative language is not important in poetry.",
        "Structure is not important in poetry.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Important considerations in writing poetry include the use of imagery and figurative language, attention to rhythm and sound (rhyme, alliteration), careful word choice to convey meaning concisely, and structure (line breaks, stanzas)."
    })
  },
  {
    id: "G10-LIT-CW-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Writing Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Writing drama requires consideration of performance elements. Which of the following is an important aspect of writing a play?,
      options: [
        Important aspects of playwriting include creating believable dialogue that reveals character, structuring the play into acts and scenes, including stage directions to guide performance, and developing dramatic tension through conflict.,
        Dialogue is not important in playwriting.,
        "Stage directions are not part of a play.,
        Conflict is not important in drama."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Important aspects of playwriting include creating believable dialogue that reveals character, structuring the play into acts and scenes, including stage directions to guide performance, and developing dramatic tension through conflict.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD LITERATURE SYLLABUS)
  // =========================================================================

  // --- ADVANCED NOVEL ANALYSIS (5 Materials) ---
  {
    id: G11-LIT-NA-01",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Thematic Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Advanced novel analysis involves exploring the layers of meaning in a literary work. Which of the following is a technique for identifying and analyzing themes in a novel?,
      options: [
        Techniques for thematic analysis include examining the title and its significance, identifying recurring motifs and patterns, analyzing characters' conflicts and growth, and considering the social and historical context to understand the author's commentary.,
        Thematic analysis only requires reading the first chapter.,
        Characters' conflicts are not relevant to themes.",
        "Historical context is not important in thematic analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Techniques for thematic analysis include examining the title and its significance, identifying recurring motifs and patterns, analyzing characters' conflicts and growth, and considering the social and historical context to understand the author's commentary."
    })
  },
  {
    id: "G11-LIT-NA-02",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Novel Analysis",
    subtopic: "Character Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Character development is a key aspect of novel analysis. Which of the following describes a dynamic character in a novel?,
      options: [
        A dynamic character undergoes significant internal change throughout the novel, often as a result of the events and conflicts they experience, leading to personal growth, learning, or a new understanding.,
        A dynamic character remains unchanged throughout the story.,
        "Dynamic characters are always the protagonist.,
        Dynamic characters do not experience conflict."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A dynamic character undergoes significant internal change throughout the novel, often as a result of the events and conflicts they experience, leading to personal growth, learning, or a new understanding.
    })
  },
  {
    id: G11-LIT-NA-03",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Narrative Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Authors use various narrative techniques to tell their stories effectively. Which of the following is a narrative technique used by authors to provide background information about characters and events?,
      options: [
        Exposition is a narrative technique used to provide background information about characters, setting, and past events that are important for understanding the story, often found at the beginning of a novel.,
        Exposition is the same as the climax.,
        Exposition only occurs at the end of a novel.",
        "Exposition is not a narrative technique.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Exposition is a narrative technique used to provide background information about characters, setting, and past events that are important for understanding the story, often found at the beginning of a novel."
    })
  },
  {
    id: "G11-LIT-NA-04",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Novel Analysis",
    subtopic: "Literary Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Literary techniques are used by authors to create specific effects. Which of the following is a technique where the author provides hints about future events in the story?,
      options: [
        Foreshadowing is a literary technique where the author provides subtle hints or clues about events that will happen later in the story, creating suspense and preparing the reader for future developments.,
        Foreshadowing reveals the ending of the story.,
        "Foreshadowing is the same as flashback.,
        Foreshadowing is not a literary technique."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Foreshadowing is a literary technique where the author provides subtle hints or clues about events that will happen later in the story, creating suspense and preparing the reader for future developments.
    })
  },
  {
    id: G11-LIT-NA-05",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Contextual Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contextual analysis examines a novel in light of its historical, social, and cultural context. Which of the following is an aspect of contextual analysis?,
      options: [
        Contextual analysis involves understanding the historical period, social conditions, and cultural values that influenced the author and the novel's creation, as well as how the novel reflects or challenges its context.,
        Contextual analysis only focuses on the novel's plot.,
        Historical context is not relevant to literary analysis.",
        "Cultural values do not influence novels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Contextual analysis involves understanding the historical period, social conditions, and cultural values that influenced the author and the novel's creation, as well as how the novel reflects or challenges its context."
    })
  },

  // --- ADVANCED POETRY (5 Materials) ---
  {
    id: "G11-LIT-PO-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Poetic Form,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Understanding poetic form is essential for analyzing poetry. Which of the following describes a sonnet's rhyme scheme?,
      options: [
        A Shakespearean sonnet has the rhyme scheme ABAB CDCD EFEF GG, with three quatrains followed by a concluding couplet that often provides a resolution or commentary on the poem's theme.,
        A sonnet has a random rhyme scheme.,
        "A sonnet does not have a rhyme scheme.,
        A Shakespearean sonnet has four quatrains."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A Shakespearean sonnet has the rhyme scheme ABAB CDCD EFEF GG, with three quatrains followed by a concluding couplet that often provides a resolution or commentary on the poem's theme.
    })
  },
  {
    id: G11-LIT-PO-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Poetry,
    subtopic: "Poetic Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The structure of a poem contributes to its meaning and effect. Which of the following refers to the grouping of lines in a poem?,
      options: [
        A stanza is a group of lines in a poem, similar to a paragraph in prose. Different stanza forms (couplet, tercet, quatrain, etc.) have different numbers of lines and can affect the poem's rhythm and meaning.,
        A stanza is a single line in a poem.,
        Stanzas are only found in sonnets.",
        "A stanza has no effect on a poem's meaning.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A stanza is a group of lines in a poem, similar to a paragraph in prose. Different stanza forms (couplet, tercet, quatrain, etc.) have different numbers of lines and can affect the poem's rhythm and meaning."
    })
  },
  {
    id: "G11-LIT-PO-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Meter and Rhythm,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Meter and rhythm are crucial elements of poetry. Which of the following describes iambic pentameter?,
      options: [
        Iambic pentameter is a metrical pattern consisting of five iambic feet per line, where each iamb consists of an unstressed syllable followed by a stressed syllable (da-DUM da-DUM da-DUM da-DUM da-DUM), commonly used in Shakespeare's plays and sonnets.,
        Iambic pentameter has four feet per line.,
        "Iambic pentameter is a free verse form.,
        Iambic pentameter has six stressed syllables per line."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Iambic pentameter is a metrical pattern consisting of five iambic feet per line, where each iamb consists of an unstressed syllable followed by a stressed syllable (da-DUM da-DUM da-DUM da-DUM da-DUM), commonly used in Shakespeare's plays and sonnets.
    })
  },
  {
    id: G11-LIT-PO-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Poetry,
    subtopic: "Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Figurative language is essential for creating meaning and effect in poetry. Which of the following is an example of a paradox in poetry?,
      options: [
        A paradox is a statement that appears contradictory but contains a deeper truth, such as 'The more you give, the more you have' or 'In peace, there is war' where opposing ideas are used to reveal complex meanings.,
        A paradox is the same as an oxymoron.,
        A paradox has no meaning.",
        "A paradox is a literal statement.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A paradox is a statement that appears contradictory but contains a deeper truth, such as 'The more you give, the more you have' or 'In peace, there is war' where opposing ideas are used to reveal complex meanings."
    })
  },
  {
    id: "G11-LIT-PO-05",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Stylistic Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Stylistic analysis examines how a poet uses language to achieve particular effects. Which of the following is a consideration in the stylistic analysis of a poem?,
      options: [
        Stylistic analysis considers the poet's choice of words (diction), sentence structure (syntax), use of figurative language, sound devices (alliteration, assonance, onomatopoeia), and imagery to understand how meaning and effect are created.,
        Stylistic analysis only looks at the poem's theme.,
        "Diction is not relevant to stylistic analysis.,
        Sound devices are not important in poetry."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Stylistic analysis considers the poet's choice of words (diction), sentence structure (syntax), use of figurative language, sound devices (alliteration, assonance, onomatopoeia), and imagery to understand how meaning and effect are created.
    })
  },

  // --- ADVANCED DRAMA (5 Materials) ---
  {
    id: G11-LIT-DR-01",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Dialogue",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Dialogue in drama serves multiple functions. Which of the following is a function of dialogue that reveals a character's inner thoughts and feelings to the audience without other characters hearing?,
      options: [
        A soliloquy is a speech delivered by a character alone on stage, revealing their inner thoughts and feelings to the audience, providing insight into their motivations and conflicts.,
        Dialogue in drama is always between two characters.,
        Soliloquies are not a form of dialogue.",
        "Soliloquies are addressed to other characters.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A soliloquy is a speech delivered by a character alone on stage, revealing their inner thoughts and feelings to the audience, providing insight into their motivations and conflicts."
    })
  },
  {
    id: "G11-LIT-DR-02",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Drama",
    subtopic: "Characterization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Characterization in drama relies heavily on dialogue and action. Which of the following is a technique used to reveal character in a play?,
      options: [
        Characterization in drama is revealed through what characters say (dialogue), what they do (actions), how others respond to them, their appearance, and through stage directions that describe their behavior and emotions.,
        Characterization in drama is only revealed through narration.,
        "Stage directions do not reveal character.,
        Actions are not important in character development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Characterization in drama is revealed through what characters say (dialogue), what they do (actions), how others respond to them, their appearance, and through stage directions that describe their behavior and emotions.
    })
  },
  {
    id: G11-LIT-DR-03",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Staging",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Staging involves the physical elements of a theatrical performance. Which of the following is a component of staging in drama?,
      options: [
        Components of staging include set design, lighting, costumes, props, sound effects, and the positioning and movement of actors on stage (blocking), all of which contribute to the visual and auditory experience of the play.,
        Staging only involves the actors.,
        Costumes are not part of staging.",
        "Sound effects are not a component of staging.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Components of staging include set design, lighting, costumes, props, sound effects, and the positioning and movement of actors on stage (blocking), all of which contribute to the visual and auditory experience of the play."
    })
  },
  {
    id: "G11-LIT-DR-04",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Drama",
    subtopic: "Dramatic Conventions,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Dramatic conventions are techniques used to structure and enhance a theatrical performance. Which of the following is a dramatic convention where a character speaks their thoughts aloud, unheard by other characters?,
      options: [
        An aside is a dramatic convention where a character speaks directly to the audience, expressing their thoughts or feelings, while the other characters on stage are supposed not to hear them.,
        An aside is the same as a soliloquy.",
        "An aside is a dialogue between characters.,
        An aside is a stage direction."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An aside is a dramatic convention where a character speaks directly to the audience, expressing their thoughts or feelings, while the other characters on stage are supposed not to hear them.
    })
  },
  {
    id: G11-LIT-DR-05",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Dramatic Conflict",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Conflict is central to dramatic literature. Which of the following describes an internal conflict in a play?,
      options: [
        Internal conflict occurs within a character, involving a struggle between opposing desires, beliefs, or emotions within the character's mind, often driving their decisions and actions throughout the play.,
        Internal conflict involves a struggle with another character.,
        Internal conflict is a conflict with society.",
        "Internal conflict is a conflict with nature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Internal conflict occurs within a character, involving a struggle between opposing desires, beliefs, or emotions within the character's mind, often driving their decisions and actions throughout the play."
    })
  },

  // --- COMPARATIVE LITERATURE (4 Materials) ---
  {
    id: "G11-LIT-CL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Comparative Literature",
    subtopic: "Comparing Texts,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Comparative literature involves analyzing similarities and differences between literary works. Which of the following is a basis for comparing two literary texts?,
      options: [
        Literary texts can be compared based on their themes, characters, settings, plot structures, narrative techniques, literary devices, and the cultural or historical contexts in which they were written.,
        Texts can only be compared if they are from the same genre.,
        "Themes are not a basis for comparison.,
        Settings cannot be used for comparison."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literary texts can be compared based on their themes, characters, settings, plot structures, narrative techniques, literary devices, and the cultural or historical contexts in which they were written.
    })
  },
  {
    id: G11-LIT-CL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Comparative Literature,
    subtopic: "Thematic Comparison",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Thematic comparison examines how different authors treat similar subjects. Which of the following is a thematic approach to comparing two novels about colonialism?,
      options: [
        A thematic comparison of two novels about colonialism might explore how each author portrays the impact of colonial rule on indigenous populations, the representation of resistance, and the portrayal of the colonial authorities.,
        Thematic comparison only examines plot differences.,
        Colonial novels cannot be compared thematically.",
        "Thematic comparison ignores character analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A thematic comparison of two novels about colonialism might explore how each author portrays the impact of colonial rule on indigenous populations, the representation of resistance, and the portrayal of the colonial authorities."
    })
  },
  {
    id: "G11-LIT-CL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Comparative Literature",
    subtopic: "Structural Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Structural comparison examines how literary works are organized. Which of the following is a structural element that can be compared between two poems?,
      options: [
        Structural elements that can be compared between poems include rhyme scheme, meter, stanza structure, line length, and overall form (sonnet, free verse, ballad, etc.), which affect the meaning and effect of the poems.,
        Structure is not relevant to poetry comparison.,
        "Rhyme scheme cannot be compared.,
        All poems have the same structure."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Structural elements that can be compared between poems include rhyme scheme, meter, stanza structure, line length, and overall form (sonnet, free verse, ballad, etc.), which affect the meaning and effect of the poems.
    })
  },
  {
    id: G11-LIT-CL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Comparative Literature,
    subtopic: "Contextual Comparison",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contextual comparison examines how the social and historical contexts of literary works affect their meaning. Which of the following is a benefit of contextual comparison?,
      options: [
        Contextual comparison helps readers understand how different historical, social, and cultural contexts influence the themes, characters, and messages of literary works, revealing how literature reflects and responds to specific times and places.,
        Contextual comparison ignores historical influences.,
        Social context does not affect literary meaning.",
        "Contextual comparison is only useful for novels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Contextual comparison helps readers understand how different historical, social, and cultural contexts influence the themes, characters, and messages of literary works, revealing how literature reflects and responds to specific times and places."
    })
  },

  // --- LITERARY CRITICISM (4 Materials) ---
  {
    id: "G11-LIT-LC-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Literary Criticism",
    subtopic: "Formalist Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Formalist criticism focuses on the form and structure of a literary work. Which of the following is a primary focus of formalist criticism?,
      options: [
        Formalist criticism focuses on the literary work itself, examining its language, structure, style, and literary devices, without considering external factors such as the author's biography or historical context.,
        Formalist criticism focuses on the author's life.,
        "Formalist criticism examines historical context.,
        Formalist criticism ignores literary devices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Formalist criticism focuses on the literary work itself, examining its language, structure, style, and literary devices, without considering external factors such as the author's biography or historical context.
    })
  },
  {
    id: G11-LIT-LC-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Literary Criticism,
    subtopic: "Historical Criticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Historical criticism examines a literary work in its historical context. Which of the following does historical criticism consider when analyzing a text?,
      options: [
        Historical criticism considers the historical period in which a work was written, including its social, political, and cultural conditions, and how these factors influenced the author and the meaning of the text.,
        Historical criticism ignores historical context.,
        Historical criticism only focuses on the text itself.",
        "Historical criticism is the same as formalist criticism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Historical criticism considers the historical period in which a work was written, including its social, political, and cultural conditions, and how these factors influenced the author and the meaning of the text."
    })
  },
  {
    id: "G11-LIT-LC-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Literary Criticism",
    subtopic: "Post-Colonial Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Post-colonial criticism examines literature produced in formerly colonized nations. Which of the following is a concern of post-colonial criticism?,
      options: [
        Post-colonial criticism examines how literature addresses the effects of colonialism, the struggle for independence and identity, the representation of colonized peoples, and the negotiation between indigenous and colonial cultures.,
        Post-colonial criticism focuses on European literature.,
        "Post-colonial criticism ignores colonial history.,
        Post-colonial criticism is not concerned with identity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Post-colonial criticism examines how literature addresses the effects of colonialism, the struggle for independence and identity, the representation of colonized peoples, and the negotiation between indigenous and colonial cultures.
    })
  },
  {
    id: G11-LIT-LC-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Literary Criticism,
    subtopic: "Reader-Response Criticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Reader-response criticism focuses on the reader's experience and interpretation of a text. Which of the following is a key idea in reader-response criticism?,
      options: [
        Reader-response criticism emphasizes that meaning is created through the interaction between the reader and the text, with different readers interpreting the same text differently based on their experiences, beliefs, and cultural backgrounds.,
        Reader-response criticism argues that meaning is fixed in the text.,
        Reader-response criticism ignores the reader's experience.",
        "Reader-response criticism is the same as author-centered criticism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reader-response criticism emphasizes that meaning is created through the interaction between the reader and the text, with different readers interpreting the same text differently based on their experiences, beliefs, and cultural backgrounds."
    })
  },

  // --- CREATIVE WRITING (4 Materials) ---
  {
    id: "G11-LIT-CW-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Advanced Narrative Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Advanced narrative techniques enhance the depth and impact of creative writing. Which of the following is a technique where a writer begins a story in the middle of the action?,
      options: [
        In medias res is a narrative technique where a story begins in the middle of the action, creating immediacy and engaging the reader immediately, with background information revealed later through flashbacks or exposition.,
        In medias res means beginning at the very beginning.,
        "In medias res is the same as flashback.,
        In medias res is not a narrative technique."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In medias res is a narrative technique where a story begins in the middle of the action, creating immediacy and engaging the reader immediately, with background information revealed later through flashbacks or exposition.
    })
  },
  {
    id: G11-LIT-CW-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Voice and Style",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Voice and style are essential elements of creative writing that distinguish one writer from another. Which of the following contributes to a writer's unique voice?,
      options: [
        A writer's voice is created through their choice of words (diction), sentence structure (syntax), tone, use of figurative language, and the overall perspective and personality that comes through in their writing.,
        Voice is only about word choice.,
        Style is not important in creative writing.",
        "Voice cannot be developed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A writer's voice is created through their choice of words (diction), sentence structure (syntax), tone, use of figurative language, and the overall perspective and personality that comes through in their writing."
    })
  },
  {
    id: "G11-LIT-CW-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Developing Characters,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Developing believable characters is crucial for effective creative writing. Which of the following is a strategy for creating complex characters?,
      options: [
        Strategies for creating complex characters include giving characters conflicting desires or goals, developing detailed backstories, showing rather than telling their traits, allowing them to change and grow, and including flaws and contradictions.,
        Characters should be completely good or completely evil.,
        "Backstories are not important for character development.,
        Characters should not change throughout a story."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Strategies for creating complex characters include giving characters conflicting desires or goals, developing detailed backstories, showing rather than telling their traits, allowing them to change and grow, and including flaws and contradictions.
    })
  },
  {
    id: G11-LIT-CW-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Writing Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Writing poetry requires attention to sound, imagery, and form. Which of the following is a consideration when writing a poem in a specific form (e.g., sonnet, haiku)?,
      options: [
        When writing a poem in a specific form, a writer must consider the prescribed rhyme scheme, meter, line count, stanza structure, and thematic conventions, while still expressing their unique voice and ideas.,
        Form does not affect the writing of a poem.,
        All poems have the same form.",
        "Rhyme scheme is not important in formal poetry.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: When writing a poem in a specific form, a writer must consider the prescribed rhyme scheme, meter, line count, stanza structure, and thematic conventions, while still expressing their unique voice and ideas."
    })
  },

  // --- AFRICAN LITERATURE (4 Materials) ---
  {
    id: "G11-LIT-AL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "African Literature",
    subtopic: "African Novels,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African novels have made significant contributions to world literature. Which of the following is a major theme in Chinua Achebe's novel 'Things Fall Apart'?,
      options: [
        Major themes in 'Things Fall Apart' include the clash between traditional Igbo culture and colonial European culture, the effects of colonialism on African societies, masculinity and gender roles, fate and free will, and the struggle for identity.,
        The novel only addresses traditional rituals.,
        "Colonialism is not a theme in the novel.,
        Gender roles are not explored in the novel."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Major themes in 'Things Fall Apart' include the clash between traditional Igbo culture and colonial European culture, the effects of colonialism on African societies, masculinity and gender roles, fate and free will, and the struggle for identity.
    })
  },
  {
    id: G11-LIT-AL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "African Literature,
    subtopic: "African Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " African poetry addresses various themes related to the continent's history and culture. Which of the following is a theme commonly addressed in African poetry?,
      options: [
        Common themes in African poetry include the celebration of African heritage and culture, the critique of colonialism and post-colonial governance, the struggle for freedom and independence, and the exploration of identity and belonging.,
        African poetry only addresses nature.,
        Colonialism is not a theme in African poetry.",
        "African poetry does not address identity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African poetry include the celebration of African heritage and culture, the critique of colonialism and post-colonial governance, the struggle for freedom and independence, and the exploration of identity and belonging."
    })
  },
  {
    id: "G11-LIT-AL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "African Literature",
    subtopic: "African Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African drama reflects the social and political realities of the continent. Which of the following is a prominent African playwright known for addressing themes of political corruption and social justice?,
      options: [
        Ngũgĩ wa Thiong'o is a prominent African playwright whose works, such as 'The Trial of Dedan Kimathi' and 'I Will Marry When I Want,' address themes of political oppression, corruption, and the struggle for social justice in Kenya.,
        Ngũgĩ wa Thiong'o only writes poetry.,
        "Ngũgĩ wa Thiong'o addresses only historical themes.,
        Ngũgĩ wa Thiong'o does not address social justice."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ngũgĩ wa Thiong'o is a prominent African playwright whose works, such as 'The Trial of Dedan Kimathi' and 'I Will Marry When I Want,' address themes of political oppression, corruption, and the struggle for social justice in Kenya.
    })
  },
  {
    id: G11-LIT-AL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "African Literature,
    subtopic: "Oral Tradition in African Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Oral tradition influences written African literature. Which of the following is an example of oral tradition elements in African written literature?,
      options: [
        Written African literature often incorporates oral tradition elements such as proverbs, folktales, songs, riddles, and oral narrative structures, as seen in the works of Chinua Achebe and Ngũgĩ wa Thiong'o.,
        Written African literature does not draw from oral tradition.,
        Proverbs are not used in written African literature.",
        "Oral tradition has no influence on written literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Written African literature often incorporates oral tradition elements such as proverbs, folktales, songs, riddles, and oral narrative structures, as seen in the works of Chinua Achebe and Ngũgĩ wa Thiong'o."
    })
  },

  // --- WORLD LITERATURE (4 Materials) ---
  {
    id: "G11-LIT-WL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "World Literature",
    subtopic: "European Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "European literature has had a significant influence on global literary traditions. Which of the following is a major work of English literature known for its exploration of themes such as ambition and guilt?,
      options: [
        William Shakespeare's 'Macbeth' is a major work of English literature that explores themes of ambition, power, guilt, and the corrupting influence of unchecked ambition, through the tragic downfall of its protagonist.,
        Macbeth is a comedy.,
        "Macbeth addresses only political themes.,
        Macbeth has no tragic elements."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "William Shakespeare's 'Macbeth' is a major work of English literature that explores themes of ambition, power, guilt, and the corrupting influence of unchecked ambition, through the tragic downfall of its protagonist.
    })
  },
  {
    id: G11-LIT-WL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "World Literature,
    subtopic: "American Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " American literature reflects the country's diverse history and culture. Which of the following is a significant American literary work that addresses themes of racial injustice and the struggle for equality?,
      options: [
        Harper Lee's 'To Kill a Mockingbird' is a significant American novel that addresses themes of racial injustice, moral growth, empathy, and the loss of innocence, through the eyes of a young girl in the American South.,
        The novel only addresses childhood experiences.,
        Racial injustice is not a theme in the novel.",
        "The novel does not address moral growth.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Harper Lee's 'To Kill a Mockingbird' is a significant American novel that addresses themes of racial injustice, moral growth, empathy, and the loss of innocence, through the eyes of a young girl in the American South."
    })
  },
  {
    id: "G11-LIT-WL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "World Literature",
    subtopic: "Asian Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Asian literature offers diverse perspectives and traditions. Which of the following is a notable work from Asian literature that explores themes of tradition and modernity?,
      options: [
        Chinua Achebe's 'Things Fall Apart' is not an Asian novel, but a classic of African literature. For Asian literature, works such as 'The Tale of Genji' by Murasaki Shikibu or 'The God of Small Things' by Arundhati Roy explore tradition and modernity.,
        Asian literature does not address tradition.,
        "The Tale of Genji is an African novel.,
        Asian literature does not address modernity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chinua Achebe's 'Things Fall Apart' is not an Asian novel, but a classic of African literature. For Asian literature, works such as 'The Tale of Genji' by Murasaki Shikibu or 'The God of Small Things' by Arundhati Roy explore tradition and modernity.
    })
  },
  {
    id: G11-LIT-WL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "World Literature,
    subtopic: "Comparative Global Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " World literature often explores universal themes that resonate across cultures. Which of the following is a universal theme found in literature from around the world?,
      options: [
        Universal themes in world literature include the struggle between good and evil, the search for identity, the experience of love and loss, the challenges of growing up, and the resilience of the human spirit in the face of adversity.,
        Literature from different cultures does not share themes.,
        Love and loss are not universal themes.",
        "The human spirit is not a theme in literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Universal themes in world literature include the struggle between good and evil, the search for identity, the experience of love and loss, the challenges of growing up, and the resilience of the human spirit in the face of adversity."
    })
  }`nexport const literatureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD LITERATURE SYLLABUS)
  // =========================================================================
  {
    id: "G10-LIT-IL-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Introduction to Literature",
    subtopic: "Definition of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "Literature is a body of written, spoken, or performed works that express human experiences, emotions, and ideas. Which of the following best defines literature as an art form?,
      options: [
        "Literature is the artistic expression of human experiences through language, encompassing various genres such as prose, poetry, and drama, and reflecting the cultural, social, and historical contexts in which it is created.,
        Literature is any written text without artistic merit.",
        "Literature is the study of grammar and language rules.,
        Literature is only poetry and does not include prose."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literature is the artistic expression of human experiences through language, encompassing various genres such as prose, poetry, and drama, and reflecting the cultural, social, and historical contexts in which it is created.
    })
  },
  {
    id: G10-LIT-IL-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Introduction to Literature,
    subtopic: "Genres of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Literature is broadly divided into genres, each with distinct characteristics. Which of the following is NOT a major genre of literature?,
      options: [
        Prose, poetry, and drama are the three major genres of literature, with prose including novels and short stories, poetry using rhythmic and figurative language, and drama written for performance.,
        Prose is a major genre of literature.,
        Poetry is a major genre of literature.",
        "Drama is a major genre of literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Prose, poetry, and drama are the three major genres of literature, with prose including novels and short stories, poetry using rhythmic and figurative language, and drama written for performance."
    })
  },
  {
    id: "G10-LIT-IL-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Introduction to Literature",
    subtopic: "Literary Appreciation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Literary appreciation involves understanding and enjoying literary works. Which of the following is an important aspect of literary appreciation?,
      options: [
        Literary appreciation involves analyzing the themes, characters, plot, language, and style of a literary work, as well as understanding its cultural and historical context and the author's purpose.,
        Literary appreciation only involves reading the text once.,
        "Literary appreciation does not require analysis of themes.,
        Literary appreciation is only about memorizing facts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literary appreciation involves analyzing the themes, characters, plot, language, and style of a literary work, as well as understanding its cultural and historical context and the author's purpose.
    })
  },
  {
    id: G10-LIT-IL-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Introduction to Literature,
    subtopic: "Purpose of Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Literature serves various purposes in society. Which of the following is a purpose of literature?,
      options: [
        Literature serves to entertain, educate, inform, challenge societal norms, preserve culture, and enable readers to explore human experiences, emotions, and perspectives from different viewpoints.,
        Literature only serves to entertain.,
        Literature has no educational value.",
        "Literature does not preserve culture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Literature serves to entertain, educate, inform, challenge societal norms, preserve culture, and enable readers to explore human experiences, emotions, and perspectives from different viewpoints."
    })
  },
  {
    id: "G10-LIT-NV-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Elements of the Novel,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "A novel is a long work of prose fiction that tells a story. Which of the following is a key element of a novel?,
      options: [
        The key elements of a novel include plot (the sequence of events), characters (the people in the story), setting (the time and place), theme (the central idea), point of view (the perspective from which the story is told), and style (the author's use of language).,
        A novel only has characters and a plot.,
        "Setting is not an element of a novel.,
        Point of view is not an element of a novel."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The key elements of a novel include plot (the sequence of events), characters (the people in the story), setting (the time and place), theme (the central idea), point of view (the perspective from which the story is told), and style (the author's use of language).
    })
  },
  {
    id: G10-LIT-NV-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "The Novel,
    subtopic: "Plot Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The plot of a novel follows a specific structure that creates narrative tension and resolution. Which of the following correctly describes the parts of a plot structure in a novel?,
      options: [
        A plot typically follows the structure: exposition (introduction), rising action (building conflict), climax (the turning point), falling action (resolving conflict), and resolution (the conclusion).,
        A plot structure has only two parts: beginning and end.,
        The climax is not part of a plot structure.",
        "Falling action occurs before the rising action.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A plot typically follows the structure: exposition (introduction), rising action (building conflict), climax (the turning point), falling action (resolving conflict), and resolution (the conclusion)."
    })
  },
  {
    id: "G10-LIT-NV-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Characterization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Characterization is the process by which an author reveals the personality of a character. Which of the following is a method of characterization in a novel?,
      options: [
        Methods of characterization include direct characterization (the author directly describes the character) and indirect characterization (revealing the character through their actions, speech, thoughts, appearance, and how others react to them).,
        Characterization is only done through direct description.,
        "Indirect characterization does not occur in novels.,
        Characters' actions do not reveal their personality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Methods of characterization include direct characterization (the author directly describes the character) and indirect characterization (revealing the character through their actions, speech, thoughts, appearance, and how others react to them).
    })
  },
  {
    id: G10-LIT-NV-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "The Novel,
    subtopic: "Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Theme is the central idea or underlying message of a novel. Which of the following is an example of a common theme in African novels?,
      options: [
        Common themes in African novels include colonialism and its effects, identity and belonging, tradition versus modernity, corruption, power and leadership, social injustice, and the struggle for freedom and self-determination.,
        African novels only address traditional African culture.,
        Colonialism is not a theme in African novels.",
        "African novels do not address contemporary issues.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African novels include colonialism and its effects, identity and belonging, tradition versus modernity, corruption, power and leadership, social injustice, and the struggle for freedom and self-determination."
    })
  },
  {
    id: "G10-LIT-NV-05",
    grade: "Grade 10",
    subject: "Literature",
    topic: "The Novel",
    subtopic: "Point of View,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Point of view is the perspective from which a story is told. Which of the following describes a first-person point of view in a novel?,
      options: [
        A first-person point of view uses the pronoun 'I' and the narrator is a character in the story, telling the events from their personal perspective and sharing their thoughts and feelings.,
        First-person point of view is told from the perspective of an omniscient narrator.,
        "First-person point of view uses the pronoun 'he' or 'she'.,
        First-person point of view only focuses on external events."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A first-person point of view uses the pronoun 'I' and the narrator is a character in the story, telling the events from their personal perspective and sharing their thoughts and feelings.
    })
  },
  {
    id: G10-LIT-SS-01",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Elements of Short Stories",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A short story is a brief work of fiction that focuses on a single incident or character. Which of the following distinguishes a short story from a novel?,
      options: [
        A short story is shorter in length, focuses on a single incident or character, has a limited number of characters, and typically develops a single theme or idea, whereas a novel is longer and more complex.,
        Short stories are always more complex than novels.,
        Short stories have multiple themes.",
        "Short stories are not works of fiction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A short story is shorter in length, focuses on a single incident or character, has a limited number of characters, and typically develops a single theme or idea, whereas a novel is longer and more complex."
    })
  },
  {
    id: "G10-LIT-SS-02",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Short Stories",
    subtopic: "Plot in Short Stories,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The plot of a short story is usually simple and focused on a single conflict. Which of the following is a characteristic of plot in short stories?,
      options: [
        Short stories typically have a simple plot structure that focuses on a single incident or conflict, with a clear beginning, middle, and end, and often ends with a twist or a moment of realization.,
        Short stories have complex, multi-layered plots.,
        "Short stories do not have a resolution.,
        Short stories have many subplots."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Short stories typically have a simple plot structure that focuses on a single incident or conflict, with a clear beginning, middle, and end, and often ends with a twist or a moment of realization.
    })
  },
  {
    id: G10-LIT-SS-03",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Characterization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Characterization in short stories is often economical and focused. Which of the following is a technique used to develop characters in a short story?,
      options: [
        Authors develop characters in short stories through selective detail, dialogue, actions, and thoughts, often revealing key traits quickly to create vivid and memorable characters in limited space.,
        Characterization in short stories requires extensive description.,
        Short stories do not focus on character development.",
        "Dialogue is not used for characterization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Authors develop characters in short stories through selective detail, dialogue, actions, and thoughts, often revealing key traits quickly to create vivid and memorable characters in limited space."
    })
  },
  {
    id: "G10-LIT-SS-04",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Short Stories",
    subtopic: "Themes,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Short stories often explore universal themes in a concise form. Which of the following is a common theme in short stories?,
      options: [
        Common themes in short stories include love, loss, identity, morality, conflict, cultural clashes, betrayal, forgiveness, and the human condition, often presented with clarity and impact.,
        Short stories only explore political themes.,
        "Short stories do not have themes.,
        Short stories only explore supernatural themes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Common themes in short stories include love, loss, identity, morality, conflict, cultural clashes, betrayal, forgiveness, and the human condition, often presented with clarity and impact.
    })
  },
  {
    id: G10-LIT-SS-05",
    grade: "Grade 10,
    subject: Literature",
    topic: "Short Stories,
    subtopic: "Setting",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Setting includes the time, place, and social environment in which a story takes place. Which of the following is a function of setting in a short story?,
      options: [
        Setting functions to create atmosphere and mood, influence characters' actions and beliefs, symbolize themes, and provide historical and cultural context, helping readers understand the story more deeply.,
        Setting has no effect on a story's meaning.,
        Setting only refers to the physical location.",
        "Setting does not influence characters.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Setting functions to create atmosphere and mood, influence characters' actions and beliefs, symbolize themes, and provide historical and cultural context, helping readers understand the story more deeply."
    })
  },
  {
    id: "G10-LIT-PO-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Elements of Poetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Poetry is a form of literature that uses aesthetic and rhythmic qualities of language. Which of the following is a key element of poetry?,
      options: [
        Key elements of poetry include rhyme, rhythm, meter, imagery, figurative language, symbolism, tone, and structure, all of which work together to create meaning and evoke emotion.,
        Poetry does not have structure.,
        "Rhyme is not an element of poetry.,
        Poetry does not use figurative language."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Key elements of poetry include rhyme, rhythm, meter, imagery, figurative language, symbolism, tone, and structure, all of which work together to create meaning and evoke emotion.
    })
  },
  {
    id: G10-LIT-PO-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Poetry,
    subtopic: "Forms of Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Poetry exists in various forms with distinct structures. Which of the following is a form of poetry that consists of fourteen lines and follows a specific rhyme scheme?,
      options: [
        A sonnet is a poem of fourteen lines with a specific rhyme scheme, usually in iambic pentameter, with the Shakespearean sonnet having three quatrains and a couplet (ABAB CDCD EFEF GG).,
        An epic is a fourteen-line poem.,
        A haiku is a fourteen-line poem.",
        "A villanelle is a fourteen-line poem.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A sonnet is a poem of fourteen lines with a specific rhyme scheme, usually in iambic pentameter, with the Shakespearean sonnet having three quatrains and a couplet (ABAB CDCD EFEF GG)."
    })
  },
  {
    id: "G10-LIT-PO-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Imagery,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Imagery is a vital element of poetry that appeals to the senses. Which of the following is an example of visual imagery in poetry?,
      options: [
        Visual imagery appeals to the sense of sight, creating pictures in the reader's mind, such as 'The golden sun sank slowly behind the purple hills,' evoking a vivid visual image.,
        Visual imagery appeals to the sense of hearing.,
        "Visual imagery is not used in poetry.,
        Visual imagery describes tastes and smells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Visual imagery appeals to the sense of sight, creating pictures in the reader's mind, such as 'The golden sun sank slowly behind the purple hills,' evoking a vivid visual image.
    })
  },
  {
    id: G10-LIT-PO-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Poetry,
    subtopic: "Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Figurative language is used extensively in poetry to create meaning and effect. Which of the following is a metaphor?,
      options: [
        A metaphor is a figure of speech that compares two unlike things by stating that one thing is the other, without using 'like' or 'as,' such as 'The world is a stage'.,
        A metaphor uses 'like' or 'as' to compare things.,
        A metaphor is a comparison of similar things.",
        "A metaphor is a personification.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A metaphor is a figure of speech that compares two unlike things by stating that one thing is the other, without using 'like' or 'as,' such as 'The world is a stage'."
    })
  },
  {
    id: "G10-LIT-PO-05",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Poetry",
    subtopic: "Tone and Mood,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Tone and mood are important aspects of poetry that affect the reader's experience. Which of the following describes the difference between tone and mood in a poem?,
      options: [
        Tone is the poet's attitude toward the subject or audience (revealed through word choice and style), while mood is the emotional atmosphere that the poem creates for the reader.,
        Tone and mood are the same thing.,
        "Tone is created by the reader's emotions.,
        Mood is the author's attitude."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tone is the poet's attitude toward the subject or audience (revealed through word choice and style), while mood is the emotional atmosphere that the poem creates for the reader.
    })
  },
  {
    id: G10-LIT-DR-01",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Elements of Drama",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Drama is a genre of literature intended for performance. Which of the following is a key element of drama?,
      options: [
        Key elements of drama include plot, characters, dialogue, setting, stage directions, conflict, and theme, all of which contribute to the performance and meaning of the play.,
        Drama does not require dialogue.,
        Stage directions are not part of drama.",
        "Conflict is not an element of drama.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Key elements of drama include plot, characters, dialogue, setting, stage directions, conflict, and theme, all of which contribute to the performance and meaning of the play."
    })
  },
  {
    id: "G10-LIT-DR-02",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Drama",
    subtopic: "Types of Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Drama can be classified into different types based on its content and tone. Which of the following is a type of drama that addresses serious and often tragic themes, typically involving a noble protagonist who experiences a downfall?,
      options: [
        A tragedy is a type of drama that deals with serious themes and ends in disaster or downfall for the protagonist, often due to a tragic flaw or circumstances beyond their control.,
        A comedy is a tragedy.",
        "A tragedy has a happy ending.,
        A tragedy only features comic elements."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A tragedy is a type of drama that deals with serious themes and ends in disaster or downfall for the protagonist, often due to a tragic flaw or circumstances beyond their control.
    })
  },
  {
    id: G10-LIT-DR-03",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Dialogue",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Dialogue is a fundamental element of drama that reveals character and advances the plot. Which of the following is a function of dialogue in a play?,
      options: [
        Dialogue functions to reveal character traits and relationships, advance the plot, create conflict and tension, provide exposition and background information, and create dramatic effect.,
        Dialogue is only used for entertainment.,
        Dialogue does not reveal character.",
        "Dialogue does not advance the plot.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dialogue functions to reveal character traits and relationships, advance the plot, create conflict and tension, provide exposition and background information, and create dramatic effect."
    })
  },
  {
    id: "G10-LIT-DR-04",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Drama",
    subtopic: "Stage Directions,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Stage directions are instructions in a play that guide the performance. Which of the following is provided by stage directions in a play?,
      options: [
        Stage directions provide information about the setting, characters' movements, gestures, facial expressions, tone of voice, and other aspects of the performance that are not conveyed through dialogue.,
        Stage directions are only for the audience.,
        "Stage directions are the same as dialogue.,
        Stage directions are not important in drama."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Stage directions provide information about the setting, characters' movements, gestures, facial expressions, tone of voice, and other aspects of the performance that are not conveyed through dialogue.
    })
  },
  {
    id: G10-LIT-DR-05",
    grade: "Grade 10,
    subject: Literature",
    topic: "Drama,
    subtopic: "Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Drama explores various themes relevant to human experience. Which of the following is a common theme in African drama?,
      options: [
        Common themes in African drama include the clash between tradition and modernity, the impact of colonialism and post-colonialism, corruption and the abuse of power, identity and belonging, social justice, and the struggle for independence and freedom.,
        African drama only explores historical themes.,
        Corruption is not a theme in African drama.",
        "African drama does not address social justice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African drama include the clash between tradition and modernity, the impact of colonialism and post-colonialism, corruption and the abuse of power, identity and belonging, social justice, and the struggle for independence and freedom."
    })
  },
  {
    id: "G10-LIT-OL-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Oral Literature",
    subtopic: "Genres of Oral Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Oral literature refers to stories, poems, and performances that are passed down through word of mouth. Which of the following is a genre of oral literature?,
      options: [
        "Genres of oral literature include folktales, myths, legends, proverbs, riddles, oral poetry, songs, and oral narratives, which are transmitted through speech and performance across generations.,
        Oral literature only includes written texts.",
        "Proverbs are not part of oral literature.,
        Oral literature does not include songs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Genres of oral literature include folktales, myths, legends, proverbs, riddles, oral poetry, songs, and oral narratives, which are transmitted through speech and performance across generations.
    })
  },
  {
    id: G10-LIT-OL-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Oral Literature,
    subtopic: "Features of Oral Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Oral literature has distinct features that reflect its oral and performative nature. Which of the following is a feature of oral literature?,
      options: [
        Features of oral literature include the use of repetition, parallelism, formulaic language, call-and-response patterns, performance and audience participation, and variation in transmission from one teller to another.,
        Oral literature is always fixed and unchanging.,
        Repetition is not a feature of oral literature.",
        "Performance is not part of oral literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Features of oral literature include the use of repetition, parallelism, formulaic language, call-and-response patterns, performance and audience participation, and variation in transmission from one teller to another."
    })
  },
  {
    id: "G10-LIT-OL-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Oral Literature",
    subtopic: "Function of Oral Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Oral literature serves important functions in African communities. Which of the following is a function of oral literature?,
      options: [
        Oral literature functions to educate and pass on knowledge, entertain, preserve culture and traditions, convey moral values, provide social commentary, and foster community cohesion and identity.,
        Oral literature only serves to entertain.,
        "Oral literature does not pass on knowledge.,
        Oral literature does not preserve culture."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Oral literature functions to educate and pass on knowledge, entertain, preserve culture and traditions, convey moral values, provide social commentary, and foster community cohesion and identity.
    })
  },
  {
    id: G10-LIT-OL-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Oral Literature,
    subtopic: "Performance",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Performance is integral to oral literature. Which of the following is an element of performance in oral literature?,
      options: [
        Performance in oral literature includes aspects such as voice modulation, gestures, facial expressions, movement, audience participation, and the use of music and dance to enhance the delivery and impact of the narrative.,
        Performance is not part of oral literature.,
        Oral literature does not involve audience participation.",
        "Music is not used in oral literature performance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Performance in oral literature includes aspects such as voice modulation, gestures, facial expressions, movement, audience participation, and the use of music and dance to enhance the delivery and impact of the narrative."
    })
  },
  {
    id: "G10-LIT-LD-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Literary Devices",
    subtopic: "Simile and Metaphor,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Similes and metaphors are important figures of speech used in literature. Which of the following is the difference between a simile and a metaphor?,
      options: [
        A simile compares two unlike things using 'like' or 'as' (e.g., 'Her eyes are like stars'), while a metaphor states that one thing is another (e.g., 'Her eyes are stars').,
        A simile and metaphor are the same.,
        "A simile does not use 'like' or 'as'.,
        A metaphor uses 'like' or 'as'."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A simile compares two unlike things using 'like' or 'as' (e.g., 'Her eyes are like stars'), while a metaphor states that one thing is another (e.g., 'Her eyes are stars').
    })
  },
  {
    id: G10-LIT-LD-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Literary Devices,
    subtopic: "Personification",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Personification is a literary device that gives human qualities to non-human things. Which of the following is an example of personification in literature?,
      options: [
        Personification gives human qualities to inanimate objects or abstract concepts, such as 'The wind whispered through the trees' or 'The sun smiled down on the children,' where the wind and sun are described as human-like.,
        Personification describes animals.,
        Personification is the same as simile.",
        "Personification does not involve human qualities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Personification gives human qualities to inanimate objects or abstract concepts, such as 'The wind whispered through the trees' or 'The sun smiled down on the children,' where the wind and sun are described as human-like."
    })
  },
  {
    id: "G10-LIT-LD-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Literary Devices",
    subtopic: "Symbolism,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Symbolism is a literary device where objects, characters, or events represent abstract ideas. Which of the following is an example of symbolism in literature?,
      options: [
        "Symbolism uses objects, colors, or events to represent deeper meanings, such as a dove symbolizing peace, a red rose symbolizing love, or a storm symbolizing conflict or turmoil in a narrative.,
        Symbolism is the same as metaphor.",
        "Symbolism uses literal meanings only.,
        A dove is never used as a symbol."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Symbolism uses objects, colors, or events to represent deeper meanings, such as a dove symbolizing peace, a red rose symbolizing love, or a storm symbolizing conflict or turmoil in a narrative.
    })
  },
  {
    id: G10-LIT-LD-04",
    grade: "Grade 10,
    subject: Literature",
    topic: "Literary Devices,
    subtopic: "Irony",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Irony is a literary device where the intended meaning is opposite to the literal meaning. Which of the following is an example of dramatic irony in literature?,
      options: [
        Dramatic irony occurs when the audience knows something that the characters do not, such as in a tragedy where the audience knows a character is doomed, but the character remains unaware.,
        Dramatic irony is the same as verbal irony.,
        In dramatic irony, the characters know more than the audience.",
        "Dramatic irony does not involve the audience.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dramatic irony occurs when the audience knows something that the characters do not, such as in a tragedy where the audience knows a character is doomed, but the character remains unaware."
    })
  },
  {
    id: "G10-LIT-CW-01",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Writing Narratives,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Creative writing involves expressing ideas and emotions in an imaginative way. Which of the following is an important element of narrative writing?,
      options: [
        Key elements of narrative writing include a clear plot structure, well-developed characters, vivid setting, engaging dialogue, and a central theme or message that gives the story meaning.,
        Narrative writing does not require a plot.,
        "Dialogue is not important in narrative writing.,
        Characters are not essential in narrative writing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Key elements of narrative writing include a clear plot structure, well-developed characters, vivid setting, engaging dialogue, and a central theme or message that gives the story meaning.
    })
  },
  {
    id: G10-LIT-CW-02",
    grade: "Grade 10,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Writing Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Writing poetry requires attention to language and form. Which of the following is an important consideration when writing a poem?,
      options: [
        Important considerations in writing poetry include the use of imagery and figurative language, attention to rhythm and sound (rhyme, alliteration), careful word choice to convey meaning concisely, and structure (line breaks, stanzas).,
        Poetry does not require attention to rhythm.,
        Figurative language is not important in poetry.",
        "Structure is not important in poetry.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Important considerations in writing poetry include the use of imagery and figurative language, attention to rhythm and sound (rhyme, alliteration), careful word choice to convey meaning concisely, and structure (line breaks, stanzas)."
    })
  },
  {
    id: "G10-LIT-CW-03",
    grade: "Grade 10",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Writing Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Writing drama requires consideration of performance elements. Which of the following is an important aspect of writing a play?,
      options: [
        Important aspects of playwriting include creating believable dialogue that reveals character, structuring the play into acts and scenes, including stage directions to guide performance, and developing dramatic tension through conflict.,
        Dialogue is not important in playwriting.,
        "Stage directions are not part of a play.,
        Conflict is not important in drama."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Important aspects of playwriting include creating believable dialogue that reveals character, structuring the play into acts and scenes, including stage directions to guide performance, and developing dramatic tension through conflict.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD LITERATURE SYLLABUS)
  // =========================================================================
  {
    id: G11-LIT-NA-01",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Thematic Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Advanced novel analysis involves exploring the layers of meaning in a literary work. Which of the following is a technique for identifying and analyzing themes in a novel?,
      options: [
        Techniques for thematic analysis include examining the title and its significance, identifying recurring motifs and patterns, analyzing characters' conflicts and growth, and considering the social and historical context to understand the author's commentary.,
        Thematic analysis only requires reading the first chapter.,
        Characters' conflicts are not relevant to themes.",
        "Historical context is not important in thematic analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Techniques for thematic analysis include examining the title and its significance, identifying recurring motifs and patterns, analyzing characters' conflicts and growth, and considering the social and historical context to understand the author's commentary."
    })
  },
  {
    id: "G11-LIT-NA-02",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Novel Analysis",
    subtopic: "Character Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Character development is a key aspect of novel analysis. Which of the following describes a dynamic character in a novel?,
      options: [
        A dynamic character undergoes significant internal change throughout the novel, often as a result of the events and conflicts they experience, leading to personal growth, learning, or a new understanding.,
        A dynamic character remains unchanged throughout the story.,
        "Dynamic characters are always the protagonist.,
        Dynamic characters do not experience conflict."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A dynamic character undergoes significant internal change throughout the novel, often as a result of the events and conflicts they experience, leading to personal growth, learning, or a new understanding.
    })
  },
  {
    id: G11-LIT-NA-03",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Narrative Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Authors use various narrative techniques to tell their stories effectively. Which of the following is a narrative technique used by authors to provide background information about characters and events?,
      options: [
        Exposition is a narrative technique used to provide background information about characters, setting, and past events that are important for understanding the story, often found at the beginning of a novel.,
        Exposition is the same as the climax.,
        Exposition only occurs at the end of a novel.",
        "Exposition is not a narrative technique.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Exposition is a narrative technique used to provide background information about characters, setting, and past events that are important for understanding the story, often found at the beginning of a novel."
    })
  },
  {
    id: "G11-LIT-NA-04",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Novel Analysis",
    subtopic: "Literary Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Literary techniques are used by authors to create specific effects. Which of the following is a technique where the author provides hints about future events in the story?,
      options: [
        Foreshadowing is a literary technique where the author provides subtle hints or clues about events that will happen later in the story, creating suspense and preparing the reader for future developments.,
        Foreshadowing reveals the ending of the story.,
        "Foreshadowing is the same as flashback.,
        Foreshadowing is not a literary technique."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Foreshadowing is a literary technique where the author provides subtle hints or clues about events that will happen later in the story, creating suspense and preparing the reader for future developments.
    })
  },
  {
    id: G11-LIT-NA-05",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Novel Analysis,
    subtopic: "Contextual Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contextual analysis examines a novel in light of its historical, social, and cultural context. Which of the following is an aspect of contextual analysis?,
      options: [
        Contextual analysis involves understanding the historical period, social conditions, and cultural values that influenced the author and the novel's creation, as well as how the novel reflects or challenges its context.,
        Contextual analysis only focuses on the novel's plot.,
        Historical context is not relevant to literary analysis.",
        "Cultural values do not influence novels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Contextual analysis involves understanding the historical period, social conditions, and cultural values that influenced the author and the novel's creation, as well as how the novel reflects or challenges its context."
    })
  },
  {
    id: "G11-LIT-PO-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Poetic Form,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Understanding poetic form is essential for analyzing poetry. Which of the following describes a sonnet's rhyme scheme?,
      options: [
        A Shakespearean sonnet has the rhyme scheme ABAB CDCD EFEF GG, with three quatrains followed by a concluding couplet that often provides a resolution or commentary on the poem's theme.,
        A sonnet has a random rhyme scheme.,
        "A sonnet does not have a rhyme scheme.,
        A Shakespearean sonnet has four quatrains."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A Shakespearean sonnet has the rhyme scheme ABAB CDCD EFEF GG, with three quatrains followed by a concluding couplet that often provides a resolution or commentary on the poem's theme.
    })
  },
  {
    id: G11-LIT-PO-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Poetry,
    subtopic: "Poetic Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The structure of a poem contributes to its meaning and effect. Which of the following refers to the grouping of lines in a poem?,
      options: [
        A stanza is a group of lines in a poem, similar to a paragraph in prose. Different stanza forms (couplet, tercet, quatrain, etc.) have different numbers of lines and can affect the poem's rhythm and meaning.,
        A stanza is a single line in a poem.,
        Stanzas are only found in sonnets.",
        "A stanza has no effect on a poem's meaning.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A stanza is a group of lines in a poem, similar to a paragraph in prose. Different stanza forms (couplet, tercet, quatrain, etc.) have different numbers of lines and can affect the poem's rhythm and meaning."
    })
  },
  {
    id: "G11-LIT-PO-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Meter and Rhythm,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Meter and rhythm are crucial elements of poetry. Which of the following describes iambic pentameter?,
      options: [
        Iambic pentameter is a metrical pattern consisting of five iambic feet per line, where each iamb consists of an unstressed syllable followed by a stressed syllable (da-DUM da-DUM da-DUM da-DUM da-DUM), commonly used in Shakespeare's plays and sonnets.,
        Iambic pentameter has four feet per line.,
        "Iambic pentameter is a free verse form.,
        Iambic pentameter has six stressed syllables per line."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Iambic pentameter is a metrical pattern consisting of five iambic feet per line, where each iamb consists of an unstressed syllable followed by a stressed syllable (da-DUM da-DUM da-DUM da-DUM da-DUM), commonly used in Shakespeare's plays and sonnets.
    })
  },
  {
    id: G11-LIT-PO-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Poetry,
    subtopic: "Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Figurative language is essential for creating meaning and effect in poetry. Which of the following is an example of a paradox in poetry?,
      options: [
        A paradox is a statement that appears contradictory but contains a deeper truth, such as 'The more you give, the more you have' or 'In peace, there is war' where opposing ideas are used to reveal complex meanings.,
        A paradox is the same as an oxymoron.,
        A paradox has no meaning.",
        "A paradox is a literal statement.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A paradox is a statement that appears contradictory but contains a deeper truth, such as 'The more you give, the more you have' or 'In peace, there is war' where opposing ideas are used to reveal complex meanings."
    })
  },
  {
    id: "G11-LIT-PO-05",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Poetry",
    subtopic: "Stylistic Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Stylistic analysis examines how a poet uses language to achieve particular effects. Which of the following is a consideration in the stylistic analysis of a poem?,
      options: [
        Stylistic analysis considers the poet's choice of words (diction), sentence structure (syntax), use of figurative language, sound devices (alliteration, assonance, onomatopoeia), and imagery to understand how meaning and effect are created.,
        Stylistic analysis only looks at the poem's theme.,
        "Diction is not relevant to stylistic analysis.,
        Sound devices are not important in poetry."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Stylistic analysis considers the poet's choice of words (diction), sentence structure (syntax), use of figurative language, sound devices (alliteration, assonance, onomatopoeia), and imagery to understand how meaning and effect are created.
    })
  },
  {
    id: G11-LIT-DR-01",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Dialogue",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Dialogue in drama serves multiple functions. Which of the following is a function of dialogue that reveals a character's inner thoughts and feelings to the audience without other characters hearing?,
      options: [
        A soliloquy is a speech delivered by a character alone on stage, revealing their inner thoughts and feelings to the audience, providing insight into their motivations and conflicts.,
        Dialogue in drama is always between two characters.,
        Soliloquies are not a form of dialogue.",
        "Soliloquies are addressed to other characters.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A soliloquy is a speech delivered by a character alone on stage, revealing their inner thoughts and feelings to the audience, providing insight into their motivations and conflicts."
    })
  },
  {
    id: "G11-LIT-DR-02",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Drama",
    subtopic: "Characterization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Characterization in drama relies heavily on dialogue and action. Which of the following is a technique used to reveal character in a play?,
      options: [
        Characterization in drama is revealed through what characters say (dialogue), what they do (actions), how others respond to them, their appearance, and through stage directions that describe their behavior and emotions.,
        Characterization in drama is only revealed through narration.,
        "Stage directions do not reveal character.,
        Actions are not important in character development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Characterization in drama is revealed through what characters say (dialogue), what they do (actions), how others respond to them, their appearance, and through stage directions that describe their behavior and emotions.
    })
  },
  {
    id: G11-LIT-DR-03",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Staging",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Staging involves the physical elements of a theatrical performance. Which of the following is a component of staging in drama?,
      options: [
        Components of staging include set design, lighting, costumes, props, sound effects, and the positioning and movement of actors on stage (blocking), all of which contribute to the visual and auditory experience of the play.,
        Staging only involves the actors.,
        Costumes are not part of staging.",
        "Sound effects are not a component of staging.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Components of staging include set design, lighting, costumes, props, sound effects, and the positioning and movement of actors on stage (blocking), all of which contribute to the visual and auditory experience of the play."
    })
  },
  {
    id: "G11-LIT-DR-04",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Advanced Drama",
    subtopic: "Dramatic Conventions,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Dramatic conventions are techniques used to structure and enhance a theatrical performance. Which of the following is a dramatic convention where a character speaks their thoughts aloud, unheard by other characters?,
      options: [
        An aside is a dramatic convention where a character speaks directly to the audience, expressing their thoughts or feelings, while the other characters on stage are supposed not to hear them.,
        An aside is the same as a soliloquy.",
        "An aside is a dialogue between characters.,
        An aside is a stage direction."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An aside is a dramatic convention where a character speaks directly to the audience, expressing their thoughts or feelings, while the other characters on stage are supposed not to hear them.
    })
  },
  {
    id: G11-LIT-DR-05",
    grade: "Grade 11,
    subject: Literature",
    topic: "Advanced Drama,
    subtopic: "Dramatic Conflict",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Conflict is central to dramatic literature. Which of the following describes an internal conflict in a play?,
      options: [
        Internal conflict occurs within a character, involving a struggle between opposing desires, beliefs, or emotions within the character's mind, often driving their decisions and actions throughout the play.,
        Internal conflict involves a struggle with another character.,
        Internal conflict is a conflict with society.",
        "Internal conflict is a conflict with nature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Internal conflict occurs within a character, involving a struggle between opposing desires, beliefs, or emotions within the character's mind, often driving their decisions and actions throughout the play."
    })
  },
  {
    id: "G11-LIT-CL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Comparative Literature",
    subtopic: "Comparing Texts,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Comparative literature involves analyzing similarities and differences between literary works. Which of the following is a basis for comparing two literary texts?,
      options: [
        Literary texts can be compared based on their themes, characters, settings, plot structures, narrative techniques, literary devices, and the cultural or historical contexts in which they were written.,
        Texts can only be compared if they are from the same genre.,
        "Themes are not a basis for comparison.,
        Settings cannot be used for comparison."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literary texts can be compared based on their themes, characters, settings, plot structures, narrative techniques, literary devices, and the cultural or historical contexts in which they were written.
    })
  },
  {
    id: G11-LIT-CL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Comparative Literature,
    subtopic: "Thematic Comparison",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Thematic comparison examines how different authors treat similar subjects. Which of the following is a thematic approach to comparing two novels about colonialism?,
      options: [
        A thematic comparison of two novels about colonialism might explore how each author portrays the impact of colonial rule on indigenous populations, the representation of resistance, and the portrayal of the colonial authorities.,
        Thematic comparison only examines plot differences.,
        Colonial novels cannot be compared thematically.",
        "Thematic comparison ignores character analysis.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A thematic comparison of two novels about colonialism might explore how each author portrays the impact of colonial rule on indigenous populations, the representation of resistance, and the portrayal of the colonial authorities."
    })
  },
  {
    id: "G11-LIT-CL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Comparative Literature",
    subtopic: "Structural Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Structural comparison examines how literary works are organized. Which of the following is a structural element that can be compared between two poems?,
      options: [
        Structural elements that can be compared between poems include rhyme scheme, meter, stanza structure, line length, and overall form (sonnet, free verse, ballad, etc.), which affect the meaning and effect of the poems.,
        Structure is not relevant to poetry comparison.,
        "Rhyme scheme cannot be compared.,
        All poems have the same structure."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Structural elements that can be compared between poems include rhyme scheme, meter, stanza structure, line length, and overall form (sonnet, free verse, ballad, etc.), which affect the meaning and effect of the poems.
    })
  },
  {
    id: G11-LIT-CL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Comparative Literature,
    subtopic: "Contextual Comparison",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contextual comparison examines how the social and historical contexts of literary works affect their meaning. Which of the following is a benefit of contextual comparison?,
      options: [
        Contextual comparison helps readers understand how different historical, social, and cultural contexts influence the themes, characters, and messages of literary works, revealing how literature reflects and responds to specific times and places.,
        Contextual comparison ignores historical influences.,
        Social context does not affect literary meaning.",
        "Contextual comparison is only useful for novels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Contextual comparison helps readers understand how different historical, social, and cultural contexts influence the themes, characters, and messages of literary works, revealing how literature reflects and responds to specific times and places."
    })
  },
  {
    id: "G11-LIT-LC-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Literary Criticism",
    subtopic: "Formalist Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Formalist criticism focuses on the form and structure of a literary work. Which of the following is a primary focus of formalist criticism?,
      options: [
        Formalist criticism focuses on the literary work itself, examining its language, structure, style, and literary devices, without considering external factors such as the author's biography or historical context.,
        Formalist criticism focuses on the author's life.,
        "Formalist criticism examines historical context.,
        Formalist criticism ignores literary devices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Formalist criticism focuses on the literary work itself, examining its language, structure, style, and literary devices, without considering external factors such as the author's biography or historical context.
    })
  },
  {
    id: G11-LIT-LC-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Literary Criticism,
    subtopic: "Historical Criticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Historical criticism examines a literary work in its historical context. Which of the following does historical criticism consider when analyzing a text?,
      options: [
        Historical criticism considers the historical period in which a work was written, including its social, political, and cultural conditions, and how these factors influenced the author and the meaning of the text.,
        Historical criticism ignores historical context.,
        Historical criticism only focuses on the text itself.",
        "Historical criticism is the same as formalist criticism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Historical criticism considers the historical period in which a work was written, including its social, political, and cultural conditions, and how these factors influenced the author and the meaning of the text."
    })
  },
  {
    id: "G11-LIT-LC-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Literary Criticism",
    subtopic: "Post-Colonial Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Post-colonial criticism examines literature produced in formerly colonized nations. Which of the following is a concern of post-colonial criticism?,
      options: [
        Post-colonial criticism examines how literature addresses the effects of colonialism, the struggle for independence and identity, the representation of colonized peoples, and the negotiation between indigenous and colonial cultures.,
        Post-colonial criticism focuses on European literature.,
        "Post-colonial criticism ignores colonial history.,
        Post-colonial criticism is not concerned with identity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Post-colonial criticism examines how literature addresses the effects of colonialism, the struggle for independence and identity, the representation of colonized peoples, and the negotiation between indigenous and colonial cultures.
    })
  },
  {
    id: G11-LIT-LC-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Literary Criticism,
    subtopic: "Reader-Response Criticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Reader-response criticism focuses on the reader's experience and interpretation of a text. Which of the following is a key idea in reader-response criticism?,
      options: [
        Reader-response criticism emphasizes that meaning is created through the interaction between the reader and the text, with different readers interpreting the same text differently based on their experiences, beliefs, and cultural backgrounds.,
        Reader-response criticism argues that meaning is fixed in the text.,
        Reader-response criticism ignores the reader's experience.",
        "Reader-response criticism is the same as author-centered criticism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reader-response criticism emphasizes that meaning is created through the interaction between the reader and the text, with different readers interpreting the same text differently based on their experiences, beliefs, and cultural backgrounds."
    })
  },
  {
    id: "G11-LIT-CW-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Advanced Narrative Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Advanced narrative techniques enhance the depth and impact of creative writing. Which of the following is a technique where a writer begins a story in the middle of the action?,
      options: [
        In medias res is a narrative technique where a story begins in the middle of the action, creating immediacy and engaging the reader immediately, with background information revealed later through flashbacks or exposition.,
        In medias res means beginning at the very beginning.,
        "In medias res is the same as flashback.,
        In medias res is not a narrative technique."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In medias res is a narrative technique where a story begins in the middle of the action, creating immediacy and engaging the reader immediately, with background information revealed later through flashbacks or exposition.
    })
  },
  {
    id: G11-LIT-CW-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Voice and Style",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Voice and style are essential elements of creative writing that distinguish one writer from another. Which of the following contributes to a writer's unique voice?,
      options: [
        A writer's voice is created through their choice of words (diction), sentence structure (syntax), tone, use of figurative language, and the overall perspective and personality that comes through in their writing.,
        Voice is only about word choice.,
        Style is not important in creative writing.",
        "Voice cannot be developed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A writer's voice is created through their choice of words (diction), sentence structure (syntax), tone, use of figurative language, and the overall perspective and personality that comes through in their writing."
    })
  },
  {
    id: "G11-LIT-CW-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "Creative Writing",
    subtopic: "Developing Characters,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Developing believable characters is crucial for effective creative writing. Which of the following is a strategy for creating complex characters?,
      options: [
        Strategies for creating complex characters include giving characters conflicting desires or goals, developing detailed backstories, showing rather than telling their traits, allowing them to change and grow, and including flaws and contradictions.,
        Characters should be completely good or completely evil.,
        "Backstories are not important for character development.,
        Characters should not change throughout a story."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Strategies for creating complex characters include giving characters conflicting desires or goals, developing detailed backstories, showing rather than telling their traits, allowing them to change and grow, and including flaws and contradictions.
    })
  },
  {
    id: G11-LIT-CW-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "Creative Writing,
    subtopic: "Writing Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Writing poetry requires attention to sound, imagery, and form. Which of the following is a consideration when writing a poem in a specific form (e.g., sonnet, haiku)?,
      options: [
        When writing a poem in a specific form, a writer must consider the prescribed rhyme scheme, meter, line count, stanza structure, and thematic conventions, while still expressing their unique voice and ideas.,
        Form does not affect the writing of a poem.,
        All poems have the same form.",
        "Rhyme scheme is not important in formal poetry.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: When writing a poem in a specific form, a writer must consider the prescribed rhyme scheme, meter, line count, stanza structure, and thematic conventions, while still expressing their unique voice and ideas."
    })
  },
  {
    id: "G11-LIT-AL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "African Literature",
    subtopic: "African Novels,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African novels have made significant contributions to world literature. Which of the following is a major theme in Chinua Achebe's novel 'Things Fall Apart'?,
      options: [
        Major themes in 'Things Fall Apart' include the clash between traditional Igbo culture and colonial European culture, the effects of colonialism on African societies, masculinity and gender roles, fate and free will, and the struggle for identity.,
        The novel only addresses traditional rituals.,
        "Colonialism is not a theme in the novel.,
        Gender roles are not explored in the novel."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Major themes in 'Things Fall Apart' include the clash between traditional Igbo culture and colonial European culture, the effects of colonialism on African societies, masculinity and gender roles, fate and free will, and the struggle for identity.
    })
  },
  {
    id: G11-LIT-AL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "African Literature,
    subtopic: "African Poetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " African poetry addresses various themes related to the continent's history and culture. Which of the following is a theme commonly addressed in African poetry?,
      options: [
        Common themes in African poetry include the celebration of African heritage and culture, the critique of colonialism and post-colonial governance, the struggle for freedom and independence, and the exploration of identity and belonging.,
        African poetry only addresses nature.,
        Colonialism is not a theme in African poetry.",
        "African poetry does not address identity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Common themes in African poetry include the celebration of African heritage and culture, the critique of colonialism and post-colonial governance, the struggle for freedom and independence, and the exploration of identity and belonging."
    })
  },
  {
    id: "G11-LIT-AL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "African Literature",
    subtopic: "African Drama,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African drama reflects the social and political realities of the continent. Which of the following is a prominent African playwright known for addressing themes of political corruption and social justice?,
      options: [
        Ngũgĩ wa Thiong'o is a prominent African playwright whose works, such as 'The Trial of Dedan Kimathi' and 'I Will Marry When I Want,' address themes of political oppression, corruption, and the struggle for social justice in Kenya.,
        Ngũgĩ wa Thiong'o only writes poetry.,
        "Ngũgĩ wa Thiong'o addresses only historical themes.,
        Ngũgĩ wa Thiong'o does not address social justice."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ngũgĩ wa Thiong'o is a prominent African playwright whose works, such as 'The Trial of Dedan Kimathi' and 'I Will Marry When I Want,' address themes of political oppression, corruption, and the struggle for social justice in Kenya.
    })
  },
  {
    id: G11-LIT-AL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "African Literature,
    subtopic: "Oral Tradition in African Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Oral tradition influences written African literature. Which of the following is an example of oral tradition elements in African written literature?,
      options: [
        Written African literature often incorporates oral tradition elements such as proverbs, folktales, songs, riddles, and oral narrative structures, as seen in the works of Chinua Achebe and Ngũgĩ wa Thiong'o.,
        Written African literature does not draw from oral tradition.,
        Proverbs are not used in written African literature.",
        "Oral tradition has no influence on written literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Written African literature often incorporates oral tradition elements such as proverbs, folktales, songs, riddles, and oral narrative structures, as seen in the works of Chinua Achebe and Ngũgĩ wa Thiong'o."
    })
  },
  {
    id: "G11-LIT-WL-01",
    grade: "Grade 11",
    subject: "Literature",
    topic: "World Literature",
    subtopic: "European Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "European literature has had a significant influence on global literary traditions. Which of the following is a major work of English literature known for its exploration of themes such as ambition and guilt?,
      options: [
        William Shakespeare's 'Macbeth' is a major work of English literature that explores themes of ambition, power, guilt, and the corrupting influence of unchecked ambition, through the tragic downfall of its protagonist.,
        Macbeth is a comedy.,
        "Macbeth addresses only political themes.,
        Macbeth has no tragic elements."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "William Shakespeare's 'Macbeth' is a major work of English literature that explores themes of ambition, power, guilt, and the corrupting influence of unchecked ambition, through the tragic downfall of its protagonist.
    })
  },
  {
    id: G11-LIT-WL-02",
    grade: "Grade 11,
    subject: Literature",
    topic: "World Literature,
    subtopic: "American Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " American literature reflects the country's diverse history and culture. Which of the following is a significant American literary work that addresses themes of racial injustice and the struggle for equality?,
      options: [
        Harper Lee's 'To Kill a Mockingbird' is a significant American novel that addresses themes of racial injustice, moral growth, empathy, and the loss of innocence, through the eyes of a young girl in the American South.,
        The novel only addresses childhood experiences.,
        Racial injustice is not a theme in the novel.",
        "The novel does not address moral growth.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Harper Lee's 'To Kill a Mockingbird' is a significant American novel that addresses themes of racial injustice, moral growth, empathy, and the loss of innocence, through the eyes of a young girl in the American South."
    })
  },
  {
    id: "G11-LIT-WL-03",
    grade: "Grade 11",
    subject: "Literature",
    topic: "World Literature",
    subtopic: "Asian Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Asian literature offers diverse perspectives and traditions. Which of the following is a notable work from Asian literature that explores themes of tradition and modernity?,
      options: [
        Chinua Achebe's 'Things Fall Apart' is not an Asian novel, but a classic of African literature. For Asian literature, works such as 'The Tale of Genji' by Murasaki Shikibu or 'The God of Small Things' by Arundhati Roy explore tradition and modernity.,
        Asian literature does not address tradition.,
        "The Tale of Genji is an African novel.,
        Asian literature does not address modernity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chinua Achebe's 'Things Fall Apart' is not an Asian novel, but a classic of African literature. For Asian literature, works such as 'The Tale of Genji' by Murasaki Shikibu or 'The God of Small Things' by Arundhati Roy explore tradition and modernity.
    })
  },
  {
    id: G11-LIT-WL-04",
    grade: "Grade 11,
    subject: Literature",
    topic: "World Literature,
    subtopic: "Comparative Global Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " World literature often explores universal themes that resonate across cultures. Which of the following is a universal theme found in literature from around the world?,
      options: [
        Universal themes in world literature include the struggle between good and evil, the search for identity, the experience of love and loss, the challenges of growing up, and the resilience of the human spirit in the face of adversity.,
        Literature from different cultures does not share themes.,
        Love and loss are not universal themes.",
        "The human spirit is not a theme in literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Universal themes in world literature include the struggle between good and evil, the search for identity, the experience of love and loss, the challenges of growing up, and the resilience of the human spirit in the face of adversity."
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD LITERATURE SYLLABUS)
  // =========================================================================

  // --- CRITICAL LITERARY ANALYSIS (5 Materials) ---
  {
    id: "G12-LIT-CA-01",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Critical Literary Analysis",
    subtopic: "Advanced Literary Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Advanced literary criticism involves the systematic evaluation of literary works. Which of the following is a key question that a literary critic might ask when analyzing a novel?,
      options: [
        A literary critic might ask: 'How does the author use literary devices to develop the themes of the work?' and 'What is the relationship between the form of the work and its meaning?' to explore the deeper significance of the text.,
        A literary critic only asks about the author's biography.,
        "A literary critic is not concerned with literary devices.,
        A literary critic only summarizes the plot."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A literary critic might ask: 'How does the author use literary devices to develop the themes of the work?' and 'What is the relationship between the form of the work and its meaning?' to explore the deeper significance of the text.
    })
  },
  {
    id: G12-LIT-CA-02",
    grade: "Grade 12,
    subject: Literature",
    topic: "Critical Literary Analysis,
    subtopic: "Textual Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Textual analysis involves a close reading of a literary text to uncover meaning. Which of the following is a technique used in textual analysis?,
      options: [
        Textual analysis involves examining word choice (diction), sentence structure (syntax), imagery, symbolism, and other literary devices to understand how they contribute to the overall meaning and effect of the text.,
        Textual analysis only looks at the plot summary.,
        Textual analysis ignores the language of the text.",
        "Textual analysis focuses only on the author's biography.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Textual analysis involves examining word choice (diction), sentence structure (syntax), imagery, symbolism, and other literary devices to understand how they contribute to the overall meaning and effect of the text."
    })
  },
  {
    id: "G12-LIT-CA-03",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Critical Literary Analysis",
    subtopic: "Deconstructing Texts,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Deconstruction is a critical approach that examines the assumptions and contradictions in a text. Which of the following is a key idea in deconstruction?,
      options: [
        Deconstruction challenges the idea of a fixed, stable meaning in a text, arguing that meaning is created through the play of language and that texts contain inherent contradictions and ambiguities that reveal their complexity.,
        Deconstruction argues that texts have only one interpretation.,
        "Deconstruction ignores the role of language.,
        Deconstruction is the same as formalist criticism."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Deconstruction challenges the idea of a fixed, stable meaning in a text, arguing that meaning is created through the play of language and that texts contain inherent contradictions and ambiguities that reveal their complexity.
    })
  },
  {
    id: G12-LIT-CA-04",
    grade: "Grade 12,
    subject: Literature",
    topic: "Critical Literary Analysis,
    subtopic: "Feminist Literary Criticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Feminist literary criticism examines how literature represents and constructs gender. Which of the following is a concern of feminist literary criticism?,
      options: [
        Feminist literary criticism examines the representation of women in literature, how gender roles are constructed and challenged, the portrayal of female experiences, and the ways in which literary works reflect or critique patriarchal societies.,
        Feminist literary criticism only focuses on male authors.,
        Feminist literary criticism ignores gender representation.",
        "Feminist literary criticism is not concerned with power dynamics.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Feminist literary criticism examines the representation of women in literature, how gender roles are constructed and challenged, the portrayal of female experiences, and the ways in which literary works reflect or critique patriarchal societies."
    })
  },
  {
    id: "G12-LIT-CA-05",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Critical Literary Analysis",
    subtopic: "Psychoanalytic Criticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Psychoanalytic criticism applies psychological theories to the analysis of literature. Which of the following is a focus of psychoanalytic literary criticism?,
      options: [
        Psychoanalytic criticism examines the unconscious motivations of characters, the symbolism of dreams and desires in literature, and the psychological conflicts that drive the narrative, drawing on the theories of Freud and Jung.,
        Psychoanalytic criticism ignores the psychology of characters.,
        "Psychoanalytic criticism focuses only on the author's psychology.,
        Psychoanalytic criticism does not examine symbolism."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Psychoanalytic criticism examines the unconscious motivations of characters, the symbolism of dreams and desires in literature, and the psychological conflicts that drive the narrative, drawing on the theories of Freud and Jung.
    })
  },

  // --- THEMATIC STUDIES (4 Materials) ---
  {
    id: G12-LIT-TS-01",
    grade: "Grade 12,
    subject: Literature",
    topic: "Thematic Studies,
    subtopic: "The Theme of Identity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The theme of identity is central to many literary works. Which of the following is a way in which the theme of identity is explored in African literature?,
      options: [
        In African literature, the theme of identity is often explored through characters' struggles to define themselves in the context of colonialism, post-colonialism, cultural change, and the tension between tradition and modernity, as seen in works like 'Things Fall Apart' and 'The River Between'.,
        Identity is not a theme in African literature.,
        African literature only explores European identity.",
        "Tradition and modernity are not related to identity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: In African literature, the theme of identity is often explored through characters' struggles to define themselves in the context of colonialism, post-colonialism, cultural change, and the tension between tradition and modernity, as seen in works like 'Things Fall Apart' and 'The River Between'."
    })
  },
  {
    id: "G12-LIT-TS-02",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Thematic Studies",
    subtopic: "The Theme of Power,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The theme of power is a recurring subject in literature. Which of the following is a way in which the theme of power is explored in literary works?,
      options: [
        Literary works explore the theme of power through the portrayal of political leadership, the abuse of power, the struggle for liberation, corruption, and the dynamics of power relationships between individuals, groups, and institutions.,
        Power is not a theme in literature.,
        "Literature only celebrates those in power.,
        The abuse of power is not explored in literature."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Literary works explore the theme of power through the portrayal of political leadership, the abuse of power, the struggle for liberation, corruption, and the dynamics of power relationships between individuals, groups, and institutions.
    })
  },
  {
    id: G12-LIT-TS-03",
    grade: "Grade 12,
    subject: Literature",
    topic: "Thematic Studies,
    subtopic: "The Theme of Love",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Love is a universal theme that appears in many literary works. Which of the following is a way in which love is portrayed in literature?,
      options: [
        In literature, love is portrayed in various forms, including romantic love, familial love, platonic love, and love of country, and is explored through characters' relationships, sacrifices, conflicts, and the challenges they face in pursuing or maintaining love.,
        Love is only portrayed as romantic in literature.,
        Love is not a significant theme in literature.",
        "Love is always portrayed positively in literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: In literature, love is portrayed in various forms, including romantic love, familial love, platonic love, and love of country, and is explored through characters' relationships, sacrifices, conflicts, and the challenges they face in pursuing or maintaining love."
    })
  },
  {
    id: "G12-LIT-TS-04",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Thematic Studies",
    subtopic: "The Theme of Social Justice,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Social justice is a theme that addresses issues of fairness and equality. Which of the following is an example of the theme of social justice in literature?,
      options: [
        The theme of social justice appears in literature through the portrayal of oppression, discrimination, inequality, the struggle for rights, and characters who fight for fairness and justice in their societies, such as in novels addressing racism, colonialism, or class struggle.,
        Social justice is not a literary theme.,
        "Literature does not address inequality.,
        Social justice themes are only found in non-fiction."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The theme of social justice appears in literature through the portrayal of oppression, discrimination, inequality, the struggle for rights, and characters who fight for fairness and justice in their societies, such as in novels addressing racism, colonialism, or class struggle.
    })
  },

  // --- LITERARY MOVEMENTS (5 Materials) ---
  {
    id: G12-LIT-LM-01",
    grade: "Grade 12,
    subject: Literature",
    topic: "Literary Movements,
    subtopic: "Romanticism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Romanticism was a literary movement that emphasized emotion and individualism. Which of the following is a characteristic of Romantic literature?,
      options: [
        Romantic literature is characterized by an emphasis on emotion, imagination, and individualism, a celebration of nature, a fascination with the supernatural, and a rejection of the rationalism and order of the Enlightenment era.,
        Romantic literature emphasizes reason and logic.,
        Romantic literature focuses only on urban life.",
        "Romantic literature rejects emotion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Romantic literature is characterized by an emphasis on emotion, imagination, and individualism, a celebration of nature, a fascination with the supernatural, and a rejection of the rationalism and order of the Enlightenment era."
    })
  },
  {
    id: "G12-LIT-LM-02",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Literary Movements",
    subtopic: "Realism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Realism is a literary movement that sought to depict life as it truly is. Which of the following is a characteristic of Realist literature?,
      options: [
        Realist literature is characterized by the depiction of everyday life and ordinary people, a focus on social issues and class, and a rejection of idealization and romanticism, aiming to present life with accuracy and objectivity.,
        Realist literature idealizes its subjects.,
        "Realist literature focuses only on the upper class.,
        Realist literature avoids social commentary."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Realist literature is characterized by the depiction of everyday life and ordinary people, a focus on social issues and class, and a rejection of idealization and romanticism, aiming to present life with accuracy and objectivity.
    })
  },
  {
    id: G12-LIT-LM-03",
    grade: "Grade 12,
    subject: Literature",
    topic: "Literary Movements,
    subtopic: "Modernism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Modernism was a literary movement that broke with traditional forms and conventions. Which of the following is a characteristic of Modernist literature?,
      options: [
        Modernist literature is characterized by experimentation with form, the use of stream of consciousness, fragmentation, disillusionment with tradition, and an exploration of the inner self, alienation, and the complexities of modern life.,
        Modernist literature uses traditional forms.,
        Modernist literature is optimistic about society.",
        "Modernist literature avoids experimentation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Modernist literature is characterized by experimentation with form, the use of stream of consciousness, fragmentation, disillusionment with tradition, and an exploration of the inner self, alienation, and the complexities of modern life."
    })
  },
  {
    id: "G12-LIT-LM-04",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Literary Movements",
    subtopic: "Post-Modernism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Post-modernism is a literary movement that emerged after Modernism. Which of the following is a characteristic of Post-modernist literature?,
      options: [
        Post-modernist literature is characterized by self-reflexivity, metafiction, irony, playfulness, a rejection of grand narratives, and an emphasis on language and meaning as constructed and unstable.,
        Post-modernist literature believes in fixed meaning.,
        "Post-modernist literature ignores language play.,
        Post-modernist literature is serious and earnest."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Post-modernist literature is characterized by self-reflexivity, metafiction, irony, playfulness, a rejection of grand narratives, and an emphasis on language and meaning as constructed and unstable.
    })
  },
  {
    id: G12-LIT-LM-05",
    grade: "Grade 12,
    subject: Literature",
    topic: "Literary Movements,
    subtopic: "Magical Realism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Magical Realism is a literary genre that blends realistic and magical elements. Which of the following is a characteristic of Magical Realism?,
      options: [
        Magical Realism is characterized by the integration of magical or fantastical elements into a realistic setting, treating the extraordinary as ordinary, and using the magical to explore political, cultural, or social realities.,
        Magical Realism contains no realistic elements.,
        Magical Realism is pure fantasy.",
        "Magical Realism does not address social realities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Magical Realism is characterized by the integration of magical or fantastical elements into a realistic setting, treating the extraordinary as ordinary, and using the magical to explore political, cultural, or social realities."
    })
  },

  // --- COMPARATIVE ANALYSIS (4 Materials) ---
  {
    id: "G12-LIT-CA-01",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Comparative Analysis",
    subtopic: "Cross-Cultural Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Cross-cultural comparison involves examining literary works from different cultures. Which of the following is an approach to cross-cultural comparison?,
      options: [
        Cross-cultural comparison involves examining how different cultures represent universal themes such as love, death, and identity, as well as how cultural values and historical experiences shape the form and meaning of literary works.,
        Cross-cultural comparison is only possible for texts from the same culture.,
        "Cross-cultural comparison ignores cultural context.,
        Cross-cultural comparison is not a valid approach."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cross-cultural comparison involves examining how different cultures represent universal themes such as love, death, and identity, as well as how cultural values and historical experiences shape the form and meaning of literary works.
    })
  },
  {
    id: G12-LIT-CA-02",
    grade: "Grade 12,
    subject: Literature",
    topic: "Comparative Analysis,
    subtopic: "Intertextual Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Intertextual analysis examines how texts relate to and reference other texts. Which of the following is an example of intertextuality in literature?,
      options: [
        Intertextuality occurs when a text references, quotes, or alludes to another text, such as a novel that incorporates elements of a classical myth, or a poem that alludes to a well-known literary work, creating layers of meaning.,
        Intertextuality is the same as plagiarism.,
        Intertextuality occurs only in non-fiction.",
        "Intertextuality is not a literary concept.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Intertextuality occurs when a text references, quotes, or alludes to another text, such as a novel that incorporates elements of a classical myth, or a poem that alludes to a well-known literary work, creating layers of meaning."
    })
  },
  {
    id: "G12-LIT-CA-03",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Comparative Analysis",
    subtopic: "Thematic Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Thematic comparison examines how different authors treat the same theme. Which of the following is a benefit of thematic comparison?,
      options: [
        Thematic comparison allows readers to understand how different cultural contexts and authorial perspectives shape the portrayal of the same theme, revealing the diversity and depth of human experience and literary expression.,
        Thematic comparison simplifies literary analysis.,
        "Thematic comparison ignores differences between texts.,
        Thematic comparison is only useful for poems."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Thematic comparison allows readers to understand how different cultural contexts and authorial perspectives shape the portrayal of the same theme, revealing the diversity and depth of human experience and literary expression.
    })
  },
  {
    id: G12-LIT-CA-04",
    grade: "Grade 12,
    subject: Literature",
    topic: "Comparative Analysis,
    subtopic: "Genre Comparison",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Genre comparison examines how different genres approach similar subjects. Which of the following is an example of genre comparison?,
      options: [
        Genre comparison might examine how the theme of war is treated differently in a novel, a poem, and a play, considering how the conventions and constraints of each genre shape the representation of the subject.,
        Genre comparison only examines texts from the same genre.,
        Genre comparison is not a valid approach.",
        "Genre comparison ignores thematic content.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Genre comparison might examine how the theme of war is treated differently in a novel, a poem, and a play, considering how the conventions and constraints of each genre shape the representation of the subject."
    })
  },

  // --- CREATIVE WRITING PORTFOLIO (4 Materials) ---
  {
    id: "G12-LIT-CW-01",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Creative Writing Portfolio",
    subtopic: "Crafting a Narrative,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Crafting a narrative requires attention to structure and style. Which of the following is a key consideration when writing a short story?,
      options: [
        When writing a short story, key considerations include developing a clear plot with a beginning, middle, and end, creating engaging characters, establishing a vivid setting, and using dialogue and action to advance the story and reveal character.,
        Plot is not important in a short story.,
        "Characters do not need development.,
        Setting is irrelevant to a short story."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "When writing a short story, key considerations include developing a clear plot with a beginning, middle, and end, creating engaging characters, establishing a vivid setting, and using dialogue and action to advance the story and reveal character.
    })
  },
  {
    id: G12-LIT-CW-02",
    grade: "Grade 12,
    subject: Literature",
    topic: "Creative Writing Portfolio,
    subtopic: "Revising and Editing",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Revision and editing are essential stages of the writing process. Which of the following is an aspect of revising a creative writing piece?,
      options: [
        Revising involves rethinking the content, structure, and style of a piece, improving the development of ideas, characters, and plot, while editing focuses on correcting grammar, punctuation, spelling, and word choice.,
        Revising is the same as editing.,
        Revision is not necessary for creative writing.",
        "Editing only focuses on plot.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Revising involves rethinking the content, structure, and style of a piece, improving the development of ideas, characters, and plot, while editing focuses on correcting grammar, punctuation, spelling, and word choice."
    })
  },
  {
    id: "G12-LIT-CW-03",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Creative Writing Portfolio",
    subtopic: "Developing Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Developing a unique voice is important in creative writing. Which of the following contributes to a writer's distinctive voice?,
      options: [
        A writer's voice is shaped by their choice of words, sentence structure, tone, use of figurative language, and the perspective and personality that come through in their writing, reflecting their unique way of seeing and expressing the world.,
        Voice is only about word choice.,
        "Voice cannot be developed intentionally.,
        Voice is the same as style."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A writer's voice is shaped by their choice of words, sentence structure, tone, use of figurative language, and the perspective and personality that come through in their writing, reflecting their unique way of seeing and expressing the world.
    })
  },
  {
    id: G12-LIT-CW-04",
    grade: "Grade 12,
    subject: Literature",
    topic: "Creative Writing Portfolio,
    subtopic: "Portfolio Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " A creative writing portfolio is a collection of original works. Which of the following is a criterion for assessing a creative writing portfolio?,
      options: [
        Criteria for assessing a creative writing portfolio include the quality of the writing, creativity and originality, the development of themes, the use of literary techniques, the effectiveness of style and voice, and the overall coherence and impact of the collection.,
        A portfolio is assessed only on quantity.,
        Originality is not a criterion for assessment.",
        "The use of literary techniques is not considered.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Criteria for assessing a creative writing portfolio include the quality of the writing, creativity and originality, the development of themes, the use of literary techniques, the effectiveness of style and voice, and the overall coherence and impact of the collection."
    })
  },

  // --- LITERARY THEORY (5 Materials) ---
  {
    id: "G12-LIT-LT-01",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Literary Theory",
    subtopic: "Marxist Literary Theory,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Marxist literary theory examines literature through the lens of class struggle and economic systems. Which of the following is a concern of Marxist literary criticism?,
      options: [
        Marxist literary criticism examines how literature reflects and critiques class relations, economic inequality, and the power structures of capitalist societies, focusing on the portrayal of social classes, labor, and economic conflict.,
        Marxist criticism ignores economic factors.,
        "Marxist criticism focuses only on the ruling class.,
        Marxist criticism does not address social conflict."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Marxist literary criticism examines how literature reflects and critiques class relations, economic inequality, and the power structures of capitalist societies, focusing on the portrayal of social classes, labor, and economic conflict.
    })
  },
  {
    id: G12-LIT-LT-02",
    grade: "Grade 12,
    subject: Literature",
    topic: "Literary Theory,
    subtopic: "Structuralism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Structuralism in literary theory examines the underlying structures that give meaning to texts. Which of the following is a principle of structuralism?,
      options: [
        Structuralism holds that meaning is produced through the relationships and differences between elements in a system, and that literary texts can be understood by analyzing their underlying structures and patterns.,
        Structuralism argues that meaning is random.,
        Structuralism ignores textual structure.",
        "Structuralism focuses only on the author's intent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Structuralism holds that meaning is produced through the relationships and differences between elements in a system, and that literary texts can be understood by analyzing their underlying structures and patterns."
    })
  },
  {
    id: "G12-LIT-LT-03",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Literary Theory",
    subtopic: "Post-Structuralism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Post-structuralism challenges the assumptions of structuralism. Which of the following is a key idea in post-structuralist theory?,
      options: [
        Post-structuralism argues that meaning is unstable and always deferred, that language cannot capture reality perfectly, and that texts contain contradictions and ambiguities that resist fixed interpretation.,
        Post-structuralism believes in fixed meaning.,
        "Post-structuralism ignores language.,
        Post-structuralism is the same as structuralism."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Post-structuralism argues that meaning is unstable and always deferred, that language cannot capture reality perfectly, and that texts contain contradictions and ambiguities that resist fixed interpretation.
    })
  },
  {
    id: G12-LIT-LT-04",
    grade: "Grade 12,
    subject: Literature",
    topic: "Literary Theory,
    subtopic: "Post-Colonial Theory",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Post-colonial theory examines the cultural and political legacy of colonialism. Which of the following is a key concern of post-colonial theory?,
      options: [
        Post-colonial theory examines how literature addresses the effects of colonialism, the construction of identity in post-colonial contexts, the representation of colonized and colonizer, and the resistance to colonial discourse and power.,
        Post-colonial theory ignores colonial history.,
        Post-colonial theory only focuses on European literature.",
        "Post-colonial theory is not concerned with identity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Post-colonial theory examines how literature addresses the effects of colonialism, the construction of identity in post-colonial contexts, the representation of colonized and colonizer, and the resistance to colonial discourse and power."
    })
  },
  {
    id: "G12-LIT-LT-05",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Literary Theory",
    subtopic: "Ecocriticism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Ecocriticism is a literary theory that examines the relationship between literature and the environment. Which of the following is a focus of ecocriticism?,
      options: [
        Ecocriticism examines how literature represents the natural world, environmental degradation, and the relationship between humans and nature, and how literary works can contribute to environmental awareness and action.,
        Ecocriticism ignores the environment.,
        "Ecocriticism only focuses on urban settings.,
        Ecocriticism is not a valid literary theory."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ecocriticism examines how literature represents the natural world, environmental degradation, and the relationship between humans and nature, and how literary works can contribute to environmental awareness and action.
    })
  },

  // --- POST-COLONIAL LITERATURE (4 Materials) ---
  {
    id: G12-LIT-PC-01",
    grade: "Grade 12,
    subject: Literature",
    topic: "Post-Colonial Literature,
    subtopic: "African Post-Colonial Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Post-colonial literature from Africa addresses the legacy of colonialism. Which of the following is a theme commonly found in African post-colonial literature?,
      options: [
        Themes in African post-colonial literature include the search for identity after colonialism, the struggle between tradition and modernity, the critique of corrupt post-colonial governments, the representation of cultural hybridity, and the recovery of suppressed histories and voices.,
        African post-colonial literature only addresses colonial history.,
        African post-colonial literature ignores contemporary issues.",
        "Cultural hybridity is not a theme in post-colonial literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Themes in African post-colonial literature include the search for identity after colonialism, the struggle between tradition and modernity, the critique of corrupt post-colonial governments, the representation of cultural hybridity, and the recovery of suppressed histories and voices."
    })
  },
  {
    id: "G12-LIT-PC-02",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Post-Colonial Literature",
    subtopic: "Caribbean Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Caribbean post-colonial literature explores the effects of colonialism and slavery. Which of the following is a theme in Caribbean post-colonial literature?,
      options: [
        Caribbean post-colonial literature explores themes of identity and displacement, the legacy of slavery and colonialism, cultural hybridity (Creolization), resistance and liberation, and the negotiation of African, European, and indigenous influences.,
        Caribbean literature only addresses European themes.,
        "Slavery is not a theme in Caribbean literature.,
        Caribbean literature does not address identity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Caribbean post-colonial literature explores themes of identity and displacement, the legacy of slavery and colonialism, cultural hybridity (Creolization), resistance and liberation, and the negotiation of African, European, and indigenous influences.
    })
  },
  {
    id: G12-LIT-PC-03",
    grade: "Grade 12,
    subject: Literature",
    topic: "Post-Colonial Literature,
    subtopic: "Indian Post-Colonial Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Post-colonial literature from India addresses the impact of British colonialism. Which of the following is a concern of Indian post-colonial literature?,
      options: [
        Indian post-colonial literature examines the effects of partition, the negotiation of tradition and modernity, the role of English in post-colonial society, the representation of diaspora and migration, and the critique of caste and gender hierarchies.,
        Indian literature only addresses colonial history.,
        Caste is not addressed in Indian literature.",
        "Indian post-colonial literature ignores gender issues.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Indian post-colonial literature examines the effects of partition, the negotiation of tradition and modernity, the role of English in post-colonial society, the representation of diaspora and migration, and the critique of caste and gender hierarchies."
    })
  },
  {
    id: "G12-LIT-PC-04",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Post-Colonial Literature",
    subtopic: "Writing Back to the Centre,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The concept of 'writing back to the centre' refers to post-colonial writers challenging and subverting colonial literary traditions. Which of the following is an example of writing back to the centre?,
      options: [
        Post-colonial writers 'write back to the centre' by rewriting colonial narratives from indigenous perspectives, using local languages and forms, challenging colonial representations, and asserting alternative identities and histories.,
        Writing back to the centre means imitating colonial literature.,
        "Writing back to the centre reinforces colonial narratives.,
        Writing back to the centre ignores indigenous perspectives."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Post-colonial writers 'write back to the centre' by rewriting colonial narratives from indigenous perspectives, using local languages and forms, challenging colonial representations, and asserting alternative identities and histories.
    })
  },

  // --- CONTEMPORARY LITERATURE (4 Materials) ---
  {
    id: G12-LIT-CL-01",
    grade: "Grade 12,
    subject: Literature",
    topic: "Contemporary Literature,
    subtopic: "Contemporary Trends",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contemporary literature reflects current trends and issues in society. Which of the following is a trend in contemporary literature?,
      options: [
        Trends in contemporary literature include the use of diverse voices and perspectives, experimentation with form (including digital and multimedia), the exploration of globalization and identity, and the treatment of pressing social and environmental issues.,
        Contemporary literature uses only traditional forms.,
        Contemporary literature does not address social issues.",
        "Globalization is not a theme in contemporary literature.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Trends in contemporary literature include the use of diverse voices and perspectives, experimentation with form (including digital and multimedia), the exploration of globalization and identity, and the treatment of pressing social and environmental issues."
    })
  },
  {
    id: "G12-LIT-CL-02",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Contemporary Literature",
    subtopic: "Technology and Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Technology has influenced contemporary literature in various ways. Which of the following is a way in which technology has impacted literature?,
      options: [
        Technology has impacted literature through the emergence of new forms such as digital fiction, hypertext, and interactive narratives, as well as through the use of social media and digital publishing platforms for the creation and dissemination of literary works.,
        Technology has not influenced literature.,
        "Digital fiction is not a form of literature.,
        Technology only affects how literature is consumed, not created."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Technology has impacted literature through the emergence of new forms such as digital fiction, hypertext, and interactive narratives, as well as through the use of social media and digital publishing platforms for the creation and dissemination of literary works.
    })
  },
  {
    id: G12-LIT-CL-03",
    grade: "Grade 12,
    subject: Literature",
    topic: "Contemporary Literature,
    subtopic: "Diverse Voices",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Contemporary literature increasingly features diverse voices. Which of the following is an example of a diverse voice that has gained prominence in contemporary literature?,
      options: [
        Contemporary literature has seen the rise of voices from marginalized communities, including writers from African diaspora, indigenous peoples, LGBTQ+ writers, and writers from other underrepresented groups, whose works enrich the literary landscape.,
        Diverse voices are not represented in contemporary literature.,
        Contemporary literature is dominated by a single perspective.",
        "Marginalized voices are only found in non-fiction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Contemporary literature has seen the rise of voices from marginalized communities, including writers from African diaspora, indigenous peoples, LGBTQ+ writers, and writers from other underrepresented groups, whose works enrich the literary landscape."
    })
  },
  {
    id: "G12-LIT-CL-04",
    grade: "Grade 12",
    subject: "Literature",
    topic: "Contemporary Literature",
    subtopic: "Environmental Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Environmental literature addresses ecological concerns. Which of the following is a theme in contemporary environmental literature?,
      options: [
        Environmental literature addresses themes such as climate change, environmental degradation, the relationship between humans and nature, sustainability, and the impact of human activity on the planet, often calling for awareness and action.,
        Environmental literature does not address climate change.,
        "Environmental literature ignores human impact.,
        Environmental literature is not a significant genre."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Environmental literature addresses themes such as climate change, environmental degradation, the relationship between humans and nature, sustainability, and the impact of human activity on the planet, often calling for awareness and action."
    })
  }
];


