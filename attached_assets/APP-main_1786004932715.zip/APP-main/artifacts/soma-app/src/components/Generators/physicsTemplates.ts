export const physicsTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD PHYSICS SYLLABUS)
  // =========================================================================

  // --- INTRODUCTION TO PHYSICS (3 Materials) ---
  {
    id: "G10-PHY-IP-01",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Introduction to Physics",
    subtopic: "Definition of Physics",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "Physics is a fundamental science that studies the natural world. Which of the following best defines physics and its primary focus?",
      options: ["Physics is the branch of science that studies matter", energy, and their interactions, focusing on understanding the fundamental laws and principles that govern the behavior of the universe.,
        Physics is the study of living organisms and their environment.,
        "Physics is the study of chemical reactions and compounds.,
        Physics is the study of ancient civilizations and their technologies."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Physics is the branch of science that studies matter, energy, and their interactions, focusing on understanding the fundamental laws and principles that govern the behavior of the universe.
    })
  },
  {
    id: G10-PHY-IP-02",
    grade: "Grade 10,
    subject: Physics",
    topic: "Introduction to Physics,
    subtopic: "Branches of Physics",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Physics is divided into various branches that focus on different aspects of the physical world. Which of the following branches of physics deals with the study of heat and temperature?,
      options: ["Thermodynamics is the branch of physics that deals with heat", temperature, and the relationship between heat and other forms of energy.,
        Mechanics deals with motion and forces.",
        Optics deals with light and its properties.",
        "Electromagnetism deals with electricity and magnetism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Thermodynamics is the branch of physics that deals with heat", temperature, and the relationship between heat and other forms of energy."
    })
  },
  {
    id: "G10-PHY-IP-03",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Introduction to Physics",
    subtopic: "Measurement,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Measurement is fundamental to physics and involves quantifying physical quantities. Which of the following is the SI unit for length?,
      options: ["The SI unit for length is the meter (m)", which is the fundamental unit of length in the International System of Units.,
        The SI unit for length is the kilometer (km).",
        "The SI unit for length is the centimeter (cm).,
        The SI unit for length is the inch (in)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for length is the meter (m), which is the fundamental unit of length in the International System of Units.
    })
  },

  // --- MECHANICS (6 Materials) ---
  {
    id: G10-PHY-MC-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Mechanics,
    subtopic: "Motion",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Motion is the change in position of an object over time. Which of the following correctly describes the difference between speed and velocity?,
      options: ["Speed is a scalar quantity that measures the rate of change of distance without direction", while velocity is a vector quantity that measures the rate of change of displacement with direction.,
        Speed and velocity are the same thing.",
        Speed is a vector quantity while velocity is a scalar quantity.",
        "Speed measures displacement while velocity measures distance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Speed is a scalar quantity that measures the rate of change of distance without direction", while velocity is a vector quantity that measures the rate of change of displacement with direction."
    })
  },
  {
    id: "G10-PHY-MC-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Mechanics",
    subtopic: "Acceleration,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Acceleration is the rate of change of velocity. Which of the following is the SI unit for acceleration?,
      options: ["The SI unit for acceleration is meters per second squared (m/s²)", which represents the change in velocity per unit time.,
        The SI unit for acceleration is meters per second (m/s).",
        "The SI unit for acceleration is kilograms (kg).,
        The SI unit for acceleration is newtons (N)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for acceleration is meters per second squared (m/s²), which represents the change in velocity per unit time.
    })
  },
  {
    id: G10-PHY-MC-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Mechanics,
    subtopic: "Forces",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Newton's laws of motion describe the relationship between forces and motion. Which of the following correctly states Newton's First Law of Motion?,
      options: ["Newton's First Law states that an object will remain at rest or continue moving at a constant velocity unless acted upon by an external force", also known as the law of inertia.,
        Newton's First Law states that force equals mass times acceleration.,
        Newton's First Law states that for every action", there is an equal and opposite reaction.",
        "Newton's First Law states that energy is conserved in all interactions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Newton's First Law states that an object will remain at rest or continue moving at a constant velocity unless acted upon by an external force", also known as the law of inertia."
    })
  },
  {
    id: "G10-PHY-MC-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Mechanics",
    subtopic: "Newton's Second Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Newton's Second Law relates force, mass, and acceleration. If a force of 20 N is applied to a mass of 5 kg, what is the acceleration produced?",
      options: ["Using F = ma", "acceleration = F/m = 20 N / 5 kg = 4 m/s².",
        Acceleration = 25 m/s².",
        "Acceleration = 15 m/s².,
        Acceleration = 100 m/s²."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using F = ma, acceleration = F/m = 20 N / 5 kg = 4 m/s².
    })
  },
  {
    id: G10-PHY-MC-05",
    grade: "Grade 10,
    subject: Physics",
    topic: "Mechanics,
    subtopic: "Newton's Third Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Newton's Third Law states that for every action, there is an equal and opposite reaction. Which of the following is an example of Newton's Third Law?,
      options: ["A rocket launching is an example of Newton's Third Law: the rocket expels exhaust gases downward (action)", and the gases push the rocket upward (reaction).,
        A ball rolling on the ground is an example of Newton's Third Law.",
        A car speeding up is an example of Newton's Third Law.",
        "A book resting on a table is an example of Newton's Third Law.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A rocket launching is an example of Newton's Third Law: the rocket expels exhaust gases downward (action)", and the gases push the rocket upward (reaction)."
    })
  },
  {
    id: "G10-PHY-MC-06",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Mechanics",
    subtopic: "Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Energy is the capacity to do work. Which of the following is the SI unit for energy?,
      options: ["The SI unit for energy is the joule (J)", which is defined as the work done when a force of one newton moves an object through a distance of one meter.,
        The SI unit for energy is the watt (W).",
        "The SI unit for energy is the newton (N).,
        The SI unit for energy is the kilogram (kg)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for energy is the joule (J), which is defined as the work done when a force of one newton moves an object through a distance of one meter.
    })
  },

  // --- THERMAL PHYSICS (4 Materials) ---
  {
    id: G10-PHY-TP-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Thermal Physics,
    subtopic: "Heat and Temperature",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Heat and temperature are related but distinct concepts. Which of the following correctly distinguishes between heat and temperature?,
      options: ["Heat is the transfer of thermal energy from one object to another due to a temperature difference", while temperature is a measure of the average kinetic energy of the particles in a substance.,
        Heat and temperature are the same thing.",
        Heat is measured in degrees while temperature is measured in joules.",
        "Temperature is the transfer of thermal energy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Heat is the transfer of thermal energy from one object to another due to a temperature difference", while temperature is a measure of the average kinetic energy of the particles in a substance."
    })
  },
  {
    id: "G10-PHY-TP-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Thermal Physics",
    subtopic: "Thermal Expansion,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Thermal expansion occurs when substances expand upon heating. Which of the following describes why most substances expand when heated?,
      options: ["Most substances expand when heated because the particles gain kinetic energy and move further apart", increasing the volume of the substance.,
        Most substances contract when heated.",
        "Thermal expansion occurs because particles lose energy.,
        Substances do not expand when heated."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Most substances expand when heated because the particles gain kinetic energy and move further apart, increasing the volume of the substance.
    })
  },
  {
    id: G10-PHY-TP-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Thermal Physics,
    subtopic: "Heat Transfer",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Heat can be transferred through various mechanisms. Which of the following is the method of heat transfer that does not require a medium?,
      options: ["Radiation is the method of heat transfer that does not require a medium", as it involves the transfer of energy through electromagnetic waves (e.g., heat from the sun).,
        Conduction requires a medium.",
        Convection requires a medium.",
        "All methods of heat transfer require a medium.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Radiation is the method of heat transfer that does not require a medium", as it involves the transfer of energy through electromagnetic waves (e.g., heat from the sun)."
    })
  },
  {
    id: "G10-PHY-TP-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Thermal Physics",
    subtopic: "Thermal Conductivity,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Thermal conductivity is a measure of a material's ability to conduct heat. Which of the following materials is the best conductor of heat?,
      options: ["Metals such as copper and aluminum are the best conductors of heat due to their free electrons that can transfer thermal energy rapidly.",
        Wood is the best conductor of heat.",
        "Plastic is the best conductor of heat.,
        Rubber is the best conductor of heat."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Metals such as copper and aluminum are the best conductors of heat due to their free electrons that can transfer thermal energy rapidly.
    })
  },

  // --- WAVES (5 Materials) ---
  {
    id: G10-PHY-WV-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Waves,
    subtopic: "Properties of Waves",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Waves are disturbances that transfer energy without transferring matter. Which of the following is a property of a wave?,
      options: ["Wave properties include amplitude (height)", wavelength (distance between successive crests or troughs), frequency (number of waves per second), and speed (how fast the wave travels).,
        Waves only have amplitude.",
        Waves do not have wavelength.",
        "Waves do not have frequency.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Wave properties include amplitude (height)", wavelength (distance between successive crests or troughs), frequency (number of waves per second), and speed (how fast the wave travels)."
    })
  },
  {
    id: "G10-PHY-WV-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Waves",
    subtopic: "Types of Waves,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Waves can be classified as transverse or longitudinal. Which of the following correctly describes a transverse wave?,
      options: ["A transverse wave is a wave in which the particles of the medium vibrate perpendicular to the direction of wave propagation", such as waves on a string or electromagnetic waves.,
        A transverse wave has particles vibrating parallel to the direction of wave propagation.",
        "Sound waves are transverse waves.,
        Light waves are longitudinal waves."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A transverse wave is a wave in which the particles of the medium vibrate perpendicular to the direction of wave propagation, such as waves on a string or electromagnetic waves.
    })
  },
  {
    id: G10-PHY-WV-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Waves,
    subtopic: "Sound",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Sound is a mechanical wave that requires a medium to travel. Which of the following is the approximate speed of sound in air at room temperature?,
      options: ["The speed of sound in air at room temperature (20°C) is approximately 343 m/s.",
        The speed of sound in air is 3 × 10⁸ m/s.",
        The speed of sound in air is 1500 m/s.",
        "The speed of sound in air is 600 m/s.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The speed of sound in air at room temperature (20°C) is approximately 343 m/s."
    })
  },
  {
    id: "G10-PHY-WV-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Waves",
    subtopic: "Electromagnetic Waves,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Electromagnetic waves are waves that can travel through a vacuum. Which of the following is an example of an electromagnetic wave?,
      options: ["Light is an electromagnetic wave that can travel through a vacuum", along with radio waves, microwaves, infrared, ultraviolet, X-rays, and gamma rays.,
        Sound is an electromagnetic wave.",
        "Water waves are electromagnetic waves.,
        Sound is a transverse wave."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Light is an electromagnetic wave that can travel through a vacuum, along with radio waves, microwaves, infrared, ultraviolet, X-rays, and gamma rays.
    })
  },
  {
    id: G10-PHY-WV-05",
    grade: "Grade 10,
    subject: Physics",
    topic: "Waves,
    subtopic: "Wave Equation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The wave equation relates wave speed, frequency, and wavelength. If a wave has a frequency of 50 Hz and a wavelength of 4 m, what is its speed?,
      options: ["Speed = frequency × wavelength = 50 Hz × 4 m = 200 m/s.",
        Speed = 12.5 m/s.",
        Speed = 54 m/s.",
        "Speed = 46 m/s.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Speed = frequency × wavelength = 50 Hz × 4 m = 200 m/s."
    })
  },

  // --- ELECTRICITY (5 Materials) ---
  {
    id: "G10-PHY-EL-01",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Electricity",
    subtopic: "Electric Circuits,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "An electric circuit is a closed loop through which electric current can flow. Which of the following is required for current to flow in a circuit?,
      options: ["A closed loop of conducting material", a source of electromotive force (such as a battery), and a load (such as a bulb) are required for current to flow in a circuit.,
        Only a battery is required.",
        "Only a conducting wire is required.,
        A switch is not required."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A closed loop of conducting material, a source of electromotive force (such as a battery), and a load (such as a bulb) are required for current to flow in a circuit.
    })
  },
  {
    id: G10-PHY-EL-02",
    grade: "Grade 10,
    subject: Physics",
    topic: "Electricity,
    subtopic: "Current",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Electric current is the flow of electric charge. Which of the following is the SI unit for electric current?,
      options: ["The SI unit for electric current is the ampere (A)", which is defined as the flow of one coulomb of charge per second.,
        The SI unit for electric current is the volt (V).",
        The SI unit for electric current is the ohm (Ω).",
        "The SI unit for electric current is the watt (W).
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for electric current is the ampere (A)", which is defined as the flow of one coulomb of charge per second."
    })
  },
  {
    id: "G10-PHY-EL-03",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Electricity",
    subtopic: "Voltage,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Voltage is the electric potential difference that drives current. Which of the following is the SI unit for voltage?,
      options: ["The SI unit for voltage is the volt (V)", named after Alessandro Volta, representing the potential difference required to produce one ampere of current with one watt of power.,
        The SI unit for voltage is the ampere (A).",
        "The SI unit for voltage is the ohm (Ω).,
        The SI unit for voltage is the coulomb (C)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for voltage is the volt (V), named after Alessandro Volta, representing the potential difference required to produce one ampere of current with one watt of power.
    })
  },
  {
    id: G10-PHY-EL-04",
    grade: "Grade 10,
    subject: Physics",
    topic: "Electricity,
    subtopic: "Resistance",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Resistance is the opposition to the flow of electric current. Which of the following is the SI unit for resistance?,
      options: ["The SI unit for resistance is the ohm (Ω)", named after Georg Simon Ohm, representing the resistance that allows one ampere of current to flow when a voltage of one volt is applied.,
        The SI unit for resistance is the volt (V).",
        The SI unit for resistance is the ampere (A).",
        "The SI unit for resistance is the watt (W).
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for resistance is the ohm (Ω)", named after Georg Simon Ohm, representing the resistance that allows one ampere of current to flow when a voltage of one volt is applied."
    })
  },
  {
    id: "G10-PHY-EL-05",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Electricity",
    subtopic: "Series and Parallel Circuits,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "In a series circuit, components are connected one after another. Which of the following is true about current in a series circuit?,
      options: ["In a series circuit", the current is the same at all points in the circuit because there is only one path for the current to flow.,
        In a series circuit", the current is different at different points.",
        "In a series circuit, the current is zero at all times.,
        In a series circuit, the current is split between the components."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In a series circuit, the current is the same at all points in the circuit because there is only one path for the current to flow.
    })
  },

  // --- MAGNETISM (4 Materials) ---
  {
    id: G10-PHY-MG-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Magnetism,
    subtopic: "Magnetic Fields",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Magnetic fields are regions where magnetic forces can be detected. Which of the following correctly describes the direction of magnetic field lines around a bar magnet?,
      options: ["Magnetic field lines exit from the north pole of a magnet and enter the south pole", forming continuous loops outside and inside the magnet.,
        Magnetic field lines exit from the south pole and enter the north pole.",
        Magnetic field lines are parallel and do not form loops.",
        "Magnetic field lines only exist outside the magnet.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Magnetic field lines exit from the north pole of a magnet and enter the south pole", forming continuous loops outside and inside the magnet."
    })
  },
  {
    id: "G10-PHY-MG-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Magnetism",
    subtopic: "Electromagnets,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Electromagnets are magnets whose magnetic field is produced by an electric current. Which of the following is a way to increase the strength of an electromagnet?,
      options: ["The strength of an electromagnet can be increased by increasing the current", increasing the number of turns of wire in the coil, or using a core made of a magnetic material such as iron.,
        Increasing the voltage reduces the strength.",
        "Using a core made of plastic increases the strength.,
        Reducing the number of turns increases the strength."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The strength of an electromagnet can be increased by increasing the current, increasing the number of turns of wire in the coil, or using a core made of a magnetic material such as iron.
    })
  },
  {
    id: G10-PHY-MG-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Magnetism,
    subtopic: "Applications of Magnets",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Magnets have numerous practical applications. Which of the following is an application of electromagnets in modern technology?,
      options: ["Electromagnets are used in electric motors", generators, transformers, magnetic resonance imaging (MRI) machines, and magnetic levitation trains (maglev).,
        Electromagnets are only used in simple compasses.",
        Electromagnets are used only in toys.",
        "Electromagnets have no practical applications.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Electromagnets are used in electric motors", generators, transformers, magnetic resonance imaging (MRI) machines, and magnetic levitation trains (maglev)."
    })
  },
  {
    id: "G10-PHY-MG-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Magnetism",
    subtopic: "Magnetic Materials,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Materials can be classified based on their magnetic properties. Which of the following is a ferromagnetic material?,
      options: ["Iron is a ferromagnetic material", meaning it can be magnetized and attracted to magnets, along with cobalt and nickel.,
        Copper is a ferromagnetic material.",
        "Aluminum is a ferromagnetic material.,
        Gold is a ferromagnetic material."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Iron is a ferromagnetic material, meaning it can be magnetized and attracted to magnets, along with cobalt and nickel.
    })
  },

  // --- OPTICS (4 Materials) ---
  {
    id: G10-PHY-OP-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Optics,
    subtopic: "Reflection",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Reflection is the bouncing back of light from a surface. Which of the following states the law of reflection?,
      options: ["The law of reflection states that the angle of incidence equals the angle of reflection", measured from the normal to the reflecting surface.,
        The law of reflection states that the angle of incidence is twice the angle of reflection.",
        The law of reflection states that the angle of incidence is half the angle of reflection.",
        "The law of reflection states that light is always absorbed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The law of reflection states that the angle of incidence equals the angle of reflection", measured from the normal to the reflecting surface."
    })
  },
  {
    id: "G10-PHY-OP-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Optics",
    subtopic: "Refraction,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Refraction is the bending of light as it passes from one medium to another. When light travels from air into water, which of the following occurs?,
      options: ["When light travels from air into water", it slows down and bends toward the normal because water has a higher refractive index than air.",
        Light speeds up and bends away from the normal.",
        "Light continues at the same speed and does not bend.,
        Light is completely reflected."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "When light travels from air into water, it slows down and bends toward the normal because water has a higher refractive index than air.
    })
  },
  {
    id: G10-PHY-OP-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Optics,
    subtopic: "Lenses",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Lenses are optical devices that refract light. Which of the following describes a convex lens?,
      options: ["A convex lens is thicker at the center than at the edges and converges light rays to a focal point", making it a converging lens.,
        A convex lens is thinner at the center than at the edges and diverges light rays.",
        A convex lens has no effect on light rays.",
        "A convex lens is used only in microscopes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A convex lens is thicker at the center than at the edges and converges light rays to a focal point", making it a converging lens."
    })
  },
  {
    id: "G10-PHY-OP-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Optics",
    subtopic: "Mirrors,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Mirrors are surfaces that reflect light to form images. Which of the following describes a concave mirror?,
      options: ["A concave mirror curves inward like the inside of a sphere and converges light rays to a focal point", allowing it to form real or virtual images.,
        A concave mirror curves outward like the back of a spoon and diverges light rays.",
        "A concave mirror is flat.,
        A concave mirror has no focal point."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A concave mirror curves inward like the inside of a sphere and converges light rays to a focal point, allowing it to form real or virtual images.
    })
  },

  // --- ENERGY (4 Materials) ---
  {
    id: G10-PHY-EN-01",
    grade: "Grade 10,
    subject: Physics",
    topic: "Energy,
    subtopic: "Forms of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Energy exists in various forms and can be converted from one form to another. Which of the following is an example of potential energy?,
      options: ["Potential energy is stored energy due to an object's position or configuration", such as gravitational potential energy of a raised object or elastic potential energy of a stretched spring.,
        Kinetic energy is an example of potential energy.",
        Thermal energy is an example of potential energy.",
        "Sound energy is an example of potential energy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Potential energy is stored energy due to an object's position or configuration", such as gravitational potential energy of a raised object or elastic potential energy of a stretched spring."
    })
  },
  {
    id: "G10-PHY-EN-02",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Energy",
    subtopic: "Kinetic Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Kinetic energy is the energy of motion. Which of the following is the formula for kinetic energy?,
      options: ["Kinetic energy (KE) = ½ mv²", where m is the mass and v is the velocity of the object.,
        Kinetic energy = mgh.",
        "Kinetic energy = Fd.,
        Kinetic energy = ½ kx²."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kinetic energy (KE) = ½ mv², where m is the mass and v is the velocity of the object.
    })
  },
  {
    id: G10-PHY-EN-03",
    grade: "Grade 10,
    subject: Physics",
    topic: "Energy,
    subtopic: "Conservation of Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The law of conservation of energy states that energy cannot be created or destroyed, only transformed. Which of the following is an example of energy conservation?,
      options: ["Energy is conserved when an object falls: gravitational potential energy is converted to kinetic energy", with the total mechanical energy remaining constant (neglecting air resistance).,
        Energy is conserved only in nuclear reactions.",
        Energy can be created by humans.",
        "Energy can be destroyed by friction.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Energy is conserved when an object falls: gravitational potential energy is converted to kinetic energy", with the total mechanical energy remaining constant (neglecting air resistance)."
    })
  },
  {
    id: "G10-PHY-EN-04",
    grade: "Grade 10",
    subject: "Physics",
    topic: "Energy",
    subtopic: "Work,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Work is done when a force causes an object to move. Which of the following is the formula for work done?,
      options: ["Work done = Force × distance moved in the direction of the force (W = Fd).",
        Work done = Force × time.",
        "Work done = Mass × acceleration.,
        Work done = Power × time."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Work done = Force × distance moved in the direction of the force (W = Fd).
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD PHYSICS SYLLABUS)
  // =========================================================================

  // --- MECHANICS ADVANCED (6 Materials) ---
  {
    id: G11-PHY-MC-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Mechanics Advanced,
    subtopic: "Kinematics",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kinematics describes motion without considering its causes. Which of the following equations of motion relates displacement, initial velocity, final velocity, and acceleration?,
      options: ["v² = u² + 2as is the equation of motion relating final velocity (v)", initial velocity (u), acceleration (a), and displacement (s).,
        s = ut + ½ at² relates time and displacement.",
        v = u + at relates velocity and time.",
        "F = ma relates force and acceleration.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "v² = u² + 2as is the equation of motion relating final velocity (v)", initial velocity (u), acceleration (a), and displacement (s)."
    })
  },
  {
    id: "G11-PHY-MC-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Mechanics Advanced",
    subtopic: "Dynamics,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Dynamics deals with the relationship between motion and forces. Which of the following correctly states the principle of conservation of momentum?,
      options: ["The principle of conservation of momentum states that the total momentum of a closed system remains constant if no external forces act on it.",
        Momentum is always conserved in all collisions.",
        "Momentum is the same as energy.,
        Momentum can be created and destroyed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The principle of conservation of momentum states that the total momentum of a closed system remains constant if no external forces act on it.
    })
  },
  {
    id: G11-PHY-MC-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Mechanics Advanced,
    subtopic: "Circular Motion",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Circular motion involves motion along a circular path. Which of the following is the centripetal acceleration formula for an object moving in a circle of radius r with speed v?,
      options: ["Centripetal acceleration (a) = v²/r", where v is the speed and r is the radius of the circular path.,
        Centripetal acceleration = v/r.",
        Centripetal acceleration = mv²/r.",
        "Centripetal acceleration = ωr.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Centripetal acceleration (a) = v²/r", where v is the speed and r is the radius of the circular path."
    })
  },
  {
    id: "G11-PHY-MC-04",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Mechanics Advanced",
    subtopic: "Gravitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Newton's law of universal gravitation describes the force between two masses. Which of the following is the formula for the gravitational force between two masses?,
      options: ["F = G(m₁m₂)/r²", where G is the gravitational constant, m₁ and m₂ are the masses, and r is the distance between them.,
        F = Gm₁m₂r².",
        "F = GM/r².,
        F = mg."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "F = G(m₁m₂)/r², where G is the gravitational constant, m₁ and m₂ are the masses, and r is the distance between them.
    })
  },
  {
    id: G11-PHY-MC-05",
    grade: "Grade 11,
    subject: Physics",
    topic: "Mechanics Advanced,
    subtopic: "Projectile Motion",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Projectile motion is the motion of an object projected into the air. Which of the following is true about the horizontal component of projectile motion?,
      options: ["The horizontal component of projectile motion has constant velocity (no acceleration) if we neglect air resistance", because there is no horizontal force acting on the projectile.,
        The horizontal component accelerates due to gravity.",
        The horizontal component is zero.",
        "The horizontal component decreases with time.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The horizontal component of projectile motion has constant velocity (no acceleration) if we neglect air resistance", because there is no horizontal force acting on the projectile."
    })
  },
  {
    id: "G11-PHY-MC-06",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Mechanics Advanced",
    subtopic: "Friction,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Friction is a force that opposes motion between surfaces in contact. Which of the following is true about static friction?,
      options: ["Static friction is the force that must be overcome to start moving an object at rest", and it is generally greater than kinetic friction.,
        Static friction is less than kinetic friction.",
        "Static friction only exists in liquids.,
        Static friction is the same as rolling friction."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Static friction is the force that must be overcome to start moving an object at rest, and it is generally greater than kinetic friction.
    })
  },

  // --- WORK, ENERGY, AND POWER (5 Materials) ---
  {
    id: G11-PHY-WE-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Work, Energy, and Power,
    subtopic: "Work-Energy Theorem",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The work-energy theorem relates the work done on an object to its change in kinetic energy. Which of the following is the work-energy theorem?,
      options: ["The work-energy theorem states that the net work done on an object equals the change in its kinetic energy (W_net = ΔKE).",
        The work-energy theorem states that work done equals force times distance.",
        The work-energy theorem states that energy is always conserved.",
        "The work-energy theorem states that work done is always zero.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The work-energy theorem states that the net work done on an object equals the change in its kinetic energy (W_net = ΔKE)."
    })
  },
  {
    id: "G11-PHY-WE-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Work", Energy, and Power",
    subtopic: "Power,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Power is the rate at which work is done or energy is transferred. Which of the following is the SI unit for power?,
      options: ["The SI unit for power is the watt (W)", which is defined as one joule per second (1 W = 1 J/s).,
        The SI unit for power is the joule (J).",
        "The SI unit for power is the newton (N).,
        The SI unit for power is the horsepower (hp)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for power is the watt (W), which is defined as one joule per second (1 W = 1 J/s).
    })
  },
  {
    id: G11-PHY-WE-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Work, Energy, and Power,
    subtopic: "Efficiency",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Efficiency is a measure of how well a machine or device uses energy. Which of the following is the formula for efficiency?,
      options: ["Efficiency = (useful output energy / input energy) × 100%", or (useful power output / power input) × 100%.,
        Efficiency = input energy - output energy.",
        Efficiency = output energy / time.",
        "Efficiency is always 100%.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Efficiency = (useful output energy / input energy) × 100%", or (useful power output / power input) × 100%."
    })
  },
  {
    id: "G11-PHY-WE-04",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Work", Energy, and Power",
    subtopic: "Energy Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "In a closed system, mechanical energy is conserved when only conservative forces act. Which of the following is an example of a conservative force?,
      options: ["Gravitational force is a conservative force because the work done by gravity depends only on the initial and final positions", not the path taken.",
        Friction is a conservative force.",
        "Air resistance is a conservative force.,
        No forces are conservative."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gravitational force is a conservative force because the work done by gravity depends only on the initial and final positions, not the path taken.
    })
  },
  {
    id: G11-PHY-WE-05",
    grade: "Grade 11,
    subject: Physics",
    topic: "Work, Energy, and Power,
    subtopic: "Kinetic Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kinetic energy depends on mass and velocity. If the velocity of an object is doubled, by what factor does its kinetic energy increase?,
      options: ["Kinetic energy is proportional to v²", so if velocity is doubled, kinetic energy increases by a factor of 4.,
        Kinetic energy increases by a factor of 2.",
        Kinetic energy increases by a factor of 8.",
        "Kinetic energy does not change.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kinetic energy is proportional to v²", so if velocity is doubled, kinetic energy increases by a factor of 4."
    })
  },

  // --- PROPERTIES OF MATTER (4 Materials) ---
  {
    id: "G11-PHY-PM-01",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Properties of Matter",
    subtopic: "Density,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Density is mass per unit volume. Which of the following is the formula for density?,
      options: ["Density (ρ) = mass / volume (m/V).",
        Density = volume / mass.",
        "Density = mass × volume.,
        Density = mass × acceleration."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Density (ρ) = mass / volume (m/V).
    })
  },
  {
    id: G11-PHY-PM-02",
    grade: "Grade 11,
    subject: Physics",
    topic: "Properties of Matter,
    subtopic: "Elasticity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Elasticity is the ability of a material to return to its original shape after deformation. Which of the following is the definition of Young's modulus?,
      options: ["Young's modulus is the ratio of stress (force per unit area) to strain (relative change in length)", measuring the stiffness of a material.,
        Young's modulus is the ratio of strain to stress.",
        Young's modulus measures the density of a material.",
        "Young's modulus measures the temperature of a material.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Young's modulus is the ratio of stress (force per unit area) to strain (relative change in length)", measuring the stiffness of a material."
    })
  },
  {
    id: "G11-PHY-PM-03",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Properties of Matter",
    subtopic: "Pressure,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Pressure is force per unit area. Which of the following is the SI unit for pressure?,
      options: ["The SI unit for pressure is the pascal (Pa)", which is defined as one newton per square meter (1 Pa = 1 N/m²).,
        The SI unit for pressure is the newton (N).",
        "The SI unit for pressure is the joule (J).,
        The SI unit for pressure is the bar (bar)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The SI unit for pressure is the pascal (Pa), which is defined as one newton per square meter (1 Pa = 1 N/m²).
    })
  },
  {
    id: G11-PHY-PM-04",
    grade: "Grade 11,
    subject: Physics",
    topic: "Properties of Matter,
    subtopic: "Fluid Pressure",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Fluid pressure increases with depth. Which of the following is the formula for pressure at a depth h in a fluid of density ρ?,
      options: ["Pressure (P) = ρgh", where ρ is the fluid density, g is the acceleration due to gravity, and h is the depth.,
        Pressure = ρgh².",
        Pressure = ρ/g h.",
        "Pressure = mg.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pressure (P) = ρgh", where ρ is the fluid density, g is the acceleration due to gravity, and h is the depth."
    })
  },

  // --- HEAT AND THERMODYNAMICS (5 Materials) ---
  {
    id: "G11-PHY-HT-01",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Heat and Thermodynamics",
    subtopic: "Heat Transfer,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Heat can be transferred through conduction, convection, or radiation. Which of the following describes convection?",
      options: [
        "Convection is the transfer of heat through the movement of fluids (liquids or gases) caused by density differences due to temperature changes.,
        Convection is the transfer of heat by electromagnetic waves.",
        "Convection is the transfer of heat through direct contact without material movement.,
        Convection occurs only in solids."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Convection is the transfer of heat through the movement of fluids (liquids or gases) caused by density differences due to temperature changes.
    })
  },
  {
    id: G11-PHY-HT-02",
    grade: "Grade 11,
    subject: Physics",
    topic: "Heat and Thermodynamics,
    subtopic: "Specific Heat Capacity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Specific heat capacity is the amount of heat required to raise the temperature of 1 kg of a substance by 1 K. Which of the following is the formula for heat energy?,
      options: ["Heat energy (Q) = mcΔT", where m is mass, c is specific heat capacity, and ΔT is the change in temperature.,
        Heat energy = mgh.",
        Heat energy = ½mv².",
        "Heat energy = Fd.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Heat energy (Q) = mcΔT", where m is mass, c is specific heat capacity, and ΔT is the change in temperature."
    })
  },
  {
    id: "G11-PHY-HT-03",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Heat and Thermodynamics",
    subtopic: "Latent Heat,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Latent heat is the heat required to change the state of a substance without changing its temperature. Which of the following is the formula for latent heat?,
      options: ["Latent heat (Q) = mL", where m is the mass and L is the specific latent heat of the substance.,
        Latent heat = mcΔT.",
        "Latent heat = mgh.,
        Latent heat = ½mv²."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Latent heat (Q) = mL, where m is the mass and L is the specific latent heat of the substance.
    })
  },
  {
    id: G11-PHY-HT-04",
    grade: "Grade 11,
    subject: Physics",
    topic: "Heat and Thermodynamics,
    subtopic: "Gas Laws",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Boyle's Law describes the relationship between pressure and volume of a gas at constant temperature. Which of the following is Boyle's Law?,
      options: ["Boyle's Law states that at constant temperature", the pressure of a gas is inversely proportional to its volume (P₁V₁ = P₂V₂).,
        Boyle's Law states that at constant pressure, volume is proportional to temperature.,
        Boyle's Law states that at constant volume", pressure is proportional to temperature.",
        "Boyle's Law states that PV = nRT.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Boyle's Law states that at constant temperature", the pressure of a gas is inversely proportional to its volume (P₁V₁ = P₂V₂)."
    })
  },
  {
    id: "G11-PHY-HT-05",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Heat and Thermodynamics",
    subtopic: "Thermodynamics Laws,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The first law of thermodynamics relates heat, work, and internal energy. Which of the following is the first law of thermodynamics?",
      options: [
        "The first law of thermodynamics states that the change in internal energy of a system equals the heat added to the system minus the work done by the system (ΔU = Q - W).,
        The first law states that energy can be created.",
        "The first law states that heat flows from cold to hot.,
        The first law states that entropy always increases."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The first law of thermodynamics states that the change in internal energy of a system equals the heat added to the system minus the work done by the system (ΔU = Q - W).
    })
  },

  // --- WAVE PHENOMENA (4 Materials) ---
  {
    id: G11-PHY-WP-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Wave Phenomena,
    subtopic: "Interference",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Interference occurs when two or more waves meet and superpose. Which of the following describes constructive interference?,
      options: ["Constructive interference occurs when two waves are in phase", meaning their crests and troughs align, resulting in a wave of increased amplitude.,
        Constructive interference occurs when waves are out of phase.",
        Constructive interference results in a wave of decreased amplitude.",
        "Constructive interference results in no wave at all.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructive interference occurs when two waves are in phase", meaning their crests and troughs align, resulting in a wave of increased amplitude."
    })
  },
  {
    id: "G11-PHY-WP-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Wave Phenomena",
    subtopic: "Diffraction,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Diffraction is the bending of waves around obstacles or through openings. Which of the following factors affects the amount of diffraction?,
      options: ["Diffraction is most noticeable when the size of the obstacle or opening is comparable to the wavelength of the wave.",
        Diffraction does not depend on wavelength.",
        "Diffraction is independent of the size of the obstacle.,
        Diffraction only occurs with light waves."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Diffraction is most noticeable when the size of the obstacle or opening is comparable to the wavelength of the wave.
    })
  },
  {
    id: G11-PHY-WP-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Wave Phenomena,
    subtopic: "Standing Waves",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Standing waves are formed by the interference of two waves traveling in opposite directions. Which of the following is a characteristic of standing waves?,
      options: ["Standing waves have nodes (points of no displacement) and antinodes (points of maximum displacement) that remain fixed in position.",
        Standing waves travel through the medium.",
        Standing waves have no nodes.",
        "Standing waves have no fixed pattern.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Standing waves have nodes (points of no displacement) and antinodes (points of maximum displacement) that remain fixed in position."
    })
  },
  {
    id: "G11-PHY-WP-04",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Wave Phenomena",
    subtopic: "Doppler Effect,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Doppler effect is the change in frequency of a wave due to relative motion between the source and observer. Which of the following is an example of the Doppler effect?,
      options: ["The Doppler effect is observed when a siren from an approaching ambulance sounds higher in pitch than when it is moving away from the observer.",
        The Doppler effect is the change in wave amplitude.",
        "The Doppler effect occurs only with light waves.,
        The Doppler effect does not change the observed frequency."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Doppler effect is observed when a siren from an approaching ambulance sounds higher in pitch than when it is moving away from the observer.
    })
  },

  // --- ELECTROSTATICS (4 Materials) ---
  {
    id: G11-PHY-ES-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Electrostatics,
    subtopic: "Electric Charge",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Electric charge is a fundamental property of matter. Which of the following describes the law of conservation of electric charge?,
      options: ["The law of conservation of charge states that the total electric charge in an isolated system is always conserved; charge can neither be created nor destroyed.",
        Charge can be created and destroyed.",
        Charge is always lost in interactions.",
        "Charge is always gained in interactions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The law of conservation of charge states that the total electric charge in an isolated system is always conserved; charge can neither be created nor destroyed."
    })
  },
  {
    id: "G11-PHY-ES-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Electrostatics",
    subtopic: "Coulomb's Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Coulomb's Law describes the force between two point charges. Which of the following is the formula for Coulomb's Law?,
      options: ["F = k(q₁q₂)/r²", where k is Coulomb's constant, q₁ and q₂ are the charges, and r is the distance between them.,
        F = kq/r².",
        "F = G(m₁m₂)/r².,
        F = qE."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "F = k(q₁q₂)/r², where k is Coulomb's constant, q₁ and q₂ are the charges, and r is the distance between them.
    })
  },
  {
    id: G11-PHY-ES-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Electrostatics,
    subtopic: "Electric Fields",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Electric fields are regions where electric forces act. Which of the following is the definition of electric field strength?,
      options: ["Electric field strength (E) is the force per unit positive charge (E = F/q).",
        Electric field strength is the same as voltage.",
        Electric field strength is measured in newtons.",
        "Electric field strength is force × charge.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Electric field strength (E) is the force per unit positive charge (E = F/q)."
    })
  },
  {
    id: "G11-PHY-ES-04",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Electrostatics",
    subtopic: "Capacitors,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Capacitors are devices that store electrical charge. Which of the following is the formula for capacitance?,
      options: ["Capacitance (C) = Q/V", where Q is the charge stored and V is the voltage across the capacitor.,
        Capacitance = V/Q.",
        "Capacitance = QV.,
        Capacitance = ½QV."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Capacitance (C) = Q/V, where Q is the charge stored and V is the voltage across the capacitor.
    })
  },

  // --- CURRENT ELECTRICITY (4 Materials) ---
  {
    id: G11-PHY-CE-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Current Electricity,
    subtopic: "Ohm's Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Ohm's Law describes the relationship between voltage, current, and resistance. If a circuit has a voltage of 12 V and a current of 2 A, what is the resistance?,
      options: ["Using V = IR", R = V/I = 12 V / 2 A = 6 Ω.,
        R = 24 Ω.",
        R = 14 Ω.",
        "R = 10 Ω.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using V = IR", R = V/I = 12 V / 2 A = 6 Ω."
    })
  },
  {
    id: "G11-PHY-CE-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Current Electricity",
    subtopic: "Electrical Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Electrical energy is the work done by electric current. Which of the following is the formula for electrical energy?,
      options: ["Electrical energy (E) = VIt", where V is voltage, I is current, and t is time.,
        Electrical energy = IRt.",
        "Electrical energy = V²Rt.,
        Electrical energy = Pt."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Electrical energy (E) = VIt, where V is voltage, I is current, and t is time.
    })
  },
  {
    id: G11-PHY-CE-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Current Electricity,
    subtopic: "Resistors in Series",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Resistors can be connected in series or parallel. How is total resistance calculated for resistors connected in series?,
      options: ["For resistors in series", the total resistance is the sum of the individual resistances (R_total = R₁ + R₂ + R₃ + ...).,
        For resistors in series, total resistance is the reciprocal of the sum of reciprocals.,
        For resistors in series", total resistance is always less than the smallest resistor.",
        "For resistors in series, total resistance is zero.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "For resistors in series", the total resistance is the sum of the individual resistances (R_total = R₁ + R₂ + R₃ + ...)."
    })
  },
  {
    id: "G11-PHY-CE-04",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Current Electricity",
    subtopic: "Resistors in Parallel,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "For resistors connected in parallel, how is the total resistance calculated?,
      options: ["For resistors in parallel", the total resistance is calculated using: 1/R_total = 1/R₁ + 1/R₂ + 1/R₃ + ...,
        For resistors in parallel", total resistance is the sum of the individual resistances.",
        "For resistors in parallel, total resistance is always greater than the largest resistor.,
        For resistors in parallel, total resistance is zero."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "For resistors in parallel, the total resistance is calculated using: 1/R_total = 1/R₁ + 1/R₂ + 1/R₃ + ...
    })
  },

  // --- ELECTROMAGNETISM (3 Materials) ---
  {
    id: G11-PHY-EM-01",
    grade: "Grade 11,
    subject: Physics",
    topic: "Electromagnetism,
    subtopic: "Magnetic Fields",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Magnetic fields are produced by moving charges. Which of the following is the right-hand rule for determining the direction of the magnetic field around a current-carrying conductor?,
      options: ["The right-hand rule states that if you point your right thumb in the direction of the current", your fingers curl in the direction of the magnetic field around the conductor.,
        The right-hand rule states that the magnetic field is parallel to the current.",
        The right-hand rule states that the magnetic field is perpendicular to the current.",
        "The right-hand rule states that there is no magnetic field.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The right-hand rule states that if you point your right thumb in the direction of the current", your fingers curl in the direction of the magnetic field around the conductor."
    })
  },
  {
    id: "G11-PHY-EM-02",
    grade: "Grade 11",
    subject: "Physics",
    topic: "Electromagnetism",
    subtopic: "Electromagnetic Induction,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Electromagnetic induction is the process of generating an electric current from a changing magnetic field. Which of the following is the formula for the induced emf according to Faraday's Law?,
      options: ["Faraday's Law states that the induced emf (ε) = -N(ΔΦ/Δt)", where N is the number of turns, Φ is the magnetic flux, and t is time.,
        Faraday's Law states that emf = BIL.",
        "Faraday's Law states that emf = IR.,
        Faraday's Law states that emf = VIt."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Faraday's Law states that the induced emf (ε) = -N(ΔΦ/Δt), where N is the number of turns, Φ is the magnetic flux, and t is time.
    })
  },
  {
    id: G11-PHY-EM-03",
    grade: "Grade 11,
    subject: Physics",
    topic: "Electromagnetism,
    subtopic: "Applications",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Electromagnetic induction has numerous practical applications. Which of the following is a device that uses electromagnetic induction?,
      options: ["A generator uses electromagnetic induction to convert mechanical energy into electrical energy by rotating a coil in a magnetic field.",
        A motor uses electromagnetic induction to convert electrical energy into mechanical energy.",
        A transformer uses electromagnetic induction to change voltage.",
        "All of the above are correct.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A generator uses electromagnetic induction to convert mechanical energy into electrical energy by rotating a coil in a magnetic field."
    })
  }`nexport const physicsTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD PHYSICS SYLLABUS)
  // =========================================================================

  // --- ADVANCED MECHANICS (5 Materials) ---
  {
    id: "G12-PHY-AM-01",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Advanced Mechanics",
    subtopic: "Rotational Dynamics,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Rotational dynamics deals with the motion of objects rotating about an axis. Which of the following is the formula for torque (moment of force)?,
      options: ["Torque (τ) = rF sinθ", where r is the perpendicular distance from the axis of rotation to the line of action of the force, F is the force, and θ is the angle between r and F.,
        Torque = Fr².",
        "Torque = Iα.,
        Torque = ½Iω²."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Torque (τ) = rF sinθ, where r is the perpendicular distance from the axis of rotation to the line of action of the force, F is the force, and θ is the angle between r and F.
    })
  },
  {
    id: G12-PHY-AM-02",
    grade: "Grade 12,
    subject: Physics",
    topic: "Advanced Mechanics,
    subtopic: "Angular Momentum",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Angular momentum is the rotational analog of linear momentum. Which of the following is the formula for angular momentum?,
      options: ["Angular momentum (L) = Iω", where I is the moment of inertia and ω is the angular velocity.,
        Angular momentum = mv.",
        Angular momentum = rF.",
        "Angular momentum = ½Iω².
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Angular momentum (L) = Iω", where I is the moment of inertia and ω is the angular velocity."
    })
  },
  {
    id: "G12-PHY-AM-03",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Advanced Mechanics",
    subtopic: "Simple Harmonic Motion,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Simple harmonic motion (SHM) is a type of periodic motion where the restoring force is proportional to displacement. Which of the following is the equation for the period of a simple pendulum?,
      options: ["The period of a simple pendulum is T = 2π√(L/g)", where L is the length of the pendulum and g is the acceleration due to gravity.,
        T = 2π√(g/L).",
        "T = 2π√(m/k).,
        T = 2π√(I/mgd)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The period of a simple pendulum is T = 2π√(L/g), where L is the length of the pendulum and g is the acceleration due to gravity.
    })
  },
  {
    id: G12-PHY-AM-04",
    grade: "Grade 12,
    subject: Physics",
    topic: "Advanced Mechanics,
    subtopic: "Gravitation",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Gravitational fields describe the force per unit mass at a point in space. Which of the following is the formula for gravitational field strength?,
      options: ["Gravitational field strength (g) = GM/r²", where G is the gravitational constant, M is the mass of the object creating the field, and r is the distance from its center.,
        g = GM/r.",
        g = F/m.",
        "g = mgh.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gravitational field strength (g) = GM/r²", where G is the gravitational constant, M is the mass of the object creating the field, and r is the distance from its center."
    })
  },
  {
    id: "G12-PHY-AM-05",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Advanced Mechanics",
    subtopic: "Orbital Motion,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Orbital motion describes the motion of objects in orbit due to gravitational forces. Which of the following is Kepler's Third Law of planetary motion?,
      options: ["Kepler's Third Law states that the square of the orbital period (T²) is proportional to the cube of the semi-major axis (r³) of the orbit: T² ∝ r³.",
        Kepler's Third Law states that planets move in elliptical orbits.",
        "Kepler's Third Law states that planets sweep out equal areas in equal times.,
        Kepler's Third Law states that all planets have the same orbital period."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kepler's Third Law states that the square of the orbital period (T²) is proportional to the cube of the semi-major axis (r³) of the orbit: T² ∝ r³.
    })
  },

  // --- MODERN PHYSICS (5 Materials) ---
  {
    id: G12-PHY-MP-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Modern Physics,
    subtopic: "Quantum Theory",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Quantum theory describes the behavior of matter and energy at the atomic and subatomic level. Which of the following is Planck's quantum hypothesis?,
      options: ["Planck's quantum hypothesis states that energy is emitted or absorbed in discrete packets called quanta", with E = hf, where h is Planck's constant and f is the frequency.,
        Planck's hypothesis states that energy is continuous.",
        Planck's hypothesis states that E = mc².",
        "Planck's hypothesis states that energy is always conserved.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Planck's quantum hypothesis states that energy is emitted or absorbed in discrete packets called quanta", with E = hf, where h is Planck's constant and f is the frequency."
    })
  },
  {
    id: "G12-PHY-MP-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Modern Physics",
    subtopic: "Photoelectric Effect,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The photoelectric effect is the emission of electrons from a metal when light shines on it. Which of the following is Einstein's photoelectric equation?,
      options: ["Einstein's photoelectric equation: K_max = hf - φ", where K_max is the maximum kinetic energy of the emitted electrons, hf is the photon energy, and φ is the work function of the metal.,
        K_max = ½mv².",
        "K_max = hf + φ.,
        K_max = φ - hf."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Einstein's photoelectric equation: K_max = hf - φ, where K_max is the maximum kinetic energy of the emitted electrons, hf is the photon energy, and φ is the work function of the metal.
    })
  },
  {
    id: G12-PHY-MP-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Modern Physics,
    subtopic: "Wave-Particle Duality",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Wave-particle duality is the concept that particles can exhibit both wave-like and particle-like properties. Which of the following is the de Broglie wavelength equation?,
      options: ["The de Broglie wavelength (λ) = h/p = h/(mv)", where h is Planck's constant, p is momentum, m is mass, and v is velocity.,
        λ = h/m.",
        λ = hf.",
        "λ = c/f.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The de Broglie wavelength (λ) = h/p = h/(mv)", where h is Planck's constant, p is momentum, m is mass, and v is velocity."
    })
  },
  {
    id: "G12-PHY-MP-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Modern Physics",
    subtopic: "Atomic Structure,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Bohr model describes the structure of the hydrogen atom. Which of the following is the formula for the energy levels of the hydrogen atom according to Bohr?,
      options: ["According to Bohr", the energy levels of hydrogen are E_n = -13.6/n² eV, where n is the principal quantum number (n = 1, 2, 3, ...).,
        E_n = -13.6/n eV.",
        "E_n = 13.6/n² eV.,
        E_n = -13.6n² eV."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "According to Bohr, the energy levels of hydrogen are E_n = -13.6/n² eV, where n is the principal quantum number (n = 1, 2, 3, ...).
    })
  },
  {
    id: G12-PHY-MP-05",
    grade: "Grade 12,
    subject: Physics",
    topic: "Modern Physics,
    subtopic: "Mass-Energy Equivalence",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Mass-energy equivalence is a key concept in modern physics. Which of the following is Einstein's mass-energy equivalence formula?,
      options: ["Einstein's mass-energy equivalence: E = mc²", where E is energy, m is mass, and c is the speed of light in a vacuum (3 × 10⁸ m/s).,
        E = ½mc².",
        E = mgh.",
        "E = hf.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Einstein's mass-energy equivalence: E = mc²", where E is energy, m is mass, and c is the speed of light in a vacuum (3 × 10⁸ m/s)."
    })
  },

  // --- ELECTROMAGNETISM (5 Materials) ---
  {
    id: "G12-PHY-EM-01",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Electromagnetism",
    subtopic: "Magnetic Fields,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Magnetic fields are produced by moving charges and can exert forces on other moving charges. Which of the following is the formula for the magnetic force on a current-carrying conductor?,
      options: ["The magnetic force on a current-carrying conductor is F = BIL sinθ", where B is the magnetic flux density, I is the current, L is the length of the conductor, and θ is the angle between the conductor and the magnetic field.,
        F = BIL cosθ.",
        "F = BIL.,
        F = B/LI."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The magnetic force on a current-carrying conductor is F = BIL sinθ, where B is the magnetic flux density, I is the current, L is the length of the conductor, and θ is the angle between the conductor and the magnetic field.
    })
  },
  {
    id: G12-PHY-EM-02",
    grade: "Grade 12,
    subject: Physics",
    topic: "Electromagnetism,
    subtopic: "Electromagnetic Induction",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Electromagnetic induction is the process of generating an electric current from a changing magnetic field. Which of the following is Faraday's Law of electromagnetic induction?,
      options: ["Faraday's Law states that the induced electromotive force (emf) is equal to the negative rate of change of magnetic flux through a circuit: ε = -N(ΔΦ/Δt).",
        ε = -NΦ/t.",
        ε = Bvl.",
        "ε = L(dI/dt).
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Faraday's Law states that the induced electromotive force (emf) is equal to the negative rate of change of magnetic flux through a circuit: ε = -N(ΔΦ/Δt)."
    })
  },
  {
    id: "G12-PHY-EM-03",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Electromagnetism",
    subtopic: "Transformers,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Transformers are devices that change the voltage of alternating current. Which of the following is the formula for the relationship between input and output voltage in a transformer?,
      options: ["For a transformer", V_p/V_s = N_p/N_s, where V_p and V_s are the primary and secondary voltages, and N_p and N_s are the number of turns in the primary and secondary coils.,
        V_p/V_s = N_s/N_p.",
        "V_p/V_s = I_p/I_s.,
        V_p/V_s = N_p × N_s."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "For a transformer, V_p/V_s = N_p/N_s, where V_p and V_s are the primary and secondary voltages, and N_p and N_s are the number of turns in the primary and secondary coils.
    })
  },
  {
    id: G12-PHY-EM-04",
    grade: "Grade 12,
    subject: Physics",
    topic: "Electromagnetism,
    subtopic: "AC Circuits",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Alternating current (AC) circuits involve sinusoidal voltages and currents. Which of the following is the root mean square (RMS) value of an AC voltage?,
      options: ["The RMS voltage (V_rms) = V_peak/√2", where V_peak is the maximum (peak) voltage of the AC signal.,
        V_rms = V_peak × √2.",
        V_rms = V_peak/2.",
        "V_rms = V_peak.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The RMS voltage (V_rms) = V_peak/√2", where V_peak is the maximum (peak) voltage of the AC signal."
    })
  },
  {
    id: "G12-PHY-EM-05",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Electromagnetism",
    subtopic: "LC Circuits,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "LC circuits consist of an inductor and a capacitor and can oscillate at a resonant frequency. Which of the following is the formula for the resonant frequency of an LC circuit?,
      options: ["The resonant frequency of an LC circuit is f = 1/(2π√(LC))", where L is the inductance and C is the capacitance.,
        f = 2π√(LC).",
        "f = √(LC).,
        f = 1/(2πLC)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The resonant frequency of an LC circuit is f = 1/(2π√(LC)), where L is the inductance and C is the capacitance.
    })
  },

  // --- THERMODYNAMICS (4 Materials) ---
  {
    id: G12-PHY-TH-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Thermodynamics,
    subtopic: "Laws of Thermodynamics",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The laws of thermodynamics govern the behavior of energy and heat in systems. Which of the following is the Second Law of Thermodynamics?,
      options: ["The Second Law of Thermodynamics states that the entropy of an isolated system always increases over time", and heat flows from hot to cold spontaneously.,
        The Second Law states that energy is conserved.",
        The Second Law states that no heat engine can be 100% efficient.",
        "The Second Law states that entropy always decreases.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Second Law of Thermodynamics states that the entropy of an isolated system always increases over time", and heat flows from hot to cold spontaneously."
    })
  },
  {
    id: "G12-PHY-TH-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Thermodynamics",
    subtopic: "Heat Engines,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Heat engines convert thermal energy into mechanical work. Which of the following is the formula for the efficiency of a Carnot engine?,
      options: ["The efficiency of a Carnot engine is η = 1 - (T_c/T_h)", where T_c is the temperature of the cold reservoir and T_h is the temperature of the hot reservoir (both in kelvin).,
        η = T_h/T_c.",
        "η = 1 + (T_c/T_h).,
        η = (T_h - T_c)/T_c."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The efficiency of a Carnot engine is η = 1 - (T_c/T_h), where T_c is the temperature of the cold reservoir and T_h is the temperature of the hot reservoir (both in kelvin).
    })
  },
  {
    id: G12-PHY-TH-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Thermodynamics,
    subtopic: "Entropy",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Entropy is a measure of the disorder or randomness of a system. Which of the following is the formula for the change in entropy?,
      options: ["The change in entropy (ΔS) = Q_rev/T", where Q_rev is the heat transferred reversibly and T is the absolute temperature.,
        ΔS = Q/T².",
        ΔS = T/Q.",
        "ΔS = k ln W.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The change in entropy (ΔS) = Q_rev/T", where Q_rev is the heat transferred reversibly and T is the absolute temperature."
    })
  },
  {
    id: "G12-PHY-TH-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Thermodynamics",
    subtopic: "Refrigerators and Heat Pumps,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Refrigerators and heat pumps transfer heat from a cold region to a hot region using work input. Which of the following is the coefficient of performance (COP) for a refrigerator?,
      options: ["The coefficient of performance for a refrigerator is COP = Q_c/W", where Q_c is the heat removed from the cold reservoir and W is the work input.,
        COP = Q_h/W.",
        "COP = Q_h/Q_c.,
        COP = W/Q_c."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The coefficient of performance for a refrigerator is COP = Q_c/W, where Q_c is the heat removed from the cold reservoir and W is the work input.
    })
  },

  // --- WAVE OPTICS (4 Materials) ---
  {
    id: G12-PHY-WO-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Wave Optics,
    subtopic: "Interference",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Interference of light occurs when two coherent light waves superimpose. Which of the following is the condition for constructive interference in Young's double-slit experiment?,
      options: ["Constructive interference occurs when the path difference between the two waves is an integer multiple of the wavelength: d sinθ = nλ", where n = 0, 1, 2, ...,
        d sinθ = (n + ½)λ.",
        d sinθ = nλ/2.",
        "d sinθ = 2nλ.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructive interference occurs when the path difference between the two waves is an integer multiple of the wavelength: d sinθ = nλ", where n = 0, 1, 2, ..."
    })
  },
  {
    id: "G12-PHY-WO-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Wave Optics",
    subtopic: "Diffraction,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Diffraction is the bending of waves around obstacles. Which of the following is the condition for the first minimum in single-slit diffraction?,
      options: ["The first minimum in single-slit diffraction occurs when a sinθ = λ", where a is the width of the slit and θ is the angle from the center.,
        a sinθ = λ/2.",
        "a sinθ = 2λ.,
        a sinθ = 3λ/2."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The first minimum in single-slit diffraction occurs when a sinθ = λ, where a is the width of the slit and θ is the angle from the center.
    })
  },
  {
    id: G12-PHY-WO-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Wave Optics,
    subtopic: "Diffraction Grating",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " A diffraction grating consists of many parallel slits and produces sharp interference patterns. Which of the following is the grating equation?,
      options: ["The grating equation is d sinθ = nλ", where d is the distance between slits, θ is the angle of diffraction, n is the order (0, 1, 2, ...), and λ is the wavelength.,
        d sinθ = (n + ½)λ.",
        d sinθ = nλ/2.",
        "d cosθ = nλ.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The grating equation is d sinθ = nλ", where d is the distance between slits, θ is the angle of diffraction, n is the order (0, 1, 2, ...), and λ is the wavelength."
    })
  },
  {
    id: "G12-PHY-WO-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Wave Optics",
    subtopic: "Polarization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Polarization is the phenomenon where light waves vibrate in a particular direction. Which of the following describes Malus's Law for polarized light?,
      options: ["Malus's Law states that when polarized light passes through a polarizer", the transmitted intensity is I = I₀ cos²θ, where I₀ is the incident intensity and θ is the angle between the light's polarization direction and the polarizer's axis.,
        I = I₀ cosθ.",
        "I = I₀ sin²θ.,
        I = I₀ tanθ."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Malus's Law states that when polarized light passes through a polarizer, the transmitted intensity is I = I₀ cos²θ, where I₀ is the incident intensity and θ is the angle between the light's polarization direction and the polarizer's axis.
    })
  },

  // --- GEOMETRICAL OPTICS (4 Materials) ---
  {
    id: G12-PHY-GO-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Geometrical Optics,
    subtopic: "Lens Formula",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The lens formula relates the object distance, image distance, and focal length of a lens. Which of the following is the lens formula?,
      options: ["The lens formula is 1/f = 1/v + 1/u", where f is the focal length, v is the image distance, and u is the object distance (using the sign convention).,
        1/f = 1/v - 1/u.",
        1/f = v + u.",
        "f = uv/(u+v).
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The lens formula is 1/f = 1/v + 1/u", where f is the focal length, v is the image distance, and u is the object distance (using the sign convention)."
    })
  },
  {
    id: "G12-PHY-GO-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Geometrical Optics",
    subtopic: "Mirror Formula,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The mirror formula relates the object distance, image distance, and focal length of a spherical mirror. Which of the following is the mirror formula?",
      options: ["The mirror formula is 1/f = 1/v + 1/u, where f is the focal length, v is the image distance, and u is the object distance", "following the sign convention.",
        1/f = 1/v - 1/u.",
        "1/f = v + u.,
        f = uv/(u+v)."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The mirror formula is 1/f = 1/v + 1/u, where f is the focal length, v is the image distance, and u is the object distance, following the sign convention.
    })
  },
  {
    id: G12-PHY-GO-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Geometrical Optics,
    subtopic: "Optical Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Optical instruments use lenses and mirrors to form images. Which of the following is the formula for the magnifying power of a simple microscope?,
      options: ["The magnifying power of a simple microscope is M = 1 + D/f", where D is the near point distance (25 cm) and f is the focal length of the lens.,
        M = D/f.",
        M = f/D.",
        "M = 1 - D/f.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The magnifying power of a simple microscope is M = 1 + D/f", where D is the near point distance (25 cm) and f is the focal length of the lens."
    })
  },
  {
    id: "G12-PHY-GO-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Geometrical Optics",
    subtopic: "Aberrations,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Aberrations are defects in images formed by lenses or mirrors. Which of the following describes chromatic aberration?,
      options: ["Chromatic aberration occurs when different wavelengths of light are refracted differently by a lens", causing colored fringes around images. It is corrected using achromatic doublets or using a combination of lenses.,
        Chromatic aberration is caused by spherical surfaces.",
        "Chromatic aberration affects only mirrors.,
        Chromatic aberration cannot be corrected."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chromatic aberration occurs when different wavelengths of light are refracted differently by a lens, causing colored fringes around images. It is corrected using achromatic doublets or using a combination of lenses.
    })
  },

  // --- SEMICONDUCTOR PHYSICS (4 Materials) ---
  {
    id: G12-PHY-SP-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Semiconductor Physics,
    subtopic: "Semiconductors",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Semiconductors are materials with electrical conductivity between conductors and insulators. Which of the following is an intrinsic semiconductor?,
      options: ["Pure silicon and pure germanium are intrinsic semiconductors", with electrical conductivity that increases with temperature due to thermal excitation of electrons across the band gap.,
        Doped silicon is an intrinsic semiconductor.",
        Metals are intrinsic semiconductors.",
        "Pure silicon is an insulator.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pure silicon and pure germanium are intrinsic semiconductors", with electrical conductivity that increases with temperature due to thermal excitation of electrons across the band gap."
    })
  },
  {
    id: "G12-PHY-SP-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Semiconductor Physics",
    subtopic: "Diodes,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A p-n junction diode is a semiconductor device that allows current to flow in only one direction. Which of the following describes the forward bias condition of a diode?,
      options: ["In forward bias", the p-side is connected to the positive terminal and the n-side to the negative terminal, reducing the depletion region and allowing current to flow through the diode.,
        In forward bias, the diode blocks current flow.",
        "In forward bias, the depletion region widens.,
        In forward bias, no current flows."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In forward bias, the p-side is connected to the positive terminal and the n-side to the negative terminal, reducing the depletion region and allowing current to flow through the diode.
    })
  },
  {
    id: G12-PHY-SP-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Semiconductor Physics,
    subtopic: "Transistors",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Transistors are semiconductor devices used for amplification and switching. Which of the following describes the function of a bipolar junction transistor (BJT)?,
      options: ["A BJT has three regions: emitter", base, and collector. A small current at the base terminal controls a much larger current between the emitter and collector, allowing amplification.,
        A BJT has only two terminals.",
        A BJT cannot amplify signals.",
        "A BJT is only used as a switch.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A BJT has three regions: emitter", base, and collector. A small current at the base terminal controls a much larger current between the emitter and collector, allowing amplification."
    })
  },
  {
    id: "G12-PHY-SP-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Semiconductor Physics",
    subtopic: "Operational Amplifiers,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Operational amplifiers (op-amps) are versatile integrated circuits used in many electronic applications. Which of the following is a characteristic of an ideal op-amp?,
      options: ["An ideal op-amp has infinite voltage gain", infinite input impedance, zero output impedance, and infinite bandwidth.,
        An ideal op-amp has zero voltage gain.",
        "An ideal op-amp has very high output impedance.,
        An ideal op-amp has limited bandwidth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An ideal op-amp has infinite voltage gain, infinite input impedance, zero output impedance, and infinite bandwidth.
    })
  },

  // --- RADIOACTIVITY AND NUCLEAR PHYSICS (4 Materials) ---
  {
    id: G12-PHY-RN-01",
    grade: "Grade 12,
    subject: Physics",
    topic: "Radioactivity and Nuclear Physics,
    subtopic: "Radioactive Decay",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Radioactive decay is the spontaneous disintegration of unstable atomic nuclei. Which of the following types of radiation consists of helium nuclei?,
      options: ["Alpha radiation consists of helium nuclei (2 protons and 2 neutrons)", has the highest ionizing power, and is stopped by a sheet of paper.,
        Beta radiation consists of helium nuclei.",
        Gamma radiation consists of helium nuclei.",
        "Alpha radiation is a type of electromagnetic radiation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Alpha radiation consists of helium nuclei (2 protons and 2 neutrons)", has the highest ionizing power, and is stopped by a sheet of paper."
    })
  },
  {
    id: "G12-PHY-RN-02",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Radioactivity and Nuclear Physics",
    subtopic: "Half-Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Half-life is the time taken for half of the radioactive nuclei in a sample to decay. If a radioactive isotope has a half-life of 10 years, what fraction of the original sample remains after 30 years?,
      options: ["After 30 years (3 half-lives)", the remaining fraction is (½)³ = 1/8 of the original amount.",
        1/4 of the original amount.",
        "1/2 of the original amount.,
        1/16 of the original amount."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "After 30 years (3 half-lives), the remaining fraction is (½)³ = 1/8 of the original amount.
    })
  },
  {
    id: G12-PHY-RN-03",
    grade: "Grade 12,
    subject: Physics",
    topic: "Radioactivity and Nuclear Physics,
    subtopic: "Nuclear Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Nuclear reactions involve changes in the nucleus of an atom. Which of the following describes nuclear fission?,
      options: ["Nuclear fission is the splitting of a heavy nucleus into two smaller nuclei", releasing a large amount of energy and neutrons, as seen in nuclear reactors.,
        Nuclear fission is the combining of two light nuclei.",
        Nuclear fission produces only alpha particles.",
        "Nuclear fission is a spontaneous process.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nuclear fission is the splitting of a heavy nucleus into two smaller nuclei", releasing a large amount of energy and neutrons, as seen in nuclear reactors."
    })
  },
  {
    id: "G12-PHY-RN-04",
    grade: "Grade 12",
    subject: "Physics",
    topic: "Radioactivity and Nuclear Physics",
    subtopic: "Nuclear Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Nuclear energy is released from nuclear reactions. Which of the following is a benefit of using nuclear energy for electricity generation?,
      options: ["Nuclear energy produces a large amount of energy from a small amount of fuel", produces low greenhouse gas emissions during operation, and provides reliable base-load power.,
        Nuclear energy produces high greenhouse gas emissions.",
        "Nuclear energy is available in unlimited supply.,
        Nuclear energy has no environmental risks."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nuclear energy produces a large amount of energy from a small amount of fuel, produces low greenhouse gas emissions during operation, and provides reliable base-load power."
    })
  }

];


