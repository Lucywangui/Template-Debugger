export const fasihiKiswahiliTemplates: TemplateRule[] = [
  // =========================================================================
  // DARASA LA 10: 35 MATERIALS (KICD FASIHI YA KISWAHILI)
  // =========================================================================

  // --- MADA: AINA ZA FASIHI (4 Materials) ---
  {
    id: "G10-FAS-ANA-01",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Aina za Fasihi",
    subtopic: "Fasihi Simulizi na Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Fasihi ya Kiswahili imegawanywa katika makundi mawili makuu: fasihi simulizi na fasihi andishi. Ni ipi kati ya hizi ni fasihi simulizi?,
      options: [Ngano, Riwaya, "Tamthilia, Ushairi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ngano"
    })
  },
  {
    id: G10-FAS-ANA-02",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Aina za Fasihi,
    subtopic: "Fasihi Simulizi na Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi andishi ni fasihi inayopatikana kwa maandishi. Ni ipi kati ya hizi ni mfano wa fasihi andishi?,
      options: [Riwaya, Ngano, Methali", "Vitendawili].sort(() => Math.random() - 0.5),
      correctAnswer: Riwaya"
    })
  },
  {
    id: "G10-FAS-ANA-03",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Aina za Fasihi",
    subtopic: "Fasihi Simulizi na Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Fasihi simulizi hupitishwa kwa mdomo kutoka kizazi kimoja hadi kingine. Ni kipi kati ya hivi ni sifa ya fasihi simulizi?,
      options: [Haina mwandishi maalum., Ina mwandishi mmoja., "Inachapishwa., Ina tarehe ya kuchapishwa."].sort(() => Math.random() - 0.5),
      correctAnswer: "Haina mwandishi maalum.
    })
  },
  {
    id: G10-FAS-ANA-04",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Aina za Fasihi,
    subtopic: "Fasihi Simulizi na Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi andishi ina mwandishi maalum na tarehe ya kuchapishwa. Ni ipi kati ya hizi ni sifa ya fasihi andishi?,
      options: [Ina mwandishi maalum., Haijulikani mwandishi wake., Haina tarehe.", "Haina muundo maalum.].sort(() => Math.random() - 0.5),
      correctAnswer: Ina mwandishi maalum."
    })
  },

  // --- MADA: FASIHI SIMULIZI (5 Materials) ---
  {
    id: "G10-FAS-SIM-01",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Hadithi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Hadithi ni aina ya fasihi simulizi inayosimuliwa na msimulizi. Ni kipi kati ya hivi ni muhimu katika hadithi?,
      options: [Wahusika na mazingira, Mizani, "Mshororo, Ubeti"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wahusika na mazingira
    })
  },
  {
    id: G10-FAS-SIM-02",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Ngano",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Ngano ni hadithi za jadi zinazosimuliwa na wazee. Ni kipi kati ya hivi ni mfano wa ngano?,
      options: [Hadithi ya Kisa cha Wanyama, Riwaya ya Mzee, Tamthilia ya shule", "Shairi la mapenzi].sort(() => Math.random() - 0.5),
      correctAnswer: Hadithi ya Kisa cha Wanyama"
    })
  },
  {
    id: "G10-FAS-SIM-03",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Methali ni maneno ya hekima yanayotumiwa katika fasihi simulizi. Ni ipi kati ya hizi ni methali?,
      options: [Haraka haraka haina baraka., Usiku wa maneno, "Mimi ni mwenyewe, Kazi ni kazi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Haraka haraka haina baraka.
    })
  },
  {
    id: G10-FAS-SIM-04",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Vitendawili ni aina ya fasihi simulizi inayotumiwa kwa mchezo wa akili. Ni kipi kati ya hivi ni kitendawili?,
      options: [Wewe ni nani? Mgeni ni mji., Mimi ni nini? Nimekaa kando ya barabara., Kazi ni kazi.", "Haraka haraka haina baraka.].sort(() => Math.random() - 0.5),
      correctAnswer: Mimi ni nini? Nimekaa kando ya barabara."
    })
  },
  {
    id: "G10-FAS-SIM-05",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Vitendawili vinaweza kugawanywa katika makundi kulingana na mada. Ni kundi lipi kati ya hivi ni la vitendawili?,
      options: [Vitendawili vya wanyama, Vitendawili vya nyumbani, "Vitendawili vya shule, Vyote vya juu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vyote vya juu
    })
  },

  // --- MADA: FASIHI ANDISHI (5 Materials) ---
  {
    id: G10-FAS-AND-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Riwaya ni aina ya fasihi andishi inayosimulia hadithi ndefu. Ni kipi kati ya hivi ni sifa ya riwaya?,
      options: [Hadithi ndefu yenye sura nyingi., Hadithi fupi., Hadithi ya mchezo.", "Hadithi ya shairi.].sort(() => Math.random() - 0.5),
      correctAnswer: Hadithi ndefu yenye sura nyingi."
    })
  },
  {
    id: "G10-FAS-AND-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Tamthilia,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Tamthilia ni aina ya fasihi andishi inayolenga kuigizwa jukwaani. Ni kipi kati ya hivi ni sifa ya tamthilia?,
      options: [Mazungumzo na maigizo, Mizani, "Kinai, Ubeti"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mazungumzo na maigizo
    })
  },
  {
    id: G10-FAS-AND-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Ushairi ni aina ya fasihi andishi inayojumuisha mashairi. Ni kipi kati ya hivi ni kipengele cha ushairi?,
      options: [Mizani na kinai, Wahusika, Mazingira", "Mazungumzo].sort(() => Math.random() - 0.5),
      correctAnswer: Mizani na kinai"
    })
  },
  {
    id: "G10-FAS-AND-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ushairi wa Kiswahili una mshororo na ubeti. Ni nini tofauti kati ya mshororo na ubeti?,
      options: [Mshororo ni mstari mmoja, ubeti ni kundi la mishororo., Mshororo ni kundi la mishororo, ubeti ni mstari mmoja., "Zote ni sawa., Mshororo ni mzani, ubeti ni kinai."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mshororo ni mstari mmoja, ubeti ni kundi la mishororo.
    })
  },
  {
    id: G10-FAS-AND-05",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Riwaya ina muundo wa kipekee unaojumuisha utangulizi, mwili, na hitimisho. Ni kipi kati ya hivi ni muhimu katika riwaya?,
      options: [Wahusika na mazingira, Mizani, Kinai", "Mshororo].sort(() => Math.random() - 0.5),
      correctAnswer: Wahusika na mazingira"
    })
  },

  // --- MADA: HADITHI (4 Materials) ---
  {
    id: "G10-FAS-HAD-01",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Hadithi",
    subtopic: "Muundo wa Hadithi,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Hadithi ina muundo unaoanza na utangulizi, kisha mwili, na kuishia na hitimisho. Ni sehemu ipi inaelezea mwanzo wa hadithi?,
      options: ["Utangulizi, Mwili", "Hitimisho, Mazungumzo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utangulizi
    })
  },
  {
    id: G10-FAS-HAD-02",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Hadithi,
    subtopic: "Wahusika",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Wahusika ni watu au viumbe wanaoshiriki katika hadithi. Ni aina gani ya mhusika anayepambana na shida kuu katika hadithi?,
      options: [Mhusika mkuu, Mhusika mdogo, Mhusika msaidizi", "Mhusika wa kubuni].sort(() => Math.random() - 0.5),
      correctAnswer: Mhusika mkuu"
    })
  },
  {
    id: "G10-FAS-HAD-03",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Hadithi",
    subtopic: "Mazingira,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mazingira ni wakati na mahali ambapo hadithi inatokea. Ni kipi kati ya hivi ni mazingira ya hadithi?,
      options: [Mahali na wakati, Wahusika, "Mazungumzo, Mada"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mahali na wakati
    })
  },
  {
    id: G10-FAS-HAD-04",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Hadithi,
    subtopic: "Mada",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Mada ni wazo kuu au somo la hadithi. Ni kipi kati ya hivi ni mada inayojitokeza katika hadithi?,
      options: [Ujasiri na upendo, Mizani, Mshororo", "Ubeti].sort(() => Math.random() - 0.5),
      correctAnswer: Ujasiri na upendo"
    })
  },

  // --- MADA: USHAIRI (5 Materials) ---
  {
    id: "G10-FAS-SHA-01",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Mizani na Kinai,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mizani na kinai ni vipengele muhimu vya ushairi wa Kiswahili. Mizani ni nini katika ushairi?,
      options: [Idadi ya silabi katika mshororo., Mfano wa maneno., "Picha za ushairi., Kukariri."].sort(() => Math.random() - 0.5),
      correctAnswer: "Idadi ya silabi katika mshororo.
    })
  },
  {
    id: G10-FAS-SHA-02",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Mizani na Kinai",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Kinai ni mpangilio wa silabi za mwisho katika mshororo. Ni kipi kati ya hivi ni mfano wa kinai?,
      options: [Mshororo unaoishia kwa sauti sawa., Mshororo unaoanza kwa sauti sawa., Mshororo wenye silabi nyingi.", "Mshororo wenye silabi chache.].sort(() => Math.random() - 0.5),
      correctAnswer: Mshororo unaoishia kwa sauti sawa."
    })
  },
  {
    id: "G10-FAS-SHA-03",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Mshororo na Ubeti,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Mshororo na ubeti ni vipengele vya ushairi. Ubeti ni nini?,
      options: [Kundi la mishororo., Mstari mmoja., "Mfano wa maneno., Picha za ushairi."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kundi la mishororo.
    })
  },
  {
    id: G10-FAS-SHA-04",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Vipengele vya Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Ushairi una vipengele vingi vya lugha. Ni kipi kati ya hivi ni kipengele cha ushairi?,
      options: [Picha za ushairi, Wahusika, Mazungumzo", "Mazingira].sort(() => Math.random() - 0.5),
      correctAnswer: Picha za ushairi"
    })
  },
  {
    id: "G10-FAS-SHA-05",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Vipengele vya Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ushairi wa Kiswahili una aina mbalimbali. Ni ipi kati ya hizi ni aina ya ushairi?,
      options: [Shairi la kisa, Shairi la fumbo, "Shairi la maisha, Shairi la mazingira"].sort(() => Math.random() - 0.5),
      correctAnswer: "Shairi la kisa
    })
  },

  // --- MADA: TAMTHILIA (4 Materials) ---
  {
    id: G10-FAS-TAM-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Maigizo",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tamthilia ni aina ya fasihi inayolenga kuigizwa. Ni kipi kati ya hivi ni muhimu katika tamthilia?,
      options: [Wahusika na mazingira, Mizani, Kinai", "Mshororo].sort(() => Math.random() - 0.5),
      correctAnswer: Wahusika na mazingira"
    })
  },
  {
    id: "G10-FAS-TAM-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Wahusika,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Wahusika katika tamthilia huwa na jukumu tofauti. Ni nani mhusika anayesababisha matatizo katika tamthilia?,
      options: [Mhusika mpinzani, Mhusika mkuu, "Mhusika msaidizi, Mhusika mdogo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mhusika mpinzani
    })
  },
  {
    id: G10-FAS-TAM-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Mazingira",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Mazingira katika tamthilia ni mahali na wakati wa tukio. Ni kipi kati ya hivi ni mazingira ya tamthilia?,
      options: [Mahali na wakati, Wahusika, Mazungumzo", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Mahali na wakati"
    })
  },
  {
    id: "G10-FAS-TAM-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Mada,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mada ni wazo kuu la tamthilia. Ni ipi kati ya hizi ni mada inayojitokeza katika tamthilia?,
      options: [Upendo na usaliti, Mizani, "Kinai, Mshororo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Upendo na usaliti
    })
  },

  // --- MADA: RIWAYA (4 Materials) ---
  {
    id: G10-FAS-RIW-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Muundo wa Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Riwaya ina muundo maalum unaoanza na utangulizi. Ni sehemu ipi inaelezea mwanzo wa riwaya?,
      options: [Utangulizi, Mwili, Hitimisho", "Mazungumzo].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi"
    })
  },
  {
    id: "G10-FAS-RIW-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Wahusika,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Wahusika ni watu au viumbe wanaoshiriki katika riwaya. Ni aina gani ya mhusika anayepambana na shida kuu katika riwaya?,
      options: [Mhusika mkuu, Mhusika mdogo, "Mhusika msaidizi, Mhusika wa kubuni"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mhusika mkuu
    })
  },
  {
    id: G10-FAS-RIW-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Mazingira",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Mazingira ni wakati na mahali ambapo riwaya inatokea. Ni kipi kati ya hivi ni mazingira ya riwaya?,
      options: [Mahali na wakati, Wahusika, Mazungumzo", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Mahali na wakati"
    })
  },
  {
    id: "G10-FAS-RIW-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Mada,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mada ni wazo kuu au somo la riwaya. Ni kipi kati ya hivi ni mada inayojitokeza katika riwaya?,
      options: [Ujasiri na upendo, Mizani, "Mshororo, Ubeti"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ujasiri na upendo
    })
  },

  // --- MADA: METHALI NA VITENDAWILI (4 Materials) ---
  {
    id: G10-FAS-MET-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Methali na Vitendawili,
    subtopic: "Maana ya Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Methali ni maneno ya hekima yanayotumiwa katika fasihi. Ni ipi kati ya hizi ni methali?,
      options: [Haraka haraka haina baraka., Usiku wa maneno, Mimi ni mwenyewe", "Kazi ni kazi].sort(() => Math.random() - 0.5),
      correctAnswer: Haraka haraka haina baraka."
    })
  },
  {
    id: "G10-FAS-MET-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali na Vitendawili",
    subtopic: "Maana ya Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Methali hulenga kutoa hekima na mawaidha. Ni kipi kati ya hivi ni mafunzo kutoka kwa methali?,
      options: [Mawaidha ya maisha, Mizani, "Kinai, Mshororo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mawaidha ya maisha
    })
  },
  {
    id: G10-FAS-MET-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Methali na Vitendawili,
    subtopic: "Maana ya Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Vitendawili ni aina ya fasihi simulizi inayotumiwa kwa mchezo wa akili. Ni kipi kati ya hivi ni kitendawili?,
      options: [Wewe ni nani? Mgeni ni mji., Mimi ni nini? Nimekaa kando ya barabara., Kazi ni kazi.", "Haraka haraka haina baraka.].sort(() => Math.random() - 0.5),
      correctAnswer: Mimi ni nini? Nimekaa kando ya barabara."
    })
  },
  {
    id: "G10-FAS-MET-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali na Vitendawili",
    subtopic: "Maana ya Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Vitendawili vinaweza kugawanywa katika makundi kulingana na mada. Ni kundi lipi kati ya hivi ni la vitendawili?,
      options: [Vitendawili vya wanyama, Vitendawili vya nyumbani, "Vitendawili vya shule, Vyote vya juu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vyote vya juu
    })
  },

  // --- MADA: TATHMINI YA FASIHI (4 Materials) ---
  {
    id: G10-FAS-TAT-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Tathmini ya Fasihi,
    subtopic: "Uchambuzi wa Kazi za Fasihi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tathmini ya fasihi inahusisha uchambuzi wa kazi ya fasihi. Ni kipi kati ya hivi ni muhimu katika tathmini ya fasihi?,
      options: [Muundo, wahusika, na mazingira., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Muundo, wahusika, na mazingira."
    })
  },
  {
    id: "G10-FAS-TAT-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Tathmini ya Fasihi",
    subtopic: "Uchambuzi wa Kazi za Fasihi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Tathmini ya fasihi huzingatia mtindo wa mwandishi. Ni kipi kati ya hivi ni mtindo wa mwandishi?,
      options: [Jinsi mwandishi anavyotumia lugha., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Jinsi mwandishi anavyotumia lugha.
    })
  },
  {
    id: G10-FAS-TAT-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Tathmini ya Fasihi,
    subtopic: "Uchambuzi wa Kazi za Fasihi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tathmini ya fasihi inajumuisha uangalizi wa mazingira ya kazi. Ni kipi kati ya hivi ni mazingira ya kazi ya fasihi?,
      options: [Wakati na mahali., Wahusika., Mazungumzo.", "Mada.].sort(() => Math.random() - 0.5),
      correctAnswer: Wakati na mahali."
    })
  },
  {
    id: "G10-FAS-TAT-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Tathmini ya Fasihi",
    subtopic: "Uchambuzi wa Kazi za Fasihi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Tathmini ya fasihi inaweza kujumuisha uangalizi wa mada. Ni kipi kati ya hivi ni mada ya kazi ya fasihi?,
      options: [Wazo kuu la kazi., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wazo kuu la kazi.
    })
  },

  // --- MADA: MWANDISHI NA KAZI ZAKE (4 Materials) ---
  {
    id: G10-FAS-MWA-01",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Mwandishi na Kazi Zake,
    subtopic: "Maisha ya Mwandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Kujua maisha ya mwandishi kunasaidia kuelewa kazi zake. Ni kipi kati ya hivi ni muhimu kujua kuhusu mwandishi?,
      options: [Umri wake, Mahali alipozaliwa, Kazi zake", "Mada anazoziandika].sort(() => Math.random() - 0.5),
      correctAnswer: Kazi zake"
    })
  },
  {
    id: "G10-FAS-MWA-02",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Mwandishi na Kazi Zake",
    subtopic: "Maisha ya Mwandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Wandishi wengi wa Kiswahili wameandika kazi mbalimbali. Ni mwandishi gani maarufu wa Kiswahili?,
      options: [Shaaban Robert, William Shakespeare, "Chinua Achebe, Ngugi wa Thiong'o"].sort(() => Math.random() - 0.5),
      correctAnswer: "Shaaban Robert
    })
  },
  {
    id: G10-FAS-MWA-03",
    grade: "Grade 10,
    subject: Fasihi ya Kiswahili",
    topic: "Mwandishi na Kazi Zake,
    subtopic: "Kazi za Mwandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Shaaban Robert ni mmoja wa waandishi maarufu wa Kiswahili. Ni kazi gani maarufu ya Shaaban Robert?,
      options: [Wasifu wa Siti binti Saad, Utengano, Mshora", "Tamaa ya Moyo].sort(() => Math.random() - 0.5),
      correctAnswer: Wasifu wa Siti binti Saad"
    })
  },
  {
    id: "G10-FAS-MWA-04",
    grade: "Grade 10",
    subject: "Fasihi ya Kiswahili",
    topic: "Mwandishi na Kazi Zake",
    subtopic: "Kazi za Mwandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kazi za wandishi zinaweza kuwa riwaya, tamthilia, au ushairi. Ni kipi kati ya hivi ni tamthilia maarufu ya Kiswahili?,
      options: ["Utengano, Wasifu wa Siti binti Saad", "Tamaa ya Moyo, Kivuli cha Mlima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utengano
    })
  },

  // =========================================================================
  // DARASA LA 11: 35 MATERIALS (KICD FASIHI YA KISWAHILI)
  // =========================================================================

  // --- MADA: FASIHI SIMULIZI (5 Materials) ---
  {
    id: G11-FAS-SIM-01",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Aina za Fasihi Simulizi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi simulizi inajumuisha aina mbalimbali kama ngano, nembo, nyimbo, na tenzi. Ni ipi kati ya hizi ni aina ya fasihi simulizi?,
      options: [Ngano, Riwaya, Tamthilia", "Ushairi].sort(() => Math.random() - 0.5),
      correctAnswer: Ngano"
    })
  },
  {
    id: "G11-FAS-SIM-02",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Aina za Fasihi Simulizi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Nembo ni alama zinazotumiwa katika jamii. Ni kipi kati ya hivi ni mfano wa nembo?,
      options: [Nembo ya taifa, Riwaya, "Tamthilia, Shairi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nembo ya taifa
    })
  },
  {
    id: G11-FAS-SIM-03",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Nyimbo",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Nyimbo ni aina ya fasihi simulizi inayotumiwa kwa kusherehekea au kwa maombolezo. Ni ipi kati ya hizi ni nyimbo?,
      options: [Nyimbo za taifa, Riwaya, Tamthilia", "Shairi].sort(() => Math.random() - 0.5),
      correctAnswer: Nyimbo za taifa"
    })
  },
  {
    id: "G11-FAS-SIM-04",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Tenzi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Tenzi ni aina ya fasihi simulizi inayosimulia hadithi ndefu kwa njia ya mashairi. Ni ipi kati ya hizi ni tenzi?,
      options: [Tenzi ya mwana, Riwaya, "Tamthilia, Shairi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tenzi ya mwana
    })
  },
  {
    id: G11-FAS-SIM-05",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Umuhimu wa Fasihi Simulizi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi simulizi ina umuhimu mkubwa katika jamii ya Kiswahili. Ni kipi kati ya hivi ni umuhimu wa fasihi simulizi?,
      options: [Kuhifadhi historia na mila., Kufundisha lugha., Kutengeneza riwaya.", "Kuboresha mizani.].sort(() => Math.random() - 0.5),
      correctAnswer: Kuhifadhi historia na mila."
    })
  },

  // --- MADA: FASIHI ANDISHI (5 Materials) ---
  {
    id: "G11-FAS-AND-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Aina za Fasihi Andishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Fasihi andishi inajumuisha aina mbalimbali kama riwaya, tamthilia, na ushairi. Ni ipi kati ya hizi ni fasihi andishi?,
      options: ["Riwaya, Ngano", "Nembo, Nyimbo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Riwaya
    })
  },
  {
    id: G11-FAS-AND-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Sifa za Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fasihi andishi ina sifa maalum zinazoitofautisha na fasihi simulizi. Ni kipi kati ya hivi ni sifa ya fasihi andishi?,
      options: [Ina mwandishi maalum., Haina mwandishi., Haina tarehe.", "Haina muundo.].sort(() => Math.random() - 0.5),
      correctAnswer: Ina mwandishi maalum."
    })
  },
  {
    id: "G11-FAS-AND-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Aina za Fasihi Andishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Riwaya, tamthilia, na ushairi ni aina za fasihi andishi. Ni ipi kati ya hizi inahusisha maigizo?,
      options: ["Tamthilia, Riwaya", "Ushairi, Ngano"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tamthilia
    })
  },
  {
    id: G11-FAS-AND-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Sifa za Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi andishi inaweza kugawanywa kulingana na mtindo. Ni kipi kati ya hivi ni sifa ya fasihi andishi?,
      options: [Inaweza kuchapishwa., Haina tarehe., Haina mwandishi.", "Haina muundo.].sort(() => Math.random() - 0.5),
      correctAnswer: Inaweza kuchapishwa."
    })
  },
  {
    id: "G11-FAS-AND-05",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Umuhimu wa Fasihi Andishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Fasihi andishi ina umuhimu wake katika jamii ya Kiswahili. Ni kipi kati ya hivi ni umuhimu wa fasihi andishi?,
      options: [Kuhifadhi kazi za fasihi kwa maandishi., Kufundisha mizani., "Kufundisha kinai., Kufundisha mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuhifadhi kazi za fasihi kwa maandishi.
    })
  },

  // --- MADA: USHAIRI (5 Materials) ---
  {
    id: G11-FAS-SHA-01",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Tathmini ya Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Ushairi ni aina ya fasihi inayojumuisha mashairi. Ni kipi kati ya hivi ni muhimu katika tathmini ya ushairi?,
      options: [Mizani na kinai., Wahusika., Mazingira.", "Mazungumzo.].sort(() => Math.random() - 0.5),
      correctAnswer: Mizani na kinai."
    })
  },
  {
    id: "G11-FAS-SHA-02",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Tathmini ya Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mshororo na ubeti ni vipengele vya ushairi. Ni nini tofauti kati ya mshororo na ubeti?,
      options: [Mshororo ni mstari mmoja, ubeti ni kundi la mishororo., Mshororo ni kundi la mishororo, ubeti ni mstari mmoja., "Zote ni sawa., Mshororo ni mzani, ubeti ni kinai."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mshororo ni mstari mmoja, ubeti ni kundi la mishororo.
    })
  },
  {
    id: G11-FAS-SHA-03",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Tathmini ya Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Picha za ushairi ni muhimu katika ushairi wa Kiswahili. Ni ipi kati ya hizi ni picha za ushairi?,
      options: [Simili, Mizani, Kinai", "Mshororo].sort(() => Math.random() - 0.5),
      correctAnswer: Simili"
    })
  },
  {
    id: "G11-FAS-SHA-04",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Tathmini ya Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ushairi wa Kiswahili unaweza kujumuisha masomo mbalimbali. Ni ipi kati ya hizi ni mada ya ushairi?,
      options: [Upendo na maisha., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Upendo na maisha.
    })
  },
  {
    id: G11-FAS-SHA-05",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Tathmini ya Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ushairi wa Kiswahili una aina mbalimbali. Ni ipi kati ya hizi ni aina ya ushairi?,
      options: [Shairi la kisa, Shairi la fumbo, Shairi la maisha", "Shairi la mazingira].sort(() => Math.random() - 0.5),
      correctAnswer: Shairi la kisa"
    })
  },

  // --- MADA: TAMTHILIA (4 Materials) ---
  {
    id: "G11-FAS-TAM-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Tathmini ya Tamthilia,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Tamthilia ni aina ya fasihi inayolenga kuigizwa jukwaani. Ni kipi kati ya hivi ni muhimu katika tathmini ya tamthilia?,
      options: [Mazungumzo na wahusika., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mazungumzo na wahusika.
    })
  },
  {
    id: G11-FAS-TAM-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Tathmini ya Tamthilia",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Wahusika katika tamthilia huwa na jukumu tofauti. Ni nani mhusika anayesababisha matatizo katika tamthilia?,
      options: [Mhusika mpinzani, Mhusika mkuu, Mhusika msaidizi", "Mhusika mdogo].sort(() => Math.random() - 0.5),
      correctAnswer: Mhusika mpinzani"
    })
  },
  {
    id: "G11-FAS-TAM-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Tathmini ya Tamthilia,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mazingira katika tamthilia ni mahali na wakati wa tukio. Ni kipi kati ya hivi ni mazingira ya tamthilia?,
      options: [Mahali na wakati, Wahusika, "Mazungumzo, Mada"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mahali na wakati
    })
  },
  {
    id: G11-FAS-TAM-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Tathmini ya Tamthilia",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Mada ni wazo kuu la tamthilia. Ni ipi kati ya hizi ni mada inayojitokeza katika tamthilia?,
      options: [Upendo na usaliti, Mizani, Kinai", "Mshororo].sort(() => Math.random() - 0.5),
      correctAnswer: Upendo na usaliti"
    })
  },

  // --- MADA: RIWAYA (4 Materials) ---
  {
    id: "G11-FAS-RIW-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Tathmini ya Riwaya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Riwaya ni aina ya fasihi inayosimulia hadithi ndefu. Ni kipi kati ya hivi ni muhimu katika tathmini ya riwaya?,
      options: [Muundo, wahusika, na mazingira., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Muundo, wahusika, na mazingira.
    })
  },
  {
    id: G11-FAS-RIW-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Tathmini ya Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Wahusika katika riwaya huwa na jukumu tofauti. Ni nani mhusika anayepambana na shida kuu katika riwaya?,
      options: [Mhusika mkuu, Mhusika mdogo, Mhusika msaidizi", "Mhusika wa kubuni].sort(() => Math.random() - 0.5),
      correctAnswer: Mhusika mkuu"
    })
  },
  {
    id: "G11-FAS-RIW-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Tathmini ya Riwaya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mazingira ni wakati na mahali ambapo riwaya inatokea. Ni kipi kati ya hivi ni mazingira ya riwaya?,
      options: [Mahali na wakati, Wahusika, "Mazungumzo, Mada"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mahali na wakati
    })
  },
  {
    id: G11-FAS-RIW-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Tathmini ya Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Mada ni wazo kuu la riwaya. Ni ipi kati ya hizi ni mada inayojitokeza katika riwaya?,
      options: [Ujasiri na upendo, Mizani, Mshororo", "Ubeti].sort(() => Math.random() - 0.5),
      correctAnswer: Ujasiri na upendo"
    })
  },

  // --- MADA: METHALI NA NAHAU (4 Materials) ---
  {
    id: "G11-FAS-MET-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali na Nahau",
    subtopic: "Maana ya Methali na Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Methali na nahau ni maneno ya hekima yanayotumiwa katika fasihi. Ni ipi kati ya hizi ni methali?,
      options: [Haraka haraka haina baraka., Usiku wa maneno, "Mimi ni mwenyewe, Kazi ni kazi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Haraka haraka haina baraka.
    })
  },
  {
    id: G11-FAS-MET-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Methali na Nahau,
    subtopic: "Maana ya Methali na Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Nahau ni maneno ya pamoja yenye maana ya mfano. Ni ipi kati ya hizi ni nahau?,
      options: [Kufuma kwa dharuba, Haraka haraka haina baraka., Mimi ni mwenyewe", "Kazi ni kazi].sort(() => Math.random() - 0.5),
      correctAnswer: Kufuma kwa dharuba"
    })
  },
  {
    id: "G11-FAS-MET-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali na Nahau",
    subtopic: "Matumizi ya Methali na Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Methali na nahau hutumiwa katika fasihi kwa madhumuni mbalimbali. Ni kipi kati ya hivi ni matumizi ya methali na nahau?,
      options: [Kutoa mawaidha na hekima., Kujenga mizani., "Kujenga kinai., Kujenga mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kutoa mawaidha na hekima.
    })
  },
  {
    id: G11-FAS-MET-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Methali na Nahau,
    subtopic: "Matumizi ya Methali na Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Nahau hutumiwa kueleza maana kwa njia ya mfano. Ni ipi kati ya hizi ni nahau?,
      options: [Kukata tamaa, Haraka haraka, Mimi mwenyewe", "Kazi kazi].sort(() => Math.random() - 0.5),
      correctAnswer: Kukata tamaa"
    })
  },

  // --- MADA: UCHAMBUZI WA FASIHI (4 Materials) ---
  {
    id: "G11-FAS-UCH-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Fasihi",
    subtopic: "Uchambuzi wa Lugha,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Uchambuzi wa fasihi unahusisha uchambuzi wa lugha. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa lugha?,
      options: [Mtindo wa lugha na picha za ushairi., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mtindo wa lugha na picha za ushairi.
    })
  },
  {
    id: G11-FAS-UCH-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Fasihi,
    subtopic: "Uchambuzi wa Lugha",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Picha za ushairi ni muhimu katika uchambuzi wa fasihi. Ni ipi kati ya hizi ni picha za ushairi?,
      options: [Simili, Mizani, Kinai", "Mshororo].sort(() => Math.random() - 0.5),
      correctAnswer: Simili"
    })
  },
  {
    id: "G11-FAS-UCH-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Fasihi",
    subtopic: "Uchambuzi wa Mtindo,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mtindo wa mwandishi ni jinsi anavyotumia lugha. Ni kipi kati ya hivi ni mtindo wa mwandishi?,
      options: [Jinsi anavyotumia lugha na picha za ushairi., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Jinsi anavyotumia lugha na picha za ushairi.
    })
  },
  {
    id: G11-FAS-UCH-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Fasihi,
    subtopic: "Uchambuzi wa Mazingira",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Mazingira ni wakati na mahali ambapo hadithi inatokea. Ni kipi kati ya hivi ni mazingira ya hadithi?,
      options: [Mahali na wakati, Wahusika, Mazungumzo", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Mahali na wakati"
    })
  },

  // --- MADA: FASIHI NA JAMII (4 Materials) ---
  {
    id: "G11-FAS-JAM-01",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi na Jamii",
    subtopic: "Fasihi na Mila,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Fasihi inahusiana kwa karibu na mila ya jamii. Ni kipi kati ya hivi ni umuhimu wa fasihi kwa mila?,
      options: [Inahifadhi mila na utamaduni., Inaharibu mila., "Haijalishi mila., Inapuuza mila."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inahifadhi mila na utamaduni.
    })
  },
  {
    id: G11-FAS-JAM-02",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi na Jamii,
    subtopic: "Fasihi na Maendeleo ya Jamii",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fasihi inachangia maendeleo ya jamii kwa njia mbalimbali. Ni kipi kati ya hivi ni mchango wa fasihi kwa jamii?,
      options: [Kuelimisha na kuhamasisha jamii., Kuharibu jamii., Kupuuza jamii.", "Kuudhi jamii.].sort(() => Math.random() - 0.5),
      correctAnswer: Kuelimisha na kuhamasisha jamii."
    })
  },
  {
    id: "G11-FAS-JAM-03",
    grade: "Grade 11",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi na Jamii",
    subtopic: "Fasihi na Mila,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Fasihi simulizi ina jukumu kubwa katika kuhamisha mila. Ni kipi kati ya hivi ni jukumu la fasihi simulizi?,
      options: [Kuhamisha mila na historia., Kuharibu mila., "Kupuuza mila., Kusahaulisha mila."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuhamisha mila na historia.
    })
  },
  {
    id: G11-FAS-JAM-04",
    grade: "Grade 11,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi na Jamii,
    subtopic: "Fasihi na Maendeleo ya Jamii",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi inaweza kuwa chombo cha maendeleo na mabadiliko. Ni kipi kati ya hivi ni mchango wa fasihi katika maendeleo ya jamii?,
      options: [Inatoa mawaidha na kuelimisha., Inaharibu jamii., Inapuuza jamii.", "Inaumiza jamii.].sort(() => Math.random() - 0.5),
      correctAnswer: Inatoa mawaidha na kuelimisha."
    })
  },
  // =========================================================================
  // DARASA LA 12: 35 MATERIALS (KICD FASIHI YA KISWAHILI)
  // =========================================================================

  // --- MADA: FASIHI SIMULIZI (5 Materials) ---
  {
    id: "G12-FAS-SIM-01",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Utambuzi wa Fasihi Simulizi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Fasihi simulizi ni fasihi inayopitishwa kwa mdomo. Ni ipi kati ya hizi ni sifa kuu ya fasihi simulizi?,
      options: [Haina mwandishi maalum., Ina mwandishi mmoja., "Inachapishwa., Ina tarehe ya kuchapishwa."].sort(() => Math.random() - 0.5),
      correctAnswer: "Haina mwandishi maalum.
    })
  },
  {
    id: G12-FAS-SIM-02",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Uchambuzi wa Fasihi Simulizi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Uchambuzi wa fasihi simulizi unahitaji uangalizi wa lugha na mtindo. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa fasihi simulizi?,
      options: [Lugha ya mdomo na mtindo wa usimulizi., Mizani na kinai., Mshororo na ubeti.", "Wahusika na mazingira.].sort(() => Math.random() - 0.5),
      correctAnswer: Lugha ya mdomo na mtindo wa usimulizi."
    })
  },
  {
    id: "G12-FAS-SIM-03",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Aina za Fasihi Simulizi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Fasihi simulizi inajumuisha aina mbalimbali. Ni ipi kati ya hizi ni aina ya fasihi simulizi?,
      options: [Ngano na nembo, Riwaya, "Tamthilia, Ushairi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ngano" na nembo
    })
  },
  {
    id: G12-FAS-SIM-04",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi,
    subtopic: "Uchambuzi wa Fasihi Simulizi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Tenzi ni aina ya fasihi simulizi inayosimulia hadithi ndefu kwa njia ya mashairi. Ni kipi kati ya hivi ni sifa ya tenzi?,
      options: [Hadithi ndefu kwa njia ya mashairi., Hadithi fupi., Hadithi ya mchezo.", "Hadithi ya maisha.].sort(() => Math.random() - 0.5),
      correctAnswer: Hadithi ndefu kwa njia ya mashairi."
    })
  },
  {
    id: "G12-FAS-SIM-05",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Simulizi",
    subtopic: "Umuhimu wa Fasihi Simulizi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Fasihi simulizi ina umuhimu mkubwa katika jamii. Ni kipi kati ya hivi ni umuhimu wa fasihi simulizi?,
      options: [Kuhifadhi historia na mila ya jamii., Kufundisha lugha tu., "Kutengeneza riwaya., Kuboresha mizani."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuhifadhi historia na mila ya jamii.
    })
  },

  // --- MADA: FASIHI ANDISHI (5 Materials) ---
  {
    id: G12-FAS-AND-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Utambuzi wa Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fasihi andishi ni fasihi inayopatikana kwa maandishi. Ni ipi kati ya hizi ni sifa kuu ya fasihi andishi?,
      options: [Ina mwandishi maalum na tarehe ya kuchapishwa., Haina mwandishi., Haina tarehe.", "Haina muundo.].sort(() => Math.random() - 0.5),
      correctAnswer: Ina mwandishi maalum na tarehe ya kuchapishwa."
    })
  },
  {
    id: "G12-FAS-AND-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Uchambuzi wa Fasihi Andishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Uchambuzi wa fasihi andishi unahitaji uangalizi wa muundo na mtindo. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa fasihi andishi?,
      options: [Muundo, wahusika, na mazingira., Mizani na kinai., "Mshororo na ubeti., Methali na vitendawili."].sort(() => Math.random() - 0.5),
      correctAnswer: "Muundo, wahusika, na mazingira.
    })
  },
  {
    id: G12-FAS-AND-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Aina za Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fasihi andishi inajumuisha aina mbalimbali. Ni ipi kati ya hizi ni aina ya fasihi andishi?,
      options: [Riwaya, tamthilia, na ushairi., Ngano na nembo., Nyimbo na tenzi.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Riwaya, tamthilia, na ushairi."
    })
  },
  {
    id: "G12-FAS-AND-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi Andishi",
    subtopic: "Uchambuzi wa Fasihi Andishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Uchambuzi wa fasihi andishi unajumuisha uangalizi wa lugha ya mwandishi. Ni kipi kati ya hivi ni lugha ya kifasihi?,
      options: [Lugha yenye picha za ushairi na tafauti., Lugha ya mazungumzo tu., "Lugha ya kitaaluma tu., Lugha rahisi."].sort(() => Math.random() - 0.5),
      correctAnswer: "Lugha yenye picha za ushairi na tafauti.
    })
  },
  {
    id: G12-FAS-AND-05",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi Andishi,
    subtopic: "Umuhimu wa Fasihi Andishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi andishi ina umuhimu wake katika jamii. Ni kipi kati ya hivi ni umuhimu wa fasihi andishi?,
      options: [Kuhifadhi kazi za fasihi kwa maandishi., Kufundisha mizani., Kufundisha kinai.", "Kufundisha mshororo.].sort(() => Math.random() - 0.5),
      correctAnswer: Kuhifadhi kazi za fasihi kwa maandishi."
    })
  },

  // --- MADA: USHAIRI (5 Materials) ---
  {
    id: "G12-FAS-SHA-01",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Uchambuzi wa Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ushairi ni aina ya fasihi inayojumuisha mashairi. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa ushairi?,
      options: [Mizani, kinai, na picha za ushairi., Wahusika na mazingira., "Mazungumzo na maigizo., Hadithi na muundo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mizani, kinai, na picha za ushairi.
    })
  },
  {
    id: G12-FAS-SHA-02",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Uchambuzi wa Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Mizani na kinai ni vipengele muhimu vya ushairi. Mizani ni nini katika ushairi?,
      options: [Idadi ya silabi katika mshororo., Mfano wa maneno., Picha za ushairi.", "Kukariri.].sort(() => Math.random() - 0.5),
      correctAnswer: Idadi ya silabi katika mshororo."
    })
  },
  {
    id: "G12-FAS-SHA-03",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Uchambuzi wa Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Kinai ni mpangilio wa silabi za mwisho katika mshororo. Ni kipi kati ya hivi ni mfano wa kinai?,
      options: [Mshororo unaoishia kwa sauti sawa., Mshororo unaoanza kwa sauti sawa., "Mshororo wenye silabi nyingi., Mshororo wenye silabi chache."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mshororo unaoishia kwa sauti sawa.
    })
  },
  {
    id: G12-FAS-SHA-04",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Ushairi,
    subtopic: "Uchambuzi wa Ushairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Picha za ushairi ni muhimu katika ushairi wa Kiswahili. Ni ipi kati ya hizi ni picha za ushairi?,
      options: [Simili, tashbihi, na mfano., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Simili, tashbihi, na mfano."
    })
  },
  {
    id: "G12-FAS-SHA-05",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Ushairi",
    subtopic: "Uchambuzi wa Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ushairi wa Kiswahili unaweza kugawanywa kulingana na mtindo. Ni ipi kati ya hizi ni aina ya ushairi?,
      options: [Shairi la kisa, Shairi la fumbo, "Shairi la maisha, Shairi la mazingira"].sort(() => Math.random() - 0.5),
      correctAnswer: "Shairi la kisa
    })
  },

  // --- MADA: TAMTHILIA (4 Materials) ---
  {
    id: G12-FAS-TAM-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Uchambuzi wa Tamthilia",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Tamthilia ni aina ya fasihi inayolenga kuigizwa jukwaani. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa tamthilia?,
      options: [Muundo, wahusika, na mazingira., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Muundo, wahusika, na mazingira."
    })
  },
  {
    id: "G12-FAS-TAM-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Uchambuzi wa Tamthilia,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Wahusika katika tamthilia huwa na jukumu tofauti. Ni nani mhusika anayeleta mwendo wa hadithi?,
      options: [Mhusika mkuu, Mhusika mpinzani, "Mhusika msaidizi, Mhusika mdogo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mhusika mkuu
    })
  },
  {
    id: G12-FAS-TAM-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Tamthilia,
    subtopic: "Uchambuzi wa Tamthilia",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Mazingira katika tamthilia ni mahali na wakati wa tukio. Ni kipi kati ya hivi ni mazingira ya tamthilia?,
      options: [Mahali na wakati, Wahusika, Mazungumzo", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Mahali na wakati"
    })
  },
  {
    id: "G12-FAS-TAM-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Tamthilia",
    subtopic: "Uchambuzi wa Tamthilia,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mada ni wazo kuu la tamthilia. Ni ipi kati ya hizi ni mada inayojitokeza katika tamthilia?,
      options: [Upendo na usaliti, Mizani, "Kinai, Mshororo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Upendo na usaliti
    })
  },

  // --- MADA: RIWAYA (4 Materials) ---
  {
    id: G12-FAS-RIW-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Uchambuzi wa Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Riwaya ni aina ya fasihi inayosimulia hadithi ndefu. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa riwaya?,
      options: [Muundo, wahusika, na mazingira., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Muundo, wahusika, na mazingira."
    })
  },
  {
    id: "G12-FAS-RIW-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Uchambuzi wa Riwaya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Wahusika katika riwaya huwa na jukumu tofauti. Ni nani mhusika anayepambana na shida kuu katika riwaya?,
      options: [Mhusika mkuu, Mhusika mdogo, "Mhusika msaidizi, Mhusika wa kubuni"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mhusika mkuu
    })
  },
  {
    id: G12-FAS-RIW-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Riwaya,
    subtopic: "Uchambuzi wa Riwaya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Mazingira ni wakati na mahali ambapo riwaya inatokea. Ni kipi kati ya hivi ni mazingira ya riwaya?,
      options: [Mahali na wakati, Wahusika, Mazungumzo", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Mahali na wakati"
    })
  },
  {
    id: "G12-FAS-RIW-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Riwaya",
    subtopic: "Uchambuzi wa Riwaya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mada ni wazo kuu la riwaya. Ni ipi kati ya hizi ni mada inayojitokeza katika riwaya?,
      options: [Ujasiri na upendo, Mizani, "Mshororo, Ubeti"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ujasiri na upendo
    })
  },

  // --- MADA: METHALI, NAHAU, NA VITENDAWILI (4 Materials) ---
  {
    id: G12-FAS-MET-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Methali, Nahau, na Vitendawili,
    subtopic: "Uchambuzi wa Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Methali ni maneno ya hekima yanayotumiwa katika fasihi. Ni ipi kati ya hizi ni methali?,
      options: [Haraka haraka haina baraka., Usiku wa maneno, Mimi ni mwenyewe", "Kazi ni kazi].sort(() => Math.random() - 0.5),
      correctAnswer: Haraka haraka haina baraka."
    })
  },
  {
    id: "G12-FAS-MET-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali", Nahau, na Vitendawili",
    subtopic: "Uchambuzi wa Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Nahau ni maneno ya pamoja yenye maana ya mfano. Ni ipi kati ya hizi ni nahau?,
      options: [Kufuma kwa dharuba, Haraka haraka haina baraka., "Mimi ni mwenyewe, Kazi ni kazi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kufuma kwa dharuba
    })
  },
  {
    id: G12-FAS-MET-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Methali, Nahau, na Vitendawili,
    subtopic: "Uchambuzi wa Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Vitendawili ni aina ya fasihi simulizi inayotumiwa kwa mchezo wa akili. Ni kipi kati ya hivi ni kitendawili?,
      options: [Wewe ni nani? Mgeni ni mji., Mimi ni nini? Nimekaa kando ya barabara., Kazi ni kazi.", "Haraka haraka haina baraka.].sort(() => Math.random() - 0.5),
      correctAnswer: Mimi ni nini? Nimekaa kando ya barabara."
    })
  },
  {
    id: "G12-FAS-MET-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Methali", Nahau, na Vitendawili",
    subtopic: "Uchambuzi wa Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vitendawili vinaweza kugawanywa katika makundi kulingana na mada. Ni kundi lipi kati ya hivi ni la vitendawili?,
      options: [Vitendawili vya wanyama, Vitendawili vya nyumbani, "Vitendawili vya shule, Vyote vya juu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vyote vya juu
    })
  },

  // --- MADA: MATINI TEULE (4 Materials) ---
  {
    id: G12-FAS-TEU-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Matini Teule,
    subtopic: "Uchambuzi wa Riwaya Teule",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Riwaya teule ni kazi za fasihi zilizochaguliwa kwa uchambuzi. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa riwaya teule?,
      options: [Wahusika, mazingira, na mada., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Wahusika, mazingira, na mada."
    })
  },
  {
    id: "G12-FAS-TEU-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Matini Teule",
    subtopic: "Uchambuzi wa Tamthilia Teule,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Tamthilia teule ni kazi za fasihi zilizochaguliwa kwa uchambuzi. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa tamthilia teule?,
      options: [Wahusika, mazingira, na mada., Mizani na kinai., "Mshororo na ubeti., Methali na vitendawili."].sort(() => Math.random() - 0.5),
      correctAnswer: "Wahusika, mazingira, na mada.
    })
  },
  {
    id: G12-FAS-TEU-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Matini Teule,
    subtopic: "Uchambuzi wa Ushairi Teule",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ushairi teule ni kazi za fasihi zilizochaguliwa kwa uchambuzi. Ni kipi kati ya hivi ni muhimu katika uchambuzi wa ushairi teule?,
      options: [Mizani, kinai, na picha za ushairi., Wahusika., Mazingira.", "Mada.].sort(() => Math.random() - 0.5),
      correctAnswer: Mizani, kinai, na picha za ushairi."
    })
  },
  {
    id: "G12-FAS-TEU-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Matini Teule",
    subtopic: "Uchambuzi wa Matini Teule,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Uchambuzi wa matini teule unahitaji uangalizi wa lugha ya mwandishi. Ni kipi kati ya hivi ni lugha ya kifasihi?,
      options: [Lugha yenye picha za ushairi na tafauti., Lugha ya mazungumzo tu., "Lugha ya kitaaluma tu., Lugha rahisi."].sort(() => Math.random() - 0.5),
      correctAnswer: "Lugha yenye picha za ushairi na tafauti.
    })
  },

  // --- MADA: UCHAMBUZI WA LUGHA (4 Materials) ---
  {
    id: G12-FAS-LUG-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Lugha,
    subtopic: "Lugha ya Kifasihi",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Lugha ya kifasihi ni lugha inayotumiwa katika kazi za fasihi. Ni ipi kati ya hizi ni sifa ya lugha ya kifasihi?,
      options: [Picha za ushairi na tafauti za lugha., Lugha rahisi., Lugha ya mazungumzo.", "Lugha ya kitaaluma.].sort(() => Math.random() - 0.5),
      correctAnswer: Picha za ushairi na tafauti za lugha."
    })
  },
  {
    id: "G12-FAS-LUG-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Lugha",
    subtopic: "Picha za Ushairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Picha za ushairi ni muhimu katika ushairi wa Kiswahili. Ni ipi kati ya hizi ni picha za ushairi?,
      options: [Simili, tashbihi, na mfano., Mizani na kinai., "Mshororo na ubeti., Methali na vitendawili."].sort(() => Math.random() - 0.5),
      correctAnswer: "Simili, tashbihi, na mfano.
    })
  },
  {
    id: G12-FAS-LUG-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Lugha,
    subtopic: "Tafauti za Lugha",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tafauti za lugha ni mabadiliko ya maana katika lugha. Ni ipi kati ya hizi ni tafauti za lugha?,
      options: [Kiswahili sanifu na Kiswahili cha mitaani., Mizani., Kinai.", "Mshororo.].sort(() => Math.random() - 0.5),
      correctAnswer: Kiswahili sanifu na Kiswahili cha mitaani."
    })
  },
  {
    id: "G12-FAS-LUG-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Uchambuzi wa Lugha",
    subtopic: "Tafauti za Lugha,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Tafauti za lugha hutumiwa katika fasihi kwa madhumuni mbalimbali. Ni kipi kati ya hivi ni tafauti za lugha?,
      options: [Kiswahili cha mitaani, Kiswahili sanifu, "Kiswahili cha shule, Kiswahili cha mtaa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kiswahili cha mitaani
    })
  },

  // --- MADA: UANDISHI WA INSHA (4 Materials) ---
  {
    id: G12-FAS-INS-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Uandishi wa Insha,
    subtopic: "Kuandika Insha Kuhusu Fasihi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Insha kuhusu fasihi inahitaji muundo na lugha sahihi. Ni kipi kati ya hivi ni muhimu katika kuandika insha kuhusu fasihi?,
      options: [Utangulizi, mwili, na hitimisho., Mizani na kinai., Mshororo na ubeti.", "Methali na vitendawili.].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi, mwili, na hitimisho."
    })
  },
  {
    id: "G12-FAS-INS-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Uandishi wa Insha",
    subtopic: "Kuandika Insha Kuhusu Fasihi,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Insha nzuri kuhusu fasihi inapaswa kuwa na mada wazi. Ni kipi kati ya hivi ni mada inayofaa kwa insha kuhusu fasihi?,
      options: [Uchambuzi wa kazi ya fasihi., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Uchambuzi wa kazi ya fasihi.
    })
  },
  {
    id: G12-FAS-INS-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Uandishi wa Insha,
    subtopic: "Kuandika Insha Kuhusu Fasihi",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Insha kuhusu fasihi inapaswa kuwa na mawazo yaliyo wazi. Ni kipi kati ya hivi ni muhimu katika kuandika insha?,
      options: [Kutumia lugha ya fasaha., Kutumia mizani., Kutumia kinai.", "Kutumia mshororo.].sort(() => Math.random() - 0.5),
      correctAnswer: Kutumia lugha ya fasaha."
    })
  },
  {
    id: "G12-FAS-INS-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Uandishi wa Insha",
    subtopic: "Kuandika Insha Kuhusu Fasihi,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Insha nzuri inapaswa kuwa na hoja zilizo wazi na mifano. Ni kipi kati ya hivi ni muhimu katika kuandika insha?,
      options: [Kutumia mifano kutoka kwa kazi za fasihi., Kutumia mizani., "Kutumia kinai., Kutumia mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kutumia mifano kutoka kwa kazi za fasihi.
    })
  },

  // --- MADA: FASIHI NA MAISHA (4 Materials) ---
  {
    id: G12-FAS-MAI-01",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi na Maisha,
    subtopic: "Fasihi Kama Kioo cha Maisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fasihi inaweza kuwa kioo cha maisha ya jamii. Ni kipi kati ya hivi ni jukumu la fasihi katika kuakisi maisha?,
      options: [Kuonyesha hali halisi ya jamii., Kuharibu maisha., Kupuuza maisha.", "Kusahaulisha maisha.].sort(() => Math.random() - 0.5),
      correctAnswer: Kuonyesha hali halisi ya jamii."
    })
  },
  {
    id: "G12-FAS-MAI-02",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi na Maisha",
    subtopic: "Fasihi Kama Kioo cha Maisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Wandishi wa fasihi huakisi maisha ya jamii katika kazi zao. Ni kipi kati ya hivi ni mfano wa fasihi inayoakisi maisha?,
      options: [Riwaya inayoonyesha hali ya jamii., Mizani., "Kinai., Mshororo."].sort(() => Math.random() - 0.5),
      correctAnswer: "Riwaya inayoonyesha hali ya jamii.
    })
  },
  {
    id: G12-FAS-MAI-03",
    grade: "Grade 12,
    subject: Fasihi ya Kiswahili",
    topic: "Fasihi na Maisha,
    subtopic: "Fasihi Kama Kioo cha Maisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fasihi inaweza kuwa chombo cha mabadiliko katika jamii. Ni kipi kati ya hivi ni mchango wa fasihi katika mabadiliko ya jamii?,
      options: [Kuelimisha na kuhamasisha mabadiliko., Kuharibu jamii., Kupuuza jamii.", "Kuudhi jamii.].sort(() => Math.random() - 0.5),
      correctAnswer: Kuelimisha na kuhamasisha mabadiliko."
    })
  },
  {
    id: "G12-FAS-MAI-04",
    grade: "Grade 12",
    subject: "Fasihi ya Kiswahili",
    topic: "Fasihi na Maisha",
    subtopic: "Fasihi na Mazingira,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Fasihi inahusiana kwa karibu na mazingira ya jamii. Ni kipi kati ya hivi ni umuhimu wa fasihi kwa mazingira?,
      options: [Inaonyesha mazingira na mila ya jamii., Inaharibu mazingira., "Haijalishi mazingira., Inapuuza mazingira."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inaonyesha mazingira na mila ya jamii."
    })
  }

];


