export const biologyTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD BIOLOGY SYLLABUS)
  // =========================================================================

  // --- INTRODUCTION TO BIOLOGY (3 Materials) ---
  {
    id: "G10-BIO-IB-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Introduction to Biology",
    subtopic: "Scientific Method",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: "The scientific method is a systematic approach used by biologists to investigate living organisms and natural phenomena. Which of the following correctly describes the sequence of steps in the scientific method as applied to biological research?,
      options: [
        Observation, formulation of a hypothesis, experimentation, data collection and analysis, conclusion, and communication of results.,
        Hypothesis formation, observation, experimentation, data analysis, and conclusion.,
        "Experimentation, observation, hypothesis, data analysis, and conclusion.,
        Observation, experimentation, hypothesis formation, data collection, and communication."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Observation, formulation of a hypothesis, experimentation, data collection and analysis, conclusion, and communication of results.
    })
  },
  {
    id: G10-BIO-IB-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Introduction to Biology,
    subtopic: "Laboratory Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Laboratory safety is essential in biology investigations to prevent accidents and ensure accurate results. Which of the following is the most important safety practice when handling biological specimens and chemicals in a biology laboratory?,
      options: [
        Wearing appropriate personal protective equipment (PPE) such as gloves, goggles, and laboratory coats, and following the laboratory safety rules at all times.,
        Working alone in the laboratory to minimize distractions.,
        Using chemicals without reading the labels as long as they are familiar.",
        "Disposing of all biological waste in regular trash bins.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Wearing appropriate personal protective equipment (PPE) such as gloves, goggles, and laboratory coats, and following the laboratory safety rules at all times."
    })
  },
  {
    id: "G10-BIO-IB-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Introduction to Biology",
    subtopic: "Branches of Biology,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Biology has many branches that focus on different aspects of living organisms. Which branch of biology is specifically concerned with the study of the structure and function of cells and their organelles?,
      options: [
        Cell biology (cytology) is the branch of biology that studies the structure, function, and behavior of cells, including their organelles and physiological processes.,
        Ecology studies the interactions between organisms and their environment.,
        "Genetics studies heredity and variation in organisms.,
        Anatomy studies the structure of organisms and their parts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cell biology (cytology) is the branch of biology that studies the structure, function, and behavior of cells, including their organelles and physiological processes.
    })
  },

  // --- CELL BIOLOGY (5 Materials) ---
  {
    id: G10-BIO-CB-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Cell Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The cell is the basic structural and functional unit of all living organisms. Which of the following correctly describes the structure and function of the nucleus in a eukaryotic cell?,
      options: [
        The nucleus is a membrane-bound organelle that contains the cell's genetic material (DNA) organized into chromosomes, and is the site of transcription and regulation of gene expression.,
        The nucleus is responsible for protein synthesis and is located in the cytoplasm.,
        The nucleus is the site of cellular respiration and energy production.",
        "The nucleus is responsible for photosynthesis in plant cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The nucleus is a membrane-bound organelle that contains the cell's genetic material (DNA) organized into chromosomes, and is the site of transcription and regulation of gene expression."
    })
  },
  {
    id: "G10-BIO-CB-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Biology",
    subtopic: "Organelles,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Organelles are specialized structures within cells that perform specific functions. Which of the following organelles is responsible for the production of ATP through cellular respiration and is often referred to as the 'powerhouse' of the cell?,
      options: [
        Mitochondria are responsible for aerobic respiration, producing ATP (energy) through the electron transport chain and oxidative phosphorylation, using oxygen and glucose.,
        Chloroplasts are responsible for photosynthesis in plant cells.,
        "Ribosomes are responsible for protein synthesis.,
        The Golgi apparatus is responsible for modifying and packaging proteins."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mitochondria are responsible for aerobic respiration, producing ATP (energy) through the electron transport chain and oxidative phosphorylation, using oxygen and glucose.
    })
  },
  {
    id: G10-BIO-CB-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Organelles",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The endomembrane system consists of organelles that work together to modify, package, and transport proteins and lipids. Which of the following organelles is responsible for modifying, sorting, and packaging proteins for secretion or delivery to other organelles?,
      options: [
        The Golgi apparatus is responsible for modifying, sorting, and packaging proteins and lipids into vesicles for transport to their final destinations within or outside the cell.,
        The endoplasmic reticulum (ER) is responsible for protein synthesis.,
        Lysosomes are responsible for intracellular digestion.",
        "Peroxisomes are responsible for lipid metabolism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Golgi apparatus is responsible for modifying, sorting, and packaging proteins and lipids into vesicles for transport to their final destinations within or outside the cell."
    })
  },
  {
    id: "G10-BIO-CB-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Biology",
    subtopic: "Cell Membrane Transport,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The cell membrane is selectively permeable and controls the movement of substances into and out of the cell. Which of the following processes describes the net movement of water molecules across a selectively permeable membrane from a region of higher water concentration to a region of lower water concentration?,
      options: [
        Osmosis is the net movement of water molecules across a selectively permeable membrane from a region of higher water potential (lower solute concentration) to a region of lower water potential (higher solute concentration).,
        Diffusion is the movement of any substance from high to low concentration.,
        "Active transport requires energy to move substances against their concentration gradient.,
        Facilitated diffusion uses transport proteins to move substances across the membrane."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Osmosis is the net movement of water molecules across a selectively permeable membrane from a region of higher water potential (lower solute concentration) to a region of lower water potential (higher solute concentration).
    })
  },
  {
    id: G10-BIO-CB-05",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Cell Membrane Transport",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Active transport is essential for maintaining concentration gradients and transporting substances against their concentration gradient. Which of the following correctly describes the sodium-potassium pump and its role in nerve cells?,
      options: [
        The sodium-potassium pump uses ATP to actively transport three sodium ions out of the cell and two potassium ions into the cell, maintaining the electrochemical gradient essential for nerve impulse transmission.,
        The sodium-potassium pump transports sodium and potassium ions passively without using energy.,
        The sodium-potassium pump transports water molecules across the cell membrane.",
        "The sodium-potassium pump is only found in plant cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The sodium-potassium pump uses ATP to actively transport three sodium ions out of the cell and two potassium ions into the cell, maintaining the electrochemical gradient essential for nerve impulse transmission."
    })
  },

  // --- CELL DIVISION (4 Materials) ---
  {
    id: "G10-BIO-CD-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Division",
    subtopic: "Mitosis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Mitosis is a type of cell division that results in two genetically identical daughter cells. Which of the following correctly describes the stages of mitosis in the correct sequence?,
      options: [
        Prophase, metaphase, anaphase, and telophase (PMAT) are the stages of mitosis, followed by cytokinesis to separate the cytoplasm and produce two daughter cells.,
        Metaphase, prophase, anaphase, and telophase.,
        "Telophase, anaphase, metaphase, and prophase.,
        Anaphase, metaphase, prophase, and telophase."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Prophase, metaphase, anaphase, and telophase (PMAT) are the stages of mitosis, followed by cytokinesis to separate the cytoplasm and produce two daughter cells.
    })
  },
  {
    id: G10-BIO-CD-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Division,
    subtopic: "Mitosis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Mitosis is essential for growth, repair, and asexual reproduction in organisms. Which of the following explains why mitosis is important in the process of wound healing in multicellular organisms?,
      options: [
        Mitosis produces genetically identical cells that replace damaged or lost cells at the wound site, allowing for tissue regeneration and repair.,
        Mitosis produces cells with different genetic compositions to adapt to the wound site.,
        Mitosis creates new organs to replace damaged ones.",
        "Mitosis prevents the formation of scar tissue.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mitosis produces genetically identical cells that replace damaged or lost cells at the wound site, allowing for tissue regeneration and repair."
    })
  },
  {
    id: "G10-BIO-CD-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Division",
    subtopic: "Meiosis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Meiosis is a specialized type of cell division that produces gametes for sexual reproduction. Which of the following is a key event during meiosis that contributes to genetic diversity in offspring?,
      options: [
        Crossing over during prophase I of meiosis involves the exchange of genetic material between homologous chromosomes, producing new combinations of alleles and increasing genetic variation.,
        The independent assortment of chromosomes occurs during mitosis.,
        "Meiosis does not produce genetic variation.,
        Crossing over occurs during metaphase of meiosis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crossing over during prophase I of meiosis involves the exchange of genetic material between homologous chromosomes, producing new combinations of alleles and increasing genetic variation.
    })
  },
  {
    id: G10-BIO-CD-04",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Division,
    subtopic: "Meiosis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Meiosis results in cells with half the number of chromosomes of the parent cell. Which of the following correctly describes the difference between the products of mitosis and meiosis?,
      options: [
        Mitosis produces two diploid daughter cells that are genetically identical, while meiosis produces four haploid cells that are genetically varied, each with half the number of chromosomes.,
        Mitosis produces haploid cells, while meiosis produces diploid cells.,
        Mitosis produces genetically varied cells, while meiosis produces identical cells.",
        "Both mitosis and meiosis produce identical diploid cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mitosis produces two diploid daughter cells that are genetically identical, while meiosis produces four haploid cells that are genetically varied, each with half the number of chromosomes."
    })
  },

  // --- NUTRITION IN PLANTS (5 Materials) ---
  {
    id: "G10-BIO-NP-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Photosynthesis is the process by which green plants convert light energy into chemical energy in the form of glucose. Which of the following correctly describes the role of chlorophyll in photosynthesis?,
      options: [
        Chlorophyll is a pigment that absorbs light energy from the sun, specifically in the blue and red wavelengths, and transfers this energy to the reaction centers of the photosystems to drive the light-dependent reactions.,
        Chlorophyll releases oxygen during photosynthesis.,
        "Chlorophyll is responsible for the Calvin cycle reactions.,
        Chlorophyll absorbs light in the green wavelength."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chlorophyll is a pigment that absorbs light energy from the sun, specifically in the blue and red wavelengths, and transfers this energy to the reaction centers of the photosystems to drive the light-dependent reactions.
    })
  },
  {
    id: G10-BIO-NP-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Plants,
    subtopic: "Photosynthesis",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The light-dependent reactions of photosynthesis occur in the thylakoid membranes and produce energy carriers for the Calvin cycle. Which of the following is the main product of the light-dependent reactions?,
      options: [
        ATP and NADPH are the main products of the light-dependent reactions, providing energy and reducing power for the Calvin cycle to fix carbon dioxide into glucose.,
        Glucose is produced in the light-dependent reactions.,
        Oxygen is the only product of the light-dependent reactions.",
        "Carbon dioxide is consumed in the light-dependent reactions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: ATP and NADPH are the main products of the light-dependent reactions, providing energy and reducing power for the Calvin cycle to fix carbon dioxide into glucose."
    })
  },
  {
    id: "G10-BIO-NP-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Mineral Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Plants require essential mineral nutrients for growth and development. Which of the following is a macronutrient that is essential for plant growth and is a major component of proteins and nucleic acids?,
      options: [
        Nitrogen is a macronutrient essential for plant growth, as it is a major component of amino acids (proteins), nucleic acids (DNA and RNA), and chlorophyll.,
        Calcium is a macronutrient that is a major component of proteins.,
        "Sulfur is a micronutrient.,
        Chlorine is a macronutrient needed for photosynthesis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nitrogen is a macronutrient essential for plant growth, as it is a major component of amino acids (proteins), nucleic acids (DNA and RNA), and chlorophyll.
    })
  },
  {
    id: G10-BIO-NP-04",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Plants,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Plants have specialized transport systems to move water, minerals, and nutrients. Which of the following tissues is responsible for transporting water and dissolved minerals from the roots to the rest of the plant?,
      options: [
        Xylem is the tissue responsible for transporting water and dissolved minerals from the roots to the leaves and other parts of the plant through a process driven by transpiration pull and cohesion-tension.,
        Phloem transports water from the roots to the leaves.,
        Cambium is responsible for water transport.",
        "Epidermis transports water in plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Xylem is the tissue responsible for transporting water and dissolved minerals from the roots to the leaves and other parts of the plant through a process driven by transpiration pull and cohesion-tension."
    })
  },
  {
    id: "G10-BIO-NP-05",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Transport in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Translocation is the movement of organic nutrients in the phloem from sources (where produced) to sinks (where used or stored). Which of the following is a major force driving transport in the phloem?,
      options: [
        The pressure-flow hypothesis explains that a pressure gradient is created by the active loading of sucrose into the phloem at the source (e.g., leaves) and the unloading at sinks, driving the flow of sap.,
        Transpiration pull drives phloem transport.,
        "Osmosis is the only driving force in phloem transport.,
        Active transport is not involved in phloem loading."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The pressure-flow hypothesis explains that a pressure gradient is created by the active loading of sucrose into the phloem at the source (e.g., leaves) and the unloading at sinks, driving the flow of sap.
    })
  },

  // --- NUTRITION IN ANIMALS (4 Materials) ---
  {
    id: G10-BIO-NA-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Animals,
    subtopic: "Digestive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The digestive system in animals is responsible for breaking down food into absorbable nutrients. Which of the following correctly describes the path of food from the mouth to the stomach in the human digestive system?,
      options: [
        Food travels from the mouth through the esophagus, where peristalsis moves it to the stomach for further digestion by gastric juices containing hydrochloric acid and pepsin.,
        Food travels directly from the mouth to the small intestine.,
        Food travels from the mouth through the trachea to the stomach.",
        "Food travels from the mouth through the pharynx directly to the large intestine.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Food travels from the mouth through the esophagus, where peristalsis moves it to the stomach for further digestion by gastric juices containing hydrochloric acid and pepsin."
    })
  },
  {
    id: "G10-BIO-NA-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Animals",
    subtopic: "Digestion,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Enzymes are biological catalysts that speed up chemical reactions in the digestive system. Which of the following enzymes is responsible for breaking down starch into maltose in the mouth and small intestine?,
      options: [
        Amylase (salivary amylase and pancreatic amylase) is responsible for breaking down starch (a polysaccharide) into maltose (a disaccharide) in the mouth and small intestine.,
        Lipase breaks down fats into fatty acids and glycerol.,
        "Protease breaks down proteins into amino acids.,
        Nuclease breaks down nucleic acids."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Amylase (salivary amylase and pancreatic amylase) is responsible for breaking down starch (a polysaccharide) into maltose (a disaccharide) in the mouth and small intestine.
    })
  },
  {
    id: G10-BIO-NA-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Animals,
    subtopic: "Absorption",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Absorption of nutrients occurs primarily in the small intestine. Which of the following structural adaptations of the small intestine increases the surface area for nutrient absorption?,
      options: [
        Villi and microvilli are finger-like projections that increase the surface area of the small intestine, allowing for more efficient absorption of nutrients into the bloodstream and lymphatic system.,
        The large intestine has villi for absorption.,
        The stomach has microvilli for absorption.",
        "The small intestine is only smooth inside.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Villi and microvilli are finger-like projections that increase the surface area of the small intestine, allowing for more efficient absorption of nutrients into the bloodstream and lymphatic system."
    })
  },
  {
    id: "G10-BIO-NA-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Animals",
    subtopic: "Digestive Disorders,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Digestive disorders can affect the absorption of nutrients and overall health. Which of the following is a condition characterized by inflammation of the stomach lining, often caused by the bacterium Helicobacter pylori or prolonged use of NSAIDs?,
      options: [
        Gastritis is the inflammation of the stomach lining, caused by factors such as H. pylori infection, alcohol consumption, smoking, or prolonged use of non-steroidal anti-inflammatory drugs (NSAIDs).,
        Ulcers are only caused by stress.",
        "Crohn's disease affects only the stomach.,
        Colitis affects only the small intestine."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gastritis is the inflammation of the stomach lining, caused by factors such as H. pylori infection, alcohol consumption, smoking, or prolonged use of non-steroidal anti-inflammatory drugs (NSAIDs).
    })
  },

  // --- TRANSPORT SYSTEMS (4 Materials) ---
  {
    id: G10-BIO-TS-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Transport Systems,
    subtopic: "Circulatory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The circulatory system is responsible for transporting nutrients, oxygen, hormones, and waste products throughout the body. Which of the following correctly describes the function of arteries in the human circulatory system?,
      options: [
        Arteries carry oxygenated blood away from the heart to the body tissues under high pressure, except for the pulmonary artery which carries deoxygenated blood to the lungs for oxygenation.,
        Arteries carry deoxygenated blood from the body tissues back to the heart.,
        Arteries are the site of gas exchange between blood and tissues.",
        "Arteries have thin walls and valves to prevent backflow.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Arteries carry oxygenated blood away from the heart to the body tissues under high pressure, except for the pulmonary artery which carries deoxygenated blood to the lungs for oxygenation."
    })
  },
  {
    id: "G10-BIO-TS-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Transport Systems",
    subtopic: "Blood,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Blood is composed of various components that perform different functions. Which of the following blood components is responsible for transporting oxygen from the lungs to the body tissues?,
      options: [
        Red blood cells (erythrocytes) contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport.,
        White blood cells are responsible for oxygen transport.,
        "Platelets transport oxygen in the blood.,
        Plasma is the main carrier of oxygen."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Red blood cells (erythrocytes) contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport.
    })
  },
  {
    id: G10-BIO-TS-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Transport Systems,
    subtopic: "Lymphatic System",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The lymphatic system is a network of vessels that works with the circulatory system to maintain fluid balance and support immune function. Which of the following is a primary function of the lymphatic system?,
      options: [
        The lymphatic system returns interstitial fluid (lymph) to the bloodstream, transports lipids absorbed from the small intestine, and plays a crucial role in immune defense through the production and circulation of lymphocytes.,
        The lymphatic system produces red blood cells.,
        The lymphatic system transports oxygen to tissues.",
        "The lymphatic system is only involved in digestion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The lymphatic system returns interstitial fluid (lymph) to the bloodstream, transports lipids absorbed from the small intestine, and plays a crucial role in immune defense through the production and circulation of lymphocytes."
    })
  },
  {
    id: "G10-BIO-TS-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Transport Systems",
    subtopic: "Cardiovascular Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Cardiovascular diseases are a major health concern worldwide. Which of the following is a major risk factor for atherosclerosis (hardening of the arteries)?,
      options: [
        Atherosclerosis is caused by the accumulation of plaque (fatty deposits, cholesterol, and other substances) on artery walls, which is associated with poor diet, smoking, lack of exercise, high blood pressure, and genetic predisposition.,
        Atherosclerosis is caused by eating too much protein.,
        "Regular exercise increases the risk of atherosclerosis.,
        Atherosclerosis is caused by excess water intake."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Atherosclerosis is caused by the accumulation of plaque (fatty deposits, cholesterol, and other substances) on artery walls, which is associated with poor diet, smoking, lack of exercise, high blood pressure, and genetic predisposition.
    })
  },

  // --- RESPIRATORY SYSTEMS (4 Materials) ---
  {
    id: G10-BIO-RS-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Respiratory Systems,
    subtopic: "Gas Exchange",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Gas exchange is the process by which oxygen is taken in and carbon dioxide is released. In the human respiratory system, where does the exchange of gases between the air and the bloodstream primarily occur?,
      options: [
        Gas exchange occurs in the alveoli of the lungs, where oxygen diffuses from the air into the blood across the alveolar-capillary membrane, and carbon dioxide diffuses in the opposite direction.,
        Gas exchange occurs in the trachea.,
        Gas exchange occurs in the bronchi.",
        "Gas exchange occurs in the nasal cavity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Gas exchange occurs in the alveoli of the lungs, where oxygen diffuses from the air into the blood across the alveolar-capillary membrane, and carbon dioxide diffuses in the opposite direction."
    })
  },
  {
    id: "G10-BIO-RS-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Respiratory Systems",
    subtopic: "Breathing Mechanisms,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Breathing (ventilation) is the mechanical process of moving air into and out of the lungs. Which of the following describes the process of inspiration (inhalation) in humans?,
      options: [
        Inspiration occurs when the diaphragm contracts and moves downward, and the intercostal muscles contract, expanding the chest cavity and decreasing air pressure, causing air to rush into the lungs.,
        Inspiration occurs when the diaphragm relaxes and moves upward.,
        "Inspiration is a passive process that requires no muscle contraction.,
        Inspiration only occurs through the mouth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Inspiration occurs when the diaphragm contracts and moves downward, and the intercostal muscles contract, expanding the chest cavity and decreasing air pressure, causing air to rush into the lungs.
    })
  },
  {
    id: G10-BIO-RS-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Respiratory Systems,
    subtopic: "Transport of Gases",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Oxygen is transported in the blood primarily by hemoglobin. How is carbon dioxide transported in the blood from the tissues to the lungs?,
      options: [
        Carbon dioxide is transported in the blood as bicarbonate ions (70%), dissolved in plasma (7%), and bound to hemoglobin (20%). Bicarbonate is formed when CO₂ reacts with water in the presence of carbonic anhydrase.,
        Carbon dioxide is only transported dissolved in plasma.,
        Carbon dioxide is transported only by hemoglobin.",
        "Carbon dioxide is converted into oxygen in the blood.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Carbon dioxide is transported in the blood as bicarbonate ions (70%), dissolved in plasma (7%), and bound to hemoglobin (20%). Bicarbonate is formed when CO₂ reacts with water in the presence of carbonic anhydrase."
    })
  },
  {
    id: "G10-BIO-RS-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Respiratory Systems",
    subtopic: "Respiratory Disorders,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Various factors affect respiratory health. Which of the following chronic respiratory diseases is characterized by inflammation and narrowing of the airways, often triggered by allergens or environmental factors, leading to difficulty breathing?,
      options: [
        "Asthma is a chronic respiratory disease characterized by inflammation and narrowing of the airways, causing wheezing, shortness of breath, and coughing, often triggered by allergens, exercise, or stress.,
        Tuberculosis is a chronic airway inflammation disease.",
        "Pneumonia is an allergic reaction.,
        Bronchitis is a genetic respiratory disease."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Asthma is a chronic respiratory disease characterized by inflammation and narrowing of the airways, causing wheezing, shortness of breath, and coughing, often triggered by allergens, exercise, or stress.
    })
  },

  // --- EXCRETION AND HOMEOSTASIS (6 Materials) ---
  {
    id: G10-BIO-EH-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Excretory Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Excretion is the process of removing metabolic waste products from the body. Which of the following is the primary nitrogenous waste product excreted by the human body?,
      options: [
        Urea is the primary nitrogenous waste product excreted by the human body, produced in the liver from the breakdown of amino acids (deamination) and transported via the blood to the kidneys for excretion in urine.,
        Uric acid is the primary nitrogenous waste in humans.,
        Ammonia is the primary nitrogenous waste in humans.",
        "Creatinine is the primary nitrogenous waste in humans.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Urea is the primary nitrogenous waste product excreted by the human body, produced in the liver from the breakdown of amino acids (deamination) and transported via the blood to the kidneys for excretion in urine."
    })
  },
  {
    id: "G10-BIO-EH-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Kidney Function,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The kidneys are responsible for filtering blood and producing urine. Which of the following describes the correct sequence of urine formation in the nephron?,
      options: [
        Glomerular filtration, tubular reabsorption, and tubular secretion are the three steps of urine formation in the nephron, producing urine that is excreted from the body.,
        Tubular secretion, glomerular filtration, and tubular reabsorption.,
        "Tubular reabsorption, glomerular filtration, and tubular secretion.,
        Glomerular filtration, tubular secretion, and tubular reabsorption."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Glomerular filtration, tubular reabsorption, and tubular secretion are the three steps of urine formation in the nephron, producing urine that is excreted from the body.
    })
  },
  {
    id: G10-BIO-EH-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Osmoregulation",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Osmoregulation is the regulation of water and salt balance in the body. Which of the following hormones is responsible for regulating water reabsorption in the kidneys by increasing the permeability of the collecting ducts to water?,
      options: [
        Antidiuretic hormone (ADH) is released by the posterior pituitary gland and increases water reabsorption in the kidneys, reducing urine output and helping to regulate blood osmolality.,
        Aldosterone regulates water reabsorption by controlling sodium reabsorption.,
        Insulin regulates water balance in the kidneys.",
        "Glucagon regulates water reabsorption.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Antidiuretic hormone (ADH) is released by the posterior pituitary gland and increases water reabsorption in the kidneys, reducing urine output and helping to regulate blood osmolality."
    })
  },
  {
    id: "G10-BIO-EH-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Thermoregulation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Thermoregulation is the process of maintaining the body's internal temperature within a narrow range. Which of the following mechanisms is used by the human body to cool down when the core temperature rises above normal?,
      options: [
        Vasodilation (widening of blood vessels near the skin surface) increases heat loss, and sweating cools the body through evaporation, lowering the core temperature.,
        Vasoconstriction reduces heat loss.,
        "Shivering generates heat and cools the body.,
        Piloerection (goosebumps) increases heat loss."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vasodilation (widening of blood vessels near the skin surface) increases heat loss, and sweating cools the body through evaporation, lowering the core temperature.
    })
  },
  {
    id: G10-BIO-EH-05",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Homeostasis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Homeostasis is the maintenance of a stable internal environment. Which of the following is a component of a homeostatic control system that detects changes in the internal environment?,
      options: [
        A receptor (sensor) detects changes in the internal environment (stimulus) and sends signals to the control center (integrator) to initiate a response to maintain homeostasis.,
        An effector detects changes in the internal environment.,
        The control center is responsible for detecting changes.",
        "The stimulus is the component that detects changes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A receptor (sensor) detects changes in the internal environment (stimulus) and sends signals to the control center (integrator) to initiate a response to maintain homeostasis."
    })
  },
  {
    id: "G10-BIO-EH-06",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Homeostasis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Negative feedback is a mechanism that counteracts changes to maintain homeostasis. Which of the following is an example of negative feedback in the human body?,
      options: [
        Negative feedback in thermoregulation: when body temperature rises above normal, mechanisms such as sweating and vasodilation are activated to reduce the temperature back to normal.,
        Positive feedback in thermoregulation: when temperature rises, more heat is generated.,
        "Negative feedback only works in the endocrine system.,
        Blood clotting is an example of negative feedback."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Negative feedback in thermoregulation: when body temperature rises above normal, mechanisms such as sweating and vasodilation are activated to reduce the temperature back to normal.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD BIOLOGY SYLLABUS)
  // =========================================================================

  // --- CLASSIFICATION OF LIVING THINGS (4 Materials) ---
  {
    id: G11-BIO-CL-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Classification of Living Things,
    subtopic: "Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Living organisms are classified into kingdoms based on their characteristics. Which of the following kingdoms includes organisms that are eukaryotic, multicellular, heterotrophic, and have cell walls made of chitin?,
      options: [
        Fungi are eukaryotic, multicellular (or unicellular), heterotrophic organisms with cell walls made of chitin. They obtain nutrients through absorption and play important roles as decomposers and pathogens.,
        Plantae are eukaryotic, photosynthetic organisms with cell walls made of cellulose.,
        Animalia are eukaryotic, multicellular, heterotrophic organisms that lack cell walls.",
        "Protista are eukaryotic organisms that do not fit into the other kingdoms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Fungi are eukaryotic, multicellular (or unicellular), heterotrophic organisms with cell walls made of chitin. They obtain nutrients through absorption and play important roles as decomposers and pathogens."
    })
  },
  {
    id: "G11-BIO-CL-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Classification of Living Things",
    subtopic: "Characteristics of Kingdoms,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The kingdom Monera (Prokaryotae) includes prokaryotic organisms. Which of the following is a characteristic feature of organisms in the kingdom Monera?,
      options: [
        Organisms in kingdom Monera are prokaryotic, meaning they lack a true nucleus and membrane-bound organelles. They have a single circular chromosome and divide by binary fission.,
        Organisms in kingdom Monera have a true nucleus and membrane-bound organelles.,
        "Organisms in kingdom Monera are always multicellular.,
        Organisms in kingdom Monera use photosynthesis for energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organisms in kingdom Monera are prokaryotic, meaning they lack a true nucleus and membrane-bound organelles. They have a single circular chromosome and divide by binary fission.
    })
  },
  {
    id: G11-BIO-CL-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Classification of Living Things,
    subtopic: "Binomial Nomenclature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Binomial nomenclature is the system of naming organisms with two names. Which of the following correctly describes the structure of a scientific name under binomial nomenclature?,
      options: [
        The scientific name consists of the genus name (capitalized) and the species epithet (lowercase), both italicized or underlined, e.g., Homo sapiens.,
        The scientific name consists only of the genus name.,
        The scientific name consists of the family and species names.",
        "The scientific name consists of the species name and common name.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The scientific name consists of the genus name (capitalized) and the species epithet (lowercase), both italicized or underlined, e.g., Homo sapiens."
    })
  },
  {
    id: "G11-BIO-CL-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Classification of Living Things",
    subtopic: "Taxonomic Hierarchy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The taxonomic hierarchy organizes life from broad groups to specific species. Which of the following shows the correct order of taxonomic ranks from most inclusive (broadest) to most exclusive (narrowest)?,
      options: [
        Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species (DKPCOFGS) is the correct order from most inclusive to most exclusive.,
        Species, Genus, Family, Order, Class, Phylum, Kingdom, Domain.,
        "Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species is incorrect.,
        Kingdom, Domain, Phylum, Class, Order, Family, Genus, Species."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species (DKPCOFGS) is the correct order from most inclusive to most exclusive.
    })
  },

  // --- CELL BIOLOGY ADVANCED (4 Materials) ---
  {
    id: G11-BIO-CB-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Cell Biology Advanced,
    subtopic: "Cell Specialization",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Cell specialization (differentiation) results in cells with specific functions. Which of the following is an example of a specialized animal cell that has lost its nucleus to maximize its capacity for carrying oxygen?,
      options: [
        Red blood cells (erythrocytes) are specialized cells that have lost their nucleus and organelles to maximize hemoglobin content and oxygen-carrying capacity, allowing for efficient oxygen transport.,
        White blood cells are specialized for oxygen transport.,
        Nerve cells are specialized for carrying oxygen.",
        "Muscle cells have no nucleus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Red blood cells (erythrocytes) are specialized cells that have lost their nucleus and organelles to maximize hemoglobin content and oxygen-carrying capacity, allowing for efficient oxygen transport."
    })
  },
  {
    id: "G11-BIO-CB-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Cell Biology Advanced",
    subtopic: "Tissue Organization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Tissues are groups of similar cells that work together to perform a specific function. Which of the following is a type of animal tissue that covers body surfaces, lines body cavities, and forms glands?,
      options: [
        "Epithelial tissue covers body surfaces, lines internal cavities and organs, and forms glands that secrete substances such as hormones, enzymes, and mucus.,
        Connective tissue provides support and structure.",
        "Muscle tissue enables movement.,
        Nervous tissue transmits signals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Epithelial tissue covers body surfaces, lines internal cavities and organs, and forms glands that secrete substances such as hormones, enzymes, and mucus.
    })
  },
  {
    id: G11-BIO-CB-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Cell Biology Advanced,
    subtopic: "Organ Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Organ systems are groups of organs that work together to perform major functions. Which of the following organ systems is responsible for the transport of oxygen, nutrients, hormones, and waste products throughout the body?,
      options: [
        The circulatory system is responsible for transporting oxygen, nutrients, hormones, and waste products throughout the body via the blood, heart, and blood vessels.,
        The respiratory system transports nutrients.,
        The digestive system transports oxygen.",
        "The excretory system transports hormones.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The circulatory system is responsible for transporting oxygen, nutrients, hormones, and waste products throughout the body via the blood, heart, and blood vessels."
    })
  },
  {
    id: "G11-BIO-CB-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Cell Biology Advanced",
    subtopic: "Cell Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Cell communication is essential for coordinating cellular activities. Which of the following describes the function of gap junctions in cell communication?,
      options: [
        Gap junctions are channels that allow direct communication and the exchange of small molecules and ions between adjacent cells, enabling rapid signaling and coordination.,
        Gap junctions are involved in long-distance signaling.,
        "Gap junctions are found only in plant cells.,
        Gap junctions prevent communication between cells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gap junctions are channels that allow direct communication and the exchange of small molecules and ions between adjacent cells, enabling rapid signaling and coordination.
    })
  },

  // --- PLANT PHYSIOLOGY (4 Materials) ---
  {
    id: G11-BIO-PP-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Plant Physiology,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Plants transport water and nutrients through specialized tissues. Which of the following explains how water moves from the roots to the leaves in tall trees against gravity?,
      options: [
        The cohesion-tension theory explains that water moves up the xylem through a combination of transpiration pull (evaporation from leaves), cohesion between water molecules, and adhesion to xylem walls, creating a continuous column of water.,
        Water moves in plants through active transport only.,
        Water moves in plants due to root pressure exclusively.",
        "Water moves in plants through osmosis only.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The cohesion-tension theory explains that water moves up the xylem through a combination of transpiration pull (evaporation from leaves), cohesion between water molecules, and adhesion to xylem walls, creating a continuous column of water."
    })
  },
  {
    id: "G11-BIO-PP-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Plant Physiology",
    subtopic: "Plant Hormones,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Plant hormones regulate growth and development in plants. Which of the following plant hormones is responsible for promoting stem elongation, fruit growth, and seed germination?,
      options: [
        "Gibberellins promote stem elongation, stimulate flowering and fruit development, and help in seed germination by promoting the production of amylase in cereal grains.,
        Auxins promote leaf abscission.",
        "Cytokinins promote senescence.,
        Abscisic acid promotes growth and development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gibberellins promote stem elongation, stimulate flowering and fruit development, and help in seed germination by promoting the production of amylase in cereal grains.
    })
  },
  {
    id: G11-BIO-PP-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Plant Physiology,
    subtopic: "Tropisms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Tropisms are directional growth responses of plants to external stimuli. Which of the following is the correct description of phototropism?,
      options: [
        Phototropism is the directional growth of a plant toward (positive phototropism) or away from (negative phototropism) light, mediated by the hormone auxin.,
        Phototropism is the growth of plants in response to gravity.,
        Phototropism is the growth of plants in response to touch.",
        "Phototropism is the growth of plants in response to chemicals.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Phototropism is the directional growth of a plant toward (positive phototropism) or away from (negative phototropism) light, mediated by the hormone auxin."
    })
  },
  {
    id: "G11-BIO-PP-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Plant Physiology",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The Calvin cycle is the stage of photosynthesis that fixes carbon dioxide into organic molecules. Which of the following describes the role of RuBisCO (ribulose-1,5-bisphosphate carboxylase/oxygenase) in the Calvin cycle?,
      options: [
        RuBisCO is the enzyme that catalyzes the first step of the Calvin cycle, the carboxylation of ribulose-1,5-bisphosphate (RuBP) with carbon dioxide, producing two molecules of 3-phosphoglycerate (3-PGA).,
        RuBisCO is involved in the light-dependent reactions.",
        "RuBisCO catalyzes the reduction of 3-PGA to G3P.,
        RuBisCO is not involved in the Calvin cycle."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "RuBisCO is the enzyme that catalyzes the first step of the Calvin cycle, the carboxylation of ribulose-1,5-bisphosphate (RuBP) with carbon dioxide, producing two molecules of 3-phosphoglycerate (3-PGA).
    })
  },

  // --- ANIMAL PHYSIOLOGY (5 Materials) ---
  {
    id: G11-BIO-AP-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Nervous System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The nervous system coordinates the body's responses to internal and external stimuli. Which of the following correctly describes the transmission of an impulse across a synapse?,
      options: [
        Nerve impulses are transmitted across a synapse when neurotransmitters are released from the presynaptic neuron, diffuse across the synaptic cleft, and bind to receptors on the postsynaptic neuron, generating an action potential.,
        Nerve impulses are transmitted directly through gap junctions.,
        Nerve impulses are transmitted through the bloodstream.",
        "Nerve impulses are transmitted by electrical signals only.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Nerve impulses are transmitted across a synapse when neurotransmitters are released from the presynaptic neuron, diffuse across the synaptic cleft, and bind to receptors on the postsynaptic neuron, generating an action potential."
    })
  },
  {
    id: "G11-BIO-AP-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Animal Physiology",
    subtopic: "Nervous System,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The nervous system is divided into the central and peripheral nervous systems. Which of the following is a function of the autonomic nervous system?,
      options: [
        The autonomic nervous system controls involuntary body functions such as heartbeat, breathing, digestion, and blood pressure, acting through the sympathetic (fight or flight) and parasympathetic (rest and digest) divisions.,
        The autonomic nervous system controls voluntary muscle movement.,
        "The autonomic nervous system is part of the somatic nervous system.,
        The autonomic nervous system controls conscious thought."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The autonomic nervous system controls involuntary body functions such as heartbeat, breathing, digestion, and blood pressure, acting through the sympathetic (fight or flight) and parasympathetic (rest and digest) divisions.
    })
  },
  {
    id: G11-BIO-AP-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Endocrine System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The endocrine system uses hormones to regulate body functions. Which of the following hormones is produced by the adrenal medulla and triggers the 'fight or flight' response?,
      options: [
        Epinephrine (adrenaline) is produced by the adrenal medulla and triggers the 'fight or flight' response, increasing heart rate, blood pressure, and blood glucose levels in preparation for action.,
        Cortisol is produced by the adrenal medulla.,
        Insulin is produced by the adrenal medulla.",
        "Aldosterone is produced by the adrenal medulla.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Epinephrine (adrenaline) is produced by the adrenal medulla and triggers the 'fight or flight' response, increasing heart rate, blood pressure, and blood glucose levels in preparation for action."
    })
  },
  {
    id: "G11-BIO-AP-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Animal Physiology",
    subtopic: "Sense Organs,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Sense organs detect stimuli from the environment and convert them into nerve impulses. Which of the following structures in the eye is responsible for focusing light onto the retina?,
      options: [
        The lens is responsible for focusing light onto the retina by changing its shape (accommodation) to adjust the focal length for near and far vision.,
        The cornea focuses light onto the retina.,
        "The iris focuses light onto the retina.,
        The pupil focuses light onto the retina."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The lens is responsible for focusing light onto the retina by changing its shape (accommodation) to adjust the focal length for near and far vision.
    })
  },
  {
    id: G11-BIO-AP-05",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Sense Organs",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The ear is responsible for hearing and balance. Which of the following structures in the inner ear is responsible for maintaining balance (equilibrium) and detecting changes in head position?,
      options: [
        The semicircular canals are responsible for detecting changes in head position and maintaining balance (equilibrium), working with the vestibular system to provide sensory information about head orientation and movement.,
        The cochlea is responsible for balance.,
        The eardrum is responsible for balance.",
        "The auditory nerve is responsible for balance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The semicircular canals are responsible for detecting changes in head position and maintaining balance (equilibrium), working with the vestibular system to provide sensory information about head orientation and movement."
    })
  },

  // --- REPRODUCTION (5 Materials) ---
  {
    id: "G11-BIO-RE-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Reproduction in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Sexual reproduction in flowering plants involves the fusion of male and female gametes. Which of the following describes the process of double fertilization in angiosperms?,
      options: [
        In double fertilization, one sperm cell fertilizes the egg to form the zygote (2n), while the second sperm cell fuses with the polar nuclei to form the endosperm (3n), which nourishes the developing embryo.,
        In double fertilization, two sperm cells fertilize two eggs.,
        "Double fertilization only occurs in gymnosperms.,
        Double fertilization results in the formation of two zygotes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In double fertilization, one sperm cell fertilizes the egg to form the zygote (2n), while the second sperm cell fuses with the polar nuclei to form the endosperm (3n), which nourishes the developing embryo.
    })
  },
  {
    id: G11-BIO-RE-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Reproduction,
    subtopic: "Reproduction in Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Animals reproduce either sexually or asexually. Which of the following is an advantage of sexual reproduction over asexual reproduction?,
      options: [
        Sexual reproduction produces genetic variation in offspring, increasing the potential for adaptation to changing environments and reducing the risk of extinction from diseases that affect genetically uniform populations.,
        Sexual reproduction is faster than asexual reproduction.,
        Sexual reproduction requires only one parent.",
        "Sexual reproduction produces offspring identical to the parent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sexual reproduction produces genetic variation in offspring, increasing the potential for adaptation to changing environments and reducing the risk of extinction from diseases that affect genetically uniform populations."
    })
  },
  {
    id: "G11-BIO-RE-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Human Reproduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The human reproductive system is specialized for producing gametes and supporting conception. Which of the following is the correct description of the path of a sperm cell from production to fertilization?,
      options: [
        Sperm are produced in the seminiferous tubules of the testes, mature in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to reach the female reproductive tract for fertilization in the fallopian tube (oviduct).,
        Sperm are produced in the prostate gland and travel through the ureter.,
        "Sperm are produced in the seminal vesicles and travel through the urethra.,
        Sperm are produced in the fallopian tubes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sperm are produced in the seminiferous tubules of the testes, mature in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to reach the female reproductive tract for fertilization in the fallopian tube (oviduct).
    })
  },
  {
    id: G11-BIO-RE-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Reproduction,
    subtopic: "Human Reproduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The menstrual cycle is regulated by hormones and prepares the female body for pregnancy. Which of the following hormones is responsible for ovulation and the development of the corpus luteum?,
      options: [
        Luteinizing hormone (LH) is responsible for triggering ovulation (release of the egg from the ovary) and the development of the corpus luteum, which produces progesterone to prepare the uterine lining for pregnancy.,
        Follicle-stimulating hormone (FSH) is responsible for ovulation.,
        Estrogen is responsible for ovulation.",
        "Progesterone is responsible for ovulation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Luteinizing hormone (LH) is responsible for triggering ovulation (release of the egg from the ovary) and the development of the corpus luteum, which produces progesterone to prepare the uterine lining for pregnancy."
    })
  },
  {
    id: "G11-BIO-RE-05",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Contraception,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Contraception is the intentional prevention of pregnancy. Which of the following contraceptive methods works by preventing ovulation and thickening cervical mucus, making it difficult for sperm to reach the egg?,
      options: [
        The combined oral contraceptive pill (the pill) works by providing synthetic estrogen and progesterone to prevent ovulation and thicken cervical mucus, creating a barrier to fertilization and preventing implantation.,
        The barrier method (condoms) prevents ovulation.",
        "The intrauterine device (IUD) works by preventing ovulation.,
        The rhythm method works by preventing ovulation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The combined oral contraceptive pill (the pill) works by providing synthetic estrogen and progesterone to prevent ovulation and thicken cervical mucus, creating a barrier to fertilization and preventing implantation.
    })
  },

  // --- GENETICS (5 Materials) ---
  {
    id: G11-BIO-GE-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "Mendelian Genetics",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Mendelian genetics describes the patterns of inheritance of traits. In a monohybrid cross between two heterozygous individuals (Aa × Aa), what is the expected genotypic ratio of the offspring?,
      options: [
        The expected genotypic ratio is 1 AA : 2 Aa : 1 aa (1:2:1), as determined by the principles of Mendelian genetics when crossing two heterozygotes.,
        The expected genotypic ratio is 3:1 (dominant:recessive).,
        The expected genotypic ratio is 1:1 (homozygous:heterozygous).",
        "The expected genotypic ratio is 9:3:3:1, typical of dihybrid crosses.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The expected genotypic ratio is 1 AA : 2 Aa : 1 aa (1:2:1), as determined by the principles of Mendelian genetics when crossing two heterozygotes."
    })
  },
  {
    id: "G11-BIO-GE-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Genetics",
    subtopic: "Mendelian Genetics,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The law of independent assortment states that genes for different traits segregate independently during gamete formation. Which of the following is an exception to the law of independent assortment?,
      options: [
        Linked genes (genes located close together on the same chromosome) do not assort independently and are more likely to be inherited together, which is an exception to the law of independent assortment.,
        Alleles on different chromosomes do not assort independently.,
        "All genes assort independently regardless of their position.,
        Sex-linked genes assort independently of other genes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Linked genes (genes located close together on the same chromosome) do not assort independently and are more likely to be inherited together, which is an exception to the law of independent assortment.
    })
  },
  {
    id: G11-BIO-GE-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "DNA and RNA",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " DNA carries the genetic information in cells. Which of the following correctly describes the structure of DNA and the pairing of nitrogenous bases?,
      options: [
        DNA is a double helix with two antiparallel strands held together by hydrogen bonds between complementary nitrogenous bases: adenine pairs with thymine (A-T), and guanine pairs with cytosine (G-C).,
        DNA is a single-stranded molecule with A-G and T-C base pairing.,
        DNA is a triple helix with A-U and C-G base pairing.",
        "DNA is a circular molecule with no base pairing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: DNA is a double helix with two antiparallel strands held together by hydrogen bonds between complementary nitrogenous bases: adenine pairs with thymine (A-T), and guanine pairs with cytosine (G-C)."
    })
  },
  {
    id: "G11-BIO-GE-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Genetics",
    subtopic: "Protein Synthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Protein synthesis involves transcription and translation. Which of the following describes the process of transcription in protein synthesis?,
      options: [
        Transcription is the process in which a segment of DNA is used as a template to synthesize a complementary messenger RNA (mRNA) molecule, which carries the genetic information from the nucleus to the ribosome.,
        Transcription is the process of synthesizing proteins at the ribosome.,
        "Transcription is the process of translating mRNA into protein.,
        Transcription occurs only in the cytoplasm."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Transcription is the process in which a segment of DNA is used as a template to synthesize a complementary messenger RNA (mRNA) molecule, which carries the genetic information from the nucleus to the ribosome.
    })
  },
  {
    id: G11-BIO-GE-05",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "Protein Synthesis",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Translation is the process by which the genetic code in mRNA is used to synthesize proteins. Which of the following is the role of tRNA (transfer RNA) in translation?,
      options: [
        tRNA carries specific amino acids to the ribosome and uses its anticodon to recognize the codon on mRNA, ensuring that the correct amino acid is added to the growing polypeptide chain in the correct sequence.,
        tRNA carries the genetic code from the nucleus to the ribosome.,
        tRNA is involved in transcription and translation.",
        "tRNA makes up the ribosomes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: tRNA carries specific amino acids to the ribosome and uses its anticodon to recognize the codon on mRNA, ensuring that the correct amino acid is added to the growing polypeptide chain in the correct sequence."
    })
  },

  // --- GROWTH AND DEVELOPMENT (4 Materials) ---
  {
    id: "G11-BIO-GD-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Growth and Development",
    subtopic: "Growth Curves,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Growth curves show patterns of growth in organisms over time. Which of the following describes the logistic growth curve of a population in a limited environment?,
      options: [
        A logistic growth curve shows an initial exponential phase, followed by a deceleration phase as resources become limited, and finally reaches a carrying capacity (plateau) where the population stabilizes at the maximum sustainable size.,
        A logistic growth curve shows unlimited exponential growth.,
        "A logistic growth curve shows a decline in population size.,
        A logistic growth curve is always linear."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A logistic growth curve shows an initial exponential phase, followed by a deceleration phase as resources become limited, and finally reaches a carrying capacity (plateau) where the population stabilizes at the maximum sustainable size.
    })
  },
  {
    id: G11-BIO-GD-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Growth and Development,
    subtopic: "Embryonic Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Embryonic development involves a series of stages from fertilization to birth. Which of the following correctly describes the stage of embryonic development in which the blastocyst implants into the uterine lining?,
      options: [
        Implantation occurs when the blastocyst, after traveling through the fallopian tube and reaching the uterus, attaches to and embeds itself into the endometrial lining, allowing the embryo to receive nutrients and oxygen from the mother.,
        Implantation occurs before fertilization.,
        Implantation is the formation of the placenta.",
        "Implantation is the development of the heart.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Implantation occurs when the blastocyst, after traveling through the fallopian tube and reaching the uterus, attaches to and embeds itself into the endometrial lining, allowing the embryo to receive nutrients and oxygen from the mother."
    })
  },
  {
    id: "G11-BIO-GD-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Growth and Development",
    subtopic: "Germ Layer Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "During embryonic development, three germ layers are formed. Which of the following tissues and organs develop from the ectoderm?,
      options: [
        The ectoderm gives rise to the skin (epidermis), hair, nails, the nervous system (brain, spinal cord, and nerves), and sensory organs (eyes, ears, nose).,
        The ectoderm gives rise to muscles and bones.",
        "The ectoderm gives rise to the digestive system.,
        The ectoderm gives rise to the circulatory system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The ectoderm gives rise to the skin (epidermis), hair, nails, the nervous system (brain, spinal cord, and nerves), and sensory organs (eyes, ears, nose).
    })
  },
  {
    id: G11-BIO-GD-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Growth and Development,
    subtopic: "Factors Affecting Growth",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Growth is influenced by both genetic and environmental factors. Which of the following environmental factors has the most significant effect on plant growth and development?,
      options: [
        Light, temperature, water, and nutrients are the most significant environmental factors affecting plant growth. Light provides energy for photosynthesis, temperature affects metabolic processes, water is essential for turgor and transport, and nutrients provide the building blocks for growth.,
        Wind is the most important environmental factor.,
        Altitude is the most important factor.",
        "Density of planting is the most important environmental factor.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Light, temperature, water, and nutrients are the most significant environmental factors affecting plant growth. Light provides energy for photosynthesis, temperature affects metabolic processes, water is essential for turgor and transport, and nutrients provide the building blocks for growth."
    })
  },

  // --- MICROBIOLOGY (4 Materials) ---
  {
    id: "G11-BIO-MB-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Microbiology",
    subtopic: "Bacteria,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Bacteria are prokaryotic microorganisms with diverse roles in ecosystems. Which of the following correctly describes the structure of bacterial cells and their method of reproduction?,
      options: [
        Bacterial cells are prokaryotic with a single circular chromosome, a cell wall made of peptidoglycan, and no membrane-bound organelles. They reproduce asexually by binary fission (division into two identical daughter cells).,
        Bacteria are eukaryotic with a nucleus.,
        "Bacteria reproduce by mitosis like eukaryotic cells.,
        Bacteria have chloroplasts for photosynthesis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bacterial cells are prokaryotic with a single circular chromosome, a cell wall made of peptidoglycan, and no membrane-bound organelles. They reproduce asexually by binary fission (division into two identical daughter cells).
    })
  },
  {
    id: G11-BIO-MB-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Microbiology,
    subtopic: "Viruses",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Viruses are non-cellular infectious agents that require a host cell to replicate. Which of the following explains why viruses are not considered living organisms?,
      options: [
        Viruses are not considered living because they cannot replicate independently, lack cellular organization (no cytoplasm, organelles, or metabolism), and require a host cell to produce new virus particles.,
        Viruses are considered living because they contain DNA or RNA.,
        Viruses are considered living because they can cause disease.",
        "Viruses are considered living because they have a cell wall.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Viruses are not considered living because they cannot replicate independently, lack cellular organization (no cytoplasm, organelles, or metabolism), and require a host cell to produce new virus particles."
    })
  },
  {
    id: "G11-BIO-MB-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Microbiology",
    subtopic: "Fungi,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Fungi are eukaryotic organisms that play important roles as decomposers, pathogens, and symbionts. Which of the following is a key characteristic of fungi that distinguishes them from plants?,
      options: [
        "Fungi are heterotrophic (absorb nutrients from their environment) and have cell walls made of chitin, while plants are autotrophic and have cell walls made of cellulose.,
        Fungi are autotrophic and have cellulose cell walls.",
        "Fungi have chloroplasts and can photosynthesize.,
        Fungi are prokaryotic organisms."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Fungi are heterotrophic (absorb nutrients from their environment) and have cell walls made of chitin, while plants are autotrophic and have cell walls made of cellulose.
    })
  },
  {
    id: G11-BIO-MB-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Microbiology,
    subtopic: "Protozoa",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Protozoa are single-celled eukaryotic organisms that are often motile. Which of the following is a protozoan that causes malaria and is transmitted by the Anopheles mosquito?,
      options: [
        Plasmodium is a protozoan parasite that causes malaria. It is transmitted through the bite of an infected female Anopheles mosquito, where the parasite undergoes development in the mosquito before being injected into the human host.,
        Trypanosoma causes malaria.,
        Entamoeba causes malaria.",
        "Giardia causes malaria.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plasmodium is a protozoan parasite that causes malaria. It is transmitted through the bite of an infected female Anopheles mosquito, where the parasite undergoes development in the mosquito before being injected into the human host."
    })
  }`nexport const biologyTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD BIOLOGY SYLLABUS)
  // =========================================================================
  {
    id: "G10-BIO-IB-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Introduction to Biology",
    subtopic: "Scientific Method",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: "The scientific method is a systematic approach used by biologists to investigate living organisms and natural phenomena. Which of the following correctly describes the sequence of steps in the scientific method as applied to biological research?,
      options: [
        Observation, formulation of a hypothesis, experimentation, data collection and analysis, conclusion, and communication of results.,
        Hypothesis formation, observation, experimentation, data analysis, and conclusion.,
        "Experimentation, observation, hypothesis, data analysis, and conclusion.,
        Observation, experimentation, hypothesis formation, data collection, and communication."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Observation, formulation of a hypothesis, experimentation, data collection and analysis, conclusion, and communication of results.
    })
  },
  {
    id: G10-BIO-IB-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Introduction to Biology,
    subtopic: "Laboratory Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Laboratory safety is essential in biology investigations to prevent accidents and ensure accurate results. Which of the following is the most important safety practice when handling biological specimens and chemicals in a biology laboratory?,
      options: [
        Wearing appropriate personal protective equipment (PPE) such as gloves, goggles, and laboratory coats, and following the laboratory safety rules at all times.,
        Working alone in the laboratory to minimize distractions.,
        Using chemicals without reading the labels as long as they are familiar.",
        "Disposing of all biological waste in regular trash bins.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Wearing appropriate personal protective equipment (PPE) such as gloves, goggles, and laboratory coats, and following the laboratory safety rules at all times."
    })
  },
  {
    id: "G10-BIO-IB-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Introduction to Biology",
    subtopic: "Branches of Biology,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Biology has many branches that focus on different aspects of living organisms. Which branch of biology is specifically concerned with the study of the structure and function of cells and their organelles?,
      options: [
        Cell biology (cytology) is the branch of biology that studies the structure, function, and behavior of cells, including their organelles and physiological processes.,
        Ecology studies the interactions between organisms and their environment.,
        "Genetics studies heredity and variation in organisms.,
        Anatomy studies the structure of organisms and their parts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cell biology (cytology) is the branch of biology that studies the structure, function, and behavior of cells, including their organelles and physiological processes.
    })
  },
  {
    id: G10-BIO-CB-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Cell Structure",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The cell is the basic structural and functional unit of all living organisms. Which of the following correctly describes the structure and function of the nucleus in a eukaryotic cell?,
      options: [
        The nucleus is a membrane-bound organelle that contains the cell's genetic material (DNA) organized into chromosomes, and is the site of transcription and regulation of gene expression.,
        The nucleus is responsible for protein synthesis and is located in the cytoplasm.,
        The nucleus is the site of cellular respiration and energy production.",
        "The nucleus is responsible for photosynthesis in plant cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The nucleus is a membrane-bound organelle that contains the cell's genetic material (DNA) organized into chromosomes, and is the site of transcription and regulation of gene expression."
    })
  },
  {
    id: "G10-BIO-CB-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Biology",
    subtopic: "Organelles,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Organelles are specialized structures within cells that perform specific functions. Which of the following organelles is responsible for the production of ATP through cellular respiration and is often referred to as the 'powerhouse' of the cell?,
      options: [
        Mitochondria are responsible for aerobic respiration, producing ATP (energy) through the electron transport chain and oxidative phosphorylation, using oxygen and glucose.,
        Chloroplasts are responsible for photosynthesis in plant cells.,
        "Ribosomes are responsible for protein synthesis.,
        The Golgi apparatus is responsible for modifying and packaging proteins."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mitochondria are responsible for aerobic respiration, producing ATP (energy) through the electron transport chain and oxidative phosphorylation, using oxygen and glucose.
    })
  },
  {
    id: G10-BIO-CB-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Organelles",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The endomembrane system consists of organelles that work together to modify, package, and transport proteins and lipids. Which of the following organelles is responsible for modifying, sorting, and packaging proteins for secretion or delivery to other organelles?,
      options: [
        The Golgi apparatus is responsible for modifying, sorting, and packaging proteins and lipids into vesicles for transport to their final destinations within or outside the cell.,
        The endoplasmic reticulum (ER) is responsible for protein synthesis.,
        Lysosomes are responsible for intracellular digestion.",
        "Peroxisomes are responsible for lipid metabolism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Golgi apparatus is responsible for modifying, sorting, and packaging proteins and lipids into vesicles for transport to their final destinations within or outside the cell."
    })
  },
  {
    id: "G10-BIO-CB-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Biology",
    subtopic: "Cell Membrane Transport,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The cell membrane is selectively permeable and controls the movement of substances into and out of the cell. Which of the following processes describes the net movement of water molecules across a selectively permeable membrane from a region of higher water concentration to a region of lower water concentration?,
      options: [
        Osmosis is the net movement of water molecules across a selectively permeable membrane from a region of higher water potential (lower solute concentration) to a region of lower water potential (higher solute concentration).,
        Diffusion is the movement of any substance from high to low concentration.,
        "Active transport requires energy to move substances against their concentration gradient.,
        Facilitated diffusion uses transport proteins to move substances across the membrane."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Osmosis is the net movement of water molecules across a selectively permeable membrane from a region of higher water potential (lower solute concentration) to a region of lower water potential (higher solute concentration).
    })
  },
  {
    id: G10-BIO-CB-05",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Biology,
    subtopic: "Cell Membrane Transport",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Active transport is essential for maintaining concentration gradients and transporting substances against their concentration gradient. Which of the following correctly describes the sodium-potassium pump and its role in nerve cells?,
      options: [
        The sodium-potassium pump uses ATP to actively transport three sodium ions out of the cell and two potassium ions into the cell, maintaining the electrochemical gradient essential for nerve impulse transmission.,
        The sodium-potassium pump transports sodium and potassium ions passively without using energy.,
        The sodium-potassium pump transports water molecules across the cell membrane.",
        "The sodium-potassium pump is only found in plant cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The sodium-potassium pump uses ATP to actively transport three sodium ions out of the cell and two potassium ions into the cell, maintaining the electrochemical gradient essential for nerve impulse transmission."
    })
  },
  {
    id: "G10-BIO-CD-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Division",
    subtopic: "Mitosis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Mitosis is a type of cell division that results in two genetically identical daughter cells. Which of the following correctly describes the stages of mitosis in the correct sequence?,
      options: [
        Prophase, metaphase, anaphase, and telophase (PMAT) are the stages of mitosis, followed by cytokinesis to separate the cytoplasm and produce two daughter cells.,
        Metaphase, prophase, anaphase, and telophase.,
        "Telophase, anaphase, metaphase, and prophase.,
        Anaphase, metaphase, prophase, and telophase."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Prophase, metaphase, anaphase, and telophase (PMAT) are the stages of mitosis, followed by cytokinesis to separate the cytoplasm and produce two daughter cells.
    })
  },
  {
    id: G10-BIO-CD-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Division,
    subtopic: "Mitosis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Mitosis is essential for growth, repair, and asexual reproduction in organisms. Which of the following explains why mitosis is important in the process of wound healing in multicellular organisms?,
      options: [
        Mitosis produces genetically identical cells that replace damaged or lost cells at the wound site, allowing for tissue regeneration and repair.,
        Mitosis produces cells with different genetic compositions to adapt to the wound site.,
        Mitosis creates new organs to replace damaged ones.",
        "Mitosis prevents the formation of scar tissue.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mitosis produces genetically identical cells that replace damaged or lost cells at the wound site, allowing for tissue regeneration and repair."
    })
  },
  {
    id: "G10-BIO-CD-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Cell Division",
    subtopic: "Meiosis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Meiosis is a specialized type of cell division that produces gametes for sexual reproduction. Which of the following is a key event during meiosis that contributes to genetic diversity in offspring?,
      options: [
        Crossing over during prophase I of meiosis involves the exchange of genetic material between homologous chromosomes, producing new combinations of alleles and increasing genetic variation.,
        The independent assortment of chromosomes occurs during mitosis.,
        "Meiosis does not produce genetic variation.,
        Crossing over occurs during metaphase of meiosis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crossing over during prophase I of meiosis involves the exchange of genetic material between homologous chromosomes, producing new combinations of alleles and increasing genetic variation.
    })
  },
  {
    id: G10-BIO-CD-04",
    grade: "Grade 10,
    subject: Biology",
    topic: "Cell Division,
    subtopic: "Meiosis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Meiosis results in cells with half the number of chromosomes of the parent cell. Which of the following correctly describes the difference between the products of mitosis and meiosis?,
      options: [
        Mitosis produces two diploid daughter cells that are genetically identical, while meiosis produces four haploid cells that are genetically varied, each with half the number of chromosomes.,
        Mitosis produces haploid cells, while meiosis produces diploid cells.,
        Mitosis produces genetically varied cells, while meiosis produces identical cells.",
        "Both mitosis and meiosis produce identical diploid cells.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mitosis produces two diploid daughter cells that are genetically identical, while meiosis produces four haploid cells that are genetically varied, each with half the number of chromosomes."
    })
  },
  {
    id: "G10-BIO-NP-01",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Photosynthesis is the process by which green plants convert light energy into chemical energy in the form of glucose. Which of the following correctly describes the role of chlorophyll in photosynthesis?,
      options: [
        Chlorophyll is a pigment that absorbs light energy from the sun, specifically in the blue and red wavelengths, and transfers this energy to the reaction centers of the photosystems to drive the light-dependent reactions.,
        Chlorophyll releases oxygen during photosynthesis.,
        "Chlorophyll is responsible for the Calvin cycle reactions.,
        Chlorophyll absorbs light in the green wavelength."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chlorophyll is a pigment that absorbs light energy from the sun, specifically in the blue and red wavelengths, and transfers this energy to the reaction centers of the photosystems to drive the light-dependent reactions.
    })
  },
  {
    id: G10-BIO-NP-02",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Plants,
    subtopic: "Photosynthesis",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The light-dependent reactions of photosynthesis occur in the thylakoid membranes and produce energy carriers for the Calvin cycle. Which of the following is the main product of the light-dependent reactions?,
      options: [
        ATP and NADPH are the main products of the light-dependent reactions, providing energy and reducing power for the Calvin cycle to fix carbon dioxide into glucose.,
        Glucose is produced in the light-dependent reactions.,
        Oxygen is the only product of the light-dependent reactions.",
        "Carbon dioxide is consumed in the light-dependent reactions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: ATP and NADPH are the main products of the light-dependent reactions, providing energy and reducing power for the Calvin cycle to fix carbon dioxide into glucose."
    })
  },
  {
    id: "G10-BIO-NP-03",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Mineral Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Plants require essential mineral nutrients for growth and development. Which of the following is a macronutrient that is essential for plant growth and is a major component of proteins and nucleic acids?,
      options: [
        Nitrogen is a macronutrient essential for plant growth, as it is a major component of amino acids (proteins), nucleic acids (DNA and RNA), and chlorophyll.,
        Calcium is a macronutrient that is a major component of proteins.,
        "Sulfur is a micronutrient.,
        Chlorine is a macronutrient needed for photosynthesis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nitrogen is a macronutrient essential for plant growth, as it is a major component of amino acids (proteins), nucleic acids (DNA and RNA), and chlorophyll.
    })
  },
  {
    id: G10-BIO-NP-04",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Plants,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Plants have specialized transport systems to move water, minerals, and nutrients. Which of the following tissues is responsible for transporting water and dissolved minerals from the roots to the rest of the plant?,
      options: [
        Xylem is the tissue responsible for transporting water and dissolved minerals from the roots to the leaves and other parts of the plant through a process driven by transpiration pull and cohesion-tension.,
        Phloem transports water from the roots to the leaves.,
        Cambium is responsible for water transport.",
        "Epidermis transports water in plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Xylem is the tissue responsible for transporting water and dissolved minerals from the roots to the leaves and other parts of the plant through a process driven by transpiration pull and cohesion-tension."
    })
  },
  {
    id: "G10-BIO-NP-05",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Plants",
    subtopic: "Transport in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Translocation is the movement of organic nutrients in the phloem from sources (where produced) to sinks (where used or stored). Which of the following is a major force driving transport in the phloem?,
      options: [
        The pressure-flow hypothesis explains that a pressure gradient is created by the active loading of sucrose into the phloem at the source (e.g., leaves) and the unloading at sinks, driving the flow of sap.,
        Transpiration pull drives phloem transport.,
        "Osmosis is the only driving force in phloem transport.,
        Active transport is not involved in phloem loading."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The pressure-flow hypothesis explains that a pressure gradient is created by the active loading of sucrose into the phloem at the source (e.g., leaves) and the unloading at sinks, driving the flow of sap.
    })
  },
  {
    id: G10-BIO-NA-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Animals,
    subtopic: "Digestive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The digestive system in animals is responsible for breaking down food into absorbable nutrients. Which of the following correctly describes the path of food from the mouth to the stomach in the human digestive system?,
      options: [
        Food travels from the mouth through the esophagus, where peristalsis moves it to the stomach for further digestion by gastric juices containing hydrochloric acid and pepsin.,
        Food travels directly from the mouth to the small intestine.,
        Food travels from the mouth through the trachea to the stomach.",
        "Food travels from the mouth through the pharynx directly to the large intestine.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Food travels from the mouth through the esophagus, where peristalsis moves it to the stomach for further digestion by gastric juices containing hydrochloric acid and pepsin."
    })
  },
  {
    id: "G10-BIO-NA-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Animals",
    subtopic: "Digestion,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Enzymes are biological catalysts that speed up chemical reactions in the digestive system. Which of the following enzymes is responsible for breaking down starch into maltose in the mouth and small intestine?,
      options: [
        Amylase (salivary amylase and pancreatic amylase) is responsible for breaking down starch (a polysaccharide) into maltose (a disaccharide) in the mouth and small intestine.,
        Lipase breaks down fats into fatty acids and glycerol.,
        "Protease breaks down proteins into amino acids.,
        Nuclease breaks down nucleic acids."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Amylase (salivary amylase and pancreatic amylase) is responsible for breaking down starch (a polysaccharide) into maltose (a disaccharide) in the mouth and small intestine.
    })
  },
  {
    id: G10-BIO-NA-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Nutrition in Animals,
    subtopic: "Absorption",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Absorption of nutrients occurs primarily in the small intestine. Which of the following structural adaptations of the small intestine increases the surface area for nutrient absorption?,
      options: [
        Villi and microvilli are finger-like projections that increase the surface area of the small intestine, allowing for more efficient absorption of nutrients into the bloodstream and lymphatic system.,
        The large intestine has villi for absorption.,
        The stomach has microvilli for absorption.",
        "The small intestine is only smooth inside.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Villi and microvilli are finger-like projections that increase the surface area of the small intestine, allowing for more efficient absorption of nutrients into the bloodstream and lymphatic system."
    })
  },
  {
    id: "G10-BIO-NA-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Nutrition in Animals",
    subtopic: "Digestive Disorders,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Digestive disorders can affect the absorption of nutrients and overall health. Which of the following is a condition characterized by inflammation of the stomach lining, often caused by the bacterium Helicobacter pylori or prolonged use of NSAIDs?,
      options: [
        Gastritis is the inflammation of the stomach lining, caused by factors such as H. pylori infection, alcohol consumption, smoking, or prolonged use of non-steroidal anti-inflammatory drugs (NSAIDs).,
        Ulcers are only caused by stress.",
        "Crohn's disease affects only the stomach.,
        Colitis affects only the small intestine."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gastritis is the inflammation of the stomach lining, caused by factors such as H. pylori infection, alcohol consumption, smoking, or prolonged use of non-steroidal anti-inflammatory drugs (NSAIDs).
    })
  },
  {
    id: G10-BIO-TS-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Transport Systems,
    subtopic: "Circulatory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The circulatory system is responsible for transporting nutrients, oxygen, hormones, and waste products throughout the body. Which of the following correctly describes the function of arteries in the human circulatory system?,
      options: [
        Arteries carry oxygenated blood away from the heart to the body tissues under high pressure, except for the pulmonary artery which carries deoxygenated blood to the lungs for oxygenation.,
        Arteries carry deoxygenated blood from the body tissues back to the heart.,
        Arteries are the site of gas exchange between blood and tissues.",
        "Arteries have thin walls and valves to prevent backflow.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Arteries carry oxygenated blood away from the heart to the body tissues under high pressure, except for the pulmonary artery which carries deoxygenated blood to the lungs for oxygenation."
    })
  },
  {
    id: "G10-BIO-TS-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Transport Systems",
    subtopic: "Blood,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Blood is composed of various components that perform different functions. Which of the following blood components is responsible for transporting oxygen from the lungs to the body tissues?,
      options: [
        Red blood cells (erythrocytes) contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport.,
        White blood cells are responsible for oxygen transport.,
        "Platelets transport oxygen in the blood.,
        Plasma is the main carrier of oxygen."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Red blood cells (erythrocytes) contain hemoglobin, an iron-containing protein that binds to oxygen in the lungs and releases it to tissues, enabling efficient oxygen transport.
    })
  },
  {
    id: G10-BIO-TS-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Transport Systems,
    subtopic: "Lymphatic System",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The lymphatic system is a network of vessels that works with the circulatory system to maintain fluid balance and support immune function. Which of the following is a primary function of the lymphatic system?,
      options: [
        The lymphatic system returns interstitial fluid (lymph) to the bloodstream, transports lipids absorbed from the small intestine, and plays a crucial role in immune defense through the production and circulation of lymphocytes.,
        The lymphatic system produces red blood cells.,
        The lymphatic system transports oxygen to tissues.",
        "The lymphatic system is only involved in digestion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The lymphatic system returns interstitial fluid (lymph) to the bloodstream, transports lipids absorbed from the small intestine, and plays a crucial role in immune defense through the production and circulation of lymphocytes."
    })
  },
  {
    id: "G10-BIO-TS-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Transport Systems",
    subtopic: "Cardiovascular Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Cardiovascular diseases are a major health concern worldwide. Which of the following is a major risk factor for atherosclerosis (hardening of the arteries)?,
      options: [
        Atherosclerosis is caused by the accumulation of plaque (fatty deposits, cholesterol, and other substances) on artery walls, which is associated with poor diet, smoking, lack of exercise, high blood pressure, and genetic predisposition.,
        Atherosclerosis is caused by eating too much protein.,
        "Regular exercise increases the risk of atherosclerosis.,
        Atherosclerosis is caused by excess water intake."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Atherosclerosis is caused by the accumulation of plaque (fatty deposits, cholesterol, and other substances) on artery walls, which is associated with poor diet, smoking, lack of exercise, high blood pressure, and genetic predisposition.
    })
  },
  {
    id: G10-BIO-RS-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Respiratory Systems,
    subtopic: "Gas Exchange",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Gas exchange is the process by which oxygen is taken in and carbon dioxide is released. In the human respiratory system, where does the exchange of gases between the air and the bloodstream primarily occur?,
      options: [
        Gas exchange occurs in the alveoli of the lungs, where oxygen diffuses from the air into the blood across the alveolar-capillary membrane, and carbon dioxide diffuses in the opposite direction.,
        Gas exchange occurs in the trachea.,
        Gas exchange occurs in the bronchi.",
        "Gas exchange occurs in the nasal cavity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Gas exchange occurs in the alveoli of the lungs, where oxygen diffuses from the air into the blood across the alveolar-capillary membrane, and carbon dioxide diffuses in the opposite direction."
    })
  },
  {
    id: "G10-BIO-RS-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Respiratory Systems",
    subtopic: "Breathing Mechanisms,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Breathing (ventilation) is the mechanical process of moving air into and out of the lungs. Which of the following describes the process of inspiration (inhalation) in humans?,
      options: [
        Inspiration occurs when the diaphragm contracts and moves downward, and the intercostal muscles contract, expanding the chest cavity and decreasing air pressure, causing air to rush into the lungs.,
        Inspiration occurs when the diaphragm relaxes and moves upward.,
        "Inspiration is a passive process that requires no muscle contraction.,
        Inspiration only occurs through the mouth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Inspiration occurs when the diaphragm contracts and moves downward, and the intercostal muscles contract, expanding the chest cavity and decreasing air pressure, causing air to rush into the lungs.
    })
  },
  {
    id: G10-BIO-RS-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Respiratory Systems,
    subtopic: "Transport of Gases",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Oxygen is transported in the blood primarily by hemoglobin. How is carbon dioxide transported in the blood from the tissues to the lungs?,
      options: [
        Carbon dioxide is transported in the blood as bicarbonate ions (70%), dissolved in plasma (7%), and bound to hemoglobin (20%). Bicarbonate is formed when CO₂ reacts with water in the presence of carbonic anhydrase.,
        Carbon dioxide is only transported dissolved in plasma.,
        Carbon dioxide is transported only by hemoglobin.",
        "Carbon dioxide is converted into oxygen in the blood.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Carbon dioxide is transported in the blood as bicarbonate ions (70%), dissolved in plasma (7%), and bound to hemoglobin (20%). Bicarbonate is formed when CO₂ reacts with water in the presence of carbonic anhydrase."
    })
  },
  {
    id: "G10-BIO-RS-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Respiratory Systems",
    subtopic: "Respiratory Disorders,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Various factors affect respiratory health. Which of the following chronic respiratory diseases is characterized by inflammation and narrowing of the airways, often triggered by allergens or environmental factors, leading to difficulty breathing?,
      options: [
        "Asthma is a chronic respiratory disease characterized by inflammation and narrowing of the airways, causing wheezing, shortness of breath, and coughing, often triggered by allergens, exercise, or stress.,
        Tuberculosis is a chronic airway inflammation disease.",
        "Pneumonia is an allergic reaction.,
        Bronchitis is a genetic respiratory disease."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Asthma is a chronic respiratory disease characterized by inflammation and narrowing of the airways, causing wheezing, shortness of breath, and coughing, often triggered by allergens, exercise, or stress.
    })
  },
  {
    id: G10-BIO-EH-01",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Excretory Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Excretion is the process of removing metabolic waste products from the body. Which of the following is the primary nitrogenous waste product excreted by the human body?,
      options: [
        Urea is the primary nitrogenous waste product excreted by the human body, produced in the liver from the breakdown of amino acids (deamination) and transported via the blood to the kidneys for excretion in urine.,
        Uric acid is the primary nitrogenous waste in humans.,
        Ammonia is the primary nitrogenous waste in humans.",
        "Creatinine is the primary nitrogenous waste in humans.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Urea is the primary nitrogenous waste product excreted by the human body, produced in the liver from the breakdown of amino acids (deamination) and transported via the blood to the kidneys for excretion in urine."
    })
  },
  {
    id: "G10-BIO-EH-02",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Kidney Function,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The kidneys are responsible for filtering blood and producing urine. Which of the following describes the correct sequence of urine formation in the nephron?,
      options: [
        Glomerular filtration, tubular reabsorption, and tubular secretion are the three steps of urine formation in the nephron, producing urine that is excreted from the body.,
        Tubular secretion, glomerular filtration, and tubular reabsorption.,
        "Tubular reabsorption, glomerular filtration, and tubular secretion.,
        Glomerular filtration, tubular secretion, and tubular reabsorption."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Glomerular filtration, tubular reabsorption, and tubular secretion are the three steps of urine formation in the nephron, producing urine that is excreted from the body.
    })
  },
  {
    id: G10-BIO-EH-03",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Osmoregulation",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Osmoregulation is the regulation of water and salt balance in the body. Which of the following hormones is responsible for regulating water reabsorption in the kidneys by increasing the permeability of the collecting ducts to water?,
      options: [
        Antidiuretic hormone (ADH) is released by the posterior pituitary gland and increases water reabsorption in the kidneys, reducing urine output and helping to regulate blood osmolality.,
        Aldosterone regulates water reabsorption by controlling sodium reabsorption.,
        Insulin regulates water balance in the kidneys.",
        "Glucagon regulates water reabsorption.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Antidiuretic hormone (ADH) is released by the posterior pituitary gland and increases water reabsorption in the kidneys, reducing urine output and helping to regulate blood osmolality."
    })
  },
  {
    id: "G10-BIO-EH-04",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Thermoregulation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Thermoregulation is the process of maintaining the body's internal temperature within a narrow range. Which of the following mechanisms is used by the human body to cool down when the core temperature rises above normal?,
      options: [
        Vasodilation (widening of blood vessels near the skin surface) increases heat loss, and sweating cools the body through evaporation, lowering the core temperature.,
        Vasoconstriction reduces heat loss.,
        "Shivering generates heat and cools the body.,
        Piloerection (goosebumps) increases heat loss."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vasodilation (widening of blood vessels near the skin surface) increases heat loss, and sweating cools the body through evaporation, lowering the core temperature.
    })
  },
  {
    id: G10-BIO-EH-05",
    grade: "Grade 10,
    subject: Biology",
    topic: "Excretion and Homeostasis,
    subtopic: "Homeostasis",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Homeostasis is the maintenance of a stable internal environment. Which of the following is a component of a homeostatic control system that detects changes in the internal environment?,
      options: [
        A receptor (sensor) detects changes in the internal environment (stimulus) and sends signals to the control center (integrator) to initiate a response to maintain homeostasis.,
        An effector detects changes in the internal environment.,
        The control center is responsible for detecting changes.",
        "The stimulus is the component that detects changes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A receptor (sensor) detects changes in the internal environment (stimulus) and sends signals to the control center (integrator) to initiate a response to maintain homeostasis."
    })
  },
  {
    id: "G10-BIO-EH-06",
    grade: "Grade 10",
    subject: "Biology",
    topic: "Excretion and Homeostasis",
    subtopic: "Homeostasis,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Negative feedback is a mechanism that counteracts changes to maintain homeostasis. Which of the following is an example of negative feedback in the human body?,
      options: [
        Negative feedback in thermoregulation: when body temperature rises above normal, mechanisms such as sweating and vasodilation are activated to reduce the temperature back to normal.,
        Positive feedback in thermoregulation: when temperature rises, more heat is generated.,
        "Negative feedback only works in the endocrine system.,
        Blood clotting is an example of negative feedback."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Negative feedback in thermoregulation: when body temperature rises above normal, mechanisms such as sweating and vasodilation are activated to reduce the temperature back to normal.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD BIOLOGY SYLLABUS)
  // =========================================================================
  {
    id: G11-BIO-CL-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Classification of Living Things,
    subtopic: "Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Living organisms are classified into kingdoms based on their characteristics. Which of the following kingdoms includes organisms that are eukaryotic, multicellular, heterotrophic, and have cell walls made of chitin?,
      options: [
        Fungi are eukaryotic, multicellular (or unicellular), heterotrophic organisms with cell walls made of chitin. They obtain nutrients through absorption and play important roles as decomposers and pathogens.,
        Plantae are eukaryotic, photosynthetic organisms with cell walls made of cellulose.,
        Animalia are eukaryotic, multicellular, heterotrophic organisms that lack cell walls.",
        "Protista are eukaryotic organisms that do not fit into the other kingdoms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Fungi are eukaryotic, multicellular (or unicellular), heterotrophic organisms with cell walls made of chitin. They obtain nutrients through absorption and play important roles as decomposers and pathogens."
    })
  },
  {
    id: "G11-BIO-CL-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Classification of Living Things",
    subtopic: "Characteristics of Kingdoms,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The kingdom Monera (Prokaryotae) includes prokaryotic organisms. Which of the following is a characteristic feature of organisms in the kingdom Monera?,
      options: [
        Organisms in kingdom Monera are prokaryotic, meaning they lack a true nucleus and membrane-bound organelles. They have a single circular chromosome and divide by binary fission.,
        Organisms in kingdom Monera have a true nucleus and membrane-bound organelles.,
        "Organisms in kingdom Monera are always multicellular.,
        Organisms in kingdom Monera use photosynthesis for energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organisms in kingdom Monera are prokaryotic, meaning they lack a true nucleus and membrane-bound organelles. They have a single circular chromosome and divide by binary fission.
    })
  },
  {
    id: G11-BIO-CL-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Classification of Living Things,
    subtopic: "Binomial Nomenclature",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Binomial nomenclature is the system of naming organisms with two names. Which of the following correctly describes the structure of a scientific name under binomial nomenclature?,
      options: [
        The scientific name consists of the genus name (capitalized) and the species epithet (lowercase), both italicized or underlined, e.g., Homo sapiens.,
        The scientific name consists only of the genus name.,
        The scientific name consists of the family and species names.",
        "The scientific name consists of the species name and common name.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The scientific name consists of the genus name (capitalized) and the species epithet (lowercase), both italicized or underlined, e.g., Homo sapiens."
    })
  },
  {
    id: "G11-BIO-CL-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Classification of Living Things",
    subtopic: "Taxonomic Hierarchy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The taxonomic hierarchy organizes life from broad groups to specific species. Which of the following shows the correct order of taxonomic ranks from most inclusive (broadest) to most exclusive (narrowest)?,
      options: [
        Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species (DKPCOFGS) is the correct order from most inclusive to most exclusive.,
        Species, Genus, Family, Order, Class, Phylum, Kingdom, Domain.,
        "Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species is incorrect.,
        Kingdom, Domain, Phylum, Class, Order, Family, Genus, Species."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Domain, Kingdom, Phylum, Class, Order, Family, Genus, Species (DKPCOFGS) is the correct order from most inclusive to most exclusive.
    })
  },
  {
    id: G11-BIO-CB-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Cell Biology Advanced,
    subtopic: "Cell Specialization",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Cell specialization (differentiation) results in cells with specific functions. Which of the following is an example of a specialized animal cell that has lost its nucleus to maximize its capacity for carrying oxygen?,
      options: [
        Red blood cells (erythrocytes) are specialized cells that have lost their nucleus and organelles to maximize hemoglobin content and oxygen-carrying capacity, allowing for efficient oxygen transport.,
        White blood cells are specialized for oxygen transport.,
        Nerve cells are specialized for carrying oxygen.",
        "Muscle cells have no nucleus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Red blood cells (erythrocytes) are specialized cells that have lost their nucleus and organelles to maximize hemoglobin content and oxygen-carrying capacity, allowing for efficient oxygen transport."
    })
  },
  {
    id: "G11-BIO-CB-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Cell Biology Advanced",
    subtopic: "Tissue Organization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Tissues are groups of similar cells that work together to perform a specific function. Which of the following is a type of animal tissue that covers body surfaces, lines body cavities, and forms glands?,
      options: [
        "Epithelial tissue covers body surfaces, lines internal cavities and organs, and forms glands that secrete substances such as hormones, enzymes, and mucus.,
        Connective tissue provides support and structure.",
        "Muscle tissue enables movement.,
        Nervous tissue transmits signals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Epithelial tissue covers body surfaces, lines internal cavities and organs, and forms glands that secrete substances such as hormones, enzymes, and mucus.
    })
  },
  {
    id: G11-BIO-CB-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Cell Biology Advanced,
    subtopic: "Organ Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Organ systems are groups of organs that work together to perform major functions. Which of the following organ systems is responsible for the transport of oxygen, nutrients, hormones, and waste products throughout the body?,
      options: [
        The circulatory system is responsible for transporting oxygen, nutrients, hormones, and waste products throughout the body via the blood, heart, and blood vessels.,
        The respiratory system transports nutrients.,
        The digestive system transports oxygen.",
        "The excretory system transports hormones.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The circulatory system is responsible for transporting oxygen, nutrients, hormones, and waste products throughout the body via the blood, heart, and blood vessels."
    })
  },
  {
    id: "G11-BIO-CB-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Cell Biology Advanced",
    subtopic: "Cell Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Cell communication is essential for coordinating cellular activities. Which of the following describes the function of gap junctions in cell communication?,
      options: [
        Gap junctions are channels that allow direct communication and the exchange of small molecules and ions between adjacent cells, enabling rapid signaling and coordination.,
        Gap junctions are involved in long-distance signaling.,
        "Gap junctions are found only in plant cells.,
        Gap junctions prevent communication between cells."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gap junctions are channels that allow direct communication and the exchange of small molecules and ions between adjacent cells, enabling rapid signaling and coordination.
    })
  },
  {
    id: G11-BIO-PP-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Plant Physiology,
    subtopic: "Transport in Plants",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Plants transport water and nutrients through specialized tissues. Which of the following explains how water moves from the roots to the leaves in tall trees against gravity?,
      options: [
        The cohesion-tension theory explains that water moves up the xylem through a combination of transpiration pull (evaporation from leaves), cohesion between water molecules, and adhesion to xylem walls, creating a continuous column of water.,
        Water moves in plants through active transport only.,
        Water moves in plants due to root pressure exclusively.",
        "Water moves in plants through osmosis only.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The cohesion-tension theory explains that water moves up the xylem through a combination of transpiration pull (evaporation from leaves), cohesion between water molecules, and adhesion to xylem walls, creating a continuous column of water."
    })
  },
  {
    id: "G11-BIO-PP-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Plant Physiology",
    subtopic: "Plant Hormones,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Plant hormones regulate growth and development in plants. Which of the following plant hormones is responsible for promoting stem elongation, fruit growth, and seed germination?,
      options: [
        "Gibberellins promote stem elongation, stimulate flowering and fruit development, and help in seed germination by promoting the production of amylase in cereal grains.,
        Auxins promote leaf abscission.",
        "Cytokinins promote senescence.,
        Abscisic acid promotes growth and development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gibberellins promote stem elongation, stimulate flowering and fruit development, and help in seed germination by promoting the production of amylase in cereal grains.
    })
  },
  {
    id: G11-BIO-PP-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Plant Physiology,
    subtopic: "Tropisms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Tropisms are directional growth responses of plants to external stimuli. Which of the following is the correct description of phototropism?,
      options: [
        Phototropism is the directional growth of a plant toward (positive phototropism) or away from (negative phototropism) light, mediated by the hormone auxin.,
        Phototropism is the growth of plants in response to gravity.,
        Phototropism is the growth of plants in response to touch.",
        "Phototropism is the growth of plants in response to chemicals.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Phototropism is the directional growth of a plant toward (positive phototropism) or away from (negative phototropism) light, mediated by the hormone auxin."
    })
  },
  {
    id: "G11-BIO-PP-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Plant Physiology",
    subtopic: "Photosynthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The Calvin cycle is the stage of photosynthesis that fixes carbon dioxide into organic molecules. Which of the following describes the role of RuBisCO (ribulose-1,5-bisphosphate carboxylase/oxygenase) in the Calvin cycle?,
      options: [
        RuBisCO is the enzyme that catalyzes the first step of the Calvin cycle, the carboxylation of ribulose-1,5-bisphosphate (RuBP) with carbon dioxide, producing two molecules of 3-phosphoglycerate (3-PGA).,
        RuBisCO is involved in the light-dependent reactions.",
        "RuBisCO catalyzes the reduction of 3-PGA to G3P.,
        RuBisCO is not involved in the Calvin cycle."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "RuBisCO is the enzyme that catalyzes the first step of the Calvin cycle, the carboxylation of ribulose-1,5-bisphosphate (RuBP) with carbon dioxide, producing two molecules of 3-phosphoglycerate (3-PGA).
    })
  },
  {
    id: G11-BIO-AP-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Nervous System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The nervous system coordinates the body's responses to internal and external stimuli. Which of the following correctly describes the transmission of an impulse across a synapse?,
      options: [
        Nerve impulses are transmitted across a synapse when neurotransmitters are released from the presynaptic neuron, diffuse across the synaptic cleft, and bind to receptors on the postsynaptic neuron, generating an action potential.,
        Nerve impulses are transmitted directly through gap junctions.,
        Nerve impulses are transmitted through the bloodstream.",
        "Nerve impulses are transmitted by electrical signals only.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Nerve impulses are transmitted across a synapse when neurotransmitters are released from the presynaptic neuron, diffuse across the synaptic cleft, and bind to receptors on the postsynaptic neuron, generating an action potential."
    })
  },
  {
    id: "G11-BIO-AP-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Animal Physiology",
    subtopic: "Nervous System,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The nervous system is divided into the central and peripheral nervous systems. Which of the following is a function of the autonomic nervous system?,
      options: [
        The autonomic nervous system controls involuntary body functions such as heartbeat, breathing, digestion, and blood pressure, acting through the sympathetic (fight or flight) and parasympathetic (rest and digest) divisions.,
        The autonomic nervous system controls voluntary muscle movement.,
        "The autonomic nervous system is part of the somatic nervous system.,
        The autonomic nervous system controls conscious thought."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The autonomic nervous system controls involuntary body functions such as heartbeat, breathing, digestion, and blood pressure, acting through the sympathetic (fight or flight) and parasympathetic (rest and digest) divisions.
    })
  },
  {
    id: G11-BIO-AP-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Endocrine System",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The endocrine system uses hormones to regulate body functions. Which of the following hormones is produced by the adrenal medulla and triggers the 'fight or flight' response?,
      options: [
        Epinephrine (adrenaline) is produced by the adrenal medulla and triggers the 'fight or flight' response, increasing heart rate, blood pressure, and blood glucose levels in preparation for action.,
        Cortisol is produced by the adrenal medulla.,
        Insulin is produced by the adrenal medulla.",
        "Aldosterone is produced by the adrenal medulla.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Epinephrine (adrenaline) is produced by the adrenal medulla and triggers the 'fight or flight' response, increasing heart rate, blood pressure, and blood glucose levels in preparation for action."
    })
  },
  {
    id: "G11-BIO-AP-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Animal Physiology",
    subtopic: "Sense Organs,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Sense organs detect stimuli from the environment and convert them into nerve impulses. Which of the following structures in the eye is responsible for focusing light onto the retina?,
      options: [
        The lens is responsible for focusing light onto the retina by changing its shape (accommodation) to adjust the focal length for near and far vision.,
        The cornea focuses light onto the retina.,
        "The iris focuses light onto the retina.,
        The pupil focuses light onto the retina."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The lens is responsible for focusing light onto the retina by changing its shape (accommodation) to adjust the focal length for near and far vision.
    })
  },
  {
    id: G11-BIO-AP-05",
    grade: "Grade 11,
    subject: Biology",
    topic: "Animal Physiology,
    subtopic: "Sense Organs",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The ear is responsible for hearing and balance. Which of the following structures in the inner ear is responsible for maintaining balance (equilibrium) and detecting changes in head position?,
      options: [
        The semicircular canals are responsible for detecting changes in head position and maintaining balance (equilibrium), working with the vestibular system to provide sensory information about head orientation and movement.,
        The cochlea is responsible for balance.,
        The eardrum is responsible for balance.",
        "The auditory nerve is responsible for balance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The semicircular canals are responsible for detecting changes in head position and maintaining balance (equilibrium), working with the vestibular system to provide sensory information about head orientation and movement."
    })
  },
  {
    id: "G11-BIO-RE-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Reproduction in Plants,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Sexual reproduction in flowering plants involves the fusion of male and female gametes. Which of the following describes the process of double fertilization in angiosperms?,
      options: [
        In double fertilization, one sperm cell fertilizes the egg to form the zygote (2n), while the second sperm cell fuses with the polar nuclei to form the endosperm (3n), which nourishes the developing embryo.,
        In double fertilization, two sperm cells fertilize two eggs.,
        "Double fertilization only occurs in gymnosperms.,
        Double fertilization results in the formation of two zygotes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In double fertilization, one sperm cell fertilizes the egg to form the zygote (2n), while the second sperm cell fuses with the polar nuclei to form the endosperm (3n), which nourishes the developing embryo.
    })
  },
  {
    id: G11-BIO-RE-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Reproduction,
    subtopic: "Reproduction in Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Animals reproduce either sexually or asexually. Which of the following is an advantage of sexual reproduction over asexual reproduction?,
      options: [
        Sexual reproduction produces genetic variation in offspring, increasing the potential for adaptation to changing environments and reducing the risk of extinction from diseases that affect genetically uniform populations.,
        Sexual reproduction is faster than asexual reproduction.,
        Sexual reproduction requires only one parent.",
        "Sexual reproduction produces offspring identical to the parent.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sexual reproduction produces genetic variation in offspring, increasing the potential for adaptation to changing environments and reducing the risk of extinction from diseases that affect genetically uniform populations."
    })
  },
  {
    id: "G11-BIO-RE-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Human Reproduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The human reproductive system is specialized for producing gametes and supporting conception. Which of the following is the correct description of the path of a sperm cell from production to fertilization?,
      options: [
        Sperm are produced in the seminiferous tubules of the testes, mature in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to reach the female reproductive tract for fertilization in the fallopian tube (oviduct).,
        Sperm are produced in the prostate gland and travel through the ureter.,
        "Sperm are produced in the seminal vesicles and travel through the urethra.,
        Sperm are produced in the fallopian tubes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sperm are produced in the seminiferous tubules of the testes, mature in the epididymis, travel through the vas deferens, and are ejaculated through the urethra to reach the female reproductive tract for fertilization in the fallopian tube (oviduct).
    })
  },
  {
    id: G11-BIO-RE-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Reproduction,
    subtopic: "Human Reproduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The menstrual cycle is regulated by hormones and prepares the female body for pregnancy. Which of the following hormones is responsible for ovulation and the development of the corpus luteum?,
      options: [
        Luteinizing hormone (LH) is responsible for triggering ovulation (release of the egg from the ovary) and the development of the corpus luteum, which produces progesterone to prepare the uterine lining for pregnancy.,
        Follicle-stimulating hormone (FSH) is responsible for ovulation.,
        Estrogen is responsible for ovulation.",
        "Progesterone is responsible for ovulation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Luteinizing hormone (LH) is responsible for triggering ovulation (release of the egg from the ovary) and the development of the corpus luteum, which produces progesterone to prepare the uterine lining for pregnancy."
    })
  },
  {
    id: "G11-BIO-RE-05",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Reproduction",
    subtopic: "Contraception,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Contraception is the intentional prevention of pregnancy. Which of the following contraceptive methods works by preventing ovulation and thickening cervical mucus, making it difficult for sperm to reach the egg?,
      options: [
        The combined oral contraceptive pill (the pill) works by providing synthetic estrogen and progesterone to prevent ovulation and thicken cervical mucus, creating a barrier to fertilization and preventing implantation.,
        The barrier method (condoms) prevents ovulation.",
        "The intrauterine device (IUD) works by preventing ovulation.,
        The rhythm method works by preventing ovulation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The combined oral contraceptive pill (the pill) works by providing synthetic estrogen and progesterone to prevent ovulation and thicken cervical mucus, creating a barrier to fertilization and preventing implantation.
    })
  },
  {
    id: G11-BIO-GE-01",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "Mendelian Genetics",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Mendelian genetics describes the patterns of inheritance of traits. In a monohybrid cross between two heterozygous individuals (Aa × Aa), what is the expected genotypic ratio of the offspring?,
      options: [
        The expected genotypic ratio is 1 AA : 2 Aa : 1 aa (1:2:1), as determined by the principles of Mendelian genetics when crossing two heterozygotes.,
        The expected genotypic ratio is 3:1 (dominant:recessive).,
        The expected genotypic ratio is 1:1 (homozygous:heterozygous).",
        "The expected genotypic ratio is 9:3:3:1, typical of dihybrid crosses.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The expected genotypic ratio is 1 AA : 2 Aa : 1 aa (1:2:1), as determined by the principles of Mendelian genetics when crossing two heterozygotes."
    })
  },
  {
    id: "G11-BIO-GE-02",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Genetics",
    subtopic: "Mendelian Genetics,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The law of independent assortment states that genes for different traits segregate independently during gamete formation. Which of the following is an exception to the law of independent assortment?,
      options: [
        Linked genes (genes located close together on the same chromosome) do not assort independently and are more likely to be inherited together, which is an exception to the law of independent assortment.,
        Alleles on different chromosomes do not assort independently.,
        "All genes assort independently regardless of their position.,
        Sex-linked genes assort independently of other genes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Linked genes (genes located close together on the same chromosome) do not assort independently and are more likely to be inherited together, which is an exception to the law of independent assortment.
    })
  },
  {
    id: G11-BIO-GE-03",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "DNA and RNA",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " DNA carries the genetic information in cells. Which of the following correctly describes the structure of DNA and the pairing of nitrogenous bases?,
      options: [
        DNA is a double helix with two antiparallel strands held together by hydrogen bonds between complementary nitrogenous bases: adenine pairs with thymine (A-T), and guanine pairs with cytosine (G-C).,
        DNA is a single-stranded molecule with A-G and T-C base pairing.,
        DNA is a triple helix with A-U and C-G base pairing.",
        "DNA is a circular molecule with no base pairing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: DNA is a double helix with two antiparallel strands held together by hydrogen bonds between complementary nitrogenous bases: adenine pairs with thymine (A-T), and guanine pairs with cytosine (G-C)."
    })
  },
  {
    id: "G11-BIO-GE-04",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Genetics",
    subtopic: "Protein Synthesis,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Protein synthesis involves transcription and translation. Which of the following describes the process of transcription in protein synthesis?,
      options: [
        Transcription is the process in which a segment of DNA is used as a template to synthesize a complementary messenger RNA (mRNA) molecule, which carries the genetic information from the nucleus to the ribosome.,
        Transcription is the process of synthesizing proteins at the ribosome.,
        "Transcription is the process of translating mRNA into protein.,
        Transcription occurs only in the cytoplasm."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Transcription is the process in which a segment of DNA is used as a template to synthesize a complementary messenger RNA (mRNA) molecule, which carries the genetic information from the nucleus to the ribosome.
    })
  },
  {
    id: G11-BIO-GE-05",
    grade: "Grade 11,
    subject: Biology",
    topic: "Genetics,
    subtopic: "Protein Synthesis",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Translation is the process by which the genetic code in mRNA is used to synthesize proteins. Which of the following is the role of tRNA (transfer RNA) in translation?,
      options: [
        tRNA carries specific amino acids to the ribosome and uses its anticodon to recognize the codon on mRNA, ensuring that the correct amino acid is added to the growing polypeptide chain in the correct sequence.,
        tRNA carries the genetic code from the nucleus to the ribosome.,
        tRNA is involved in transcription and translation.",
        "tRNA makes up the ribosomes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: tRNA carries specific amino acids to the ribosome and uses its anticodon to recognize the codon on mRNA, ensuring that the correct amino acid is added to the growing polypeptide chain in the correct sequence."
    })
  },
  {
    id: "G11-BIO-GD-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Growth and Development",
    subtopic: "Growth Curves,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Growth curves show patterns of growth in organisms over time. Which of the following describes the logistic growth curve of a population in a limited environment?,
      options: [
        A logistic growth curve shows an initial exponential phase, followed by a deceleration phase as resources become limited, and finally reaches a carrying capacity (plateau) where the population stabilizes at the maximum sustainable size.,
        A logistic growth curve shows unlimited exponential growth.,
        "A logistic growth curve shows a decline in population size.,
        A logistic growth curve is always linear."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A logistic growth curve shows an initial exponential phase, followed by a deceleration phase as resources become limited, and finally reaches a carrying capacity (plateau) where the population stabilizes at the maximum sustainable size.
    })
  },
  {
    id: G11-BIO-GD-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Growth and Development,
    subtopic: "Embryonic Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Embryonic development involves a series of stages from fertilization to birth. Which of the following correctly describes the stage of embryonic development in which the blastocyst implants into the uterine lining?,
      options: [
        Implantation occurs when the blastocyst, after traveling through the fallopian tube and reaching the uterus, attaches to and embeds itself into the endometrial lining, allowing the embryo to receive nutrients and oxygen from the mother.,
        Implantation occurs before fertilization.,
        Implantation is the formation of the placenta.",
        "Implantation is the development of the heart.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Implantation occurs when the blastocyst, after traveling through the fallopian tube and reaching the uterus, attaches to and embeds itself into the endometrial lining, allowing the embryo to receive nutrients and oxygen from the mother."
    })
  },
  {
    id: "G11-BIO-GD-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Growth and Development",
    subtopic: "Germ Layer Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "During embryonic development, three germ layers are formed. Which of the following tissues and organs develop from the ectoderm?,
      options: [
        The ectoderm gives rise to the skin (epidermis), hair, nails, the nervous system (brain, spinal cord, and nerves), and sensory organs (eyes, ears, nose).,
        The ectoderm gives rise to muscles and bones.",
        "The ectoderm gives rise to the digestive system.,
        The ectoderm gives rise to the circulatory system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The ectoderm gives rise to the skin (epidermis), hair, nails, the nervous system (brain, spinal cord, and nerves), and sensory organs (eyes, ears, nose).
    })
  },
  {
    id: G11-BIO-GD-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Growth and Development,
    subtopic: "Factors Affecting Growth",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Growth is influenced by both genetic and environmental factors. Which of the following environmental factors has the most significant effect on plant growth and development?,
      options: [
        Light, temperature, water, and nutrients are the most significant environmental factors affecting plant growth. Light provides energy for photosynthesis, temperature affects metabolic processes, water is essential for turgor and transport, and nutrients provide the building blocks for growth.,
        Wind is the most important environmental factor.,
        Altitude is the most important factor.",
        "Density of planting is the most important environmental factor.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Light, temperature, water, and nutrients are the most significant environmental factors affecting plant growth. Light provides energy for photosynthesis, temperature affects metabolic processes, water is essential for turgor and transport, and nutrients provide the building blocks for growth."
    })
  },
  {
    id: "G11-BIO-MB-01",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Microbiology",
    subtopic: "Bacteria,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Bacteria are prokaryotic microorganisms with diverse roles in ecosystems. Which of the following correctly describes the structure of bacterial cells and their method of reproduction?,
      options: [
        Bacterial cells are prokaryotic with a single circular chromosome, a cell wall made of peptidoglycan, and no membrane-bound organelles. They reproduce asexually by binary fission (division into two identical daughter cells).,
        Bacteria are eukaryotic with a nucleus.,
        "Bacteria reproduce by mitosis like eukaryotic cells.,
        Bacteria have chloroplasts for photosynthesis."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bacterial cells are prokaryotic with a single circular chromosome, a cell wall made of peptidoglycan, and no membrane-bound organelles. They reproduce asexually by binary fission (division into two identical daughter cells).
    })
  },
  {
    id: G11-BIO-MB-02",
    grade: "Grade 11,
    subject: Biology",
    topic: "Microbiology,
    subtopic: "Viruses",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Viruses are non-cellular infectious agents that require a host cell to replicate. Which of the following explains why viruses are not considered living organisms?,
      options: [
        Viruses are not considered living because they cannot replicate independently, lack cellular organization (no cytoplasm, organelles, or metabolism), and require a host cell to produce new virus particles.,
        Viruses are considered living because they contain DNA or RNA.,
        Viruses are considered living because they can cause disease.",
        "Viruses are considered living because they have a cell wall.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Viruses are not considered living because they cannot replicate independently, lack cellular organization (no cytoplasm, organelles, or metabolism), and require a host cell to produce new virus particles."
    })
  },
  {
    id: "G11-BIO-MB-03",
    grade: "Grade 11",
    subject: "Biology",
    topic: "Microbiology",
    subtopic: "Fungi,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Fungi are eukaryotic organisms that play important roles as decomposers, pathogens, and symbionts. Which of the following is a key characteristic of fungi that distinguishes them from plants?,
      options: [
        "Fungi are heterotrophic (absorb nutrients from their environment) and have cell walls made of chitin, while plants are autotrophic and have cell walls made of cellulose.,
        Fungi are autotrophic and have cellulose cell walls.",
        "Fungi have chloroplasts and can photosynthesize.,
        Fungi are prokaryotic organisms."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Fungi are heterotrophic (absorb nutrients from their environment) and have cell walls made of chitin, while plants are autotrophic and have cell walls made of cellulose.
    })
  },
  {
    id: G11-BIO-MB-04",
    grade: "Grade 11,
    subject: Biology",
    topic: "Microbiology,
    subtopic: "Protozoa",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Protozoa are single-celled eukaryotic organisms that are often motile. Which of the following is a protozoan that causes malaria and is transmitted by the Anopheles mosquito?,
      options: [
        Plasmodium is a protozoan parasite that causes malaria. It is transmitted through the bite of an infected female Anopheles mosquito, where the parasite undergoes development in the mosquito before being injected into the human host.,
        Trypanosoma causes malaria.,
        Entamoeba causes malaria.",
        "Giardia causes malaria.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Plasmodium is a protozoan parasite that causes malaria. It is transmitted through the bite of an infected female Anopheles mosquito, where the parasite undergoes development in the mosquito before being injected into the human host."
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD BIOLOGY SYLLABUS)
  // =========================================================================

  // --- ECOLOGY (5 Materials) ---
  {
    id: "G12-BIO-EC-01",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Ecology",
    subtopic: "Ecosystems,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "An ecosystem consists of living organisms (biotic factors) interacting with their non-living (abiotic) environment. Which of the following correctly defines an ecosystem and its components?,
      options: [
        An ecosystem is a community of living organisms (biotic factors) interacting with each other and with the non-living components (abiotic factors) such as climate, soil, water, and light in a given area.,
        An ecosystem is just the physical environment without living organisms.,
        "An ecosystem includes only the living organisms in an area.,
        An ecosystem is a single population of organisms."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "An ecosystem is a community of living organisms (biotic factors) interacting with each other and with the non-living components (abiotic factors) such as climate, soil, water, and light in a given area.
    })
  },
  {
    id: G12-BIO-EC-02",
    grade: "Grade 12,
    subject: Biology",
    topic: "Ecology,
    subtopic: "Energy Flow",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Energy flows through an ecosystem from producers to consumers. Which of the following explains why energy transfer between trophic levels is inefficient (only about 10% is transferred)?,
      options: [
        Energy is lost at each trophic level through metabolic processes such as respiration, as heat, and through incomplete consumption and digestion, resulting in only about 10% of energy being transferred to the next level.,
        Energy transfer is always 100% efficient.,
        Energy is not lost between trophic levels.",
        "Energy is stored completely in the tissues of organisms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Energy is lost at each trophic level through metabolic processes such as respiration, as heat, and through incomplete consumption and digestion, resulting in only about 10% of energy being transferred to the next level."
    })
  },
  {
    id: "G12-BIO-EC-03",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Ecology",
    subtopic: "Nutrient Cycling,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Nutrient cycling is the movement of nutrients through biotic and abiotic components of ecosystems. Which of the following describes the role of decomposers in nutrient cycling?,
      options: [
        Decomposers (bacteria and fungi) break down dead organic matter and waste products, releasing nutrients such as carbon, nitrogen, and phosphorus back into the environment for reuse by producers.,
        Decomposers are responsible for photosynthesis.,
        "Decomposers are consumers that eat living organisms.,
        Decomposers are producers that make their own food."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Decomposers (bacteria and fungi) break down dead organic matter and waste products, releasing nutrients such as carbon, nitrogen, and phosphorus back into the environment for reuse by producers.
    })
  },
  {
    id: G12-BIO-EC-04",
    grade: "Grade 12,
    subject: Biology",
    topic: "Ecology,
    subtopic: "Populations",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Population ecology studies the dynamics of populations and factors affecting their size. Which of the following is a density-dependent factor that limits population growth?,
      options: [
        Competition for resources such as food and space is a density-dependent factor that limits population growth, as the population increases, resources become scarcer and competition intensifies, reducing growth.,
        Natural disasters such as floods and fires are density-dependent factors.,
        Climate change is a density-dependent factor.",
        "Weather conditions are density-dependent factors.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Competition for resources such as food and space is a density-dependent factor that limits population growth, as the population increases, resources become scarcer and competition intensifies, reducing growth."
    })
  },
  {
    id: "G12-BIO-EC-05",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Ecology",
    subtopic: "Succession,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Ecological succession is the gradual process of change in the species composition of an ecosystem. Which of the following describes primary succession, where life begins on bare rock?,
      options: [
        Primary succession begins on bare rock where no soil exists, starting with pioneer species such as lichens and mosses that break down rock to form soil, followed by progressively more complex communities over time.,
        Primary succession occurs in areas where soil already exists.",
        "Primary succession is the regrowth of a forest after a fire.,
        Primary succession starts with large trees dominating the ecosystem."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Primary succession begins on bare rock where no soil exists, starting with pioneer species such as lichens and mosses that break down rock to form soil, followed by progressively more complex communities over time.
    })
  },

  // --- BIODIVERSITY AND CONSERVATION (4 Materials) ---
  {
    id: G12-BIO-BC-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Biodiversity and Conservation,
    subtopic: "Importance of Biodiversity",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Biodiversity refers to the variety of life on Earth at all levels, from genes to ecosystems. Which of the following is an ecosystem service provided by high biodiversity?,
      options: [
        High biodiversity provides ecosystem services such as pollination of crops, pest control, nutrient cycling, climate regulation, and provision of clean water and air, all of which support human well-being.,
        Biodiversity only provides aesthetic value to humans.,
        Ecosystem services are not related to biodiversity.",
        "High biodiversity reduces the stability of ecosystems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: High biodiversity provides ecosystem services such as pollination of crops, pest control, nutrient cycling, climate regulation, and provision of clean water and air, all of which support human well-being."
    })
  },
  {
    id: "G12-BIO-BC-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Biodiversity and Conservation",
    subtopic: "Threats to Biodiversity,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Biodiversity is threatened by various human activities and natural processes. Which of the following is the primary driver of biodiversity loss globally?,
      options: [
        Habitat loss and fragmentation due to agricultural expansion, urbanization, deforestation, and other land-use changes is the primary driver of biodiversity loss globally.,
        Invasive species are the primary driver of biodiversity loss.,
        "Pollution is the only threat to biodiversity.,
        Climate change is the primary driver of biodiversity loss."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Habitat loss and fragmentation due to agricultural expansion, urbanization, deforestation, and other land-use changes is the primary driver of biodiversity loss globally.
    })
  },
  {
    id: G12-BIO-BC-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Biodiversity and Conservation,
    subtopic: "Conservation Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Conservation strategies are essential for protecting biodiversity. Which of the following is an in-situ conservation approach that protects species in their natural habitats?,
      options: [
        In-situ conservation involves protecting species in their natural habitats through mechanisms such as national parks, wildlife reserves, and marine protected areas, where ecosystems are maintained and managed.,
        Ex-situ conservation protects species in their natural habitats.,
        Zoos and botanical gardens are examples of in-situ conservation.",
        "Seed banks are in-situ conservation methods.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: In-situ conservation involves protecting species in their natural habitats through mechanisms such as national parks, wildlife reserves, and marine protected areas, where ecosystems are maintained and managed."
    })
  },
  {
    id: "G12-BIO-BC-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Biodiversity and Conservation",
    subtopic: "Conservation Strategies,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Ex-situ conservation involves protecting species outside their natural habitats. Which of the following is an example of ex-situ conservation?,
      options: [
        Ex-situ conservation involves protecting species in artificial settings such as zoos, botanical gardens, seed banks, and gene banks, where they are preserved outside their natural habitats.,
        National parks are ex-situ conservation methods.,
        "Wildlife reserves are ex-situ conservation methods.,
        Marine protected areas are ex-situ conservation methods."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ex-situ conservation involves protecting species in artificial settings such as zoos, botanical gardens, seed banks, and gene banks, where they are preserved outside their natural habitats.
    })
  },

  // --- EVOLUTION (5 Materials) ---
  {
    id: G12-BIO-EV-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Evolution,
    subtopic: "Theories of Evolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Evolution is the process of change in the heritable characteristics of populations over generations. Which of the following is the central tenet of Darwin's theory of evolution by natural selection?,
      options: [
        Darwin's theory of evolution by natural selection states that individuals with traits better suited to their environment are more likely to survive and reproduce, passing these favorable traits to their offspring, leading to gradual change in populations.,
        Darwin's theory states that all organisms are created in their current form and do not change.,
        Darwin's theory states that evolution occurs through sudden mutations.",
        "Darwin's theory states that organisms can change their traits during their lifetime and pass them on.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Darwin's theory of evolution by natural selection states that individuals with traits better suited to their environment are more likely to survive and reproduce, passing these favorable traits to their offspring, leading to gradual change in populations."
    })
  },
  {
    id: "G12-BIO-EV-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Evolution",
    subtopic: "Mechanisms of Evolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Evolution occurs through various mechanisms, including natural selection, mutation, genetic drift, and gene flow. Which of the following describes genetic drift as a mechanism of evolution?,
      options: [
        "Genetic drift is the random change in allele frequencies in a population due to chance events, particularly in small populations, and can lead to the loss or fixation of alleles independent of their adaptive value.,
        Genetic drift is the movement of alleles between populations.",
        "Genetic drift is the introduction of new alleles through mutation.,
        Genetic drift is the differential survival and reproduction of individuals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Genetic drift is the random change in allele frequencies in a population due to chance events, particularly in small populations, and can lead to the loss or fixation of alleles independent of their adaptive value.
    })
  },
  {
    id: G12-BIO-EV-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Evolution,
    subtopic: "Evidence for Evolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Various types of evidence support the theory of evolution. Which of the following provides evidence for evolution from the study of the distribution of species across different geographic regions?,
      options: [
        Biogeography provides evidence for evolution by showing that species in different geographic regions are related but have adapted to their specific environments, and that closely related species are often found in close proximity.,
        Fossil records are the only evidence for evolution.,
        Comparative anatomy provides evidence for evolution.",
        "Molecular biology provides evidence for evolution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Biogeography provides evidence for evolution by showing that species in different geographic regions are related but have adapted to their specific environments, and that closely related species are often found in close proximity."
    })
  },
  {
    id: "G12-BIO-EV-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Evolution",
    subtopic: "Evidence for Evolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "The fossil record provides direct evidence of evolution. Which of the following is the significance of transitional fossils such as Archaeopteryx in supporting the theory of evolution?,
      options: [
        Transitional fossils such as Archaeopteryx show intermediate characteristics between major groups (reptiles and birds), providing strong evidence for evolutionary relationships and the process of gradual change.,
        Transitional fossils are rare and have no significance.,
        "Archaeopteryx is the ancestor of all mammals.,
        Transitional fossils disprove the theory of evolution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Transitional fossils such as Archaeopteryx show intermediate characteristics between major groups (reptiles and birds), providing strong evidence for evolutionary relationships and the process of gradual change.
    })
  },
  {
    id: G12-BIO-EV-05",
    grade: "Grade 12,
    subject: Biology",
    topic: "Evolution,
    subtopic: "Speciation",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Speciation is the process by which new species arise. Which of the following describes allopatric speciation?,
      options: [
        Allopatric speciation occurs when a population is geographically separated (by a physical barrier such as a mountain range or river), leading to reproductive isolation and eventually the formation of new species.,
        Allopatric speciation occurs when populations are not geographically separated.,
        Allopatric speciation occurs when organisms choose different mating partners.",
        "Allopatric speciation is the formation of new species in the same geographic area.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Allopatric speciation occurs when a population is geographically separated (by a physical barrier such as a mountain range or river), leading to reproductive isolation and eventually the formation of new species."
    })
  },

  // --- HUMAN HEALTH AND DISEASE (5 Materials) ---
  {
    id: "G12-BIO-HH-01",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Human Health and Disease",
    subtopic: "Pathogens,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Pathogens are disease-causing organisms that infect humans. Which of the following is a bacterial disease that affects the respiratory system and is transmitted through airborne droplets?,
      options: [
        Tuberculosis (TB) is a bacterial disease caused by Mycobacterium tuberculosis, which primarily affects the lungs and is transmitted through the air when an infected person coughs or sneezes.,
        Malaria is a bacterial disease of the respiratory system.,
        "HIV/AIDS is a bacterial disease of the respiratory system.,
        Cholera is a bacterial disease of the respiratory system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tuberculosis (TB) is a bacterial disease caused by Mycobacterium tuberculosis, which primarily affects the lungs and is transmitted through the air when an infected person coughs or sneezes.
    })
  },
  {
    id: G12-BIO-HH-02",
    grade: "Grade 12,
    subject: Biology",
    topic: "Human Health and Disease,
    subtopic: "Immunity",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " The immune system protects the body from pathogens through various mechanisms. Which of the following is an example of active immunity?,
      options: [
        Active immunity occurs when the body produces its own antibodies in response to exposure to a pathogen or through vaccination, providing long-lasting protection and immunological memory.,
        Active immunity is the transfer of antibodies from mother to fetus.,
        Active immunity occurs through the injection of antibodies from another source.",
        "Active immunity provides immediate but short-lasting protection.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Active immunity occurs when the body produces its own antibodies in response to exposure to a pathogen or through vaccination, providing long-lasting protection and immunological memory."
    })
  },
  {
    id: "G12-BIO-HH-03",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Human Health and Disease",
    subtopic: "Disease Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Disease prevention involves various strategies to reduce the risk of infection. Which of the following is the most effective strategy for preventing the spread of communicable diseases?,
      options: [
        Vaccination and immunization programs, combined with improved hygiene and sanitation practices, are the most effective strategies for preventing the spread of communicable diseases.,
        Avoiding all contact with other people is the most effective strategy.,
        "Taking antibiotics regularly is the most effective strategy.,
        Only treating people after they get sick is an effective prevention strategy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vaccination and immunization programs, combined with improved hygiene and sanitation practices, are the most effective strategies for preventing the spread of communicable diseases.
    })
  },
  {
    id: G12-BIO-HH-04",
    grade: "Grade 12,
    subject: Biology",
    topic: "Human Health and Disease,
    subtopic: "Non-Communicable Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Non-communicable diseases (NCDs) are chronic conditions not caused by infectious agents. Which of the following is a lifestyle-related risk factor for the development of type 2 diabetes?,
      options: [
        Obesity, physical inactivity, and poor diet are major lifestyle-related risk factors for the development of type 2 diabetes, which can be prevented or delayed through healthy lifestyle choices.,
        Type 2 diabetes is caused only by genetic factors.,
        Type 2 diabetes is always a communicable disease.",
        "Vaccination prevents type 2 diabetes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Obesity, physical inactivity, and poor diet are major lifestyle-related risk factors for the development of type 2 diabetes, which can be prevented or delayed through healthy lifestyle choices."
    })
  },
  {
    id: "G12-BIO-HH-05",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Human Health and Disease",
    subtopic: "Antimicrobial Resistance,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Antimicrobial resistance (AMR) is a growing public health concern. Which of the following is a major contributor to the development of antimicrobial resistance?,
      options: [
        Overuse and misuse of antibiotics, including not completing prescribed courses and using antibiotics for viral infections, contributes to the development of antimicrobial resistance in bacteria.,
        Proper use of antibiotics reduces resistance.,
        "Antimicrobial resistance occurs only in hospitals.,
        Vaccination contributes to antimicrobial resistance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Overuse and misuse of antibiotics, including not completing prescribed courses and using antibiotics for viral infections, contributes to the development of antimicrobial resistance in bacteria.
    })
  },

  // --- BIOTECHNOLOGY (4 Materials) ---
  {
    id: G12-BIO-BT-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Biotechnology,
    subtopic: "Genetic Engineering",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Genetic engineering is the direct manipulation of an organism's genes using biotechnology. Which of the following describes the process of creating recombinant DNA using restriction enzymes and DNA ligase?,
      options: [
        Recombinant DNA is created by cutting DNA at specific recognition sites using restriction enzymes, and then joining the resulting DNA fragments from different sources using DNA ligase to produce a new combination of genes.,
        Recombinant DNA is created by randomly mixing DNA from different sources.,
        Recombinant DNA is created using only DNA polymerase.",
        "Recombinant DNA is created without the use of enzymes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Recombinant DNA is created by cutting DNA at specific recognition sites using restriction enzymes, and then joining the resulting DNA fragments from different sources using DNA ligase to produce a new combination of genes."
    })
  },
  {
    id: "G12-BIO-BT-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Biotechnology",
    subtopic: "Applications,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Biotechnology has numerous applications in medicine, agriculture, and industry. Which of the following is a medical application of genetic engineering?,
      options: [
        "Genetic engineering is used to produce recombinant human insulin (humulin) by inserting the human insulin gene into bacteria, allowing large-scale production of this life-saving hormone for diabetes treatment.,
        Genetic engineering is used only for cosmetic purposes.",
        "Genetic engineering has no medical applications.,
        Genetic engineering is only used for food production."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Genetic engineering is used to produce recombinant human insulin (humulin) by inserting the human insulin gene into bacteria, allowing large-scale production of this life-saving hormone for diabetes treatment.
    })
  },
  {
    id: G12-BIO-BT-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Biotechnology,
    subtopic: "Applications",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Genetically modified (GM) crops have been developed to improve agricultural productivity. Which of the following is a common trait introduced into GM crops such as Bt cotton?,
      options: [
        Bt cotton has been genetically engineered to produce an insecticidal protein from the bacterium Bacillus thuringiensis (Bt), providing resistance to certain insect pests and reducing the need for chemical pesticides.,
        Bt cotton is engineered to produce more carbohydrates.,
        Bt cotton is resistant to herbicides only.",
        "Bt cotton has increased salt tolerance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Bt cotton has been genetically engineered to produce an insecticidal protein from the bacterium Bacillus thuringiensis (Bt), providing resistance to certain insect pests and reducing the need for chemical pesticides."
    })
  },
  {
    id: "G12-BIO-BT-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Biotechnology",
    subtopic: "Ethics,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Biotechnology raises important ethical, social, and safety concerns. Which of the following is an ethical concern associated with genetic engineering and biotechnology?,
      options: [
        "Ethical concerns include potential effects on human health and the environment, genetic privacy and discrimination issues, and the moral implications of manipulating the genetic makeup of organisms, including concerns about the sanctity of life.,
        Biotechnology has no ethical concerns.",
        "Only environmental concerns matter in biotechnology.,
        Ethical concerns are only about cost."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethical concerns include potential effects on human health and the environment, genetic privacy and discrimination issues, and the moral implications of manipulating the genetic makeup of organisms, including concerns about the sanctity of life.
    })
  },

  // --- ENVIRONMENT AND NATURAL RESOURCES (4 Materials) ---
  {
    id: G12-BIO-EN-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Environment and Natural Resources,
    subtopic: "Sustainable Use",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Sustainable use of natural resources ensures their availability for future generations. Which of the following is an example of sustainable resource management?,
      options: [
        Sustainable resource management includes practices such as selective logging, controlled fishing quotas, and management of water resources to prevent depletion and maintain ecosystem health.,
        Using resources without any restrictions is sustainable.,
        Extracting all resources for immediate benefit is sustainable.",
        "Ignoring environmental impacts is sustainable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sustainable resource management includes practices such as selective logging, controlled fishing quotas, and management of water resources to prevent depletion and maintain ecosystem health."
    })
  },
  {
    id: "G12-BIO-EN-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Environment and Natural Resources",
    subtopic: "Pollution,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Pollution is the introduction of contaminants into the environment that cause harm. Which of the following is a major source of water pollution in agricultural areas?,
      options: [
        Agricultural runoff containing fertilizers, pesticides, and animal waste is a major source of water pollution, leading to eutrophication and contamination of water sources.,
        Only industrial waste causes water pollution.,
        "Agricultural runoff has no effect on water quality.,
        Fertilizers in runoff do not cause water pollution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agricultural runoff containing fertilizers, pesticides, and animal waste is a major source of water pollution, leading to eutrophication and contamination of water sources.
    })
  },
  {
    id: G12-BIO-EN-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Environment and Natural Resources,
    subtopic: "Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Natural resource management involves planning and implementing practices to maintain and improve the quality of natural resources. Which of the following is a key principle of integrated watershed management?,
      options: [
        Integrated watershed management considers the entire watershed as a unit and balances the various uses of water and land resources (agriculture, forestry, urban development) while protecting water quality and ecosystems.,
        Integrated watershed management focuses only on water quantity.,
        Integrated watershed management ignores environmental protection.",
        "Integrated watershed management does not consider land use.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Integrated watershed management considers the entire watershed as a unit and balances the various uses of water and land resources (agriculture, forestry, urban development) while protecting water quality and ecosystems."
    })
  },
  {
    id: "G12-BIO-EN-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Environment and Natural Resources",
    subtopic: "Climate Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Climate change is having significant impacts on ecosystems and natural resources. Which of the following is an effect of climate change on biodiversity?,
      options: [
        Climate change is causing shifts in species distribution, changes in phenology (timing of life events), extinction of vulnerable species, and disruption of ecological interactions, threatening global biodiversity.,
        Climate change has no effect on biodiversity.,
        "Climate change increases biodiversity uniformly.,
        Climate change only affects polar regions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Climate change is causing shifts in species distribution, changes in phenology (timing of life events), extinction of vulnerable species, and disruption of ecological interactions, threatening global biodiversity.
    })
  },

  // --- REPRODUCTION AND DEVELOPMENT (4 Materials) ---
  {
    id: G12-BIO-RD-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Reproduction and Development,
    subtopic: "Reproductive Health",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Reproductive health is a state of physical, mental, and social well-being related to reproduction. Which of the following is an important aspect of reproductive health education for adolescents?,
      options: [
        Comprehensive sex education that includes information about puberty, reproductive anatomy, contraception, sexually transmitted infections (STIs), and healthy relationships is important for adolescent reproductive health.,
        Reproductive health education is not important for adolescents.,
        Only abstinence education is needed.",
        "Reproductive health education should only be provided after adolescence.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Comprehensive sex education that includes information about puberty, reproductive anatomy, contraception, sexually transmitted infections (STIs), and healthy relationships is important for adolescent reproductive health."
    })
  },
  {
    id: "G12-BIO-RD-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Reproduction and Development",
    subtopic: "Contraception,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Contraceptive methods help individuals plan their families and prevent unwanted pregnancies. Which of the following is a barrier method of contraception that also provides protection against sexually transmitted infections?,
      options: [
        Condoms (male and female) are barrier methods of contraception that physically prevent sperm from reaching the egg and provide protection against sexually transmitted infections (STIs).,
        The pill is a barrier method.,
        "Contraceptive implants are barrier methods.,
        The IUD is a barrier method."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Condoms (male and female) are barrier methods of contraception that physically prevent sperm from reaching the egg and provide protection against sexually transmitted infections (STIs).
    })
  },
  {
    id: G12-BIO-RD-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Reproduction and Development,
    subtopic: "Fertilization",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Fertilization is the fusion of male and female gametes to form a zygote. Which of the following is the correct description of the process of fertilization in humans?,
      options: [
        Fertilization occurs when a sperm cell penetrates the outer layers of the egg cell in the fallopian tube, leading to the fusion of their nuclei and the formation of a diploid zygote, which then begins to divide and develop.,
        Fertilization occurs in the uterus.,
        Fertilization only requires one sperm cell.",
        "Fertilization occurs without any genetic material.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Fertilization occurs when a sperm cell penetrates the outer layers of the egg cell in the fallopian tube, leading to the fusion of their nuclei and the formation of a diploid zygote, which then begins to divide and develop."
    })
  },
  {
    id: "G12-BIO-RD-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Reproduction and Development",
    subtopic: "Prenatal Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Prenatal development consists of three main stages. Which of the following correctly describes the fetal stage of prenatal development?,
      options: [
        The fetal stage begins at the end of the embryonic period (after 8 weeks) and continues until birth, characterized by significant growth, organ maturation, and the development of recognizable human features.,
        The fetal stage is the first stage of development.,
        "The fetal stage occurs in the first 2 weeks of development.,
        The fetal stage is when implantation occurs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The fetal stage begins at the end of the embryonic period (after 8 weeks) and continues until birth, characterized by significant growth, organ maturation, and the development of recognizable human features.
    })
  },

  // --- APPLIED BIOLOGY (4 Materials) ---
  {
    id: G12-BIO-AB-01",
    grade: "Grade 12,
    subject: Biology",
    topic: "Applied Biology,
    subtopic: "Agriculture",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Biology has many applications in agriculture to improve food production. Which of the following is a biological application in agriculture that uses microorganisms to improve soil fertility?,
      options: [
        Biofertilizers use beneficial microorganisms such as nitrogen-fixing bacteria (Rhizobium) and mycorrhizal fungi to enhance soil fertility and promote plant growth, reducing the need for chemical fertilizers.,
        Only chemical fertilizers are used in agriculture.,
        Biofertilizers are not effective in agriculture.",
        "Microorganisms have no role in agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Biofertilizers use beneficial microorganisms such as nitrogen-fixing bacteria (Rhizobium) and mycorrhizal fungi to enhance soil fertility and promote plant growth, reducing the need for chemical fertilizers."
    })
  },
  {
    id: "G12-BIO-AB-02",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Applied Biology",
    subtopic: "Medicine,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Biology is fundamental to medicine and healthcare. Which of the following is an application of biology in medicine that involves the use of living cells and tissues to repair or replace damaged organs?,
      options: [
        Tissue engineering and regenerative medicine use stem cells and biomaterials to grow tissues and organs in the laboratory for transplantation, offering new treatments for previously incurable conditions.,
        Tissue engineering is not a biological application.,
        "Regenerative medicine does not use stem cells.,
        Tissue engineering is only used for cosmetic purposes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Tissue engineering and regenerative medicine use stem cells and biomaterials to grow tissues and organs in the laboratory for transplantation, offering new treatments for previously incurable conditions.
    })
  },
  {
    id: G12-BIO-AB-03",
    grade: "Grade 12,
    subject: Biology",
    topic: "Applied Biology,
    subtopic: "Industry",
    maxUses: 5,
    usageCount: 0,
    minWords: 29,
    generate: () => ({
      text: " Industrial biotechnology uses living organisms to produce products and chemicals. Which of the following is an example of industrial biotechnology that uses microorganisms to produce biofuels?,
      options: [
        Biofuel production involves using microorganisms such as yeast and bacteria to ferment biomass (e.g., sugarcane, maize) to produce ethanol, a renewable source of energy.,
        Only fossil fuels are used as energy sources.,
        Biofuels are not produced by microorganisms.",
        "Industrial biotechnology does not involve biofuels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Biofuel production involves using microorganisms such as yeast and bacteria to ferment biomass (e.g., sugarcane, maize) to produce ethanol, a renewable source of energy."
    })
  },
  {
    id: "G12-BIO-AB-04",
    grade: "Grade 12",
    subject: "Biology",
    topic: "Applied Biology",
    subtopic: "Environmental Remediation,
    maxUses: 5,
    usageCount: 0,
    minWords: 29,",
    generate: () => ({
      text: "Environmental remediation uses biological processes to clean up contaminated environments. Which of the following describes bioremediation as an environmental application of biology?,
      options: [
        Bioremediation uses microorganisms such as bacteria and fungi to break down or remove pollutants from contaminated soil and water, offering a natural and cost-effective way to clean up environmental contamination.,
        Bioremediation uses only chemical treatments.,
        "Microorganisms are not used for bioremediation.,
        Bioremediation is not effective for cleaning pollution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bioremediation uses microorganisms such as bacteria and fungi to break down or remove pollutants from contaminated soil and water, offering a natural and cost-effective way to clean up environmental contamination."
    })
  }

];


