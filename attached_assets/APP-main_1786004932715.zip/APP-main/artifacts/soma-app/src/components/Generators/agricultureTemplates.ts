export const agricultureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL CONSERVATION (5 Materials) ---
  {
    id: "G4-AG-SC-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Types of Soil",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Soil is an important natural resource for agriculture. Different types of soil have different properties that affect crop growth. Which type of soil is best for growing most crops because it holds water well but also drains properly?,
      options: [
        Loam soil, which is a mixture of sand, silt, and clay, providing good drainage and water-holding capacity for healthy plant growth.,
        Clay soil, which drains very slowly and becomes waterlogged easily.,
        "Sandy soil, which drains too quickly and does not hold nutrients well.,
        Gravel soil, which has large particles and cannot support plant growth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Loam soil, which is a mixture of sand, silt, and clay, providing good drainage and water-holding capacity for healthy plant growth.
    })
  },
  {
    id: G4-AG-SC-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Erosion",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Soil erosion is the process by which topsoil is carried away by wind or water, reducing soil fertility. Which of the following human activities is a major cause of soil erosion in agricultural areas?,
      options: [
        Deforestation, where trees are cut down without replanting, leaving the soil exposed to erosion by wind and rain.,
        Planting trees and maintaining forests to protect the soil.,
        Building terraces on sloped land to prevent erosion.",
        "Using cover crops to protect the soil surface.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Deforestation, where trees are cut down without replanting, leaving the soil exposed to erosion by wind and rain."
    })
  },
  {
    id: "G4-AG-SC-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Soil Conservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Various methods can be used to conserve soil and prevent erosion. Which of the following soil conservation methods involves planting crops in rows along the contour of the land to reduce water runoff?,
      options: [
        Contour farming, where crops are planted in rows that follow the natural shape (contours) of the land to slow water flow and reduce erosion.,
        Terracing, which involves creating flat platforms on steep slopes.,
        "Mulching, which involves covering the soil with organic materials.,
        Strip cropping, which involves planting different crops in alternating strips."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Contour farming, where crops are planted in rows that follow the natural shape (contours) of the land to slow water flow and reduce erosion.
    })
  },
  {
    id: G4-AG-SC-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Fertility",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Soil fertility is the ability of soil to provide nutrients for plant growth. Which of the following practices helps maintain and improve soil fertility in farming?,
      options: [
        Adding organic matter such as manure, compost, and crop residues to replenish nutrients and improve soil structure.,
        Burning crop residues after harvest to clear the field.,
        Growing the same crop year after year without rotation.",
        "Using excessive chemical fertilizers without organic matter.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Adding organic matter such as manure, compost, and crop residues to replenish nutrients and improve soil structure."
    })
  },
  {
    id: "G4-AG-SC-05",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Importance of Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Soil conservation is important for sustainable agriculture and food production. Which of the following is a major benefit of conserving soil in agricultural areas?,
      options: [
        Soil conservation maintains soil fertility and productivity, ensuring that crops can continue to grow well for future generations.,
        Soil conservation increases the speed of soil erosion.,
        "Soil conservation reduces the need for farming activities.,
        Soil conservation has no impact on agricultural productivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Soil conservation maintains soil fertility and productivity, ensuring that crops can continue to grow well for future generations.
    })
  },

  // --- WATER CONSERVATION AND IRRIGATION (4 Materials) ---
  {
    id: G4-AG-WC-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Sources of Water",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Water is essential for plant growth and agricultural production. Which of the following is a natural source of water that can be used for irrigation in farming?,
      options: [
        Rivers, lakes, rainfall, and groundwater (wells and boreholes) are natural sources of water used for irrigation.,
        Only rainfall can be used for farming.,
        Salt water from oceans is suitable for irrigation.",
        "Water from sewage can be used without treatment.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Rivers, lakes, rainfall, and groundwater (wells and boreholes) are natural sources of water used for irrigation."
    })
  },
  {
    id: "G4-AG-WC-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Water Conservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Water conservation involves using water efficiently and preventing waste. Which of the following is an effective method of conserving water in agricultural areas?,
      options: [
        Mulching, which involves covering the soil with organic materials to reduce evaporation and conserve soil moisture.,
        Allowing water to run off fields without using it.,
        "Using large amounts of water without measuring it.,
        Watering crops during the hottest part of the day."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mulching, which involves covering the soil with organic materials to reduce evaporation and conserve soil moisture.
    })
  },
  {
    id: G4-AG-WC-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Irrigation Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Irrigation is the artificial application of water to crops to supplement rainfall. Which of the following irrigation methods involves watering plants drop by drop near the root zone, conserving water efficiently?,
      options: [
        Drip irrigation, which delivers water directly to the plant roots through small tubes, reducing water loss through evaporation and runoff.,
        Flood irrigation, where water is allowed to flood the entire field.,
        Sprinkler irrigation, where water is sprayed over the crops like rain.",
        "Furrow irrigation, where water runs between rows of crops.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Drip irrigation, which delivers water directly to the plant roots through small tubes, reducing water loss through evaporation and runoff."
    })
  },
  {
    id: "G4-AG-WC-04",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Rainwater Harvesting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Rainwater harvesting involves collecting and storing rainwater for later use in agriculture. Which of the following is a method of harvesting rainwater on a farm?,
      options: [
        Constructing water tanks or ponds to collect and store rainwater from rooftops or surface runoff for use during dry periods.,
        Allowing rainwater to run off the farm without collection.,
        "Using rainwater only for drinking and not for agriculture.,
        Using rainwater immediately without any storage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructing water tanks or ponds to collect and store rainwater from rooftops or surface runoff for use during dry periods.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G4-AG-CP-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cereals",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Cereals are grass-like crops grown for their edible grains and are important staple foods. Which of the following crops is the most widely grown cereal in Kenya and is used to make ugali and flour?,
      options: [
        Maize, which is the main staple food in Kenya and is used to make ugali, porridge, and other traditional dishes.,
        Rice, which is grown in paddy fields and consumed as a main meal.,
        Wheat, which is used to make bread and other baked goods.",
        "Sorghum, which is drought-tolerant and used for porridge and animal feed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maize, which is the main staple food in Kenya and is used to make ugali, porridge, and other traditional dishes."
    })
  },
  {
    id: "G4-AG-CP-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vegetables are important for providing vitamins and minerals in the diet. Which of the following vegetables is a leafy green that is commonly grown in Kenyan farms and used in traditional dishes such as sukuma wiki?,
      options: [
        Kale (sukuma wiki), which is a leafy vegetable rich in iron and vitamins, commonly grown in small-scale farms across Kenya.,
        Carrots, which are root vegetables grown for their orange roots.,
        "Cabbage, which is a round vegetable with layered leaves.,
        Onions, which are bulb vegetables used as flavoring in cooking."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kale (sukuma wiki), which is a leafy vegetable rich in iron and vitamins, commonly grown in small-scale farms across Kenya.
    })
  },
  {
    id: G4-AG-CP-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Fruits",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fruits are an important source of vitamins and income for farmers. Which of the following fruits is a major export crop for Kenya and is known for its sweet taste and yellow-orange flesh?,
      options: [
        Mangoes, which are grown in coastal and eastern regions of Kenya and are a major export fruit crop.,
        Avocados, which are grown for their creamy flesh and are exported to international markets.,
        Bananas, which are grown for their starchy fruit and are a staple in many regions.",
        "Oranges, which are citrus fruits grown for their juice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mangoes, which are grown in coastal and eastern regions of Kenya and are a major export fruit crop."
    })
  },
  {
    id: "G4-AG-CP-04",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Root Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Root crops are grown for their underground storage organs and are important food and cash crops. Which of the following root crops is a staple food in many parts of Kenya and is used to make chapati, bread, and fries?,
      options: [
        "Potatoes (Irish potatoes), which are grown in the highlands and are used to make chips, chapati, and various stews.,
        Cassava, which is drought-tolerant and grown in drier regions.",
        "Sweet potatoes, which are grown for their sweet taste and nutritious roots.,
        Carrots, which are grown for their orange roots."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Potatoes (Irish potatoes), which are grown in the highlands and are used to make chips, chapati, and various stews.
    })
  },
  {
    id: G4-AG-CP-05",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Legumes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Legumes are crops that have the ability to fix nitrogen in the soil through their root nodules. Which of the following legumes is an important source of protein in the Kenyan diet and is commonly grown as a cash crop?,
      options: [
        Beans, which are rich in protein and can be grown in various regions, and are a staple in the Kenyan diet.,
        Maize, which is a cereal crop.,
        Wheat, which is used to make flour.",
        "Sorghum, which is drought-tolerant.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, which are rich in protein and can be grown in various regions, and are a staple in the Kenyan diet."
    })
  },

  // --- LIVESTOCK PRODUCTION (4 Materials) ---
  {
    id: "G4-AG-LP-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Cattle,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Cattle are important livestock animals that provide meat, milk, and other products. Which of the following cattle breeds is commonly kept for dairy production in Kenya and is known for its high milk yield?,
      options: [
        "Friesian cattle, which are high-yielding dairy breeds commonly kept in Kenya for milk production.,
        Boran cattle, which are beef cattle kept for meat production.",
        "Zebu cattle, which are indigenous breeds known for their heat tolerance.,
        Angus cattle, which are known for their meat quality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Friesian cattle, which are high-yielding dairy breeds commonly kept in Kenya for milk production.
    })
  },
  {
    id: G4-AG-LP-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Goats",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Goats are hardy animals that can survive in dry areas and provide meat, milk, and skin. Which of the following goat breeds is commonly kept in Kenya for both meat and milk production?,
      options: [
        Galla goats, which are native to Kenya and are raised for both meat and milk in arid and semi-arid areas.,
        Boer goats, which are famous for their meat.,
        Saanen goats, which are dairy goats.",
        "Angora goats, which are kept for their mohair.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Galla goats, which are native to Kenya and are raised for both meat and milk in arid and semi-arid areas."
    })
  },
  {
    id: "G4-AG-LP-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Poultry,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Poultry farming is popular in Kenya for meat and egg production. Which of the following poultry breeds is commonly kept for egg production in Kenya?,
      options: [
        Kenya Brown, which is a breed known for high egg production and is widely kept in Kenya for commercial and small-scale egg farming.,
        Broilers, which are kept for meat production.,
        "Indigenous chickens, which are kept for both meat and eggs.,
        Turkeys, which are kept for their meat."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya Brown, which is a breed known for high egg production and is widely kept in Kenya for commercial and small-scale egg farming.
    })
  },
  {
    id: G4-AG-LP-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Sheep",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Sheep are kept for meat, wool, and milk in various parts of Kenya. Which of the following sheep breeds is commonly kept in Kenya's highlands for wool production?,
      options: [
        Merino sheep, which are known for their high-quality wool and are raised in the highlands of Kenya.,
        Dorper sheep, which are kept for meat production.,
        Red Maasai sheep, which are indigenous to Kenya and are kept for meat.",
        "Crossbred sheep, which are kept for both meat and wool.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Merino sheep, which are known for their high-quality wool and are raised in the highlands of Kenya."
    })
  },

  // --- FARM TOOLS AND EQUIPMENT (4 Materials) ---
  {
    id: "G4-AG-FT-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Farm Tools and Equipment",
    subtopic: "Hand Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Farm tools are essential for carrying out agricultural activities. Which of the following hand tools is used for digging and turning soil in preparation for planting?,
      options: [
        A jembe (hoe), which is a common hand tool used for digging, tilling, and weeding in Kenyan farms.,
        A panga (machete), which is used for cutting vegetation.,
        "A rake, which is used for collecting leaves and leveling soil.,
        A spade, which is used for digging but has a flat blade."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A jembe (hoe), which is a common hand tool used for digging, tilling, and weeding in Kenyan farms.
    })
  },
  {
    id: G4-AG-FT-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Farm Tools and Equipment,
    subtopic: "Hand Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Different farm tools are used for different activities. Which of the following tools is used for planting seeds in rows on a farm?,
      options: [
        A dibber (or planting stick), which is used to make holes for planting seeds at the correct depth and spacing.,
        A rake, which is used to level the soil.,
        A fork, which is used to turn compost.",
        "A watering can, which is used for watering plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A dibber (or planting stick), which is used to make holes for planting seeds at the correct depth and spacing."
    })
  },
  {
    id: "G4-AG-FT-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Farm Tools and Equipment",
    subtopic: "Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper maintenance of farm tools ensures their longevity and efficiency. Which of the following practices is important for maintaining hand tools such as hoes and pangas?,
      options: [
        Cleaning tools after use, sharpening cutting edges regularly, storing tools in a dry place, and oiling metal parts to prevent rust.,
        Leaving tools out in the rain to clean them.,
        "Using tools without any maintenance.,
        Storing tools in a wet, damp area."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning tools after use, sharpening cutting edges regularly, storing tools in a dry place, and oiling metal parts to prevent rust.
    })
  },
  {
    id: G4-AG-FT-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Farm Tools and Equipment,
    subtopic: "Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Safety is important when using farm tools to prevent injuries. Which of the following safety practices should be followed when using sharp tools such as pangas and axes?,
      options: [
        Using tools away from other people, keeping cutting tools sharp and in good condition, and storing them safely when not in use.,
        Using tools in a careless and hurried manner.,
        Leaving sharp tools lying around on the ground.",
        "Using tools with loose handles.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using tools away from other people, keeping cutting tools sharp and in good condition, and storing them safely when not in use."
    })
  },

  // --- AGRICULTURAL MARKETING (3 Materials) ---
  {
    id: "G4-AG-AM-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Agricultural Marketing",
    subtopic: "Selling Produce,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Agricultural marketing involves selling farm produce to get income. Which of the following is the most common way that small-scale farmers sell their produce in Kenya?,
      options: [
        Selling at local markets (marikiti) or directly to consumers and traders in the community.,
        Exporting all produce to international markets.,
        "Selling only to large corporations.,
        Not selling produce and only keeping it for the family."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Selling at local markets (marikiti) or directly to consumers and traders in the community.
    })
  },
  {
    id: G4-AG-AM-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Agricultural Marketing,
    subtopic: "Market Places",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different market places serve farmers in different ways. Which of the following is a place where many farmers gather to sell their produce to buyers and is often held on specific days of the week?,
      options: [
        A market (soko), which is a designated place where farmers bring their produce for sale to traders, retailers, and consumers.,
        A supermarket, which is a retail store.,
        A farm gate, where farmers sell directly from their farms.",
        "A wholesale store, where large quantities are sold.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A market (soko), which is a designated place where farmers bring their produce for sale to traders, retailers, and consumers."
    })
  },
  {
    id: "G4-AG-AM-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Agricultural Marketing",
    subtopic: "Pricing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Pricing of farm produce affects the income that farmers earn. Which of the following factors affects the price of farm produce in the market?,
      options: [
        Supply and demand - when there is a lot of produce in the market, prices are usually lower, while when there is shortage, prices tend to be higher.,
        Only the size of the produce affects price.,
        "The weather has no effect on prices.,
        All produce sells at the same price regardless of quality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Supply and demand - when there is a lot of produce in the market, prices are usually lower, while when there is shortage, prices tend to be higher.
    })
  },

  // --- ENVIRONMENTAL CONSERVATION (3 Materials) ---
  {
    id: G4-AG-EC-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Environmental Conservation,
    subtopic: "Tree Planting",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Tree planting is an important agricultural practice that contributes to environmental conservation. Which of the following is a benefit of planting trees on farms?,
      options: [
        Trees provide shade, prevent soil erosion, improve soil fertility, provide wood and fruit, and enhance the beauty of the landscape.,
        Trees only provide firewood and have no other benefits.,
        Trees take too long to grow and are not worth planting.",
        "Trees reduce soil fertility.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Trees provide shade, prevent soil erosion, improve soil fertility, provide wood and fruit, and enhance the beauty of the landscape."
    })
  },
  {
    id: "G4-AG-EC-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Environmental Conservation",
    subtopic: "Agroforestry,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Agroforestry is a land use system that combines trees with crops or livestock on the same piece of land. Which of the following is a benefit of agroforestry systems?,
      options: [
        Agroforestry improves soil fertility through leaf litter, provides shade for crops, offers income from tree products, and increases biodiversity.,
        Agroforestry reduces crop production by competing with crops.,
        "Agroforestry only provides firewood and no other benefits.,
        Agroforestry is harmful to the environment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry improves soil fertility through leaf litter, provides shade for crops, offers income from tree products, and increases biodiversity.
    })
  },
  {
    id: G4-AG-EC-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Environmental Conservation,
    subtopic: "Environmental Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Taking care of the environment is everyone's responsibility. Which of the following actions can farmers take to protect the environment and promote sustainable farming?,
      options: [
        Practicing soil conservation, planting trees, using organic fertilizers, and managing waste properly.,
        Using only chemical fertilizers and pesticides regardless of their effects.,
        Burning crop residues and clearing forests for farming.",
        "Ignoring environmental concerns and focusing only on production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Practicing soil conservation, planting trees, using organic fertilizers, and managing waste properly."
    })
  },

  // --- ORGANIC FARMING (3 Materials) ---
  {
    id: "G4-AG-OF-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Organic Farming",
    subtopic: "Composting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Composting is the process of decomposing organic waste to produce nutrient-rich compost. Which of the following materials is suitable for composting?,
      options: [
        Kitchen waste, grass clippings, leaves, animal manure, and other organic materials that can decompose to form rich compost.,
        Plastic and glass materials.,
        "Metal cans and other inorganic waste.,
        Only dry leaves without any other materials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kitchen waste, grass clippings, leaves, animal manure, and other organic materials that can decompose to form rich compost.
    })
  },
  {
    id: G4-AG-OF-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Organic Farming,
    subtopic: "Natural Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Natural pest control methods help farmers reduce pests without using harmful chemicals. Which of the following is an organic pest control method?,
      options: [
        Using biological controls such as natural predators (e.g., birds, beneficial insects) and botanical pesticides such as neem extract to control pests.,
        Using only synthetic chemical pesticides to kill all pests.,
        Ignoring pests and allowing them to damage crops.",
        "Using pesticides without considering their effects.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using biological controls such as natural predators (e.g., birds, beneficial insects) and botanical pesticides such as neem extract to control pests."
    })
  },
  {
    id: "G4-AG-OF-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Organic Farming",
    subtopic: "Organic Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Organic farming avoids synthetic chemicals and uses natural methods for production. Which of the following is a practice associated with organic farming?,
      options: [
        Using organic fertilizers (manure, compost), crop rotation, biological pest control, and maintaining soil health through natural processes.,
        Using synthetic fertilizers and chemical pesticides extensively.,
        "Planting the same crop continuously without rotation.,
        Using genetically modified organisms without regulation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using organic fertilizers (manure, compost), crop rotation, biological pest control, and maintaining soil health through natural processes.
    })
  },

  // --- FOOD PROCESSING AND PRESERVATION (2 Materials) ---
  {
    id: G4-AG-FP-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Food Processing and Preservation,
    subtopic: "Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Food preservation extends the shelf life of food and reduces waste. Which of the following is a traditional method of preserving food in Kenya?,
      options: [
        Sun drying, where foods such as maize, beans, and vegetables are dried in the sun to prevent spoilage.,
        Refrigeration, which is a modern method of preserving food.,
        Canning, which involves preserving food in cans.",
        "Freezing, which involves keeping food at very low temperatures.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sun drying, where foods such as maize, beans, and vegetables are dried in the sun to prevent spoilage."
    })
  },
  {
    id: "G4-AG-FP-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Food Processing and Preservation",
    subtopic: "Processing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Food processing involves changing raw food materials into products that can be consumed or stored for longer periods. Which of the following is a processed food product from maize?,
      options: [
        Maize flour (unga wa mahindi), which is produced by grinding dried maize grains and is used to make ugali and porridge.,
        Cooking oil, which is processed from oil seeds.,
        "Sugar, which is processed from sugarcane.,
        Milk powder, which is processed from milk."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maize flour (unga wa mahindi), which is produced by grinding dried maize grains and is used to make ugali and porridge.
    })
  },

  // --- CLIMATE AND AGRICULTURE (2 Materials) ---
  {
    id: G4-AG-CA-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Climate and Agriculture,
    subtopic: "Weather Patterns",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Weather patterns greatly affect agricultural activities and crop production. Which of the following weather conditions is most favorable for crop growth in Kenya?,
      options: [
        Well-distributed rainfall (short and long rains) and moderate temperatures, which allow crops to grow and mature properly.,
        Long periods of drought with no rainfall.,
        Excessive rainfall leading to flooding.",
        "Very high temperatures with no rainfall.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Well-distributed rainfall (short and long rains) and moderate temperatures, which allow crops to grow and mature properly."
    })
  },
  {
    id: "G4-AG-CA-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Climate and Agriculture",
    subtopic: "Effect on Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Climate change is affecting agricultural production in Kenya. Which of the following is an effect of climate change on agriculture?,
      options: [
        More frequent droughts, unpredictable rainfall patterns, increased pests and diseases, and reduced crop yields.,
        More favorable and predictable weather patterns.,
        "Increased crop yields and food security.,
        Reduced pest and disease problems."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "More frequent droughts, unpredictable rainfall patterns, increased pests and diseases, and reduced crop yields.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL CONSERVATION (4 Materials) ---
  {
    id: G5-AG-SC-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Advanced Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Advanced soil conservation methods are used to protect soil from erosion and maintain its fertility. Which of the following methods involves creating level platforms on steep slopes to reduce water runoff and soil erosion?,
      options: [
        Terracing, which involves building stepped platforms on steep slopes to slow water flow and prevent soil erosion.,
        Contour farming, which involves planting crops along the contours of the land.,
        Strip cropping, which involves planting different crops in alternating strips.",
        "Mulching, which involves covering the soil with organic materials.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Terracing, which involves building stepped platforms on steep slopes to slow water flow and prevent soil erosion."
    })
  },
  {
    id: "G5-AG-SC-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Soil Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper soil management is essential for sustainable agricultural production. Which of the following practices helps improve soil structure and fertility?,
      options: [
        Crop rotation, where different crops are grown in sequence to prevent nutrient depletion and reduce pest and disease buildup.,
        Growing the same crop continuously without rotation.,
        "Burning all crop residues after harvest.,
        Using only synthetic fertilizers without organic matter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crop rotation, where different crops are grown in sequence to prevent nutrient depletion and reduce pest and disease buildup.
    })
  },
  {
    id: G5-AG-SC-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Testing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Soil testing helps farmers know the nutrients present in the soil and the fertilizer required for optimal crop growth. Which of the following is the purpose of soil testing?,
      options: [
        To determine the nutrient content, pH level, and type of soil, which helps farmers make informed decisions about fertilizer and lime application.,
        To test only for the presence of pests.,
        To measure the amount of water in the soil.",
        "To determine the size of the farm.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: To determine the nutrient content, pH level, and type of soil, which helps farmers make informed decisions about fertilizer and lime application."
    })
  },
  {
    id: "G5-AG-SC-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Organic Matter,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Organic matter in the soil improves soil structure, water-holding capacity, and nutrient availability. Which of the following sources of organic matter is commonly used by farmers?,
      options: [
        "Animal manure (cow dung, chicken manure), compost, and crop residues that are added to the soil to improve fertility.,
        Plastic and other synthetic materials.",
        "Only chemical fertilizers without organic materials.,
        Sand and gravel to improve drainage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Animal manure (cow dung, chicken manure), compost, and crop residues that are added to the soil to improve fertility.
    })
  },

  // --- WATER CONSERVATION AND IRRIGATION (4 Materials) ---
  {
    id: G5-AG-WC-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Rainwater Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Rainwater harvesting is becoming increasingly important in farming. Which of the following is a benefit of harvesting rainwater on a farm?,
      options: [
        Rainwater harvesting provides water during dry seasons, reduces soil erosion, and lowers the cost of water for irrigation.,
        Rainwater harvesting is expensive and not beneficial for farmers.,
        Rainwater harvesting only works in urban areas.",
        "Rainwater harvesting has no benefit for crop production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Rainwater harvesting provides water during dry seasons, reduces soil erosion, and lowers the cost of water for irrigation."
    })
  },
  {
    id: "G5-AG-WC-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Drip Irrigation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Drip irrigation is a modern irrigation method that saves water and improves crop yields. Why is drip irrigation considered more water-efficient than traditional irrigation methods?,
      options: [
        Drip irrigation delivers water directly to the plant's root zone drop by drop, reducing water loss through evaporation and runoff, and only wetting the soil around the roots.,
        Drip irrigation uses more water than other methods but is easier to install.,
        "Drip irrigation is not suitable for any crop production.,
        Drip irrigation wastes water by spraying it in the air."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drip irrigation delivers water directly to the plant's root zone drop by drop, reducing water loss through evaporation and runoff, and only wetting the soil around the roots.
    })
  },
  {
    id: G5-AG-WC-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Water Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Water management on the farm involves using water efficiently and avoiding waste. Which of the following practices helps conserve water in agriculture?,
      options: [
        Using mulch to cover the soil, planting drought-resistant crops, and avoiding watering during the hottest part of the day.,
        Overwatering crops to ensure they have enough water.,
        Using flood irrigation for all crops.",
        "Ignoring water conservation practices.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using mulch to cover the soil, planting drought-resistant crops, and avoiding watering during the hottest part of the day."
    })
  },
  {
    id: "G5-AG-WC-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Irrigation Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Different irrigation systems are used depending on the farm size and water availability. Which of the following is an advantage of sprinkler irrigation?,
      options: [
        Sprinkler irrigation can cover large areas, can be used on uneven land, and mimics natural rainfall, but it may lose some water to evaporation.,
        Sprinkler irrigation is only suitable for small gardens.,
        "Sprinkler irrigation wastes a lot of water.,
        Sprinkler irrigation requires no equipment or maintenance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sprinkler irrigation can cover large areas, can be used on uneven land, and mimics natural rainfall, but it may lose some water to evaporation.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G5-AG-CP-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cereal Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Cereal crops are important for food security and income generation. Which of the following cereals is commonly grown in the dry regions of Kenya and is used as a staple food?,
      options: [
        Sorghum, which is drought-tolerant and grown in the drylands of Kenya for food and animal feed.,
        Rice, which requires a lot of water and is grown in paddy fields.,
        Wheat, which is grown in cooler highland areas.",
        "Barley, which is grown for malting and animal feed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sorghum, which is drought-tolerant and grown in the drylands of Kenya for food and animal feed."
    })
  },
  {
    id: "G5-AG-CP-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Legume Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Legume crops are important in agriculture because they fix nitrogen in the soil, improving fertility for subsequent crops. Which of the following is an important legume crop grown in Kenya?,
      options: [
        Groundnuts (peanuts), which are grown for their nuts and also fix nitrogen in the soil, improving fertility for other crops.,
        Maize, which is a cereal crop.",
        "Potatoes, which are root crops.,
        Cassava, which is a root crop."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Groundnuts (peanuts), which are grown for their nuts and also fix nitrogen in the soil, improving fertility for other crops.
    })
  },
  {
    id: G5-AG-CP-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Vegetable Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Vegetables are essential for a balanced diet and good health. Which of the following vegetables is a major cash crop in Kenya, often exported to international markets?,
      options: [
        Green beans (French beans), which are a major export vegetable crop grown in many parts of Kenya.,
        Cabbage, which is grown for local consumption.,
        Spinach, which is grown in home gardens.",
        "Onions, which are grown for local markets.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Green beans (French beans), which are a major export vegetable crop grown in many parts of Kenya."
    })
  },
  {
    id: "G5-AG-CP-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Fruit Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fruit crops provide income and nutrition to farmers and families. Which of the following fruits is a major export crop in Kenya, known for its high demand in European markets?,
      options: [
        Avocado (also known as avocado pear), which is a major export fruit from Kenya, prized for its creamy flesh and nutritional value.,
        Oranges, which are grown for local consumption.",
        "Lemons, which are grown for juice and flavoring.,
        Papaya, which is grown in tropical regions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Avocado (also known as avocado pear), which is a major export fruit from Kenya, prized for its creamy flesh and nutritional value.
    })
  },
  {
    id: G5-AG-CP-05",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cash Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Cash crops are grown primarily for sale rather than for food. Which of the following is a major cash crop in Kenya that is used in the production of chocolate and other confectionery?,
      options: [
        Cocoa, which is grown in coastal and Western Kenya regions and is used to make chocolate and other products.,
        Sugarcane, which is grown for sugar production.,
        Coffee, which is a major export crop grown in the highlands.",
        "Tea, which is a major export crop grown in the highlands.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cocoa, which is grown in coastal and Western Kenya regions and is used to make chocolate and other products."
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: "G5-AG-LP-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Dairy Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Dairy farming is an important agricultural enterprise in Kenya. Which of the following practices is most important for ensuring high milk production from dairy cows?,
      options: [
        Feeding cows a balanced diet, providing clean water, maintaining proper hygiene, regular milking, and veterinary care.,
        Only feeding cows grass without any supplementary feed.,
        "Milking cows infrequently to save time.,
        Ignoring the health and hygiene of the dairy animals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Feeding cows a balanced diet, providing clean water, maintaining proper hygiene, regular milking, and veterinary care.
    })
  },
  {
    id: G5-AG-LP-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Poultry Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Poultry farming is a popular and profitable enterprise in Kenya. Which of the following is a key requirement for successful poultry farming?,
      options: [
        Providing a clean and well-ventilated house, proper feeding, vaccination against diseases, and clean drinking water.,
        Keeping poultry in crowded and unsanitary conditions.,
        Feeding poultry only on kitchen scraps without proper nutrition.",
        "Ignoring disease prevention and vaccination.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing a clean and well-ventilated house, proper feeding, vaccination against diseases, and clean drinking water."
    })
  },
  {
    id: "G5-AG-LP-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Maintaining animal health is crucial for livestock productivity. Which of the following is a sign that a farm animal may be sick and requires attention?,
      options: [
        Reduced appetite, lethargy, abnormal behavior, coughing, diarrhea, and changes in body condition are signs that an animal may be sick.,
        The animal is eating well and is very active.,
        "The animal has a shiny coat and bright eyes.,
        The animal is producing well and gaining weight."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Reduced appetite, lethargy, abnormal behavior, coughing, diarrhea, and changes in body condition are signs that an animal may be sick.
    })
  },
  {
    id: G5-AG-LP-04",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Feed",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Animal feed is essential for livestock production and must provide the required nutrients. Which of the following is a source of protein for livestock feed?,
      options: [
        Soybean meal, cottonseed cake, and fishmeal are sources of protein used in livestock feed for growth and milk production.,
        Only grass and hay, which are sources of fiber.,
        Millet and sorghum, which are sources of energy.",
        "Salt, which is a mineral supplement.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Soybean meal, cottonseed cake, and fishmeal are sources of protein used in livestock feed for growth and milk production."
    })
  },
  {
    id: "G5-AG-LP-05",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Housing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper housing is essential for livestock health and production. Which of the following features is important in a livestock shelter?,
      options: [
        Good ventilation, protection from weather and predators, proper drainage, and enough space for the animals to move freely.,
        A dark and enclosed space with no ventilation.,
        "A structure that is overcrowded with no space for movement.,
        A leaking roof with no drainage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Good ventilation, protection from weather and predators, proper drainage, and enough space for the animals to move freely.
    })
  },

  // --- FARM STRUCTURES (3 Materials) ---
  {
    id: G5-AG-FS-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Types of Structures",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Farm structures are important for storing produce and housing livestock. Which of the following farm structures is used to store dry grains such as maize and beans?,
      options: [
        A granary (silika), which is a structure designed to store dry grains and protect them from insects, rodents, and moisture.,
        A dairy shed, which houses dairy cows.,
        A poultry house, which houses chickens.",
        "A greenhouse, which is used for growing vegetables.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A granary (silika), which is a structure designed to store dry grains and protect them from insects, rodents, and moisture."
    })
  },
  {
    id: "G5-AG-FS-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Construction,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Farm structures need to be properly constructed to serve their purpose. Which of the following is important when constructing a livestock shed?,
      options: [
        Using durable materials, proper orientation for sunlight and ventilation, and ensuring the structure is safe and comfortable for animals.,
        Using any available materials regardless of quality.,
        "Constructing the shed in a low-lying area prone to flooding.,
        Building the shed without considering ventilation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using durable materials, proper orientation for sunlight and ventilation, and ensuring the structure is safe and comfortable for animals.
    })
  },
  {
    id: G5-AG-FS-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Regular maintenance is necessary to keep farm structures in good condition. Which of the following is a maintenance practice for farm structures?,
      options: [
        Regularly inspecting and repairing roofs, walls, and fences, treating wooden structures against pests, and cleaning structures regularly.,
        Ignoring minor repairs until the structure collapses.,
        Building new structures instead of maintaining old ones.",
        "Leaving structures in a poor state of repair.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regularly inspecting and repairing roofs, walls, and fences, treating wooden structures against pests, and cleaning structures regularly."
    })
  },

  // --- AGRIBUSINESS (3 Materials) ---
  {
    id: "G5-AG-AB-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Farm Records,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Farm records help farmers track their income, expenses, and production. Which of the following is an important farm record to keep?,
      options: [
        "A record of all income and expenses, including costs of inputs, labor, and revenue from produce sales.,
        A record of only the expenses without income.",
        "A record of only the production without costs.,
        No records, as they are not important for farming."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A record of all income and expenses, including costs of inputs, labor, and revenue from produce sales.
    })
  },
  {
    id: G5-AG-AB-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Marketing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Marketing is important for selling farm produce and maximizing income. Which of the following is a strategy that farmers can use to get better prices for their produce?,
      options: [
        Value addition (processing produce before sale), selling during times of scarcity, and forming cooperatives to sell in bulk.,
        Selling all produce immediately after harvest when prices are low.,
        Ignoring market conditions and selling at any price.",
        "Only selling to the first buyer who comes along.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Value addition (processing produce before sale), selling during times of scarcity, and forming cooperatives to sell in bulk."
    })
  },
  {
    id: "G5-AG-AB-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Entrepreneurship in agriculture involves starting and managing a farm enterprise to make a profit. Which of the following is a characteristic of a successful agripreneur?,
      options: [
        Being innovative, willing to take calculated risks, keeping good records, and seeking knowledge about new farming methods and markets.,
        Avoiding any risks and sticking to traditional methods only.,
        "Not planning for the business and just hoping for success.,
        Ignoring market information and making decisions arbitrarily."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Being innovative, willing to take calculated risks, keeping good records, and seeking knowledge about new farming methods and markets.
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: G5-AG-AF-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Benefits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Agroforestry has many benefits for farmers and the environment. Which of the following is a major benefit of integrating trees into farming systems?,
      options: [
        Trees improve soil fertility, reduce erosion, provide shade, produce fruit and timber, and can improve micro-climates for crop growth.,
        Trees compete with crops and reduce yields.,
        Trees take up too much space and have no benefit for farmers.",
        "Trees are harmful to livestock and reduce biodiversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Trees improve soil fertility, reduce erosion, provide shade, produce fruit and timber, and can improve micro-climates for crop growth."
    })
  },
  {
    id: "G5-AG-AF-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Managing agroforestry systems involves planting, pruning, and harvesting trees. Which of the following practices helps maintain tree health in an agroforestry system?,
      options: [
        "Regular pruning, mulching, watering young trees, and protecting trees from livestock and fires.,
        Planting trees and leaving them to grow without any care.",
        "Cutting all trees for timber without replanting.,
        Allowing livestock to damage tree saplings."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular pruning, mulching, watering young trees, and protecting trees from livestock and fires.
    })
  },
  {
    id: G5-AG-AF-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Species Selection",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Choosing the right tree species is important for successful agroforestry. Which of the following tree species is commonly grown in Kenyan farms for its nitrogen-fixing ability and timber?,
      options: [
        Grevillea robusta, which is a fast-growing tree that fixes nitrogen, provides timber, and is grown widely in Kenyan farms.,
        Eucalyptus, which is grown for timber.,
        Acacia, which is drought-resistant.",
        "Mangrove, which grows in coastal areas.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Grevillea robusta, which is a fast-growing tree that fixes nitrogen, provides timber, and is grown widely in Kenyan farms."
    })
  },

  // --- FOOD SECURITY (3 Materials) ---
  {
    id: "G5-AG-FS-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Food Production,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Food security exists when all people have physical and economic access to sufficient, safe, and nutritious food. Which of the following is a factor that promotes food security in a community?,
      options: [
        "Diversified farming, good storage facilities, access to markets, and policies that support small-scale farmers.,
        Relying only on one crop for all food needs.",
        "Not having any food storage systems.,
        Ignoring the needs of the most vulnerable community members."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Diversified farming, good storage facilities, access to markets, and policies that support small-scale farmers.
    })
  },
  {
    id: G5-AG-FS-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Food Storage",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proper food storage is essential for food security. Which of the following is a good food storage practice that prevents post-harvest losses?,
      options: [
        Storing grains in clean, dry containers, treating them with pesticides, and ensuring good ventilation to prevent fungal growth.,
        Storing grains in damp and poorly ventilated areas.,
        Leaving harvested grains in the field for long periods.",
        "Mixing stored grains with other materials that attract pests.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Storing grains in clean, dry containers, treating them with pesticides, and ensuring good ventilation to prevent fungal growth."
    })
  },
  {
    id: "G5-AG-FS-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Nutrition is an important aspect of food security, ensuring that people have access to a variety of nutritious foods. Which of the following contributes to improved nutrition in a community?,
      options: [
        Growing diverse crops that provide different nutrients, nutrition education, and access to protein-rich foods and fruits.,
        Growing only staple food crops with limited nutritional value.",
        "Relying only on processed and packaged foods.,
        Ignoring nutrition and only focusing on quantity of food."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Growing diverse crops that provide different nutrients, nutrition education, and access to protein-rich foods and fruits.
    })
  },

  // --- AGRICULTURAL ECONOMICS (2 Materials) ---
  {
    id: G5-AG-AE-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agricultural Economics,
    subtopic: "Supply and Demand",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Supply and demand affect the prices of agricultural products. When the supply of a crop increases dramatically during the harvest season, what typically happens to the price?,
      options: [
        The price usually decreases because there is more produce available than buyers need (high supply, low demand).,
        The price increases because farmers want more money.,
        The price remains unchanged regardless of supply.",
        "The price fluctuates randomly without any pattern.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The price usually decreases because there is more produce available than buyers need (high supply, low demand)."
    })
  },
  {
    id: "G5-AG-AE-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Farm Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Farm planning involves making decisions about what to grow, how much to produce, and how to sell produce. Which of the following is an important step in farm planning?,
      options: [
        "Assessing market demand, calculating input costs, estimating possible returns, and planning based on available resources.,
        Choosing crops randomly without considering market demand.",
        "Ignoring costs and just growing what is easy.,
        Not planning and hoping for the best."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Assessing market demand, calculating input costs, estimating possible returns, and planning based on available resources.
    })
  },

  // --- SUSTAINABLE AGRICULTURE (3 Materials) ---
  {
    id: G5-AG-SA-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Conservation Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Conservation farming is an approach that aims to protect the environment while maintaining agricultural productivity. Which of the following is a principle of conservation farming?,
      options: [
        Minimal soil disturbance (no-till), permanent soil cover (mulching), and crop diversification to maintain soil health.,
        Ploughing the soil deeply and frequently.,
        Leaving the soil bare without any cover.",
        "Monocropping without rotation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Minimal soil disturbance (no-till), permanent soil cover (mulching), and crop diversification to maintain soil health."
    })
  },
  {
    id: "G5-AG-SA-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Sustainable Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable farming practices ensure that land remains productive for future generations. Which of the following practices is considered sustainable?,
      options: [
        Crop rotation, organic farming, integrated pest management, and efficient water use.,
        Chemical-intensive farming with no regard for environmental impact.,
        "Clearing natural forests to expand farmland.,
        Overusing irrigation water without conservation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crop rotation, organic farming, integrated pest management, and efficient water use.
    })
  },
  {
    id: G5-AG-SA-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Climate Resilience",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Climate resilience in agriculture involves adapting farming practices to changing weather patterns and climate conditions. Which of the following practices builds climate resilience in farming?,
      options: [
        Planting drought-tolerant crops, improving water storage, using climate information for planning, and diversifying income sources.,
        Continuing with the same farming practices without adapting.,
        Ignoring weather forecasts and planning.",
        "Planting only high-risk crops regardless of climate conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Planting drought-tolerant crops, improving water storage, using climate information for planning, and diversifying income sources."
    })
  }`nexport const agricultureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL CONSERVATION (5 Materials) ---
  {
    id: "G4-AG-SC-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Types of Soil",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Soil is an important natural resource for agriculture. Different types of soil have different properties that affect crop growth. Which type of soil is best for growing most crops because it holds water well but also drains properly?,
      options: [
        Loam soil, which is a mixture of sand, silt, and clay, providing good drainage and water-holding capacity for healthy plant growth.,
        Clay soil, which drains very slowly and becomes waterlogged easily.,
        "Sandy soil, which drains too quickly and does not hold nutrients well.,
        Gravel soil, which has large particles and cannot support plant growth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Loam soil, which is a mixture of sand, silt, and clay, providing good drainage and water-holding capacity for healthy plant growth.
    })
  },
  {
    id: G4-AG-SC-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Erosion",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Soil erosion is the process by which topsoil is carried away by wind or water, reducing soil fertility. Which of the following human activities is a major cause of soil erosion in agricultural areas?,
      options: [
        Deforestation, where trees are cut down without replanting, leaving the soil exposed to erosion by wind and rain.,
        Planting trees and maintaining forests to protect the soil.,
        Building terraces on sloped land to prevent erosion.",
        "Using cover crops to protect the soil surface.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Deforestation, where trees are cut down without replanting, leaving the soil exposed to erosion by wind and rain."
    })
  },
  {
    id: "G4-AG-SC-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Soil Conservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Various methods can be used to conserve soil and prevent erosion. Which of the following soil conservation methods involves planting crops in rows along the contour of the land to reduce water runoff?,
      options: [
        Contour farming, where crops are planted in rows that follow the natural shape (contours) of the land to slow water flow and reduce erosion.,
        Terracing, which involves creating flat platforms on steep slopes.,
        "Mulching, which involves covering the soil with organic materials.,
        Strip cropping, which involves planting different crops in alternating strips."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Contour farming, where crops are planted in rows that follow the natural shape (contours) of the land to slow water flow and reduce erosion.
    })
  },
  {
    id: G4-AG-SC-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Fertility",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Soil fertility is the ability of soil to provide nutrients for plant growth. Which of the following practices helps maintain and improve soil fertility in farming?,
      options: [
        Adding organic matter such as manure, compost, and crop residues to replenish nutrients and improve soil structure.,
        Burning crop residues after harvest to clear the field.,
        Growing the same crop year after year without rotation.",
        "Using excessive chemical fertilizers without organic matter.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Adding organic matter such as manure, compost, and crop residues to replenish nutrients and improve soil structure."
    })
  },
  {
    id: "G4-AG-SC-05",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Importance of Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Soil conservation is important for sustainable agriculture and food production. Which of the following is a major benefit of conserving soil in agricultural areas?,
      options: [
        Soil conservation maintains soil fertility and productivity, ensuring that crops can continue to grow well for future generations.,
        Soil conservation increases the speed of soil erosion.,
        "Soil conservation reduces the need for farming activities.,
        Soil conservation has no impact on agricultural productivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Soil conservation maintains soil fertility and productivity, ensuring that crops can continue to grow well for future generations.
    })
  },

  // --- WATER CONSERVATION AND IRRIGATION (4 Materials) ---
  {
    id: G4-AG-WC-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Sources of Water",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Water is essential for plant growth and agricultural production. Which of the following is a natural source of water that can be used for irrigation in farming?,
      options: [
        Rivers, lakes, rainfall, and groundwater (wells and boreholes) are natural sources of water used for irrigation.,
        Only rainfall can be used for farming.,
        Salt water from oceans is suitable for irrigation.",
        "Water from sewage can be used without treatment.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Rivers, lakes, rainfall, and groundwater (wells and boreholes) are natural sources of water used for irrigation."
    })
  },
  {
    id: "G4-AG-WC-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Water Conservation Methods,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Water conservation involves using water efficiently and preventing waste. Which of the following is an effective method of conserving water in agricultural areas?,
      options: [
        Mulching, which involves covering the soil with organic materials to reduce evaporation and conserve soil moisture.,
        Allowing water to run off fields without using it.,
        "Using large amounts of water without measuring it.,
        Watering crops during the hottest part of the day."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mulching, which involves covering the soil with organic materials to reduce evaporation and conserve soil moisture.
    })
  },
  {
    id: G4-AG-WC-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Irrigation Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Irrigation is the artificial application of water to crops to supplement rainfall. Which of the following irrigation methods involves watering plants drop by drop near the root zone, conserving water efficiently?,
      options: [
        Drip irrigation, which delivers water directly to the plant roots through small tubes, reducing water loss through evaporation and runoff.,
        Flood irrigation, where water is allowed to flood the entire field.,
        Sprinkler irrigation, where water is sprayed over the crops like rain.",
        "Furrow irrigation, where water runs between rows of crops.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Drip irrigation, which delivers water directly to the plant roots through small tubes, reducing water loss through evaporation and runoff."
    })
  },
  {
    id: "G4-AG-WC-04",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Rainwater Harvesting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Rainwater harvesting involves collecting and storing rainwater for later use in agriculture. Which of the following is a method of harvesting rainwater on a farm?,
      options: [
        Constructing water tanks or ponds to collect and store rainwater from rooftops or surface runoff for use during dry periods.,
        Allowing rainwater to run off the farm without collection.,
        "Using rainwater only for drinking and not for agriculture.,
        Using rainwater immediately without any storage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructing water tanks or ponds to collect and store rainwater from rooftops or surface runoff for use during dry periods.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G4-AG-CP-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cereals",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Cereals are grass-like crops grown for their edible grains and are important staple foods. Which of the following crops is the most widely grown cereal in Kenya and is used to make ugali and flour?,
      options: [
        Maize, which is the main staple food in Kenya and is used to make ugali, porridge, and other traditional dishes.,
        Rice, which is grown in paddy fields and consumed as a main meal.,
        Wheat, which is used to make bread and other baked goods.",
        "Sorghum, which is drought-tolerant and used for porridge and animal feed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maize, which is the main staple food in Kenya and is used to make ugali, porridge, and other traditional dishes."
    })
  },
  {
    id: "G4-AG-CP-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Vegetables,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vegetables are important for providing vitamins and minerals in the diet. Which of the following vegetables is a leafy green that is commonly grown in Kenyan farms and used in traditional dishes such as sukuma wiki?,
      options: [
        Kale (sukuma wiki), which is a leafy vegetable rich in iron and vitamins, commonly grown in small-scale farms across Kenya.,
        Carrots, which are root vegetables grown for their orange roots.,
        "Cabbage, which is a round vegetable with layered leaves.,
        Onions, which are bulb vegetables used as flavoring in cooking."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kale (sukuma wiki), which is a leafy vegetable rich in iron and vitamins, commonly grown in small-scale farms across Kenya.
    })
  },
  {
    id: G4-AG-CP-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Fruits",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Fruits are an important source of vitamins and income for farmers. Which of the following fruits is a major export crop for Kenya and is known for its sweet taste and yellow-orange flesh?,
      options: [
        Mangoes, which are grown in coastal and eastern regions of Kenya and are a major export fruit crop.,
        Avocados, which are grown for their creamy flesh and are exported to international markets.,
        Bananas, which are grown for their starchy fruit and are a staple in many regions.",
        "Oranges, which are citrus fruits grown for their juice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mangoes, which are grown in coastal and eastern regions of Kenya and are a major export fruit crop."
    })
  },
  {
    id: "G4-AG-CP-04",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Root Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Root crops are grown for their underground storage organs and are important food and cash crops. Which of the following root crops is a staple food in many parts of Kenya and is used to make chapati, bread, and fries?,
      options: [
        "Potatoes (Irish potatoes), which are grown in the highlands and are used to make chips, chapati, and various stews.,
        Cassava, which is drought-tolerant and grown in drier regions.",
        "Sweet potatoes, which are grown for their sweet taste and nutritious roots.,
        Carrots, which are grown for their orange roots."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Potatoes (Irish potatoes), which are grown in the highlands and are used to make chips, chapati, and various stews.
    })
  },
  {
    id: G4-AG-CP-05",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Legumes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Legumes are crops that have the ability to fix nitrogen in the soil through their root nodules. Which of the following legumes is an important source of protein in the Kenyan diet and is commonly grown as a cash crop?,
      options: [
        Beans, which are rich in protein and can be grown in various regions, and are a staple in the Kenyan diet.,
        Maize, which is a cereal crop.,
        Wheat, which is used to make flour.",
        "Sorghum, which is drought-tolerant.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Beans, which are rich in protein and can be grown in various regions, and are a staple in the Kenyan diet."
    })
  },

  // --- LIVESTOCK PRODUCTION (4 Materials) ---
  {
    id: "G4-AG-LP-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Cattle,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Cattle are important livestock animals that provide meat, milk, and other products. Which of the following cattle breeds is commonly kept for dairy production in Kenya and is known for its high milk yield?,
      options: [
        "Friesian cattle, which are high-yielding dairy breeds commonly kept in Kenya for milk production.,
        Boran cattle, which are beef cattle kept for meat production.",
        "Zebu cattle, which are indigenous breeds known for their heat tolerance.,
        Angus cattle, which are known for their meat quality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Friesian cattle, which are high-yielding dairy breeds commonly kept in Kenya for milk production.
    })
  },
  {
    id: G4-AG-LP-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Goats",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Goats are hardy animals that can survive in dry areas and provide meat, milk, and skin. Which of the following goat breeds is commonly kept in Kenya for both meat and milk production?,
      options: [
        Galla goats, which are native to Kenya and are raised for both meat and milk in arid and semi-arid areas.,
        Boer goats, which are famous for their meat.,
        Saanen goats, which are dairy goats.",
        "Angora goats, which are kept for their mohair.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Galla goats, which are native to Kenya and are raised for both meat and milk in arid and semi-arid areas."
    })
  },
  {
    id: "G4-AG-LP-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Poultry,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Poultry farming is popular in Kenya for meat and egg production. Which of the following poultry breeds is commonly kept for egg production in Kenya?,
      options: [
        Kenya Brown, which is a breed known for high egg production and is widely kept in Kenya for commercial and small-scale egg farming.,
        Broilers, which are kept for meat production.,
        "Indigenous chickens, which are kept for both meat and eggs.,
        Turkeys, which are kept for their meat."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya Brown, which is a breed known for high egg production and is widely kept in Kenya for commercial and small-scale egg farming.
    })
  },
  {
    id: G4-AG-LP-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Sheep",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Sheep are kept for meat, wool, and milk in various parts of Kenya. Which of the following sheep breeds is commonly kept in Kenya's highlands for wool production?,
      options: [
        Merino sheep, which are known for their high-quality wool and are raised in the highlands of Kenya.,
        Dorper sheep, which are kept for meat production.,
        Red Maasai sheep, which are indigenous to Kenya and are kept for meat.",
        "Crossbred sheep, which are kept for both meat and wool.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Merino sheep, which are known for their high-quality wool and are raised in the highlands of Kenya."
    })
  },

  // --- FARM TOOLS AND EQUIPMENT (4 Materials) ---
  {
    id: "G4-AG-FT-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Farm Tools and Equipment",
    subtopic: "Hand Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Farm tools are essential for carrying out agricultural activities. Which of the following hand tools is used for digging and turning soil in preparation for planting?,
      options: [
        A jembe (hoe), which is a common hand tool used for digging, tilling, and weeding in Kenyan farms.,
        A panga (machete), which is used for cutting vegetation.,
        "A rake, which is used for collecting leaves and leveling soil.,
        A spade, which is used for digging but has a flat blade."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A jembe (hoe), which is a common hand tool used for digging, tilling, and weeding in Kenyan farms.
    })
  },
  {
    id: G4-AG-FT-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Farm Tools and Equipment,
    subtopic: "Hand Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Different farm tools are used for different activities. Which of the following tools is used for planting seeds in rows on a farm?,
      options: [
        A dibber (or planting stick), which is used to make holes for planting seeds at the correct depth and spacing.,
        A rake, which is used to level the soil.,
        A fork, which is used to turn compost.",
        "A watering can, which is used for watering plants.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A dibber (or planting stick), which is used to make holes for planting seeds at the correct depth and spacing."
    })
  },
  {
    id: "G4-AG-FT-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Farm Tools and Equipment",
    subtopic: "Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Proper maintenance of farm tools ensures their longevity and efficiency. Which of the following practices is important for maintaining hand tools such as hoes and pangas?,
      options: [
        Cleaning tools after use, sharpening cutting edges regularly, storing tools in a dry place, and oiling metal parts to prevent rust.,
        Leaving tools out in the rain to clean them.,
        "Using tools without any maintenance.,
        Storing tools in a wet, damp area."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cleaning tools after use, sharpening cutting edges regularly, storing tools in a dry place, and oiling metal parts to prevent rust.
    })
  },
  {
    id: G4-AG-FT-04",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Farm Tools and Equipment,
    subtopic: "Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Safety is important when using farm tools to prevent injuries. Which of the following safety practices should be followed when using sharp tools such as pangas and axes?,
      options: [
        Using tools away from other people, keeping cutting tools sharp and in good condition, and storing them safely when not in use.,
        Using tools in a careless and hurried manner.,
        Leaving sharp tools lying around on the ground.",
        "Using tools with loose handles.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using tools away from other people, keeping cutting tools sharp and in good condition, and storing them safely when not in use."
    })
  },

  // --- AGRICULTURAL MARKETING (3 Materials) ---
  {
    id: "G4-AG-AM-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Agricultural Marketing",
    subtopic: "Selling Produce,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Agricultural marketing involves selling farm produce to get income. Which of the following is the most common way that small-scale farmers sell their produce in Kenya?,
      options: [
        Selling at local markets (marikiti) or directly to consumers and traders in the community.,
        Exporting all produce to international markets.,
        "Selling only to large corporations.,
        Not selling produce and only keeping it for the family."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Selling at local markets (marikiti) or directly to consumers and traders in the community.
    })
  },
  {
    id: G4-AG-AM-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Agricultural Marketing,
    subtopic: "Market Places",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Different market places serve farmers in different ways. Which of the following is a place where many farmers gather to sell their produce to buyers and is often held on specific days of the week?,
      options: [
        A market (soko), which is a designated place where farmers bring their produce for sale to traders, retailers, and consumers.,
        A supermarket, which is a retail store.,
        A farm gate, where farmers sell directly from their farms.",
        "A wholesale store, where large quantities are sold.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A market (soko), which is a designated place where farmers bring their produce for sale to traders, retailers, and consumers."
    })
  },
  {
    id: "G4-AG-AM-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Agricultural Marketing",
    subtopic: "Pricing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Pricing of farm produce affects the income that farmers earn. Which of the following factors affects the price of farm produce in the market?,
      options: [
        Supply and demand - when there is a lot of produce in the market, prices are usually lower, while when there is shortage, prices tend to be higher.,
        Only the size of the produce affects price.,
        "The weather has no effect on prices.,
        All produce sells at the same price regardless of quality."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Supply and demand - when there is a lot of produce in the market, prices are usually lower, while when there is shortage, prices tend to be higher.
    })
  },

  // --- ENVIRONMENTAL CONSERVATION (3 Materials) ---
  {
    id: G4-AG-EC-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Environmental Conservation,
    subtopic: "Tree Planting",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Tree planting is an important agricultural practice that contributes to environmental conservation. Which of the following is a benefit of planting trees on farms?,
      options: [
        Trees provide shade, prevent soil erosion, improve soil fertility, provide wood and fruit, and enhance the beauty of the landscape.,
        Trees only provide firewood and have no other benefits.,
        Trees take too long to grow and are not worth planting.",
        "Trees reduce soil fertility.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Trees provide shade, prevent soil erosion, improve soil fertility, provide wood and fruit, and enhance the beauty of the landscape."
    })
  },
  {
    id: "G4-AG-EC-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Environmental Conservation",
    subtopic: "Agroforestry,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Agroforestry is a land use system that combines trees with crops or livestock on the same piece of land. Which of the following is a benefit of agroforestry systems?,
      options: [
        Agroforestry improves soil fertility through leaf litter, provides shade for crops, offers income from tree products, and increases biodiversity.,
        Agroforestry reduces crop production by competing with crops.,
        "Agroforestry only provides firewood and no other benefits.,
        Agroforestry is harmful to the environment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry improves soil fertility through leaf litter, provides shade for crops, offers income from tree products, and increases biodiversity.
    })
  },
  {
    id: G4-AG-EC-03",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Environmental Conservation,
    subtopic: "Environmental Care",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Taking care of the environment is everyone's responsibility. Which of the following actions can farmers take to protect the environment and promote sustainable farming?,
      options: [
        Practicing soil conservation, planting trees, using organic fertilizers, and managing waste properly.,
        Using only chemical fertilizers and pesticides regardless of their effects.,
        Burning crop residues and clearing forests for farming.",
        "Ignoring environmental concerns and focusing only on production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Practicing soil conservation, planting trees, using organic fertilizers, and managing waste properly."
    })
  },

  // --- ORGANIC FARMING (3 Materials) ---
  {
    id: "G4-AG-OF-01",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Organic Farming",
    subtopic: "Composting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Composting is the process of decomposing organic waste to produce nutrient-rich compost. Which of the following materials is suitable for composting?,
      options: [
        Kitchen waste, grass clippings, leaves, animal manure, and other organic materials that can decompose to form rich compost.,
        Plastic and glass materials.,
        "Metal cans and other inorganic waste.,
        Only dry leaves without any other materials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kitchen waste, grass clippings, leaves, animal manure, and other organic materials that can decompose to form rich compost.
    })
  },
  {
    id: G4-AG-OF-02",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Organic Farming,
    subtopic: "Natural Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Natural pest control methods help farmers reduce pests without using harmful chemicals. Which of the following is an organic pest control method?,
      options: [
        Using biological controls such as natural predators (e.g., birds, beneficial insects) and botanical pesticides such as neem extract to control pests.,
        Using only synthetic chemical pesticides to kill all pests.,
        Ignoring pests and allowing them to damage crops.",
        "Using pesticides without considering their effects.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using biological controls such as natural predators (e.g., birds, beneficial insects) and botanical pesticides such as neem extract to control pests."
    })
  },
  {
    id: "G4-AG-OF-03",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Organic Farming",
    subtopic: "Organic Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Organic farming avoids synthetic chemicals and uses natural methods for production. Which of the following is a practice associated with organic farming?,
      options: [
        Using organic fertilizers (manure, compost), crop rotation, biological pest control, and maintaining soil health through natural processes.,
        Using synthetic fertilizers and chemical pesticides extensively.,
        "Planting the same crop continuously without rotation.,
        Using genetically modified organisms without regulation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using organic fertilizers (manure, compost), crop rotation, biological pest control, and maintaining soil health through natural processes.
    })
  },

  // --- FOOD PROCESSING AND PRESERVATION (2 Materials) ---
  {
    id: G4-AG-FP-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Food Processing and Preservation,
    subtopic: "Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Food preservation extends the shelf life of food and reduces waste. Which of the following is a traditional method of preserving food in Kenya?,
      options: [
        Sun drying, where foods such as maize, beans, and vegetables are dried in the sun to prevent spoilage.,
        Refrigeration, which is a modern method of preserving food.,
        Canning, which involves preserving food in cans.",
        "Freezing, which involves keeping food at very low temperatures.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sun drying, where foods such as maize, beans, and vegetables are dried in the sun to prevent spoilage."
    })
  },
  {
    id: "G4-AG-FP-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Food Processing and Preservation",
    subtopic: "Processing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Food processing involves changing raw food materials into products that can be consumed or stored for longer periods. Which of the following is a processed food product from maize?,
      options: [
        Maize flour (unga wa mahindi), which is produced by grinding dried maize grains and is used to make ugali and porridge.,
        Cooking oil, which is processed from oil seeds.,
        "Sugar, which is processed from sugarcane.,
        Milk powder, which is processed from milk."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maize flour (unga wa mahindi), which is produced by grinding dried maize grains and is used to make ugali and porridge.
    })
  },

  // --- CLIMATE AND AGRICULTURE (2 Materials) ---
  {
    id: G4-AG-CA-01",
    grade: "Grade 4,
    subject: Agriculture",
    topic: "Climate and Agriculture,
    subtopic: "Weather Patterns",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Weather patterns greatly affect agricultural activities and crop production. Which of the following weather conditions is most favorable for crop growth in Kenya?,
      options: [
        Well-distributed rainfall (short and long rains) and moderate temperatures, which allow crops to grow and mature properly.,
        Long periods of drought with no rainfall.,
        Excessive rainfall leading to flooding.",
        "Very high temperatures with no rainfall.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Well-distributed rainfall (short and long rains) and moderate temperatures, which allow crops to grow and mature properly."
    })
  },
  {
    id: "G4-AG-CA-02",
    grade: "Grade 4",
    subject: "Agriculture",
    topic: "Climate and Agriculture",
    subtopic: "Effect on Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Climate change is affecting agricultural production in Kenya. Which of the following is an effect of climate change on agriculture?,
      options: [
        More frequent droughts, unpredictable rainfall patterns, increased pests and diseases, and reduced crop yields.,
        More favorable and predictable weather patterns.,
        "Increased crop yields and food security.,
        Reduced pest and disease problems."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "More frequent droughts, unpredictable rainfall patterns, increased pests and diseases, and reduced crop yields.
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL CONSERVATION (4 Materials) ---
  {
    id: G5-AG-SC-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Advanced Methods",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Advanced soil conservation methods are used to protect soil from erosion and maintain its fertility. Which of the following methods involves creating level platforms on steep slopes to reduce water runoff and soil erosion?,
      options: [
        Terracing, which involves building stepped platforms on steep slopes to slow water flow and prevent soil erosion.,
        Contour farming, which involves planting crops along the contours of the land.,
        Strip cropping, which involves planting different crops in alternating strips.",
        "Mulching, which involves covering the soil with organic materials.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Terracing, which involves building stepped platforms on steep slopes to slow water flow and prevent soil erosion."
    })
  },
  {
    id: "G5-AG-SC-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Soil Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper soil management is essential for sustainable agricultural production. Which of the following practices helps improve soil structure and fertility?,
      options: [
        Crop rotation, where different crops are grown in sequence to prevent nutrient depletion and reduce pest and disease buildup.,
        Growing the same crop continuously without rotation.,
        "Burning all crop residues after harvest.,
        Using only synthetic fertilizers without organic matter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crop rotation, where different crops are grown in sequence to prevent nutrient depletion and reduce pest and disease buildup.
    })
  },
  {
    id: G5-AG-SC-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Testing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Soil testing helps farmers know the nutrients present in the soil and the fertilizer required for optimal crop growth. Which of the following is the purpose of soil testing?,
      options: [
        To determine the nutrient content, pH level, and type of soil, which helps farmers make informed decisions about fertilizer and lime application.,
        To test only for the presence of pests.,
        To measure the amount of water in the soil.",
        "To determine the size of the farm.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: To determine the nutrient content, pH level, and type of soil, which helps farmers make informed decisions about fertilizer and lime application."
    })
  },
  {
    id: "G5-AG-SC-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Organic Matter,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Organic matter in the soil improves soil structure, water-holding capacity, and nutrient availability. Which of the following sources of organic matter is commonly used by farmers?,
      options: [
        "Animal manure (cow dung, chicken manure), compost, and crop residues that are added to the soil to improve fertility.,
        Plastic and other synthetic materials.",
        "Only chemical fertilizers without organic materials.,
        Sand and gravel to improve drainage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Animal manure (cow dung, chicken manure), compost, and crop residues that are added to the soil to improve fertility.
    })
  },

  // --- WATER CONSERVATION AND IRRIGATION (4 Materials) ---
  {
    id: G5-AG-WC-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Rainwater Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Rainwater harvesting is becoming increasingly important in farming. Which of the following is a benefit of harvesting rainwater on a farm?,
      options: [
        Rainwater harvesting provides water during dry seasons, reduces soil erosion, and lowers the cost of water for irrigation.,
        Rainwater harvesting is expensive and not beneficial for farmers.,
        Rainwater harvesting only works in urban areas.",
        "Rainwater harvesting has no benefit for crop production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Rainwater harvesting provides water during dry seasons, reduces soil erosion, and lowers the cost of water for irrigation."
    })
  },
  {
    id: "G5-AG-WC-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Drip Irrigation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Drip irrigation is a modern irrigation method that saves water and improves crop yields. Why is drip irrigation considered more water-efficient than traditional irrigation methods?,
      options: [
        Drip irrigation delivers water directly to the plant's root zone drop by drop, reducing water loss through evaporation and runoff, and only wetting the soil around the roots.,
        Drip irrigation uses more water than other methods but is easier to install.,
        "Drip irrigation is not suitable for any crop production.,
        Drip irrigation wastes water by spraying it in the air."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drip irrigation delivers water directly to the plant's root zone drop by drop, reducing water loss through evaporation and runoff, and only wetting the soil around the roots.
    })
  },
  {
    id: G5-AG-WC-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Conservation and Irrigation,
    subtopic: "Water Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Water management on the farm involves using water efficiently and avoiding waste. Which of the following practices helps conserve water in agriculture?,
      options: [
        Using mulch to cover the soil, planting drought-resistant crops, and avoiding watering during the hottest part of the day.,
        Overwatering crops to ensure they have enough water.,
        Using flood irrigation for all crops.",
        "Ignoring water conservation practices.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using mulch to cover the soil, planting drought-resistant crops, and avoiding watering during the hottest part of the day."
    })
  },
  {
    id: "G5-AG-WC-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Conservation and Irrigation",
    subtopic: "Irrigation Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Different irrigation systems are used depending on the farm size and water availability. Which of the following is an advantage of sprinkler irrigation?,
      options: [
        Sprinkler irrigation can cover large areas, can be used on uneven land, and mimics natural rainfall, but it may lose some water to evaporation.,
        Sprinkler irrigation is only suitable for small gardens.,
        "Sprinkler irrigation wastes a lot of water.,
        Sprinkler irrigation requires no equipment or maintenance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sprinkler irrigation can cover large areas, can be used on uneven land, and mimics natural rainfall, but it may lose some water to evaporation.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G5-AG-CP-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cereal Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Cereal crops are important for food security and income generation. Which of the following cereals is commonly grown in the dry regions of Kenya and is used as a staple food?,
      options: [
        Sorghum, which is drought-tolerant and grown in the drylands of Kenya for food and animal feed.,
        Rice, which requires a lot of water and is grown in paddy fields.,
        Wheat, which is grown in cooler highland areas.",
        "Barley, which is grown for malting and animal feed.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sorghum, which is drought-tolerant and grown in the drylands of Kenya for food and animal feed."
    })
  },
  {
    id: "G5-AG-CP-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Legume Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Legume crops are important in agriculture because they fix nitrogen in the soil, improving fertility for subsequent crops. Which of the following is an important legume crop grown in Kenya?,
      options: [
        Groundnuts (peanuts), which are grown for their nuts and also fix nitrogen in the soil, improving fertility for other crops.,
        Maize, which is a cereal crop.",
        "Potatoes, which are root crops.,
        Cassava, which is a root crop."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Groundnuts (peanuts), which are grown for their nuts and also fix nitrogen in the soil, improving fertility for other crops.
    })
  },
  {
    id: G5-AG-CP-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Vegetable Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Vegetables are essential for a balanced diet and good health. Which of the following vegetables is a major cash crop in Kenya, often exported to international markets?,
      options: [
        Green beans (French beans), which are a major export vegetable crop grown in many parts of Kenya.,
        Cabbage, which is grown for local consumption.,
        Spinach, which is grown in home gardens.",
        "Onions, which are grown for local markets.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Green beans (French beans), which are a major export vegetable crop grown in many parts of Kenya."
    })
  },
  {
    id: "G5-AG-CP-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Fruit Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Fruit crops provide income and nutrition to farmers and families. Which of the following fruits is a major export crop in Kenya, known for its high demand in European markets?,
      options: [
        Avocado (also known as avocado pear), which is a major export fruit from Kenya, prized for its creamy flesh and nutritional value.,
        Oranges, which are grown for local consumption.",
        "Lemons, which are grown for juice and flavoring.,
        Papaya, which is grown in tropical regions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Avocado (also known as avocado pear), which is a major export fruit from Kenya, prized for its creamy flesh and nutritional value.
    })
  },
  {
    id: G5-AG-CP-05",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Cash Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Cash crops are grown primarily for sale rather than for food. Which of the following is a major cash crop in Kenya that is used in the production of chocolate and other confectionery?,
      options: [
        Cocoa, which is grown in coastal and Western Kenya regions and is used to make chocolate and other products.,
        Sugarcane, which is grown for sugar production.,
        Coffee, which is a major export crop grown in the highlands.",
        "Tea, which is a major export crop grown in the highlands.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cocoa, which is grown in coastal and Western Kenya regions and is used to make chocolate and other products."
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: "G5-AG-LP-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Dairy Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Dairy farming is an important agricultural enterprise in Kenya. Which of the following practices is most important for ensuring high milk production from dairy cows?,
      options: [
        Feeding cows a balanced diet, providing clean water, maintaining proper hygiene, regular milking, and veterinary care.,
        Only feeding cows grass without any supplementary feed.,
        "Milking cows infrequently to save time.,
        Ignoring the health and hygiene of the dairy animals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Feeding cows a balanced diet, providing clean water, maintaining proper hygiene, regular milking, and veterinary care.
    })
  },
  {
    id: G5-AG-LP-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Poultry Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Poultry farming is a popular and profitable enterprise in Kenya. Which of the following is a key requirement for successful poultry farming?,
      options: [
        Providing a clean and well-ventilated house, proper feeding, vaccination against diseases, and clean drinking water.,
        Keeping poultry in crowded and unsanitary conditions.,
        Feeding poultry only on kitchen scraps without proper nutrition.",
        "Ignoring disease prevention and vaccination.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing a clean and well-ventilated house, proper feeding, vaccination against diseases, and clean drinking water."
    })
  },
  {
    id: "G5-AG-LP-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Maintaining animal health is crucial for livestock productivity. Which of the following is a sign that a farm animal may be sick and requires attention?,
      options: [
        Reduced appetite, lethargy, abnormal behavior, coughing, diarrhea, and changes in body condition are signs that an animal may be sick.,
        The animal is eating well and is very active.,
        "The animal has a shiny coat and bright eyes.,
        The animal is producing well and gaining weight."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Reduced appetite, lethargy, abnormal behavior, coughing, diarrhea, and changes in body condition are signs that an animal may be sick.
    })
  },
  {
    id: G5-AG-LP-04",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Feed",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Animal feed is essential for livestock production and must provide the required nutrients. Which of the following is a source of protein for livestock feed?,
      options: [
        Soybean meal, cottonseed cake, and fishmeal are sources of protein used in livestock feed for growth and milk production.,
        Only grass and hay, which are sources of fiber.,
        Millet and sorghum, which are sources of energy.",
        "Salt, which is a mineral supplement.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Soybean meal, cottonseed cake, and fishmeal are sources of protein used in livestock feed for growth and milk production."
    })
  },
  {
    id: "G5-AG-LP-05",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Housing,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Proper housing is essential for livestock health and production. Which of the following features is important in a livestock shelter?,
      options: [
        Good ventilation, protection from weather and predators, proper drainage, and enough space for the animals to move freely.,
        A dark and enclosed space with no ventilation.,
        "A structure that is overcrowded with no space for movement.,
        A leaking roof with no drainage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Good ventilation, protection from weather and predators, proper drainage, and enough space for the animals to move freely.
    })
  },

  // --- FARM STRUCTURES (3 Materials) ---
  {
    id: G5-AG-FS-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Types of Structures",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Farm structures are important for storing produce and housing livestock. Which of the following farm structures is used to store dry grains such as maize and beans?,
      options: [
        A granary (silika), which is a structure designed to store dry grains and protect them from insects, rodents, and moisture.,
        A dairy shed, which houses dairy cows.,
        A poultry house, which houses chickens.",
        "A greenhouse, which is used for growing vegetables.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A granary (silika), which is a structure designed to store dry grains and protect them from insects, rodents, and moisture."
    })
  },
  {
    id: "G5-AG-FS-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Construction,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Farm structures need to be properly constructed to serve their purpose. Which of the following is important when constructing a livestock shed?,
      options: [
        Using durable materials, proper orientation for sunlight and ventilation, and ensuring the structure is safe and comfortable for animals.,
        Using any available materials regardless of quality.,
        "Constructing the shed in a low-lying area prone to flooding.,
        Building the shed without considering ventilation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using durable materials, proper orientation for sunlight and ventilation, and ensuring the structure is safe and comfortable for animals.
    })
  },
  {
    id: G5-AG-FS-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Regular maintenance is necessary to keep farm structures in good condition. Which of the following is a maintenance practice for farm structures?,
      options: [
        Regularly inspecting and repairing roofs, walls, and fences, treating wooden structures against pests, and cleaning structures regularly.,
        Ignoring minor repairs until the structure collapses.,
        Building new structures instead of maintaining old ones.",
        "Leaving structures in a poor state of repair.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regularly inspecting and repairing roofs, walls, and fences, treating wooden structures against pests, and cleaning structures regularly."
    })
  },

  // --- AGRIBUSINESS (3 Materials) ---
  {
    id: "G5-AG-AB-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Farm Records,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Farm records help farmers track their income, expenses, and production. Which of the following is an important farm record to keep?,
      options: [
        "A record of all income and expenses, including costs of inputs, labor, and revenue from produce sales.,
        A record of only the expenses without income.",
        "A record of only the production without costs.,
        No records, as they are not important for farming."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A record of all income and expenses, including costs of inputs, labor, and revenue from produce sales.
    })
  },
  {
    id: G5-AG-AB-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Marketing",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Marketing is important for selling farm produce and maximizing income. Which of the following is a strategy that farmers can use to get better prices for their produce?,
      options: [
        Value addition (processing produce before sale), selling during times of scarcity, and forming cooperatives to sell in bulk.,
        Selling all produce immediately after harvest when prices are low.,
        Ignoring market conditions and selling at any price.",
        "Only selling to the first buyer who comes along.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Value addition (processing produce before sale), selling during times of scarcity, and forming cooperatives to sell in bulk."
    })
  },
  {
    id: "G5-AG-AB-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Entrepreneurship,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Entrepreneurship in agriculture involves starting and managing a farm enterprise to make a profit. Which of the following is a characteristic of a successful agripreneur?,
      options: [
        Being innovative, willing to take calculated risks, keeping good records, and seeking knowledge about new farming methods and markets.,
        Avoiding any risks and sticking to traditional methods only.,
        "Not planning for the business and just hoping for success.,
        Ignoring market information and making decisions arbitrarily."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Being innovative, willing to take calculated risks, keeping good records, and seeking knowledge about new farming methods and markets.
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: G5-AG-AF-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Benefits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Agroforestry has many benefits for farmers and the environment. Which of the following is a major benefit of integrating trees into farming systems?,
      options: [
        Trees improve soil fertility, reduce erosion, provide shade, produce fruit and timber, and can improve micro-climates for crop growth.,
        Trees compete with crops and reduce yields.,
        Trees take up too much space and have no benefit for farmers.",
        "Trees are harmful to livestock and reduce biodiversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Trees improve soil fertility, reduce erosion, provide shade, produce fruit and timber, and can improve micro-climates for crop growth."
    })
  },
  {
    id: "G5-AG-AF-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Managing agroforestry systems involves planting, pruning, and harvesting trees. Which of the following practices helps maintain tree health in an agroforestry system?,
      options: [
        "Regular pruning, mulching, watering young trees, and protecting trees from livestock and fires.,
        Planting trees and leaving them to grow without any care.",
        "Cutting all trees for timber without replanting.,
        Allowing livestock to damage tree saplings."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular pruning, mulching, watering young trees, and protecting trees from livestock and fires.
    })
  },
  {
    id: G5-AG-AF-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Species Selection",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Choosing the right tree species is important for successful agroforestry. Which of the following tree species is commonly grown in Kenyan farms for its nitrogen-fixing ability and timber?,
      options: [
        Grevillea robusta, which is a fast-growing tree that fixes nitrogen, provides timber, and is grown widely in Kenyan farms.,
        Eucalyptus, which is grown for timber.,
        Acacia, which is drought-resistant.",
        "Mangrove, which grows in coastal areas.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Grevillea robusta, which is a fast-growing tree that fixes nitrogen, provides timber, and is grown widely in Kenyan farms."
    })
  },

  // --- FOOD SECURITY (3 Materials) ---
  {
    id: "G5-AG-FS-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Food Production,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Food security exists when all people have physical and economic access to sufficient, safe, and nutritious food. Which of the following is a factor that promotes food security in a community?,
      options: [
        "Diversified farming, good storage facilities, access to markets, and policies that support small-scale farmers.,
        Relying only on one crop for all food needs.",
        "Not having any food storage systems.,
        Ignoring the needs of the most vulnerable community members."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Diversified farming, good storage facilities, access to markets, and policies that support small-scale farmers.
    })
  },
  {
    id: G5-AG-FS-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Food Storage",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Proper food storage is essential for food security. Which of the following is a good food storage practice that prevents post-harvest losses?,
      options: [
        Storing grains in clean, dry containers, treating them with pesticides, and ensuring good ventilation to prevent fungal growth.,
        Storing grains in damp and poorly ventilated areas.,
        Leaving harvested grains in the field for long periods.",
        "Mixing stored grains with other materials that attract pests.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Storing grains in clean, dry containers, treating them with pesticides, and ensuring good ventilation to prevent fungal growth."
    })
  },
  {
    id: "G5-AG-FS-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Nutrition is an important aspect of food security, ensuring that people have access to a variety of nutritious foods. Which of the following contributes to improved nutrition in a community?,
      options: [
        Growing diverse crops that provide different nutrients, nutrition education, and access to protein-rich foods and fruits.,
        Growing only staple food crops with limited nutritional value.",
        "Relying only on processed and packaged foods.,
        Ignoring nutrition and only focusing on quantity of food."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Growing diverse crops that provide different nutrients, nutrition education, and access to protein-rich foods and fruits.
    })
  },

  // --- AGRICULTURAL ECONOMICS (2 Materials) ---
  {
    id: G5-AG-AE-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agricultural Economics,
    subtopic: "Supply and Demand",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Supply and demand affect the prices of agricultural products. When the supply of a crop increases dramatically during the harvest season, what typically happens to the price?,
      options: [
        The price usually decreases because there is more produce available than buyers need (high supply, low demand).,
        The price increases because farmers want more money.,
        The price remains unchanged regardless of supply.",
        "The price fluctuates randomly without any pattern.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The price usually decreases because there is more produce available than buyers need (high supply, low demand)."
    })
  },
  {
    id: "G5-AG-AE-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Farm Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Farm planning involves making decisions about what to grow, how much to produce, and how to sell produce. Which of the following is an important step in farm planning?,
      options: [
        "Assessing market demand, calculating input costs, estimating possible returns, and planning based on available resources.,
        Choosing crops randomly without considering market demand.",
        "Ignoring costs and just growing what is easy.,
        Not planning and hoping for the best."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Assessing market demand, calculating input costs, estimating possible returns, and planning based on available resources.
    })
  },

  // --- SUSTAINABLE AGRICULTURE (3 Materials) ---
  {
    id: G5-AG-SA-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Conservation Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Conservation farming is an approach that aims to protect the environment while maintaining agricultural productivity. Which of the following is a principle of conservation farming?,
      options: [
        Minimal soil disturbance (no-till), permanent soil cover (mulching), and crop diversification to maintain soil health.,
        Ploughing the soil deeply and frequently.,
        Leaving the soil bare without any cover.",
        "Monocropping without rotation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Minimal soil disturbance (no-till), permanent soil cover (mulching), and crop diversification to maintain soil health."
    })
  },
  {
    id: "G5-AG-SA-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Sustainable Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable farming practices ensure that land remains productive for future generations. Which of the following practices is considered sustainable?,
      options: [
        Crop rotation, organic farming, integrated pest management, and efficient water use.,
        Chemical-intensive farming with no regard for environmental impact.,
        "Clearing natural forests to expand farmland.,
        Overusing irrigation water without conservation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crop rotation, organic farming, integrated pest management, and efficient water use.
    })
  },
  {
    id: G5-AG-SA-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Climate Resilience",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Climate resilience in agriculture involves adapting farming practices to changing weather patterns and climate conditions. Which of the following practices builds climate resilience in farming?,
      options: [
        Planting drought-tolerant crops, improving water storage, using climate information for planning, and diversifying income sources.,
        Continuing with the same farming practices without adapting.,
        Ignoring weather forecasts and planning.",
        "Planting only high-risk crops regardless of climate conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Planting drought-tolerant crops, improving water storage, using climate information for planning, and diversifying income sources."
    })
  }`nexport const agricultureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL CONSERVATION (4 Materials) ---
  {
    id: "G5-AG-SC-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Advanced Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Advanced soil conservation methods are essential for protecting soil from erosion and maintaining its fertility for sustainable agriculture. Which of the following soil conservation methods involves constructing stepped platforms on steep slopes to reduce water runoff and soil loss?,
      options: [
        Terracing is a soil conservation method where stepped platforms are built on steep slopes to slow water flow and prevent soil erosion.,
        Contour farming involves planting crops along the contours of the land to reduce water runoff.,
        "Mulching is the practice of covering the soil with organic materials to reduce evaporation and erosion.,
        Strip cropping involves planting different crops in alternating strips across the field."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Terracing is a soil conservation method where stepped platforms are built on steep slopes to slow water flow and prevent soil erosion.
    })
  },
  {
    id: G5-AG-SC-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Fertility Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Soil fertility management involves maintaining the nutrient levels in the soil to support healthy crop growth and maximize agricultural productivity. Which of the following practices best maintains soil fertility while also improving soil structure?,
      options: [
        Incorporating organic matter such as manure, compost, and crop residues into the soil to provide nutrients and improve soil structure and water-holding capacity.,
        Using only synthetic chemical fertilizers without any organic matter to provide nutrients to crops.,
        Burning all crop residues after harvest to clear the land quickly.",
        "Allowing the soil to lie fallow without any management practices.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Incorporating organic matter such as manure, compost, and crop residues into the soil to provide nutrients and improve soil structure and water-holding capacity."
    })
  },
  {
    id: "G5-AG-SC-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Soil Conservation",
    subtopic: "Sustainable Soil Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable soil management practices aim to maintain soil health and productivity for future generations. Which of the following practices contributes to sustainable soil management?,
      options: [
        Crop rotation, cover cropping, and reduced tillage are sustainable soil management practices that maintain soil health and prevent degradation.,
        Intensive tillage and deep ploughing improve soil health.,
        "Continuous monocropping with chemical fertilizers maintains soil fertility.,
        Burning crop residues adds nutrients to the soil."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crop rotation, cover cropping, and reduced tillage are sustainable soil management practices that maintain soil health and prevent degradation.
    })
  },
  {
    id: G5-AG-SC-04",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Soil Conservation,
    subtopic: "Soil Erosion Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Controlling soil erosion is crucial for maintaining soil fertility and preventing land degradation. Which of the following is the most effective method for controlling soil erosion in areas with high rainfall?,
      options: [
        Planting cover crops, constructing terraces, and maintaining permanent soil cover through mulching to protect the soil from raindrop impact and runoff.,
        Removing all vegetation from the land to prevent competition with crops.,
        Ploughing the soil deeply and frequently to break up compaction.",
        "Allowing livestock to graze freely on sloping land.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Planting cover crops, constructing terraces, and maintaining permanent soil cover through mulching to protect the soil from raindrop impact and runoff."
    })
  },

  // --- WATER HARVESTING AND CONSERVATION (4 Materials) ---
  {
    id: "G5-AG-WH-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Harvesting and Conservation",
    subtopic: "Rainwater Harvesting,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Rainwater harvesting is the collection and storage of rainwater for agricultural and domestic use. Which of the following is the most effective method of harvesting rainwater for small-scale farming in Kenya?,
      options: [
        Constructing water tanks and pans to collect runoff water from rooftops and catchment areas for use during dry periods and for irrigation.,
        Allowing rainwater to run off the farm without any collection systems.,
        "Using only water from rivers and boreholes without harvesting rainwater.,
        Building large dams without proper catchment management."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructing water tanks and pans to collect runoff water from rooftops and catchment areas for use during dry periods and for irrigation.
    })
  },
  {
    id: G5-AG-WH-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Harvesting and Conservation,
    subtopic: "Water Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Water management in agriculture involves using water efficiently and reducing waste. Which of the following practices helps farmers manage water effectively and ensure that crops receive adequate moisture?,
      options: [
        Using mulch to reduce evaporation, scheduling irrigation during cooler times of the day, and applying water based on crop requirements and soil moisture levels.,
        Overwatering all crops to ensure they have sufficient water.,
        Watering crops only when they show signs of wilting.",
        "Ignoring soil moisture conditions and watering on a fixed schedule.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using mulch to reduce evaporation, scheduling irrigation during cooler times of the day, and applying water based on crop requirements and soil moisture levels."
    })
  },
  {
    id: "G5-AG-WH-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Water Harvesting and Conservation",
    subtopic: "Irrigation Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Irrigation systems are used to supply water to crops when rainfall is insufficient. Which of the following irrigation methods is the most water-efficient and suitable for areas with limited water resources?,
      options: [
        Drip irrigation is the most water-efficient method as it delivers water directly to the plant root zone, reducing evaporation and runoff losses.,
        Flood irrigation is efficient as it covers the entire field with water.,
        "Sprinkler irrigation wastes a lot of water through evaporation.,
        Furrow irrigation is suitable for all crop types."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drip irrigation is the most water-efficient method as it delivers water directly to the plant root zone, reducing evaporation and runoff losses.
    })
  },
  {
    id: G5-AG-WH-04",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Water Harvesting and Conservation,
    subtopic: "Water Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Water conservation involves reducing water loss and using water wisely. Which of the following is an effective water conservation practice that farmers can adopt in their fields?,
      options: [
        Applying organic mulch to the soil surface to reduce evaporation, improve soil structure, and conserve soil moisture for crop growth.,
        Using flood irrigation for all crops to ensure complete soil wetting.,
        Watering crops during the hottest part of the day to prevent heat stress.",
        "Leaving the soil bare and exposed to sunlight.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Applying organic mulch to the soil surface to reduce evaporation, improve soil structure, and conserve soil moisture for crop growth."
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: "G5-AG-CP-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Cereal Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Cereal crops are major sources of food and income for farmers in Kenya. Which of the following cereal crops is primarily grown in the highlands of Kenya and is a key ingredient in making bread and other baked products?,
      options: [
        Wheat is the main cereal crop grown in the Kenyan highlands and is processed into flour for making bread, cakes, and other baked products.,
        Maize is the staple food in Kenya and is used to make ugali and porridge.,
        "Rice is grown in paddy fields and is a major food crop in irrigation schemes.,
        Sorghum is drought-tolerant and grown in dry regions for food and animal feed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Wheat is the main cereal crop grown in the Kenyan highlands and is processed into flour for making bread, cakes, and other baked products.
    })
  },
  {
    id: G5-AG-CP-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Legumes",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Legumes are valuable crops that fix nitrogen in the soil and provide protein-rich food. Which of the following legumes is a common food crop in Kenya and is also used as an animal feed supplement?,
      options: [
        Soya beans (soybeans) are an important legume crop grown for their high protein content and oil, used in human food and animal feed.,
        Maize is a cereal crop, not a legume.,
        Groundnuts are grown for their nuts.",
        "Beans are common in Kenyan meals.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Soya beans (soybeans) are an important legume crop grown for their high protein content and oil, used in human food and animal feed."
    })
  },
  {
    id: "G5-AG-CP-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Vegetable Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Vegetables are vital for nutrition and provide income for many smallholder farmers in Kenya. Which of the following vegetable crops is a major export and a key source of foreign exchange for Kenya?,
      options: [
        French beans (green beans) are a major export vegetable from Kenya, grown for fresh produce markets in Europe and other regions.,
        Kale (sukuma wiki) is grown for local markets.,
        "Cabbage is commonly grown for the domestic market.,
        Tomatoes are grown for both local and export markets."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "French beans (green beans) are a major export vegetable from Kenya, grown for fresh produce markets in Europe and other regions.
    })
  },
  {
    id: G5-AG-CP-04",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Fruit Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Fruit crops are important for nutrition and income diversification. Which of the following fruits has become a major export crop from Kenya, particularly known for its quality in international markets?,
      options: [
        Avocado is a major export fruit from Kenya, with growing demand in European and Asian markets due to its nutritional value and culinary versatility.,
        Mangoes are exported in smaller quantities.,
        Bananas are mainly consumed locally.",
        "Oranges are grown for the domestic market.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Avocado is a major export fruit from Kenya, with growing demand in European and Asian markets due to its nutritional value and culinary versatility."
    })
  },
  {
    id: "G5-AG-CP-05",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Cash Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Cash crops are grown primarily for sale and are important for generating income for farmers. Which of the following cash crops is a significant source of income for small-scale farmers in the Rift Valley and Central regions of Kenya?,
      options: [
        Coffee is a major cash crop in Kenya, grown in the highlands and sold through cooperatives and auction systems, generating significant export earnings.,
        Sugarcane is grown in Western Kenya for sugar production.,
        "Tea is a major cash crop grown in the highlands.,
        Cotton is grown in dry regions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Coffee is a major cash crop in Kenya, grown in the highlands and sold through cooperatives and auction systems, generating significant export earnings.
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: G5-AG-LP-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Dairy Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Dairy farming is an important economic activity in Kenya, providing milk and meat. Which of the following management practices is most critical for maximizing milk production in dairy cows?,
      options: [
        Providing a balanced diet with adequate energy, protein, and minerals, ensuring clean water, regular milking, and maintaining proper hygiene in the milking shed.,
        Feeding cows only grass and water without any supplements.,
        Milking cows once every two days to save time.",
        "Keeping cows in overcrowded and unsanitary conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing a balanced diet with adequate energy, protein, and minerals, ensuring clean water, regular milking, and maintaining proper hygiene in the milking shed."
    })
  },
  {
    id: "G5-AG-LP-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Poultry Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Poultry farming is a profitable agribusiness that can be started with relatively low capital. Which of the following is essential for successful poultry farming and helps prevent disease outbreaks?,
      options: [
        Providing a clean, well-ventilated house with proper biosecurity measures, vaccination programs, and good feeding practices to maintain flock health.,
        Keeping poultry in crowded conditions to save space.,
        "Feeding poultry on kitchen waste only.,
        Not vaccinating birds to save money."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Providing a clean, well-ventilated house with proper biosecurity measures, vaccination programs, and good feeding practices to maintain flock health.
    })
  },
  {
    id: G5-AG-LP-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Health",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Maintaining good animal health is essential for productive livestock farming. Which of the following is an early sign of illness in farm animals that farmers should monitor?,
      options: [
        Reduced feed intake, lethargy, abnormal behavior, changes in body temperature, and production losses are early signs that an animal may be unwell.,
        An animal that is active and has a good appetite.,
        An animal with a shiny coat and normal behavior.",
        "An animal that is producing well and is healthy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reduced feed intake, lethargy, abnormal behavior, changes in body temperature, and production losses are early signs that an animal may be unwell."
    })
  },
  {
    id: "G5-AG-LP-04",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Feed,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Quality animal feed is essential for livestock health and production. Which of the following feed components provides energy for livestock and is commonly used in animal diets?,
      options: [
        Maize (corn) and sorghum are energy-rich feed components used in livestock diets to provide carbohydrates for maintenance, growth, and production.,
        Fish meal provides protein to livestock.,
        "Mineral supplements provide essential minerals.,
        Hay provides fiber for ruminant animals."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maize (corn) and sorghum are energy-rich feed components used in livestock diets to provide carbohydrates for maintenance, growth, and production.
    })
  },
  {
    id: G5-AG-LP-05",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Housing",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Proper housing is essential for livestock health and productivity. Which of the following housing features is most important for the health and welfare of dairy cattle?,
      options: [
        Good ventilation, proper drainage, comfortable resting area, clean water supply, and protection from harsh weather conditions.,
        A dark, enclosed space with no ventilation.,
        A structure with a leaking roof and no drainage.",
        "A crowded pen with no space for animals to lie down.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Good ventilation, proper drainage, comfortable resting area, clean water supply, and protection from harsh weather conditions."
    })
  },

  // --- FARM STRUCTURES (3 Materials) ---
  {
    id: "G5-AG-FS-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Types of Farm Structures,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Farm structures serve various purposes, including livestock housing, crop storage, and processing. Which of the following farm structures is designed specifically to store grains and protect them from pests and moisture?,
      options: [
        "A granary or silo is a farm structure designed for safe storage of grains such as maize, beans, and wheat, protecting them from insects, rodents, and moisture.,
        A dairy shed is used to house dairy cattle.",
        "A poultry house is used to keep chickens.,
        A greenhouse is used for protected crop cultivation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A granary or silo is a farm structure designed for safe storage of grains such as maize, beans, and wheat, protecting them from insects, rodents, and moisture.
    })
  },
  {
    id: G5-AG-FS-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Construction",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " When constructing farm structures, farmers must consider various factors to ensure durability and functionality. Which of the following factors is most important when constructing a livestock shelter?,
      options: [
        Proper site selection (well-drained area), use of durable construction materials, adequate space for animals, and good ventilation are key considerations.,
        Using low-quality materials to save costs.,
        Building in a low-lying area prone to flooding.",
        "Constructing without considering the needs of the livestock.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Proper site selection (well-drained area), use of durable construction materials, adequate space for animals, and good ventilation are key considerations."
    })
  },
  {
    id: "G5-AG-FS-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular maintenance of farm structures extends their lifespan and ensures safety. Which of the following is an important maintenance practice for farm structures?,
      options: [
        Regular inspection, repair of damaged parts, treatment of wooden structures against termites, and cleaning to prevent pest infestation.,
        Ignoring minor damage and only repairing when structures fail.,
        "Not inspecting structures and waiting for them to collapse.,
        Using structures without any form of maintenance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular inspection, repair of damaged parts, treatment of wooden structures against termites, and cleaning to prevent pest infestation.
    })
  },

  // --- AGRIBUSINESS (3 Materials) ---
  {
    id: G5-AG-AB-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Farm Records",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Farm records are essential for making informed business decisions and tracking farm performance. Which of the following records helps a farmer determine whether the farm business is making a profit?,
      options: [
        Income and expenditure records, which track all revenue from produce sales and all expenses on inputs, labor, and other costs, enabling profit calculation.,
        Only production records without any financial information.,
        Records of only expenses without income.",
        "No records as farmers know their business intuitively.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Income and expenditure records, which track all revenue from produce sales and all expenses on inputs, labor, and other costs, enabling profit calculation."
    })
  },
  {
    id: "G5-AG-AB-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Marketing,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Effective marketing is important for farmers to get better prices for their produce. Which of the following strategies helps farmers capture more value from their agricultural produce?,
      options: [
        Value addition through processing (e.g., making flour, juice, or oil), packaging, and branding, which increases the price farmers receive.,
        Selling all produce immediately after harvest without processing.,
        "Ignoring quality standards and selling low-quality produce.,
        Selling only to the first buyer without comparing prices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Value addition through processing (e.g., making flour, juice, or oil), packaging, and branding, which increases the price farmers receive.
    })
  },
  {
    id: G5-AG-AB-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Entrepreneurship in agriculture involves identifying business opportunities and taking calculated risks. Which of the following is an essential quality of a successful agricultural entrepreneur?,
      options: [
        Innovation, willingness to learn new techniques, effective business planning, risk management skills, and the ability to adapt to changing market conditions.,
        Sticking to traditional methods without trying anything new.,
        Not planning for the business and hoping for success.",
        "Ignoring market trends and consumer preferences.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Innovation, willingness to learn new techniques, effective business planning, risk management skills, and the ability to adapt to changing market conditions."
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: "G5-AG-AF-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Benefits of Agroforestry,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Agroforestry integrates trees into farming systems and provides multiple benefits. Which of the following is a major environmental benefit of agroforestry systems?,
      options: [
        Agroforestry improves soil fertility through nitrogen fixation and leaf litter, reduces soil erosion, enhances biodiversity, and helps mitigate climate change by storing carbon.,
        Agroforestry only provides wood for fuel and construction.,
        "Agroforestry competes with crops and reduces yields.,
        Agroforestry has no impact on environmental conservation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry improves soil fertility through nitrogen fixation and leaf litter, reduces soil erosion, enhances biodiversity, and helps mitigate climate change by storing carbon.
    })
  },
  {
    id: G5-AG-AF-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Effective management is important for successful agroforestry systems. Which of the following practices is important for maintaining healthy trees in an agroforestry system?,
      options: [
        Pruning to maintain shape and reduce shading, applying manure or compost, watering during dry periods, and protecting trees from damage by livestock.,
        Planting trees and leaving them completely unattended.,
        Cutting down trees as soon as they reach a certain height.",
        "Allowing livestock to freely browse on tree seedlings.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Pruning to maintain shape and reduce shading, applying manure or compost, watering during dry periods, and protecting trees from damage by livestock."
    })
  },
  {
    id: "G5-AG-AF-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Species Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Selecting appropriate tree species is critical for agroforestry success. Which of the following tree species is commonly used in Kenyan agroforestry systems for its nitrogen-fixing ability and multiple uses?,
      options: [
        Gliricidia sepium is a fast-growing nitrogen-fixing tree widely used in agroforestry for soil improvement, fodder, firewood, and green manure.,
        Eucalyptus is grown for timber but can deplete soil moisture.,
        "Pine trees are grown for timber and wood products.,
        Mangrove trees are grown in coastal regions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gliricidia sepium is a fast-growing nitrogen-fixing tree widely used in agroforestry for soil improvement, fodder, firewood, and green manure.
    })
  },

  // --- FOOD SECURITY (3 Materials) ---
  {
    id: G5-AG-FS-01",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Food Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Food security exists when all people have access to sufficient, safe, and nutritious food. Which of the following is a strategy that improves food security at the household level?,
      options: [
        Diversifying food production through home gardens, keeping small livestock, and preserving surplus produce for times of shortage.,
        Relying entirely on purchased food without producing any.,
        Growing only one type of crop for the whole year.",
        "Not planning for food storage and preservation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Diversifying food production through home gardens, keeping small livestock, and preserving surplus produce for times of shortage."
    })
  },
  {
    id: "G5-AG-FS-02",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Proper food storage is crucial for minimizing post-harvest losses and ensuring food availability throughout the year. Which of the following practices is most effective for storing grains such as maize and beans?,
      options: [
        Drying grains to the correct moisture content, storing them in airtight containers with appropriate pesticides, and protecting them from insects and rodents.,
        Storing grains in sacks in a damp room.,
        "Storing grains in the open where they can be accessed by pests.,
        Storing grains without drying them first."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drying grains to the correct moisture content, storing them in airtight containers with appropriate pesticides, and protecting them from insects and rodents.
    })
  },
  {
    id: G5-AG-FS-03",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Nutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nutrition is an important component of food security. Which of the following strategies helps improve dietary diversity and nutritional outcomes in a community?,
      options: [
        Promoting the consumption of a variety of foods from all food groups, including vegetables, fruits, proteins, and energy-giving foods, through education and accessible food production.,
        Relying only on starchy staple foods without variety.,
        Ignoring nutrition and only focusing on food quantity.",
        "Promoting only processed and packaged foods.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Promoting the consumption of a variety of foods from all food groups, including vegetables, fruits, proteins, and energy-giving foods, through education and accessible food production."
    })
  },

  // --- AGRICULTURAL ECONOMICS (2 Materials) ---
  {
    id: "G5-AG-AE-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Supply and Demand,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The principles of supply and demand determine the prices of agricultural products. If there is a drought that reduces the harvest of vegetables, what effect will this likely have on vegetable prices?,
      options: [
        Vegetable prices will increase because the supply is reduced while demand remains the same or increases.,
        Vegetable prices will decrease because farmers want to sell quickly.",
        "Vegetable prices will remain unchanged regardless of the supply.,
        Vegetable prices will fluctuate based on the weather only."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vegetable prices will increase because the supply is reduced while demand remains the same or increases.
    })
  },
  {
    id: G5-AG-AE-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Agricultural Economics,
    subtopic: "Farm Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Farm planning involves strategic decisions about resource allocation and production. Which of the following is an important element of a farm business plan that helps farmers allocate their resources?,
      options: [
        A budget that estimates income and expenses, a production plan that schedules crop and livestock activities, and a marketing plan that identifies target markets.,
        A plan that only focuses on production without considering costs.,
        A plan that ignores market conditions.",
        "No planning as farmers respond to immediate needs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A budget that estimates income and expenses, a production plan that schedules crop and livestock activities, and a marketing plan that identifies target markets."
    })
  },

  // --- SUSTAINABLE AGRICULTURE (3 Materials) ---
  {
    id: "G5-AG-SA-01",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Conservation Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Conservation farming is an approach that seeks to maintain and improve soil health and productivity. Which of the following is a key principle of conservation farming?,
      options: [
        Minimum soil disturbance (reduced tillage), permanent soil cover (mulching), and crop diversification to maintain and improve soil health.,
        Frequent deep ploughing to aerate the soil.,
        "Leaving the soil bare and exposed.,
        Growing the same crop continuously without rotation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Minimum soil disturbance (reduced tillage), permanent soil cover (mulching), and crop diversification to maintain and improve soil health.
    })
  },
  {
    id: G5-AG-SA-02",
    grade: "Grade 5,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Sustainable Practices",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Sustainable farming practices help protect the environment and maintain agricultural productivity. Which of the following is an example of a sustainable agricultural practice?,
      options: [
        Integrated pest management (IPM), which combines biological, cultural, and chemical control methods to manage pests while minimizing environmental impact.,
        Using only synthetic chemical pesticides regardless of their effects.,
        Monocropping without any crop rotation.",
        "Overusing chemical fertilizers to maximize yields.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Integrated pest management (IPM), which combines biological, cultural, and chemical control methods to manage pests while minimizing environmental impact."
    })
  },
  {
    id: "G5-AG-SA-03",
    grade: "Grade 5",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate Resilience,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Climate-resilient agriculture helps farmers adapt to changing weather patterns and climate variability. Which of the following practices contributes to building climate resilience in agriculture?,
      options: [
        Planting drought-tolerant crop varieties, improving water storage and conservation, and using weather information to plan farming activities.,
        Planting only crops that are susceptible to drought.,
        "Ignoring climate information and continuing with traditional practices.,
        Planting only early-maturing varieties that are not adapted to the area."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Planting drought-tolerant crop varieties, improving water storage and conservation, and using weather information to plan farming activities.
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL SCIENCE (5 Materials) ---
  {
    id: G6-AG-SS-01",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Formation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil formation is a continuous process influenced by various factors over long periods. Which of the following is a major factor that influences soil formation and determines the characteristics of different soil types?,
      options: [
        Climate, parent material, topography, organisms, and time are the five major factors that interact to form different types of soil with distinct characteristics.,
        Only rainfall influences soil formation.,
        Only the type of rocks (parent material) determines soil type.",
        "Temperature is the only factor that affects soil formation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Climate, parent material, topography, organisms, and time are the five major factors that interact to form different types of soil with distinct characteristics."
    })
  },
  {
    id: "G6-AG-SS-02",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Different soil types have distinct physical and chemical properties that affect their suitability for different crops. Which of the following characteristics is associated with clay soils?,
      options: [
        Clay soils have very fine particles, hold water well, and are rich in nutrients, but they can become waterlogged and are heavy and difficult to work.,
        Clay soils are light and porous with large particles.,
        "Clay soils are high in sand content and drain quickly.,
        Clay soils have no ability to hold water or nutrients."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Clay soils have very fine particles, hold water well, and are rich in nutrients, but they can become waterlogged and are heavy and difficult to work.
    })
  },
  {
    id: G6-AG-SS-03",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Fertility",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil fertility refers to the ability of soil to provide essential nutrients for plant growth. Which of the following nutrients is a primary macronutrient that plants need in large quantities and is essential for leaf and vegetative growth?,
      options: [
        Nitrogen is a primary macronutrient essential for leaf and vegetative growth, and is a key component of proteins, chlorophyll, and amino acids.,
        Phosphorus is important for root and flower development.,
        Potassium is important for fruit development and disease resistance.",
        "Iron is a micronutrient needed in smaller quantities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Nitrogen is a primary macronutrient essential for leaf and vegetative growth, and is a key component of proteins, chlorophyll, and amino acids."
    })
  },
  {
    id: "G6-AG-SS-04",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Soil conservation is essential for sustainable agricultural production. Which of the following conservation practices is most effective in preventing water erosion on sloping land?,
      options: [
        Contour farming and terracing slow water flow and reduce soil erosion by creating barriers that capture and hold water, allowing it to infiltrate the soil.,
        Leaving the land bare and exposed to runoff.,
        "Ploughing up and down the slope.,
        Burning all vegetation on the slope."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Contour farming and terracing slow water flow and reduce soil erosion by creating barriers that capture and hold water, allowing it to infiltrate the soil.
    })
  },
  {
    id: G6-AG-SS-05",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Testing",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Soil testing provides valuable information for making informed fertilizer decisions. Which of the following is a reason why farmers should conduct soil tests before applying fertilizers?,
      options: [
        Soil tests determine the nutrient content and pH of the soil, helping farmers apply the right type and amount of fertilizer to meet crop needs without wasting money or causing environmental damage.,
        Soil tests are only useful for large-scale farmers.,
        Soil tests provide no useful information for fertilizer application.",
        "Soil tests are expensive and not worth the cost.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Soil tests determine the nutrient content and pH of the soil, helping farmers apply the right type and amount of fertilizer to meet crop needs without wasting money or causing environmental damage."
    })
  },

  // --- WATER MANAGEMENT (4 Materials) ---
  {
    id: "G6-AG-WM-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Sources,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Farmers need to understand available water sources to ensure adequate supply for agricultural production. Which of the following is an important water source for farming in Kenya's dry and semi-arid areas?,
      options: [
        Groundwater (wells and boreholes) is a crucial water source for farming in dry regions, providing a reliable supply for irrigation, especially during dry seasons.,
        Rivers and lakes are only available during rainy seasons.,
        "Rainfall is not a source of water for agriculture.,
        Oceans provide fresh water for farming."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Groundwater (wells and boreholes) is a crucial water source for farming in dry regions, providing a reliable supply for irrigation, especially during dry seasons.
    })
  },
  {
    id: G6-AG-WM-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Irrigation Technologies",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Irrigation technologies help farmers produce crops throughout the year. Which of the following irrigation technologies is best suited for small-scale farmers with limited water resources?,
      options: [
        Drip irrigation is ideal for small-scale farmers with limited water resources because it delivers water directly to the plant roots, reducing losses and improving efficiency.,
        Flood irrigation is suitable for all farm sizes.,
        Sprinkler irrigation uses less water than drip irrigation.",
        "Furrow irrigation is the most water-efficient method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Drip irrigation is ideal for small-scale farmers with limited water resources because it delivers water directly to the plant roots, reducing losses and improving efficiency."
    })
  },
  {
    id: "G6-AG-WM-03",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Water conservation techniques help farmers manage water resources effectively. Which of the following conservation techniques involves constructing small basins around plants to capture rainfall and reduce runoff?,
      options: [
        Zai pits or planting basins are small pits dug around plants that capture and store rainwater, reducing runoff and improving water infiltration for crops.,
        Mulching involves covering the soil with organic materials.,
        "Terracing is building stepped platforms on slopes.,
        Contour farming is planting along the contours of the land."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Zai pits or planting basins are small pits dug around plants that capture and store rainwater, reducing runoff and improving water infiltration for crops.
    })
  },
  {
    id: G6-AG-WM-04",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Irrigation Scheduling",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Irrigation scheduling determines when and how much water to apply to crops. Which of the following factors should be considered when scheduling irrigation?,
      options: [
        Crop type, growth stage, soil moisture levels, weather conditions, and available water resources should be considered to determine irrigation timing and amounts.,
        Only the time of year matters for irrigation.,
        All crops need the same amount of water.",
        "Irrigation scheduling is only based on the farmer's schedule.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Crop type, growth stage, soil moisture levels, weather conditions, and available water resources should be considered to determine irrigation timing and amounts."
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: "G6-AG-CP-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Field Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Field crops are grown on large areas and are important for food security and income. Which of the following is a key field crop in the coastal region of Kenya and is a source of cooking fat?,
      options: [
        Coconut is a major field crop in the coastal region of Kenya, providing both food and income through its products, especially cooking oil, copra, and other products.,
        Maize is grown in the highlands.,
        "Tea is grown in the highlands.,
        Coffee is grown in the highlands."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Coconut is a major field crop in the coastal region of Kenya, providing both food and income through its products, especially cooking oil, copra, and other products.
    })
  },
  {
    id: G6-AG-CP-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Horticultural Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Horticultural crops include fruits, vegetables, and flowers grown for fresh consumption or processing. Which of the following is an important horticultural crop that has become a major export earner for Kenya?,
      options: [
        Cut flowers (especially roses) have become a major export crop for Kenya, earning significant foreign exchange and providing employment in the horticultural sector.,
        Wheat is a field crop, not horticultural.,
        Maize is a field crop, not horticultural.",
        "Sugarcane is a field crop, not horticultural.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cut flowers (especially roses) have become a major export crop for Kenya, earning significant foreign exchange and providing employment in the horticultural sector."
    })
  },
  {
    id: "G6-AG-CP-03",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Crop Management Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Crop management involves various practices that promote healthy growth and maximize yields. Which of the following practices involves removing unwanted plants that compete with crops for nutrients, water, and light?,
      options: [
        "Weeding is the removal of unwanted plants (weeds) that compete with crops for nutrients, water, and light, reducing yields and increasing pest problems.,
        Pruning involves cutting of parts of the plant.",
        "Mulching involves covering the soil with organic material.,
        Fertilization involves adding nutrients to the soil."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Weeding is the removal of unwanted plants (weeds) that compete with crops for nutrients, water, and light, reducing yields and increasing pest problems.
    })
  },
  {
    id: G6-AG-CP-04",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Pest Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pests are organisms that damage crops and reduce yields. Which of the following is an integrated pest management strategy that uses natural enemies to control pest populations?,
      options: [
        Biological control uses natural enemies such as predators, parasites, and pathogens to control pest populations, reducing the need for chemical pesticides.,
        Using only synthetic chemical pesticides to kill pests.,
        Ignoring pests and allowing them to damage crops.",
        "Using pesticides without monitoring pest populations.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Biological control uses natural enemies such as predators, parasites, and pathogens to control pest populations, reducing the need for chemical pesticides."
    })
  },
  {
    id: "G6-AG-CP-05",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Harvesting,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Harvesting is the process of gathering mature crops from the field. Which of the following is the best time to harvest maize for optimal quality and storage?,
      options: [
        Maize should be harvested when the grain moisture content is about 13-15%, the husks are dry, and the grains are hard and well-filled, to ensure good quality and safe storage.,
        Maize can be harvested at any time regardless of moisture content.,
        "Maize should be harvested immediately after flowering.,
        Maize should be left in the field to dry completely."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maize should be harvested when the grain moisture content is about 13-15%, the husks are dry, and the grains are hard and well-filled, to ensure good quality and safe storage.
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: G6-AG-LP-01",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Cattle",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Cattle are important livestock animals that provide milk, meat, and other products. Which of the following cattle breeds is particularly adapted to dry conditions and is kept for milk production in Kenya's arid regions?,
      options: [
        Zebu cattle (indigenous breeds) are adapted to dry conditions and are kept for milk production in Kenya's dry and semi-arid regions due to their heat tolerance and ability to survive on limited resources.,
        Friesian cattle are adapted to cool highland regions.,
        Ayrshire cattle are dairy breeds from the highlands.",
        "Jersey cattle are adapted to highland regions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Zebu cattle (indigenous breeds) are adapted to dry conditions and are kept for milk production in Kenya's dry and semi-arid regions due to their heat tolerance and ability to survive on limited resources."
    })
  },
  {
    id: "G6-AG-LP-02",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Goats,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Goats are versatile animals that are important for smallholder farmers. Which of the following goat breeds is kept for both meat and milk production and is widely distributed in Kenya?,
      options: [
        Galla goats are a dual-purpose breed kept for both meat and milk, and are widely distributed across Kenya, especially in the drier regions.,
        Boer goats are specialized for meat production.,
        "Saanen goats are specialized dairy breeds.,
        Angora goats are kept for mohair production."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Galla goats are a dual-purpose breed kept for both meat and milk, and are widely distributed across Kenya, especially in the drier regions.
    })
  },
  {
    id: G6-AG-LP-03",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Poultry",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Poultry farming provides eggs and meat for nutrition and income. Which of the following is a common management practice for ensuring good egg production in layers?,
      options: [
        Providing balanced feed with adequate calcium and protein, maintaining a consistent day length, and ensuring proper lighting in the poultry house.,
        Feeding layers only on kitchen scraps.,
        Keeping layers in crowded conditions.",
        "Not supplementing feed with calcium.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing balanced feed with adequate calcium and protein, maintaining a consistent day length, and ensuring proper lighting in the poultry house."
    })
  },
  {
    id: "G6-AG-LP-04",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Sheep,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sheep are kept for wool, meat, and other products. Which of the following sheep breeds is kept for meat production in Kenya's semi-arid and pastoral regions?,
      options: [
        "Red Maasai sheep are a hardy indigenous breed kept for meat production in Kenya's semi-arid and pastoral regions, adapted to dry conditions and resistant to some diseases.,
        Merino sheep are kept for wool production.",
        "Dorper sheep are a crossbred meat breed.,
        Corriedale sheep are kept for wool production."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Red Maasai sheep are a hardy indigenous breed kept for meat production in Kenya's semi-arid and pastoral regions, adapted to dry conditions and resistant to some diseases.
    })
  },
  {
    id: G6-AG-LP-05",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Pig Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pig farming is a profitable livestock enterprise that can be practiced with relatively low capital. Which of the following is an important aspect of pig management for good health and productivity?,
      options: [
        Providing adequate housing with proper ventilation, balanced feed with sufficient protein and energy, clean water, and a strict hygiene protocol to prevent disease.,
        Keeping pigs in overcrowded and unsanitary conditions.,
        Feeding pigs only on household waste.",
        "Not vaccinating pigs against common diseases.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Providing adequate housing with proper ventilation, balanced feed with sufficient protein and energy, clean water, and a strict hygiene protocol to prevent disease."
    })
  },

  // --- FARM MECHANIZATION (3 Materials) ---
  {
    id: "G6-AG-FM-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Farm Machinery,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Farm mechanization involves the use of machinery to reduce labor and improve productivity. Which of the following farm machines is commonly used for preparing land in large-scale farming?,
      options: [
        A tractor is a powerful farm machine used for land preparation, including ploughing, harrowing, and planting, greatly reducing labor and time.,
        A power tiller is a small machine used for gardening.,
        "A combine harvester is used for harvesting and threshing.,
        A cultivator is used for secondary tillage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A tractor is a powerful farm machine used for land preparation, including ploughing, harrowing, and planting, greatly reducing labor and time.
    })
  },
  {
    id: G6-AG-FM-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Farm Mechanization,
    subtopic: "Hand Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Hand tools remain important for small-scale farmers. Which of the following hand tools is used for transplanting seedlings and making holes for planting?,
      options: [
        A dibber (dibbling stick) is a hand tool used for transplanting seedlings and making holes for planting seeds, ensuring proper depth and spacing.,
        A jembe (hoe) is used for digging and weeding.,
        A panga (machete) is used for clearing vegetation.",
        "A rake is used for leveling the soil.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A dibber (dibbling stick) is a hand tool used for transplanting seedlings and making holes for planting seeds, ensuring proper depth and spacing."
    })
  },
  {
    id: "G6-AG-FM-03",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Equipment Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Regular maintenance of farm tools and machinery extends their lifespan and ensures safety. Which of the following is a good maintenance practice for tractors and machinery?,
      options: [
        Regular servicing, checking and changing oil, cleaning and lubricating moving parts, and following the manufacturer's recommended maintenance schedule.,
        Using machinery without any regular maintenance.,
        "Not servicing machinery until it breaks down.,
        Ignoring manufacturer's maintenance recommendations."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular servicing, checking and changing oil, cleaning and lubricating moving parts, and following the manufacturer's recommended maintenance schedule.
    })
  },

  // --- AGRICULTURAL EXTENSION (3 Materials) ---
  {
    id: G6-AG-AE-01",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Advisory Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Agricultural extension services provide farmers with information and support to improve farming practices. Which of the following is a key role of agricultural extension officers?,
      options: [
        Extension officers provide technical advice and training to farmers on improved farming methods, new technologies, pest control, and market information.,
        Extension officers only work in offices and don't visit farms.,
        Extension officers are responsible only for distributing farm inputs.",
        "Extension officers only work with large-scale farmers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Extension officers provide technical advice and training to farmers on improved farming methods, new technologies, pest control, and market information."
    })
  },
  {
    id: "G6-AG-AE-02",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Agricultural Extension",
    subtopic: "Farmer Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Farmer education is important for improving agricultural productivity and sustainability. Which of the following is an effective method of delivering agricultural education to farmers in rural areas?,
      options: [
        Farmer field schools (FFS) are hands-on, participatory learning approaches where farmers learn new practices and solve problems together under the guidance of facilitators.,
        Only using formal lectures and classroom teaching.,
        "Providing written materials without follow-up support.,
        Ignoring farmers' practical experience in the learning process."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Farmer field schools (FFS) are hands-on, participatory learning approaches where farmers learn new practices and solve problems together under the guidance of facilitators.
    })
  },
  {
    id: G6-AG-AE-03",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Technology Transfer",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Technology transfer involves sharing innovations and new agricultural technologies with farmers. Which of the following is a challenge in transferring agricultural technology to small-scale farmers?,
      options: [
        Limited access to information, high cost of new technologies, limited financial resources, and lack of appropriate infrastructure are common challenges for small-scale farmers.,
        Small-scale farmers always adopt new technologies quickly.,
        All new technologies are affordable for small-scale farmers.",
        "Small-scale farmers have unlimited access to information.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Limited access to information, high cost of new technologies, limited financial resources, and lack of appropriate infrastructure are common challenges for small-scale farmers."
    })
  },

  // --- AGRIBUSINESS AND MARKETING (3 Materials) ---
  {
    id: "G6-AG-AM-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Value Addition,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Value addition involves processing farm produce to increase its value and marketability. Which of the following is an example of value addition in agribusiness?,
      options: [
        Processing mangoes into juice, drying vegetables for sale, or turning milk into cheese or yoghurt, which increases the shelf life and value of produce.,
        Selling raw, unprocessed produce directly from the farm.,
        "Only selling produce at the lowest possible price.,
        Ignoring the processing of produce."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Processing mangoes into juice, drying vegetables for sale, or turning milk into cheese or yoghurt, which increases the shelf life and value of produce.
    })
  },
  {
    id: G6-AG-AM-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Agribusiness and Marketing,
    subtopic: "Market Access",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Accessing markets is important for farmers to get fair prices for their produce. Which of the following strategies helps farmers improve their market access?,
      options: [
        Forming marketing cooperatives, linking with agribusiness companies, improving product quality, and using market information to identify best prices and buyers.,
        Selling only to local markets without exploring better opportunities.,
        Ignoring quality requirements for export markets.",
        "Not seeking market information and advice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Forming marketing cooperatives, linking with agribusiness companies, improving product quality, and using market information to identify best prices and buyers."
    })
  },
  {
    id: "G6-AG-AM-03",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Cooperative Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Agricultural cooperatives help farmers pool resources and market their products collectively. Which of the following is an advantage of joining a cooperative for small-scale farmers?,
      options: [
        Cooperatives help farmers get better prices through collective marketing, reduce transaction costs, provide access to credit and inputs, and offer technical training.,
        Cooperatives are only beneficial for large-scale farmers.,
        "Cooperatives eliminate competition among farmers.,
        Cooperatives have no effect on farmers' income."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooperatives help farmers get better prices through collective marketing, reduce transaction costs, provide access to credit and inputs, and offer technical training.
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: G6-AG-AF-01",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Silvopastoral Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Silvopastoral systems integrate trees, livestock, and pasture on the same land. Which of the following is a benefit of integrating trees into livestock grazing systems?,
      options: [
        Silvopastoral systems provide shade for livestock, improve fodder availability, reduce soil erosion, and provide additional income from tree products.,
        Trees compete with pasture and reduce livestock production.,
        Silvopastoral systems are only suitable for large ranches.",
        "Trees have no benefits for livestock grazing systems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Silvopastoral systems provide shade for livestock, improve fodder availability, reduce soil erosion, and provide additional income from tree products."
    })
  },
  {
    id: "G6-AG-AF-02",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Fruit Trees,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Fruit trees provide important nutritional and economic benefits for farm families. Which of the following fruit trees is commonly grown in tropical agroforestry systems for its high nutritional value and income potential?,
      options: [
        Mango trees are widely grown in tropical agroforestry systems for their nutritious fruit, providing both income and nutritional benefits to farm families.,
        Eucalyptus trees are grown for timber.,
        "Pine trees are grown for construction.,
        Grevillea trees are grown for fuelwood."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mango trees are widely grown in tropical agroforestry systems for their nutritious fruit, providing both income and nutritional benefits to farm families.
    })
  },
  {
    id: G6-AG-AF-03",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Multipurpose Trees",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Multipurpose trees provide various products and benefits, including food, fodder, and timber. Which of the following is a characteristic of a multipurpose tree in agroforestry?,
      options: [
        A multipurpose tree provides multiple benefits such as food (fruits or nuts), fodder, fertilizer (nitrogen fixation), fuelwood, timber, and soil conservation.,
        A multipurpose tree only provides one benefit.,
        A multipurpose tree is not useful for farmers.",
        "Multipurpose trees only grow in specific climatic conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A multipurpose tree provides multiple benefits such as food (fruits or nuts), fodder, fertilizer (nitrogen fixation), fuelwood, timber, and soil conservation."
    })
  },

  // --- FOOD PROCESSING AND VALUE ADDITION (2 Materials) ---
  {
    id: "G6-AG-FP-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Food Processing and Value Addition",
    subtopic: "Processing Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Food processing transforms raw agricultural produce into products that can be used or sold. Which of the following is a processing technique used to extend the shelf life of fruits and vegetables?,
      options: [
        Drying is an important processing technique that reduces moisture content in fruits and vegetables, preventing spoilage and extending shelf life.,
        Only fresh produce can be consumed.,
        "Fruits and vegetables cannot be processed.,
        All processing reduces nutritional value."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Drying is an important processing technique that reduces moisture content in fruits and vegetables, preventing spoilage and extending shelf life.
    })
  },
  {
    id: G6-AG-FP-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Food Processing and Value Addition,
    subtopic: "Product Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Product development involves creating new products from agricultural produce. Which of the following is a value-added product that can be made from milk?,
      options: [
        Yoghurt, cheese, butter, and ghee are value-added products that can be made from milk, providing additional income for farmers and nutritious products for consumers.,
        Only fresh milk can be sold.,
        Milk cannot be processed into other products.",
        "All milk products have the same value as raw milk.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Yoghurt, cheese, butter, and ghee are value-added products that can be made from milk, providing additional income for farmers and nutritious products for consumers."
    })
  },

  // --- SUSTAINABLE AGRICULTURE (2 Materials) ---
  {
    id: "G6-AG-SA-01",
    grade: "Grade 6",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate-Smart Agriculture,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Climate-smart agriculture addresses climate change while improving food security. Which of the following is an example of a climate-smart farming practice that increases resilience to drought?,
      options: [
        Conservation agriculture (minimum tillage, permanent soil cover, and crop rotation) increases soil water-holding capacity and reduces vulnerability to drought.,
        Deep ploughing reduces soil moisture conservation.,
        "Burning crop residues increases soil fertility.,
        Monocropping improves resilience to drought."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conservation agriculture (minimum tillage, permanent soil cover, and crop rotation) increases soil water-holding capacity and reduces vulnerability to drought.
    })
  },
  {
    id: G6-AG-SA-02",
    grade: "Grade 6,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Environmental Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Environmental conservation practices help protect the natural resource base for agriculture. Which of the following is a practice that contributes to the conservation of biodiversity on farms?,
      options: [
        Maintaining agroforestry systems, planting hedgerows and field margins, and conserving natural habitats provide refuges for beneficial insects and wildlife.,
        Clearing all natural vegetation for agriculture.,
        Using only monocropping systems.",
        "Eliminating all insects and animals from the farm.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maintaining agroforestry systems, planting hedgerows and field margins, and conserving natural habitats provide refuges for beneficial insects and wildlife."
    })
  }`nexport const agricultureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL SCIENCE AND CONSERVATION (5 Materials) ---
  {
    id: "G7-AG-SC-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Formation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil formation is a complex process involving the weathering of parent material and the action of various factors over time. Which of the following factors is the primary determinant of soil color and texture in a particular region?,
      options: [
        Parent material is the primary determinant of soil color and texture, as different rocks weather to produce distinct soil types with varying mineral composition and particle size.,
        Climate only determines the color of soil.,
        "Soil organisms have no effect on soil formation.,
        Time is not a factor in soil formation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Parent material is the primary determinant of soil color and texture, as different rocks weather to produce distinct soil types with varying mineral composition and particle size.
    })
  },
  {
    id: G7-AG-SC-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Different soil types have distinct characteristics that affect their agricultural potential. Which of the following soil types is characterized by its dark color, high organic matter content, and excellent fertility?,
      options: [
        Chernozem soils are characterized by their dark color, high organic matter content, and exceptional fertility, making them highly productive for agriculture.,
        Sandy soils are dark colored and very fertile.,
        Clay soils are light in color and have low fertility.",
        "Laterite soils have high organic matter content.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chernozem soils are characterized by their dark color, high organic matter content, and exceptional fertility, making them highly productive for agriculture."
    })
  },
  {
    id: "G7-AG-SC-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Fertility,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil fertility is determined by the availability of essential plant nutrients. Which of the following is a micronutrient that is required in small amounts but is essential for plant growth and development?,
      options: [
        Zinc is a micronutrient essential for plant growth, playing a key role in enzyme function and protein synthesis, despite being required in small quantities.,
        Nitrogen is a primary macronutrient.,
        "Phosphorus is a secondary macronutrient.,
        Calcium is a secondary macronutrient."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Zinc is a micronutrient essential for plant growth, playing a key role in enzyme function and protein synthesis, despite being required in small quantities.
    })
  },
  {
    id: G7-AG-SC-04",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil conservation practices are essential for maintaining soil productivity and preventing degradation. Which of the following practices involves creating depressions or basins to capture rainfall and reduce runoff?,
      options: [
        Zai pits are small planting basins that capture rainfall, concentrate nutrients, and reduce runoff, improving crop yields in dryland areas.,
        Terracing is building stepped platforms on slopes.,
        Mulching is covering the soil with organic materials.",
        "Contour farming is planting along the contours of the land.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Zai pits are small planting basins that capture rainfall, concentrate nutrients, and reduce runoff, improving crop yields in dryland areas."
    })
  },
  {
    id: "G7-AG-SC-05",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Proper soil conservation practices can prevent or reduce the effects of soil degradation on agricultural productivity. Which of the following is a major cause of soil erosion in Kenya's agricultural areas?,
      options: [
        Deforestation is a major cause of soil erosion in Kenya, as removal of trees and vegetation leaves the soil exposed to wind and water erosion, reducing soil fertility and agricultural productivity.,
        Terracing is a major cause of soil erosion.,
        "Mulching increases soil erosion.,
        Contour farming causes soil erosion."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Deforestation is a major cause of soil erosion in Kenya, as removal of trees and vegetation leaves the soil exposed to wind and water erosion, reducing soil fertility and agricultural productivity.
    })
  },

  // --- WATER MANAGEMENT (4 Materials) ---
  {
    id: G7-AG-WM-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Sources",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Understanding various water sources is crucial for agricultural water management. Which of the following is a renewable water source that is replenished naturally through the hydrological cycle?,
      options: [
        Surface water from rivers and lakes is a renewable water source that is continuously replenished by rainfall and runoff, making it an important resource for irrigation.,
        Groundwater is non-renewable water.,
        Desalinated water is a renewable source.",
        "Meltwater is not renewable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Surface water from rivers and lakes is a renewable water source that is continuously replenished by rainfall and runoff, making it an important resource for irrigation."
    })
  },
  {
    id: "G7-AG-WM-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Irrigation Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Irrigation systems are essential for crop production in areas with limited rainfall. Which of the following irrigation systems is most suitable for irrigating steep slopes and uneven terrain?,
      options: [
        Sprinkler irrigation is suitable for sloping and uneven terrain as it applies water uniformly over the land without requiring perfectly level ground.,
        Flood irrigation is suitable for sloping areas.,
        "Drip irrigation is not suitable for uneven terrain.,
        Furrow irrigation is best for steep slopes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sprinkler irrigation is suitable for sloping and uneven terrain as it applies water uniformly over the land without requiring perfectly level ground.
    })
  },
  {
    id: G7-AG-WM-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Water conservation is essential for ensuring reliable water supply for agriculture. Which of the following practices helps farmers conserve water by reducing evaporation and improving infiltration?,
      options: [
        Mulching reduces evaporation by covering the soil surface with organic materials, improves water infiltration, and helps conserve soil moisture for crop growth.,
        Flood irrigation conserves water.,
        Bare soil is best for water conservation.",
        "Deep ploughing reduces evaporation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mulching reduces evaporation by covering the soil surface with organic materials, improves water infiltration, and helps conserve soil moisture for crop growth."
    })
  },
  {
    id: "G7-AG-WM-04",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Irrigation Efficiency,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Irrigation efficiency measures how effectively water is delivered and used by crops. Which of the following factors reduces irrigation efficiency in agricultural systems?,
      options: [
        Water loss through evaporation, runoff, and deep percolation reduces irrigation efficiency, requiring more water to achieve the same crop yields.,
        Applying water during the cooler times of day improves efficiency.,
        "Using drip irrigation reduces efficiency.,
        Drip irrigation is inefficient."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Water loss through evaporation, runoff, and deep percolation reduces irrigation efficiency, requiring more water to achieve the same crop yields.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G7-AG-CP-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Field Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Field crops are an important source of food and income for Kenyan farmers. Which of the following field crops is a dual-purpose crop that provides food for humans and feed for livestock?,
      options: [
        Sorghum is a dual-purpose crop that provides both food and feed, and is also used for brewing and as a fodder crop, making it valuable in mixed farming systems.,
        Wheat is only used for human food.,
        Maize is only used for human food.",
        "Rice is only used for human food.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sorghum is a dual-purpose crop that provides both food and feed, and is also used for brewing and as a fodder crop, making it valuable in mixed farming systems."
    })
  },
  {
    id: "G7-AG-CP-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Horticultural Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Horticultural crops are high-value products that contribute significantly to agricultural income. Which of the following horticultural crops is grown in Kenya and is an important source of vitamins and minerals in the diet?,
      options: [
        Kale (sukuma wiki) is an important horticultural crop in Kenya that provides essential vitamins and minerals, particularly vitamin C, vitamin K, and iron.,
        Maize is a horticultural crop.,
        "Wheat is a horticultural crop.,
        Sorghum is a horticultural crop."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kale (sukuma wiki) is an important horticultural crop in Kenya that provides essential vitamins and minerals, particularly vitamin C, vitamin K, and iron.
    })
  },
  {
    id: G7-AG-CP-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Crop Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Effective crop management involves various practices that promote healthy growth and maximize yields. Which of the following practices is important for ensuring the establishment of young crop plants?,
      options: [
        Thinning is the removal of excess seedlings to ensure adequate spacing, reduce competition for resources, and allow each plant to develop properly.,
        Overcrowding improves crop yields.,
        Thinning reduces crop yields.",
        "Thinning is not important for crop production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Thinning is the removal of excess seedlings to ensure adequate spacing, reduce competition for resources, and allow each plant to develop properly."
    })
  },
  {
    id: "G7-AG-CP-04",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Pest and Disease Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Pest and disease control is essential for protecting crops and ensuring optimal yields. Which of the following is an integrated pest management strategy that combines biological and chemical controls?,
      options: [
        Integrated pest management combines biological control (natural enemies), cultural practices (crop rotation), and chemical control (selective pesticides) for sustainable pest management.,
        Only using chemical pesticides is integrated pest management.,
        "Integrated pest management avoids all chemical use.,
        Integrated pest management relies only on biological control."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Integrated pest management combines biological control (natural enemies), cultural practices (crop rotation), and chemical control (selective pesticides) for sustainable pest management.
    })
  },
  {
    id: G7-AG-CP-05",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Harvesting is the process of gathering mature crops from the field. Which of the following is the recommended time for harvesting vegetables to ensure high quality and nutritional value?,
      options: [
        Vegetables should be harvested at their peak maturity, when they are tender, crisp, and have the best color and flavor for optimal quality and nutrition.,
        Vegetables can be harvested at any time.,
        Vegetables should be harvested only after they wilt.",
        "Vegetables should be harvested before they are ripe.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Vegetables should be harvested at their peak maturity, when they are tender, crisp, and have the best color and flavor for optimal quality and nutrition."
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: "G7-AG-LP-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Cattle Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Cattle farming is a major agricultural enterprise in Kenya, providing milk, meat, and other products. Which of the following is an important management practice for beef cattle production?,
      options: [
        "Beef cattle management includes regular weighing and monitoring, providing adequate nutrition, controlling parasites, and ensuring the animals are healthy and gaining weight.,
        Beef cattle should not be monitored for weight gain.",
        "Parasite control is not important in beef production.,
        Beef cattle can survive on poor quality feed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Beef cattle management includes regular weighing and monitoring, providing adequate nutrition, controlling parasites, and ensuring the animals are healthy and gaining weight.
    })
  },
  {
    id: G7-AG-LP-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Goat Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Goat farming is a valuable enterprise for smallholder farmers, providing meat, milk, and other products. Which of the following is an adaptation that makes goats well-suited for dry areas?,
      options: [
        Goats are adapted to dry areas due to their ability to conserve water efficiently, tolerate high temperatures, and feed on a variety of tough, low-quality vegetation.,
        Goats require large amounts of water daily.,
        Goats are very sensitive to heat.",
        "Goats only eat fresh green grass.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Goats are adapted to dry areas due to their ability to conserve water efficiently, tolerate high temperatures, and feed on a variety of tough, low-quality vegetation."
    })
  },
  {
    id: "G7-AG-LP-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Poultry Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Poultry farming is a popular enterprise due to its relatively low startup costs and high returns. Which of the following is an important factor in the success of a poultry enterprise?,
      options: [
        Good management practices, including proper feeding, clean water, vaccination, and a clean environment, are essential for successful poultry production.,
        Poultry can survive without any management.,
        "Poultry feed does not affect productivity.,
        Vaccinations are not necessary for poultry."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Good management practices, including proper feeding, clean water, vaccination, and a clean environment, are essential for successful poultry production.
    })
  },
  {
    id: G7-AG-LP-04",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Sheep",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Sheep are kept for wool, meat, and other products in various parts of Kenya. Which of the following is a common sheep management practice?,
      options: [
        Regular shearing, parasite control, and providing adequate nutrition are important management practices for sheep, particularly for wool production and maintenance.,
        Sheep management only involves feeding.,
        Parasite control is not important for sheep.",
        "Shearing is harmful to sheep.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regular shearing, parasite control, and providing adequate nutrition are important management practices for sheep, particularly for wool production and maintenance."
    })
  },
  {
    id: "G7-AG-LP-05",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Pig Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Pig farming can be a profitable enterprise with proper management. Which of the following is the most important health management practice in pig farming?,
      options: [
        Preventing and controlling diseases through proper hygiene, vaccination, and quarantine of new animals is the most important health management practice in pig farming.,
        Pig health management is not important.,
        "Vaccination is not necessary for pigs.,
        Pigs do not get diseases."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Preventing and controlling diseases through proper hygiene, vaccination, and quarantine of new animals is the most important health management practice in pig farming.
    })
  },

  // --- FARM STRUCTURES (3 Materials) ---
  {
    id: G7-AG-FS-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Types of Farm Structures",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Farm structures serve various purposes, including production and processing. Which of the following farm structures is used for crop production under controlled conditions?,
      options: [
        A greenhouse is a structure used for crop production under controlled conditions, allowing for better management of temperature, humidity, and pests, and extending the growing season.,
        A granary is used for storage.,
        A dairy shed is used for housing cattle.",
        "A poultry house is used for housing chickens.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A greenhouse is a structure used for crop production under controlled conditions, allowing for better management of temperature, humidity, and pests, and extending the growing season."
    })
  },
  {
    id: "G7-AG-FS-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Construction,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Proper construction techniques are important for the durability and functionality of farm structures. Which of the following is important in constructing a protective shelter for livestock?,
      options: [
        Using quality building materials, ensuring proper drainage and ventilation, and constructing the shelter in an appropriate location are all important in livestock shelter construction.,
        Livestock shelters do not require drainage.,
        "Ventilation is not important in livestock shelters.,
        Any location is suitable for building a livestock shelter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using quality building materials, ensuring proper drainage and ventilation, and constructing the shelter in an appropriate location are all important in livestock shelter construction.
    })
  },
  {
    id: G7-AG-FS-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Regular maintenance is important to ensure farm structures serve their purpose effectively. Which of the following is a maintenance practice for farm structures?,
      options: [
        Regularly inspecting and repairing roofs, treating wood against pests and fungi, painting metal parts to prevent rust, and replacing damaged parts.,
        Ignoring repairs to save time.,
        Only repairing farm structures when they collapse.",
        "Not inspecting structures for damage.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regularly inspecting and repairing roofs, treating wood against pests and fungi, painting metal parts to prevent rust, and replacing damaged parts."
    })
  },

  // --- AGRICULTURAL ECONOMICS (3 Materials) ---
  {
    id: "G7-AG-AE-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Farm Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Farm planning involves making decisions about resource allocation and production strategies. Which of the following is an essential element of a farm plan?,
      options: [
        A farm plan includes a production plan, budget, marketing plan, and risk management strategy to guide resource allocation and decision-making.,
        A farm plan only focuses on production.,
        "A farm plan does not include budgeting.,
        A farm plan ignores marketing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A farm plan includes a production plan, budget, marketing plan, and risk management strategy to guide resource allocation and decision-making.
    })
  },
  {
    id: G7-AG-AE-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agricultural Economics,
    subtopic: "Record Keeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Record keeping is an important aspect of farm management. Which of the following records helps a farmer track the financial performance of the farm enterprise?,
      options: [
        Financial records (income and expenditure records) track all revenue from produce sales and expenses on inputs and labor, providing data for profit and loss analysis.,
        Only production records are important.,
        Record keeping is not important for farm management.",
        "Financial records are not useful for farmers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Financial records (income and expenditure records) track all revenue from produce sales and expenses on inputs and labor, providing data for profit and loss analysis."
    })
  },
  {
    id: "G7-AG-AE-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Marketing,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Marketing is crucial for farm profitability, connecting producers with consumers. Which of the following is a key consideration for marketing agricultural produce?,
      options: [
        Understanding market demand, timing sales to optimize prices, and meeting quality standards are key considerations for marketing farm produce.,
        Marketing only involves selling at any price.",
        "Quality standards are not important for marketing.,
        Timing sales does not affect prices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Understanding market demand, timing sales to optimize prices, and meeting quality standards are key considerations for marketing farm produce.
    })
  },

  // --- AGRIBUSINESS (3 Materials) ---
  {
    id: G7-AG-AB-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Entrepreneurship in agriculture involves identifying opportunities and managing agricultural enterprises. Which of the following is an essential characteristic for success as an agripreneur?,
      options: [
        An agripreneur should have creativity and innovation, willingness to take calculated risks, business management skills, and the ability to adapt to changing conditions.,
        Agripreneurs should avoid risks completely.,
        Agripreneurs should not plan for the business.",
        "Agripreneurs should not adapt to changing conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: An agripreneur should have creativity and innovation, willingness to take calculated risks, business management skills, and the ability to adapt to changing conditions."
    })
  },
  {
    id: "G7-AG-AB-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Value Addition,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Value addition in agribusiness increases the value of farm produce. Which of the following is an example of value addition that enhances marketability and profitability?,
      options: [
        Transforming raw produce into processed goods (such as making flour from maize, juice from fruits, or cheese from milk) increases value and extends shelf life.,
        Selling raw produce without processing adds value.,
        "Value addition does not improve profitability.,
        Processing produce always reduces its value."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Transforming raw produce into processed goods (such as making flour from maize, juice from fruits, or cheese from milk) increases value and extends shelf life.
    })
  },
  {
    id: G7-AG-AB-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Business Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Effective business management is essential for running a successful agribusiness. Which of the following is a key aspect of business management in agriculture?,
      options: [
        Financial planning and management, including budgeting, record keeping, and assessing profitability, are key aspects of agribusiness management.,
        Business management is not important in agriculture.,
        Financial planning is not relevant to agribusiness.",
        "Record keeping wastes time and money.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Financial planning and management, including budgeting, record keeping, and assessing profitability, are key aspects of agribusiness management."
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: "G7-AG-AF-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Tree Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Effective tree management is important for successful agroforestry. Which of the following practices helps in the management of trees in agroforestry systems?,
      options: [
        Pruning, thinning, and protecting trees from damage are important management practices for maintaining tree health and productivity in agroforestry.,
        Trees do not require management in agroforestry.,
        "Pruning is harmful to trees.,
        Thinning does not affect tree productivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pruning, thinning, and protecting trees from damage are important management practices for maintaining tree health and productivity in agroforestry.
    })
  },
  {
    id: G7-AG-AF-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Benefits",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agroforestry provides multiple benefits to farmers and the environment. Which of the following is a major environmental benefit of agroforestry?,
      options: [
        Agroforestry helps mitigate climate change by sequestering carbon in trees and soil, reduces greenhouse gas emissions, and provides habitat for biodiversity.,
        Agroforestry only provides food for farmers.,
        Agroforestry does not help mitigate climate change.",
        "Agroforestry harms biodiversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Agroforestry helps mitigate climate change by sequestering carbon in trees and soil, reduces greenhouse gas emissions, and provides habitat for biodiversity."
    })
  },
  {
    id: "G7-AG-AF-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Species Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Selecting appropriate tree species is important for achieving agroforestry objectives. Which of the following tree species is known for its nitrogen-fixing ability and is commonly used as a shade tree in coffee and tea farms?,
      options: [
        Grevillea robusta is a nitrogen-fixing tree commonly used in coffee and tea farms for shade and soil improvement, providing benefits such as timber and fuelwood as well.,
        Eucalyptus is a nitrogen-fixing tree.,
        "Pine trees are nitrogen-fixing trees.,
        Acacia trees are not nitrogen-fixing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Grevillea robusta is a nitrogen-fixing tree commonly used in coffee and tea farms for shade and soil improvement, providing benefits such as timber and fuelwood as well.
    })
  },

  // --- FOOD SECURITY (2 Materials) ---
  {
    id: G7-AG-FS-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Food Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Food security depends on various factors, including production and access. Which of the following strategies contributes most to food security at the household level?,
      options: [
        Diversifying food production through kitchen gardens, keeping small livestock, and storing surplus produce for lean periods are key strategies for household food security.,
        Relying solely on market purchases provides food security.,
        Growing only one crop ensures food security.",
        "Not storing food is a good strategy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Diversifying food production through kitchen gardens, keeping small livestock, and storing surplus produce for lean periods are key strategies for household food security."
    })
  },
  {
    id: "G7-AG-FS-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Proper food storage is essential for maintaining food quality and security. Which of the following is the most important factor for preventing food spoilage during storage?,
      options: [
        Keeping stored food at the right temperature and moisture levels to prevent microbial growth and pest infestation is crucial for preventing spoilage.,
        Temperature does not affect food storage.,
        "Moisture levels are not important for food storage.,
        Pest infestation does not cause food spoilage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Keeping stored food at the right temperature and moisture levels to prevent microbial growth and pest infestation is crucial for preventing spoilage.
    })
  },

  // --- SUSTAINABLE AGRICULTURE (2 Materials) ---
  {
    id: G7-AG-SA-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Conservation Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Conservation farming practices help maintain soil health and productivity. Which of the following is a key principle of conservation agriculture?,
      options: [
        Minimum soil disturbance (reduced tillage), permanent soil cover, and crop diversification are the three key principles of conservation agriculture.,
        Deep ploughing is a principle of conservation agriculture.,
        Bare soil is a principle of conservation agriculture.",
        "Monocropping is a principle of conservation agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Minimum soil disturbance (reduced tillage), permanent soil cover, and crop diversification are the three key principles of conservation agriculture."
    })
  },
  {
    id: "G7-AG-SA-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate Resilience,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Building resilience to climate change is critical for agriculture. Which of the following practices helps farmers build resilience to climate-related shocks?,
      options: [
        Diversifying crops and livestock, improving water storage, using drought-tolerant varieties, and adopting climate-smart agriculture practices build resilience to climate change.,
        Planting only one crop builds resilience.,
        "Drought-tolerant varieties do not help with climate resilience.,
        Climate-smart agriculture does not help build resilience."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Diversifying crops and livestock, improving water storage, using drought-tolerant varieties, and adopting climate-smart agriculture practices build resilience to climate change.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL SCIENCE (5 Materials) ---
  {
    id: G8-AG-SS-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil analysis is essential for making informed decisions about soil management. Which of the following soil analysis methods is used to determine the nutrient status of soil?,
      options: [
        Chemical analysis is used to determine the nutrient content of soil, including macronutrients (nitrogen, phosphorus, potassium) and micronutrients.,
        Physical analysis determines nutrient content.,
        Visual observation determines nutrient status.",
        "Biological analysis determines nutrient content.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical analysis is used to determine the nutrient content of soil, including macronutrients (nitrogen, phosphorus, potassium) and micronutrients."
    })
  },
  {
    id: "G8-AG-SS-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil Fertility Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Effective soil fertility management improves crop productivity and sustainability. Which of the following is a way to improve soil fertility through sustainable practices?,
      options: [
        Using organic fertilizers, such as manure and compost, combined with inorganic fertilizers in a balanced approach to meet crop nutrient needs while maintaining soil health.,
        Using only inorganic fertilizers without organic matter.,
        "Leaving the soil fallow without management.,
        Burning crop residues to add nutrients."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using organic fertilizers, such as manure and compost, combined with inorganic fertilizers in a balanced approach to meet crop nutrient needs while maintaining soil health.
    })
  },
  {
    id: G8-AG-SS-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil conservation is critical for preventing land degradation. Which of the following conservation techniques is particularly effective for controlling soil erosion on steep slopes?,
      options: [
        Terracing is an effective technique for controlling soil erosion on steep slopes by creating platforms that reduce water runoff and soil loss.,
        Mulching is more effective than terracing on steep slopes.,
        Contour farming is effective only on flat land.",
        "Bare soil is best for preventing erosion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Terracing is an effective technique for controlling soil erosion on steep slopes by creating platforms that reduce water runoff and soil loss."
    })
  },
  {
    id: "G8-AG-SS-04",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil pH,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil pH affects nutrient availability and crop growth. Which of the following is the optimal pH range for most crops in agricultural soils?,
      options: [
        The optimal pH range for most crops is between 6.0 and 7.5, where nutrients are most available and soil biological activity is optimal.,
        pH 5.0 is optimal for all crops.,
        "pH 8.5 is optimal for all crops.,
        Soil pH does not affect crop growth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The optimal pH range for most crops is between 6.0 and 7.5, where nutrients are most available and soil biological activity is optimal.
    })
  },
  {
    id: G8-AG-SS-05",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Pollution",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil pollution can be caused by various human activities, affecting agricultural productivity. Which of the following is a major source of soil pollution in agricultural areas?,
      options: [
        Chemical fertilizers and pesticides, if not used responsibly, can accumulate in the soil and cause pollution, affecting soil health and water quality.,
        Organic manure is a major source of soil pollution.,
        Crop residues cause significant soil pollution.",
        "Burning crop residues does not pollute the soil.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical fertilizers and pesticides, if not used responsibly, can accumulate in the soil and cause pollution, affecting soil health and water quality."
    })
  },

  // --- WATER MANAGEMENT (4 Materials) ---
  {
    id: "G8-AG-WM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Advanced Irrigation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Advanced irrigation techniques improve water use efficiency. Which of the following irrigation methods uses sensors to deliver water precisely when and where it is needed?,
      options: [
        Automated drip irrigation systems use sensors to monitor soil moisture and weather conditions, delivering water precisely when crops need it, reducing water waste.,
        Flood irrigation uses sensors to deliver water.,
        "Sprinkler irrigation is the most advanced method.,
        Furrow irrigation is technology advanced."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Automated drip irrigation systems use sensors to monitor soil moisture and weather conditions, delivering water precisely when crops need it, reducing water waste.
    })
  },
  {
    id: G8-AG-WM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Water harvesting techniques capture and store water for agricultural use. Which of the following water harvesting techniques is particularly effective in areas with high rainfall variability?,
      options: [
        Building farm ponds and water pans to capture and store runoff water is particularly effective in areas with high rainfall variability, providing water for irrigation during dry spells.,
        Only rainwater from roofs can be harvested.,
        Farm ponds are not effective for water harvesting.",
        "Water pans cannot be used for irrigation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Building farm ponds and water pans to capture and store runoff water is particularly effective in areas with high rainfall variability, providing water for irrigation during dry spells."
    })
  },
  {
    id: "G8-AG-WM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Quality,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Water quality is important for crop production and livestock health. Which of the following is a potential problem associated with poor-quality irrigation water?,
      options: [
        High salinity in irrigation water can cause osmotic stress, nutrient imbalances, and damage to crops, reducing yields and affecting soil health.,
        Poor water quality does not affect plants.,
        "Salinity improves crop yields.,
        Water quality has no effect on soil structure."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "High salinity in irrigation water can cause osmotic stress, nutrient imbalances, and damage to crops, reducing yields and affecting soil health.
    })
  },
  {
    id: G8-AG-WM-04",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Use Efficiency",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Improving water use efficiency is critical for sustainable agriculture. Which of the following practices helps improve water use efficiency in crop production?,
      options: [
        Using deficit irrigation, where water is applied at critical growth stages, and selecting drought-resistant varieties, helps maximize yields per unit of water used.,
        Overwatering crops improves efficiency.,
        Applying water during the hottest part of the day is efficient.",
        "Using flood irrigation is the most efficient method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using deficit irrigation, where water is applied at critical growth stages, and selecting drought-resistant varieties, helps maximize yields per unit of water used."
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: "G8-AG-CP-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Advanced Crop Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Advanced crop management practices aim to maximize productivity while minimizing environmental impact. Which of the following is an example of a precision agriculture technique?,
      options: [
        Variable rate technology (VRT), which applies inputs (fertilizer, pesticides) at variable rates across a field based on soil variability, is a precision agriculture technique that optimizes input use.,
        Uniform application of fertilizers is precision agriculture.,
        "Using only manual labor is precision agriculture.,
        Precision agriculture does not use technology."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Variable rate technology (VRT), which applies inputs (fertilizer, pesticides) at variable rates across a field based on soil variability, is a precision agriculture technique that optimizes input use.
    })
  },
  {
    id: G8-AG-CP-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Integrated pest management (IPM) provides sustainable approaches to pest control. Which of the following is a cultural control method used in integrated pest management?,
      options: [
        Crop rotation and intercropping are cultural control methods that disrupt pest life cycles, reduce pest populations, and increase biodiversity.,
        Using only chemical pesticides is cultural control.,
        Biological control uses cultural methods.",
        "Mechanical control is a cultural method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Crop rotation and intercropping are cultural control methods that disrupt pest life cycles, reduce pest populations, and increase biodiversity."
    })
  },
  {
    id: "G8-AG-CP-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Harvesting and Post-Harvest,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Post-harvest handling affects the quality and marketability of produce. Which of the following is an important post-harvest practice for preventing spoilage of fruits and vegetables?,
      options: [
        Cooling and proper packaging to reduce spoilage and maintain freshness, quality, and shelf life of fruits and vegetables after harvest.,
        Leaving produce in the sun extends shelf life.,
        "Using cardboard boxes is a post-harvest practice.,
        Cooling is not important after harvest."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooling and proper packaging to reduce spoilage and maintain freshness, quality, and shelf life of fruits and vegetables after harvest.
    })
  },
  {
    id: G8-AG-CP-04",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Agro-Processing",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agro-processing adds value to raw agricultural produce. Which of the following is a processed product from sugarcane?,
      options: [
        Sugar, molasses, and ethanol are processed products from sugarcane that have significant economic value.,
        Sugarcane can only be used to make sugar.,
        Ethanol cannot be produced from sugarcane.",
        "Molasses is not made from sugarcane.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sugar, molasses, and ethanol are processed products from sugarcane that have significant economic value."
    })
  },
  {
    id: "G8-AG-CP-05",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Sustainable Crop Production,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Sustainable crop production is essential for maintaining agricultural productivity. Which of the following is a sustainable crop production practice that reduces reliance on chemical fertilizers?,
      options: [
        Agroforestry, which integrates trees and crops, improves soil fertility naturally, reducing dependence on chemical fertilizers and improving long-term productivity.,
        Using only synthetic fertilizers is sustainable.,
        "Agroforestry does not reduce fertilizer use.,
        Monocropping improves soil fertility."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry, which integrates trees and crops, improves soil fertility naturally, reducing dependence on chemical fertilizers and improving long-term productivity.
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: G8-AG-LP-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Breeding",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Animal breeding improves livestock genetics and productivity. Which of the following is an advantage of artificial insemination (AI) in livestock breeding?,
      options: [
        Artificial insemination provides access to superior genetics, reduces disease transmission, and improves reproductive efficiency, allowing for rapid genetic improvement.,
        Artificial insemination is always more expensive.,
        Artificial insemination spreads diseases.",
        "Artificial insemination reduces genetic diversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Artificial insemination provides access to superior genetics, reduces disease transmission, and improves reproductive efficiency, allowing for rapid genetic improvement."
    })
  },
  {
    id: "G8-AG-LP-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Health Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Animal health management is essential for livestock productivity. Which of the following is the most effective strategy for preventing disease outbreaks in a livestock operation?,
      options: [
        Implementing a comprehensive biosecurity protocol including quarantine, vaccination programs, and regular health monitoring prevents disease introduction and spread.,
        Only treating sick animals prevents disease outbreaks.,
        "Vaccination is not effective for disease prevention.,
        Biosecurity is not important for livestock health."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Implementing a comprehensive biosecurity protocol including quarantine, vaccination programs, and regular health monitoring prevents disease introduction and spread.
    })
  },
  {
    id: G8-AG-LP-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Livestock Production Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Different livestock production systems exist depending on resource availability and management practices. Which of the following livestock production systems is characterized by low inputs and extensive grazing?,
      options: [
        Extensive pastoralism is a production system characterized by low inputs, large grazing areas, and low stocking rates, typical in Kenya's dry regions.,
        Intensive production systems use low inputs.,
        Zero-grazing is a low-input system.",
        "Feedlot systems have low inputs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Extensive pastoralism is a production system characterized by low inputs, large grazing areas, and low stocking rates, typical in Kenya's dry regions."
    })
  },
  {
    id: "G8-AG-LP-04",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Livestock Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Livestock nutrition affects health and productivity. Which of the following is a protein source for livestock feed?,
      options: [
        Soybean meal, cottonseed cake, and fishmeal are high-quality protein sources used in livestock feed for growth, milk production, and maintenance.,
        Only grass provides protein.,
        "Maize is a protein source.,
        Protein sources are not needed in livestock feed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Soybean meal, cottonseed cake, and fishmeal are high-quality protein sources used in livestock feed for growth, milk production, and maintenance.
    })
  },
  {
    id: G8-AG-LP-05",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Livestock Marketing",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Livestock marketing is important for farmers to earn income. Which of the following is a challenge faced by livestock farmers in Kenya?,
      options: [
        Limited market access, poor infrastructure, seasonal price fluctuations, and competition from imports are major challenges for livestock farmers in Kenya.,
        Market access is easy for all farmers.,
        Prices are always stable in livestock markets.",
        "Imports do not affect local livestock prices.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Limited market access, poor infrastructure, seasonal price fluctuations, and competition from imports are major challenges for livestock farmers in Kenya."
    })
  },

  // --- FARM MECHANIZATION (3 Materials) ---
  {
    id: "G8-AG-FM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Farm Machinery,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Farm machinery improves agricultural efficiency and productivity. Which of the following farm machines is used for harvesting crops like maize and wheat?,
      options: [
        A combine harvester is used for harvesting and threshing crops such as maize and wheat, combining harvesting, threshing, and cleaning in one operation.,
        A tractor is used for harvesting.,
        "A power tiller is used for harvesting.,
        A planter is used for harvesting."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A combine harvester is used for harvesting and threshing crops such as maize and wheat, combining harvesting, threshing, and cleaning in one operation.
    })
  },
  {
    id: G8-AG-FM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Farm Mechanization,
    subtopic: "Equipment Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Regular maintenance extends the life of farm machinery and reduces breakdowns. Which of the following is an important maintenance practice for tractors?,
      options: [
        Changing engine oil regularly, checking tire pressure, lubricating moving parts, and servicing the fuel system are essential maintenance practices for tractors.,
        Tractors do not require maintenance.,
        Oil changes are not important for tractors.",
        "Checking tire pressure is not important.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Changing engine oil regularly, checking tire pressure, lubricating moving parts, and servicing the fuel system are essential maintenance practices for tractors."
    })
  },
  {
    id: "G8-AG-FM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Farm Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Simple farm tools remain important for small-scale farmers. Which of the following hand tools is used for removing weeds from fields?,
      options: [
        A jembe (hoe) is used for weeding, digging, and tilling, making it an essential tool for small-scale farmers in Kenya.,
        A panga (machete) is used for weeding.,
        "A rake is used for removing weeds.,
        A dibber is used for weeding."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A jembe (hoe) is used for weeding, digging, and tilling, making it an essential tool for small-scale farmers in Kenya.
    })
  },

  // --- AGRICULTURAL EXTENSION (3 Materials) ---
  {
    id: G8-AG-AE-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Advisory Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agricultural extension services connect farmers with vital information and resources. Which of the following is a key role of extension officers in Kenya's agricultural development?,
      options: [
        Extension officers provide training and technical advice to farmers on modern farming methods, pest control, and market access, helping them improve their farming practices.,
        Extension officers only work in offices.,
        Extension officers are only responsible for distributing inputs.",
        "Extension officers only work with large farms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Extension officers provide training and technical advice to farmers on modern farming methods, pest control, and market access, helping them improve their farming practices."
    })
  },
  {
    id: "G8-AG-AE-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agricultural Extension",
    subtopic: "Technology Transfer,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Technology transfer ensures farmers can adopt improved agricultural practices. Which of the following is an effective approach for transferring technology to small-scale farmers?,
      options: [
        Farmer field schools (FFS) provide hands-on learning and participatory approaches to technology transfer, enabling farmers to test and adopt technologies adapted to their local conditions.,
        Using only printed materials for technology transfer.,
        "Technology transfer does not need to be adapted to local conditions.,
        Participatory approaches are not effective."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Farmer field schools (FFS) provide hands-on learning and participatory approaches to technology transfer, enabling farmers to test and adopt technologies adapted to their local conditions.
    })
  },
  {
    id: G8-AG-AE-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Farmer Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Farmer education programs help farmers make informed decisions. Which of the following is an important benefit of continuous farmer education?,
      options: [
        Continuous farmer education helps farmers adapt to changing agricultural practices and market conditions, improving their productivity and profitability.,
        Farmer education is not important for productivity.,
        Education does not affect profitability.",
        "Continuous education has no benefits.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Continuous farmer education helps farmers adapt to changing agricultural practices and market conditions, improving their productivity and profitability."
    })
  },

  // --- AGRIBUSINESS AND MARKETING (3 Materials) ---
  {
    id: "G8-AG-AM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Market Access,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Accessing markets is essential for farm profitability. Which of the following helps small-scale farmers access better markets for their produce?,
      options: [
        Organizing into marketing cooperatives and groups helps farmers combine their produce, gain better bargaining power, and access larger markets at better prices.,
        Farmers can access better markets individually.,
        "Cooperatives do not help with market access.,
        Organizing into groups reduces market access."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organizing into marketing cooperatives and groups helps farmers combine their produce, gain better bargaining power, and access larger markets at better prices.
    })
  },
  {
    id: G8-AG-AM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agribusiness and Marketing,
    subtopic: "Value Addition",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Value addition increases the profitability of agricultural enterprises. Which of the following is a value-added product from milk?,
      options: [
        Yoghurt, cheese, and butter are value-added dairy products that command higher prices than raw milk, reducing spoilage and increasing income.,
        Raw milk is a value-added product.,
        Milk cannot be processed into value-added products.",
        "Value-added dairy products are not profitable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Yoghurt, cheese, and butter are value-added dairy products that command higher prices than raw milk, reducing spoilage and increasing income."
    })
  },
  {
    id: "G8-AG-AM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Cooperative Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Agricultural cooperatives provide support and resources for farmers. Which of the following is a benefit of joining an agricultural cooperative?,
      options: [
        Cooperatives provide access to input credit, training, marketing, and information sharing, helping farmers improve their productivity and income.,
        Cooperatives only benefit large-scale farmers.,
        "Cooperatives are not helpful for individual farmers.,
        Cooperatives limit access to resources."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooperatives provide access to input credit, training, marketing, and information sharing, helping farmers improve their productivity and income.
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: G8-AG-AF-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Silvopastoral Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Silvopastoral systems integrate trees with livestock production. Which of the following is a benefit of incorporating trees into livestock grazing systems?,
      options: [
        Silvopastoral systems provide shade for livestock, improve animal welfare and productivity, and provide fodder and additional income from tree products.,
        Trees compete with livestock for forage.,
        Silvopastoral systems reduce productivity.",
        "Livestock damage trees in silvopastoral systems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Silvopastoral systems provide shade for livestock, improve animal welfare and productivity, and provide fodder and additional income from tree products."
    })
  },
  {
    id: "G8-AG-AF-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Fruit Trees,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Fruit trees in agroforestry systems contribute to food and nutritional security. Which of the following fruit trees is important for nutrition and is widely grown in Kenya?,
      options: [
        Mango is widely grown in Kenya for its nutritional value and income potential, providing vitamins (especially vitamin C) and dietary fiber.,
        Mango trees are grown only in coastal areas.,
        "Mango is not important for nutrition.,
        Mango is not grown in Kenya."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mango is widely grown in Kenya for its nutritional value and income potential, providing vitamins (especially vitamin C) and dietary fiber.
    })
  },
  {
    id: G8-AG-AF-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Multipurpose Trees",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Multipurpose trees provide various products for farmers. Which of the following is an example of a multipurpose tree in East Africa?,
      options: [
        Moringa tree is a multipurpose tree providing nutritious leaves, medicinal products, seeds for oil production, and fodder for livestock, with many uses in agriculture and nutrition.,
        Moringa only provides leaves for food.,
        Moringa is not grown in East Africa.",
        "Moringa has no medicinal value.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Moringa tree is a multipurpose tree providing nutritious leaves, medicinal products, seeds for oil production, and fodder for livestock, with many uses in agriculture and nutrition."
    })
  },

  // --- FOOD PROCESSING AND VALUE ADDITION (2 Materials) ---
  {
    id: "G8-AG-FP-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Food Processing and Value Addition",
    subtopic: "Processing Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Food processing techniques transform agricultural products into safe, shelf-stable, and marketable items. Which of the following processing techniques extends the shelf life of fruits and vegetables?,
      options: [
        "Canning and bottling are techniques that extend the shelf life of fruits and vegetables, preserving them for consumption when fresh produce is unavailable.,
        Freezing is a technique that extends shelf life, but is more energy-intensive.",
        "Drying is only suitable for grains.,
        Processing is not important for fruits."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Canning and bottling are techniques that extend the shelf life of fruits and vegetables, preserving them for consumption when fresh produce is unavailable.
    })
  },
  {
    id: G8-AG-FP-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Food Processing and Value Addition,
    subtopic: "Product Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Product development involves creating new value-added products from agricultural produce. Which of the following is a value-added product that can be made from cassava?,
      options: [
        Cassava flour, cassava chips, and cassava starch are value-added products from cassava that provide alternative income sources for farmers.,
        Only fresh cassava can be sold.,
        Cassava cannot be processed.",
        "Cassava processing is not profitable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cassava flour, cassava chips, and cassava starch are value-added products from cassava that provide alternative income sources for farmers."
    })
  },

  // --- SUSTAINABLE AGRICULTURE (2 Materials) ---
  {
    id: "G8-AG-SA-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate-Smart Agriculture,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Climate-smart agriculture aims to increase productivity and resilience while reducing greenhouse gas emissions. Which of the following is a climate-smart agriculture practice?,
      options: [
        Conservation agriculture (minimum tillage) and integrating trees with crops are climate-smart practices that reduce emissions, improve soil health, and increase resilience to climate shocks.,
        Deep ploughing is climate-smart agriculture.,
        "Burning crop residues is climate-smart.,
        Monocropping is climate-smart."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conservation agriculture (minimum tillage) and integrating trees with crops are climate-smart practices that reduce emissions, improve soil health, and increase resilience to climate shocks.
    })
  },
  {
    id: G8-AG-SA-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Environmental Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Environmental conservation is integral to sustainable agriculture. Which of the following practices contributes to the conservation of natural resources on farms?,
      options: [
        Maintaining riparian buffers along waterways, protecting wetlands, and preserving natural habitats contribute to environmental conservation in agricultural landscapes.,
        Clearing all natural vegetation is environmentally friendly.,
        Environmental conservation is not important for farms.",
        "Wetlands should be converted to agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maintaining riparian buffers along waterways, protecting wetlands, and preserving natural habitats contribute to environmental conservation in agricultural landscapes."
    })
  }`nexport const agricultureTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================
  {
    id: "G7-AG-SC-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Formation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil formation is a complex process involving the weathering of parent material and the action of various factors over time. Which of the following factors is the primary determinant of soil color and texture in a particular region?,
      options: [
        Parent material is the primary determinant of soil color and texture, as different rocks weather to produce distinct soil types with varying mineral composition and particle size.,
        Climate only determines the color of soil.,
        "Soil organisms have no effect on soil formation.,
        Time is not a factor in soil formation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Parent material is the primary determinant of soil color and texture, as different rocks weather to produce distinct soil types with varying mineral composition and particle size.
    })
  },
  {
    id: G7-AG-SC-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Types",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Different soil types have distinct characteristics that affect their agricultural potential. Which of the following soil types is characterized by its dark color, high organic matter content, and excellent fertility?,
      options: [
        Chernozem soils are characterized by their dark color, high organic matter content, and exceptional fertility, making them highly productive for agriculture.,
        Sandy soils are dark colored and very fertile.,
        Clay soils are light in color and have low fertility.",
        "Laterite soils have high organic matter content.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chernozem soils are characterized by their dark color, high organic matter content, and exceptional fertility, making them highly productive for agriculture."
    })
  },
  {
    id: "G7-AG-SC-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Fertility,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil fertility is determined by the availability of essential plant nutrients. Which of the following is a micronutrient that is required in small amounts but is essential for plant growth and development?,
      options: [
        Zinc is a micronutrient essential for plant growth, playing a key role in enzyme function and protein synthesis, despite being required in small quantities.,
        Nitrogen is a primary macronutrient.,
        "Phosphorus is a secondary macronutrient.,
        Calcium is a secondary macronutrient."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Zinc is a micronutrient essential for plant growth, playing a key role in enzyme function and protein synthesis, despite being required in small quantities.
    })
  },
  {
    id: G7-AG-SC-04",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil conservation practices are essential for maintaining soil productivity and preventing degradation. Which of the following practices involves creating depressions or basins to capture rainfall and reduce runoff?,
      options: [
        Zai pits are small planting basins that capture rainfall, concentrate nutrients, and reduce runoff, improving crop yields in dryland areas.,
        Terracing is building stepped platforms on slopes.,
        Mulching is covering the soil with organic materials.",
        "Contour farming is planting along the contours of the land.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Zai pits are small planting basins that capture rainfall, concentrate nutrients, and reduce runoff, improving crop yields in dryland areas."
    })
  },
  {
    id: "G7-AG-SC-05",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Proper soil conservation practices can prevent or reduce the effects of soil degradation on agricultural productivity. Which of the following is a major cause of soil erosion in Kenya's agricultural areas?,
      options: [
        Deforestation is a major cause of soil erosion in Kenya, as removal of trees and vegetation leaves the soil exposed to wind and water erosion, reducing soil fertility and agricultural productivity.,
        Terracing is a major cause of soil erosion.,
        "Mulching increases soil erosion.,
        Contour farming causes soil erosion."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Deforestation is a major cause of soil erosion in Kenya, as removal of trees and vegetation leaves the soil exposed to wind and water erosion, reducing soil fertility and agricultural productivity.
    })
  },
  {
    id: G7-AG-WM-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Sources",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Understanding various water sources is crucial for agricultural water management. Which of the following is a renewable water source that is replenished naturally through the hydrological cycle?,
      options: [
        Surface water from rivers and lakes is a renewable water source that is continuously replenished by rainfall and runoff, making it an important resource for irrigation.,
        Groundwater is non-renewable water.,
        Desalinated water is a renewable source.",
        "Meltwater is not renewable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Surface water from rivers and lakes is a renewable water source that is continuously replenished by rainfall and runoff, making it an important resource for irrigation."
    })
  },
  {
    id: "G7-AG-WM-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Irrigation Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Irrigation systems are essential for crop production in areas with limited rainfall. Which of the following irrigation systems is most suitable for irrigating steep slopes and uneven terrain?,
      options: [
        Sprinkler irrigation is suitable for sloping and uneven terrain as it applies water uniformly over the land without requiring perfectly level ground.,
        Flood irrigation is suitable for sloping areas.,
        "Drip irrigation is not suitable for uneven terrain.,
        Furrow irrigation is best for steep slopes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sprinkler irrigation is suitable for sloping and uneven terrain as it applies water uniformly over the land without requiring perfectly level ground.
    })
  },
  {
    id: G7-AG-WM-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Water conservation is essential for ensuring reliable water supply for agriculture. Which of the following practices helps farmers conserve water by reducing evaporation and improving infiltration?,
      options: [
        Mulching reduces evaporation by covering the soil surface with organic materials, improves water infiltration, and helps conserve soil moisture for crop growth.,
        Flood irrigation conserves water.,
        Bare soil is best for water conservation.",
        "Deep ploughing reduces evaporation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mulching reduces evaporation by covering the soil surface with organic materials, improves water infiltration, and helps conserve soil moisture for crop growth."
    })
  },
  {
    id: "G7-AG-WM-04",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Irrigation Efficiency,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Irrigation efficiency measures how effectively water is delivered and used by crops. Which of the following factors reduces irrigation efficiency in agricultural systems?,
      options: [
        Water loss through evaporation, runoff, and deep percolation reduces irrigation efficiency, requiring more water to achieve the same crop yields.,
        Applying water during the cooler times of day improves efficiency.,
        "Using drip irrigation reduces efficiency.,
        Drip irrigation is inefficient."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Water loss through evaporation, runoff, and deep percolation reduces irrigation efficiency, requiring more water to achieve the same crop yields.
    })
  },
  {
    id: G7-AG-CP-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Field Crops",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Field crops are an important source of food and income for Kenyan farmers. Which of the following field crops is a dual-purpose crop that provides food for humans and feed for livestock?,
      options: [
        Sorghum is a dual-purpose crop that provides both food and feed, and is also used for brewing and as a fodder crop, making it valuable in mixed farming systems.,
        Wheat is only used for human food.,
        Maize is only used for human food.",
        "Rice is only used for human food.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sorghum is a dual-purpose crop that provides both food and feed, and is also used for brewing and as a fodder crop, making it valuable in mixed farming systems."
    })
  },
  {
    id: "G7-AG-CP-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Horticultural Crops,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Horticultural crops are high-value products that contribute significantly to agricultural income. Which of the following horticultural crops is grown in Kenya and is an important source of vitamins and minerals in the diet?,
      options: [
        Kale (sukuma wiki) is an important horticultural crop in Kenya that provides essential vitamins and minerals, particularly vitamin C, vitamin K, and iron.,
        Maize is a horticultural crop.,
        "Wheat is a horticultural crop.,
        Sorghum is a horticultural crop."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kale (sukuma wiki) is an important horticultural crop in Kenya that provides essential vitamins and minerals, particularly vitamin C, vitamin K, and iron.
    })
  },
  {
    id: G7-AG-CP-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Crop Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Effective crop management involves various practices that promote healthy growth and maximize yields. Which of the following practices is important for ensuring the establishment of young crop plants?,
      options: [
        Thinning is the removal of excess seedlings to ensure adequate spacing, reduce competition for resources, and allow each plant to develop properly.,
        Overcrowding improves crop yields.,
        Thinning reduces crop yields.",
        "Thinning is not important for crop production.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Thinning is the removal of excess seedlings to ensure adequate spacing, reduce competition for resources, and allow each plant to develop properly."
    })
  },
  {
    id: "G7-AG-CP-04",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Pest and Disease Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Pest and disease control is essential for protecting crops and ensuring optimal yields. Which of the following is an integrated pest management strategy that combines biological and chemical controls?,
      options: [
        Integrated pest management combines biological control (natural enemies), cultural practices (crop rotation), and chemical control (selective pesticides) for sustainable pest management.,
        Only using chemical pesticides is integrated pest management.,
        "Integrated pest management avoids all chemical use.,
        Integrated pest management relies only on biological control."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Integrated pest management combines biological control (natural enemies), cultural practices (crop rotation), and chemical control (selective pesticides) for sustainable pest management.
    })
  },
  {
    id: G7-AG-CP-05",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Harvesting is the process of gathering mature crops from the field. Which of the following is the recommended time for harvesting vegetables to ensure high quality and nutritional value?,
      options: [
        Vegetables should be harvested at their peak maturity, when they are tender, crisp, and have the best color and flavor for optimal quality and nutrition.,
        Vegetables can be harvested at any time.,
        Vegetables should be harvested only after they wilt.",
        "Vegetables should be harvested before they are ripe.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Vegetables should be harvested at their peak maturity, when they are tender, crisp, and have the best color and flavor for optimal quality and nutrition."
    })
  },
  {
    id: "G7-AG-LP-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Cattle Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Cattle farming is a major agricultural enterprise in Kenya, providing milk, meat, and other products. Which of the following is an important management practice for beef cattle production?,
      options: [
        "Beef cattle management includes regular weighing and monitoring, providing adequate nutrition, controlling parasites, and ensuring the animals are healthy and gaining weight.,
        Beef cattle should not be monitored for weight gain.",
        "Parasite control is not important in beef production.,
        Beef cattle can survive on poor quality feed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Beef cattle management includes regular weighing and monitoring, providing adequate nutrition, controlling parasites, and ensuring the animals are healthy and gaining weight.
    })
  },
  {
    id: G7-AG-LP-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Goat Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Goat farming is a valuable enterprise for smallholder farmers, providing meat, milk, and other products. Which of the following is an adaptation that makes goats well-suited for dry areas?,
      options: [
        Goats are adapted to dry areas due to their ability to conserve water efficiently, tolerate high temperatures, and feed on a variety of tough, low-quality vegetation.,
        Goats require large amounts of water daily.,
        Goats are very sensitive to heat.",
        "Goats only eat fresh green grass.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Goats are adapted to dry areas due to their ability to conserve water efficiently, tolerate high temperatures, and feed on a variety of tough, low-quality vegetation."
    })
  },
  {
    id: "G7-AG-LP-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Poultry Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Poultry farming is a popular enterprise due to its relatively low startup costs and high returns. Which of the following is an important factor in the success of a poultry enterprise?,
      options: [
        Good management practices, including proper feeding, clean water, vaccination, and a clean environment, are essential for successful poultry production.,
        Poultry can survive without any management.,
        "Poultry feed does not affect productivity.,
        Vaccinations are not necessary for poultry."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Good management practices, including proper feeding, clean water, vaccination, and a clean environment, are essential for successful poultry production.
    })
  },
  {
    id: G7-AG-LP-04",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Sheep",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Sheep are kept for wool, meat, and other products in various parts of Kenya. Which of the following is a common sheep management practice?,
      options: [
        Regular shearing, parasite control, and providing adequate nutrition are important management practices for sheep, particularly for wool production and maintenance.,
        Sheep management only involves feeding.,
        Parasite control is not important for sheep.",
        "Shearing is harmful to sheep.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regular shearing, parasite control, and providing adequate nutrition are important management practices for sheep, particularly for wool production and maintenance."
    })
  },
  {
    id: "G7-AG-LP-05",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Pig Farming,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Pig farming can be a profitable enterprise with proper management. Which of the following is the most important health management practice in pig farming?,
      options: [
        Preventing and controlling diseases through proper hygiene, vaccination, and quarantine of new animals is the most important health management practice in pig farming.,
        Pig health management is not important.,
        "Vaccination is not necessary for pigs.,
        Pigs do not get diseases."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Preventing and controlling diseases through proper hygiene, vaccination, and quarantine of new animals is the most important health management practice in pig farming.
    })
  },
  {
    id: G7-AG-FS-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Types of Farm Structures",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Farm structures serve various purposes, including production and processing. Which of the following farm structures is used for crop production under controlled conditions?,
      options: [
        A greenhouse is a structure used for crop production under controlled conditions, allowing for better management of temperature, humidity, and pests, and extending the growing season.,
        A granary is used for storage.,
        A dairy shed is used for housing cattle.",
        "A poultry house is used for housing chickens.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A greenhouse is a structure used for crop production under controlled conditions, allowing for better management of temperature, humidity, and pests, and extending the growing season."
    })
  },
  {
    id: "G7-AG-FS-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Farm Structures",
    subtopic: "Construction,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Proper construction techniques are important for the durability and functionality of farm structures. Which of the following is important in constructing a protective shelter for livestock?,
      options: [
        Using quality building materials, ensuring proper drainage and ventilation, and constructing the shelter in an appropriate location are all important in livestock shelter construction.,
        Livestock shelters do not require drainage.,
        "Ventilation is not important in livestock shelters.,
        Any location is suitable for building a livestock shelter."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using quality building materials, ensuring proper drainage and ventilation, and constructing the shelter in an appropriate location are all important in livestock shelter construction.
    })
  },
  {
    id: G7-AG-FS-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Farm Structures,
    subtopic: "Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Regular maintenance is important to ensure farm structures serve their purpose effectively. Which of the following is a maintenance practice for farm structures?,
      options: [
        Regularly inspecting and repairing roofs, treating wood against pests and fungi, painting metal parts to prevent rust, and replacing damaged parts.,
        Ignoring repairs to save time.,
        Only repairing farm structures when they collapse.",
        "Not inspecting structures for damage.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Regularly inspecting and repairing roofs, treating wood against pests and fungi, painting metal parts to prevent rust, and replacing damaged parts."
    })
  },
  {
    id: "G7-AG-AE-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Farm Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Farm planning involves making decisions about resource allocation and production strategies. Which of the following is an essential element of a farm plan?,
      options: [
        A farm plan includes a production plan, budget, marketing plan, and risk management strategy to guide resource allocation and decision-making.,
        A farm plan only focuses on production.,
        "A farm plan does not include budgeting.,
        A farm plan ignores marketing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A farm plan includes a production plan, budget, marketing plan, and risk management strategy to guide resource allocation and decision-making.
    })
  },
  {
    id: G7-AG-AE-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agricultural Economics,
    subtopic: "Record Keeping",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Record keeping is an important aspect of farm management. Which of the following records helps a farmer track the financial performance of the farm enterprise?,
      options: [
        Financial records (income and expenditure records) track all revenue from produce sales and expenses on inputs and labor, providing data for profit and loss analysis.,
        Only production records are important.,
        Record keeping is not important for farm management.",
        "Financial records are not useful for farmers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Financial records (income and expenditure records) track all revenue from produce sales and expenses on inputs and labor, providing data for profit and loss analysis."
    })
  },
  {
    id: "G7-AG-AE-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agricultural Economics",
    subtopic: "Marketing,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Marketing is crucial for farm profitability, connecting producers with consumers. Which of the following is a key consideration for marketing agricultural produce?,
      options: [
        Understanding market demand, timing sales to optimize prices, and meeting quality standards are key considerations for marketing farm produce.,
        Marketing only involves selling at any price.",
        "Quality standards are not important for marketing.,
        Timing sales does not affect prices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Understanding market demand, timing sales to optimize prices, and meeting quality standards are key considerations for marketing farm produce.
    })
  },
  {
    id: G7-AG-AB-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Entrepreneurship",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Entrepreneurship in agriculture involves identifying opportunities and managing agricultural enterprises. Which of the following is an essential characteristic for success as an agripreneur?,
      options: [
        An agripreneur should have creativity and innovation, willingness to take calculated risks, business management skills, and the ability to adapt to changing conditions.,
        Agripreneurs should avoid risks completely.,
        Agripreneurs should not plan for the business.",
        "Agripreneurs should not adapt to changing conditions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: An agripreneur should have creativity and innovation, willingness to take calculated risks, business management skills, and the ability to adapt to changing conditions."
    })
  },
  {
    id: "G7-AG-AB-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agribusiness",
    subtopic: "Value Addition,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Value addition in agribusiness increases the value of farm produce. Which of the following is an example of value addition that enhances marketability and profitability?,
      options: [
        Transforming raw produce into processed goods (such as making flour from maize, juice from fruits, or cheese from milk) increases value and extends shelf life.,
        Selling raw produce without processing adds value.,
        "Value addition does not improve profitability.,
        Processing produce always reduces its value."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Transforming raw produce into processed goods (such as making flour from maize, juice from fruits, or cheese from milk) increases value and extends shelf life.
    })
  },
  {
    id: G7-AG-AB-03",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agribusiness,
    subtopic: "Business Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Effective business management is essential for running a successful agribusiness. Which of the following is a key aspect of business management in agriculture?,
      options: [
        Financial planning and management, including budgeting, record keeping, and assessing profitability, are key aspects of agribusiness management.,
        Business management is not important in agriculture.,
        Financial planning is not relevant to agribusiness.",
        "Record keeping wastes time and money.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Financial planning and management, including budgeting, record keeping, and assessing profitability, are key aspects of agribusiness management."
    })
  },
  {
    id: "G7-AG-AF-01",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Tree Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Effective tree management is important for successful agroforestry. Which of the following practices helps in the management of trees in agroforestry systems?,
      options: [
        Pruning, thinning, and protecting trees from damage are important management practices for maintaining tree health and productivity in agroforestry.,
        Trees do not require management in agroforestry.,
        "Pruning is harmful to trees.,
        Thinning does not affect tree productivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pruning, thinning, and protecting trees from damage are important management practices for maintaining tree health and productivity in agroforestry.
    })
  },
  {
    id: G7-AG-AF-02",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Benefits",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agroforestry provides multiple benefits to farmers and the environment. Which of the following is a major environmental benefit of agroforestry?,
      options: [
        Agroforestry helps mitigate climate change by sequestering carbon in trees and soil, reduces greenhouse gas emissions, and provides habitat for biodiversity.,
        Agroforestry only provides food for farmers.,
        Agroforestry does not help mitigate climate change.",
        "Agroforestry harms biodiversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Agroforestry helps mitigate climate change by sequestering carbon in trees and soil, reduces greenhouse gas emissions, and provides habitat for biodiversity."
    })
  },
  {
    id: "G7-AG-AF-03",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Species Selection,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Selecting appropriate tree species is important for achieving agroforestry objectives. Which of the following tree species is known for its nitrogen-fixing ability and is commonly used as a shade tree in coffee and tea farms?,
      options: [
        Grevillea robusta is a nitrogen-fixing tree commonly used in coffee and tea farms for shade and soil improvement, providing benefits such as timber and fuelwood as well.,
        Eucalyptus is a nitrogen-fixing tree.,
        "Pine trees are nitrogen-fixing trees.,
        Acacia trees are not nitrogen-fixing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Grevillea robusta is a nitrogen-fixing tree commonly used in coffee and tea farms for shade and soil improvement, providing benefits such as timber and fuelwood as well.
    })
  },
  {
    id: G7-AG-FS-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Food Security,
    subtopic: "Food Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Food security depends on various factors, including production and access. Which of the following strategies contributes most to food security at the household level?,
      options: [
        Diversifying food production through kitchen gardens, keeping small livestock, and storing surplus produce for lean periods are key strategies for household food security.,
        Relying solely on market purchases provides food security.,
        Growing only one crop ensures food security.",
        "Not storing food is a good strategy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Diversifying food production through kitchen gardens, keeping small livestock, and storing surplus produce for lean periods are key strategies for household food security."
    })
  },
  {
    id: "G7-AG-FS-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Food Security",
    subtopic: "Food Storage,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Proper food storage is essential for maintaining food quality and security. Which of the following is the most important factor for preventing food spoilage during storage?,
      options: [
        Keeping stored food at the right temperature and moisture levels to prevent microbial growth and pest infestation is crucial for preventing spoilage.,
        Temperature does not affect food storage.,
        "Moisture levels are not important for food storage.,
        Pest infestation does not cause food spoilage."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Keeping stored food at the right temperature and moisture levels to prevent microbial growth and pest infestation is crucial for preventing spoilage.
    })
  },
  {
    id: G7-AG-SA-01",
    grade: "Grade 7,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Conservation Farming",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Conservation farming practices help maintain soil health and productivity. Which of the following is a key principle of conservation agriculture?,
      options: [
        Minimum soil disturbance (reduced tillage), permanent soil cover, and crop diversification are the three key principles of conservation agriculture.,
        Deep ploughing is a principle of conservation agriculture.,
        Bare soil is a principle of conservation agriculture.",
        "Monocropping is a principle of conservation agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Minimum soil disturbance (reduced tillage), permanent soil cover, and crop diversification are the three key principles of conservation agriculture."
    })
  },
  {
    id: "G7-AG-SA-02",
    grade: "Grade 7",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate Resilience,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Building resilience to climate change is critical for agriculture. Which of the following practices helps farmers build resilience to climate-related shocks?,
      options: [
        Diversifying crops and livestock, improving water storage, using drought-tolerant varieties, and adopting climate-smart agriculture practices build resilience to climate change.,
        Planting only one crop builds resilience.,
        "Drought-tolerant varieties do not help with climate resilience.,
        Climate-smart agriculture does not help build resilience."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Diversifying crops and livestock, improving water storage, using drought-tolerant varieties, and adopting climate-smart agriculture practices build resilience to climate change.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================
  {
    id: G8-AG-SS-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil analysis is essential for making informed decisions about soil management. Which of the following soil analysis methods is used to determine the nutrient status of soil?,
      options: [
        Chemical analysis is used to determine the nutrient content of soil, including macronutrients (nitrogen, phosphorus, potassium) and micronutrients.,
        Physical analysis determines nutrient content.,
        Visual observation determines nutrient status.",
        "Biological analysis determines nutrient content.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical analysis is used to determine the nutrient content of soil, including macronutrients (nitrogen, phosphorus, potassium) and micronutrients."
    })
  },
  {
    id: "G8-AG-SS-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil Fertility Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Effective soil fertility management improves crop productivity and sustainability. Which of the following is a way to improve soil fertility through sustainable practices?,
      options: [
        Using organic fertilizers, such as manure and compost, combined with inorganic fertilizers in a balanced approach to meet crop nutrient needs while maintaining soil health.,
        Using only inorganic fertilizers without organic matter.,
        "Leaving the soil fallow without management.,
        Burning crop residues to add nutrients."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using organic fertilizers, such as manure and compost, combined with inorganic fertilizers in a balanced approach to meet crop nutrient needs while maintaining soil health.
    })
  },
  {
    id: G8-AG-SS-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil conservation is critical for preventing land degradation. Which of the following conservation techniques is particularly effective for controlling soil erosion on steep slopes?,
      options: [
        Terracing is an effective technique for controlling soil erosion on steep slopes by creating platforms that reduce water runoff and soil loss.,
        Mulching is more effective than terracing on steep slopes.,
        Contour farming is effective only on flat land.",
        "Bare soil is best for preventing erosion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Terracing is an effective technique for controlling soil erosion on steep slopes by creating platforms that reduce water runoff and soil loss."
    })
  },
  {
    id: "G8-AG-SS-04",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Soil Science",
    subtopic: "Soil pH,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soil pH affects nutrient availability and crop growth. Which of the following is the optimal pH range for most crops in agricultural soils?,
      options: [
        The optimal pH range for most crops is between 6.0 and 7.5, where nutrients are most available and soil biological activity is optimal.,
        pH 5.0 is optimal for all crops.,
        "pH 8.5 is optimal for all crops.,
        Soil pH does not affect crop growth."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The optimal pH range for most crops is between 6.0 and 7.5, where nutrients are most available and soil biological activity is optimal.
    })
  },
  {
    id: G8-AG-SS-05",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Soil Science,
    subtopic: "Soil Pollution",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Soil pollution can be caused by various human activities, affecting agricultural productivity. Which of the following is a major source of soil pollution in agricultural areas?,
      options: [
        Chemical fertilizers and pesticides, if not used responsibly, can accumulate in the soil and cause pollution, affecting soil health and water quality.,
        Organic manure is a major source of soil pollution.,
        Crop residues cause significant soil pollution.",
        "Burning crop residues does not pollute the soil.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical fertilizers and pesticides, if not used responsibly, can accumulate in the soil and cause pollution, affecting soil health and water quality."
    })
  },
  {
    id: "G8-AG-WM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Advanced Irrigation,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Advanced irrigation techniques improve water use efficiency. Which of the following irrigation methods uses sensors to deliver water precisely when and where it is needed?,
      options: [
        Automated drip irrigation systems use sensors to monitor soil moisture and weather conditions, delivering water precisely when crops need it, reducing water waste.,
        Flood irrigation uses sensors to deliver water.,
        "Sprinkler irrigation is the most advanced method.,
        Furrow irrigation is technology advanced."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Automated drip irrigation systems use sensors to monitor soil moisture and weather conditions, delivering water precisely when crops need it, reducing water waste.
    })
  },
  {
    id: G8-AG-WM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Harvesting",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Water harvesting techniques capture and store water for agricultural use. Which of the following water harvesting techniques is particularly effective in areas with high rainfall variability?,
      options: [
        Building farm ponds and water pans to capture and store runoff water is particularly effective in areas with high rainfall variability, providing water for irrigation during dry spells.,
        Only rainwater from roofs can be harvested.,
        Farm ponds are not effective for water harvesting.",
        "Water pans cannot be used for irrigation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Building farm ponds and water pans to capture and store runoff water is particularly effective in areas with high rainfall variability, providing water for irrigation during dry spells."
    })
  },
  {
    id: "G8-AG-WM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Quality,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Water quality is important for crop production and livestock health. Which of the following is a potential problem associated with poor-quality irrigation water?,
      options: [
        High salinity in irrigation water can cause osmotic stress, nutrient imbalances, and damage to crops, reducing yields and affecting soil health.,
        Poor water quality does not affect plants.,
        "Salinity improves crop yields.,
        Water quality has no effect on soil structure."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "High salinity in irrigation water can cause osmotic stress, nutrient imbalances, and damage to crops, reducing yields and affecting soil health.
    })
  },
  {
    id: G8-AG-WM-04",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Use Efficiency",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Improving water use efficiency is critical for sustainable agriculture. Which of the following practices helps improve water use efficiency in crop production?,
      options: [
        Using deficit irrigation, where water is applied at critical growth stages, and selecting drought-resistant varieties, helps maximize yields per unit of water used.,
        Overwatering crops improves efficiency.,
        Applying water during the hottest part of the day is efficient.",
        "Using flood irrigation is the most efficient method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using deficit irrigation, where water is applied at critical growth stages, and selecting drought-resistant varieties, helps maximize yields per unit of water used."
    })
  },
  {
    id: "G8-AG-CP-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Advanced Crop Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Advanced crop management practices aim to maximize productivity while minimizing environmental impact. Which of the following is an example of a precision agriculture technique?,
      options: [
        Variable rate technology (VRT), which applies inputs (fertilizer, pesticides) at variable rates across a field based on soil variability, is a precision agriculture technique that optimizes input use.,
        Uniform application of fertilizers is precision agriculture.,
        "Using only manual labor is precision agriculture.,
        Precision agriculture does not use technology."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Variable rate technology (VRT), which applies inputs (fertilizer, pesticides) at variable rates across a field based on soil variability, is a precision agriculture technique that optimizes input use.
    })
  },
  {
    id: G8-AG-CP-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Pest Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Integrated pest management (IPM) provides sustainable approaches to pest control. Which of the following is a cultural control method used in integrated pest management?,
      options: [
        Crop rotation and intercropping are cultural control methods that disrupt pest life cycles, reduce pest populations, and increase biodiversity.,
        Using only chemical pesticides is cultural control.,
        Biological control uses cultural methods.",
        "Mechanical control is a cultural method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Crop rotation and intercropping are cultural control methods that disrupt pest life cycles, reduce pest populations, and increase biodiversity."
    })
  },
  {
    id: "G8-AG-CP-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Harvesting and Post-Harvest,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Post-harvest handling affects the quality and marketability of produce. Which of the following is an important post-harvest practice for preventing spoilage of fruits and vegetables?,
      options: [
        Cooling and proper packaging to reduce spoilage and maintain freshness, quality, and shelf life of fruits and vegetables after harvest.,
        Leaving produce in the sun extends shelf life.,
        "Using cardboard boxes is a post-harvest practice.,
        Cooling is not important after harvest."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooling and proper packaging to reduce spoilage and maintain freshness, quality, and shelf life of fruits and vegetables after harvest.
    })
  },
  {
    id: G8-AG-CP-04",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Agro-Processing",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agro-processing adds value to raw agricultural produce. Which of the following is a processed product from sugarcane?,
      options: [
        Sugar, molasses, and ethanol are processed products from sugarcane that have significant economic value.,
        Sugarcane can only be used to make sugar.,
        Ethanol cannot be produced from sugarcane.",
        "Molasses is not made from sugarcane.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sugar, molasses, and ethanol are processed products from sugarcane that have significant economic value."
    })
  },
  {
    id: "G8-AG-CP-05",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Sustainable Crop Production,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Sustainable crop production is essential for maintaining agricultural productivity. Which of the following is a sustainable crop production practice that reduces reliance on chemical fertilizers?,
      options: [
        Agroforestry, which integrates trees and crops, improves soil fertility naturally, reducing dependence on chemical fertilizers and improving long-term productivity.,
        Using only synthetic fertilizers is sustainable.,
        "Agroforestry does not reduce fertilizer use.,
        Monocropping improves soil fertility."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry, which integrates trees and crops, improves soil fertility naturally, reducing dependence on chemical fertilizers and improving long-term productivity.
    })
  },
  {
    id: G8-AG-LP-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Breeding",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Animal breeding improves livestock genetics and productivity. Which of the following is an advantage of artificial insemination (AI) in livestock breeding?,
      options: [
        Artificial insemination provides access to superior genetics, reduces disease transmission, and improves reproductive efficiency, allowing for rapid genetic improvement.,
        Artificial insemination is always more expensive.,
        Artificial insemination spreads diseases.",
        "Artificial insemination reduces genetic diversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Artificial insemination provides access to superior genetics, reduces disease transmission, and improves reproductive efficiency, allowing for rapid genetic improvement."
    })
  },
  {
    id: "G8-AG-LP-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Health Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Animal health management is essential for livestock productivity. Which of the following is the most effective strategy for preventing disease outbreaks in a livestock operation?,
      options: [
        Implementing a comprehensive biosecurity protocol including quarantine, vaccination programs, and regular health monitoring prevents disease introduction and spread.,
        Only treating sick animals prevents disease outbreaks.,
        "Vaccination is not effective for disease prevention.,
        Biosecurity is not important for livestock health."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Implementing a comprehensive biosecurity protocol including quarantine, vaccination programs, and regular health monitoring prevents disease introduction and spread.
    })
  },
  {
    id: G8-AG-LP-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Livestock Production Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Different livestock production systems exist depending on resource availability and management practices. Which of the following livestock production systems is characterized by low inputs and extensive grazing?,
      options: [
        Extensive pastoralism is a production system characterized by low inputs, large grazing areas, and low stocking rates, typical in Kenya's dry regions.,
        Intensive production systems use low inputs.,
        Zero-grazing is a low-input system.",
        "Feedlot systems have low inputs.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Extensive pastoralism is a production system characterized by low inputs, large grazing areas, and low stocking rates, typical in Kenya's dry regions."
    })
  },
  {
    id: "G8-AG-LP-04",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Livestock Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Livestock nutrition affects health and productivity. Which of the following is a protein source for livestock feed?,
      options: [
        Soybean meal, cottonseed cake, and fishmeal are high-quality protein sources used in livestock feed for growth, milk production, and maintenance.,
        Only grass provides protein.,
        "Maize is a protein source.,
        Protein sources are not needed in livestock feed."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Soybean meal, cottonseed cake, and fishmeal are high-quality protein sources used in livestock feed for growth, milk production, and maintenance.
    })
  },
  {
    id: G8-AG-LP-05",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Livestock Marketing",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Livestock marketing is important for farmers to earn income. Which of the following is a challenge faced by livestock farmers in Kenya?,
      options: [
        Limited market access, poor infrastructure, seasonal price fluctuations, and competition from imports are major challenges for livestock farmers in Kenya.,
        Market access is easy for all farmers.,
        Prices are always stable in livestock markets.",
        "Imports do not affect local livestock prices.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Limited market access, poor infrastructure, seasonal price fluctuations, and competition from imports are major challenges for livestock farmers in Kenya."
    })
  },
  {
    id: "G8-AG-FM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Farm Machinery,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Farm machinery improves agricultural efficiency and productivity. Which of the following farm machines is used for harvesting crops like maize and wheat?,
      options: [
        A combine harvester is used for harvesting and threshing crops such as maize and wheat, combining harvesting, threshing, and cleaning in one operation.,
        A tractor is used for harvesting.,
        "A power tiller is used for harvesting.,
        A planter is used for harvesting."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A combine harvester is used for harvesting and threshing crops such as maize and wheat, combining harvesting, threshing, and cleaning in one operation.
    })
  },
  {
    id: G8-AG-FM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Farm Mechanization,
    subtopic: "Equipment Maintenance",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Regular maintenance extends the life of farm machinery and reduces breakdowns. Which of the following is an important maintenance practice for tractors?,
      options: [
        Changing engine oil regularly, checking tire pressure, lubricating moving parts, and servicing the fuel system are essential maintenance practices for tractors.,
        Tractors do not require maintenance.,
        Oil changes are not important for tractors.",
        "Checking tire pressure is not important.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Changing engine oil regularly, checking tire pressure, lubricating moving parts, and servicing the fuel system are essential maintenance practices for tractors."
    })
  },
  {
    id: "G8-AG-FM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Farm Tools,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Simple farm tools remain important for small-scale farmers. Which of the following hand tools is used for removing weeds from fields?,
      options: [
        A jembe (hoe) is used for weeding, digging, and tilling, making it an essential tool for small-scale farmers in Kenya.,
        A panga (machete) is used for weeding.,
        "A rake is used for removing weeds.,
        A dibber is used for weeding."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A jembe (hoe) is used for weeding, digging, and tilling, making it an essential tool for small-scale farmers in Kenya.
    })
  },
  {
    id: G8-AG-AE-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Advisory Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Agricultural extension services connect farmers with vital information and resources. Which of the following is a key role of extension officers in Kenya's agricultural development?,
      options: [
        Extension officers provide training and technical advice to farmers on modern farming methods, pest control, and market access, helping them improve their farming practices.,
        Extension officers only work in offices.,
        Extension officers are only responsible for distributing inputs.",
        "Extension officers only work with large farms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Extension officers provide training and technical advice to farmers on modern farming methods, pest control, and market access, helping them improve their farming practices."
    })
  },
  {
    id: "G8-AG-AE-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agricultural Extension",
    subtopic: "Technology Transfer,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Technology transfer ensures farmers can adopt improved agricultural practices. Which of the following is an effective approach for transferring technology to small-scale farmers?,
      options: [
        Farmer field schools (FFS) provide hands-on learning and participatory approaches to technology transfer, enabling farmers to test and adopt technologies adapted to their local conditions.,
        Using only printed materials for technology transfer.,
        "Technology transfer does not need to be adapted to local conditions.,
        Participatory approaches are not effective."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Farmer field schools (FFS) provide hands-on learning and participatory approaches to technology transfer, enabling farmers to test and adopt technologies adapted to their local conditions.
    })
  },
  {
    id: G8-AG-AE-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Farmer Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Farmer education programs help farmers make informed decisions. Which of the following is an important benefit of continuous farmer education?,
      options: [
        Continuous farmer education helps farmers adapt to changing agricultural practices and market conditions, improving their productivity and profitability.,
        Farmer education is not important for productivity.,
        Education does not affect profitability.",
        "Continuous education has no benefits.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Continuous farmer education helps farmers adapt to changing agricultural practices and market conditions, improving their productivity and profitability."
    })
  },
  {
    id: "G8-AG-AM-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Market Access,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Accessing markets is essential for farm profitability. Which of the following helps small-scale farmers access better markets for their produce?,
      options: [
        Organizing into marketing cooperatives and groups helps farmers combine their produce, gain better bargaining power, and access larger markets at better prices.,
        Farmers can access better markets individually.,
        "Cooperatives do not help with market access.,
        Organizing into groups reduces market access."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organizing into marketing cooperatives and groups helps farmers combine their produce, gain better bargaining power, and access larger markets at better prices.
    })
  },
  {
    id: G8-AG-AM-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agribusiness and Marketing,
    subtopic: "Value Addition",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Value addition increases the profitability of agricultural enterprises. Which of the following is a value-added product from milk?,
      options: [
        Yoghurt, cheese, and butter are value-added dairy products that command higher prices than raw milk, reducing spoilage and increasing income.,
        Raw milk is a value-added product.,
        Milk cannot be processed into value-added products.",
        "Value-added dairy products are not profitable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Yoghurt, cheese, and butter are value-added dairy products that command higher prices than raw milk, reducing spoilage and increasing income."
    })
  },
  {
    id: "G8-AG-AM-03",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Cooperative Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Agricultural cooperatives provide support and resources for farmers. Which of the following is a benefit of joining an agricultural cooperative?,
      options: [
        Cooperatives provide access to input credit, training, marketing, and information sharing, helping farmers improve their productivity and income.,
        Cooperatives only benefit large-scale farmers.,
        "Cooperatives are not helpful for individual farmers.,
        Cooperatives limit access to resources."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooperatives provide access to input credit, training, marketing, and information sharing, helping farmers improve their productivity and income.
    })
  },
  {
    id: G8-AG-AF-01",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Silvopastoral Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Silvopastoral systems integrate trees with livestock production. Which of the following is a benefit of incorporating trees into livestock grazing systems?,
      options: [
        Silvopastoral systems provide shade for livestock, improve animal welfare and productivity, and provide fodder and additional income from tree products.,
        Trees compete with livestock for forage.,
        Silvopastoral systems reduce productivity.",
        "Livestock damage trees in silvopastoral systems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Silvopastoral systems provide shade for livestock, improve animal welfare and productivity, and provide fodder and additional income from tree products."
    })
  },
  {
    id: "G8-AG-AF-02",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Fruit Trees,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Fruit trees in agroforestry systems contribute to food and nutritional security. Which of the following fruit trees is important for nutrition and is widely grown in Kenya?,
      options: [
        Mango is widely grown in Kenya for its nutritional value and income potential, providing vitamins (especially vitamin C) and dietary fiber.,
        Mango trees are grown only in coastal areas.,
        "Mango is not important for nutrition.,
        Mango is not grown in Kenya."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mango is widely grown in Kenya for its nutritional value and income potential, providing vitamins (especially vitamin C) and dietary fiber.
    })
  },
  {
    id: G8-AG-AF-03",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Multipurpose Trees",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Multipurpose trees provide various products for farmers. Which of the following is an example of a multipurpose tree in East Africa?,
      options: [
        Moringa tree is a multipurpose tree providing nutritious leaves, medicinal products, seeds for oil production, and fodder for livestock, with many uses in agriculture and nutrition.,
        Moringa only provides leaves for food.,
        Moringa is not grown in East Africa.",
        "Moringa has no medicinal value.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Moringa tree is a multipurpose tree providing nutritious leaves, medicinal products, seeds for oil production, and fodder for livestock, with many uses in agriculture and nutrition."
    })
  },
  {
    id: "G8-AG-FP-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Food Processing and Value Addition",
    subtopic: "Processing Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Food processing techniques transform agricultural products into safe, shelf-stable, and marketable items. Which of the following processing techniques extends the shelf life of fruits and vegetables?,
      options: [
        "Canning and bottling are techniques that extend the shelf life of fruits and vegetables, preserving them for consumption when fresh produce is unavailable.,
        Freezing is a technique that extends shelf life, but is more energy-intensive.",
        "Drying is only suitable for grains.,
        Processing is not important for fruits."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Canning and bottling are techniques that extend the shelf life of fruits and vegetables, preserving them for consumption when fresh produce is unavailable.
    })
  },
  {
    id: G8-AG-FP-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Food Processing and Value Addition,
    subtopic: "Product Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Product development involves creating new value-added products from agricultural produce. Which of the following is a value-added product that can be made from cassava?,
      options: [
        Cassava flour, cassava chips, and cassava starch are value-added products from cassava that provide alternative income sources for farmers.,
        Only fresh cassava can be sold.,
        Cassava cannot be processed.",
        "Cassava processing is not profitable.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cassava flour, cassava chips, and cassava starch are value-added products from cassava that provide alternative income sources for farmers."
    })
  },
  {
    id: "G8-AG-SA-01",
    grade: "Grade 8",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Climate-Smart Agriculture,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Climate-smart agriculture aims to increase productivity and resilience while reducing greenhouse gas emissions. Which of the following is a climate-smart agriculture practice?,
      options: [
        Conservation agriculture (minimum tillage) and integrating trees with crops are climate-smart practices that reduce emissions, improve soil health, and increase resilience to climate shocks.,
        Deep ploughing is climate-smart agriculture.,
        "Burning crop residues is climate-smart.,
        Monocropping is climate-smart."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conservation agriculture (minimum tillage) and integrating trees with crops are climate-smart practices that reduce emissions, improve soil health, and increase resilience to climate shocks.
    })
  },
  {
    id: G8-AG-SA-02",
    grade: "Grade 8,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Environmental Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Environmental conservation is integral to sustainable agriculture. Which of the following practices contributes to the conservation of natural resources on farms?,
      options: [
        Maintaining riparian buffers along waterways, protecting wetlands, and preserving natural habitats contribute to environmental conservation in agricultural landscapes.,
        Clearing all natural vegetation is environmentally friendly.,
        Environmental conservation is not important for farms.",
        "Wetlands should be converted to agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Maintaining riparian buffers along waterways, protecting wetlands, and preserving natural habitats contribute to environmental conservation in agricultural landscapes."
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD AGRICULTURE SYLLABUS)
  // =========================================================================

  // --- SOIL SCIENCE AND CONSERVATION (5 Materials) ---
  {
    id: "G9-AG-SC-01",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Soil analysis is an important tool for making informed decisions about soil management and crop production. Which of the following is the most reliable method for determining the nutrient status of a soil sample?,
      options: [
        A comprehensive soil test conducted in a certified soil testing laboratory is the most reliable method for determining the nutrient status of a soil sample, as it provides accurate measurements of available nutrients and soil pH.,
        Visual observation of plant growth is sufficient to determine nutrient status.,
        "Feeling the soil texture is enough to determine nutrient needs.,
        Only measuring soil pH is needed to determine nutrient availability."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A comprehensive soil test conducted in a certified soil testing laboratory is the most reliable method for determining the nutrient status of a soil sample, as it provides accurate measurements of available nutrients and soil pH.
    })
  },
  {
    id: G9-AG-SC-02",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Fertility Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Sustainable soil fertility management is essential for maintaining agricultural productivity and protecting the environment. Which of the following approaches is the most sustainable for managing soil fertility in the long term?,
      options: [
        Integrated soil fertility management (ISFM), which combines organic and inorganic fertilizers with improved crop varieties and agronomic practices, is the most sustainable approach for managing soil fertility.,
        Using only inorganic fertilizers without any organic matter is the best approach.,
        Using only organic fertilizers is always sufficient.",
        "Relying solely on crop rotation to maintain fertility.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Integrated soil fertility management (ISFM), which combines organic and inorganic fertilizers with improved crop varieties and agronomic practices, is the most sustainable approach for managing soil fertility."
    })
  },
  {
    id: "G9-AG-SC-03",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Soil conservation practices are essential for maintaining soil health and agricultural productivity. Which of the following conservation practices is most effective for reducing soil erosion in areas with both wind and water erosion?,
      options: [
        Agroforestry and windbreaks are effective for reducing both wind and water erosion by providing permanent soil cover and slowing wind speeds, while also improving soil structure.,
        Terracing only helps with water erosion.,
        "Mulching only helps with water erosion.,
        Contour farming only helps with wind erosion."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Agroforestry and windbreaks are effective for reducing both wind and water erosion by providing permanent soil cover and slowing wind speeds, while also improving soil structure.
    })
  },
  {
    id: G9-AG-SC-04",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Soil Science and Conservation,
    subtopic: "Soil Organic Matter",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Soil organic matter is a critical component of healthy agricultural soils. Which of the following is the primary benefit of maintaining high organic matter levels in agricultural soils?,
      options: [
        Soil organic matter improves soil structure, water-holding capacity, and nutrient availability, while also supporting beneficial soil organisms and increasing resilience to environmental stress.,
        Soil organic matter only adds nutrients to the soil.,
        Organic matter has no effect on soil structure.",
        "Increasing organic matter does not affect water-holding capacity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Soil organic matter improves soil structure, water-holding capacity, and nutrient availability, while also supporting beneficial soil organisms and increasing resilience to environmental stress."
    })
  },
  {
    id: "G9-AG-SC-05",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Soil Science and Conservation",
    subtopic: "Soil Degradation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Soil degradation reduces agricultural productivity and affects food security. Which of the following is the most severe form of soil degradation that causes irreversible damage to agricultural land?,
      options: [
        Soil salinization, which is the accumulation of salts in the soil due to poor irrigation practices or natural causes, can lead to irreversible damage to agricultural land and loss of productivity.,
        Soil erosion is always irreversible.,
        "Nutrient depletion is irreversible.,
        Acidification can be reversed quickly."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Soil salinization, which is the accumulation of salts in the soil due to poor irrigation practices or natural causes, can lead to irreversible damage to agricultural land and loss of productivity.
    })
  },

  // --- WATER MANAGEMENT (4 Materials) ---
  {
    id: G9-AG-WM-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Advanced Irrigation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Advanced irrigation technologies can significantly improve water use efficiency in agriculture. Which of the following technologies allows farmers to monitor and control irrigation systems remotely using mobile devices?,
      options: [
        Smart irrigation systems use sensors, weather data, and mobile connectivity to monitor soil moisture and control irrigation automatically or remotely, improving water efficiency.,
        Drip irrigation is the only advanced irrigation technology.,
        Flood irrigation is more advanced than smart irrigation.",
        "Sprinkler irrigation has remote monitoring capabilities.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Smart irrigation systems use sensors, weather data, and mobile connectivity to monitor soil moisture and control irrigation automatically or remotely, improving water efficiency."
    })
  },
  {
    id: "G9-AG-WM-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Harvesting,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Water harvesting techniques are crucial for supplementing water supplies in rain-fed agricultural systems. Which of the following water harvesting techniques is most appropriate for small-scale farmers in semi-arid regions?,
      options: [
        In-situ rainwater harvesting techniques such as zai pits and contour bunds are appropriate for small-scale farmers in semi-arid regions as they capture rainfall and improve water infiltration at minimal cost.,
        Large dams are the most appropriate for small-scale farmers.,
        "Extensive irrigation canals are suitable for small-scale farmers.,
        Boreholes are the best option for water harvesting."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "In-situ rainwater harvesting techniques such as zai pits and contour bunds are appropriate for small-scale farmers in semi-arid regions as they capture rainfall and improve water infiltration at minimal cost.
    })
  },
  {
    id: G9-AG-WM-03",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Water Management,
    subtopic: "Water Quality",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Water quality is an important factor affecting crop growth and livestock health. Which of the following is an indicator of poor water quality that can affect agricultural production?,
      options: [
        High salinity (measured as electrical conductivity) in irrigation water indicates poor water quality that can cause osmotic stress and reduce crop yields, especially in sensitive crops.,
        Low pH of water is always a problem.,
        Water temperature is the only indicator of water quality.",
        "Water color is the most important indicator of quality.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: High salinity (measured as electrical conductivity) in irrigation water indicates poor water quality that can cause osmotic stress and reduce crop yields, especially in sensitive crops."
    })
  },
  {
    id: "G9-AG-WM-04",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Water Management",
    subtopic: "Water Use Efficiency,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Improving water use efficiency is critical in agriculture. Which of the following is the most effective way to improve water use efficiency in crop production?,
      options: [
        Using deficit irrigation combined with drought-tolerant crop varieties maximizes crop yield per unit of water, making it the most effective way to improve water use efficiency.,
        Over-irrigating crops improves efficiency.,
        "Changing irrigation frequency only without other adjustments.,
        Using only drought-tolerant varieties without irrigation management."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using deficit irrigation combined with drought-tolerant crop varieties maximizes crop yield per unit of water, making it the most effective way to improve water use efficiency.
    })
  },

  // --- CROP PRODUCTION (5 Materials) ---
  {
    id: G9-AG-CP-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Advanced Crop Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Advanced crop management practices are essential for optimizing yields and ensuring sustainability. Which of the following is a key component of conservation agriculture that helps build soil health over time?,
      options: [
        Permanent soil cover (mulching) with crop residues or cover crops reduces erosion, improves soil health, and conserves moisture, which are key components of conservation agriculture.,
        Continuous deep ploughing is a component of conservation agriculture.,
        Burning crop residues is part of conservation agriculture.",
        "Monocropping without rotation is a conservation agriculture practice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Permanent soil cover (mulching) with crop residues or cover crops reduces erosion, improves soil health, and conserves moisture, which are key components of conservation agriculture."
    })
  },
  {
    id: "G9-AG-CP-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Pest Control,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Integrated pest management (IPM) is a sustainable approach to pest control. Which of the following is an important biological control method used in IPM?,
      options: [
        Biological control using natural enemies such as parasitic wasps and predatory insects is an important component of IPM that reduces pest populations without harmful chemicals.,
        Using only chemical pesticides is biological control.,
        "Cultural methods are the only biological control.,
        Mechanical control is a form of biological control."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Biological control using natural enemies such as parasitic wasps and predatory insects is an important component of IPM that reduces pest populations without harmful chemicals.
    })
  },
  {
    id: G9-AG-CP-03",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Post-Harvest Handling",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Proper post-harvest handling is crucial for reducing losses and maintaining food quality. Which of the following practices is most important for reducing post-harvest losses of grains and cereals?,
      options: [
        Proper drying to safe moisture levels before storage is the most important practice for reducing post-harvest losses of grains, as it prevents fungal growth and insect infestation.,
        Storing grains immediately after harvest without drying.,
        Using only metal containers for storage.",
        "Applying pesticides after storage without drying.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Proper drying to safe moisture levels before storage is the most important practice for reducing post-harvest losses of grains, as it prevents fungal growth and insect infestation."
    })
  },
  {
    id: "G9-AG-CP-04",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Crop Production",
    subtopic: "Agro-Processing,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Agro-processing adds value to agricultural commodities and opens new markets. Which of the following is a processed product that can be derived from oilseeds such as sunflower and soybean?,
      options: [
        Edible oil and oilseed cake (used for animal feed) are processed products that can be derived from oilseeds, providing multiple income streams from the same crop.,
        Only raw oilseeds can be sold.,
        "Oilseeds cannot be processed into edible oil.,
        Animal feed is not produced from oilseeds."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Edible oil and oilseed cake (used for animal feed) are processed products that can be derived from oilseeds, providing multiple income streams from the same crop.
    })
  },
  {
    id: G9-AG-CP-05",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Crop Production,
    subtopic: "Sustainable Crop Production",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Sustainable crop production requires a balanced approach that considers both productivity and environmental health. Which of the following practices contributes to sustainable crop production by improving biodiversity?,
      options: [
        Crop rotation and intercropping contribute to sustainable crop production by improving biodiversity, reducing pest and disease pressure, and maintaining soil health.,
        Monocropping is the most sustainable practice.,
        Using only synthetic inputs is sustainable.",
        "Burning crop residues improves biodiversity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Crop rotation and intercropping contribute to sustainable crop production by improving biodiversity, reducing pest and disease pressure, and maintaining soil health."
    })
  },

  // --- LIVESTOCK PRODUCTION (5 Materials) ---
  {
    id: "G9-AG-LP-01",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Animal Breeding,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Animal breeding strategies influence livestock productivity and sustainability. Which of the following breeding strategies is used to maintain or improve specific traits in a livestock population?,
      options: [
        Selective breeding (selection) of animals with desirable traits is a breeding strategy used to improve specific characteristics such as milk production, growth rate, and disease resistance.,
        Random breeding without selection improves traits.,
        "Breeding only for single traits is recommended.,
        All animals should be bred regardless of their traits."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Selective breeding (selection) of animals with desirable traits is a breeding strategy used to improve specific characteristics such as milk production, growth rate, and disease resistance.
    })
  },
  {
    id: G9-AG-LP-02",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Animal Health Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Animal health management is critical for livestock productivity and food safety. Which of the following is the most important component of an effective animal health management plan?,
      options: [
        A comprehensive disease prevention program including vaccination, biosecurity, and regular health monitoring is the most important component of an effective animal health management plan.,
        Only treating sick animals is sufficient.,
        Vaccination is not important for livestock health.",
        "Biosecurity measures are optional for livestock farms.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A comprehensive disease prevention program including vaccination, biosecurity, and regular health monitoring is the most important component of an effective animal health management plan."
    })
  },
  {
    id: "G9-AG-LP-03",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Livestock Production Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Different livestock production systems have different environmental and economic implications. Which of the following livestock production systems is generally associated with the highest environmental footprint but also the highest productivity?,
      options: [
        Intensive livestock production systems (e.g., feedlots and confined animal operations) have the highest productivity but also the highest environmental impact due to waste management challenges.,
        Extensive pastoralism has the highest environmental footprint.,
        "Mixed farming systems have the lowest productivity.,
        Intensive systems have the lowest environmental impact."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Intensive livestock production systems (e.g., feedlots and confined animal operations) have the highest productivity but also the highest environmental impact due to waste management challenges.
    })
  },
  {
    id: G9-AG-LP-04",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Livestock Production,
    subtopic: "Livestock Nutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Livestock nutrition is a key factor in productivity and health. Which of the following nutrient groups is required in small amounts by livestock but is critical for metabolic function?,
      options: [
        Minerals and vitamins are required in small amounts but are critical for metabolic function, growth, reproduction, and disease resistance in livestock.,
        Carbohydrates are micronutrients.,
        Proteins are only needed in small amounts.",
        "Fats are the most critical micronutrients.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Minerals and vitamins are required in small amounts but are critical for metabolic function, growth, reproduction, and disease resistance in livestock."
    })
  },
  {
    id: "G9-AG-LP-05",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Livestock Production",
    subtopic: "Livestock Marketing,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Livestock marketing is essential for farmers to realize value from their livestock enterprises. Which of the following factors most influences livestock prices in local markets in Kenya?,
      options: [
        Livestock prices are heavily influenced by market demand, with higher prices during festivals and religious holidays when demand is high, and lower prices during drought periods.,
        Livestock prices are determined only by animal weight.,
        "Seasonal variations do not affect livestock prices.,
        Imports have no effect on local livestock prices."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Livestock prices are heavily influenced by market demand, with higher prices during festivals and religious holidays when demand is high, and lower prices during drought periods.
    })
  },

  // --- FARM MECHANIZATION (3 Materials) ---
  {
    id: G9-AG-FM-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Farm Mechanization,
    subtopic: "Machinery",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Farm machinery increases agricultural efficiency and productivity. Which of the following farm machines is used for land preparation by plowing and harrowing?,
      options: [
        A tractor with attached implements (plow and harrow) is used for land preparation, including plowing and harrowing, to prepare the soil for planting.,
        A combine harvester is used for land preparation.,
        A planter is used for land preparation.",
        "A power tiller is used for harvesting.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A tractor with attached implements (plow and harrow) is used for land preparation, including plowing and harrowing, to prepare the soil for planting."
    })
  },
  {
    id: "G9-AG-FM-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Farm Mechanization",
    subtopic: "Equipment Maintenance,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Proper maintenance of farm machinery reduces breakdowns and extends the life of equipment. Which of the following is the most important maintenance practice for farm machinery?,
      options: [
        Regular servicing and lubrication of moving parts is the most important maintenance practice for farm machinery, as it reduces friction, wear, and breakdowns.,
        Only cleaning equipment after use is sufficient maintenance.,
        "Machinery does not require regular maintenance.,
        Replacing parts only when they break is a good practice."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular servicing and lubrication of moving parts is the most important maintenance practice for farm machinery, as it reduces friction, wear, and breakdowns.
    })
  },
  {
    id: G9-AG-FM-03",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Farm Mechanization,
    subtopic: "Farm Tools",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Farm tools remain important for small-scale farmers. Which of the following tools is used for harvesting grains and cutting fodder?,
      options: [
        A scythe or sickle is used for harvesting grains and cutting fodder, providing a simple but effective way to harvest crops in small-scale farming systems.,
        A jembe is used for harvesting.,
        A panga is used for planting.",
        "A rake is used for harvesting grains.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A scythe or sickle is used for harvesting grains and cutting fodder, providing a simple but effective way to harvest crops in small-scale farming systems."
    })
  },

  // --- AGRICULTURAL EXTENSION (3 Materials) ---
  {
    id: "G9-AG-AE-01",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Agricultural Extension",
    subtopic: "Advisory Services,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Agricultural extension services are vital for technology transfer and farmer education. Which of the following is a key challenge facing agricultural extension services in Kenya?,
      options: [
        Inadequate funding and staffing, limited access to remote areas, and poor coordination among stakeholders are key challenges facing agricultural extension services in Kenya.,
        Extension services have more resources than they need.,
        "Extension services reach all farmers effectively.,
        There are no challenges facing extension services."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Inadequate funding and staffing, limited access to remote areas, and poor coordination among stakeholders are key challenges facing agricultural extension services in Kenya.
    })
  },
  {
    id: G9-AG-AE-02",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Agricultural Extension,
    subtopic: "Technology Transfer",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Technology transfer is essential for improving agricultural productivity. Which of the following is an effective method for transferring agricultural technology to small-scale farmers?,
      options: [
        Demonstration plots and field days are effective methods for technology transfer, as they allow farmers to see and learn about new technologies in their local context.,
        Only printed materials are effective for technology transfer.,
        Radio announcements are the only effective method.",
        "Technology transfer is not needed for small-scale farmers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Demonstration plots and field days are effective methods for technology transfer, as they allow farmers to see and learn about new technologies in their local context."
    })
  },
  {
    id: "G9-AG-AE-03",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Agricultural Extension",
    subtopic: "Farmer Education,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Continuous farmer education is important for agricultural development. Which of the following is a benefit of farmer education programs?,
      options: [
        Farmer education improves adoption of improved practices, increases productivity, enhances farm profitability, and builds sustainable livelihoods and food security.,
        Farmer education has no impact on productivity.,
        "Farmer education only helps with marketing.,
        Education does not affect farm profitability."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Farmer education improves adoption of improved practices, increases productivity, enhances farm profitability, and builds sustainable livelihoods and food security.
    })
  },

  // --- AGRIBUSINESS AND MARKETING (3 Materials) ---
  {
    id: G9-AG-AM-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Agribusiness and Marketing,
    subtopic: "Market Access",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Market access is a major determinant of farm income and agricultural growth. Which of the following is a major barrier to market access for small-scale farmers in Kenya?,
      options: [
        Lack of market information, poor infrastructure, and limited bargaining power are major barriers to market access for small-scale farmers in Kenya.,
        Access to markets is easy for all farmers.,
        Infrastructure is not a barrier to market access.",
        "Farmers have all the market information they need.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Lack of market information, poor infrastructure, and limited bargaining power are major barriers to market access for small-scale farmers in Kenya."
    })
  },
  {
    id: "G9-AG-AM-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Agribusiness and Marketing",
    subtopic: "Value Addition,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Value addition is a strategy to increase the value of agricultural produce. Which of the following is a value-added product that can be made from fresh milk?,
      options: [
        Yoghurt, cheese, and butter are value-added products that can be made from fresh milk, providing higher returns and extending the shelf life of the product.,
        Fresh milk is already a value-added product.,
        "Milk cannot be processed into value-added products.,
        Value-added milk products are not profitable."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Yoghurt, cheese, and butter are value-added products that can be made from fresh milk, providing higher returns and extending the shelf life of the product.
    })
  },
  {
    id: G9-AG-AM-03",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Agribusiness and Marketing,
    subtopic: "Cooperative Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Agricultural cooperatives provide a framework for collective action and resource pooling. Which of the following is the greatest advantage of a cooperative for small-scale farmers?,
      options: [
        Cooperatives provide farmers with collective bargaining power, access to larger markets, economies of scale in purchasing inputs, and access to credit and training.,
        Cooperatives only benefit large-scale farmers.,
        Cooperatives are not helpful for individual farmers.",
        "Cooperatives increase competition among members.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cooperatives provide farmers with collective bargaining power, access to larger markets, economies of scale in purchasing inputs, and access to credit and training."
    })
  },

  // --- AGROFORESTRY (3 Materials) ---
  {
    id: "G9-AG-AF-01",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Silvopastoral Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Silvopastoral systems integrate trees with livestock production. Which of the following is a major benefit of silvopastoral systems in dry areas?,
      options: [
        Silvopastoral systems provide shade and reduce heat stress on livestock, improve fodder availability through tree leaves, and increase livestock productivity in dry areas.,
        Trees have no benefits in pastoral systems.,
        "Livestock productivity is always lower in silvopastoral systems.,
        Shade is not important for livestock."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Silvopastoral systems provide shade and reduce heat stress on livestock, improve fodder availability through tree leaves, and increase livestock productivity in dry areas.
    })
  },
  {
    id: G9-AG-AF-02",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Agroforestry,
    subtopic: "Fruit Trees",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Fruit trees play an important role in improving nutrition and income for farm families. Which of the following is a major challenge in integrating fruit trees into agroforestry systems?,
      options: [
        The long time to maturity of most fruit trees is a challenge for farmers, as they must wait several years before seeing returns, making appropriate species selection important.,
        Fruit trees always produce quick returns.,
        Fruit trees are easy to establish.",
        "All fruit trees are suitable for all areas.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The long time to maturity of most fruit trees is a challenge for farmers, as they must wait several years before seeing returns, making appropriate species selection important."
    })
  },
  {
    id: "G9-AG-AF-03",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Agroforestry",
    subtopic: "Multipurpose Trees,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Multipurpose trees provide a variety of products and services. Which of the following is a multipurpose tree that is important in Kenya's agricultural systems?,
      options: [
        Moringa is an important multipurpose tree providing nutritious leaves, high-quality oil, and potential medicinal uses, making it valuable in food and nutrition security.,
        Moringa only provides wood.,
        "Moringa is not grown in Kenya.,
        Moringa has no medicinal uses."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Moringa is an important multipurpose tree providing nutritious leaves, high-quality oil, and potential medicinal uses, making it valuable in food and nutrition security.
    })
  },

  // --- FOOD PROCESSING AND VALUE ADDITION (2 Materials) ---
  {
    id: G9-AG-FP-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Food Processing and Value Addition,
    subtopic: "Processing Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Food processing techniques convert raw agricultural commodities into consumable products. Which of the following food processing techniques is appropriate for reducing post-harvest losses of cereals and grains?,
      options: [
        Drying and proper storage are the most important food processing techniques for reducing post-harvest losses of cereals and grains, by reducing moisture and preventing spoilage.,
        Canning is the best technique for grains.,
        Freezing is used for grains.",
        "Smoking is used for grain preservation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Drying and proper storage are the most important food processing techniques for reducing post-harvest losses of cereals and grains, by reducing moisture and preventing spoilage."
    })
  },
  {
    id: "G9-AG-FP-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Food Processing and Value Addition",
    subtopic: "Product Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Product development in agriculture involves creating new uses and markets for agricultural produce. Which of the following is an innovative use of cassava that adds value to the crop?,
      options: [
        Cassava processing into high-quality cassava flour, starch, and bioethanol are innovative uses that add value to cassava and provide new income opportunities.,
        Cassava is only used for fresh consumption.,
        "Cassava starch has no market.,
        Bioethanol production from cassava is not viable."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Cassava processing into high-quality cassava flour, starch, and bioethanol are innovative uses that add value to cassava and provide new income opportunities.
    })
  },

  // --- SUSTAINABLE AGRICULTURE (2 Materials) ---
  {
    id: G9-AG-SA-01",
    grade: "Grade 9,
    subject: Agriculture",
    topic: "Sustainable Agriculture,
    subtopic: "Climate-Smart Agriculture",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Climate-smart agriculture promotes sustainable practices that build resilience to climate change. Which of the following is a key pillar of climate-smart agriculture?,
      options: [
        Building resilience to climate shocks, increasing productivity sustainably, and reducing greenhouse gas emissions are the three key pillars of climate-smart agriculture.,
        Climate-smart agriculture only focuses on productivity.,
        Reducing emissions is not part of climate-smart agriculture.",
        "Resilience is not a pillar of climate-smart agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Building resilience to climate shocks, increasing productivity sustainably, and reducing greenhouse gas emissions are the three key pillars of climate-smart agriculture."
    })
  },
  {
    id: "G9-AG-SA-02",
    grade: "Grade 9",
    subject: "Agriculture",
    topic: "Sustainable Agriculture",
    subtopic: "Environmental Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Environmental conservation is essential for long-term agricultural sustainability. Which of the following is a sustainable practice that protects natural resources while maintaining agricultural productivity?,
      options: [
        Integrated watershed management, which balances agricultural production with protection of water resources and biodiversity, is a sustainable practice that maintains productivity while conserving natural resources.,
        Clearing all natural vegetation for agriculture is sustainable.,
        "Environmental conservation is not compatible with agriculture.,
        Protecting natural resources reduces agricultural productivity."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Integrated watershed management, which balances agricultural production with protection of water resources and biodiversity, is a sustainable practice that maintains productivity while conserving natural resources."
    })
  }

];


