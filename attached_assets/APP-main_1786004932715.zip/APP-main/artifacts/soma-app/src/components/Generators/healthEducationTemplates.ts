export const healthEducationTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD HEALTH EDUCATION SYLLABUS)
  // =========================================================================

  // --- HEALTH AND NUTRITION (5 Materials) ---
  {
    id: "G7-HE-HN-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Introduction to Nutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Nutrition is the process by which the body takes in and uses food for growth, energy, and maintenance of health. Which of the following is the best definition of nutrition according to health education principles?,
      options: [
        "Nutrition is the study of how food affects the body and how the body uses food to grow, repair itself, and maintain health.,
        Nutrition is the process of eating food only when hungry.",
        "Nutrition is the study of cooking methods and food preparation.,
        Nutrition is the process of eliminating waste from the body."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nutrition is the study of how food affects the body and how the body uses food to grow, repair itself, and maintain health.
    })
  },
  {
    id: G7-HE-HN-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Health and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A balanced diet is essential for good health and requires foods from all food groups in the correct proportions. Which of the following foods belongs to the body-building food group and why is it important?,
      options: [
        Beans and meat, which are rich in proteins essential for building and repairing body tissues.,
        Bread and rice, which provide energy for the body.,
        Fruits and vegetables, which provide vitamins for immunity.",
        "Butter and cooking oil, which provide fats for energy storage.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Beans and meat, which are rich in proteins essential for building and repairing body tissues."
    })
  },
  {
    id: "G7-HE-HN-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Different nutrients perform specific functions in the body. What is the primary function of vitamins in the human body, and why are they essential for health?,
      options: [
        Vitamins are essential for regulating body processes, supporting immune function, and maintaining overall health; they cannot be produced in sufficient quantities by the body and must be obtained from food.,
        Vitamins provide energy for daily activities.",
        "Vitamins are used to build muscles and tissues.,
        Vitamins are stored as fat for long-term energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins are essential for regulating body processes, supporting immune function, and maintaining overall health; they cannot be produced in sufficient quantities by the body and must be obtained from food.
    })
  },
  {
    id: G7-HE-HN-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Health and Nutrition,
    subtopic: "Malnutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Malnutrition results when the body does not get the right amount of nutrients needed for proper functioning. Which of the following health problems is caused by a deficiency of iron in the diet?,
      options: [
        Iron deficiency leads to anaemia, characterized by fatigue, weakness, and pale skin because the body cannot produce enough red blood cells to carry oxygen.,
        Iron deficiency leads to rickets, which causes weak and soft bones.,
        Iron deficiency leads to scurvy, which causes bleeding gums and joint pain.",
        "Iron deficiency leads to beriberi, which causes nerve and muscle problems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Iron deficiency leads to anaemia, characterized by fatigue, weakness, and pale skin because the body cannot produce enough red blood cells to carry oxygen."
    })
  },
  {
    id: "G7-HE-HN-05",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Healthy Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Developing healthy eating habits during adolescence is important for growth and preventing lifestyle diseases. Which of the following practices is the best approach to maintaining a healthy diet?,
      options: [
        Eating regular meals with a variety of foods from all food groups, drinking plenty of water, and limiting processed foods high in sugar, salt, and unhealthy fats.,
        Skipping breakfast to save time and reduce calorie intake.,
        "Eating only fruits and vegetables without any proteins or carbohydrates.,
        Eating large amounts of fried and fatty foods for energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Eating regular meals with a variety of foods from all food groups, drinking plenty of water, and limiting processed foods high in sugar, salt, and unhealthy fats.
    })
  },

  // --- HUMAN BODY SYSTEMS (5 Materials) ---
  {
    id: G7-HE-HB-01",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Skeletal System",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The skeletal system provides structure, support, and protection for the body. Which of the following describes the primary functions of the human skeleton in maintaining health?,
      options: [
        The skeleton supports the body, protects vital organs such as the heart and lungs, allows movement, stores minerals, and produces blood cells in the bone marrow.,
        The skeleton is responsible for digesting food and absorbing nutrients.,
        The skeleton pumps blood throughout the body.",
        "The skeleton controls the body's response to stress.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The skeleton supports the body, protects vital organs such as the heart and lungs, allows movement, stores minerals, and produces blood cells in the bone marrow."
    })
  },
  {
    id: "G7-HE-HB-02",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Muscular System,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The muscular system enables movement and maintains posture. Which of the following correctly describes how muscles work in pairs to produce movement?,
      options: [
        Muscles work as antagonistic pairs, where one muscle contracts (agonist) while the other relaxes (antagonist) to produce movement, such as the biceps and triceps in the arm.,
        Muscles work independently without coordination.,
        "All muscles contract and relax at the same time.,
        Muscles do not require energy to function."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Muscles work as antagonistic pairs, where one muscle contracts (agonist) while the other relaxes (antagonist) to produce movement, such as the biceps and triceps in the arm.
    })
  },
  {
    id: G7-HE-HB-03",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Digestive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The digestive system breaks down food into nutrients that can be absorbed into the bloodstream. Which of the following is the correct sequence of organs through which food passes during digestion?,
      options: [
        Mouth → Oesophagus → Stomach → Small intestine → Large intestine → Rectum → Anus.,
        Mouth → Stomach → Oesophagus → Small intestine → Large intestine → Anus.,
        Mouth → Large intestine → Small intestine → Stomach → Oesophagus → Anus.",
        "Mouth → Oesophagus → Large intestine → Stomach → Small intestine → Anus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mouth → Oesophagus → Stomach → Small intestine → Large intestine → Rectum → Anus."
    })
  },
  {
    id: "G7-HE-HB-04",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Respiratory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The respiratory system is responsible for gas exchange between the body and the environment. What is the function of the alveoli in the lungs, and how does their structure support this function?,
      options: [
        Alveoli are tiny air sacs with thin walls and a rich blood supply, where oxygen diffuses into the blood and carbon dioxide diffuses out, facilitating efficient gas exchange.,
        Alveoli produce mucus to trap dust and germs.",
        "Alveoli are responsible for warming and filtering the air we breathe.,
        Alveoli contract and expand to pump air into the lungs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Alveoli are tiny air sacs with thin walls and a rich blood supply, where oxygen diffuses into the blood and carbon dioxide diffuses out, facilitating efficient gas exchange.
    })
  },
  {
    id: G7-HE-HB-05",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Circulatory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The circulatory system transports oxygen, nutrients, hormones, and waste products throughout the body. Which of the following correctly describes the function of the heart and its role in circulation?,
      options: [
        The heart is a muscular organ that pumps blood through the circulatory system. It has four chambers (two atria and two ventricles) that coordinate to ensure efficient circulation of oxygenated and deoxygenated blood.,
        The heart produces red blood cells and platelets.,
        The heart filters waste products from the blood.",
        "The heart stores oxygen for use by the body.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The heart is a muscular organ that pumps blood through the circulatory system. It has four chambers (two atria and two ventricles) that coordinate to ensure efficient circulation of oxygenated and deoxygenated blood."
    })
  },

  // --- MENTAL AND EMOTIONAL HEALTH (4 Materials) ---
  {
    id: "G7-HE-ME-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Self-Awareness,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Self-awareness is the ability to recognize and understand one's own emotions, thoughts, and behaviors. Why is self-awareness important for adolescent mental health and well-being?,
      options: [
        "Self-awareness helps adolescents understand their strengths and weaknesses, manage their emotions effectively, make better decisions, and build healthy relationships with others.,
        Self-awareness is only important for adults, not adolescents.",
        "Self-awareness encourages isolation from others.,
        Self-awareness prevents any emotional expression."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Self-awareness helps adolescents understand their strengths and weaknesses, manage their emotions effectively, make better decisions, and build healthy relationships with others.
    })
  },
  {
    id: G7-HE-ME-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Understanding Emotions",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Emotions are natural responses to situations that affect how we feel and behave. Which of the following is a healthy way to cope with feelings of anger and frustration?,
      options: [
        Taking time to calm down, expressing feelings in a constructive way, talking to a trusted person, and using relaxation techniques such as deep breathing.,
        Lashing out at others and breaking things.,
        Bottling up emotions and ignoring them.",
        "Reacting immediately without thinking.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Taking time to calm down, expressing feelings in a constructive way, talking to a trusted person, and using relaxation techniques such as deep breathing."
    })
  },
  {
    id: "G7-HE-ME-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Stress Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stress is the body's response to challenges or demands. Which of the following stress management techniques is most effective for reducing the negative effects of stress on mental and physical health?,
      options: [
        Engaging in regular physical activity, practicing mindfulness and relaxation techniques, maintaining social connections, and ensuring adequate sleep.,
        Ignoring stress and pretending it does not exist.,
        "Using alcohol or drugs to cope with stress.,
        Spending excessive time on social media and screen time."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Engaging in regular physical activity, practicing mindfulness and relaxation techniques, maintaining social connections, and ensuring adequate sleep.
    })
  },
  {
    id: G7-HE-ME-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Building Resilience",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Resilience is the ability to bounce back from difficult situations and challenges. Which of the following factors helps build resilience in adolescents?,
      options: [
        Having supportive relationships with family and friends, developing problem-solving skills, maintaining a positive outlook, and learning from failures and setbacks.,
        Avoiding all challenges and difficult situations.,
        Relying only on oneself without any support.",
        "Giving up easily when faced with challenges.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Having supportive relationships with family and friends, developing problem-solving skills, maintaining a positive outlook, and learning from failures and setbacks."
    })
  },

  // --- PERSONAL HYGIENE (4 Materials) ---
  {
    id: "G7-HE-PH-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Personal Hygiene",
    subtopic: "Body Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Personal hygiene is essential for preventing the spread of diseases and maintaining good health. What is the recommended practice for maintaining personal cleanliness and preventing body odor?,
      options: [
        Bathing daily with soap and water, wearing clean clothes, and using deodorant or antiperspirant to control body odor.,
        Bathing only once a week to save water.,
        "Wearing dirty clothes and not bathing to develop immunity.,
        Using perfume to cover odor without bathing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water, wearing clean clothes, and using deodorant or antiperspirant to control body odor.
    })
  },
  {
    id: G7-HE-PH-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Personal Hygiene,
    subtopic: "Dental Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Dental hygiene is crucial for preventing tooth decay, gum disease, and bad breath. Which of the following is the most effective daily dental hygiene practice recommended by health professionals?,
      options: [
        Brushing teeth twice a day (morning and before bed) with fluoride toothpaste, flossing daily, and visiting the dentist regularly for check-ups.,
        Brushing teeth only once a week.,
        Using a toothpick to clean between teeth instead of flossing.",
        "Rinsing the mouth with water only without brushing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Brushing teeth twice a day (morning and before bed) with fluoride toothpaste, flossing daily, and visiting the dentist regularly for check-ups."
    })
  },
  {
    id: "G7-HE-PH-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Skin care is important for preventing acne, infections, and maintaining healthy skin. What is the recommended daily skin care routine for adolescents to maintain healthy skin?,
      options: [
        "Washing the face twice daily with a gentle cleanser, moisturizing, using sunscreen, and avoiding touching the face with dirty hands.,
        Washing the face only when it feels oily.",
        "Using harsh soaps and scrubbing the skin vigorously.,
        Popping pimples to make them go away faster."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing the face twice daily with a gentle cleanser, moisturizing, using sunscreen, and avoiding touching the face with dirty hands.
    })
  },
  {
    id: G7-HE-PH-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Personal Hygiene,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Good grooming involves caring for the skin, hair, and nails to maintain a neat and healthy appearance. Which of the following grooming practices is important for preventing nail infections?,
      options: [
        Keeping nails clean and trimmed, avoiding biting nails, and ensuring nails are dry and clean to prevent fungal and bacterial infections.,
        Biting nails to keep them short.,
        Ignoring nail hygiene and allowing them to grow long and dirty.",
        "Covering nails with artificial nails without cleaning underneath.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Keeping nails clean and trimmed, avoiding biting nails, and ensuring nails are dry and clean to prevent fungal and bacterial infections."
    })
  },

  // --- USE OF MEDICINE (4 Materials) ---
  {
    id: "G7-HE-UM-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Proper Use of Medicine,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Medicine is used to prevent, treat, or cure diseases. Which of the following is the correct practice for taking prescribed medication safely?,
      options: [
        "Following the doctor's instructions regarding dosage, timing, and duration; never sharing prescription medication; and reporting any side effects to a healthcare professional.,
        Taking the medicine only when symptoms appear, regardless of the schedule prescribed.",
        "Sharing medication with friends and family who have similar symptoms.,
        Increasing the dose to recover faster without consulting a doctor."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Following the doctor's instructions regarding dosage, timing, and duration; never sharing prescription medication; and reporting any side effects to a healthcare professional.
    })
  },
  {
    id: G7-HE-UM-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Over-the-Counter Medications",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Over-the-counter (OTC) medications are medicines that can be purchased without a prescription. What safety precautions should be taken when using OTC medications?,
      options: [
        Reading the label carefully, following dosage instructions, checking expiry dates, and consulting a pharmacist if unsure about the medication.,
        Taking any OTC medication available regardless of symptoms.,
        Ignoring expiry dates and using medication that has been stored for years.",
        "Taking more than the recommended dose to get faster relief.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reading the label carefully, following dosage instructions, checking expiry dates, and consulting a pharmacist if unsure about the medication."
    })
  },
  {
    id: "G7-HE-UM-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Drug Abuse Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Drug abuse is the harmful use of substances that can lead to addiction, health problems, and social issues. Which of the following is the most effective way to prevent drug abuse among adolescents?,
      options: [
        "Education about the dangers of drug use, developing healthy coping skills, building strong support networks, and engaging in positive extracurricular activities.,
        Encouraging adolescents to try drugs to satisfy their curiosity.",
        "Ignoring the issue and not discussing drugs with young people.,
        Allowing adolescents to make their own choices without guidance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Education about the dangers of drug use, developing healthy coping skills, building strong support networks, and engaging in positive extracurricular activities.
    })
  },
  {
    id: G7-HE-UM-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Substance Abuse",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Substance abuse can cause serious physical, mental, and social harm. Which of the following substances is a common legal substance that is misused and can lead to addiction?,
      options: [
        Alcohol, which when consumed excessively can lead to liver damage, impaired judgment, addiction, and negative social consequences.,
        Fruits and vegetables, which are healthy foods.,
        Water, which is essential for life.",
        "Prescribed medications used correctly under medical supervision.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Alcohol, which when consumed excessively can lead to liver damage, impaired judgment, addiction, and negative social consequences."
    })
  },

  // --- FIRST AID AND BASIC LIFE SUPPORT (4 Materials) ---
  {
    id: "G7-HE-FA-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Introduction to First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who has been injured or suddenly becomes ill before professional medical help arrives. What is the first step to take when providing first aid in an emergency?,
      options: [
        Assess the situation for safety, check the person's responsiveness, and call for emergency help immediately if needed.,
        Start treating the injury immediately without assessing the situation.,
        "Move the person to a different location without checking for injuries.,
        Apply medication without knowing what is wrong."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Assess the situation for safety, check the person's responsiveness, and call for emergency help immediately if needed.
    })
  },
  {
    id: G7-HE-FA-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Common Injuries",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Cuts and wounds are common injuries that require proper first aid to prevent infection. What is the correct procedure for treating a minor cut at home?,
      options: [
        Clean the wound with soap and water, apply an antiseptic, cover with a sterile bandage, and seek medical attention if the wound is deep or bleeding heavily.,
        Cover the wound with a dirty cloth without cleaning it.,
        Apply butter or oil to the wound.",
        "Ignore the wound and let it heal on its own without any care.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the wound with soap and water, apply an antiseptic, cover with a sterile bandage, and seek medical attention if the wound is deep or bleeding heavily."
    })
  },
  {
    id: "G7-HE-FA-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Burns and Scalds,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Burns and scalds can cause severe injury and require prompt first aid. What is the immediate first aid treatment for a minor burn?,
      options: [
        Run cool (not cold) water over the burn for 10-15 minutes, cover it with a sterile non-stick dressing, and seek medical help for severe burns.,
        Apply ice directly to the burn to cool it down.,
        "Apply butter, oil, or toothpaste to the burned area.,
        Pop any blisters that form on the burn."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool (not cold) water over the burn for 10-15 minutes, cover it with a sterile non-stick dressing, and seek medical help for severe burns.
    })
  },
  {
    id: G7-HE-FA-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Choking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Choking occurs when the airway is blocked, preventing breathing. What is the correct first aid procedure to assist a conscious person who is choking?,
      options: [
        Perform the Heimlich maneuver (abdominal thrusts) by standing behind the person and applying inward and upward pressure to the abdomen to dislodge the object.,
        Slap the person hard on the back to dislodge the object.,
        Give the person water to drink to wash down the object.",
        "Lay the person down and wait for the object to pass.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Perform the Heimlich maneuver (abdominal thrusts) by standing behind the person and applying inward and upward pressure to the abdomen to dislodge the object."
    })
  },

  // --- ENVIRONMENTAL HEALTH AND SANITATION (4 Materials) ---
  {
    id: "G7-HE-EH-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Home Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Home sanitation is essential for preventing the spread of diseases and maintaining a healthy living environment. Which of the following practices is most important for maintaining sanitation at home?,
      options: [
        Regularly cleaning the house, proper waste disposal, keeping the kitchen and bathroom hygienic, and ensuring proper ventilation.,
        Cleaning the house only when it becomes visibly dirty.,
        "Leaving garbage inside the house until it piles up.,
        Ignoring hygiene in the kitchen and bathroom."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regularly cleaning the house, proper waste disposal, keeping the kitchen and bathroom hygienic, and ensuring proper ventilation.
    })
  },
  {
    id: G7-HE-EH-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Waste Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Proper waste management is crucial for preventing pollution and disease transmission. Which of the following is the correct way to dispose of household waste to protect the environment and community health?,
      options: [
        Separating waste into biodegradable and non-biodegradable categories, using designated disposal points, and ensuring hazardous waste is handled safely.,
        Burning all waste in the backyard.,
        Dumping waste in rivers and streams.",
        "Burying all waste in the garden without sorting.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Separating waste into biodegradable and non-biodegradable categories, using designated disposal points, and ensuring hazardous waste is handled safely."
    })
  },
  {
    id: "G7-HE-EH-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Water and Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Access to safe drinking water is essential for preventing waterborne diseases. What is the recommended method for purifying water in areas where the water supply may be contaminated?,
      options: [
        Boiling water for at least one minute, using water purification tablets, or filtering water through a reliable water filter to remove pathogens.,
        Adding sugar to water to kill bacteria.,
        "Allowing water to stand for a few days before drinking.,
        Using water directly from the source without treatment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiling water for at least one minute, using water purification tablets, or filtering water through a reliable water filter to remove pathogens.
    })
  },
  {
    id: G7-HE-EH-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Pollution Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Pollution has harmful effects on human health and the environment. Which of the following actions can individuals take to reduce air pollution in their community?,
      options: [
        Using public transportation or walking instead of private cars, avoiding burning waste, planting trees, and using clean energy sources.,
        Burning garbage and leaves in the backyard.,
        Leaving car engines running unnecessarily.",
        "Using fuels such as kerosene indoors without ventilation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using public transportation or walking instead of private cars, avoiding burning waste, planting trees, and using clean energy sources."
    })
  },

  // --- PHYSICAL ACTIVITY AND FITNESS (3 Materials) ---
  {
    id: "G7-HE-PA-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Physical Activity and Fitness",
    subtopic: "Importance of Exercise,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular physical activity is essential for maintaining good health and preventing lifestyle diseases. What is the recommended minimum amount of physical activity for adolescents to maintain good health?,
      options: [
        At least 60 minutes of moderate-to-vigorous physical activity daily, including activities that strengthen bones and muscles.,
        At least 30 minutes of physical activity once a week.,
        "Physical activity is not important for adolescents.,
        Only 15 minutes of physical activity per day."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "At least 60 minutes of moderate-to-vigorous physical activity daily, including activities that strengthen bones and muscles.
    })
  },
  {
    id: G7-HE-PA-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Physical Activity and Fitness,
    subtopic: "Components of Fitness",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Physical fitness includes various components that contribute to overall health and well-being. Which of the following components of fitness refers to the ability of the heart, lungs, and blood vessels to deliver oxygen to working muscles during sustained activity?,
      options: [
        Cardiorespiratory endurance, which is the ability of the cardiovascular and respiratory systems to sustain prolonged exercise.,
        Muscular strength, which is the maximum force a muscle can exert.,
        Flexibility, which is the range of motion around a joint.",
        "Body composition, which is the proportion of fat and fat-free mass in the body.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cardiorespiratory endurance, which is the ability of the cardiovascular and respiratory systems to sustain prolonged exercise."
    })
  },
  {
    id: "G7-HE-PA-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Physical Activity and Fitness",
    subtopic: "Benefits of Exercise,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular exercise provides numerous physical and mental health benefits. Which of the following is a mental health benefit of regular physical activity?,
      options: [
        Regular physical activity reduces stress, anxiety, and depression; improves mood; and enhances cognitive function and self-esteem.,
        Physical activity only benefits physical health, not mental health.,
        "Physical activity increases stress and anxiety levels.,
        Physical activity has no effect on mood or mental well-being."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular physical activity reduces stress, anxiety, and depression; improves mood; and enhances cognitive function and self-esteem.
    })
  },

  // --- SAFETY AND INJURY PREVENTION (2 Materials) ---
  {
    id: G7-HE-SI-01",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Safety and Injury Prevention,
    subtopic: "Personal Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Personal safety involves taking precautions to prevent harm and injury. Which of the following is the most important safety practice when walking alone in an unfamiliar area?,
      options: [
        Being aware of your surroundings, avoiding isolated areas, informing someone of your route, and avoiding distractions such as using headphones or phones.,
        Wearing earphones and not paying attention to surroundings.,
        Walking through isolated areas as shortcuts.",
        "Ignoring safety concerns and walking anywhere at any time.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Being aware of your surroundings, avoiding isolated areas, informing someone of your route, and avoiding distractions such as using headphones or phones."
    })
  },
  {
    id: "G7-HE-SI-02",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Safety and Injury Prevention",
    subtopic: "Road Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Road safety is essential for preventing traffic accidents and injuries. Which of the following is the correct road safety practice for pedestrians crossing a road?,
      options: [
        Crossing at designated crosswalks, looking both ways before crossing, waiting for vehicles to stop, and avoiding crossing while using a phone.,
        Crossing the road anywhere without checking for traffic.,
        "Running across the road without looking.,
        Crossing the road while wearing headphones and not paying attention."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crossing at designated crosswalks, looking both ways before crossing, waiting for vehicles to stop, and avoiding crossing while using a phone.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD HEALTH EDUCATION SYLLABUS)
  // =========================================================================

  // --- NUTRITION IN THE LIFECYCLE (5 Materials) ---
  {
    id: G8-HE-NL-01",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Nutrition Across Life Stages",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Nutritional needs vary at different life stages to support growth, development, and health. Which of the following describes the specific nutritional needs of adolescents compared to other age groups?,
      options: [
        Adolescents need increased energy, protein, calcium, and iron to support rapid growth, bone development, and the onset of puberty, with increased physical activity and metabolic demands.,
        Adolescents have lower nutritional needs than children below 5 years.,
        Adolescents need the same nutrients as elderly people.",
        "Adolescents need no additional nutrients beyond what they consumed in childhood.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Adolescents need increased energy, protein, calcium, and iron to support rapid growth, bone development, and the onset of puberty, with increased physical activity and metabolic demands."
    })
  },
  {
    id: "G8-HE-NL-02",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Nutrition in the Lifecycle",
    subtopic: "Maternal and Child Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Good nutrition during pregnancy and early childhood is crucial for the health of the mother and the development of the child. Which of the following nutrients is especially important during pregnancy for fetal brain development and preventing neural tube defects?,
      options: [
        Folic acid (folate), which is essential for neural tube development and preventing birth defects such as spina bifida.,
        Calcium, which is important only for the mother's bones.,
        "Iron, which is needed only in small amounts during pregnancy.,
        Vitamin C, which has no role in fetal development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Folic acid (folate), which is essential for neural tube development and preventing birth defects such as spina bifida.
    })
  },
  {
    id: G8-HE-NL-03",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Lifestyle Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Lifestyle diseases are health conditions that are largely influenced by diet, physical activity, and other lifestyle factors. Which of the following is an example of a lifestyle disease associated with poor diet and physical inactivity?,
      options: [
        Type 2 diabetes, which is associated with obesity, poor diet, and physical inactivity, and can be prevented through healthy lifestyle choices.,
        Malaria, which is caused by a parasite transmitted by mosquitoes.,
        Tuberculosis, which is an infectious disease caused by bacteria.",
        "HIV/AIDS, which is caused by a virus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Type 2 diabetes, which is associated with obesity, poor diet, and physical inactivity, and can be prevented through healthy lifestyle choices."
    })
  },
  {
    id: "G8-HE-NL-04",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Nutrition in the Lifecycle",
    subtopic: "Behavior Change Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Behavior change communication (BCC) is a strategy used to promote healthy behaviors and prevent diseases. Which of the following is an effective approach to communicating nutrition messages to adolescents?,
      options: [
        Using engaging, age-appropriate content, social media platforms, school-based education programs, peer education, and interactive activities to promote healthy eating.,
        Using only formal lectures without any interactive elements.,
        "Ignoring the preferences and learning styles of adolescents.,
        Using complex scientific language that adolescents cannot understand."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using engaging, age-appropriate content, social media platforms, school-based education programs, peer education, and interactive activities to promote healthy eating.
    })
  },
  {
    id: G8-HE-NL-05",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Nutrition Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nutrition education helps individuals make informed food choices and adopt healthy eating habits. Which of the following is an important outcome of effective nutrition education for adolescents?,
      options: [
        Improved understanding of food labels, better food choices, reduced risk of lifestyle diseases, and the ability to plan balanced meals within a budget.,
        Increased consumption of processed and junk foods.,
        Reduced interest in nutrition and health.",
        "Greater reliance on supplements without learning about healthy eating.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Improved understanding of food labels, better food choices, reduced risk of lifestyle diseases, and the ability to plan balanced meals within a budget."
    })
  },

  // --- HUMAN BODY SYSTEMS (4 Materials) ---
  {
    id: "G8-HE-HB-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Diseases of the Digestive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The digestive system can be affected by various diseases and disorders. Which of the following is a common digestive disorder caused by eating contaminated food or drinking unsafe water?,
      options: [
        Gastroenteritis (food poisoning), which is characterized by diarrhea, vomiting, and abdominal pain, and is caused by consuming food or water contaminated with bacteria, viruses, or parasites.,
        Heart disease, which affects the cardiovascular system.,
        "Asthma, which affects the respiratory system.,
        Osteoporosis, which affects the skeletal system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gastroenteritis (food poisoning), which is characterized by diarrhea, vomiting, and abdominal pain, and is caused by consuming food or water contaminated with bacteria, viruses, or parasites.
    })
  },
  {
    id: G8-HE-HB-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Diseases of the Respiratory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The respiratory system is vulnerable to infections and diseases. Which of the following is a chronic respiratory disease characterized by inflammation and narrowing of the airways, often triggered by allergens or environmental factors?,
      options: [
        Asthma, which causes wheezing, shortness of breath, and difficulty breathing, and is managed through medication and avoiding triggers.,
        Tuberculosis, which is caused by bacteria and affects the lungs.,
        Pneumonia, which is an acute infection of the lungs.",
        "Bronchitis, which is an inflammation of the bronchial tubes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Asthma, which causes wheezing, shortness of breath, and difficulty breathing, and is managed through medication and avoiding triggers."
    })
  },
  {
    id: "G8-HE-HB-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Diseases of the Circulatory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The circulatory system can be affected by diseases that increase the risk of heart attacks and strokes. Which of the following is a risk factor for cardiovascular disease?,
      options: [
        High blood pressure (hypertension), which damages blood vessels and increases the workload on the heart, leading to an increased risk of heart disease and stroke.,
        Regular physical exercise, which improves cardiovascular health.,
        "A balanced diet rich in fruits and vegetables.,
        Maintaining a healthy body weight."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "High blood pressure (hypertension), which damages blood vessels and increases the workload on the heart, leading to an increased risk of heart disease and stroke.
    })
  },
  {
    id: G8-HE-HB-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Diseases of the Skeletal System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The skeletal system can be affected by diseases such as osteoporosis. Which of the following practices can help prevent osteoporosis and maintain bone health?,
      options: [
        Consuming adequate calcium and vitamin D, engaging in weight-bearing physical activity, and avoiding smoking and excessive alcohol consumption.,
        Consuming only calcium supplements without vitamin D.,
        Avoiding any physical activity to protect the bones.",
        "Smoking and consuming alcohol regularly.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Consuming adequate calcium and vitamin D, engaging in weight-bearing physical activity, and avoiding smoking and excessive alcohol consumption."
    })
  },

  // --- MENTAL AND EMOTIONAL HEALTH (4 Materials) ---
  {
    id: "G8-HE-ME-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Stress and Coping Mechanisms,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stress is a common experience during adolescence, and developing coping mechanisms is important for mental health. Which of the following is a positive coping mechanism for managing stress?,
      options: [
        Engaging in physical activity, talking to a trusted friend or adult, practicing relaxation techniques such as deep breathing, and maintaining a healthy lifestyle.,
        Using alcohol or drugs to escape from stress.",
        "Bottling up feelings and not talking to anyone.,
        Spending excessive time on social media to avoid problems."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Engaging in physical activity, talking to a trusted friend or adult, practicing relaxation techniques such as deep breathing, and maintaining a healthy lifestyle.
    })
  },
  {
    id: G8-HE-ME-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Emotional Well-Being",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Emotional well-being is an important aspect of mental health that involves understanding and managing emotions. Which of the following practices contributes to positive emotional well-being?,
      options: [
        Practicing gratitude, maintaining positive relationships, engaging in activities that bring joy, and having a sense of purpose and meaning in life.,
        Ignoring emotions and pretending they do not exist.,
        Focusing only on negative experiences and emotions.",
        "Isolating oneself from others.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Practicing gratitude, maintaining positive relationships, engaging in activities that bring joy, and having a sense of purpose and meaning in life."
    })
  },
  {
    id: "G8-HE-ME-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Mental Health Awareness,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Mental health awareness involves recognizing the signs of mental health problems and seeking help. Which of the following is a sign that someone may be experiencing a mental health problem?,
      options: [
        Persistent sadness or low mood, changes in sleep or appetite, withdrawal from social activities, difficulty concentrating, and feelings of hopelessness.,
        Feeling happy and energetic every day without any variation.,
        "Being extremely social and never wanting to be alone.,
        Having occasional bad moods that pass quickly."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Persistent sadness or low mood, changes in sleep or appetite, withdrawal from social activities, difficulty concentrating, and feelings of hopelessness.
    })
  },
  {
    id: G8-HE-ME-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Seeking Help",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Seeking help is an important step in managing mental health problems. Which of the following is the most appropriate course of action for an adolescent who is experiencing persistent mental health difficulties?,
      options: [
        Talking to a trusted adult such as a parent, teacher, or school counselor, and seeking professional help from a mental health specialist.,
        Keeping the problem to oneself and hoping it goes away.,
        Ignoring the problem and pretending everything is fine.",
        "Self-medicating with drugs or alcohol.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Talking to a trusted adult such as a parent, teacher, or school counselor, and seeking professional help from a mental health specialist."
    })
  },

  // --- USE OF MEDICINE (4 Materials) ---
  {
    id: "G8-HE-UM-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Drug and Substance Abuse Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Drug and substance abuse prevention involves educating individuals about the risks of drug use. Which of the following is a common misconception that contributes to drug abuse among adolescents?,
      options: [
        The misconception that drugs are harmless or that 'everyone is doing it,' which leads to experimentation without understanding the serious consequences of drug abuse.,
        The belief that drugs are always dangerous and should never be used.,
        "The understanding that drugs can only be used with a prescription.,
        The belief that alcohol is not a drug."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The misconception that drugs are harmless or that 'everyone is doing it,' which leads to experimentation without understanding the serious consequences of drug abuse.
    })
  },
  {
    id: G8-HE-UM-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Proper Medication Use",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Proper medication use is essential for treatment effectiveness and preventing harm. Which of the following practices should be avoided when taking antibiotics?,
      options: [
        Stopping antibiotics early when symptoms improve instead of completing the prescribed course, as this can lead to antibiotic resistance.,
        Taking the full course of antibiotics as prescribed.,
        Taking antibiotics at the same time each day.",
        "Storing antibiotics in a cool, dry place.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Stopping antibiotics early when symptoms improve instead of completing the prescribed course, as this can lead to antibiotic resistance."
    })
  },
  {
    id: "G8-HE-UM-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Substance Abuse Consequences,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Substance abuse has serious short-term and long-term consequences for health, relationships, and society. Which of the following is a long-term health consequence of tobacco smoking?,
      options: [
        "Chronic obstructive pulmonary disease (COPD), lung cancer, and cardiovascular disease, which are associated with long-term tobacco use.,
        Anxiety and depression only.",
        "Temporary loss of smell and taste.,
        Increased appetite and weight gain."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chronic obstructive pulmonary disease (COPD), lung cancer, and cardiovascular disease, which are associated with long-term tobacco use.
    })
  },
  {
    id: G8-HE-UM-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Refusal Skills",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refusal skills are important for resisting peer pressure to use drugs. Which of the following is an effective refusal skill for saying 'no' to drugs?,
      options: [
        Using the 'broken record' technique (repeating your refusal), suggesting alternative activities, and maintaining assertive body language while saying 'no' firmly.,
        Agreeing to try drugs to avoid disappointing friends.,
        Silently going along with the group without saying anything.",
        "Being aggressive and confrontational when refusing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using the 'broken record' technique (repeating your refusal), suggesting alternative activities, and maintaining assertive body language while saying 'no' firmly."
    })
  },

  // --- FIRST AID AND BASIC LIFE SUPPORT (4 Materials) ---
  {
    id: "G8-HE-FA-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Emergency Response,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Emergency response involves a series of steps to ensure safety and provide effective first aid. What does the 'DRABC' acronym stand for in emergency first aid?,
      options: [
        DRABC stands for Danger, Response, Airway, Breathing, and Circulation - the primary survey steps for assessing and managing an emergency.,
        DRABC stands for Diagnosis, Recovery, Assessment, Breathing, and Care.,
        "DRABC stands for Danger, Recovery, Airway, Breathing, and Circulation.,
        DRABC stands for Delivery, Response, Airway, Breathing, and CPR."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "DRABC stands for Danger, Response, Airway, Breathing, and Circulation - the primary survey steps for assessing and managing an emergency.
    })
  },
  {
    id: G8-HE-FA-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Cardiopulmonary Resuscitation (CPR)",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Cardiopulmonary resuscitation (CPR) is a life-saving technique used in emergencies when someone's heart has stopped. For a child, what is the recommended ratio of chest compressions to rescue breaths during one-person CPR?,
      options: [
        The recommended ratio is 30 compressions to 2 breaths for all ages, including children and adults, when performed by a single rescuer.,
        The recommended ratio is 15 compressions to 2 breaths for children.,
        The recommended ratio is 5 compressions to 1 breath for children.",
        "The recommended ratio is 100 compressions to 5 breaths for children.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The recommended ratio is 30 compressions to 2 breaths for all ages, including children and adults, when performed by a single rescuer."
    })
  },
  {
    id: "G8-HE-FA-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Fracture Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Fractures are common injuries that require proper immobilization to prevent further damage. What is the correct first aid procedure for a suspected fracture?,
      options: [
        Immobilize the injured area using a splint, apply ice to reduce swelling, and seek medical attention without moving the person unnecessarily.,
        Move the injured area to test if it is really broken.,
        "Apply heat to the injury to reduce swelling.,
        Try to push the bone back into place."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Immobilize the injured area using a splint, apply ice to reduce swelling, and seek medical attention without moving the person unnecessarily.
    })
  },
  {
    id: G8-HE-FA-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "First Aid Kits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A first aid kit is essential for responding to emergencies. Which of the following items is essential to include in a basic first aid kit?,
      options: [
        Sterile bandages and dressings, adhesive tape, scissors, tweezers, antiseptic solution, pain relievers, and disposable gloves.,
        Only bandages without any other supplies.,
        A stethoscope and blood pressure monitor.",
        "Surgical instruments that require professional training to use.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sterile bandages and dressings, adhesive tape, scissors, tweezers, antiseptic solution, pain relievers, and disposable gloves."
    })
  },

  // --- ENVIRONMENTAL HEALTH AND SANITATION (4 Materials) ---
  {
    id: "G8-HE-EH-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Community Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Community sanitation involves collective efforts to maintain a clean and healthy environment. Which of the following community actions is most important for preventing the spread of infectious diseases?,
      options: [
        Ensuring proper disposal of human waste (sanitation), safe drinking water, and community waste management systems.,
        Individual hygiene practices only, without considering the community.,
        "Building more roads and infrastructure without sanitation facilities.,
        Focusing only on school sanitation without community involvement."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ensuring proper disposal of human waste (sanitation), safe drinking water, and community waste management systems.
    })
  },
  {
    id: G8-HE-EH-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Pollution Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Water pollution is a serious environmental health issue that affects communities. Which of the following is a major source of water pollution in Kenyan communities?,
      options: [
        Dumping of untreated sewage and industrial waste into water bodies, agricultural runoff containing fertilizers and pesticides, and improper disposal of solid waste.,
        Rainwater, which is naturally polluted.,
        Water that is used for swimming and recreation.",
        "Water that is consumed by animals.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dumping of untreated sewage and industrial waste into water bodies, agricultural runoff containing fertilizers and pesticides, and improper disposal of solid waste."
    })
  },
  {
    id: "G8-HE-EH-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Environmental Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Environmental conservation is important for health and sustainable development. Which of the following activities contributes to environmental conservation?,
      options: [
        Planting trees, protecting water catchments, reducing waste, recycling materials, and using sustainable resources.,
        Clearing forests to create more agricultural land.,
        "Burning waste to reduce its volume.,
        Using pesticides excessively to increase agricultural yields."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Planting trees, protecting water catchments, reducing waste, recycling materials, and using sustainable resources.
    })
  },
  {
    id: G8-HE-EH-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Vector Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vector control is essential for preventing diseases such as malaria and dengue fever. Which of the following is the most effective strategy for controlling mosquito vectors?,
      options: [
        Eliminating standing water where mosquitoes breed, using insecticide-treated nets, indoor residual spraying, and environmental management.,
        Using mosquito repellent only without any other measures.,
        Ignoring the presence of stagnant water around the home.",
        "Using untreated nets without insecticide.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Eliminating standing water where mosquitoes breed, using insecticide-treated nets, indoor residual spraying, and environmental management."
    })
  },

  // --- REPRODUCTIVE HEALTH (3 Materials) ---
  {
    id: "G8-HE-RH-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Reproductive Health",
    subtopic: "Puberty and Adolescence,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Puberty is a period of physical and emotional changes that occur during adolescence. Which of the following changes occurs in females during puberty?,
      options: [
        Breast development, growth of pubic hair, onset of menstruation, widening of hips, and increased height and weight.,
        Facial hair growth and deepening of the voice.,
        "Decrease in height and weight.,
        No significant physical changes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Breast development, growth of pubic hair, onset of menstruation, widening of hips, and increased height and weight.
    })
  },
  {
    id: G8-HE-RH-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Reproductive Health,
    subtopic: "Reproductive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The reproductive system is responsible for producing gametes and facilitating reproduction. Which of the following correctly describes the function of the ovaries in the female reproductive system?,
      options: [
        The ovaries produce eggs (ova) and secrete female sex hormones (estrogen and progesterone) that regulate the menstrual cycle and support pregnancy.,
        The ovaries produce sperm cells and testosterone.,
        The ovaries store urine and release it from the body.",
        "The ovaries are responsible for digestion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The ovaries produce eggs (ova) and secrete female sex hormones (estrogen and progesterone) that regulate the menstrual cycle and support pregnancy."
    })
  },
  {
    id: "G8-HE-RH-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Reproductive Health",
    subtopic: "Personal Responsibility,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Personal responsibility is important for reproductive health and preventing sexually transmitted infections (STIs). Which of the following is a responsible behavior for protecting reproductive health?,
      options: [
        Abstaining from sexual activity, using condoms consistently and correctly, getting regular health check-ups, and staying informed about sexual and reproductive health.,
        Engaging in sexual activity without protection.,
        "Avoiding any health education or information.,
        Refusing to discuss reproductive health issues with anyone."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Abstaining from sexual activity, using condoms consistently and correctly, getting regular health check-ups, and staying informed about sexual and reproductive health.
    })
  },

  // --- LIFESTYLE DISEASES (3 Materials) ---
  {
    id: G8-HE-LD-01",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Lifestyle Diseases,
    subtopic: "Non-Communicable Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Non-communicable diseases (NCDs) are chronic conditions not caused by infectious agents. Which of the following is an example of a non-communicable disease that is associated with lifestyle factors?,
      options: [
        Heart disease, which is associated with poor diet, physical inactivity, smoking, and excessive alcohol consumption.,
        Tuberculosis, which is caused by bacteria.,
        Malaria, which is caused by parasites.",
        "Cholera, which is caused by contaminated water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Heart disease, which is associated with poor diet, physical inactivity, smoking, and excessive alcohol consumption."
    })
  },
  {
    id: "G8-HE-LD-02",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Lifestyle Diseases",
    subtopic: "Prevention of Lifestyle Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Lifestyle diseases can be prevented through healthy lifestyle choices. Which of the following is the most effective way to reduce the risk of type 2 diabetes?,
      options: [
        Maintaining a healthy weight through balanced nutrition and regular physical activity, avoiding sugary foods and drinks, and monitoring blood sugar levels.,
        Eating large amounts of sugar to build tolerance.,
        "Avoiding exercise to save energy.,
        Smoking cigarettes to reduce appetite."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintaining a healthy weight through balanced nutrition and regular physical activity, avoiding sugary foods and drinks, and monitoring blood sugar levels.
    })
  },
  {
    id: G8-HE-LD-03",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Lifestyle Diseases,
    subtopic: "Management of Chronic Conditions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Managing chronic conditions such as diabetes and hypertension requires lifestyle changes and medical care. What is the recommended dietary approach for a person with hypertension?,
      options: [
        Reducing salt (sodium) intake, eating more fruits and vegetables, reducing alcohol consumption, and maintaining a healthy weight.,
        Eating a high-salt diet to maintain blood pressure.,
        Consuming large amounts of caffeine.",
        "Ignoring dietary changes and only taking medication.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reducing salt (sodium) intake, eating more fruits and vegetables, reducing alcohol consumption, and maintaining a healthy weight."
    })
  },

  // --- HEALTH PROMOTION (4 Materials) ---
  {
    id: "G8-HE-HP-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Health Promotion",
    subtopic: "Community Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Community health involves the well-being of a population and the collective efforts to maintain it. Which of the following is an example of a community-level health promotion activity?,
      options: [
        Organizing health awareness campaigns, promoting vaccination, encouraging regular health check-ups, and improving access to clean water and sanitation.,
        Individual lifestyle changes without community involvement.,
        "Only treating sick individuals without prevention.,
        Building hospitals without addressing social determinants of health."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organizing health awareness campaigns, promoting vaccination, encouraging regular health check-ups, and improving access to clean water and sanitation.
    })
  },
  {
    id: G8-HE-HP-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Health Promotion,
    subtopic: "Health Advocacy",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Health advocacy involves speaking up for health rights and promoting policies that improve health. Which of the following is an effective way for adolescents to advocate for better health in their community?,
      options: [
        Participating in community health meetings, writing to local leaders, using social media to raise awareness, and organizing health education activities in school.,
        Avoiding any involvement in health issues.,
        Complaining without taking any action.",
        "Waiting for adults to address all health problems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Participating in community health meetings, writing to local leaders, using social media to raise awareness, and organizing health education activities in school."
    })
  },
  {
    id: "G8-HE-HP-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Health Promotion",
    subtopic: "Health-Seeking Behavior,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Health-seeking behavior involves recognizing symptoms and taking appropriate action. Which of the following demonstrates appropriate health-seeking behavior?,
      options: [
        Visiting a health professional when experiencing persistent symptoms, following prescribed treatment, and seeking preventive health services such as regular check-ups.,
        Ignoring symptoms and hoping they go away.,
        "Self-medicating without professional advice.,
        Delaying seeking care until the condition is severe."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Visiting a health professional when experiencing persistent symptoms, following prescribed treatment, and seeking preventive health services such as regular check-ups.
    })
  },
  {
    id: G8-HE-HP-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Health Promotion,
    subtopic: "School Health Programs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " School health programs play an important role in promoting the health of learners. Which of the following is a component of a comprehensive school health program?,
      options: [
        Health education, provision of healthy school meals, physical education, access to health services, and a safe and supportive school environment.,
        Only health education without any physical activity components.,
        Only health services without education.",
        "Only physical education without health education.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Health education, provision of healthy school meals, physical education, access to health services, and a safe and supportive school environment."
    })
  }`nexport const healthEducationTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD HEALTH EDUCATION SYLLABUS)
  // =========================================================================
  {
    id: "G7-HE-HN-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Introduction to Nutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Nutrition is the process by which the body takes in and uses food for growth, energy, and maintenance of health. Which of the following is the best definition of nutrition according to health education principles?,
      options: [
        "Nutrition is the study of how food affects the body and how the body uses food to grow, repair itself, and maintain health.,
        Nutrition is the process of eating food only when hungry.",
        "Nutrition is the study of cooking methods and food preparation.,
        Nutrition is the process of eliminating waste from the body."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Nutrition is the study of how food affects the body and how the body uses food to grow, repair itself, and maintain health.
    })
  },
  {
    id: G7-HE-HN-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Health and Nutrition,
    subtopic: "Food Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A balanced diet is essential for good health and requires foods from all food groups in the correct proportions. Which of the following foods belongs to the body-building food group and why is it important?,
      options: [
        Beans and meat, which are rich in proteins essential for building and repairing body tissues.,
        Bread and rice, which provide energy for the body.,
        Fruits and vegetables, which provide vitamins for immunity.",
        "Butter and cooking oil, which provide fats for energy storage.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Beans and meat, which are rich in proteins essential for building and repairing body tissues."
    })
  },
  {
    id: "G7-HE-HN-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Nutrients and Their Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Different nutrients perform specific functions in the body. What is the primary function of vitamins in the human body, and why are they essential for health?,
      options: [
        Vitamins are essential for regulating body processes, supporting immune function, and maintaining overall health; they cannot be produced in sufficient quantities by the body and must be obtained from food.,
        Vitamins provide energy for daily activities.",
        "Vitamins are used to build muscles and tissues.,
        Vitamins are stored as fat for long-term energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitamins are essential for regulating body processes, supporting immune function, and maintaining overall health; they cannot be produced in sufficient quantities by the body and must be obtained from food.
    })
  },
  {
    id: G7-HE-HN-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Health and Nutrition,
    subtopic: "Malnutrition",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Malnutrition results when the body does not get the right amount of nutrients needed for proper functioning. Which of the following health problems is caused by a deficiency of iron in the diet?,
      options: [
        Iron deficiency leads to anaemia, characterized by fatigue, weakness, and pale skin because the body cannot produce enough red blood cells to carry oxygen.,
        Iron deficiency leads to rickets, which causes weak and soft bones.,
        Iron deficiency leads to scurvy, which causes bleeding gums and joint pain.",
        "Iron deficiency leads to beriberi, which causes nerve and muscle problems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Iron deficiency leads to anaemia, characterized by fatigue, weakness, and pale skin because the body cannot produce enough red blood cells to carry oxygen."
    })
  },
  {
    id: "G7-HE-HN-05",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Health and Nutrition",
    subtopic: "Healthy Eating Habits,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Developing healthy eating habits during adolescence is important for growth and preventing lifestyle diseases. Which of the following practices is the best approach to maintaining a healthy diet?,
      options: [
        Eating regular meals with a variety of foods from all food groups, drinking plenty of water, and limiting processed foods high in sugar, salt, and unhealthy fats.,
        Skipping breakfast to save time and reduce calorie intake.,
        "Eating only fruits and vegetables without any proteins or carbohydrates.,
        Eating large amounts of fried and fatty foods for energy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Eating regular meals with a variety of foods from all food groups, drinking plenty of water, and limiting processed foods high in sugar, salt, and unhealthy fats.
    })
  },
  {
    id: G7-HE-HB-01",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Skeletal System",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The skeletal system provides structure, support, and protection for the body. Which of the following describes the primary functions of the human skeleton in maintaining health?,
      options: [
        The skeleton supports the body, protects vital organs such as the heart and lungs, allows movement, stores minerals, and produces blood cells in the bone marrow.,
        The skeleton is responsible for digesting food and absorbing nutrients.,
        The skeleton pumps blood throughout the body.",
        "The skeleton controls the body's response to stress.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The skeleton supports the body, protects vital organs such as the heart and lungs, allows movement, stores minerals, and produces blood cells in the bone marrow."
    })
  },
  {
    id: "G7-HE-HB-02",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Muscular System,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The muscular system enables movement and maintains posture. Which of the following correctly describes how muscles work in pairs to produce movement?,
      options: [
        Muscles work as antagonistic pairs, where one muscle contracts (agonist) while the other relaxes (antagonist) to produce movement, such as the biceps and triceps in the arm.,
        Muscles work independently without coordination.,
        "All muscles contract and relax at the same time.,
        Muscles do not require energy to function."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Muscles work as antagonistic pairs, where one muscle contracts (agonist) while the other relaxes (antagonist) to produce movement, such as the biceps and triceps in the arm.
    })
  },
  {
    id: G7-HE-HB-03",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Digestive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The digestive system breaks down food into nutrients that can be absorbed into the bloodstream. Which of the following is the correct sequence of organs through which food passes during digestion?,
      options: [
        Mouth → Oesophagus → Stomach → Small intestine → Large intestine → Rectum → Anus.,
        Mouth → Stomach → Oesophagus → Small intestine → Large intestine → Anus.,
        Mouth → Large intestine → Small intestine → Stomach → Oesophagus → Anus.",
        "Mouth → Oesophagus → Large intestine → Stomach → Small intestine → Anus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mouth → Oesophagus → Stomach → Small intestine → Large intestine → Rectum → Anus."
    })
  },
  {
    id: "G7-HE-HB-04",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Respiratory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The respiratory system is responsible for gas exchange between the body and the environment. What is the function of the alveoli in the lungs, and how does their structure support this function?,
      options: [
        Alveoli are tiny air sacs with thin walls and a rich blood supply, where oxygen diffuses into the blood and carbon dioxide diffuses out, facilitating efficient gas exchange.,
        Alveoli produce mucus to trap dust and germs.",
        "Alveoli are responsible for warming and filtering the air we breathe.,
        Alveoli contract and expand to pump air into the lungs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Alveoli are tiny air sacs with thin walls and a rich blood supply, where oxygen diffuses into the blood and carbon dioxide diffuses out, facilitating efficient gas exchange.
    })
  },
  {
    id: G7-HE-HB-05",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Circulatory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The circulatory system transports oxygen, nutrients, hormones, and waste products throughout the body. Which of the following correctly describes the function of the heart and its role in circulation?,
      options: [
        The heart is a muscular organ that pumps blood through the circulatory system. It has four chambers (two atria and two ventricles) that coordinate to ensure efficient circulation of oxygenated and deoxygenated blood.,
        The heart produces red blood cells and platelets.,
        The heart filters waste products from the blood.",
        "The heart stores oxygen for use by the body.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The heart is a muscular organ that pumps blood through the circulatory system. It has four chambers (two atria and two ventricles) that coordinate to ensure efficient circulation of oxygenated and deoxygenated blood."
    })
  },
  {
    id: "G7-HE-ME-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Self-Awareness,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Self-awareness is the ability to recognize and understand one's own emotions, thoughts, and behaviors. Why is self-awareness important for adolescent mental health and well-being?,
      options: [
        "Self-awareness helps adolescents understand their strengths and weaknesses, manage their emotions effectively, make better decisions, and build healthy relationships with others.,
        Self-awareness is only important for adults, not adolescents.",
        "Self-awareness encourages isolation from others.,
        Self-awareness prevents any emotional expression."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Self-awareness helps adolescents understand their strengths and weaknesses, manage their emotions effectively, make better decisions, and build healthy relationships with others.
    })
  },
  {
    id: G7-HE-ME-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Understanding Emotions",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Emotions are natural responses to situations that affect how we feel and behave. Which of the following is a healthy way to cope with feelings of anger and frustration?,
      options: [
        Taking time to calm down, expressing feelings in a constructive way, talking to a trusted person, and using relaxation techniques such as deep breathing.,
        Lashing out at others and breaking things.,
        Bottling up emotions and ignoring them.",
        "Reacting immediately without thinking.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Taking time to calm down, expressing feelings in a constructive way, talking to a trusted person, and using relaxation techniques such as deep breathing."
    })
  },
  {
    id: "G7-HE-ME-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Stress Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stress is the body's response to challenges or demands. Which of the following stress management techniques is most effective for reducing the negative effects of stress on mental and physical health?,
      options: [
        Engaging in regular physical activity, practicing mindfulness and relaxation techniques, maintaining social connections, and ensuring adequate sleep.,
        Ignoring stress and pretending it does not exist.,
        "Using alcohol or drugs to cope with stress.,
        Spending excessive time on social media and screen time."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Engaging in regular physical activity, practicing mindfulness and relaxation techniques, maintaining social connections, and ensuring adequate sleep.
    })
  },
  {
    id: G7-HE-ME-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Building Resilience",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Resilience is the ability to bounce back from difficult situations and challenges. Which of the following factors helps build resilience in adolescents?,
      options: [
        Having supportive relationships with family and friends, developing problem-solving skills, maintaining a positive outlook, and learning from failures and setbacks.,
        Avoiding all challenges and difficult situations.,
        Relying only on oneself without any support.",
        "Giving up easily when faced with challenges.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Having supportive relationships with family and friends, developing problem-solving skills, maintaining a positive outlook, and learning from failures and setbacks."
    })
  },
  {
    id: "G7-HE-PH-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Personal Hygiene",
    subtopic: "Body Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Personal hygiene is essential for preventing the spread of diseases and maintaining good health. What is the recommended practice for maintaining personal cleanliness and preventing body odor?,
      options: [
        Bathing daily with soap and water, wearing clean clothes, and using deodorant or antiperspirant to control body odor.,
        Bathing only once a week to save water.,
        "Wearing dirty clothes and not bathing to develop immunity.,
        Using perfume to cover odor without bathing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Bathing daily with soap and water, wearing clean clothes, and using deodorant or antiperspirant to control body odor.
    })
  },
  {
    id: G7-HE-PH-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Personal Hygiene,
    subtopic: "Dental Hygiene",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Dental hygiene is crucial for preventing tooth decay, gum disease, and bad breath. Which of the following is the most effective daily dental hygiene practice recommended by health professionals?,
      options: [
        Brushing teeth twice a day (morning and before bed) with fluoride toothpaste, flossing daily, and visiting the dentist regularly for check-ups.,
        Brushing teeth only once a week.,
        Using a toothpick to clean between teeth instead of flossing.",
        "Rinsing the mouth with water only without brushing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Brushing teeth twice a day (morning and before bed) with fluoride toothpaste, flossing daily, and visiting the dentist regularly for check-ups."
    })
  },
  {
    id: "G7-HE-PH-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Personal Hygiene",
    subtopic: "Skin Care,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Skin care is important for preventing acne, infections, and maintaining healthy skin. What is the recommended daily skin care routine for adolescents to maintain healthy skin?,
      options: [
        "Washing the face twice daily with a gentle cleanser, moisturizing, using sunscreen, and avoiding touching the face with dirty hands.,
        Washing the face only when it feels oily.",
        "Using harsh soaps and scrubbing the skin vigorously.,
        Popping pimples to make them go away faster."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Washing the face twice daily with a gentle cleanser, moisturizing, using sunscreen, and avoiding touching the face with dirty hands.
    })
  },
  {
    id: G7-HE-PH-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Personal Hygiene,
    subtopic: "Grooming",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Good grooming involves caring for the skin, hair, and nails to maintain a neat and healthy appearance. Which of the following grooming practices is important for preventing nail infections?,
      options: [
        Keeping nails clean and trimmed, avoiding biting nails, and ensuring nails are dry and clean to prevent fungal and bacterial infections.,
        Biting nails to keep them short.,
        Ignoring nail hygiene and allowing them to grow long and dirty.",
        "Covering nails with artificial nails without cleaning underneath.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Keeping nails clean and trimmed, avoiding biting nails, and ensuring nails are dry and clean to prevent fungal and bacterial infections."
    })
  },
  {
    id: "G7-HE-UM-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Proper Use of Medicine,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Medicine is used to prevent, treat, or cure diseases. Which of the following is the correct practice for taking prescribed medication safely?,
      options: [
        "Following the doctor's instructions regarding dosage, timing, and duration; never sharing prescription medication; and reporting any side effects to a healthcare professional.,
        Taking the medicine only when symptoms appear, regardless of the schedule prescribed.",
        "Sharing medication with friends and family who have similar symptoms.,
        Increasing the dose to recover faster without consulting a doctor."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Following the doctor's instructions regarding dosage, timing, and duration; never sharing prescription medication; and reporting any side effects to a healthcare professional.
    })
  },
  {
    id: G7-HE-UM-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Over-the-Counter Medications",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Over-the-counter (OTC) medications are medicines that can be purchased without a prescription. What safety precautions should be taken when using OTC medications?,
      options: [
        Reading the label carefully, following dosage instructions, checking expiry dates, and consulting a pharmacist if unsure about the medication.,
        Taking any OTC medication available regardless of symptoms.,
        Ignoring expiry dates and using medication that has been stored for years.",
        "Taking more than the recommended dose to get faster relief.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reading the label carefully, following dosage instructions, checking expiry dates, and consulting a pharmacist if unsure about the medication."
    })
  },
  {
    id: "G7-HE-UM-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Drug Abuse Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Drug abuse is the harmful use of substances that can lead to addiction, health problems, and social issues. Which of the following is the most effective way to prevent drug abuse among adolescents?,
      options: [
        "Education about the dangers of drug use, developing healthy coping skills, building strong support networks, and engaging in positive extracurricular activities.,
        Encouraging adolescents to try drugs to satisfy their curiosity.",
        "Ignoring the issue and not discussing drugs with young people.,
        Allowing adolescents to make their own choices without guidance."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Education about the dangers of drug use, developing healthy coping skills, building strong support networks, and engaging in positive extracurricular activities.
    })
  },
  {
    id: G7-HE-UM-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Substance Abuse",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Substance abuse can cause serious physical, mental, and social harm. Which of the following substances is a common legal substance that is misused and can lead to addiction?,
      options: [
        Alcohol, which when consumed excessively can lead to liver damage, impaired judgment, addiction, and negative social consequences.,
        Fruits and vegetables, which are healthy foods.,
        Water, which is essential for life.",
        "Prescribed medications used correctly under medical supervision.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Alcohol, which when consumed excessively can lead to liver damage, impaired judgment, addiction, and negative social consequences."
    })
  },
  {
    id: "G7-HE-FA-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Introduction to First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "First aid is the immediate care given to a person who has been injured or suddenly becomes ill before professional medical help arrives. What is the first step to take when providing first aid in an emergency?,
      options: [
        Assess the situation for safety, check the person's responsiveness, and call for emergency help immediately if needed.,
        Start treating the injury immediately without assessing the situation.,
        "Move the person to a different location without checking for injuries.,
        Apply medication without knowing what is wrong."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Assess the situation for safety, check the person's responsiveness, and call for emergency help immediately if needed.
    })
  },
  {
    id: G7-HE-FA-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Common Injuries",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Cuts and wounds are common injuries that require proper first aid to prevent infection. What is the correct procedure for treating a minor cut at home?,
      options: [
        Clean the wound with soap and water, apply an antiseptic, cover with a sterile bandage, and seek medical attention if the wound is deep or bleeding heavily.,
        Cover the wound with a dirty cloth without cleaning it.,
        Apply butter or oil to the wound.",
        "Ignore the wound and let it heal on its own without any care.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Clean the wound with soap and water, apply an antiseptic, cover with a sterile bandage, and seek medical attention if the wound is deep or bleeding heavily."
    })
  },
  {
    id: "G7-HE-FA-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Burns and Scalds,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Burns and scalds can cause severe injury and require prompt first aid. What is the immediate first aid treatment for a minor burn?,
      options: [
        Run cool (not cold) water over the burn for 10-15 minutes, cover it with a sterile non-stick dressing, and seek medical help for severe burns.,
        Apply ice directly to the burn to cool it down.,
        "Apply butter, oil, or toothpaste to the burned area.,
        Pop any blisters that form on the burn."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Run cool (not cold) water over the burn for 10-15 minutes, cover it with a sterile non-stick dressing, and seek medical help for severe burns.
    })
  },
  {
    id: G7-HE-FA-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Choking",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Choking occurs when the airway is blocked, preventing breathing. What is the correct first aid procedure to assist a conscious person who is choking?,
      options: [
        Perform the Heimlich maneuver (abdominal thrusts) by standing behind the person and applying inward and upward pressure to the abdomen to dislodge the object.,
        Slap the person hard on the back to dislodge the object.,
        Give the person water to drink to wash down the object.",
        "Lay the person down and wait for the object to pass.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Perform the Heimlich maneuver (abdominal thrusts) by standing behind the person and applying inward and upward pressure to the abdomen to dislodge the object."
    })
  },
  {
    id: "G7-HE-EH-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Home Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Home sanitation is essential for preventing the spread of diseases and maintaining a healthy living environment. Which of the following practices is most important for maintaining sanitation at home?,
      options: [
        Regularly cleaning the house, proper waste disposal, keeping the kitchen and bathroom hygienic, and ensuring proper ventilation.,
        Cleaning the house only when it becomes visibly dirty.,
        "Leaving garbage inside the house until it piles up.,
        Ignoring hygiene in the kitchen and bathroom."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regularly cleaning the house, proper waste disposal, keeping the kitchen and bathroom hygienic, and ensuring proper ventilation.
    })
  },
  {
    id: G7-HE-EH-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Waste Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Proper waste management is crucial for preventing pollution and disease transmission. Which of the following is the correct way to dispose of household waste to protect the environment and community health?,
      options: [
        Separating waste into biodegradable and non-biodegradable categories, using designated disposal points, and ensuring hazardous waste is handled safely.,
        Burning all waste in the backyard.,
        Dumping waste in rivers and streams.",
        "Burying all waste in the garden without sorting.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Separating waste into biodegradable and non-biodegradable categories, using designated disposal points, and ensuring hazardous waste is handled safely."
    })
  },
  {
    id: "G7-HE-EH-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Water and Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Access to safe drinking water is essential for preventing waterborne diseases. What is the recommended method for purifying water in areas where the water supply may be contaminated?,
      options: [
        Boiling water for at least one minute, using water purification tablets, or filtering water through a reliable water filter to remove pathogens.,
        Adding sugar to water to kill bacteria.,
        "Allowing water to stand for a few days before drinking.,
        Using water directly from the source without treatment."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiling water for at least one minute, using water purification tablets, or filtering water through a reliable water filter to remove pathogens.
    })
  },
  {
    id: G7-HE-EH-04",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Pollution Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Pollution has harmful effects on human health and the environment. Which of the following actions can individuals take to reduce air pollution in their community?,
      options: [
        Using public transportation or walking instead of private cars, avoiding burning waste, planting trees, and using clean energy sources.,
        Burning garbage and leaves in the backyard.,
        Leaving car engines running unnecessarily.",
        "Using fuels such as kerosene indoors without ventilation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using public transportation or walking instead of private cars, avoiding burning waste, planting trees, and using clean energy sources."
    })
  },
  {
    id: "G7-HE-PA-01",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Physical Activity and Fitness",
    subtopic: "Importance of Exercise,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular physical activity is essential for maintaining good health and preventing lifestyle diseases. What is the recommended minimum amount of physical activity for adolescents to maintain good health?,
      options: [
        At least 60 minutes of moderate-to-vigorous physical activity daily, including activities that strengthen bones and muscles.,
        At least 30 minutes of physical activity once a week.,
        "Physical activity is not important for adolescents.,
        Only 15 minutes of physical activity per day."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "At least 60 minutes of moderate-to-vigorous physical activity daily, including activities that strengthen bones and muscles.
    })
  },
  {
    id: G7-HE-PA-02",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Physical Activity and Fitness,
    subtopic: "Components of Fitness",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Physical fitness includes various components that contribute to overall health and well-being. Which of the following components of fitness refers to the ability of the heart, lungs, and blood vessels to deliver oxygen to working muscles during sustained activity?,
      options: [
        Cardiorespiratory endurance, which is the ability of the cardiovascular and respiratory systems to sustain prolonged exercise.,
        Muscular strength, which is the maximum force a muscle can exert.,
        Flexibility, which is the range of motion around a joint.",
        "Body composition, which is the proportion of fat and fat-free mass in the body.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cardiorespiratory endurance, which is the ability of the cardiovascular and respiratory systems to sustain prolonged exercise."
    })
  },
  {
    id: "G7-HE-PA-03",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Physical Activity and Fitness",
    subtopic: "Benefits of Exercise,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Regular exercise provides numerous physical and mental health benefits. Which of the following is a mental health benefit of regular physical activity?,
      options: [
        Regular physical activity reduces stress, anxiety, and depression; improves mood; and enhances cognitive function and self-esteem.,
        Physical activity only benefits physical health, not mental health.,
        "Physical activity increases stress and anxiety levels.,
        Physical activity has no effect on mood or mental well-being."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular physical activity reduces stress, anxiety, and depression; improves mood; and enhances cognitive function and self-esteem.
    })
  },
  {
    id: G7-HE-SI-01",
    grade: "Grade 7,
    subject: Health Education",
    topic: "Safety and Injury Prevention,
    subtopic: "Personal Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Personal safety involves taking precautions to prevent harm and injury. Which of the following is the most important safety practice when walking alone in an unfamiliar area?,
      options: [
        Being aware of your surroundings, avoiding isolated areas, informing someone of your route, and avoiding distractions such as using headphones or phones.,
        Wearing earphones and not paying attention to surroundings.,
        Walking through isolated areas as shortcuts.",
        "Ignoring safety concerns and walking anywhere at any time.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Being aware of your surroundings, avoiding isolated areas, informing someone of your route, and avoiding distractions such as using headphones or phones."
    })
  },
  {
    id: "G7-HE-SI-02",
    grade: "Grade 7",
    subject: "Health Education",
    topic: "Safety and Injury Prevention",
    subtopic: "Road Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Road safety is essential for preventing traffic accidents and injuries. Which of the following is the correct road safety practice for pedestrians crossing a road?,
      options: [
        Crossing at designated crosswalks, looking both ways before crossing, waiting for vehicles to stop, and avoiding crossing while using a phone.,
        Crossing the road anywhere without checking for traffic.,
        "Running across the road without looking.,
        Crossing the road while wearing headphones and not paying attention."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Crossing at designated crosswalks, looking both ways before crossing, waiting for vehicles to stop, and avoiding crossing while using a phone.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD HEALTH EDUCATION SYLLABUS)
  // =========================================================================
  {
    id: G8-HE-NL-01",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Nutrition Across Life Stages",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Nutritional needs vary at different life stages to support growth, development, and health. Which of the following describes the specific nutritional needs of adolescents compared to other age groups?,
      options: [
        Adolescents need increased energy, protein, calcium, and iron to support rapid growth, bone development, and the onset of puberty, with increased physical activity and metabolic demands.,
        Adolescents have lower nutritional needs than children below 5 years.,
        Adolescents need the same nutrients as elderly people.",
        "Adolescents need no additional nutrients beyond what they consumed in childhood.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Adolescents need increased energy, protein, calcium, and iron to support rapid growth, bone development, and the onset of puberty, with increased physical activity and metabolic demands."
    })
  },
  {
    id: "G8-HE-NL-02",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Nutrition in the Lifecycle",
    subtopic: "Maternal and Child Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Good nutrition during pregnancy and early childhood is crucial for the health of the mother and the development of the child. Which of the following nutrients is especially important during pregnancy for fetal brain development and preventing neural tube defects?,
      options: [
        Folic acid (folate), which is essential for neural tube development and preventing birth defects such as spina bifida.,
        Calcium, which is important only for the mother's bones.,
        "Iron, which is needed only in small amounts during pregnancy.,
        Vitamin C, which has no role in fetal development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Folic acid (folate), which is essential for neural tube development and preventing birth defects such as spina bifida.
    })
  },
  {
    id: G8-HE-NL-03",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Lifestyle Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Lifestyle diseases are health conditions that are largely influenced by diet, physical activity, and other lifestyle factors. Which of the following is an example of a lifestyle disease associated with poor diet and physical inactivity?,
      options: [
        Type 2 diabetes, which is associated with obesity, poor diet, and physical inactivity, and can be prevented through healthy lifestyle choices.,
        Malaria, which is caused by a parasite transmitted by mosquitoes.,
        Tuberculosis, which is an infectious disease caused by bacteria.",
        "HIV/AIDS, which is caused by a virus.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Type 2 diabetes, which is associated with obesity, poor diet, and physical inactivity, and can be prevented through healthy lifestyle choices."
    })
  },
  {
    id: "G8-HE-NL-04",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Nutrition in the Lifecycle",
    subtopic: "Behavior Change Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Behavior change communication (BCC) is a strategy used to promote healthy behaviors and prevent diseases. Which of the following is an effective approach to communicating nutrition messages to adolescents?,
      options: [
        Using engaging, age-appropriate content, social media platforms, school-based education programs, peer education, and interactive activities to promote healthy eating.,
        Using only formal lectures without any interactive elements.,
        "Ignoring the preferences and learning styles of adolescents.,
        Using complex scientific language that adolescents cannot understand."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using engaging, age-appropriate content, social media platforms, school-based education programs, peer education, and interactive activities to promote healthy eating.
    })
  },
  {
    id: G8-HE-NL-05",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Nutrition in the Lifecycle,
    subtopic: "Nutrition Education",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nutrition education helps individuals make informed food choices and adopt healthy eating habits. Which of the following is an important outcome of effective nutrition education for adolescents?,
      options: [
        Improved understanding of food labels, better food choices, reduced risk of lifestyle diseases, and the ability to plan balanced meals within a budget.,
        Increased consumption of processed and junk foods.,
        Reduced interest in nutrition and health.",
        "Greater reliance on supplements without learning about healthy eating.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Improved understanding of food labels, better food choices, reduced risk of lifestyle diseases, and the ability to plan balanced meals within a budget."
    })
  },
  {
    id: "G8-HE-HB-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Diseases of the Digestive System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The digestive system can be affected by various diseases and disorders. Which of the following is a common digestive disorder caused by eating contaminated food or drinking unsafe water?,
      options: [
        Gastroenteritis (food poisoning), which is characterized by diarrhea, vomiting, and abdominal pain, and is caused by consuming food or water contaminated with bacteria, viruses, or parasites.,
        Heart disease, which affects the cardiovascular system.,
        "Asthma, which affects the respiratory system.,
        Osteoporosis, which affects the skeletal system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Gastroenteritis (food poisoning), which is characterized by diarrhea, vomiting, and abdominal pain, and is caused by consuming food or water contaminated with bacteria, viruses, or parasites.
    })
  },
  {
    id: G8-HE-HB-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Diseases of the Respiratory System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The respiratory system is vulnerable to infections and diseases. Which of the following is a chronic respiratory disease characterized by inflammation and narrowing of the airways, often triggered by allergens or environmental factors?,
      options: [
        Asthma, which causes wheezing, shortness of breath, and difficulty breathing, and is managed through medication and avoiding triggers.,
        Tuberculosis, which is caused by bacteria and affects the lungs.,
        Pneumonia, which is an acute infection of the lungs.",
        "Bronchitis, which is an inflammation of the bronchial tubes.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Asthma, which causes wheezing, shortness of breath, and difficulty breathing, and is managed through medication and avoiding triggers."
    })
  },
  {
    id: "G8-HE-HB-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Diseases of the Circulatory System,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "The circulatory system can be affected by diseases that increase the risk of heart attacks and strokes. Which of the following is a risk factor for cardiovascular disease?,
      options: [
        High blood pressure (hypertension), which damages blood vessels and increases the workload on the heart, leading to an increased risk of heart disease and stroke.,
        Regular physical exercise, which improves cardiovascular health.,
        "A balanced diet rich in fruits and vegetables.,
        Maintaining a healthy body weight."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "High blood pressure (hypertension), which damages blood vessels and increases the workload on the heart, leading to an increased risk of heart disease and stroke.
    })
  },
  {
    id: G8-HE-HB-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Diseases of the Skeletal System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The skeletal system can be affected by diseases such as osteoporosis. Which of the following practices can help prevent osteoporosis and maintain bone health?,
      options: [
        Consuming adequate calcium and vitamin D, engaging in weight-bearing physical activity, and avoiding smoking and excessive alcohol consumption.,
        Consuming only calcium supplements without vitamin D.,
        Avoiding any physical activity to protect the bones.",
        "Smoking and consuming alcohol regularly.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Consuming adequate calcium and vitamin D, engaging in weight-bearing physical activity, and avoiding smoking and excessive alcohol consumption."
    })
  },
  {
    id: "G8-HE-ME-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Stress and Coping Mechanisms,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Stress is a common experience during adolescence, and developing coping mechanisms is important for mental health. Which of the following is a positive coping mechanism for managing stress?,
      options: [
        Engaging in physical activity, talking to a trusted friend or adult, practicing relaxation techniques such as deep breathing, and maintaining a healthy lifestyle.,
        Using alcohol or drugs to escape from stress.",
        "Bottling up feelings and not talking to anyone.,
        Spending excessive time on social media to avoid problems."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Engaging in physical activity, talking to a trusted friend or adult, practicing relaxation techniques such as deep breathing, and maintaining a healthy lifestyle.
    })
  },
  {
    id: G8-HE-ME-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Emotional Well-Being",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Emotional well-being is an important aspect of mental health that involves understanding and managing emotions. Which of the following practices contributes to positive emotional well-being?,
      options: [
        Practicing gratitude, maintaining positive relationships, engaging in activities that bring joy, and having a sense of purpose and meaning in life.,
        Ignoring emotions and pretending they do not exist.,
        Focusing only on negative experiences and emotions.",
        "Isolating oneself from others.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Practicing gratitude, maintaining positive relationships, engaging in activities that bring joy, and having a sense of purpose and meaning in life."
    })
  },
  {
    id: "G8-HE-ME-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Mental Health Awareness,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Mental health awareness involves recognizing the signs of mental health problems and seeking help. Which of the following is a sign that someone may be experiencing a mental health problem?,
      options: [
        Persistent sadness or low mood, changes in sleep or appetite, withdrawal from social activities, difficulty concentrating, and feelings of hopelessness.,
        Feeling happy and energetic every day without any variation.,
        "Being extremely social and never wanting to be alone.,
        Having occasional bad moods that pass quickly."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Persistent sadness or low mood, changes in sleep or appetite, withdrawal from social activities, difficulty concentrating, and feelings of hopelessness.
    })
  },
  {
    id: G8-HE-ME-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Seeking Help",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Seeking help is an important step in managing mental health problems. Which of the following is the most appropriate course of action for an adolescent who is experiencing persistent mental health difficulties?,
      options: [
        Talking to a trusted adult such as a parent, teacher, or school counselor, and seeking professional help from a mental health specialist.,
        Keeping the problem to oneself and hoping it goes away.,
        Ignoring the problem and pretending everything is fine.",
        "Self-medicating with drugs or alcohol.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Talking to a trusted adult such as a parent, teacher, or school counselor, and seeking professional help from a mental health specialist."
    })
  },
  {
    id: "G8-HE-UM-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Drug and Substance Abuse Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Drug and substance abuse prevention involves educating individuals about the risks of drug use. Which of the following is a common misconception that contributes to drug abuse among adolescents?,
      options: [
        The misconception that drugs are harmless or that 'everyone is doing it,' which leads to experimentation without understanding the serious consequences of drug abuse.,
        The belief that drugs are always dangerous and should never be used.,
        "The understanding that drugs can only be used with a prescription.,
        The belief that alcohol is not a drug."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The misconception that drugs are harmless or that 'everyone is doing it,' which leads to experimentation without understanding the serious consequences of drug abuse.
    })
  },
  {
    id: G8-HE-UM-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Proper Medication Use",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Proper medication use is essential for treatment effectiveness and preventing harm. Which of the following practices should be avoided when taking antibiotics?,
      options: [
        Stopping antibiotics early when symptoms improve instead of completing the prescribed course, as this can lead to antibiotic resistance.,
        Taking the full course of antibiotics as prescribed.,
        Taking antibiotics at the same time each day.",
        "Storing antibiotics in a cool, dry place.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Stopping antibiotics early when symptoms improve instead of completing the prescribed course, as this can lead to antibiotic resistance."
    })
  },
  {
    id: "G8-HE-UM-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Use of Medicine",
    subtopic: "Substance Abuse Consequences,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Substance abuse has serious short-term and long-term consequences for health, relationships, and society. Which of the following is a long-term health consequence of tobacco smoking?,
      options: [
        "Chronic obstructive pulmonary disease (COPD), lung cancer, and cardiovascular disease, which are associated with long-term tobacco use.,
        Anxiety and depression only.",
        "Temporary loss of smell and taste.,
        Increased appetite and weight gain."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Chronic obstructive pulmonary disease (COPD), lung cancer, and cardiovascular disease, which are associated with long-term tobacco use.
    })
  },
  {
    id: G8-HE-UM-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Use of Medicine,
    subtopic: "Refusal Skills",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Refusal skills are important for resisting peer pressure to use drugs. Which of the following is an effective refusal skill for saying 'no' to drugs?,
      options: [
        Using the 'broken record' technique (repeating your refusal), suggesting alternative activities, and maintaining assertive body language while saying 'no' firmly.,
        Agreeing to try drugs to avoid disappointing friends.,
        Silently going along with the group without saying anything.",
        "Being aggressive and confrontational when refusing.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Using the 'broken record' technique (repeating your refusal), suggesting alternative activities, and maintaining assertive body language while saying 'no' firmly."
    })
  },
  {
    id: "G8-HE-FA-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Emergency Response,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Emergency response involves a series of steps to ensure safety and provide effective first aid. What does the 'DRABC' acronym stand for in emergency first aid?,
      options: [
        DRABC stands for Danger, Response, Airway, Breathing, and Circulation - the primary survey steps for assessing and managing an emergency.,
        DRABC stands for Diagnosis, Recovery, Assessment, Breathing, and Care.,
        "DRABC stands for Danger, Recovery, Airway, Breathing, and Circulation.,
        DRABC stands for Delivery, Response, Airway, Breathing, and CPR."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "DRABC stands for Danger, Response, Airway, Breathing, and Circulation - the primary survey steps for assessing and managing an emergency.
    })
  },
  {
    id: G8-HE-FA-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "Cardiopulmonary Resuscitation (CPR)",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Cardiopulmonary resuscitation (CPR) is a life-saving technique used in emergencies when someone's heart has stopped. For a child, what is the recommended ratio of chest compressions to rescue breaths during one-person CPR?,
      options: [
        The recommended ratio is 30 compressions to 2 breaths for all ages, including children and adults, when performed by a single rescuer.,
        The recommended ratio is 15 compressions to 2 breaths for children.,
        The recommended ratio is 5 compressions to 1 breath for children.",
        "The recommended ratio is 100 compressions to 5 breaths for children.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The recommended ratio is 30 compressions to 2 breaths for all ages, including children and adults, when performed by a single rescuer."
    })
  },
  {
    id: "G8-HE-FA-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "First Aid and Basic Life Support",
    subtopic: "Fracture Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Fractures are common injuries that require proper immobilization to prevent further damage. What is the correct first aid procedure for a suspected fracture?,
      options: [
        Immobilize the injured area using a splint, apply ice to reduce swelling, and seek medical attention without moving the person unnecessarily.,
        Move the injured area to test if it is really broken.,
        "Apply heat to the injury to reduce swelling.,
        Try to push the bone back into place."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Immobilize the injured area using a splint, apply ice to reduce swelling, and seek medical attention without moving the person unnecessarily.
    })
  },
  {
    id: G8-HE-FA-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "First Aid and Basic Life Support,
    subtopic: "First Aid Kits",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A first aid kit is essential for responding to emergencies. Which of the following items is essential to include in a basic first aid kit?,
      options: [
        Sterile bandages and dressings, adhesive tape, scissors, tweezers, antiseptic solution, pain relievers, and disposable gloves.,
        Only bandages without any other supplies.,
        A stethoscope and blood pressure monitor.",
        "Surgical instruments that require professional training to use.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sterile bandages and dressings, adhesive tape, scissors, tweezers, antiseptic solution, pain relievers, and disposable gloves."
    })
  },
  {
    id: "G8-HE-EH-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Community Sanitation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Community sanitation involves collective efforts to maintain a clean and healthy environment. Which of the following community actions is most important for preventing the spread of infectious diseases?,
      options: [
        Ensuring proper disposal of human waste (sanitation), safe drinking water, and community waste management systems.,
        Individual hygiene practices only, without considering the community.,
        "Building more roads and infrastructure without sanitation facilities.,
        Focusing only on school sanitation without community involvement."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ensuring proper disposal of human waste (sanitation), safe drinking water, and community waste management systems.
    })
  },
  {
    id: G8-HE-EH-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Pollution Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Water pollution is a serious environmental health issue that affects communities. Which of the following is a major source of water pollution in Kenyan communities?,
      options: [
        Dumping of untreated sewage and industrial waste into water bodies, agricultural runoff containing fertilizers and pesticides, and improper disposal of solid waste.,
        Rainwater, which is naturally polluted.,
        Water that is used for swimming and recreation.",
        "Water that is consumed by animals.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Dumping of untreated sewage and industrial waste into water bodies, agricultural runoff containing fertilizers and pesticides, and improper disposal of solid waste."
    })
  },
  {
    id: "G8-HE-EH-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Environmental Health and Sanitation",
    subtopic: "Environmental Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Environmental conservation is important for health and sustainable development. Which of the following activities contributes to environmental conservation?,
      options: [
        Planting trees, protecting water catchments, reducing waste, recycling materials, and using sustainable resources.,
        Clearing forests to create more agricultural land.,
        "Burning waste to reduce its volume.,
        Using pesticides excessively to increase agricultural yields."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Planting trees, protecting water catchments, reducing waste, recycling materials, and using sustainable resources.
    })
  },
  {
    id: G8-HE-EH-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Environmental Health and Sanitation,
    subtopic: "Vector Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vector control is essential for preventing diseases such as malaria and dengue fever. Which of the following is the most effective strategy for controlling mosquito vectors?,
      options: [
        Eliminating standing water where mosquitoes breed, using insecticide-treated nets, indoor residual spraying, and environmental management.,
        Using mosquito repellent only without any other measures.,
        Ignoring the presence of stagnant water around the home.",
        "Using untreated nets without insecticide.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Eliminating standing water where mosquitoes breed, using insecticide-treated nets, indoor residual spraying, and environmental management."
    })
  },
  {
    id: "G8-HE-RH-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Reproductive Health",
    subtopic: "Puberty and Adolescence,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Puberty is a period of physical and emotional changes that occur during adolescence. Which of the following changes occurs in females during puberty?,
      options: [
        Breast development, growth of pubic hair, onset of menstruation, widening of hips, and increased height and weight.,
        Facial hair growth and deepening of the voice.,
        "Decrease in height and weight.,
        No significant physical changes."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Breast development, growth of pubic hair, onset of menstruation, widening of hips, and increased height and weight.
    })
  },
  {
    id: G8-HE-RH-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Reproductive Health,
    subtopic: "Reproductive System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The reproductive system is responsible for producing gametes and facilitating reproduction. Which of the following correctly describes the function of the ovaries in the female reproductive system?,
      options: [
        The ovaries produce eggs (ova) and secrete female sex hormones (estrogen and progesterone) that regulate the menstrual cycle and support pregnancy.,
        The ovaries produce sperm cells and testosterone.,
        The ovaries store urine and release it from the body.",
        "The ovaries are responsible for digestion.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The ovaries produce eggs (ova) and secrete female sex hormones (estrogen and progesterone) that regulate the menstrual cycle and support pregnancy."
    })
  },
  {
    id: "G8-HE-RH-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Reproductive Health",
    subtopic: "Personal Responsibility,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Personal responsibility is important for reproductive health and preventing sexually transmitted infections (STIs). Which of the following is a responsible behavior for protecting reproductive health?,
      options: [
        Abstaining from sexual activity, using condoms consistently and correctly, getting regular health check-ups, and staying informed about sexual and reproductive health.,
        Engaging in sexual activity without protection.,
        "Avoiding any health education or information.,
        Refusing to discuss reproductive health issues with anyone."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Abstaining from sexual activity, using condoms consistently and correctly, getting regular health check-ups, and staying informed about sexual and reproductive health.
    })
  },
  {
    id: G8-HE-LD-01",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Lifestyle Diseases,
    subtopic: "Non-Communicable Diseases",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Non-communicable diseases (NCDs) are chronic conditions not caused by infectious agents. Which of the following is an example of a non-communicable disease that is associated with lifestyle factors?,
      options: [
        Heart disease, which is associated with poor diet, physical inactivity, smoking, and excessive alcohol consumption.,
        Tuberculosis, which is caused by bacteria.,
        Malaria, which is caused by parasites.",
        "Cholera, which is caused by contaminated water.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Heart disease, which is associated with poor diet, physical inactivity, smoking, and excessive alcohol consumption."
    })
  },
  {
    id: "G8-HE-LD-02",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Lifestyle Diseases",
    subtopic: "Prevention of Lifestyle Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Lifestyle diseases can be prevented through healthy lifestyle choices. Which of the following is the most effective way to reduce the risk of type 2 diabetes?,
      options: [
        Maintaining a healthy weight through balanced nutrition and regular physical activity, avoiding sugary foods and drinks, and monitoring blood sugar levels.,
        Eating large amounts of sugar to build tolerance.,
        "Avoiding exercise to save energy.,
        Smoking cigarettes to reduce appetite."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintaining a healthy weight through balanced nutrition and regular physical activity, avoiding sugary foods and drinks, and monitoring blood sugar levels.
    })
  },
  {
    id: G8-HE-LD-03",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Lifestyle Diseases,
    subtopic: "Management of Chronic Conditions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Managing chronic conditions such as diabetes and hypertension requires lifestyle changes and medical care. What is the recommended dietary approach for a person with hypertension?,
      options: [
        Reducing salt (sodium) intake, eating more fruits and vegetables, reducing alcohol consumption, and maintaining a healthy weight.,
        Eating a high-salt diet to maintain blood pressure.,
        Consuming large amounts of caffeine.",
        "Ignoring dietary changes and only taking medication.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Reducing salt (sodium) intake, eating more fruits and vegetables, reducing alcohol consumption, and maintaining a healthy weight."
    })
  },
  {
    id: "G8-HE-HP-01",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Health Promotion",
    subtopic: "Community Health,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Community health involves the well-being of a population and the collective efforts to maintain it. Which of the following is an example of a community-level health promotion activity?,
      options: [
        Organizing health awareness campaigns, promoting vaccination, encouraging regular health check-ups, and improving access to clean water and sanitation.,
        Individual lifestyle changes without community involvement.,
        "Only treating sick individuals without prevention.,
        Building hospitals without addressing social determinants of health."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Organizing health awareness campaigns, promoting vaccination, encouraging regular health check-ups, and improving access to clean water and sanitation.
    })
  },
  {
    id: G8-HE-HP-02",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Health Promotion,
    subtopic: "Health Advocacy",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Health advocacy involves speaking up for health rights and promoting policies that improve health. Which of the following is an effective way for adolescents to advocate for better health in their community?,
      options: [
        Participating in community health meetings, writing to local leaders, using social media to raise awareness, and organizing health education activities in school.,
        Avoiding any involvement in health issues.,
        Complaining without taking any action.",
        "Waiting for adults to address all health problems.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Participating in community health meetings, writing to local leaders, using social media to raise awareness, and organizing health education activities in school."
    })
  },
  {
    id: "G8-HE-HP-03",
    grade: "Grade 8",
    subject: "Health Education",
    topic: "Health Promotion",
    subtopic: "Health-Seeking Behavior,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Health-seeking behavior involves recognizing symptoms and taking appropriate action. Which of the following demonstrates appropriate health-seeking behavior?,
      options: [
        Visiting a health professional when experiencing persistent symptoms, following prescribed treatment, and seeking preventive health services such as regular check-ups.,
        Ignoring symptoms and hoping they go away.,
        "Self-medicating without professional advice.,
        Delaying seeking care until the condition is severe."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Visiting a health professional when experiencing persistent symptoms, following prescribed treatment, and seeking preventive health services such as regular check-ups.
    })
  },
  {
    id: G8-HE-HP-04",
    grade: "Grade 8,
    subject: Health Education",
    topic: "Health Promotion,
    subtopic: "School Health Programs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " School health programs play an important role in promoting the health of learners. Which of the following is a component of a comprehensive school health program?,
      options: [
        Health education, provision of healthy school meals, physical education, access to health services, and a safe and supportive school environment.,
        Only health education without any physical activity components.,
        Only health services without education.",
        "Only physical education without health education.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Health education, provision of healthy school meals, physical education, access to health services, and a safe and supportive school environment."
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD HEALTH EDUCATION SYLLABUS)
  // =========================================================================

  // --- NUTRITION AND HEALTH (4 Materials) ---
  {
    id: "G9-HE-NH-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Nutrition and Health",
    subtopic: "Advanced Nutrition,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Advanced nutrition involves understanding the complex relationships between nutrients, metabolism, and health. Which of the following best describes the role of dietary fiber in the human diet and its health benefits?,
      options: [
        "Dietary fiber, found in plant-based foods, adds bulk to the diet, promotes regular bowel movements, helps control blood sugar levels, and lowers cholesterol, reducing the risk of heart disease and digestive disorders.,
        Dietary fiber provides essential vitamins and minerals to the body.",
        "Dietary fiber is a source of energy and is stored as fat.,
        Dietary fiber has no health benefits and is not needed in the diet."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Dietary fiber, found in plant-based foods, adds bulk to the diet, promotes regular bowel movements, helps control blood sugar levels, and lowers cholesterol, reducing the risk of heart disease and digestive disorders.
    })
  },
  {
    id: G9-HE-NH-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Nutrition and Health,
    subtopic: "Dietary Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Dietary management involves planning and adjusting food intake to prevent or manage health conditions. Which of the following is the recommended dietary approach for managing type 2 diabetes?,
      options: [
        Monitoring carbohydrate intake, choosing whole grains and low-glycemic index foods, eating regular meals with consistent portion sizes, and balancing food intake with medication or physical activity.,
        Avoiding all carbohydrates completely from the diet.,
        Eating large amounts of sugary foods and simple carbohydrates.",
        "Skipping meals to reduce blood sugar levels.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Monitoring carbohydrate intake, choosing whole grains and low-glycemic index foods, eating regular meals with consistent portion sizes, and balancing food intake with medication or physical activity."
    })
  },
  {
    id: "G9-HE-NH-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Nutrition and Health",
    subtopic: "Nutrition-Related Diseases,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Nutrition-related diseases are health conditions caused or influenced by dietary factors. Which of the following is a condition characterized by inadequate intake of protein and energy, leading to growth failure, muscle wasting, and edema?,
      options: [
        "Protein-energy malnutrition (PEM), which includes conditions such as kwashiorkor and marasmus, where the body lacks sufficient protein and energy for normal growth and maintenance.,
        Iron deficiency anemia, which is caused by lack of iron.",
        "Rickets, which is caused by vitamin D deficiency.,
        Scurvy, which is caused by vitamin C deficiency."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Protein-energy malnutrition (PEM), which includes conditions such as kwashiorkor and marasmus, where the body lacks sufficient protein and energy for normal growth and maintenance.
    })
  },
  {
    id: G9-HE-NH-04",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Nutrition and Health,
    subtopic: "Nutrition and Health Promotion",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nutrition and health promotion involves strategies to improve dietary practices and overall health at the population level. Which of the following is an effective strategy for promoting healthy eating in a community?,
      options: [
        Implementing nutrition education programs, improving access to affordable healthy foods, creating supportive environments for healthy eating, and engaging community leaders in promoting nutrition.,
        Providing only nutrition information without practical support.,
        Focusing only on food supplements rather than dietary education.",
        "Implementing policies without community engagement.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Implementing nutrition education programs, improving access to affordable healthy foods, creating supportive environments for healthy eating, and engaging community leaders in promoting nutrition."
    })
  },

  // --- HUMAN BODY SYSTEMS (4 Materials) ---
  {
    id: "G9-HE-HB-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Endocrine System,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The endocrine system uses hormones to regulate various body functions, including growth, metabolism, and reproduction. Which of the following describes the role of insulin in regulating blood sugar levels?,
      options: [
        "Insulin, produced by the pancreas, facilitates the uptake of glucose from the blood into cells for energy or storage, lowering blood sugar levels after a meal.,
        Insulin raises blood sugar levels by converting glycogen to glucose.",
        "Insulin stimulates the breakdown of fat for energy.,
        Insulin has no role in regulating blood sugar levels."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Insulin, produced by the pancreas, facilitates the uptake of glucose from the blood into cells for energy or storage, lowering blood sugar levels after a meal.
    })
  },
  {
    id: G9-HE-HB-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Nervous System",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " The nervous system coordinates the body's response to internal and external stimuli. Which of the following correctly describes the function of the central nervous system (CNS) and the peripheral nervous system (PNS)?,
      options: [
        The CNS, consisting of the brain and spinal cord, processes information and coordinates responses, while the PNS consists of nerves that connect the CNS to the rest of the body and transmit signals.,
        The CNS is responsible for involuntary responses only, while the PNS handles voluntary movements.,
        The CNS is the peripheral system, and the PNS is the central system.",
        "The CNS and PNS have identical functions and structures.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The CNS, consisting of the brain and spinal cord, processes information and coordinates responses, while the PNS consists of nerves that connect the CNS to the rest of the body and transmit signals."
    })
  },
  {
    id: "G9-HE-HB-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Human Body Systems",
    subtopic: "Immune System,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The immune system protects the body against pathogens and disease. Which of the following describes the function of lymphocytes (B cells and T cells) in the specific immune response?,
      options: [
        B cells produce antibodies to neutralize pathogens, while T cells directly attack infected cells or help regulate the immune response, providing specific and targeted protection against pathogens.,
        B cells and T cells both produce antibodies to protect the body.,
        "Lymphocytes only provide non-specific defense against pathogens.,
        Lymphocytes are not involved in the immune response."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "B cells produce antibodies to neutralize pathogens, while T cells directly attack infected cells or help regulate the immune response, providing specific and targeted protection against pathogens.
    })
  },
  {
    id: G9-HE-HB-04",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Human Body Systems,
    subtopic: "Renal/Urinary System",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The renal system (kidneys) plays a vital role in filtering waste products from the blood and maintaining fluid and electrolyte balance. What is the functional unit of the kidney responsible for filtering blood and producing urine?,
      options: [
        The nephron, which consists of the glomerulus and renal tubule, is the functional unit of the kidney that filters blood, reabsorbs needed substances, and secretes wastes to form urine.,
        The alveolus is the functional unit of the kidney.,
        The glomerulus alone is responsible for all kidney functions.",
        "The renal cortex is the functional unit of the kidney.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The nephron, which consists of the glomerulus and renal tubule, is the functional unit of the kidney that filters blood, reabsorbs needed substances, and secretes wastes to form urine."
    })
  },

  // --- MENTAL AND EMOTIONAL HEALTH (4 Materials) ---
  {
    id: "G9-HE-ME-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Mental Health Disorders,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Mental health disorders are conditions that affect a person's mood, thinking, and behavior. Which of the following is a mood disorder characterized by persistent sadness, loss of interest, and changes in sleep and appetite?,
      options: [
        "Depressive disorder (clinical depression), which involves persistent low mood, loss of interest in activities, and functional impairment lasting for at least two weeks.,
        Anxiety disorder, which is characterized by excessive fear and worry.",
        "Bipolar disorder, which involves alternating episodes of depression and mania.,
        Schizophrenia, which involves distorted thinking and hallucinations."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Depressive disorder (clinical depression), which involves persistent low mood, loss of interest in activities, and functional impairment lasting for at least two weeks.
    })
  },
  {
    id: G9-HE-ME-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Coping Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Developing effective coping strategies is important for managing mental health challenges. Which of the following is an adaptive coping strategy that promotes long-term mental well-being?,
      options: [
        Cognitive reframing (changing negative thought patterns), mindfulness practices, building social support networks, engaging in meaningful activities, and seeking professional help when needed.,
        Avoiding all problems and pretending they don't exist.,
        Using substances such as alcohol to cope with difficult emotions.",
        "Blaming others for personal difficulties.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Cognitive reframing (changing negative thought patterns), mindfulness practices, building social support networks, engaging in meaningful activities, and seeking professional help when needed."
    })
  },
  {
    id: "G9-HE-ME-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Mental and Emotional Health",
    subtopic: "Well-Being,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Well-being is a holistic concept that encompasses physical, mental, and emotional health. Which of the following contributes to overall well-being and mental health?,
      options: [
        "Maintaining a healthy lifestyle, practicing self-care, building positive relationships, having a sense of purpose, and maintaining work-life balance.,
        Focusing only on academic achievement without considering mental health.",
        "Ignoring physical health in favor of mental health alone.,
        Spending excessive time on work and social media."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintaining a healthy lifestyle, practicing self-care, building positive relationships, having a sense of purpose, and maintaining work-life balance.
    })
  },
  {
    id: G9-HE-ME-04",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Mental and Emotional Health,
    subtopic: "Stigma Reduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Mental health stigma involves negative attitudes and beliefs about mental health conditions. Which of the following strategies is most effective for reducing mental health stigma in schools and communities?,
      options: [
        Education and awareness campaigns that provide accurate information about mental health, sharing personal experiences to reduce fear, and promoting inclusive and supportive environments.,
        Ignoring mental health issues and not discussing them.,
        Labeling people with mental health conditions as dangerous or unpredictable.",
        "Only focusing on physical health without addressing mental health.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Education and awareness campaigns that provide accurate information about mental health, sharing personal experiences to reduce fear, and promoting inclusive and supportive environments."
    })
  },

  // --- DRUG AND SUBSTANCE ABUSE (4 Materials) ---
  {
    id: "G9-HE-DS-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Drug and Substance Abuse",
    subtopic: "Addiction,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Addiction is a chronic brain disease characterized by compulsive substance use despite harmful consequences. Which of the following describes the biological mechanism of addiction in the brain?,
      options: [
        Addiction involves changes in the brain's reward system, particularly the dopamine pathways, leading to intense cravings, loss of control, and continued use despite negative consequences.,
        Addiction is simply a matter of weak willpower and lack of discipline.,
        "Addiction has no biological basis and is entirely psychological.,
        Addiction only affects individuals with a specific personality type."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Addiction involves changes in the brain's reward system, particularly the dopamine pathways, leading to intense cravings, loss of control, and continued use despite negative consequences.
    })
  },
  {
    id: G9-HE-DS-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Drug and Substance Abuse,
    subtopic: "Prevention",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Effective drug prevention programs address multiple risk and protective factors. Which of the following is an evidence-based approach to preventing drug abuse among adolescents?,
      options: [
        Comprehensive prevention programs that address individual, family, peer, school, and community factors, including skills training, family support, and school engagement.,
        Scare tactics and fear-based messages that exaggerate the dangers of drugs.,
        Minimal intervention approaches that assume adolescents will make good choices.",
        "Allowing adolescents to experiment with drugs to satisfy their curiosity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Comprehensive prevention programs that address individual, family, peer, school, and community factors, including skills training, family support, and school engagement."
    })
  },
  {
    id: "G9-HE-DS-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Drug and Substance Abuse",
    subtopic: "Consequences,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Substance abuse has far-reaching consequences beyond individual health, affecting families and communities. Which of the following is a social consequence of drug abuse in families?,
      options: [
        Family breakdown, financial problems, domestic violence, neglect of children, and intergenerational transmission of substance abuse patterns.,
        Improved family cohesion and financial stability.",
        "Increased academic achievement in affected families.,
        Enhanced community participation and social engagement."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Family breakdown, financial problems, domestic violence, neglect of children, and intergenerational transmission of substance abuse patterns.
    })
  },
  {
    id: G9-HE-DS-04",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Drug and Substance Abuse,
    subtopic: "Rehabilitation",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Rehabilitation and recovery services are essential for individuals with substance use disorders. Which of the following is an important component of effective substance abuse rehabilitation?,
      options: [
        A comprehensive approach including medical detoxification, behavioral therapy, counseling, peer support groups, and aftercare services to prevent relapse.,
        Only medical treatment without any psychosocial support.,
        Isolation and punishment without any therapeutic intervention.",
        "A one-time intervention without ongoing support.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A comprehensive approach including medical detoxification, behavioral therapy, counseling, peer support groups, and aftercare services to prevent relapse."
    })
  },

  // --- FIRST AID AND EMERGENCY CARE (4 Materials) ---
  {
    id: "G9-HE-FA-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "First Aid and Emergency Care",
    subtopic: "Advanced First Aid,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Advanced first aid skills are important for managing complex medical emergencies. Which of the following is the correct technique for applying a tourniquet to control severe bleeding in a limb?,
      options: [
        Apply the tourniquet 2-3 inches above the bleeding site (but not over a joint), tighten it until the bleeding stops, and note the time of application for medical personnel.,
        Apply the tourniquet directly over the wound.,
        "Tighten the tourniquet as much as possible regardless of bleeding control.,
        Apply the tourniquet without noting the time of application."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Apply the tourniquet 2-3 inches above the bleeding site (but not over a joint), tighten it until the bleeding stops, and note the time of application for medical personnel.
    })
  },
  {
    id: G9-HE-FA-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "First Aid and Emergency Care,
    subtopic: "Trauma Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Trauma management involves the immediate assessment and treatment of injuries to prevent complications. What is the purpose of the primary survey (ABCDE approach) in trauma management?,
      options: [
        The primary survey is a rapid assessment of Airway, Breathing, Circulation, Disability (neurological status), and Exposure to identify and treat life-threatening conditions in order of priority.,
        The primary survey is a comprehensive examination of all injuries.,
        The primary survey is conducted only after all injuries have been treated.",
        "The primary survey focuses only on bone fractures.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The primary survey is a rapid assessment of Airway, Breathing, Circulation, Disability (neurological status), and Exposure to identify and treat life-threatening conditions in order of priority."
    })
  },
  {
    id: "G9-HE-FA-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "First Aid and Emergency Care",
    subtopic: "Emergency Preparedness,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Emergency preparedness involves planning and preparing for potential emergencies. Which of the following is the most important component of a family emergency preparedness plan?,
      options: [
        Having an emergency contact list, a communication plan, and a well-stocked emergency kit, including food, water, first aid supplies, and important documents.,
        Having only a first aid kit without any other supplies.,
        "Relying on emergency services without preparation.,
        Ignoring emergency preparedness as it is not necessary."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Having an emergency contact list, a communication plan, and a well-stocked emergency kit, including food, water, first aid supplies, and important documents.
    })
  },
  {
    id: G9-HE-FA-04",
    grade: "Grade 9,
    subject: Health Education",
    topic: "First Aid and Emergency Care,
    subtopic: "Triage",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Triage is the process of prioritizing patients in a mass casualty or emergency situation. What does the triage color coding system RED indicate in terms of priority and urgency?,
      options: [
        RED indicates immediate (priority 1) - life-threatening conditions that require immediate treatment, such as severe bleeding, airway obstruction, or respiratory distress.,
        RED indicates urgent (priority 2) - conditions that require treatment but are not immediately life-threatening.,
        RED indicates delayed (priority 3) - minor injuries that can wait.",
        "RED indicates deceased or injuries incompatible with life.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: RED indicates immediate (priority 1) - life-threatening conditions that require immediate treatment, such as severe bleeding, airway obstruction, or respiratory distress."
    })
  },

  // --- ENVIRONMENTAL HEALTH (3 Materials) ---
  {
    id: "G9-HE-EH-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Environmental Health",
    subtopic: "Environmental Hazards,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Environmental hazards are factors in the environment that can harm human health. Which of the following is an example of a chemical environmental hazard that can lead to respiratory problems and cancer?,
      options: [
        Air pollution, which includes particulate matter, nitrogen dioxide, sulfur dioxide, and other pollutants that can cause respiratory diseases, cardiovascular problems, and lung cancer.,
        Natural disasters such as floods and droughts.,
        "Biological hazards such as bacteria and viruses.,
        Physical hazards such as noise and vibration."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Air pollution, which includes particulate matter, nitrogen dioxide, sulfur dioxide, and other pollutants that can cause respiratory diseases, cardiovascular problems, and lung cancer.
    })
  },
  {
    id: G9-HE-EH-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Environmental Health,
    subtopic: "Pollution Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Pollution control involves measures to reduce or eliminate pollutants from the environment. Which of the following is an effective strategy for reducing air pollution from vehicles?,
      options: [
        Promoting the use of public transportation, walking, and cycling; encouraging the use of cleaner fuels; implementing emission standards; and improving vehicle maintenance.,
        Encouraging the use of private vehicles for transportation.,
        Ignoring vehicle emissions and focusing only on industrial pollution.",
        "Not taking any action to reduce vehicle emissions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Promoting the use of public transportation, walking, and cycling; encouraging the use of cleaner fuels; implementing emission standards; and improving vehicle maintenance."
    })
  },
  {
    id: "G9-HE-EH-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Environmental Health",
    subtopic: "Sustainable Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Sustainable environmental practices are essential for protecting health and preserving resources for future generations. Which of the following is an example of a sustainable practice that promotes environmental health?,
      options: [
        Reducing waste, recycling and composting, conserving water and energy, using renewable energy sources, and protecting natural habitats and biodiversity.,
        Burning waste to reduce its volume.,
        "Using excessive amounts of water and energy.,
        Not considering environmental impact in daily activities."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Reducing waste, recycling and composting, conserving water and energy, using renewable energy sources, and protecting natural habitats and biodiversity.
    })
  },

  // --- REPRODUCTIVE HEALTH (3 Materials) ---
  {
    id: G9-HE-RH-01",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Reproductive Health,
    subtopic: "Reproductive Health Rights",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Reproductive health rights include the right to make informed decisions about one's reproductive health. Which of the following is a fundamental reproductive health right recognized internationally?,
      options: [
        The right to access comprehensive reproductive health information and services, including contraception, antenatal care, and safe abortion services where permitted by law.,
        The right to have children regardless of health risks.,
        The right to refuse all reproductive health services.",
        "The right to make decisions about reproductive health without considering medical advice.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The right to access comprehensive reproductive health information and services, including contraception, antenatal care, and safe abortion services where permitted by law."
    })
  },
  {
    id: "G9-HE-RH-02",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Reproductive Health",
    subtopic: "Sexually Transmitted Infections (STIs),
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Sexually transmitted infections (STIs) are infections that are transmitted through sexual contact. Which of the following is the most effective strategy for preventing the transmission of HIV/AIDS and other STIs?,
      options: [
        Abstaining from sexual activity, using condoms consistently and correctly, getting regular STI testing, and being in a mutually monogamous relationship with an uninfected partner.,
        Relying only on the appearance of symptoms to detect STIs.,
        "Taking antibiotics before sexual activity to prevent infections.,
        Refusing to get tested for STIs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Abstaining from sexual activity, using condoms consistently and correctly, getting regular STI testing, and being in a mutually monogamous relationship with an uninfected partner.
    })
  },
  {
    id: G9-HE-RH-03",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Reproductive Health,
    subtopic: "Family Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Family planning involves the use of methods to regulate the timing and spacing of pregnancies. Which of the following is a long-acting reversible contraceptive method that provides pregnancy prevention for several years with minimal user action?,
      options: [
        Long-acting reversible contraceptives (LARCs), such as the implant and the intrauterine device (IUD), which provide effective contraception for 3-10 years with high effectiveness and safety.,
        Condoms, which provide protection against both pregnancy and STIs.,
        The birth control pill, which requires daily use.",
        "Natural methods such as the rhythm method.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Long-acting reversible contraceptives (LARCs), such as the implant and the intrauterine device (IUD), which provide effective contraception for 3-10 years with high effectiveness and safety."
    })
  },

  // --- LIFESTYLE DISEASES (3 Materials) ---
  {
    id: "G9-HE-LD-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Lifestyle Diseases",
    subtopic: "Prevention,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Prevention is the most effective approach to addressing lifestyle diseases. Which of the following is a primary prevention strategy for reducing the risk of cardiovascular disease?,
      options: [
        Maintaining a healthy diet low in saturated fats and sodium, engaging in regular physical activity, not smoking, limiting alcohol consumption, and managing stress.,
        Taking cholesterol-lowering medication without lifestyle changes.,
        "Waiting for symptoms of heart disease to appear before taking action.,
        Focusing only on treating high blood pressure without addressing other risk factors."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Maintaining a healthy diet low in saturated fats and sodium, engaging in regular physical activity, not smoking, limiting alcohol consumption, and managing stress.
    })
  },
  {
    id: G9-HE-LD-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Lifestyle Diseases,
    subtopic: "Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Managing chronic lifestyle diseases involves both medical treatment and lifestyle modifications. Which of the following is the recommended approach for managing hypertension in addition to medication?,
      options: [
        Lifestyle modifications including a low-sodium diet, regular physical activity, weight management, stress reduction, and limiting alcohol consumption.,
        Relying only on medication without lifestyle changes.,
        Continuing unhealthy eating habits while taking blood pressure medication.",
        "Ignoring blood pressure monitoring and health check-ups.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Lifestyle modifications including a low-sodium diet, regular physical activity, weight management, stress reduction, and limiting alcohol consumption."
    })
  },
  {
    id: "G9-HE-LD-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Lifestyle Diseases",
    subtopic: "Health Promotion,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Health promotion for lifestyle diseases involves encouraging healthy behaviors at the population level. Which of the following is an effective population-level health promotion strategy for preventing obesity?,
      options: [
        Implementing policies that improve access to healthy foods, promote physical activity in schools and workplaces, and limit marketing of unhealthy foods to children.,
        Promoting only individual weight loss programs.,
        "Encouraging the use of appetite suppressants and weight-loss supplements.,
        Promoting unrealistic body standards without addressing health."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Implementing policies that improve access to healthy foods, promote physical activity in schools and workplaces, and limit marketing of unhealthy foods to children.
    })
  },

  // --- HEALTH PROMOTION AND ADVOCACY (3 Materials) ---
  {
    id: G9-HE-HP-01",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Health Promotion and Advocacy,
    subtopic: "Community Health",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Community health promotion involves empowering communities to take action for their health. Which of the following is a principle of community engagement in health promotion?,
      options: [
        Community participation and empowerment, where community members are involved in identifying health issues, developing solutions, and implementing programs.,
        Expert-led programs without community input.,
        Health programs that are implemented without considering community needs.",
        "Top-down approaches where communities are passive recipients of health interventions.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Community participation and empowerment, where community members are involved in identifying health issues, developing solutions, and implementing programs."
    })
  },
  {
    id: "G9-HE-HP-02",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Health Promotion and Advocacy",
    subtopic: "Advocacy,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Health advocacy involves promoting policies and actions that improve health. Which of the following is an effective advocacy strategy for promoting health in a community?,
      options: [
        Using evidence-based arguments, building coalitions with community stakeholders, engaging with policymakers, using media and social media to raise awareness, and mobilizing community members.,
        Complaining without taking any action.,
        "Advocating without understanding the community's needs.,
        Using confrontational and aggressive tactics."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Using evidence-based arguments, building coalitions with community stakeholders, engaging with policymakers, using media and social media to raise awareness, and mobilizing community members.
    })
  },
  {
    id: G9-HE-HP-03",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Health Promotion and Advocacy,
    subtopic: "Health Policy",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Health policy influences the health of populations through laws, regulations, and programs. Which of the following is an example of a health policy that contributes to public health?,
      options: [
        Legislation that restricts the sale of tobacco and alcohol to minors, taxes tobacco products, bans smoking in public places, and requires graphic health warnings on cigarette packages.,
        Policies that promote the advertising of tobacco products.,
        Laws that reduce access to healthcare services.",
        "Policies that encourage unhealthy food consumption.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Legislation that restricts the sale of tobacco and alcohol to minors, taxes tobacco products, bans smoking in public places, and requires graphic health warnings on cigarette packages."
    })
  },

  // --- PERSONAL SAFETY AND SECURITY (3 Materials) ---
  {
    id: "G9-HE-PS-01",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Personal Safety and Security",
    subtopic: "Personal Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Personal safety involves protecting oneself from harm and making informed decisions in potentially dangerous situations. Which of the following is the most important strategy for preventing gender-based violence?,
      options: [
        Education about healthy relationships, understanding consent, respecting personal boundaries, seeking help when at risk, and reporting violence to appropriate authorities.,
        Ignoring early warning signs of abusive relationships.,
        "Blaming victims for violence they experience.,
        Accepting violence as normal in relationships."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Education about healthy relationships, understanding consent, respecting personal boundaries, seeking help when at risk, and reporting violence to appropriate authorities.
    })
  },
  {
    id: G9-HE-PS-02",
    grade: "Grade 9,
    subject: Health Education",
    topic: "Personal Safety and Security,
    subtopic: "Digital Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Digital safety involves protecting personal information and staying safe online. Which of the following is a best practice for maintaining privacy and safety on social media?,
      options: [
        Setting strong passwords, using privacy settings to control who can see posts, not sharing personal information publicly, thinking before posting, and being cautious about online friendships.,
        Sharing all personal information online to build connections.,
        Using the same password for all accounts to remember easily.",
        "Accepting friend requests from strangers without verifying their identity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Setting strong passwords, using privacy settings to control who can see posts, not sharing personal information publicly, thinking before posting, and being cautious about online friendships."
    })
  },
  {
    id: "G9-HE-PS-03",
    grade: "Grade 9",
    subject: "Health Education",
    topic: "Personal Safety and Security",
    subtopic: "Community Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Community safety involves collective efforts to prevent crime and ensure the well-being of community members. Which of the following is an effective strategy for improving community safety?,
      options: [
        Community policing, neighborhood watch programs, improving street lighting, promoting community cohesion, and encouraging residents to report suspicious activities.,
        Ignoring safety concerns and hoping crime decreases.,
        "Relying only on police without community involvement.,
        Promoting individual safety without community collaboration."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Community policing, neighborhood watch programs, improving street lighting, promoting community cohesion, and encouraging residents to report suspicious activities."
    })
  }

];


