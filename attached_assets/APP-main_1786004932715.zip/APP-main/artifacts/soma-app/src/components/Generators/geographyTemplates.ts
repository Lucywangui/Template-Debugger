export const geographyTemplates: TemplateRule[] = [
  // =========================================================================
  // DARASA LA 10: 35 MATERIALS (KICD GEOGRAPHY SYLLABUS)
  // =========================================================================

  // --- MADA: INTRODUCTION TO GEOGRAPHY (4 Materials) ---
  {
    id: "G10-GEO-INT-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Introduction to Geography",
    subtopic: "Definition of Geography",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: "Geography is the study of the earth and its features, as well as the relationship between humans and the environment. Which of the following is a major branch of geography?,
      options: [Physical geography, Biological geography", "Mathematical geography, Chemical geography"].sort(() => Math.random() - 0.5),
      correctAnswer: "Physical geography"
    })
  },
  {
    id: G10-GEO-INT-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "Introduction to Geography,
    subtopic: "Branches of Geography",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Human geography focuses on the study of human activities and their impact on the environment. Which of the following is a sub-branch of human geography?,
      options: [Population geography, Geomorphology, Climatology", "Oceanography].sort(() => Math.random() - 0.5),
      correctAnswer: Population geography"
    })
  },
  {
    id: "G10-GEO-INT-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Introduction to Geography",
    subtopic: "Importance of Geography,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Geography plays a vital role in our understanding of the world. Which of the following is a reason why geography is important?,
      options: [It helps in understanding environmental issues and planning., It helps in cooking food., "It helps in writing poems., It helps in painting pictures."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps in understanding environmental issues and planning.
    })
  },
  {
    id: G10-GEO-INT-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "Introduction to Geography,
    subtopic: "Branches of Geography",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Geomorphology is the study of the earth's landforms and the processes that shape them. What is the main focus of geomorphology?,
      options: [Landforms and their formation., Weather and climate., Population and migration.", "Economic activities.].sort(() => Math.random() - 0.5),
      correctAnswer: Landforms and their formation."
    })
  },

  // --- MADA: THE EARTH (4 Materials) ---
  {
    id: "G10-GEO-EAR-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Earth",
    subtopic: "Shape and Size of the Earth,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The earth is not perfectly spherical; it is an oblate spheroid. What is the approximate circumference of the earth at the equator?,
      options: [40,075 km, 20,000 km, "60,000 km, 30,000 km"].sort(() => Math.random() - 0.5),
      correctAnswer: "40,075 km
    })
  },
  {
    id: G10-GEO-EAR-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Earth,
    subtopic: "Rotation and Revolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The earth rotates on its axis and revolves around the sun. How long does it take for the earth to complete one revolution around the sun?,
      options: [365.25 days, 24 hours, 365 days", "366 days].sort(() => Math.random() - 0.5),
      correctAnswer: 365.25 days"
    })
  },
  {
    id: "G10-GEO-EAR-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Earth",
    subtopic: "Latitudes and Longitudes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Latitudes and longitudes are lines on the earth's surface used to locate places. What is the latitude of the Equator?,
      options: [0°, 90°N, "90°S, 23.5°N"].sort(() => Math.random() - 0.5),
      correctAnswer: "0°
    })
  },
  {
    id: G10-GEO-EAR-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Earth,
    subtopic: "Latitudes and Longitudes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Prime Meridian is an important longitude line. Which city does the Prime Meridian pass through?,
      options: [Greenwich, London, Nairobi, New York", "Tokyo].sort(() => Math.random() - 0.5),
      correctAnswer: Greenwich, London"
    })
  },

  // --- MADA: THE SOLAR SYSTEM (4 Materials) ---
  {
    id: "G10-GEO-SOL-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Solar System",
    subtopic: "Planets of the Solar System,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Our solar system consists of eight planets orbiting the sun. Which planet is closest to the sun?,
      options: [Mercury, Venus, "Earth, Mars"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mercury
    })
  },
  {
    id: G10-GEO-SOL-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Solar System,
    subtopic: "Planets of the Solar System",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The planets can be classified into two groups: terrestrial and Jovian. Which planet is the largest in the solar system?,
      options: [Jupiter, Saturn, Neptune", "Uranus].sort(() => Math.random() - 0.5),
      correctAnswer: Jupiter"
    })
  },
  {
    id: "G10-GEO-SOL-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Solar System",
    subtopic: "Movements of Planets,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Planets move around the sun in elliptical orbits. What is the name of the force that keeps the planets in their orbits?,
      options: [Gravity, Magnetism, "Friction, Inertia"].sort(() => Math.random() - 0.5),
      correctAnswer: "Gravity
    })
  },
  {
    id: G10-GEO-SOL-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Solar System,
    subtopic: "Characteristics of Planets",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The earth is the only planet known to support life. What is the main reason for the earth's ability to support life?,
      options: [The presence of water and a suitable atmosphere., Its large size., Its distance from the sun.", "Its rotation speed.].sort(() => Math.random() - 0.5),
      correctAnswer: The presence of water and a suitable atmosphere."
    })
  },

  // --- MADA: WEATHER AND CLIMATE (5 Materials) ---
  {
    id: "G10-GEO-WEA-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Weather and Climate",
    subtopic: "Elements of Weather,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Weather is the state of the atmosphere at a specific time and place. Which of the following is an element of weather?,
      options: [Temperature, Population, "Culture, Economy"].sort(() => Math.random() - 0.5),
      correctAnswer: "Temperature
    })
  },
  {
    id: G10-GEO-WEA-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "Weather and Climate,
    subtopic: "Elements of Weather",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Rainfall is a crucial element of weather. What instrument is used to measure the amount of rainfall?,
      options: [Rain gauge, Thermometer, Barometer", "Anemometer].sort(() => Math.random() - 0.5),
      correctAnswer: Rain gauge"
    })
  },
  {
    id: "G10-GEO-WEA-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Weather and Climate",
    subtopic: "Elements of Weather,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Wind speed and direction are important elements of weather. What instrument is used to measure wind speed?,
      options: [Anemometer, Barometer, "Thermometer, Rain gauge"].sort(() => Math.random() - 0.5),
      correctAnswer: "Anemometer
    })
  },
  {
    id: G10-GEO-WEA-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "Weather and Climate,
    subtopic: "Elements of Weather",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Air pressure is an important element of weather. What instrument is used to measure atmospheric pressure?,
      options: [Barometer, Thermometer, Anemometer", "Rain gauge].sort(() => Math.random() - 0.5),
      correctAnswer: Barometer"
    })
  },
  {
    id: "G10-GEO-WEA-05",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Weather and Climate",
    subtopic: "Climate Classification,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Climate is the average weather conditions of a region over a long period. Which of the following is a type of climate found near the Equator?,
      options: [Tropical rainforest climate, Desert climate, "Temperate climate, Mediterranean climate"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tropical rainforest climate
    })
  },

  // --- MADA: MAP WORK (5 Materials) ---
  {
    id: G10-GEO-MAP-01",
    grade: "Grade 10,
    subject: Geography",
    topic: "Map Work,
    subtopic: "Map Reading",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Maps are important tools in geography for representing the earth's surface. What is a map scale?,
      options: [The ratio between the distance on the map and the actual distance on the ground., The map title., The map legend.", "The map border.].sort(() => Math.random() - 0.5),
      correctAnswer: The ratio between the distance on the map and the actual distance on the ground."
    })
  },
  {
    id: "G10-GEO-MAP-02",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Map Work",
    subtopic: "Map Reading,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Grid references are used to pinpoint locations on a map. What is a four-figure grid reference?,
      options: [A reference that identifies a 1 km × 1 km square on the map., A reference that identifies a single point., "A reference for a route., A reference for a region."].sort(() => Math.random() - 0.5),
      correctAnswer: "A reference that identifies a 1 km × 1 km square on the map.
    })
  },
  {
    id: G10-GEO-MAP-03",
    grade: "Grade 10,
    subject: Geography",
    topic: "Map Work,
    subtopic: "Contour Lines",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Contour lines are used on topographic maps to show elevation. What do closely spaced contour lines indicate?,
      options: [A steep slope, A gentle slope, A flat area", "A depression].sort(() => Math.random() - 0.5),
      correctAnswer: A steep slope"
    })
  },
  {
    id: "G10-GEO-MAP-04",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Map Work",
    subtopic: "Contour Lines,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the vertical interval on a topographic map?,
      options: [The difference in elevation between two consecutive contour lines., The scale of the map., "The legend of the map., The direction of the map."].sort(() => Math.random() - 0.5),
      correctAnswer: "The difference in elevation between two consecutive contour lines.
    })
  },
  {
    id: G10-GEO-MAP-05",
    grade: "Grade 10,
    subject: Geography",
    topic: "Map Work,
    subtopic: "Map Interpretation",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Interpreting a map involves understanding the symbols and features shown. Which of the following is a feature commonly shown on a topographic map?,
      options: [Rivers and roads, Population density, Climate zones", "Vegetation types].sort(() => Math.random() - 0.5),
      correctAnswer: Rivers and roads"
    })
  },

  // --- MADA: PHYSICAL GEOGRAPHY (4 Materials) ---
  {
    id: "G10-GEO-PHY-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Physical Geography",
    subtopic: "Rocks,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Rocks are solid materials that make up the earth's crust. Which of the following is a type of rock?,
      options: [Igneous, Liquid, "Gas, Plasma"].sort(() => Math.random() - 0.5),
      correctAnswer: "Igneous
    })
  },
  {
    id: G10-GEO-PHY-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "Physical Geography,
    subtopic: "Weathering",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Weathering is the breaking down of rocks at the earth's surface. What is the main agent of weathering in hot and humid regions?,
      options: [Chemical weathering, Physical weathering, Biological weathering", "Erosion].sort(() => Math.random() - 0.5),
      correctAnswer: Chemical weathering"
    })
  },
  {
    id: "G10-GEO-PHY-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Physical Geography",
    subtopic: "Erosion,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Erosion is the process of moving rock fragments from one place to another. What is the most powerful agent of erosion on the earth's surface?,
      options: [Running water, Wind, "Glaciers, Gravity"].sort(() => Math.random() - 0.5),
      correctAnswer: "Running water
    })
  },
  {
    id: G10-GEO-PHY-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "Physical Geography,
    subtopic: "Soils",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Soil is the uppermost layer of the earth's crust. Which of the following is a factor that influences soil formation?,
      options: [Climate, Population, Economy", "Culture].sort(() => Math.random() - 0.5),
      correctAnswer: Climate"
    })
  },

  // --- MADA: INTERNAL FORCES OF THE EARTH (4 Materials) ---
  {
    id: "G10-GEO-INT-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Internal Forces of the Earth",
    subtopic: "Earthquakes,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Earthquakes are sudden movements of the earth's crust. What instrument is used to measure the magnitude of an earthquake?,
      options: [Seismograph, Barometer, "Thermometer, Anemometer"].sort(() => Math.random() - 0.5),
      correctAnswer: "Seismograph
    })
  },
  {
    id: G10-GEO-INT-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "Internal Forces of the Earth,
    subtopic: "Volcanoes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Volcanoes are openings in the earth's crust through which lava, ash, and gases escape. What is the name of the molten rock found beneath the earth's crust?,
      options: [Magma, Lava, Crust", "Mantle].sort(() => Math.random() - 0.5),
      correctAnswer: Magma"
    })
  },
  {
    id: "G10-GEO-INT-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "Internal Forces of the Earth",
    subtopic: "Tsunamis,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Tsunamis are large ocean waves triggered by undersea earthquakes or volcanic eruptions. What is the main cause of a tsunami?,
      options: [Undersea earthquakes, Strong winds, "Tides, Ocean currents"].sort(() => Math.random() - 0.5),
      correctAnswer: "Undersea earthquakes
    })
  },
  {
    id: G10-GEO-INT-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "Internal Forces of the Earth,
    subtopic: "Volcanoes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Volcanoes can be classified as active, dormant, or extinct. What is an extinct volcano?,
      options: [A volcano that has not erupted in recorded history and is not expected to erupt again., A volcano that is currently erupting., A volcano that has not erupted for a long time.", "A volcano that is erupting frequently.].sort(() => Math.random() - 0.5),
      correctAnswer: A volcano that has not erupted in recorded history and is not expected to erupt again."
    })
  },

  // --- MADA: EXTERNAL FORCES OF THE EARTH (4 Materials) ---
  {
    id: "G10-GEO-EXT-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "External Forces of the Earth",
    subtopic: "River Action,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Rivers are powerful agents of erosion and deposition. Which of the following is a landform created by river deposition?,
      options: [A delta, A mountain, "A volcano, A desert"].sort(() => Math.random() - 0.5),
      correctAnswer: "A delta
    })
  },
  {
    id: G10-GEO-EXT-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "External Forces of the Earth,
    subtopic: "Glaciers",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Glaciers are large masses of ice that move slowly over land. What is a landform created by glacial erosion?,
      options: [A U-shaped valley, A V-shaped valley, A delta", "A beach].sort(() => Math.random() - 0.5),
      correctAnswer: A U-shaped valley"
    })
  },
  {
    id: "G10-GEO-EXT-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "External Forces of the Earth",
    subtopic: "Coastal Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Coastal processes are driven by waves and tides. What is a landform created by wave erosion?,
      options: [A cliff, A beach, "A spit, A bar"].sort(() => Math.random() - 0.5),
      correctAnswer: "A cliff
    })
  },
  {
    id: G10-GEO-EXT-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "External Forces of the Earth,
    subtopic: "Wind Action",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Wind action can shape landforms, especially in arid regions. What is a landform created by wind deposition?,
      options: [A sand dune, A mountain, A valley", "A lake].sort(() => Math.random() - 0.5),
      correctAnswer: A sand dune"
    })
  },

  // --- MADA: THE ATMOSPHERE (4 Materials) ---
  {
    id: "G10-GEO-ATM-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Atmosphere",
    subtopic: "Composition of the Atmosphere,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The atmosphere is the layer of gases surrounding the earth. Which gas is the most abundant in the earth's atmosphere?,
      options: [Nitrogen, Oxygen, "Carbon dioxide, Argon"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nitrogen
    })
  },
  {
    id: G10-GEO-ATM-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Atmosphere,
    subtopic: "Structure of the Atmosphere",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The atmosphere is divided into several layers based on temperature. Which layer of the atmosphere contains the ozone layer?,
      options: [Stratosphere, Troposphere, Mesosphere", "Thermosphere].sort(() => Math.random() - 0.5),
      correctAnswer: Stratosphere"
    })
  },
  {
    id: "G10-GEO-ATM-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Atmosphere",
    subtopic: "Greenhouse Effect,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The greenhouse effect is a natural process that warms the earth's surface. Which gas is a major contributor to the greenhouse effect?,
      options: [Carbon dioxide, Oxygen, "Nitrogen, Argon"].sort(() => Math.random() - 0.5),
      correctAnswer: "Carbon dioxide
    })
  },
  {
    id: G10-GEO-ATM-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Atmosphere,
    subtopic: "Greenhouse Effect",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The enhanced greenhouse effect is a major cause of global warming. What is one effect of global warming?,
      options: [Rising sea levels, Lower sea levels, Increasing ice caps", "Reduced temperature].sort(() => Math.random() - 0.5),
      correctAnswer: Rising sea levels"
    })
  },

  // --- MADA: THE HYDROSPHERE (4 Materials) ---
  {
    id: "G10-GEO-HYD-01",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Hydrosphere",
    subtopic: "The Water Cycle,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The hydrosphere includes all the water on the earth's surface. What is the water cycle?,
      options: [The continuous movement of water between the earth and the atmosphere., The water in the oceans., "The water in the rivers., The water in the lakes."].sort(() => Math.random() - 0.5),
      correctAnswer: "The continuous movement of water between the earth and the atmosphere.
    })
  },
  {
    id: G10-GEO-HYD-02",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Hydrosphere,
    subtopic: "Oceans",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The oceans cover about 71% of the earth's surface. Which is the largest ocean in the world?,
      options: [Pacific Ocean, Atlantic Ocean, Indian Ocean", "Arctic Ocean].sort(() => Math.random() - 0.5),
      correctAnswer: Pacific Ocean"
    })
  },
  {
    id: "G10-GEO-HYD-03",
    grade: "Grade 10",
    subject: "Geography",
    topic: "The Hydrosphere",
    subtopic: "Lakes and Rivers,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Lakes and rivers are important freshwater sources. Which of the following is the longest river in the world?,
      options: [River Nile, River Amazon, "River Mississippi, River Yangtze"].sort(() => Math.random() - 0.5),
      correctAnswer: "River Nile
    })
  },
  {
    id: G10-GEO-HYD-04",
    grade: "Grade 10,
    subject: Geography",
    topic: "The Hydrosphere,
    subtopic: "Lakes and Rivers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Lake Victoria is a major lake in East Africa. What is the main importance of Lake Victoria to the region?,
      options: [Fishing, transport, and hydroelectric power., Mining., Agriculture.", "Tourism.].sort(() => Math.random() - 0.5),
      correctAnswer: Fishing, transport, and hydroelectric power."
    })
  },

  // =========================================================================
  // DARASA LA 11: 35 MATERIALS (KICD GEOGRAPHY SYLLABUS)
  // =========================================================================

  // --- MADA: CLIMATE CHANGE (4 Materials) ---
  {
    id: "G11-GEO-CLI-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Climate Change",
    subtopic: "Causes of Climate Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Climate change refers to the long-term shift in global weather patterns. Which of the following is a major cause of climate change?,
      options: [Burning of fossil fuels and deforestation., Natural climate cycles., "Volcanic eruptions., Solar flares."].sort(() => Math.random() - 0.5),
      correctAnswer: "Burning of fossil fuels and deforestation.
    })
  },
  {
    id: G11-GEO-CLI-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Climate Change,
    subtopic: "Effects of Climate Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Climate change has various effects on the environment and human activities. What is one significant effect of climate change in coastal areas?,
      options: [Rising sea levels, Lower sea levels, Increasing ice caps", "Reduced temperatures].sort(() => Math.random() - 0.5),
      correctAnswer: Rising sea levels"
    })
  },
  {
    id: "G11-GEO-CLI-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Climate Change",
    subtopic: "Mitigation of Climate Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mitigation involves efforts to reduce the emission of greenhouse gases. Which of the following is a mitigation strategy?,
      options: [Switching to renewable energy sources., Burning more fossil fuels., "Cutting down forests., Using more coal."].sort(() => Math.random() - 0.5),
      correctAnswer: "Switching to renewable energy sources.
    })
  },
  {
    id: G11-GEO-CLI-04",
    grade: "Grade 11,
    subject: Geography",
    topic: "Climate Change,
    subtopic: "Mitigation of Climate Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Paris Agreement is an international treaty on climate change. What is the main goal of the Paris Agreement?,
      options: [To limit global warming to below 2°C., To increase global temperatures., To promote the use of fossil fuels.", "To ignore climate change.].sort(() => Math.random() - 0.5),
      correctAnswer: To limit global warming to below 2°C."
    })
  },

  // --- MADA: WEATHER AND CLIMATE (ADVANCED) (4 Materials) ---
  {
    id: "G11-GEO-WEA-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Weather and Climate (Advanced)",
    subtopic: "Atmospheric Pressure,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Atmospheric pressure is the weight of air pressing down on the earth's surface. What is a high-pressure system also known as?,
      options: [An anticyclone, A cyclone, "A depression, A front"].sort(() => Math.random() - 0.5),
      correctAnswer: "An anticyclone
    })
  },
  {
    id: G11-GEO-WEA-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Weather and Climate (Advanced),
    subtopic: "Winds",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Winds are caused by differences in atmospheric pressure. What are the prevailing winds in the tropics called?,
      options: [Trade winds, Westerlies, Easterlies", "Monsoon winds].sort(() => Math.random() - 0.5),
      correctAnswer: Trade winds"
    })
  },
  {
    id: "G11-GEO-WEA-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Weather and Climate (Advanced)",
    subtopic: "Ocean Currents,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ocean currents are large movements of water in the oceans. How do ocean currents influence climate?,
      options: [They transfer heat and affect temperature and rainfall., They do not affect climate., "They cool the land only., They heat the land only."].sort(() => Math.random() - 0.5),
      correctAnswer: "They transfer heat and affect temperature and rainfall.
    })
  },
  {
    id: G11-GEO-WEA-04",
    grade: "Grade 11,
    subject: Geography",
    topic: "Weather and Climate (Advanced),
    subtopic: "Rainfall Patterns",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Rainfall patterns are influenced by various factors. Which of the following is a type of rainfall?,
      options: [Convectional rainfall, Gravity rainfall, Friction rainfall", "Solar rainfall].sort(() => Math.random() - 0.5),
      correctAnswer: Convectional rainfall"
    })
  },

  // --- MADA: GEOMORPHOLOGY (4 Materials) ---
  {
    id: "G11-GEO-GEO-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Geomorphology",
    subtopic: "Plate Tectonics,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Plate tectonics is the theory that the earth's crust is made up of moving plates. What causes the movement of these plates?,
      options: [Convection currents in the mantle., Wind., "Rivers., Gravity."].sort(() => Math.random() - 0.5),
      correctAnswer: "Convection currents in the mantle.
    })
  },
  {
    id: G11-GEO-GEO-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Geomorphology,
    subtopic: "Continental Drift",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Continental drift is the theory that continents have moved over geological time. Who proposed the theory of continental drift?,
      options: [Alfred Wegener, Charles Darwin, Isaac Newton", "Albert Einstein].sort(() => Math.random() - 0.5),
      correctAnswer: Alfred Wegener"
    })
  },
  {
    id: "G11-GEO-GEO-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Geomorphology",
    subtopic: "Fold Mountains,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Fold mountains are formed by the folding of rock layers due to compressional forces. Which of the following is an example of a fold mountain?,
      options: [The Himalayas, Mount Kilimanjaro, "Mount Kenya, Mount Everest"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Himalayas
    })
  },
  {
    id: G11-GEO-GEO-04",
    grade: "Grade 11,
    subject: Geography",
    topic: "Geomorphology,
    subtopic: "Rift Valleys",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Rift valleys are formed by tensional forces that cause the earth's crust to pull apart. What is a major feature of a rift valley?,
      options: [A long, narrow valley with steep sides., A flat plain., A mountain range.", "A desert.].sort(() => Math.random() - 0.5),
      correctAnswer: A long, narrow valley with steep sides."
    })
  },

  // --- MADA: EARTHQUAKES AND VOLCANOES (4 Materials) ---
  {
    id: "G11-GEO-EAR-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Earthquakes and Volcanoes",
    subtopic: "Distribution of Earthquakes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Earthquakes are concentrated in certain regions of the world. What is the name of the zone where most earthquakes occur?,
      options: [The Pacific Ring of Fire, The Atlantic Ridge, "The Himalayan Belt, The Mediterranean Zone"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Pacific Ring of Fire
    })
  },
  {
    id: G11-GEO-EAR-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Earthquakes and Volcanoes,
    subtopic: "Effects of Earthquakes",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Earthquakes can cause extensive damage to life and property. What is a secondary effect of an earthquake?,
      options: [Tsunamis and landslides, Volcanic eruptions, Global warming", "Climate change].sort(() => Math.random() - 0.5),
      correctAnswer: Tsunamis and landslides"
    })
  },
  {
    id: "G11-GEO-EAR-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Earthquakes and Volcanoes",
    subtopic: "Management of Earthquake Risks,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Earthquake risks can be managed through various strategies. What is one way to reduce the damage caused by earthquakes?,
      options: [Constructing earthquake-resistant buildings., Ignoring the risk., "Building on fault lines., Using flexible materials."].sort(() => Math.random() - 0.5),
      correctAnswer: "Constructing earthquake-resistant buildings.
    })
  },
  {
    id: G11-GEO-EAR-04",
    grade: "Grade 11,
    subject: Geography",
    topic: "Earthquakes and Volcanoes,
    subtopic: "Management of Earthquake Risks",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Volcanoes can be classified by their activity. What is a dormant volcano?,
      options: [A volcano that is not currently erupting but could erupt in the future., A volcano that is erupting frequently., A volcano that has not erupted in recorded history.", "A volcano that is currently erupting.].sort(() => Math.random() - 0.5),
      correctAnswer: A volcano that is not currently erupting but could erupt in the future."
    })
  },

  // --- MADA: RIVER PROCESSES (4 Materials) ---
  {
    id: "G11-GEO-RIV-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "River Processes",
    subtopic: "Drainage Basins,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A drainage basin is the area of land drained by a river and its tributaries. What is a watershed in a drainage basin?,
      options: [The boundary that separates one drainage basin from another., The main river channel., "The river mouth., The source of the river."].sort(() => Math.random() - 0.5),
      correctAnswer: "The boundary that separates one drainage basin from another.
    })
  },
  {
    id: G11-GEO-RIV-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "River Processes,
    subtopic: "River Profiles",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A river profile is a cross-section of a river along its length. What is a feature of the upper course of a river?,
      options: [Steep gradient and erosion., Gentle gradient and deposition., Wide floodplains.", "Large meanders.].sort(() => Math.random() - 0.5),
      correctAnswer: Steep gradient and erosion."
    })
  },
  {
    id: "G11-GEO-RIV-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "River Processes",
    subtopic: "River Landforms,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Rivers create various landforms through erosion and deposition. What is a landform created by river deposition at the mouth of a river?,
      options: [A delta, A waterfall, "A meander, A gorge"].sort(() => Math.random() - 0.5),
      correctAnswer: "A delta
    })
  },
  {
    id: G11-GEO-RIV-04",
    grade: "Grade 11,
    subject: Geography",
    topic: "River Processes,
    subtopic: "River Landforms",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Waterfalls are common landforms in the upper course of a river. How are waterfalls formed?,
      options: [By the erosion of a band of hard rock overlaying softer rock., By deposition of sediments., By the melting of glaciers.", "By volcanic activity.].sort(() => Math.random() - 0.5),
      correctAnswer: By the erosion of a band of hard rock overlaying softer rock."
    })
  },

  // --- MADA: GLACIATION (3 Materials) ---
  {
    id: "G11-GEO-GLA-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Glaciation",
    subtopic: "Glacial Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Glaciers are large masses of ice that move slowly over the land. What is the process of glacial erosion called?,
      options: [Abrasion and plucking., Weathering., "Deposition., Erosion."].sort(() => Math.random() - 0.5),
      correctAnswer: "Abrasion and plucking.
    })
  },
  {
    id: G11-GEO-GLA-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Glaciation,
    subtopic: "Glacial Landforms",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Glacial erosion creates distinctive landforms. What is a cirque?,
      options: [A bowl-shaped hollow formed by glacial erosion., A U-shaped valley., A river valley.", "A mountain peak.].sort(() => Math.random() - 0.5),
      correctAnswer: A bowl-shaped hollow formed by glacial erosion."
    })
  },
  {
    id: "G11-GEO-GLA-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Glaciation",
    subtopic: "Glacial Landforms,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "What is a tarn in glacial geography?,
      options: [A small lake in a cirque., A U-shaped valley., "A river valley., A mountain peak."].sort(() => Math.random() - 0.5),
      correctAnswer: "A small lake in a cirque.
    })
  },

  // --- MADA: COASTAL PROCESSES (3 Materials) ---
  {
    id: G11-GEO-COA-01",
    grade: "Grade 11,
    subject: Geography",
    topic: "Coastal Processes,
    subtopic: "Coastal Erosion",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Coastal erosion is the process by which waves wear away the coast. What is a landform created by coastal erosion?,
      options: [A headland and a cliff., A beach., A sand dune.", "A spit.].sort(() => Math.random() - 0.5),
      correctAnswer: A headland and a cliff."
    })
  },
  {
    id: "G11-GEO-COA-02",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Coastal Processes",
    subtopic: "Coastal Deposition,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Coastal deposition occurs when the energy of the waves decreases. What is a landform created by coastal deposition?,
      options: [A beach and a spit., A cliff., "A headland., A cave."].sort(() => Math.random() - 0.5),
      correctAnswer: "A beach and a spit.
    })
  },
  {
    id: G11-GEO-COA-03",
    grade: "Grade 11,
    subject: Geography",
    topic: "Coastal Processes,
    subtopic: "Coastal Deposition",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A spit is a coastal depositional feature. How is a spit formed?,
      options: [By the deposition of material by wave action and longshore drift., By erosion of a cliff., By glacial action.", "By river action.].sort(() => Math.random() - 0.5),
      correctAnswer: By the deposition of material by wave action and longshore drift."
    })
  },

  // --- MADA: THE HYDROSPHERE (ADVANCED) (3 Materials) ---
  {
    id: "G11-GEO-HYD-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "The Hydrosphere (Advanced)",
    subtopic: "Ocean Currents,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ocean currents are large masses of moving water in the oceans. What is the main driving force of surface ocean currents?,
      options: [Wind, Temperature, "Salinity, Gravity"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wind
    })
  },
  {
    id: G11-GEO-HYD-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "The Hydrosphere (Advanced),
    subtopic: "Tides",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tides are the rise and fall of sea levels. What causes the tides?,
      options: [The gravitational pull of the moon and the sun., Wind., Earthquakes.", "Volcanic eruptions.].sort(() => Math.random() - 0.5),
      correctAnswer: The gravitational pull of the moon and the sun."
    })
  },
  {
    id: "G11-GEO-HYD-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "The Hydrosphere (Advanced)",
    subtopic: "Tsunamis,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Tsunamis are large ocean waves caused by undersea earthquakes. What is the main characteristic of a tsunami?,
      options: [They travel at high speeds across the ocean., They are caused by wind., "They are caused by temperature., They are caused by salinity."].sort(() => Math.random() - 0.5),
      correctAnswer: "They travel at high speeds across the ocean.
    })
  },

  // --- MADA: SOILS (3 Materials) ---
  {
    id: G11-GEO-SOI-01",
    grade: "Grade 11,
    subject: Geography",
    topic: "Soils,
    subtopic: "Soil Formation",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Soil is the uppermost layer of the earth's crust. What is the main factor that determines the type of soil in a region?,
      options: [Climate, Population, Economy", "Culture].sort(() => Math.random() - 0.5),
      correctAnswer: Climate"
    })
  },
  {
    id: "G11-GEO-SOI-02",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Soils",
    subtopic: "Soil Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Different types of soil are found in different regions. Which type of soil is most suitable for agriculture in Kenya?,
      options: [Volcanic soil, Sandy soil, "Clay soil, Sandy-clay soil"].sort(() => Math.random() - 0.5),
      correctAnswer: "Volcanic soil
    })
  },
  {
    id: G11-GEO-SOI-03",
    grade: "Grade 11,
    subject: Geography",
    topic: "Soils,
    subtopic: "Soil Conservation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Soil conservation is the practice of protecting the soil from erosion. What is one method of soil conservation?,
      options: [Terracing and contour ploughing., Overgrazing., Deforestation.", "Burning vegetation.].sort(() => Math.random() - 0.5),
      correctAnswer: Terracing and contour ploughing."
    })
  },

  // --- MADA: VEGETATION (ADVANCED) (3 Materials) ---
  {
    id: "G11-GEO-VEG-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Vegetation (Advanced)",
    subtopic: "Plant Adaptations,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Plants have adaptations that allow them to survive in their environment. What is an adaptation of plants in the desert?,
      options: [Deep roots and thick, waxy leaves., Large leaves., "Shallow roots., Thin leaves."].sort(() => Math.random() - 0.5),
      correctAnswer: "Deep roots and thick, waxy leaves.
    })
  },
  {
    id: G11-GEO-VEG-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Vegetation (Advanced),
    subtopic: "Biomes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A biome is a large community of plants and animals. What is the main factor that determines the type of biome in a region?,
      options: [Climate, Population, Culture", "Government].sort(() => Math.random() - 0.5),
      correctAnswer: Climate"
    })
  },
  {
    id: "G11-GEO-VEG-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Vegetation (Advanced)",
    subtopic: "Deforestation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Deforestation is the clearing of forests for other uses. What is the main effect of deforestation on the environment?,
      options: [Loss of biodiversity and increased soil erosion., Increased rainfall., "Improved air quality., Reduced global warming."].sort(() => Math.random() - 0.5),
      correctAnswer: "Loss of biodiversity and increased soil erosion.
    })
  },

  // --- MADA: MAP WORK (ADVANCED) (3 Materials) ---
  {
    id: G11-GEO-MAP-01",
    grade: "Grade 11,
    subject: Geography",
    topic: "Map Work (Advanced),
    subtopic: "Interpreting Topographical Maps",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Topographical maps provide detailed information about the landscape. What is a common feature shown on a topographical map?,
      options: [Contour lines and spot heights, Population data, Language distribution", "Political boundaries].sort(() => Math.random() - 0.5),
      correctAnswer: Contour lines and spot heights"
    })
  },
  {
    id: "G11-GEO-MAP-02",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Map Work (Advanced)",
    subtopic: "Drawing Cross-sections,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Drawing a cross-section from a map involves showing the profile of the land. What is the purpose of drawing a cross-section?,
      options: [To visualize the relief of the landscape., To show population density., "To show political boundaries., To show language distribution."].sort(() => Math.random() - 0.5),
      correctAnswer: "To visualize the relief of the landscape.
    })
  },
  {
    id: G11-GEO-MAP-03",
    grade: "Grade 11,
    subject: Geography",
    topic: "Map Work (Advanced),
    subtopic: "Drawing Cross-sections",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A vertical exaggeration is often used when drawing a cross-section. What is the purpose of vertical exaggeration?,
      options: [To make the landforms more visible., To reduce the scale., To change the map legend.", "To remove some features.].sort(() => Math.random() - 0.5),
      correctAnswer: To make the landforms more visible."
    })
  },

  // --- MADA: HUMAN GEOGRAPHY (3 Materials) ---
  {
    id: "G11-GEO-HUM-01",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Human Geography",
    subtopic: "Population Dynamics,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Population dynamics is the study of changes in the size and composition of a population. What is the birth rate?,
      options: [The number of live births per 1,000 people in a year., The number of deaths per 1,000 people., "The number of people moving into a country., The number of people moving out of a country."].sort(() => Math.random() - 0.5),
      correctAnswer: "The number of live births per 1,000 people in a year.
    })
  },
  {
    id: G11-GEO-HUM-02",
    grade: "Grade 11,
    subject: Geography",
    topic: "Human Geography,
    subtopic: "Migration",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Migration is the movement of people from one place to another. What is the difference between immigration and emigration?,
      options: [Immigration is moving into a country, while emigration is moving out., Immigration is moving out, while emigration is moving in., They are the same.", "Immigration is for work, while emigration is for study.].sort(() => Math.random() - 0.5),
      correctAnswer: Immigration is moving into a country, while emigration is moving out."
    })
  },
  {
    id: "G11-GEO-HUM-03",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Human Geography",
    subtopic: "Population Dynamics,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Population density is the number of people living in a given area. Why do some regions have a high population density while others have a low population density?,
      options: [Availability of resources, climate, and economic opportunities., The number of schools., "The number of churches., The language spoken."].sort(() => Math.random() - 0.5),
      correctAnswer: "Availability of resources, climate, and economic opportunities.
    })
  },

  // --- MADA: URBANIZATION (4 Materials) ---
  {
    id: G11-GEO-URB-01",
    grade: "Grade 11,
    subject: Geography",
    topic: "Urbanization,
    subtopic: "Urban Growth",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Urbanization refers to the increasing number of people living in urban areas. What is the main cause of urbanization in developing countries?,
      options: [Rural-urban migration, Low birth rates, Low death rates", "High employment in rural areas].sort(() => Math.random() - 0.5),
      correctAnswer: Rural-urban migration"
    })
  },
  {
    id: "G11-GEO-URB-02",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Urbanization",
    subtopic: "Urban Growth,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Urban growth can lead to various challenges. What is one problem associated with rapid urbanization?,
      options: [Inadequate housing and infrastructure., Increased forest cover., "Reduced traffic., Lower pollution."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inadequate housing and infrastructure.
    })
  },
  {
    id: G11-GEO-URB-03",
    grade: "Grade 11,
    subject: Geography",
    topic: "Urbanization,
    subtopic: "Urban Challenges",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Urban areas face challenges such as congestion, pollution, and crime. What is a solution to reduce urban congestion?,
      options: [Improving public transport systems., Building more private cars., Building more roads.", "Encouraging more migration to cities.].sort(() => Math.random() - 0.5),
      correctAnswer: Improving public transport systems."
    })
  },
  {
    id: "G11-GEO-URB-04",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Urbanization",
    subtopic: "Urban Challenges,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sustainable urban development aims to create cities that are environmentally friendly. What is one way to achieve sustainable urban development?,
      options: [Green building practices and renewable energy., Increasing urban sprawl., "Ignoring environmental concerns., Reducing green spaces."].sort(() => Math.random() - 0.5),
      correctAnswer: "Green building practices and renewable energy.
    })
  },

  // --- MADA: ENVIRONMENTAL MANAGEMENT (3 Materials) ---
  {
    id: G11-GEO-ENV-01",
    grade: "Grade 11,
    subject: Geography",
    topic: "Environmental Management,
    subtopic: "Pollution",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Pollution is the introduction of harmful substances into the environment. What is the main source of air pollution in urban areas?,
      options: [Vehicle emissions and industrial processes., Planting trees., Cleaning streets.", "Recycling waste.].sort(() => Math.random() - 0.5),
      correctAnswer: Vehicle emissions and industrial processes."
    })
  },
  {
    id: "G11-GEO-ENV-02",
    grade: "Grade 11",
    subject: "Geography",
    topic: "Environmental Management",
    subtopic: "Waste Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Waste management is the process of collecting, treating, and disposing of waste. What is the best way to manage waste?,
      options: ["Reduce, reuse, and recycle., Burn all waste.", "Dump waste into rivers., Bury waste in the ground."].sort(() => Math.random() - 0.5),
      correctAnswer: "Reduce, reuse, and recycle.
    })
  },
  {
    id: G11-GEO-ENV-03",
    grade: "Grade 11,
    subject: Geography",
    topic: "Environmental Management,
    subtopic: "Renewable Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Renewable energy sources are important for sustainable development. What is an example of a renewable energy source?,
      options: [Solar and wind power., Coal and oil., Natural gas.", "Nuclear power.].sort(() => Math.random() - 0.5),
      correctAnswer: Solar and wind power."
    })
  }
  // =========================================================================
  // DARASA LA 12: 35 MATERIALS (KICD GEOGRAPHY SYLLABUS)
  // =========================================================================

  // --- MADA: REGIONAL GEOGRAPHY: EAST AFRICA (4 Materials) ---
  {
    id: "G12-GEO-EA-01",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Regional Geography: East Africa",
    subtopic: "Physical Features of East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "East Africa is a region characterized by diverse physical features. Which of the following is a major physical feature found in the East African region?,
      options: [The Great Rift Valley, The Amazon River, "The Himalayas, The Rocky Mountains"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Great Rift Valley
    })
  },
  {
    id: G12-GEO-EA-02",
    grade: "Grade 12,
    subject: Geography",
    topic: "Regional Geography: East Africa,
    subtopic: "Climate of East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The climate of East Africa is influenced by its location near the equator. Which of the following is a type of climate found in East Africa?,
      options: [Tropical climate with seasonal rainfall., Desert climate., Temperate climate.", "Polar climate.].sort(() => Math.random() - 0.5),
      correctAnswer: Tropical climate with seasonal rainfall."
    })
  },
  {
    id: "G12-GEO-EA-03",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Regional Geography: East Africa",
    subtopic: "Vegetation of East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Vegetation in East Africa varies according to climate and altitude. Which type of vegetation is found in the savanna regions of East Africa?,
      options: [Grassland with scattered trees., Tropical rainforest., "Desert scrub., Mediterranean vegetation."].sort(() => Math.random() - 0.5),
      correctAnswer: "Grassland with scattered trees.
    })
  },
  {
    id: G12-GEO-EA-04",
    grade: "Grade 12,
    subject: Geography",
    topic: "Regional Geography: East Africa,
    subtopic: "Drainage Systems in East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " East Africa has several important drainage systems and water bodies. Which of the following is a major lake in East Africa?,
      options: [Lake Victoria, Lake Superior, Lake Michigan", "Lake Geneva].sort(() => Math.random() - 0.5),
      correctAnswer: Lake Victoria"
    })
  },

  // --- MADA: REGIONAL GEOGRAPHY: KENYA (4 Materials) ---
  {
    id: "G12-GEO-KE-01",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Regional Geography: Kenya",
    subtopic: "Landforms in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Kenya has a diverse range of landforms resulting from geological processes. Which of the following is the highest mountain in Kenya?,
      options: [Mount Kenya, Mount Kilimanjaro, "Mount Elgon, Mount Longonot"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mount Kenya
    })
  },
  {
    id: G12-GEO-KE-02",
    grade: "Grade 12,
    subject: Geography",
    topic: "Regional Geography: Kenya,
    subtopic: "Climate of Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Kenya experiences a variety of climatic conditions due to its diverse relief. Which region of Kenya receives the highest rainfall?,
      options: [The coastal region, The eastern region, The northern region", "The central highlands].sort(() => Math.random() - 0.5),
      correctAnswer: The coastal region"
    })
  },
  {
    id: "G12-GEO-KE-03",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Regional Geography: Kenya",
    subtopic: "Natural Resources in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Kenya is endowed with a variety of natural resources. Which of the following is a major natural resource found in Kenya?,
      options: [Soda ash and titanium, Oil and coal, "Diamonds and platinum, Gold and silver"].sort(() => Math.random() - 0.5),
      correctAnswer: "Soda ash and titanium
    })
  },
  {
    id: G12-GEO-KE-04",
    grade: "Grade 12,
    subject: Geography",
    topic: "Regional Geography: Kenya,
    subtopic: "Natural Resources in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Kenya's natural resources play a vital role in its economy. What is the main use of soda ash mined in the Magadi region?,
      options: [Manufacturing glass and detergents., Building construction., Fuel production.", "Food processing.].sort(() => Math.random() - 0.5),
      correctAnswer: Manufacturing glass and detergents."
    })
  },

  // --- MADA: ECONOMIC GEOGRAPHY (5 Materials) ---
  {
    id: "G12-GEO-ECO-01",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Economic Geography",
    subtopic: "Agriculture in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Agriculture is the backbone of Kenya's economy. Which of the following is a major cash crop grown in Kenya?,
      options: [Tea and coffee, Maize and wheat, "Rice and sugarcane, Cotton and tobacco"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tea and coffee
    })
  },
  {
    id: G12-GEO-ECO-02",
    grade: "Grade 12,
    subject: Geography",
    topic: "Economic Geography,
    subtopic: "Agriculture in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Horticulture is an important agricultural activity in Kenya. What is the main reason for Kenya's success in horticulture?,
      options: [Favorable climate and access to international markets., Large land area., Low labor costs.", "High government subsidies.].sort(() => Math.random() - 0.5),
      correctAnswer: Favorable climate and access to international markets."
    })
  },
  {
    id: "G12-GEO-ECO-03",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Economic Geography",
    subtopic: "Mining in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mining is a growing sector in Kenya's economy. Which mineral is mined in the Magadi area of Kenya?,
      options: [Soda ash, Gold, "Titanium, Copper"].sort(() => Math.random() - 0.5),
      correctAnswer: "Soda ash
    })
  },
  {
    id: G12-GEO-ECO-04",
    grade: "Grade 12,
    subject: Geography",
    topic: "Economic Geography,
    subtopic: "Fishing in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Fishing is an important economic activity in Kenya, particularly in Lake Victoria and the coastal waters. What is the main challenge facing the fishing industry in Lake Victoria?,
      options: [Overfishing and pollution., Lack of fish., High demand.", "Favorable conditions.].sort(() => Math.random() - 0.5),
      correctAnswer: Overfishing and pollution."
    })
  },
  {
    id: "G12-GEO-ECO-05",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Economic Geography",
    subtopic: "Forestry in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Forestry is an important economic activity in Kenya. What is the main challenge facing the forestry sector in Kenya today?,
      options: [Deforestation and illegal logging., Overpopulation of forests., "High timber prices., Excessive rainfall."].sort(() => Math.random() - 0.5),
      correctAnswer: "Deforestation and illegal logging.
    })
  },

  // --- MADA: INDUSTRY AND MANUFACTURING (4 Materials) ---
  {
    id: G12-GEO-IND-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Industry and Manufacturing,
    subtopic: "Manufacturing in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Manufacturing is a key contributor to Kenya's economy. Which of the following is a major manufacturing industry in Kenya?,
      options: [Cement production, Car manufacturing, Aircraft manufacturing", "Electronics assembly].sort(() => Math.random() - 0.5),
      correctAnswer: Cement production"
    })
  },
  {
    id: "G12-GEO-IND-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Industry and Manufacturing",
    subtopic: "Manufacturing in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Textile and garment manufacturing is a significant industry in Kenya. What is one challenge facing the textile industry in Kenya?,
      options: [Competition from cheap imports., Low domestic demand., "Abundance of raw materials., High government support."].sort(() => Math.random() - 0.5),
      correctAnswer: "Competition from cheap imports.
    })
  },
  {
    id: G12-GEO-IND-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Industry and Manufacturing,
    subtopic: "Food Processing in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Food processing is a growing industry in Kenya, driven by agriculture. Which of the following is a major food processing product in Kenya?,
      options: [Processed tea and coffee, Processed meat, Processed grains", "Processed dairy].sort(() => Math.random() - 0.5),
      correctAnswer: Processed tea and coffee"
    })
  },
  {
    id: "G12-GEO-IND-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Industry and Manufacturing",
    subtopic: "Industrial Location in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Many industries in Kenya are concentrated in and around major cities. Why are most industries located in urban areas?,
      options: [Access to markets, labor, and infrastructure., Lower land costs., "Better climate., Abundance of raw materials."].sort(() => Math.random() - 0.5),
      correctAnswer: "Access to markets, labor, and infrastructure.
    })
  },

  // --- MADA: TOURISM (4 Materials) ---
  {
    id: G12-GEO-TOU-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Tourism,
    subtopic: "Tourism in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tourism is a major contributor to Kenya's economy. What is the main attraction for tourists visiting Kenya?,
      options: [Wildlife, national parks, and beaches., Mountains and glaciers., Desert landscapes.", "Industrial cities.].sort(() => Math.random() - 0.5),
      correctAnswer: Wildlife, national parks, and beaches."
    })
  },
  {
    id: "G12-GEO-TOU-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Tourism",
    subtopic: "Tourism in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kenya has numerous national parks and game reserves. Which of the following is a famous national park in Kenya?,
      options: [Maasai Mara National Reserve, Tsavo National Park, "Samburu National Reserve, All of the above"].sort(() => Math.random() - 0.5),
      correctAnswer: "All of the above
    })
  },
  {
    id: G12-GEO-TOU-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Tourism,
    subtopic: "Tourism in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Tourism provides employment and income for many Kenyans. What is one challenge facing the tourism industry in Kenya?,
      options: [Seasonal variation and security concerns., High demand., Abundance of accommodation.", "Good infrastructure.].sort(() => Math.random() - 0.5),
      correctAnswer: Seasonal variation and security concerns."
    })
  },
  {
    id: "G12-GEO-TOU-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Tourism",
    subtopic: "Tourism in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Sustainable tourism aims to minimize the negative impacts of tourism. What is one way to achieve sustainable tourism in Kenya?,
      options: [Promoting eco-tourism and community-based tourism., Increasing mass tourism., "Allowing unlimited visitors to national parks., Ignoring environmental concerns."].sort(() => Math.random() - 0.5),
      correctAnswer: "Promoting eco-tourism and community-based tourism.
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G12-GEO-TRA-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Transport and Communication,
    subtopic: "The Role of Transport in Kenya's Economy",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Transport networks are crucial for the movement of goods and people in Kenya. Which mode of transport is most important for moving exports to international markets?,
      options: [Rail transport, Road transport, Air transport", "Water transport].sort(() => Math.random() - 0.5),
      correctAnswer: Rail transport"
    })
  },
  {
    id: "G12-GEO-TRA-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Transport and Communication",
    subtopic: "The Role of Transport in Kenya's Economy,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The transport sector faces several challenges in Kenya. Which of the following is a major challenge facing road transport in Kenya?,
      options: [Poor road conditions and traffic congestion., Excellent road conditions., "Low traffic volume., High funding for roads."].sort(() => Math.random() - 0.5),
      correctAnswer: "Poor road conditions and traffic congestion.
    })
  },
  {
    id: G12-GEO-TRA-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Transport and Communication,
    subtopic: "The Role of Communication in Kenya's Economy",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Communication networks have revolutionized Kenya's economy, especially through mobile technology. What is the main economic impact of mobile money services like M-Pesa in Kenya?,
      options: [Financial inclusion and ease of transactions., Decreased use of mobile phones., Increased use of cash.", "Reduced economic activity.].sort(() => Math.random() - 0.5),
      correctAnswer: Financial inclusion and ease of transactions."
    })
  },
  {
    id: "G12-GEO-TRA-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Transport and Communication",
    subtopic: "The Role of Communication in Kenya's Economy,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "What is the main advantage of using rail transport for freight in Kenya?,
      options: [It is cheaper for bulky goods and more environmentally friendly., It is faster than air transport., "It reaches every remote village., It is the only mode of transport available."].sort(() => Math.random() - 0.5),
      correctAnswer: "It is cheaper for bulky goods and more environmentally friendly.
    })
  },

  // --- MADA: POPULATION GEOGRAPHY (4 Materials) ---
  {
    id: G12-GEO-POP-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Population Geography,
    subtopic: "Population Distribution in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Population distribution in Kenya is uneven, with more people in some regions than others. Which region of Kenya has the highest population density?,
      options: [The central highlands and western Kenya., The northern region., The coastal region.", "The eastern region.].sort(() => Math.random() - 0.5),
      correctAnswer: The central highlands and western Kenya."
    })
  },
  {
    id: "G12-GEO-POP-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Population Geography",
    subtopic: "Population Structure in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Kenya has a young population structure with a high proportion of people under 25. What is a benefit of having a young population?,
      options: [A large workforce and potential for economic growth., High dependency ratio., "Low demand for schools., Low demand for jobs."].sort(() => Math.random() - 0.5),
      correctAnswer: "A large workforce and potential for economic growth.
    })
  },
  {
    id: G12-GEO-POP-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Population Geography,
    subtopic: "Population Dynamics in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Population dynamics include birth rates, death rates, and migration. What is the current trend of Kenya's population growth rate?,
      options: [High but declining., Very low., Stable.", "Negative.].sort(() => Math.random() - 0.5),
      correctAnswer: High but declining."
    })
  },
  {
    id: "G12-GEO-POP-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Population Geography",
    subtopic: "Population Dynamics in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Urbanization is closely linked to population growth in Kenya. What is the main driver of urban population growth in Kenya?,
      options: [Rural-to-urban migration., Low birth rates., "High death rates., Stable population."].sort(() => Math.random() - 0.5),
      correctAnswer: "Rural-to-urban migration.
    })
  },

  // --- MADA: URBANIZATION (4 Materials) ---
  {
    id: G12-GEO-URB-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Urbanization,
    subtopic: "Urban Growth in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Urbanization in Kenya has accelerated in recent decades. Which city is the largest urban center in Kenya?,
      options: [Nairobi, Mombasa, Kisumu", "Nakuru].sort(() => Math.random() - 0.5),
      correctAnswer: Nairobi"
    })
  },
  {
    id: "G12-GEO-URB-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Urbanization",
    subtopic: "Urban Growth in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Rapid urbanization in Kenya has led to several challenges. What is one of the main problems associated with rapid urbanization in Nairobi?,
      options: [Traffic congestion and inadequate housing., Low population density., "Abundant green spaces., Excellent infrastructure."].sort(() => Math.random() - 0.5),
      correctAnswer: "Traffic congestion and inadequate housing.
    })
  },
  {
    id: G12-GEO-URB-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Urbanization,
    subtopic: "Urban Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Urban planning is essential for sustainable urban growth in Kenya. What is one key principle of urban planning?,
      options: [Provision of adequate infrastructure and green spaces., Allowing uncontrolled urban sprawl., Ignoring the needs of the poor.", "Prioritizing private vehicles.].sort(() => Math.random() - 0.5),
      correctAnswer: Provision of adequate infrastructure and green spaces."
    })
  },
  {
    id: "G12-GEO-URB-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Urbanization",
    subtopic: "Urban Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "What is the role of the government in managing urbanization in Kenya?,
      options: [To enforce urban planning policies and invest in public infrastructure., To ignore urban problems., "To discourage migration to cities., To focus only on rural development."].sort(() => Math.random() - 0.5),
      correctAnswer: "To enforce urban planning policies and invest in public infrastructure.
    })
  },

  // --- MADA: ENVIRONMENTAL MANAGEMENT (4 Materials) ---
  {
    id: G12-GEO-ENV-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Environmental Management,
    subtopic: "Environmental Degradation in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Environmental degradation is a major challenge in Kenya. What is one of the main causes of environmental degradation in the country?,
      options: [Deforestation and pollution., Afforestation., Conservation efforts.", "Tree planting campaigns.].sort(() => Math.random() - 0.5),
      correctAnswer: Deforestation and pollution."
    })
  },
  {
    id: "G12-GEO-ENV-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Environmental Management",
    subtopic: "Pollution in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Pollution, including air, water, and land pollution, is a growing problem in Kenya. What is the main source of water pollution in Kenyan rivers?,
      options: ["Industrial waste and agricultural runoff., Clean water sources.", "Protected rivers., Untouched forests."].sort(() => Math.random() - 0.5),
      correctAnswer: "Industrial waste and agricultural runoff.
    })
  },
  {
    id: G12-GEO-ENV-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Environmental Management,
    subtopic: "Conservation in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Conservation efforts are essential to protect Kenya's rich biodiversity. What is one major conservation success story in Kenya?,
      options: [The revival of elephant and rhino populations through anti-poaching measures., The extinction of wildlife., The overpopulation of animals.", "The destruction of national parks.].sort(() => Math.random() - 0.5),
      correctAnswer: The revival of elephant and rhino populations through anti-poaching measures."
    })
  },
  {
    id: "G12-GEO-ENV-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Environmental Management",
    subtopic: "Conservation in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Sustainable development is an important goal in Kenya. How does the concept of sustainability apply to natural resource management?,
      options: [Using resources in a way that meets present needs without compromising future generations., Exploiting resources as quickly as possible., "Ignoring environmental concerns., Focusing only on economic growth."].sort(() => Math.random() - 0.5),
      correctAnswer: "Using resources in a way that meets present needs without compromising future generations.
    })
  },

  // --- MADA: SUSTAINABLE DEVELOPMENT (4 Materials) ---
  {
    id: G12-GEO-SUS-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Sustainable Development,
    subtopic: "Sustainable Use of Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Sustainable development aims to balance economic growth with environmental protection. What is an example of a sustainable practice in resource use?,
      options: [Using renewable energy sources like solar and wind power., Depleting non-renewable resources., Burning fossil fuels.", "Clearing forests for agriculture.].sort(() => Math.random() - 0.5),
      correctAnswer: Using renewable energy sources like solar and wind power."
    })
  },
  {
    id: "G12-GEO-SUS-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Sustainable Development",
    subtopic: "Renewable Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kenya is a leader in renewable energy in Africa. Which of the following is a major renewable energy source in Kenya?,
      options: [Geothermal power, Coal, "Oil, Natural gas"].sort(() => Math.random() - 0.5),
      correctAnswer: "Geothermal power
    })
  },
  {
    id: G12-GEO-SUS-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Sustainable Development,
    subtopic: "Renewable Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Wind energy is another growing renewable energy sector in Kenya. Which region of Kenya is known for its large wind power projects?,
      options: [Turkana, Nairobi, Mombasa", "Kisumu].sort(() => Math.random() - 0.5),
      correctAnswer: Turkana"
    })
  },
  {
    id: "G12-GEO-SUS-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Sustainable Development",
    subtopic: "Sustainable Development Policies,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "The Kenyan government has implemented several policies to promote sustainable development. What is one of the main environmental policies in Kenya?,
      options: [The Environmental Management and Coordination Act (EMCA)., The Economic Growth Act., "The Industrial Expansion Act., The Agricultural Development Act."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Environmental Management and Coordination Act (EMCA).
    })
  },

  // --- MADA: NATURAL HAZARDS (4 Materials) ---
  {
    id: G12-GEO-HAZ-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Natural Hazards,
    subtopic: "Droughts",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Droughts are a recurrent natural hazard in Kenya. What is the main cause of drought in Kenya?,
      options: [Failure of rains and climate variability., Excessive rainfall., Low temperatures.", "High humidity.].sort(() => Math.random() - 0.5),
      correctAnswer: Failure of rains and climate variability."
    })
  },
  {
    id: "G12-GEO-HAZ-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Natural Hazards",
    subtopic: "Floods,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Floods are another natural hazard that affects parts of Kenya. What is the main cause of flooding in Kenya?,
      options: [Heavy rainfall and overflowing rivers., Drought., "Low rainfall., High temperatures."].sort(() => Math.random() - 0.5),
      correctAnswer: "Heavy rainfall and overflowing rivers.
    })
  },
  {
    id: G12-GEO-HAZ-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Natural Hazards,
    subtopic: "Landslides",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Landslides can occur in some regions of Kenya, particularly on steep slopes. What is a common trigger of landslides in Kenya?,
      options: [Heavy rainfall and deforestation., Earthquakes., Volcanic activity.", "High winds.].sort(() => Math.random() - 0.5),
      correctAnswer: Heavy rainfall and deforestation."
    })
  },
  {
    id: "G12-GEO-HAZ-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Natural Hazards",
    subtopic: "Management of Natural Hazards,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Managing natural hazards requires both preventive and responsive measures. What is one way to manage the impact of drought in Kenya?,
      options: [Water conservation and rainwater harvesting., Burning forests., "Overgrazing land., Ignoring the problem."].sort(() => Math.random() - 0.5),
      correctAnswer: "Water conservation and rainwater harvesting.
    })
  },

  // --- MADA: MAP WORK (4 Materials) ---
  {
    id: G12-GEO-MAP-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Map Work,
    subtopic: "Reading Topographical Maps",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Topographical maps show detailed information about the landscape. What does a contour line on a topographical map represent?,
      options: [A line connecting points of equal elevation., A river., A road.", "A railway line.].sort(() => Math.random() - 0.5),
      correctAnswer: A line connecting points of equal elevation."
    })
  },
  {
    id: "G12-GEO-MAP-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Map Work",
    subtopic: "Reading Topographical Maps,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A map legend is used to interpret the symbols on a map. What is the purpose of the map legend?,
      options: [It explains the meaning of the symbols used on the map., It shows the map title., "It indicates the scale of the map., It shows the direction of the map."].sort(() => Math.random() - 0.5),
      correctAnswer: "It explains the meaning of the symbols used on the map.
    })
  },
  {
    id: G12-GEO-MAP-03",
    grade: "Grade 12,
    subject: Geography",
    topic: "Map Work,
    subtopic: "Drawing Cross-sections",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Drawing a cross-section is an important skill in map work. What is the first step in drawing a cross-section from a topographical map?,
      options: [Choosing the line of the cross-section on the map., Drawing the horizontal axis., Plotting the contour lines.", "Calculating the vertical exaggeration.].sort(() => Math.random() - 0.5),
      correctAnswer: Choosing the line of the cross-section on the map."
    })
  },
  {
    id: "G12-GEO-MAP-04",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Map Work",
    subtopic: "Drawing Cross-sections,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Vertical exaggeration is often used when drawing cross-sections. How do you calculate vertical exaggeration?,
      options: [By dividing the vertical scale by the horizontal scale., By multiplying the vertical scale by the horizontal scale., "By adding the vertical and horizontal scales., By subtracting the vertical scale from the horizontal scale."].sort(() => Math.random() - 0.5),
      correctAnswer: "By dividing the vertical scale by the horizontal scale.
    })
  },

  // --- MADA: GEOGRAPHICAL SKILLS (2 Materials) ---
  {
    id: G12-GEO-SKI-01",
    grade: "Grade 12,
    subject: Geography",
    topic: "Geographical Skills,
    subtopic: "Research Methods in Geography",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Research methods in geography involve collecting and analyzing data about the environment. What is an example of a primary research method in geography?,
      options: [Fieldwork and surveys., Reading textbooks., Analyzing secondary data.", "Watching documentaries.].sort(() => Math.random() - 0.5),
      correctAnswer: Fieldwork and surveys."
    })
  },
  {
    id: "G12-GEO-SKI-02",
    grade: "Grade 12",
    subject: "Geography",
    topic: "Geographical Skills",
    subtopic: "Fieldwork in Geography,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Fieldwork is an essential component of geographical education. Why is fieldwork important in geography?,
      options: [It allows students to apply theoretical knowledge to real-world settings., It is only for fun., "It is not necessary., It is optional."].sort(() => Math.random() - 0.5),
      correctAnswer: "It allows students to apply theoretical knowledge to real-world settings."
    })
  }

];


