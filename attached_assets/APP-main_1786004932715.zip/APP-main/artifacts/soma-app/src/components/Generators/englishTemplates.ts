export const englishTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (Based on KICD Syllabus Topics)
  // =========================================================================

  // --- SUBJECT: ENGLISH | TOPIC: NOUNS (7 Materials) ---
  {
    id: "G1-ENG-NOU-01",
    grade: "Grade 1",
    subject: "English",
    topic: "Nouns",
    subtopic: "People at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: "Which of the following words names a person who lives with you at home and cooks your meals?,
      options: [Mother, Table, "School, Dog"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mother
    })
  },
  {
    id: G1-ENG-NOU-02",
    grade: "Grade 1,
    subject: English",
    topic: "Nouns,
    subtopic: "People at School",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which word names the person who stands at the front of the class and teaches you every day?,
      options: [Teacher, Chair, Pencil", "Cup].sort(() => Math.random() - 0.5),
      correctAnswer: Teacher"
    })
  },
  {
    id: "G1-ENG-NOU-03",
    grade: "Grade 1",
    subject: "English",
    topic: "Nouns",
    subtopic: "People in the Community,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "A man who wears a uniform, directs traffic, and keeps the town safe is called what?,
      options: ["Police Officer, Book", "Tree, Ball"].sort(() => Math.random() - 0.5),
      correctAnswer: "Police Officer
    })
  },
  {
    id: G1-ENG-NOU-04",
    grade: "Grade 1,
    subject: English",
    topic: "Nouns,
    subtopic: "Animals on the Farm",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which farm animal gives us milk and makes a 'moo' sound?,
      options: [Cow, Lion, Bird", "Snake].sort(() => Math.random() - 0.5),
      correctAnswer: Cow"
    })
  },
  {
    id: "G1-ENG-NOU-05",
    grade: "Grade 1",
    subject: "English",
    topic: "Nouns",
    subtopic: "Animals in the Wild,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which large wild animal is known for hunting in the jungle and is called the 'King of Beasts'?,
      options: [Lion, Cat, "Goat, Sheep"].sort(() => Math.random() - 0.5),
      correctAnswer: "Lion
    })
  },
  {
    id: G1-ENG-NOU-06",
    grade: "Grade 1,
    subject: English",
    topic: "Nouns,
    subtopic: "Objects at Home",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Which object found at home is used for sitting down at the dining table?,
      options: [Chair, School, Dog", "Plate].sort(() => Math.random() - 0.5),
      correctAnswer: Chair"
    })
  },
  {
    id: "G1-ENG-NOU-07",
    grade: "Grade 1",
    subject: "English",
    topic: "Nouns",
    subtopic: "Objects at School,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which tool found in the classroom is used for writing and drawing on paper?,
      options: [Pencil, Bed, "Shoe, Hat"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pencil
    })
  },

  // --- SUBJECT: ENGLISH | topic: "VERBS (7 Materials) ---
  {
    id: G1-ENG-VER-01",
    grade: "Grade 1,
    subject: English",
    topic: "Verbs,
    subtopic: "Physical Actions",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " Which word describes the action of moving your legs quickly to get somewhere faster?,
      options: [Running, Sitting, Eating", "Sleeping].sort(() => Math.random() - 0.5),
      correctAnswer: Running"
    })
  },
  {
    id: "G1-ENG-VER-02",
    grade: "Grade 1",
    subject: "English",
    topic: "Verbs",
    subtopic: "Physical Actions,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which word describes the action of taking in food through your mouth?,
      options: [Eating, Drinking, "Reading, Writing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Eating
    })
  },
  {
    id: G1-ENG-VER-03",
    grade: "Grade 1,
    subject: English",
    topic: "Verbs,
    subtopic: "School Actions",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " Which verb describes what you do when you look at a book and understand the words?,
      options: [Reading, Swimming, Dancing", "Singing].sort(() => Math.random() - 0.5),
      correctAnswer: Reading"
    })
  },
  {
    id: "G1-ENG-VER-04",
    grade: "Grade 1",
    subject: "English",
    topic: "Verbs",
    subtopic: "School Actions,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which word describes the action of putting words on paper using a pencil?,
      options: [Writing, Walking, "Talking, Drawing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Writing
    })
  },
  {
    id: G1-ENG-VER-05",
    grade: "Grade 1,
    subject: English",
    topic: "Verbs,
    subtopic: "Movements",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " What word describes moving from one place to another by putting one foot in front of the other?,
      options: [Walking, Crying, Laughing", "Talking].sort(() => Math.random() - 0.5),
      correctAnswer: Walking"
    })
  },
  {
    id: "G1-ENG-VER-06",
    grade: "Grade 1",
    subject: "English",
    topic: "Verbs",
    subtopic: "Emotions,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "When you are happy and find something very funny, what action do you do with your mouth?,
      options: [Laughing, Crying", "Sleeping, Kicking"].sort(() => Math.random() - 0.5),
      correctAnswer: "Laughing
    })
  },
  {
    id: G1-ENG-VER-07",
    grade: "Grade 1,
    subject: English",
    topic: "Verbs,
    subtopic: "Daily Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Every morning, what do you do to your face and hands to make them clean before breakfast?,
      options: [Washing, Running, Jumping", "Drawing].sort(() => Math.random() - 0.5),
      correctAnswer: Washing"
    })
  },

  // --- SUBJECT: ENGLISH | TOPIC: PREPOSITIONS (7 Materials) ---
  {
    id: "G1-ENG-PRE-01",
    grade: "Grade 1",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Position (In),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => ({
      text: "The pencil is _____ the pencil case. Which word correctly fills the blank to show the pencil is placed inside?,
      options: [in, on, "under, above"].sort(() => Math.random() - 0.5),
      correctAnswer: "in
    })
  },
  {
    id: G1-ENG-PRE-02",
    grade: "Grade 1,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (On)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " The book is resting _____ the table. Which word shows the book is placed on top of the table?,
      options: [on, under, behind", "near].sort(() => Math.random() - 0.5),
      correctAnswer: on"
    })
  },
  {
    id: "G1-ENG-PRE-03",
    grade: "Grade 1",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Position (Under),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "The cat is sleeping _____ the bed because it wants to be hidden. Which word shows the cat is beneath the bed?,
      options: [under, above, "in, on"].sort(() => Math.random() - 0.5),
      correctAnswer: "under
    })
  },
  {
    id: G1-ENG-PRE-04",
    grade: "Grade 1,
    subject: English",
    topic: "Prepositions,
    subtopic: "Location (Near)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The shop is _____ our school, so we can walk there very quickly. Which word means close to?,
      options: [near, far, inside", "over].sort(() => Math.random() - 0.5),
      correctAnswer: near"
    })
  },
  {
    id: "G1-ENG-PRE-05",
    grade: "Grade 1",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Location (At),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "We will meet _____ the bus stop after school. Which word shows the specific place where you will stand?,
      options: [at, on, "in, under"].sort(() => Math.random() - 0.5),
      correctAnswer: "at
    })
  },
  {
    id: G1-ENG-PRE-06",
    grade: "Grade 1,
    subject: English",
    topic: "Prepositions,
    subtopic: "Direction (To)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " We are walking _____ the market to buy vegetables. Which word shows the direction we are heading?,
      options: [to, from, behind", "above].sort(() => Math.random() - 0.5),
      correctAnswer: to"
    })
  },
  {
    id: "G1-ENG-PRE-07",
    grade: "Grade 1",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Direction (From),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The bus came _____ Mombasa and stopped in Nairobi. Which word shows the starting point of the journey?,
      options: [from, to, "on, under"].sort(() => Math.random() - 0.5),
      correctAnswer: "from
    })
  },

  // --- SUBJECT: ENGLISH | topic: "PLURALS (7 Materials) ---
  {
    id: G1-ENG-PLU-01",
    grade: "Grade 1,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 's' to Words",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " If you have ONE pen, and you get three more, how do you write the word for 'many pens'?,
      options: [pens, pen, penss", "pens].sort(() => Math.random() - 0.5),
      correctAnswer: pens"
    })
  },
  {
    id: "G1-ENG-PLU-02",
    grade: "Grade 1",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 's' to Words,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "If there is ONE dog in the yard, and three more come, what is the correct word for 'many dogs'?,
      options: ["dogs, dog", "doges, dog"].sort(() => Math.random() - 0.5),
      correctAnswer: "dogs
    })
  },
  {
    id: G1-ENG-PLU-03",
    grade: "Grade 1,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 's' to Words",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " There is one book on the shelf, but the teacher put four more there. How do you spell 'many books'?,
      options: [books, book, books", "bookes].sort(() => Math.random() - 0.5),
      correctAnswer: books"
    })
  },
  {
    id: "G1-ENG-PLU-04",
    grade: "Grade 1",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 'es' to Words,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "A word that ends with 'x' needs 'es' to show many. If you have one box, how do you spell the plural of 'box'?,
      options: [boxes, box", "boxs, boxez"].sort(() => Math.random() - 0.5),
      correctAnswer: "boxes
    })
  },
  {
    id: G1-ENG-PLU-05",
    grade: "Grade 1,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 'es' to Words",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The word 'brush' needs 'es' when there is more than one. What is the correct plural spelling?,
      options: [brushes, brush,  brushs", "brushez].sort(() => Math.random() - 0.5),
      correctAnswer: brushes"
    })
  },
  {
    id: "G1-ENG-PLU-06",
    grade: "Grade 1",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 'es' to Words,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The word 'match' also needs 'es' for the plural. Which is the correct spelling for many matches?,
      options: [matches, match, "matchs, mathez"].sort(() => Math.random() - 0.5),
      correctAnswer: "matches
    })
  },
  {
    id: G1-ENG-PLU-07",
    grade: "Grade 1,
    subject: English",
    topic: "Plurals,
    subtopic: "Irregular Plurals",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Some words change completely. If there is one child at the park, and five join, what is the word for many children?,
      options: [children, childs, children", "child].sort(() => Math.random() - 0.5),
      correctAnswer: children"
    })
  },

  // --- SUBJECT: ENGLISH | TOPIC: READING COMPREHENSION (7 Materials) ---
  {
    id: "G1-ENG-RDC-01",
    grade: "Grade 1",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Reading Short Passages,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Read this passage: 'Jane is a girl. She loves to eat apples. She eats an apple every day.' What does Jane love to eat?,
      options: [Apples, Bananas, "Oranges, Grapes"].sort(() => Math.random() - 0.5),
      correctAnswer: "Apples
    })
  },
  {
    id: G1-ENG-RDC-02",
    grade: "Grade 1,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Reading Short Passages",
    maxUses: 5,
    usageCount: 0,
    minWords: 32,
    generate: () => ({
      text: " Read: 'The sun is hot today. It is shining brightly in the blue sky. The birds are singing.' What is the weather like today?,
      options: [Hot and sunny, Cold and rainy, Windy", "Snowing].sort(() => Math.random() - 0.5),
      correctAnswer: Hot and sunny"
    })
  },
  {
    id: "G1-ENG-RDC-03",
    grade: "Grade 1",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Reading Short Passages,
    maxUses: 5,
    usageCount: 0,
    minWords: 31,",
    generate: () => ({
      text: "Read this: 'My friend Kofi has a red bicycle. He rides it to school. He parks it under a big tree.' Where does Kofi park his bicycle?,
      options: [Under a tree, In his room, "By the gate, On the roof"].sort(() => Math.random() - 0.5),
      correctAnswer: "Under a tree
    })
  },
  {
    id: G1-ENG-RDC-04",
    grade: "Grade 1,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Finding Details",
    maxUses: 5,
    usageCount: 0,
    minWords: 34,
    generate: () => ({
      text: " Read: 'Amina has a green bag. She puts her books inside. She carries her bag on her back.' What color is Amina's bag?,
      options: [Green, Blue, Red", "Yellow].sort(() => Math.random() - 0.5),
      correctAnswer: Green"
    })
  },
  {
    id: "G1-ENG-RDC-05",
    grade: "Grade 1",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Finding Details,
    maxUses: 5,
    usageCount: 0,
    minWords: 33,",
    generate: () => ({
      text: "Read this: 'The dog is brown. It is running fast in the park. It chases a small ball.' What is the dog chasing?,
      options: [A ball, A cat, "A car, A bike"].sort(() => Math.random() - 0.5),
      correctAnswer: "A ball
    })
  },
  {
    id: G1-ENG-RDC-06",
    grade: "Grade 1,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Character Identification",
    maxUses: 5,
    usageCount: 0,
    minWords: 36,
    generate: () => ({
      text: " Read this story: 'The lazy cat slept all day. It did not want to hunt for mice. The farmer was not happy with the cat.' Who is the main character in this story?,
      options: [The cat, The dog, The farmer", "The mouse].sort(() => Math.random() - 0.5),
      correctAnswer: The cat"
    })
  },
  {
    id: "G1-ENG-RDC-07",
    grade: "Grade 1",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Sequencing Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 38,",
    generate: () => ({
      text: "Read this: 'First, John woke up. Then, he brushed his teeth. Finally, he ate his breakfast and went to school.' What did John do first?,
      options: ["He woke up, He brushed his teeth", "He ate breakfast, He went to school"].sort(() => Math.random() - 0.5),
      correctAnswer: "He woke up
    })
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (Based on KICD Syllabus Topics)
  // =========================================================================

  // --- SUBJECT: ENGLISH | topic: "NOUNS (7 Materials) ---
  {
    id: G2-ENG-NOU-01",
    grade: "Grade 2,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns: People",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which of the following is a specific name given to a particular boy?,
      options: [Peter, The boy, My friend", "A child].sort(() => Math.random() - 0.5),
      correctAnswer: Peter"
    })
  },
  {
    id: "G2-ENG-NOU-02",
    grade: "Grade 2",
    subject: "English",
    topic: "Nouns",
    subtopic: "Proper Nouns: Places,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which of the following is the proper name of a city in Kenya?,
      options: [Nairobi, City, "Town, Village"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nairobi
    })
  },
  {
    id: G2-ENG-NOU-03",
    grade: "Grade 2,
    subject: English",
    topic: "Nouns,
    subtopic: "Common Nouns: Places",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Which word names a place where you go to learn new things?,
      options: [School, Home, Market", "Park].sort(() => Math.random() - 0.5),
      correctAnswer: School"
    })
  },
  {
    id: "G2-ENG-NOU-04",
    grade: "Grade 2",
    subject: "English",
    topic: "Nouns",
    subtopic: "Common Nouns: Things,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which common noun describes a piece of furniture you sit on at the dining table?,
      options: [Chair, Table, "Bed, Door"].sort(() => Math.random() - 0.5),
      correctAnswer: "Chair
    })
  },
  {
    id: G2-ENG-NOU-05",
    grade: "Grade 2,
    subject: English",
    topic: "Nouns,
    subtopic: "Common Nouns: Animals",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which common noun names a small animal that flies and makes a buzzing sound?,
      options: [Bee, Bird, Lion", "Fish].sort(() => Math.random() - 0.5),
      correctAnswer: Bee"
    })
  },
  {
    id: "G2-ENG-NOU-06",
    grade: "Grade 2",
    subject: "English",
    topic: "Nouns",
    subtopic: "Common Nouns: Food,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which common noun names a yellow fruit that monkeys love to eat?,
      options: [Banana, Mango, "Orange, Apple"].sort(() => Math.random() - 0.5),
      correctAnswer: "Banana
    })
  },
  {
    id: G2-ENG-NOU-07",
    grade: "Grade 2,
    subject: English",
    topic: "Nouns,
    subtopic: "Naming Words",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Which word is a naming word for a tool used to write on a blackboard?,
      options: [Chalk, Pencil, Pen", "Marker].sort(() => Math.random() - 0.5),
      correctAnswer: Chalk"
    })
  },

  // --- SUBJECT: ENGLISH | TOPIC: VERBS (7 Materials) ---
  {
    id: "G2-ENG-VER-01",
    grade: "Grade 2",
    subject: "English",
    topic: "Verbs",
    subtopic: "Past Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Yesterday, I ___ a beautiful song in class. Which word correctly fills the blank to show the action is finished?,
      options: [sang, sing", "sings, singing"].sort(() => Math.random() - 0.5),
      correctAnswer: "sang
    })
  },
  {
    id: G2-ENG-VER-02",
    grade: "Grade 2,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Last week, my father ___ a car for our family. Which word shows the action happened in the past?,
      options: [bought, buy, buys", "buying].sort(() => Math.random() - 0.5),
      correctAnswer: bought"
    })
  },
  {
    id: "G2-ENG-VER-03",
    grade: "Grade 2",
    subject: "English",
    topic: "Verbs",
    subtopic: "Present Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Today, we ___ our lunch in the classroom. Which word shows the action happening right now?,
      options: [eat, ate", "eaten, eating"].sort(() => Math.random() - 0.5),
      correctAnswer: "eat
    })
  },
  {
    id: G2-ENG-VER-04",
    grade: "Grade 2,
    subject: English",
    topic: "Verbs,
    subtopic: "Present Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Every morning, the sun ___ in the east. Which verb correctly completes the sentence?,
      options: [rises, rose, rising", "rise].sort(() => Math.random() - 0.5),
      correctAnswer: rises"
    })
  },
  {
    id: "G2-ENG-VER-05",
    grade: "Grade 2",
    subject: "English",
    topic: "Verbs",
    subtopic: "Physical Actions,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which word describes the physical action of throwing a ball high into the air?,
      options: [Toss, Catch, "Walk, Sit"].sort(() => Math.random() - 0.5),
      correctAnswer: "Toss
    })
  },
  {
    id: G2-ENG-VER-06",
    grade: "Grade 2,
    subject: English",
    topic: "Verbs,
    subtopic: "School Actions",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which verb describes the action of raising your hand to answer a question in class?,
      options: [Raise, Run, Draw", "Sweep].sort(() => Math.random() - 0.5),
      correctAnswer: Raise"
    })
  },
  {
    id: "G2-ENG-VER-07",
    grade: "Grade 2",
    subject: "English",
    topic: "Verbs",
    subtopic: "Daily Activities,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "What do you do with a broom to clean the floor of your classroom?,
      options: [Sweep, Wash, "Wipe, Scrub"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sweep
    })
  },

  // --- SUBJECT: ENGLISH | topic: "PREPOSITIONS (7 Materials) ---
  {
    id: G2-ENG-PRE-01",
    grade: "Grade 2,
    subject: English",
    topic: "Prepositions,
    subtopic: "Direction (To)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " We are going ___ the park to play. Which word shows the direction we are moving?,
      options: [to, from, in", "on].sort(() => Math.random() - 0.5),
      correctAnswer: to"
    })
  },
  {
    id: "G2-ENG-PRE-02",
    grade: "Grade 2",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Direction (From),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "I received a letter ___ my friend in Mombasa. Which word correctly shows the source of the letter?,
      options: [from, to, "in, at"].sort(() => Math.random() - 0.5),
      correctAnswer: "from
    })
  },
  {
    id: G2-ENG-PRE-03",
    grade: "Grade 2,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (Near)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The school is ___ my house, so I can walk there easily. Which word shows that it is close?,
      options: [near, far, over", "under].sort(() => Math.random() - 0.5),
      correctAnswer: near"
    })
  },
  {
    id: "G2-ENG-PRE-04",
    grade: "Grade 2",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Position (Between),
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "My desk is ___ Mary's desk and John's desk. Which word correctly describes this middle position?,
      options: [between, near, "under, on"].sort(() => Math.random() - 0.5),
      correctAnswer: "between
    })
  },
  {
    id: G2-ENG-PRE-05",
    grade: "Grade 2,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (On)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The picture was hung ___ the wall. Which word correctly shows where it was placed?,
      options: [on, in, under", "above].sort(() => Math.random() - 0.5),
      correctAnswer: on"
    })
  },
  {
    id: "G2-ENG-PRE-06",
    grade: "Grade 2",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Position (In),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The milk is kept ___ the refrigerator to keep it cool. Which word shows it's placed inside?,
      options: [in, on, "under, behind"].sort(() => Math.random() - 0.5),
      correctAnswer: "in
    })
  },
  {
    id: G2-ENG-PRE-07",
    grade: "Grade 2,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (Behind)",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " He hid ___ the door so nobody could see him. Which word shows the hiding position?,
      options: [behind, in, under", "above].sort(() => Math.random() - 0.5),
      correctAnswer: behind"
    })
  },

  // --- SUBJECT: ENGLISH | TOPIC: PLURALS (7 Materials) ---
  {
    id: "G2-ENG-PLU-01",
    grade: "Grade 2",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 'es' (Words ending in ch),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The word 'bunch' ends with 'ch'. If you have more than one bunch, what is the correct plural spelling?,
      options: [bunches, bunch", "bunchs, bunchez"].sort(() => Math.random() - 0.5),
      correctAnswer: "bunches
    })
  },
  {
    id: G2-ENG-PLU-02",
    grade: "Grade 2,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 'es' (Words ending in sh)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The word 'brush' ends with 'sh'. What is the correct plural spelling?,
      options: [brushes, brush, brushs", "brushez].sort(() => Math.random() - 0.5),
      correctAnswer: brushes"
    })
  },
  {
    id: "G2-ENG-PLU-03",
    grade: "Grade 2",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 'es' (Words ending in x),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The word 'fox' ends with 'x'. If you see many foxes, what is the correct plural word?,
      options: [foxes, fox", "foxs, foxez"].sort(() => Math.random() - 0.5),
      correctAnswer: "foxes
    })
  },
  {
    id: G2-ENG-PLU-04",
    grade: "Grade 2,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 'es' (Words ending in s)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The word 'bus' ends with 's'. If there are many buses on the road, what is the correct plural spelling?,
      options: [buses, bus, buss", "busez].sort(() => Math.random() - 0.5),
      correctAnswer: buses"
    })
  },
  {
    id: "G2-ENG-PLU-05",
    grade: "Grade 2",
    subject: "English",
    topic: "Plurals",
    subtopic: "Adding 's' (Regular words),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "The word 'book' is regular. If you have many books, how do you spell the plural?,
      options: [books, book", "bookes, bookez"].sort(() => Math.random() - 0.5),
      correctAnswer: "books
    })
  },
  {
    id: G2-ENG-PLU-06",
    grade: "Grade 2,
    subject: English",
    topic: "Plurals,
    subtopic: "Adding 's' (Regular words)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The word 'tree' is regular. What is the correct plural spelling for many trees?,
      options: [trees, tree, trees", "treez].sort(() => Math.random() - 0.5),
      correctAnswer: trees"
    })
  },
  {
    id: "G2-ENG-PLU-07",
    grade: "Grade 2",
    subject: "English",
    topic: "Plurals",
    subtopic: "Irregular Plurals,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The word 'man' changes completely when talking about many. What is the correct plural for more than one man?,
      options: [men, mans, "manz, men"].sort(() => Math.random() - 0.5),
      correctAnswer: "men
    })
  },

  // --- SUBJECT: ENGLISH | topic: "READING COMPREHENSION (7 Materials) ---
  {
    id: G2-ENG-RDC-01",
    grade: "Grade 2,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Reading Passages",
    maxUses: 5,
    usageCount: 0,
    minWords: 32,
    generate: () => ({
      text: " Read this: 'Kenya is a beautiful country. It has many animals. The lion is the king of the animals.' What animal is called the king?,
      options: [Lion, Elephant, Giraffe", "Zebra].sort(() => Math.random() - 0.5),
      correctAnswer: Lion"
    })
  },
  {
    id: "G2-ENG-RDC-02",
    grade: "Grade 2",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Reading Passages,
    maxUses: 5,
    usageCount: 0,
    minWords: 33,",
    generate: () => ({
      text: "Read this: 'Mama went to the market. She bought some vegetables. She also bought fruits for the children.' What did Mama buy for the children?,
      options: [Fruits, Vegetables, "Meat, Fish"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fruits
    })
  },
  {
    id: G2-ENG-RDC-03",
    grade: "Grade 2,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Reading Passages",
    maxUses: 5,
    usageCount: 0,
    minWords: 31,
    generate: () => ({
      text: " Read: 'The cat is sleeping on the mat. It is tired. It sleeps all day.' What is the cat doing?,
      options: [Sleeping, Running, Playing", "Eating].sort(() => Math.random() - 0.5),
      correctAnswer: Sleeping"
    })
  },
  {
    id: "G2-ENG-RDC-04",
    grade: "Grade 2",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Reading Passages,
    maxUses: 5,
    usageCount: 0,
    minWords: 35,",
    generate: () => ({
      text: "Read this story: 'Peter is a lazy boy. He does not like to do his homework. He watches TV all day. His teacher is very angry.' Who is the lazy boy?,
      options: [Peter, John, "Mark, Paul"].sort(() => Math.random() - 0.5),
      correctAnswer: "Peter
    })
  },
  {
    id: G2-ENG-RDC-05",
    grade: "Grade 2,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Reading Passages",
    maxUses: 5,
    usageCount: 0,
    minWords: 34,
    generate: () => ({
      text: " Read: 'The market is very busy today. Many people are buying food. The farmers are selling fresh maize.' Who is selling fresh maize?,
      options: [Farmers, Teachers, Students", "Doctors].sort(() => Math.random() - 0.5),
      correctAnswer: Farmers"
    })
  },
  {
    id: "G2-ENG-RDC-06",
    grade: "Grade 2",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Reading Passages,
    maxUses: 5,
    usageCount: 0,
    minWords: 36,",
    generate: () => ({
      text: "Read the passage: 'The sky is blue. The clouds are white. The sun is shining brightly. It is a very beautiful day.' What color is the sky?,
      options: [Blue, White, "Red, Yellow"].sort(() => Math.random() - 0.5),
      correctAnswer: "Blue
    })
  },
  {
    id: G2-ENG-RDC-07",
    grade: "Grade 2,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Reading Passages",
    maxUses: 5,
    usageCount: 0,
    minWords: 38,
    generate: () => ({
      text: " Read: 'The train is fast. It carries many passengers. It travels from Nairobi to Mombasa every day.' Where does the train travel to?,
      options: [Mombasa, Kisumu, Nakuru", "Eldoret].sort(() => Math.random() - 0.5),
      correctAnswer: Mombasa"
    })
  }
  // =========================================================================
  // GRADE 3: 35 MATERIALS (KICD ENGLISH SYLLABUS)
  // =========================================================================

  // --- TOPIC: NOUNS (7 Materials) ---
  {
    id: "G3-ENG-NOU-01",
    grade: "Grade 3",
    subject: "English",
    topic: "Nouns",
    subtopic: "Common Nouns in the Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which of these is a common noun you would find in a forest?,
      options: [Tree, Hospital, "Classroom, Market"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tree
    })
  },
  {
    id: G3-ENG-NOU-02",
    grade: "Grade 3,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns in Daily Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which of these is a specific proper noun for a well-known lake in Kenya?,
      options: [Lake Victoria, Lake, Water", "River].sort(() => Math.random() - 0.5),
      correctAnswer: Lake Victoria"
    })
  },
  {
    id: "G3-ENG-NOU-03",
    grade: "Grade 3",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "A group of students learning together in a class is called a ___?,
      options: [Class, Team, "Family, Herd"].sort(() => Math.random() - 0.5),
      correctAnswer: "Class
    })
  },
  {
    id: G3-ENG-NOU-04",
    grade: "Grade 3,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which of these nouns describes a feeling that you cannot physically touch?,
      options: [Happiness, Table, Chair", "Book].sort(() => Math.random() - 0.5),
      correctAnswer: Happiness"
    })
  },
  {
    id: "G3-ENG-NOU-05",
    grade: "Grade 3",
    subject: "English",
    topic: "Nouns",
    subtopic: "Places,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which noun names a place where you buy fresh fruits and vegetables?,
      options: [Market, School, "Library, Church"].sort(() => Math.random() - 0.5),
      correctAnswer: "Market
    })
  },
  {
    id: G3-ENG-NOU-06",
    grade: "Grade 3,
    subject: English",
    topic: "Nouns,
    subtopic: "Animal Names",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Which of these nouns is the name of a large grey animal found in the savannah?,
      options: [Elephant, Lion, Zebra", "Snake].sort(() => Math.random() - 0.5),
      correctAnswer: Elephant"
    })
  },
  {
    id: "G3-ENG-NOU-07",
    grade: "Grade 3",
    subject: "English",
    topic: "Nouns",
    subtopic: "Objects at Home,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which noun identifies a machine used for cooking food at home?,
      options: [Stove, Bed, "Sofa, Television"].sort(() => Math.random() - 0.5),
      correctAnswer: "Stove
    })
  },

  // --- topic: "VERBS (7 Materials) ---
  {
    id: G3-ENG-VER-01",
    grade: "Grade 3,
    subject: English",
    topic: "Verbs,
    subtopic: "Verbs of Movement",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Which verb describes the action of moving quickly using your legs?,
      options: [Run, Walk, Sit", "Sleep].sort(() => Math.random() - 0.5),
      correctAnswer: Run"
    })
  },
  {
    id: "G3-ENG-VER-02",
    grade: "Grade 3",
    subject: "English",
    topic: "Verbs",
    subtopic: "Verbs of Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which verb describes the action of speaking to someone in a normal voice?,
      options: [Talk, Shout, "Whisper, Sing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Talk
    })
  },
  {
    id: G3-ENG-VER-03",
    grade: "Grade 3,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Tense Actions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Yesterday, my mother ____ a delicious meal for the family. What is the correct past tense verb?,
      options: [cooked, cook, cooks", "cooking].sort(() => Math.random() - 0.5),
      correctAnswer: cooked"
    })
  },
  {
    id: "G3-ENG-VER-04",
    grade: "Grade 3",
    subject: "English",
    topic: "Verbs",
    subtopic: "Present Tense Actions,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Every day, the sun ____ bright and early. What is the correct present tense verb?,
      options: [rises, rose", "rising, rise"].sort(() => Math.random() - 0.5),
      correctAnswer: "rises
    })
  },
  {
    id: G3-ENG-VER-05",
    grade: "Grade 3,
    subject: English",
    topic: "Verbs,
    subtopic: "Verbs of the Senses",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which verb describes using your eyes to observe something?,
      options: [Look, Listen, Taste", "Touch].sort(() => Math.random() - 0.5),
      correctAnswer: Look"
    })
  },
  {
    id: "G3-ENG-VER-06",
    grade: "Grade 3",
    subject: "English",
    topic: "Verbs",
    subtopic: "Helping Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which helping verb correctly completes this sentence? 'I ____ going to school tomorrow.',
      options: [am, is, "are, was"].sort(() => Math.random() - 0.5),
      correctAnswer: "am
    })
  },
  {
    id: G3-ENG-VER-07",
    grade: "Grade 3,
    subject: English",
    topic: "Verbs,
    subtopic: "Action Verbs at School",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which verb describes what you do when you use a pen to make words on paper?,
      options: [Write, Read, Draw", "Paint].sort(() => Math.random() - 0.5),
      correctAnswer: Write"
    })
  },

  // --- TOPIC: PREPOSITIONS (7 Materials) ---
  {
    id: "G3-ENG-PRE-01",
    grade: "Grade 3",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Location (At),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "We will meet ____ the bus stop after school. Which preposition correctly shows the location?,
      options: [at, on, "in, under"].sort(() => Math.random() - 0.5),
      correctAnswer: "at
    })
  },
  {
    id: G3-ENG-PRE-02",
    grade: "Grade 3,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (In)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The milk is kept ____ the fridge to keep it cold. Which preposition is correct?,
      options: [in, on, under", "over].sort(() => Math.random() - 0.5),
      correctAnswer: in"
    })
  },
  {
    id: "G3-ENG-PRE-03",
    grade: "Grade 3",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Position (On),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The book is resting ____ the table. Which preposition is correct for showing it's on top?,
      options: [on, under, "behind, near"].sort(() => Math.random() - 0.5),
      correctAnswer: "on
    })
  },
  {
    id: G3-ENG-PRE-04",
    grade: "Grade 3,
    subject: English",
    topic: "Prepositions,
    subtopic: "Position (Under)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " The cat is hiding ____ the table because it is scared. Which preposition shows it's beneath?,
      options: [under, above, on", "in].sort(() => Math.random() - 0.5),
      correctAnswer: under"
    })
  },
  {
    id: "G3-ENG-PRE-05",
    grade: "Grade 3",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Direction,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "We are walking ____ the market to buy vegetables. Which preposition shows the direction?,
      options: [to, from, "in, at"].sort(() => Math.random() - 0.5),
      correctAnswer: "to
    })
  },
  {
    id: G3-ENG-PRE-06",
    grade: "Grade 3,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Source",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " I got a present ____ my aunt on my birthday. Which preposition shows where it came from?,
      options: [from, to, in", "on].sort(() => Math.random() - 0.5),
      correctAnswer: from"
    })
  },
  {
    id: "G3-ENG-PRE-07",
    grade: "Grade 3",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "I will meet you ____ the morning. Which preposition is used for time?,
      options: [in, on, "at, for"].sort(() => Math.random() - 0.5),
      correctAnswer: "in
    })
  },

  // --- topic: "PLURALS (7 Materials) ---
  {
    id: G3-ENG-PLU-01",
    grade: "Grade 3,
    subject: English",
    topic: "Plurals,
    subtopic: "Regular Plurals (Add 's')",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " The plural of the word 'cup' is ____?,
      options: [cups, cupes, cupps", "cup].sort(() => Math.random() - 0.5),
      correctAnswer: cups"
    })
  },
  {
    id: "G3-ENG-PLU-02",
    grade: "Grade 3",
    subject: "English",
    topic: "Plurals",
    subtopic: "Plurals Ending in 'es' (s, sh, ch, x),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "The plural of the word 'bus' is ____?,
      options: [buses, buss, "bus, busez"].sort(() => Math.random() - 0.5),
      correctAnswer: "buses
    })
  },
  {
    id: G3-ENG-PLU-03",
    grade: "Grade 3,
    subject: English",
    topic: "Plurals,
    subtopic: "Plurals Ending in 'es'",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " What is the plural form of 'watch'?,
      options: [watches, watchs, watch", "watchez].sort(() => Math.random() - 0.5),
      correctAnswer: watches"
    })
  },
  {
    id: "G3-ENG-PLU-04",
    grade: "Grade 3",
    subject: "English",
    topic: "Plurals",
    subtopic: "Regular Plurals (Add 's'),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "What is the plural of 'cat'?,
      options: [cats, cates, "cat, catz"].sort(() => Math.random() - 0.5),
      correctAnswer: "cats
    })
  },
  {
    id: G3-ENG-PLU-05",
    grade: "Grade 3,
    subject: English",
    topic: "Plurals,
    subtopic: "Regular Plurals (Add 's')",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " What is the plural form of 'dog'?,
      options: [dogs, doge, dog", "dogz].sort(() => Math.random() - 0.5),
      correctAnswer: dogs"
    })
  },
  {
    id: "G3-ENG-PLU-06",
    grade: "Grade 3",
    subject: "English",
    topic: "Plurals",
    subtopic: "Irregular Plurals,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The plural form of 'child' is ____?,
      options: [children, childs, "child, childz"].sort(() => Math.random() - 0.5),
      correctAnswer: "children
    })
  },
  {
    id: G3-ENG-PLU-07",
    grade: "Grade 3,
    subject: English",
    topic: "Plurals,
    subtopic: "Irregular Plurals",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " The plural form of 'man' is ____?,
      options: [men, mans, man", "manz].sort(() => Math.random() - 0.5),
      correctAnswer: men"
    })
  },

  // --- TOPIC: ADJECTIVES (7 Materials) ---
  {
    id: "G3-ENG-ADJ-01",
    grade: "Grade 3",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Size,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which adjective describes the size of something very huge?,
      options: [Large, Small, "Tiny, Short"].sort(() => Math.random() - 0.5),
      correctAnswer: "Large
    })
  },
  {
    id: G3-ENG-ADJ-02",
    grade: "Grade 3,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Color",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " What color adjective describes a clear sky during the day?,
      options: [Blue, Red, Green", "Black].sort(() => Math.random() - 0.5),
      correctAnswer: Blue"
    })
  },
  {
    id: "G3-ENG-ADJ-03",
    grade: "Grade 3",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Shape,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Which adjective describes a ball that is perfectly round?,
      options: [Circular, Square, "Triangle, Rectangle"].sort(() => Math.random() - 0.5),
      correctAnswer: "Circular
    })
  },
  {
    id: G3-ENG-ADJ-04",
    grade: "Grade 3,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quality",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which adjective describes a student who works hard in class?,
      options: [Hardworking, Lazy, Sleepy", "Naughty].sort(() => Math.random() - 0.5),
      correctAnswer: Hardworking"
    })
  },
  {
    id: "G3-ENG-ADJ-05",
    grade: "Grade 3",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quantity,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which adjective shows that there is a very large number of items?,
      options: [Many, Few, "One, None"].sort(() => Math.random() - 0.5),
      correctAnswer: "Many
    })
  },
  {
    id: G3-ENG-ADJ-06",
    grade: "Grade 3,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Feeling",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which adjective describes a person who is feeling very sad?,
      options: [Sad, Happy, Angry", "Excited].sort(() => Math.random() - 0.5),
      correctAnswer: Sad"
    })
  },
  {
    id: "G3-ENG-ADJ-07",
    grade: "Grade 3",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Comparison,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which adjective correctly compares two things? 'My house is ____ than yours.',
      options: [Bigger, Big, "Biggest, Very big"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bigger
    })
  },

  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD ENGLISH SYLLABUS)
  // =========================================================================

  // --- topic: "NOUNS (7 Materials) ---
  {
    id: G4-ENG-NOU-01",
    grade: "Grade 4,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which of these is a proper noun naming a major river in Kenya?,
      options: [River Tana, River, Water", "Lake].sort(() => Math.random() - 0.5),
      correctAnswer: River Tana"
    })
  },
  {
    id: "G4-ENG-NOU-02",
    grade: "Grade 4",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What do you call a large group of fish swimming together?,
      options: [School, Herd, "Flock, Pack"].sort(() => Math.random() - 0.5),
      correctAnswer: "School
    })
  },
  {
    id: G4-ENG-NOU-03",
    grade: "Grade 4,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which noun describes the feeling of being very brave?,
      options: [Courage, Fear, Anger", "Joy].sort(() => Math.random() - 0.5),
      correctAnswer: Courage"
    })
  },
  {
    id: "G4-ENG-NOU-04",
    grade: "Grade 4",
    subject: "English",
    topic: "Nouns",
    subtopic: "Common Nouns in Nature,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "What common noun identifies a large body of water surrounded by land?,
      options: [Lake, Ocean, "River, Sea"].sort(() => Math.random() - 0.5),
      correctAnswer: "Lake
    })
  },
  {
    id: G4-ENG-NOU-05",
    grade: "Grade 4,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which of these is a compound noun made from two words?,
      options: [Rainbow, Dog, House", "Sun].sort(() => Math.random() - 0.5),
      correctAnswer: Rainbow"
    })
  },
  {
    id: "G4-ENG-NOU-06",
    grade: "Grade 4",
    subject: "English",
    topic: "Nouns",
    subtopic: "Nouns in the Community,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which noun names a place where you can borrow books for free?,
      options: [Library, Market, "School, Hospital"].sort(() => Math.random() - 0.5),
      correctAnswer: "Library
    })
  },
  {
    id: G4-ENG-NOU-07",
    grade: "Grade 4,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns in Everyday Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which is a proper noun for a very well-known mountain in Kenya?,
      options: [Mount Kilimanjaro, Hill, Rock", "Stone].sort(() => Math.random() - 0.5),
      correctAnswer: Mount Kilimanjaro"
    })
  },

  // --- TOPIC: VERBS (7 Materials) ---
  {
    id: "G4-ENG-VER-01",
    grade: "Grade 4",
    subject: "English",
    topic: "Verbs",
    subtopic: "Regular Past Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Yesterday, we ____ to the market to buy food. (Add the correct past tense of 'walk'),
      options: [walked, walk", "walks, walking"].sort(() => Math.random() - 0.5),
      correctAnswer: "walked
    })
  },
  {
    id: G4-ENG-VER-02",
    grade: "Grade 4,
    subject: English",
    topic: "Verbs,
    subtopic: "Irregular Past Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Last week, I ____ a new book to read. (Correct past tense of 'buy'),
      options: [bought, buy, buys", "buying].sort(() => Math.random() - 0.5),
      correctAnswer: bought"
    })
  },
  {
    id: "G4-ENG-VER-03",
    grade: "Grade 4",
    subject: "English",
    topic: "Verbs",
    subtopic: "Present Continuous Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Right now, the children ____ on the playground. (Correct form of 'play'),
      options: [are playing, play", "played, plays"].sort(() => Math.random() - 0.5),
      correctAnswer: "are playing
    })
  },
  {
    id: G4-ENG-VER-04",
    grade: "Grade 4,
    subject: English",
    topic: "Verbs,
    subtopic: "Future Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Tomorrow, we ____ to the zoo. (Correct future tense of 'go'),
      options: [will go, went, go", "going].sort(() => Math.random() - 0.5),
      correctAnswer: will go"
    })
  },
  {
    id: "G4-ENG-VER-05",
    grade: "Grade 4",
    subject: "English",
    topic: "Verbs",
    subtopic: "Action Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which verb describes the action of using your ears to hear something?,
      options: [Listen, See, "Smell, Touch"].sort(() => Math.random() - 0.5),
      correctAnswer: "Listen
    })
  },
  {
    id: G4-ENG-VER-06",
    grade: "Grade 4,
    subject: English",
    topic: "Verbs,
    subtopic: "State Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which verb describes a state of knowing something?,
      options: [Know, Run, Jump", "Swim].sort(() => Math.random() - 0.5),
      correctAnswer: Know"
    })
  },
  {
    id: "G4-ENG-VER-07",
    grade: "Grade 4",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "The man ____ his car. (Select the correct phrasal verb meaning 'enter'),
      options: [got into, ran out, "jumped over, sat on"].sort(() => Math.random() - 0.5),
      correctAnswer: "got into
    })
  },

  // --- topic: "ADJECTIVES (7 Materials) ---
  {
    id: G4-ENG-ADJ-01",
    grade: "Grade 4,
    subject: English",
    topic: "Adjectives,
    subtopic: "Comparative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which is the correct comparative form? 'This book is ____ than that one.',
      options: [better, good, best", "more good].sort(() => Math.random() - 0.5),
      correctAnswer: better"
    })
  },
  {
    id: "G4-ENG-ADJ-02",
    grade: "Grade 4",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Superlative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which is the superlative form? 'She is the ____ student in the class.',
      options: [smartest, smart, "smarter, more smart"].sort(() => Math.random() - 0.5),
      correctAnswer: "smartest
    })
  },
  {
    id: G4-ENG-ADJ-03",
    grade: "Grade 4,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quantity",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which adjective shows that there is no food left?,
      options: [Enough, Some, Any", "Much].sort(() => Math.random() - 0.5),
      correctAnswer: Enough"
    })
  },
  {
    id: "G4-ENG-ADJ-04",
    grade: "Grade 4",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Possessive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "This is ____ book. (Select the possessive adjective for 'I'),
      options: [my, your, "his, her"].sort(() => Math.random() - 0.5),
      correctAnswer: "my
    })
  },
  {
    id: G4-ENG-ADJ-05",
    grade: "Grade 4,
    subject: English",
    topic: "Adjectives,
    subtopic: "Demonstrative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " ____ book is very interesting. (Select the demonstrative adjective for something nearby),
      options: [This, That, Those", "These].sort(() => Math.random() - 0.5),
      correctAnswer: This"
    })
  },
  {
    id: "G4-ENG-ADJ-06",
    grade: "Grade 4",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which adjective expresses a positive opinion about something?,
      options: [Great, Bad, "Terrible, Awful"].sort(() => Math.random() - 0.5),
      correctAnswer: "Great
    })
  },
  {
    id: G4-ENG-ADJ-07",
    grade: "Grade 4,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Temperature",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which adjective describes a very cold object?,
      options: [Frozen, Warm, Hot", "Boiling].sort(() => Math.random() - 0.5),
      correctAnswer: Frozen"
    })
  },

  // --- TOPIC: READING COMPREHENSION (7 Materials) ---
  {
    id: "G4-ENG-RDC-01",
    grade: "Grade 4",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Understanding Main Idea,
    maxUses: 5,
    usageCount: 0,
    minWords: 45,",
    generate: () => ({
      text: "Read the passage: 'Kenya is a wonderful country in East Africa. It has beautiful beaches in Mombasa and snow-capped mountains in the central region. Many tourists visit to see the wildlife.' What is the main idea of this passage?,
      options: [Kenya is a country with many attractions., Tourists are rich., "Mombasa is a city., Mountains are cold."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya is a country with many attractions.
    })
  },
  {
    id: G4-ENG-RDC-02",
    grade: "Grade 4,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Finding Supporting Details",
    maxUses: 5,
    usageCount: 0,
    minWords: 40,
    generate: () => ({
      text: " Read the passage: 'Amani went to the market. He bought a kilogram of tomatoes. He also purchased a bunch of green bananas. He was happy with his shopping.' What did Amani buy at the market?,
      options: [Tomatoes and bananas, Rice and beans, Bread and milk", "Sugar and tea].sort(() => Math.random() - 0.5),
      correctAnswer: Tomatoes and bananas"
    })
  },
  {
    id: "G4-ENG-RDC-03",
    grade: "Grade 4",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Character Traits,
    maxUses: 5,
    usageCount: 0,
    minWords: 43,",
    generate: () => ({
      text: "Read: 'The old farmer worked very hard every day. He woke up early to water his crops. Even in the rain, he was in the farm.' What best describes the farmer's character?,
      options: [Hardworking, Lazy", "Sleepy, Weak"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hardworking
    })
  },
  {
    id: G4-ENG-RDC-04",
    grade: "Grade 4,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Comparing and Contrasting",
    maxUses: 5,
    usageCount: 0,
    minWords: 45,
    generate: () => ({
      text: " Read: 'Kenyans love both football and athletics. However, athletics is mostly done in the rural areas, while football is played in the cities.' How are the two sports different?,
      options: [Athletics is rural, football is urban., Both are played in the same places., Football is played in rivers.", "Athletics is for the rich.].sort(() => Math.random() - 0.5),
      correctAnswer: Athletics is rural, football is urban."
    })
  },
  {
    id: "G4-ENG-RDC-05",
    grade: "Grade 4",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Predicting Outcomes,
    maxUses: 5,
    usageCount: 0,
    minWords: 44,",
    generate: () => ({
      text: "Read: 'The sky turned grey. The wind began to blow. The clouds were getting heavier.' What is most likely to happen next?,
      options: [It will rain, The sun will shine, "The sky will go red, The wind will stop"].sort(() => Math.random() - 0.5),
      correctAnswer: "It will rain
    })
  },
  {
    id: G4-ENG-RDC-06",
    grade: "Grade 4,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Inferring Meaning",
    maxUses: 5,
    usageCount: 0,
    minWords: 46,
    generate: () => ({
      text: " Read: 'The class was very noisy. The teacher walked in and looked around. At once, the class became quiet.' What does the word 'looked around' infer?,
      options: [The teacher was checking the room, The teacher was sleeping, The teacher was talking to the cook", "The teacher was at home].sort(() => Math.random() - 0.5),
      correctAnswer: The teacher was checking the room"
    })
  },
  {
    id: "G4-ENG-RDC-07",
    grade: "Grade 4",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Sequencing Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Read: 'First, Mother boiled the water. Then, she added the tea leaves. After a while, she poured the tea into cups.' What did Mother do after she added the tea leaves?,
      options: ["She poured the tea into cups., She boiled the water.", "She drank the tea., She bought the leaves."].sort(() => Math.random() - 0.5),
      correctAnswer: "She poured the tea into cups.
    })
  }
  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD ENGLISH SYLLABUS)
  // =========================================================================

  // --- topic: "NOUNS (7 Materials) ---
  {
    id: G5-ENG-NOU-01",
    grade: "Grade 5,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which of the following is an abstract noun that represents a feeling of fear?,
      options: [Fear, Table, Chair", "Book].sort(() => Math.random() - 0.5),
      correctAnswer: Fear"
    })
  },
  {
    id: "G5-ENG-NOU-02",
    grade: "Grade 5",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What collective noun is used for a group of lions?,
      options: [Pride, Herd, "Flock, Pack"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pride
    })
  },
  {
    id: G5-ENG-NOU-03",
    grade: "Grade 5,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which is a proper noun for a famous city in Kenya located by the Indian Ocean?,
      options: [Mombasa, City, Town", "Village].sort(() => Math.random() - 0.5),
      correctAnswer: Mombasa"
    })
  },
  {
    id: "G5-ENG-NOU-04",
    grade: "Grade 5",
    subject: "English",
    topic: "Nouns",
    subtopic: "Compound Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which of these is a compound noun made from two smaller words?,
      options: [Rainbow, Forest, "Mountain, River"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rainbow
    })
  },
  {
    id: G5-ENG-NOU-05",
    grade: "Grade 5,
    subject: English",
    topic: "Nouns,
    subtopic: "Gender Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " What is the masculine gender noun for 'queen'?,
      options: [King, Prince, Lord", "Duke].sort(() => Math.random() - 0.5),
      correctAnswer: King"
    })
  },
  {
    id: "G5-ENG-NOU-06",
    grade: "Grade 5",
    subject: "English",
    topic: "Nouns",
    subtopic: "Pluralization of Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "What is the plural form of the noun 'potato'?,
      options: [Potatoes, Potatos, "Potato, Potatos"].sort(() => Math.random() - 0.5),
      correctAnswer: "Potatoes
    })
  },
  {
    id: G5-ENG-NOU-07",
    grade: "Grade 5,
    subject: English",
    topic: "Nouns,
    subtopic: "Common Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which is a common noun used to describe a place of worship?,
      options: [Church, Nairobi, Clinic", "School].sort(() => Math.random() - 0.5),
      correctAnswer: Church"
    })
  },

  // --- TOPIC: VERBS (7 Materials) ---
  {
    id: "G5-ENG-VER-01",
    grade: "Grade 5",
    subject: "English",
    topic: "Verbs",
    subtopic: "Action Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which verb describes the action of preparing food by heating it?,
      options: [Cooking, Walking, "Running, Sleeping"].sort(() => Math.random() - 0.5),
      correctAnswer: "Cooking
    })
  },
  {
    id: G5-ENG-VER-02",
    grade: "Grade 5,
    subject: English",
    topic: "Verbs,
    subtopic: "Transitive and Intransitive Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which sentence uses a transitive verb that needs an object?,
      options: [She ate an apple., She slept., The baby cried.", "The bird flew.].sort(() => Math.random() - 0.5),
      correctAnswer: She ate an apple."
    })
  },
  {
    id: "G5-ENG-VER-03",
    grade: "Grade 5",
    subject: "English",
    topic: "Verbs",
    subtopic: "Past Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct past tense of the verb 'write' in this sentence? 'She ____ a letter yesterday.',
      options: [wrote, write, "writen, writes"].sort(() => Math.random() - 0.5),
      correctAnswer: "wrote
    })
  },
  {
    id: G5-ENG-VER-04",
    grade: "Grade 5,
    subject: English",
    topic: "Verbs,
    subtopic: "Present Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Select the correct present perfect tense: 'She ____ to China twice.',
      options: [has been, went, go", "goes].sort(() => Math.random() - 0.5),
      correctAnswer: has been"
    })
  },
  {
    id: "G5-ENG-VER-05",
    grade: "Grade 5",
    subject: "English",
    topic: "Verbs",
    subtopic: "Future Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct future tense: 'They ____ the match on Sunday.',
      options: [will play, played, "plays, play"].sort(() => Math.random() - 0.5),
      correctAnswer: "will play
    })
  },
  {
    id: G5-ENG-VER-06",
    grade: "Grade 5,
    subject: English",
    topic: "Verbs,
    subtopic: "Auxiliary Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which auxiliary verb correctly fills the blank? 'You ____ finish your homework before playing.',
      options: [must, can, will", "may].sort(() => Math.random() - 0.5),
      correctAnswer: must"
    })
  },
  {
    id: "G5-ENG-VER-07",
    grade: "Grade 5",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Select the phrasal verb that means 'to stop sleeping':,
      options: [Wake up, Break down, "Give in, Hold on"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wake up
    })
  },

  // --- topic: "ADJECTIVES (7 Materials) ---
  {
    id: G5-ENG-ADJ-01",
    grade: "Grade 5,
    subject: English",
    topic: "Adjectives,
    subtopic: "Descriptive Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which adjective describes a very tall tree?,
      options: [Enormous, Small, Tiny", "Short].sort(() => Math.random() - 0.5),
      correctAnswer: Enormous"
    })
  },
  {
    id: "G5-ENG-ADJ-02",
    grade: "Grade 5",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Comparative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the comparative form of 'pretty'?,
      options: [Prettier, Pretty, "Prettiest, More pretty"].sort(() => Math.random() - 0.5),
      correctAnswer: "Prettier
    })
  },
  {
    id: G5-ENG-ADJ-03",
    grade: "Grade 5,
    subject: English",
    topic: "Adjectives,
    subtopic: "Superlative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Select the superlative form: 'The ____ runner won the gold medal.',
      options: [fastest, fast, faster", "more fast].sort(() => Math.random() - 0.5),
      correctAnswer: fastest"
    })
  },
  {
    id: "G5-ENG-ADJ-04",
    grade: "Grade 5",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Possessive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Complete the sentence: 'This is ____ book.' (Using possessive for 'I'),
      options: [my, your, "his, her"].sort(() => Math.random() - 0.5),
      correctAnswer: "my
    })
  },
  {
    id: G5-ENG-ADJ-05",
    grade: "Grade 5,
    subject: English",
    topic: "Adjectives,
    subtopic: "Demonstrative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Select the demonstrative adjective: '____ shoes are very clean.' (Pointing at the shoes nearby),
      options: [These, Those, This", "That].sort(() => Math.random() - 0.5),
      correctAnswer: These"
    })
  },
  {
    id: "G5-ENG-ADJ-06",
    grade: "Grade 5",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quantity,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Which adjective shows that there is a small number of items?,
      options: [Few, Many, "Some, All"].sort(() => Math.random() - 0.5),
      correctAnswer: "Few
    })
  },
  {
    id: G5-ENG-ADJ-07",
    grade: "Grade 5,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Opinion",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which adjective describes a movie that is very funny?,
      options: [Entertaining, Sad, Boring", "Dull].sort(() => Math.random() - 0.5),
      correctAnswer: Entertaining"
    })
  },

  // --- TOPIC: PREPOSITIONS (7 Materials) ---
  {
    id: "G5-ENG-PRE-01",
    grade: "Grade 5",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Place,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The cat is sleeping ____ the couch. Which preposition correctly completes the sentence?,
      options: [on, under, "beside, between"].sort(() => Math.random() - 0.5),
      correctAnswer: "on
    })
  },
  {
    id: G5-ENG-PRE-02",
    grade: "Grade 5,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Movement",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " She walked ____ the store to buy milk. Which preposition shows movement?,
      options: [to, on, under", "between].sort(() => Math.random() - 0.5),
      correctAnswer: to"
    })
  },
  {
    id: "G5-ENG-PRE-03",
    grade: "Grade 5",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "I will meet you ____ 3 PM. Which preposition is for a specific time?,
      options: [at, on, "in, from"].sort(() => Math.random() - 0.5),
      correctAnswer: "at
    })
  },
  {
    id: G5-ENG-PRE-04",
    grade: "Grade 5,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Source",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " I got a letter ____ my uncle. Which preposition shows the source?,
      options: [from, to, on", "by].sort(() => Math.random() - 0.5),
      correctAnswer: from"
    })
  },
  {
    id: "G5-ENG-PRE-05",
    grade: "Grade 5",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Direction,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "The birds flew ____ the nest. Which preposition shows direction?,
      options: [out of, into, "over, through"].sort(() => Math.random() - 0.5),
      correctAnswer: "out of
    })
  },
  {
    id: G5-ENG-PRE-06",
    grade: "Grade 5,
    subject: English",
    topic: "Prepositions,
    subtopic: "Complex Prepositions",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " She walked ____ the street. (Select the complex preposition),
      options: [across, at, in", "by].sort(() => Math.random() - 0.5),
      correctAnswer: across"
    })
  },
  {
    id: "G5-ENG-PRE-07",
    grade: "Grade 5",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Purpose,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "She went to the hospital ____ medical attention. Which preposition indicates purpose?,
      options: [for, to, "in, on"].sort(() => Math.random() - 0.5),
      correctAnswer: "for
    })
  },

  // --- topic: "READING COMPREHENSION (7 Materials) ---
  {
    id: G5-ENG-RDC-01",
    grade: "Grade 5,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Understanding Character",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Read: 'Mr. Tito was a kind farmer. He loved animals. He cared for the cows and fed them every day.' What can you say about Mr. Tito?,
      options: [He is kind and hardworking., He is angry., He is lazy.", "He is sick.].sort(() => Math.random() - 0.5),
      correctAnswer: He is kind and hardworking."
    })
  },
  {
    id: "G5-ENG-RDC-02",
    grade: "Grade 5",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Finding the Main Idea,
    maxUses: 5,
    usageCount: 0,
    minWords: 52,",
    generate: () => ({
      text: "Read this passage: 'Nairobi is the capital city of Kenya. It has tall buildings and busy roads. Many people come to Nairobi to work and study.' What is the main idea of the passage?,
      options: [Nairobi is a busy and important city., Nairobi has a beautiful river., "Nairobi is the smallest city., Nairobi has a big airport."].sort(() => Math.random() - 0.5),
      correctAnswer: "Nairobi is a busy and important city.
    })
  },
  {
    id: G5-ENG-RDC-03",
    grade: "Grade 5,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Inferring Meaning",
    maxUses: 5,
    usageCount: 0,
    minWords: 48,
    generate: () => ({
      text: " Read: 'The room was completely dark. She reached for her torch, but the batteries were dead. She sat silently in the corner.' Why did she sit silently?,
      options: [She was scared because it was dark., She was sleeping., She was watching TV.", "She was eating.].sort(() => Math.random() - 0.5),
      correctAnswer: She was scared because it was dark."
    })
  },
  {
    id: "G5-ENG-RDC-04",
    grade: "Grade 5",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Fact and Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Read the sentence: 'Lake Victoria is the largest lake in Africa. It is also the most beautiful lake in the world.' Which part is a fact?,
      options: [Lake Victoria is the largest lake in Africa., It is the most beautiful lake., "It is the coldest lake., It is a lake in Europe."].sort(() => Math.random() - 0.5),
      correctAnswer: "Lake Victoria is the largest lake in Africa.
    })
  },
  {
    id: G5-ENG-RDC-05",
    grade: "Grade 5,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Predicting Outcomes",
    maxUses: 5,
    usageCount: 0,
    minWords: 45,
    generate: () => ({
      text: " Read: 'The sky grew dark and heavy clouds appeared. The wind began to howl. The leaves on the trees rustled loudly.' What is most likely going to happen next?,
      options: [It will rain heavily., The sun will come out., It will snow.", "The birds will sing.].sort(() => Math.random() - 0.5),
      correctAnswer: It will rain heavily."
    })
  },
  {
    id: "G5-ENG-RDC-06",
    grade: "Grade 5",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Identifying Cause and Effect,
    maxUses: 5,
    usageCount: 0,
    minWords: 48,",
    generate: () => ({
      text: "Read: 'Because the road was muddy, the bus got stuck. The passengers had to push the bus to get it moving again.' Why did the bus get stuck?,
      options: [Because the road was muddy., Because the driver was tired.", "Because it was raining., Because the engine broke."].sort(() => Math.random() - 0.5),
      correctAnswer: "Because the road was muddy.
    })
  },
  {
    id: G5-ENG-RDC-07",
    grade: "Grade 5,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Moral of a Story",
    maxUses: 5,
    usageCount: 0,
    minWords: 52,
    generate: () => ({
      text: " Read: 'The young boy was very clever. He saved his village from a drought by building a dam. He taught everyone to work together.' What is the moral of this story?,
      options: [Working together solves problems., Fighting is good., Water is not important.", "Money is the only solution.].sort(() => Math.random() - 0.5),
      correctAnswer: Working together solves problems."
    })
  },

  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD ENGLISH SYLLABUS)
  // =========================================================================

  // --- TOPIC: NOUNS (7 Materials) ---
  {
    id: "G6-ENG-NOU-01",
    grade: "Grade 6",
    subject: "English",
    topic: "Nouns",
    subtopic: "Abstract Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What abstract noun describes the state of being faithful to your country?,
      options: [Patriotism, Fear, "Anger, Joy"].sort(() => Math.random() - 0.5),
      correctAnswer: "Patriotism
    })
  },
  {
    id: G6-ENG-NOU-02",
    grade: "Grade 6,
    subject: English",
    topic: "Nouns,
    subtopic: "Collective Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " What collective noun is used to describe a group of sheep?,
      options: [Flock, Herd, Pack", "Pride].sort(() => Math.random() - 0.5),
      correctAnswer: Flock"
    })
  },
  {
    id: "G6-ENG-NOU-03",
    grade: "Grade 6",
    subject: "English",
    topic: "Nouns",
    subtopic: "Proper Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which is a proper noun for the second-longest river in Kenya?,
      options: [River Athi, River, "Lake, Water"].sort(() => Math.random() - 0.5),
      correctAnswer: "River Athi
    })
  },
  {
    id: G6-ENG-NOU-04",
    grade: "Grade 6,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which compound noun is made from the words 'butter' and 'fly'?,
      options: [Butterfly, Butter, Fly", "Butterfly].sort(() => Math.random() - 0.5),
      correctAnswer: Butterfly"
    })
  },
  {
    id: "G6-ENG-NOU-05",
    grade: "Grade 6",
    subject: "English",
    topic: "Nouns",
    subtopic: "Gender Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "What is the feminine gender noun for 'waiter'?,
      options: [Waitress, Waitress, "Waiter, Wait"].sort(() => Math.random() - 0.5),
      correctAnswer: "Waitress
    })
  },
  {
    id: G6-ENG-NOU-06",
    grade: "Grade 6,
    subject: English",
    topic: "Nouns,
    subtopic: "Common Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which is a common noun for an individual who teaches in a classroom?,
      options: [Teacher, Nairobi, Clinic", "Car].sort(() => Math.random() - 0.5),
      correctAnswer: Teacher"
    })
  },
  {
    id: "G6-ENG-NOU-07",
    grade: "Grade 6",
    subject: "English",
    topic: "Nouns",
    subtopic: "Pluralization of Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct plural form of 'cactus'?,
      options: [Cacti, Cactuses, "Cacti, Cactus"].sort(() => Math.random() - 0.5),
      correctAnswer: "Cacti
    })
  },

  // --- topic: "VERBS (7 Materials) ---
  {
    id: G6-ENG-VER-01",
    grade: "Grade 6,
    subject: English",
    topic: "Verbs,
    subtopic: "Transitive vs Intransitive",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which sentence has a transitive verb that requires an object?,
      options: [She gave a gift., She cried., He sleeps.", "The bird sang.].sort(() => Math.random() - 0.5),
      correctAnswer: She gave a gift."
    })
  },
  {
    id: "G6-ENG-VER-02",
    grade: "Grade 6",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Select the phrasal verb that means 'to take care of'.,
      options: [Look after, Run into, "Give up, Sit down"].sort(() => Math.random() - 0.5),
      correctAnswer: "Look after
    })
  },
  {
    id: G6-ENG-VER-03",
    grade: "Grade 6,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the sentence: 'The wind ____ the trees down last night.' (Past tense of 'blow'),
      options: [blew, blowed, blown", "blow].sort(() => Math.random() - 0.5),
      correctAnswer: blew"
    })
  },
  {
    id: "G6-ENG-VER-04",
    grade: "Grade 6",
    subject: "English",
    topic: "Verbs",
    subtopic: "Present Perfect Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Select the correct present perfect tense: 'We ____ to that restaurant before.',
      options: [have been, went, "go, goes"].sort(() => Math.random() - 0.5),
      correctAnswer: "have been
    })
  },
  {
    id: G6-ENG-VER-05",
    grade: "Grade 6,
    subject: English",
    topic: "Verbs,
    subtopic: "Future Continuous Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the future continuous: 'At noon tomorrow, I ____ for my exam.',
      options: [will be studying, studied, study", "am studying].sort(() => Math.random() - 0.5),
      correctAnswer: will be studying"
    })
  },
  {
    id: "G6-ENG-VER-06",
    grade: "Grade 6",
    subject: "English",
    topic: "Verbs",
    subtopic: "Auxiliary Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which auxiliary verb is correct? 'The baby ____ be sleeping right now.',
      options: [could, would, "will, must"].sort(() => Math.random() - 0.5),
      correctAnswer: "could
    })
  },
  {
    id: G6-ENG-VER-07",
    grade: "Grade 6,
    subject: English",
    topic: "Verbs,
    subtopic: "Action Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which verb describes the action of using a razor to remove hair?,
      options: [Shaving, Cutting, Riding", "Flying].sort(() => Math.random() - 0.5),
      correctAnswer: Shaving"
    })
  },

  // --- TOPIC: ADJECTIVES (7 Materials) ---
  {
    id: "G6-ENG-ADJ-01",
    grade: "Grade 6",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Comparative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the comparative adjective for the word 'beautiful'?,
      options: [More beautiful, Beautifuler, "Beautifulest, Most beautiful"].sort(() => Math.random() - 0.5),
      correctAnswer: "More beautiful
    })
  },
  {
    id: G6-ENG-ADJ-02",
    grade: "Grade 6,
    subject: English",
    topic: "Adjectives,
    subtopic: "Superlative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Select the superlative form: 'She is the ____ girl in the class.',
      options: [tallest, tall, taller", "more tall].sort(() => Math.random() - 0.5),
      correctAnswer: tallest"
    })
  },
  {
    id: "G6-ENG-ADJ-03",
    grade: "Grade 6",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Possessive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Complete the sentence: 'This is ____ house.' (Possessive for 'we'),
      options: [our, their, "my, your"].sort(() => Math.random() - 0.5),
      correctAnswer: "our
    })
  },
  {
    id: G6-ENG-ADJ-04",
    grade: "Grade 6,
    subject: English",
    topic: "Adjectives,
    subtopic: "Demonstrative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Select the demonstrative adjective: '____ trees over there are very tall.' (Pointing far away),
      options: [Those, These, This", "That].sort(() => Math.random() - 0.5),
      correctAnswer: Those"
    })
  },
  {
    id: "G6-ENG-ADJ-05",
    grade: "Grade 6",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Descriptive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which adjective describes a person who is excellent at telling stories?,
      options: [Engaging, Angry, "Tired, Lazy"].sort(() => Math.random() - 0.5),
      correctAnswer: "Engaging
    })
  },
  {
    id: G6-ENG-ADJ-06",
    grade: "Grade 6,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quantity",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Which adjective shows that there is a very large amount?,
      options: [Enormous, Small, Tiny", "Minimal].sort(() => Math.random() - 0.5),
      correctAnswer: Enormous"
    })
  },
  {
    id: "G6-ENG-ADJ-07",
    grade: "Grade 6",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adjective expresses a negative opinion about something?,
      options: [Worst, Great, "Wonderful, Excellent"].sort(() => Math.random() - 0.5),
      correctAnswer: "Worst
    })
  },

  // --- topic: "PREPOSITIONS (7 Materials) ---
  {
    id: G6-ENG-PRE-01",
    grade: "Grade 6,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Place",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Choose the correct preposition: 'She sat ____ me during the meeting.',
      options: [beside, at, in", "on].sort(() => Math.random() - 0.5),
      correctAnswer: beside"
    })
  },
  {
    id: "G6-ENG-PRE-02",
    grade: "Grade 6",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Fill the blank: 'We will go for a picnic ____ Saturday.',
      options: [on, in, "at, to"].sort(() => Math.random() - 0.5),
      correctAnswer: "on
    })
  },
  {
    id: G6-ENG-PRE-03",
    grade: "Grade 6,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Movement",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " The dog jumped ____ the fence. (Select correct preposition),
      options: [over, under, above", "below].sort(() => Math.random() - 0.5),
      correctAnswer: over"
    })
  },
  {
    id: "G6-ENG-PRE-04",
    grade: "Grade 6",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Prepositions of Source,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "She returned ____ her trip to the coast. Which preposition shows the source of return?,
      options: [from, to, "in, on"].sort(() => Math.random() - 0.5),
      correctAnswer: "from
    })
  },
  {
    id: G6-ENG-PRE-05",
    grade: "Grade 6,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Direction",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Select the preposition showing direction: 'We went ____ the stadium.',
      options: [towards, from, on", "in].sort(() => Math.random() - 0.5),
      correctAnswer: towards"
    })
  },
  {
    id: "G6-ENG-PRE-06",
    grade: "Grade 6",
    subject: "English",
    topic: "Prepositions",
    subtopic: "Compound Prepositions,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which is a compound preposition: ' ____ the heavy rain, we still went out.',
      options: [Despite, Beside", "Above, Between"].sort(() => Math.random() - 0.5),
      correctAnswer: "Despite
    })
  },
  {
    id: G6-ENG-PRE-07",
    grade: "Grade 6,
    subject: English",
    topic: "Prepositions,
    subtopic: "Prepositions of Purpose",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " She went to the store ____ groceries. Which preposition indicates purpose?,
      options: [for, to, on", "in].sort(() => Math.random() - 0.5),
      correctAnswer: for"
    })
  },

  // --- TOPIC: READING COMPREHENSION (7 Materials) ---
  {
    id: "G6-ENG-RDC-01",
    grade: "Grade 6",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Main Idea,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Read the passage: 'The annual National Exam is an important event in Kenya. Students prepare for months. The exams are held in November.' What is the main idea?,
      options: [The National Exam is a major event., Students are lazy., "Exams are held in November., Students hate exams."].sort(() => Math.random() - 0.5),
      correctAnswer: "The National Exam is a major event.
    })
  },
  {
    id: G6-ENG-RDC-02",
    grade: "Grade 6,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Supporting Details",
    maxUses: 5,
    usageCount: 0,
    minWords: 52,
    generate: () => ({
      text: " Read: 'The Maasai people are known for their rich culture. They wear colorful shuka cloth and perform traditional jumping dances.' What is one supporting detail from the text?,
      options: [They wear colorful shuka cloth., They live in the desert., They are farmers.", "They don't have culture.].sort(() => Math.random() - 0.5),
      correctAnswer: They wear colorful shuka cloth."
    })
  },
  {
    id: "G6-ENG-RDC-03",
    grade: "Grade 6",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Inferring Character,
    maxUses: 5,
    usageCount: 0,
    minWords: 48,",
    generate: () => ({
      text: "Read: 'The young man volunteered at the hospital every weekend. He helped take patients to their rooms.' What can you infer about the young man?,
      options: [He is kind and caring., He is a doctor., "He is lazy., He is a teacher."].sort(() => Math.random() - 0.5),
      correctAnswer: "He is kind and caring.
    })
  },
  {
    id: G6-ENG-RDC-04",
    grade: "Grade 6,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Cause and Effect",
    maxUses: 5,
    usageCount: 0,
    minWords: 45,
    generate: () => ({
      text: " Read: 'The heavy rains caused the river to flood. The farmers were unable to harvest their crops.' What was the effect of the heavy rains?,
      options: [The river flooded., The sun came out., The crops grew.", "The birds flew.].sort(() => Math.random() - 0.5),
      correctAnswer: The river flooded."
    })
  },
  {
    id: "G6-ENG-RDC-05",
    grade: "Grade 6",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Predicting Outcomes,
    maxUses: 5,
    usageCount: 0,
    minWords: 47,",
    generate: () => ({
      text: "Read: 'The dog was chasing the cat. The cat ran to the fence. It climbed up the fence and sat on top.' What will the dog most likely do next?,
      options: [The dog will bark at the cat., The dog will climb the fence., "The cat will attack the dog., The cat will fly away."].sort(() => Math.random() - 0.5),
      correctAnswer: "The dog will bark at the cat.
    })
  },
  {
    id: G6-ENG-RDC-06",
    grade: "Grade 6,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Sequencing Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Read: 'First, we bought tickets. Then, we went into the theatre. Later, we watched the movie. Finally, we had dinner.' What happened after we went into the theatre?,
      options: [We watched the movie., We bought tickets., We had dinner.", "We went home.].sort(() => Math.random() - 0.5),
      correctAnswer: We watched the movie."
    })
  },
  {
    id: "G6-ENG-RDC-07",
    grade: "Grade 6",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Moral Lessons,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Read: 'The greedy man wanted all the gold. He refused to share with his poor neighbor. In the end, he lost everything.' What is the moral lesson?,
      options: [Greed leads to loss., Sharing is bad.", "Gold is not important., Friends are not needed."].sort(() => Math.random() - 0.5),
      correctAnswer: "Greed leads to loss.
    })
  }
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD JUNIOR SECONDARY)
  // =========================================================================

  // --- topic: "NOUNS (7 Materials) ---
  {
    id: G7-ENG-NOU-01",
    grade: "Grade 7,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns in Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which abstract noun describes the strong desire to succeed and achieve great things?,
      options: [Ambition, Fear, Anger", "Jealousy].sort(() => Math.random() - 0.5),
      correctAnswer: Ambition"
    })
  },
  {
    id: "G7-ENG-NOU-02",
    grade: "Grade 7",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What collective noun is used for a group of actors performing together on stage?,
      options: [Cast, Herd, "Flock, Pack"].sort(() => Math.random() - 0.5),
      correctAnswer: "Cast
    })
  },
  {
    id: G7-ENG-NOU-03",
    grade: "Grade 7,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which compound noun is formed from 'black' and 'board'?,
      options: [Blackboard, Black, Board", "Blackboard].sort(() => Math.random() - 0.5),
      correctAnswer: Blackboard"
    })
  },
  {
    id: "G7-ENG-NOU-04",
    grade: "Grade 7",
    subject: "English",
    topic: "Nouns",
    subtopic: "Proper Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which is a proper noun for the longest river in Kenya?,
      options: [River Tana, River, "Lake, Water"].sort(() => Math.random() - 0.5),
      correctAnswer: "River Tana
    })
  },
  {
    id: G7-ENG-NOU-05",
    grade: "Grade 7,
    subject: English",
    topic: "Nouns,
    subtopic: "Gender Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " What is the feminine gender noun for 'widower'?,
      options: [Widow, Wife, Sister", "Daughter].sort(() => Math.random() - 0.5),
      correctAnswer: Widow"
    })
  },
  {
    id: "G7-ENG-NOU-06",
    grade: "Grade 7",
    subject: "English",
    topic: "Nouns",
    subtopic: "Countable and Uncountable Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which of the following is an uncountable noun?,
      options: [Water, Pencil, "Chair, Book"].sort(() => Math.random() - 0.5),
      correctAnswer: "Water
    })
  },
  {
    id: G7-ENG-NOU-07",
    grade: "Grade 7,
    subject: English",
    topic: "Nouns,
    subtopic: "Pluralization",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " What is the correct plural form of 'criterion'?,
      options: [Criteria, Criterions, Criterias", "Criterion].sort(() => Math.random() - 0.5),
      correctAnswer: Criteria"
    })
  },

  // --- TOPIC: VERBS (7 Materials) ---
  {
    id: "G7-ENG-VER-01",
    grade: "Grade 7",
    subject: "English",
    topic: "Verbs",
    subtopic: "Action Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which verb describes the action of turning liquid into steam by applying heat?,
      options: [Boiling, Freezing, "Melting, Condensing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Boiling
    })
  },
  {
    id: G7-ENG-VER-02",
    grade: "Grade 7,
    subject: English",
    topic: "Verbs,
    subtopic: "Transitive and Intransitive Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which sentence contains a transitive verb that requires a direct object?,
      options: [She bought a new phone., She sleeps., The baby cried.", "The sun rose.].sort(() => Math.random() - 0.5),
      correctAnswer: She bought a new phone."
    })
  },
  {
    id: "G7-ENG-VER-03",
    grade: "Grade 7",
    subject: "English",
    topic: "Verbs",
    subtopic: "Past Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Complete the sentence: 'The sun ____ brightly yesterday.' (Correct past tense of 'shine'),
      options: [shone, shined, "shines, shining"].sort(() => Math.random() - 0.5),
      correctAnswer: "shone
    })
  },
  {
    id: G7-ENG-VER-04",
    grade: "Grade 7,
    subject: English",
    topic: "Verbs,
    subtopic: "Present Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Select the correct present perfect tense: 'They ____ to that safari park twice.',
      options: [have been, went, go", "goes].sort(() => Math.random() - 0.5),
      correctAnswer: have been"
    })
  },
  {
    id: "G7-ENG-VER-05",
    grade: "Grade 7",
    subject: "English",
    topic: "Verbs",
    subtopic: "Future Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct future tense: 'We ____ the project by Friday.',
      options: [will complete, completed, "complete, completing"].sort(() => Math.random() - 0.5),
      correctAnswer: "will complete
    })
  },
  {
    id: G7-ENG-VER-06",
    grade: "Grade 7,
    subject: English",
    topic: "Verbs,
    subtopic: "Modal Auxiliary Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which modal verb correctly fills the blank? 'You ____ wear a uniform at this school.',
      options: [must, can, would", "might].sort(() => Math.random() - 0.5),
      correctAnswer: must"
    })
  },
  {
    id: "G7-ENG-VER-07",
    grade: "Grade 7",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Select the phrasal verb that means 'to investigate or examine something'.,
      options: [Look into, Give up, "Run out, Sit down"].sort(() => Math.random() - 0.5),
      correctAnswer: "Look into
    })
  },

  // --- topic: "ADJECTIVES (7 Materials) ---
  {
    id: G7-ENG-ADJ-01",
    grade: "Grade 7,
    subject: English",
    topic: "Adjectives,
    subtopic: "Comparative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " What is the comparative adjective for the word 'famous'?,
      options: [More famous, Famouser, Famousest", "Most famous].sort(() => Math.random() - 0.5),
      correctAnswer: More famous"
    })
  },
  {
    id: "G7-ENG-ADJ-02",
    grade: "Grade 7",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Superlative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Select the superlative form: 'He is the ____ runner in the team.',
      options: [quickest, quick, "quicker, more quick"].sort(() => Math.random() - 0.5),
      correctAnswer: "quickest
    })
  },
  {
    id: G7-ENG-ADJ-03",
    grade: "Grade 7,
    subject: English",
    topic: "Adjectives,
    subtopic: "Possessive Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Complete the sentence: 'This is ____ car.' (Possessive for 'they'),
      options: [their, our, my", "your].sort(() => Math.random() - 0.5),
      correctAnswer: their"
    })
  },
  {
    id: "G7-ENG-ADJ-04",
    grade: "Grade 7",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Demonstrative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Select the demonstrative adjective: '____ shoes here are perfect for you.',
      options: [These, Those, "This, That"].sort(() => Math.random() - 0.5),
      correctAnswer: "These
    })
  },
  {
    id: G7-ENG-ADJ-05",
    grade: "Grade 7,
    subject: English",
    topic: "Adjectives,
    subtopic: "Descriptive Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adjective describes a person who is very courageous and brave?,
      options: [Heroic, Lazy, Timid", "Shy].sort(() => Math.random() - 0.5),
      correctAnswer: Heroic"
    })
  },
  {
    id: "G7-ENG-ADJ-06",
    grade: "Grade 7",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quantity,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which adjective shows that something cannot be counted individually?,
      options: [Some, Many, "Few, All"].sort(() => Math.random() - 0.5),
      correctAnswer: "Some
    })
  },
  {
    id: G7-ENG-ADJ-07",
    grade: "Grade 7,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quality",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adjective best describes a well-crafted and thoughtfully built house?,
      options: [Sturdy, Small, Tall", "Modern].sort(() => Math.random() - 0.5),
      correctAnswer: Sturdy"
    })
  },

  // --- TOPIC: ADVERBS (7 Materials) ---
  {
    id: "G7-ENG-ADV-01",
    grade: "Grade 7",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Manner,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adverb describes how someone performs an action with great speed?,
      options: [Quickly, Slowly, "Gently, Softly"].sort(() => Math.random() - 0.5),
      correctAnswer: "Quickly
    })
  },
  {
    id: G7-ENG-ADV-02",
    grade: "Grade 7,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Frequency",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which adverb best fills the blank? 'She ____ visits her grandmother on weekends.',
      options: [Often, Never, Usually", "Always].sort(() => Math.random() - 0.5),
      correctAnswer: Often"
    })
  },
  {
    id: "G7-ENG-ADV-03",
    grade: "Grade 7",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adverb indicates that an action has recently been completed?,
      options: [Already, Tomorrow, "Yesterday, Later"].sort(() => Math.random() - 0.5),
      correctAnswer: "Already
    })
  },
  {
    id: G7-ENG-ADV-04",
    grade: "Grade 7,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Place",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which adverb describes the location of an action? 'Please put the books ____.',
      options: [Here, Quickly, Often", "Yesterday].sort(() => Math.random() - 0.5),
      correctAnswer: Here"
    })
  },
  {
    id: "G7-ENG-ADV-05",
    grade: "Grade 7",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Comparative Adverbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Select the correct comparative adverb: 'She sings ____ than her sister.',
      options: [better, good, "well, best"].sort(() => Math.random() - 0.5),
      correctAnswer: "better
    })
  },
  {
    id: G7-ENG-ADV-06",
    grade: "Grade 7,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Degree",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adverb intensifies the adjective? 'The exam was ____ difficult.',
      options: [Very, Now, There", "Often].sort(() => Math.random() - 0.5),
      correctAnswer: Very"
    })
  },
  {
    id: "G7-ENG-ADV-07",
    grade: "Grade 7",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Purpose,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb explains why something was done? 'She went to the library ____ study.',
      options: [To, For, "Because, So"].sort(() => Math.random() - 0.5),
      correctAnswer: "To
    })
  },

  // --- topic: "READING COMPREHENSION (7 Materials) ---
  {
    id: G7-ENG-RDC-01",
    grade: "Grade 7,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Identifying Author's Purpose",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The government has banned the use of plastic bags to protect the environment. They are harmful to wildlife.' What is the author's purpose?,
      options: [To persuade readers to stop using plastic., To scare readers., To make money.", "To entertain readers.].sort(() => Math.random() - 0.5),
      correctAnswer: To persuade readers to stop using plastic."
    })
  },
  {
    id: "G7-ENG-RDC-02",
    grade: "Grade 7",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Character Motivation,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'Amos trained hard for the marathon. He wanted to win the trophy to make his sick mother proud.' Why did Amos train so hard?,
      options: [To make his mother proud., To get a prize., "To become famous., To get money."].sort(() => Math.random() - 0.5),
      correctAnswer: "To make his mother proud.
    })
  },
  {
    id: G7-ENG-RDC-03",
    grade: "Grade 7,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Identifying Themes",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'Kenya is a land of great diversity. From the hot coastal plains to the cold highlands, it has something for everyone.' What is the main theme of this passage?,
      options: [Kenya's diversity, The weather, The people of Kenya", "The animals].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya's diversity"
    })
  },
  {
    id: "G7-ENG-RDC-04",
    grade: "Grade 7",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Making Inferences,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The room was completely silent. Every student stared at the door. The teacher walked in with a stern look.' What can you infer about the students' mood?,
      options: [They were nervous., They were happy., "They were sleeping., They were fighting."].sort(() => Math.random() - 0.5),
      correctAnswer: "They were nervous.
    })
  },
  {
    id: G7-ENG-RDC-05",
    grade: "Grade 7,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Understanding Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The sun was a blazing fire in the sky.' What literary device is used in this sentence?,
      options: [Simile, Metaphor, Personification", "Hyperbole].sort(() => Math.random() - 0.5),
      correctAnswer: Metaphor"
    })
  },
  {
    id: "G7-ENG-RDC-06",
    grade: "Grade 7",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Text Structure,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'First, the boy felt scared. Then, he started looking for a way out. Finally, he found the courage to escape.' How is the text organized?,
      options: ["Chronological order, Cause and effect", "Problem and solution, Compare and contrast"].sort(() => Math.random() - 0.5),
      correctAnswer: "Chronological order
    })
  },
  {
    id: G7-ENG-RDC-07",
    grade: "Grade 7,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Summarizing",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The Maasai tribe is known for their warrior culture, vibrant attire, and traditional ceremonies. They have lived in the Rift Valley for centuries.' Which is the best summary of this text?,
      options: [The Maasai are a vibrant culture., The Maasai have cattle., The Maasai live in cities.", "The Maasai are from Europe.].sort(() => Math.random() - 0.5),
      correctAnswer: The Maasai are a vibrant culture."
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD JUNIOR SECONDARY)
  // =========================================================================

  // --- TOPIC: NOUNS (7 Materials) ---
  {
    id: "G8-ENG-NOU-01",
    grade: "Grade 8",
    subject: "English",
    topic: "Nouns",
    subtopic: "Abstract Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What abstract noun describes the state of being completely honest and truthful?,
      options: [Integrity, Fear, "Jealousy, Anger"].sort(() => Math.random() - 0.5),
      correctAnswer: "Integrity
    })
  },
  {
    id: G8-ENG-NOU-02",
    grade: "Grade 8,
    subject: English",
    topic: "Nouns,
    subtopic: "Collective Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " What collective noun is used for a group of musicians who play instruments together?,
      options: [Band, Team, Herd", "Flock].sort(() => Math.random() - 0.5),
      correctAnswer: Band"
    })
  },
  {
    id: "G8-ENG-NOU-03",
    grade: "Grade 8",
    subject: "English",
    topic: "Nouns",
    subtopic: "Compound Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which compound noun is formed from 'under' and 'ground'?,
      options: [Underground, Under, "Ground, Under"].sort(() => Math.random() - 0.5),
      correctAnswer: "Underground
    })
  },
  {
    id: G8-ENG-NOU-04",
    grade: "Grade 8,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which is a proper noun for the capital city of Kenya?,
      options: [Nairobi, City, Town", "Mombasa].sort(() => Math.random() - 0.5),
      correctAnswer: Nairobi"
    })
  },
  {
    id: "G8-ENG-NOU-05",
    grade: "Grade 8",
    subject: "English",
    topic: "Nouns",
    subtopic: "Gender Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the feminine gender noun for 'nephew'?,
      options: [Niece, Cousin, "Sister, Aunt"].sort(() => Math.random() - 0.5),
      correctAnswer: "Niece
    })
  },
  {
    id: G8-ENG-NOU-06",
    grade: "Grade 8,
    subject: English",
    topic: "Nouns,
    subtopic: "Countable vs Uncountable",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which of the following is a countable noun?,
      options: [Chair, Air, Water", "Music].sort(() => Math.random() - 0.5),
      correctAnswer: Chair"
    })
  },
  {
    id: "G8-ENG-NOU-07",
    grade: "Grade 8",
    subject: "English",
    topic: "Nouns",
    subtopic: "Pluralization,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct plural form of 'phenomenon'?,
      options: [Phenomena, Phenomenons, "Phenomenas, Phenomenon"].sort(() => Math.random() - 0.5),
      correctAnswer: "Phenomena
    })
  },

  // --- topic: "VERBS (7 Materials) ---
  {
    id: G8-ENG-VER-01",
    grade: "Grade 8,
    subject: English",
    topic: "Verbs,
    subtopic: "Action Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which verb describes the action of mixing ingredients together to make a meal?,
      options: [Stir, Run, Jump", "Sleep].sort(() => Math.random() - 0.5),
      correctAnswer: Stir"
    })
  },
  {
    id: "G8-ENG-VER-02",
    grade: "Grade 8",
    subject: "English",
    topic: "Verbs",
    subtopic: "Active and Passive Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Convert to passive voice: 'The chef prepared the meal.',
      options: [The meal was prepared by the chef., The chef prepares the meal., "The meal was prepared., The chef is preparing the meal."].sort(() => Math.random() - 0.5),
      correctAnswer: "The meal was prepared by the chef.
    })
  },
  {
    id: G8-ENG-VER-03",
    grade: "Grade 8,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the sentence: 'By the time we arrived, the train ____.' (Past perfect of 'leave'),
      options: [had left, left, has left", "leaves].sort(() => Math.random() - 0.5),
      correctAnswer: had left"
    })
  },
  {
    id: "G8-ENG-VER-04",
    grade: "Grade 8",
    subject: "English",
    topic: "Verbs",
    subtopic: "Reported Speech,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Reported speech: 'I am hungry,' he said. What is the correct reported form?,
      options: [He said he was hungry., He said he is hungry.", "He says he is hungry., He says he was hungry."].sort(() => Math.random() - 0.5),
      correctAnswer: "He said he was hungry.
    })
  },
  {
    id: G8-ENG-VER-05",
    grade: "Grade 8,
    subject: English",
    topic: "Verbs,
    subtopic: "Future Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " What is the correct future perfect tense? 'By next year, she ____ her degree.',
      options: [will have completed, completed, will complete", "is completing].sort(() => Math.random() - 0.5),
      correctAnswer: will have completed"
    })
  },
  {
    id: "G8-ENG-VER-06",
    grade: "Grade 8",
    subject: "English",
    topic: "Verbs",
    subtopic: "Conditional Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is the correct conditional? 'If you ____ hard, you will succeed.',
      options: [work, worked", "working, works"].sort(() => Math.random() - 0.5),
      correctAnswer: "work
    })
  },
  {
    id: G8-ENG-VER-07",
    grade: "Grade 8,
    subject: English",
    topic: "Verbs,
    subtopic: "Phrasal Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Select the phrasal verb that means 'to experience a memory again'.,
      options: [Look back, Run into, Come up", "Give in].sort(() => Math.random() - 0.5),
      correctAnswer: Look back"
    })
  },

  // --- TOPIC: CONJUNCTIONS (7 Materials) ---
  {
    id: "G8-ENG-CON-01",
    grade: "Grade 8",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Coordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which coordinating conjunction connects two opposite ideas? 'He was tired, ____ he continued working.',
      options: [but, and", "or, so"].sort(() => Math.random() - 0.5),
      correctAnswer: "but
    })
  },
  {
    id: G8-ENG-CON-02",
    grade: "Grade 8,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Subordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the sentence: '____ it was raining, we still went for the walk.',
      options: [Although, Because, Since", "Unless].sort(() => Math.random() - 0.5),
      correctAnswer: Although"
    })
  },
  {
    id: "G8-ENG-CON-03",
    grade: "Grade 8",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Correlative Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Select the correct correlative conjunction: '____ you study hard, ____ you will pass.',
      options: [If ... then, Either ... or", "Neither ... nor, Not only ... but also"].sort(() => Math.random() - 0.5),
      correctAnswer: "If ... then
    })
  },
  {
    id: G8-ENG-CON-04",
    grade: "Grade 8,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Coordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Which conjunction joins two choices? 'You can take tea ____ coffee.',
      options: [or, but, and", "so].sort(() => Math.random() - 0.5),
      correctAnswer: or"
    })
  },
  {
    id: "G8-ENG-CON-05",
    grade: "Grade 8",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Subordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Complete: 'We stayed inside ____ the weather was too cold.',
      options: [because, until, "while, unless"].sort(() => Math.random() - 0.5),
      correctAnswer: "because
    })
  },
  {
    id: G8-ENG-CON-06",
    grade: "Grade 8,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Correlative Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Select the correct pair: '____ my brother ____ my sister will attend the party.',
      options: [Either ... or, Both ... and, Neither ... nor", "Not only ... but also].sort(() => Math.random() - 0.5),
      correctAnswer: Either ... or"
    })
  },
  {
    id: "G8-ENG-CON-07",
    grade: "Grade 8",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Conjunctive Adverbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which conjunctive adverb shows a contrast? 'He was very tired; ____, he kept working.',
      options: [However, Moreover", "Therefore, Consequently"].sort(() => Math.random() - 0.5),
      correctAnswer: "However
    })
  },

  // --- topic: "READING COMPREHENSION (7 Materials) ---
  {
    id: G8-ENG-RDC-01",
    grade: "Grade 8,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Analyzing Tone",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The majestic mountains stood tall against the sky. The sunset painted a golden curtain over the land.' What is the tone of this passage?,
      options: [Peaceful and beautiful, Sad and angry, Funny and playful", "Scary and dark].sort(() => Math.random() - 0.5),
      correctAnswer: Peaceful and beautiful"
    })
  },
  {
    id: "G8-ENG-RDC-02",
    grade: "Grade 8",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Understanding Persuasive Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'It is time to protect our forests. The trees give us clean air and preserve our wildlife. Join the campaign today.' What technique is used to persuade the reader?,
      options: [Emotional appeal, Financial appeal, "Legal threat, Exaggeration"].sort(() => Math.random() - 0.5),
      correctAnswer: "Emotional appeal
    })
  },
  {
    id: G8-ENG-RDC-03",
    grade: "Grade 8,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Character Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'Kofi started as a shy boy. As he joined the debate club, he became more confident. He eventually became the president of the club.' How did Kofi change over time?,
      options: [He became more confident., He became angrier., He became lazy.", "He became a teacher.].sort(() => Math.random() - 0.5),
      correctAnswer: He became more confident."
    })
  },
  {
    id: "G8-ENG-RDC-04",
    grade: "Grade 8",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Identifying Bias,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The new iPhone is the greatest phone ever made. Everyone should buy it.' Is this statement unbiased?,
      options: [No, it is biased and opinionated., Yes, it is a fact., "Yes, it is neutral., No, it is a scientific finding."].sort(() => Math.random() - 0.5),
      correctAnswer: "No, it is biased and opinionated.
    })
  },
  {
    id: G8-ENG-RDC-05",
    grade: "Grade 8,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Drawing Conclusions",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The Zulu dance is a vibrant cultural performance. It involves rhythmic foot stomping and powerful chants. It is performed during important celebrations.' What conclusion can you draw about the Zulu dance?,
      options: [It is an energetic celebration of culture., It is a boring dance., It is a dance from Europe.", "It is a modern dance.].sort(() => Math.random() - 0.5),
      correctAnswer: It is an energetic celebration of culture."
    })
  },
  {
    id: "G8-ENG-RDC-06",
    grade: "Grade 8",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Distinguishing Fact from Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'Kenya gained independence in 1963. It is the most beautiful country in the world.' Which part of the statement is a fact?,
      options: [Kenya gained independence in 1963., Kenya is the most beautiful country., "Kenya is in Africa., Kenya has a big population."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya gained independence in 1963.
    })
  },
  {
    id: G8-ENG-RDC-07",
    grade: "Grade 8,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Comparing Texts",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read Text A: 'The cheetah is the fastest land animal.' Read Text B: 'The peregrine falcon is the fastest animal in the sky.' How are these two texts similar?,
      options: [Both talk about speed., Both are about dogs., Both talk about water.", "Both are about flying.].sort(() => Math.random() - 0.5),
      correctAnswer: Both talk about speed."
    })
  }
  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD JUNIOR SECONDARY - COMPLETION)
  // =========================================================================

  // --- TOPIC: NOUNS (5 Materials) ---
  {
    id: "G9-ENG-NOU-01",
    grade: "Grade 9",
    subject: "English",
    topic: "Nouns",
    subtopic: "Abstract Nouns in Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "In the story, the character showed great ____ when she stood up to the bullies. Which abstract noun fits best?,
      options: [Courage, Anger", "Fear, Sadness"].sort(() => Math.random() - 0.5),
      correctAnswer: "Courage
    })
  },
  {
    id: G9-ENG-NOU-02",
    grade: "Grade 9,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which compound noun correctly describes the room where you eat your meals?,
      options: [Dining room, Bedroom, Bathroom", "Kitchen].sort(() => Math.random() - 0.5),
      correctAnswer: Dining room"
    })
  },
  {
    id: "G9-ENG-NOU-03",
    grade: "Grade 9",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What collective noun is used for a group of ships sailing together?,
      options: [Fleet, Herd, "Pack, Flock"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fleet
    })
  },
  {
    id: G9-ENG-NOU-04",
    grade: "Grade 9,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which is a proper noun for the largest lake in Kenya?,
      options: [Lake Victoria, Lake, River", "Ocean].sort(() => Math.random() - 0.5),
      correctAnswer: Lake Victoria"
    })
  },
  {
    id: "G9-ENG-NOU-05",
    grade: "Grade 9",
    subject: "English",
    topic: "Nouns",
    subtopic: "Pluralization,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "What is the correct plural form of 'appendix'?,
      options: [Appendices, Appendixes, "Appendices, Appendix"].sort(() => Math.random() - 0.5),
      correctAnswer: "Appendices
    })
  },

  // --- topic: "VERBS (6 Materials) ---
  {
    id: G9-ENG-VER-01",
    grade: "Grade 9,
    subject: English",
    topic: "Verbs,
    subtopic: "Action Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which verb describes the action of cutting grass using a machine?,
      options: [Mowing, Plowing, Sowing", "Rowing].sort(() => Math.random() - 0.5),
      correctAnswer: Mowing"
    })
  },
  {
    id: "G9-ENG-VER-02",
    grade: "Grade 9",
    subject: "English",
    topic: "Verbs",
    subtopic: "Active and Passive Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Convert to passive voice: 'The police arrested the thief.',
      options: [The thief was arrested by the police., The thief arrests the police., "The police were arrested., The thief is arrested."].sort(() => Math.random() - 0.5),
      correctAnswer: "The thief was arrested by the police.
    })
  },
  {
    id: G9-ENG-VER-03",
    grade: "Grade 9,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the sentence: 'She realized she ____ her keys at home.' (Past perfect of 'leave'),
      options: [had left, left, has left", "leaves].sort(() => Math.random() - 0.5),
      correctAnswer: had left"
    })
  },
  {
    id: "G9-ENG-VER-04",
    grade: "Grade 9",
    subject: "English",
    topic: "Verbs",
    subtopic: "Reported Speech,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Reported speech: 'I will come tomorrow,' she said. What is the correct reported form?,
      options: [She said she would come the next day., She said she will come tomorrow.", "She says she will come., She said she came yesterday."].sort(() => Math.random() - 0.5),
      correctAnswer: "She said she would come the next day.
    })
  },
  {
    id: G9-ENG-VER-05",
    grade: "Grade 9,
    subject: English",
    topic: "Verbs,
    subtopic: "Conditional Sentences",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " What is the correct conditional? 'If I ____ you, I would accept the offer.',
      options: [were, was, am", "is].sort(() => Math.random() - 0.5),
      correctAnswer: were"
    })
  },
  {
    id: "G9-ENG-VER-06",
    grade: "Grade 9",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Select the phrasal verb that means 'to tolerate or endure something'.,
      options: [Put up with, Give up, "Run out, Sit down"].sort(() => Math.random() - 0.5),
      correctAnswer: "Put up with
    })
  },

  // --- topic: "ADJECTIVES (6 Materials) ---
  {
    id: G9-ENG-ADJ-01",
    grade: "Grade 9,
    subject: English",
    topic: "Adjectives,
    subtopic: "Comparative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " What is the comparative adjective for the word 'intelligent'?,
      options: [More intelligent, Intelligenter, Intelligentest", "Most intelligent].sort(() => Math.random() - 0.5),
      correctAnswer: More intelligent"
    })
  },
  {
    id: "G9-ENG-ADJ-02",
    grade: "Grade 9",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Superlative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Select the superlative form: 'This is the ____ movie I have ever watched.',
      options: [best, good, "better, more good"].sort(() => Math.random() - 0.5),
      correctAnswer: "best
    })
  },
  {
    id: G9-ENG-ADJ-03",
    grade: "Grade 9,
    subject: English",
    topic: "Adjectives,
    subtopic: "Possessive Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Complete the sentence: 'This is ____ project.' (Possessive for 'we'),
      options: [our, their, my", "your].sort(() => Math.random() - 0.5),
      correctAnswer: our"
    })
  },
  {
    id: "G9-ENG-ADJ-04",
    grade: "Grade 9",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quantity,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adjective shows that there is no amount left?,
      options: [Enough, Some, "Any, Much"].sort(() => Math.random() - 0.5),
      correctAnswer: "Enough
    })
  },
  {
    id: G9-ENG-ADJ-05",
    grade: "Grade 9,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quality",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which adjective describes a person who is extremely wise and knowledgeable?,
      options: [Wise, Smart, Clever", "Intelligent].sort(() => Math.random() - 0.5),
      correctAnswer: Wise"
    })
  },
  {
    id: "G9-ENG-ADJ-06",
    grade: "Grade 9",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adjective expresses a positive opinion about a book?,
      options: [Excellent, Boring, "Terrible, Awful"].sort(() => Math.random() - 0.5),
      correctAnswer: "Excellent
    })
  },

  // --- topic: "ADVERBS (6 Materials) ---
  {
    id: G9-ENG-ADV-01",
    grade: "Grade 9,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Manner",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adverb describes how someone performs an action with great care?,
      options: [Carefully, Quickly, Slowly", "Gently].sort(() => Math.random() - 0.5),
      correctAnswer: Carefully"
    })
  },
  {
    id: "G9-ENG-ADV-02",
    grade: "Grade 9",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Frequency,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adverb indicates that an action happens at all times?,
      options: [Always, Never, "Sometimes, Often"].sort(() => Math.random() - 0.5),
      correctAnswer: "Always
    })
  },
  {
    id: G9-ENG-ADV-03",
    grade: "Grade 9,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Time",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adverb indicates that an action will happen in the future?,
      options: [Soon, Now, Already", "Yesterday].sort(() => Math.random() - 0.5),
      correctAnswer: Soon"
    })
  },
  {
    id: "G9-ENG-ADV-04",
    grade: "Grade 9",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Place,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which adverb indicates a location far away from the speaker?,
      options: [There, Here, "Near, Inside"].sort(() => Math.random() - 0.5),
      correctAnswer: "There
    })
  },
  {
    id: G9-ENG-ADV-05",
    grade: "Grade 9,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Degree",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which adverb modifies the adjective? 'The movie was ____ interesting.',
      options: [Very, Now, There", "Often].sort(() => Math.random() - 0.5),
      correctAnswer: Very"
    })
  },
  {
    id: "G9-ENG-ADV-06",
    grade: "Grade 9",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Purpose,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb explains the reason behind an action? 'She went to the library ____ study.',
      options: [To, For, "Because, So"].sort(() => Math.random() - 0.5),
      correctAnswer: "To
    })
  },

  // --- topic: "CONJUNCTIONS (6 Materials) ---
  {
    id: G9-ENG-CON-01",
    grade: "Grade 9,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Coordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which coordinating conjunction links two contrasting ideas? 'He is tall, ____ his brother is short.',
      options: [but, and, or", "so].sort(() => Math.random() - 0.5),
      correctAnswer: but"
    })
  },
  {
    id: "G9-ENG-CON-02",
    grade: "Grade 9",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Subordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Complete the sentence: '____ it is raining, we will stay indoors.',
      options: [Since, Although", "Unless, Because"].sort(() => Math.random() - 0.5),
      correctAnswer: "Since
    })
  },
  {
    id: G9-ENG-CON-03",
    grade: "Grade 9,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Correlative Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Select the correct correlative conjunction: '____ you stop complaining, ____ we will get nowhere.',
      options: [If ... then, Either ... or, Neither ... nor", "Not only ... but also].sort(() => Math.random() - 0.5),
      correctAnswer: If ... then"
    })
  },
  {
    id: "G9-ENG-CON-04",
    grade: "Grade 9",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Coordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Which conjunction joins two alternative choices? 'You can take the bus ____ the train.',
      options: [or, but, "and, so"].sort(() => Math.random() - 0.5),
      correctAnswer: "or
    })
  },
  {
    id: G9-ENG-CON-05",
    grade: "Grade 9,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Subordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Complete: 'We waited ____ the rain stopped.',
      options: [until, because, while", "unless].sort(() => Math.random() - 0.5),
      correctAnswer: until"
    })
  },
  {
    id: "G9-ENG-CON-06",
    grade: "Grade 9",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Conjunctive Adverbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which conjunctive adverb shows a cause and effect? 'He was late; ____, he missed the beginning.',
      options: [Consequently, However", "Moreover, Therefore"].sort(() => Math.random() - 0.5),
      correctAnswer: "Consequently
    })
  },

  // --- topic: "READING COMPREHENSION (6 Materials) ---
  {
    id: G9-ENG-RDC-01",
    grade: "Grade 9,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Analyzing Author's Purpose",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The government has introduced a new policy to improve healthcare. It will benefit all citizens.' What is the author's purpose?,
      options: [To inform about a new policy., To scare the reader., To make money.", "To entertain the reader.].sort(() => Math.random() - 0.5),
      correctAnswer: To inform about a new policy."
    })
  },
  {
    id: "G9-ENG-RDC-02",
    grade: "Grade 9",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Character Motivation,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'Kiprop trained tirelessly for the marathon. He wanted to win to support his family.' Why did Kiprop train so hard?,
      options: [To support his family., To become famous., "To get a prize., To get money."].sort(() => Math.random() - 0.5),
      correctAnswer: "To support his family.
    })
  },
  {
    id: G9-ENG-RDC-03",
    grade: "Grade 9,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Identifying Bias",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'City A is the best city in the world. Everyone should move there.' Is this statement biased?,
      options: [Yes, it is biased and opinionated., No, it is a fact., Yes, it is neutral.", "No, it is scientific.].sort(() => Math.random() - 0.5),
      correctAnswer: Yes, it is biased and opinionated."
    })
  },
  {
    id: "G9-ENG-RDC-04",
    grade: "Grade 9",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Making Inferences,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The room was quiet. The students nervously looked at their exams.' What can you infer about the students' mood?,
      options: [They were anxious., They were happy., "They were sleeping., They were fighting."].sort(() => Math.random() - 0.5),
      correctAnswer: "They were anxious.
    })
  },
  {
    id: G9-ENG-RDC-05",
    grade: "Grade 9,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Understanding Figurative Language",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The wind whispered through the trees.' What literary device is used?,
      options: [Personification, Simile, Metaphor", "Hyperbole].sort(() => Math.random() - 0.5),
      correctAnswer: Personification"
    })
  },
  {
    id: "G9-ENG-RDC-06",
    grade: "Grade 9",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Summarizing,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The Maasai people are known for their rich culture. They wear colorful clothing and perform traditional dances.' What is the best summary?,
      options: [The Maasai are a culturally rich community., The Maasai are poor., "The Maasai live in cities., The Maasai are from Europe."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maasai are a culturally rich community.
    })
  },

  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD SENIOR SECONDARY - BEGINNING)
  // =========================================================================

  // --- topic: "NOUNS (5 Materials) ---
  {
    id: G10-ENG-NOU-01",
    grade: "Grade 10,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which abstract noun describes the quality of being truthful and honest in all dealings?,
      options: [Integrity, Fear, Jealousy", "Anger].sort(() => Math.random() - 0.5),
      correctAnswer: Integrity"
    })
  },
  {
    id: "G10-ENG-NOU-02",
    grade: "Grade 10",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What collective noun is used for a group of people who work together on a project?,
      options: [Team, Herd, "Flock, Pack"].sort(() => Math.random() - 0.5),
      correctAnswer: "Team
    })
  },
  {
    id: G10-ENG-NOU-03",
    grade: "Grade 10,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which compound noun refers to the device used for making and receiving calls?,
      options: [Telephone, Television, Computer", "Radio].sort(() => Math.random() - 0.5),
      correctAnswer: Telephone"
    })
  },
  {
    id: "G10-ENG-NOU-04",
    grade: "Grade 10",
    subject: "English",
    topic: "Nouns",
    subtopic: "Proper Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which is a proper noun for the highest mountain in Kenya?,
      options: [Mount Kenya, Mount, "Hill, Rock"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mount Kenya
    })
  },
  {
    id: G10-ENG-NOU-05",
    grade: "Grade 10,
    subject: English",
    topic: "Nouns,
    subtopic: "Countable and Uncountable Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which of the following is an uncountable noun?,
      options: [Rice, Chair, Table", "Book].sort(() => Math.random() - 0.5),
      correctAnswer: Rice"
    })
  },

  // --- TOPIC: VERBS (6 Materials) ---
  {
    id: "G10-ENG-VER-01",
    grade: "Grade 10",
    subject: "English",
    topic: "Verbs",
    subtopic: "Action Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which verb describes the action of completely destroying a building?,
      options: [Demolish, Build, "Repair, Paint"].sort(() => Math.random() - 0.5),
      correctAnswer: "Demolish
    })
  },
  {
    id: G10-ENG-VER-02",
    grade: "Grade 10,
    subject: English",
    topic: "Verbs,
    subtopic: "Active and Passive Voice",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Convert to passive voice: 'The mechanic repaired the car.',
      options: [The car was repaired by the mechanic., The car repairs the mechanic., The mechanic was repaired.", "The car is repairing.].sort(() => Math.random() - 0.5),
      correctAnswer: The car was repaired by the mechanic."
    })
  },
  {
    id: "G10-ENG-VER-03",
    grade: "Grade 10",
    subject: "English",
    topic: "Verbs",
    subtopic: "Past Perfect Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Complete the sentence: 'By the time we arrived, they ____ the meeting.' (Past perfect of 'start'),
      options: [had started, started", "has started, starts"].sort(() => Math.random() - 0.5),
      correctAnswer: "had started
    })
  },
  {
    id: G10-ENG-VER-04",
    grade: "Grade 10,
    subject: English",
    topic: "Verbs,
    subtopic: "Reported Speech",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Reported speech: 'I am reading,' she said. What is the correct reported form?,
      options: [She said she was reading., She said she is reading., She says she is reading.", "She says she was reading.].sort(() => Math.random() - 0.5),
      correctAnswer: She said she was reading."
    })
  },
  {
    id: "G10-ENG-VER-05",
    grade: "Grade 10",
    subject: "English",
    topic: "Verbs",
    subtopic: "Future Perfect Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the correct future perfect tense? 'By next month, she ____ her degree.',
      options: [will have completed, completed", "will complete, is completing"].sort(() => Math.random() - 0.5),
      correctAnswer: "will have completed
    })
  },
  {
    id: G10-ENG-VER-06",
    grade: "Grade 10,
    subject: English",
    topic: "Verbs,
    subtopic: "Conditional Sentences",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the correct conditional? 'If she ____ harder, she would have passed.',
      options: [had studied, studied, studies", "is studying].sort(() => Math.random() - 0.5),
      correctAnswer: had studied"
    })
  },

  // --- TOPIC: ADJECTIVES (6 Materials) ---
  {
    id: "G10-ENG-ADJ-01",
    grade: "Grade 10",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Comparative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the comparative adjective for the word 'expensive'?,
      options: [More expensive, Expensiver, "Expensivest, Most expensive"].sort(() => Math.random() - 0.5),
      correctAnswer: "More expensive
    })
  },
  {
    id: G10-ENG-ADJ-02",
    grade: "Grade 10,
    subject: English",
    topic: "Adjectives,
    subtopic: "Superlative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Select the superlative form: 'This is the ____ performance I have ever seen.',
      options: [worst, bad, worse", "more bad].sort(() => Math.random() - 0.5),
      correctAnswer: worst"
    })
  },
  {
    id: "G10-ENG-ADJ-03",
    grade: "Grade 10",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Possessive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Complete the sentence: 'This is ____ responsibility.' (Possessive for 'you'),
      options: [your, our, "my, their"].sort(() => Math.random() - 0.5),
      correctAnswer: "your
    })
  },
  {
    id: G10-ENG-ADJ-04",
    grade: "Grade 10,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quantity",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adjective indicates an exact number of items?,
      options: [Three, Some, Few", "Many].sort(() => Math.random() - 0.5),
      correctAnswer: Three"
    })
  },
  {
    id: "G10-ENG-ADJ-05",
    grade: "Grade 10",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quality,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adjective describes a person who is highly skilled and experienced?,
      options: [Expert, Novice, "Beginner, Amateur"].sort(() => Math.random() - 0.5),
      correctAnswer: "Expert
    })
  },
  {
    id: G10-ENG-ADJ-06",
    grade: "Grade 10,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Opinion",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which adjective expresses a negative opinion about an experience?,
      options: [Terrible, Great, Wonderful", "Excellent].sort(() => Math.random() - 0.5),
      correctAnswer: Terrible"
    })
  },

  // --- TOPIC: ADVERBS (6 Materials) ---
  {
    id: "G10-ENG-ADV-01",
    grade: "Grade 10",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Manner,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb describes how someone performs an action with great precision?,
      options: [Accurately, Quickly, "Slowly, Gently"].sort(() => Math.random() - 0.5),
      correctAnswer: "Accurately
    })
  },
  {
    id: G10-ENG-ADV-02",
    grade: "Grade 10,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Frequency",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which adverb indicates that an action happens occasionally?,
      options: [Sometimes, Always, Never", "Often].sort(() => Math.random() - 0.5),
      correctAnswer: Sometimes"
    })
  },
  {
    id: "G10-ENG-ADV-03",
    grade: "Grade 10",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb indicates that an action happened in the past?,
      options: [Yesterday, Tomorrow, "Soon, Later"].sort(() => Math.random() - 0.5),
      correctAnswer: "Yesterday
    })
  },
  {
    id: G10-ENG-ADV-04",
    grade: "Grade 10,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Place",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which adverb indicates a location near the speaker?,
      options: [Here, There, Near", "Inside].sort(() => Math.random() - 0.5),
      correctAnswer: Here"
    })
  },
  {
    id: "G10-ENG-ADV-05",
    grade: "Grade 10",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Degree,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb modifies the adjective? 'The solution is ____ simple.',
      options: [Quite, Now, "There, Often"].sort(() => Math.random() - 0.5),
      correctAnswer: "Quite
    })
  },
  {
    id: G10-ENG-ADV-06",
    grade: "Grade 10,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Purpose",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which adverb explains the reason behind an action? 'He called his mother ____ tell her the good news.',
      options: [To, For, Because", "So].sort(() => Math.random() - 0.5),
      correctAnswer: To"
    })
  },

  // --- TOPIC: CONJUNCTIONS (6 Materials) ---
  {
    id: "G10-ENG-CON-01",
    grade: "Grade 10",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Coordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which coordinating conjunction joins two similar ideas? 'I like coffee ____ tea.',
      options: [and, but, "or, so"].sort(() => Math.random() - 0.5),
      correctAnswer: "and
    })
  },
  {
    id: G10-ENG-CON-02",
    grade: "Grade 10,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Subordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Complete: 'We left early ____ we could catch the bus.',
      options: [so that, because, while", "unless].sort(() => Math.random() - 0.5),
      correctAnswer: so that"
    })
  },
  {
    id: "G10-ENG-CON-03",
    grade: "Grade 10",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Correlative Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Select the correct correlative conjunction: '____ you eat vegetables, ____ you will stay healthy.',
      options: [If ... then, Either ... or", "Neither ... nor, Not only ... but also"].sort(() => Math.random() - 0.5),
      correctAnswer: "If ... then
    })
  },
  {
    id: G10-ENG-CON-04",
    grade: "Grade 10,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Coordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Which conjunction joins two contrasting ideas? 'She is rich, ____ she is not happy.',
      options: [but, and, or", "so].sort(() => Math.random() - 0.5),
      correctAnswer: but"
    })
  },
  {
    id: "G10-ENG-CON-05",
    grade: "Grade 10",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Subordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Complete: '____ it was late, we continued working.',
      options: [Although, Because", "Since, Unless"].sort(() => Math.random() - 0.5),
      correctAnswer: "Although
    })
  },
  {
    id: G10-ENG-CON-06",
    grade: "Grade 10,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Conjunctive Adverbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which conjunctive adverb shows a contrast? 'He was tired; ____, he kept working.',
      options: [However, Moreover, Therefore", "Consequently].sort(() => Math.random() - 0.5),
      correctAnswer: However"
    })
  },

  // --- TOPIC: READING COMPREHENSION (6 Materials) ---
  {
    id: "G10-ENG-RDC-01",
    grade: "Grade 10",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Tone and Mood,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The serene valley lay quiet under the pale moonlight. The gentle breeze carried the scent of flowers.' What is the mood of this passage?,
      options: [Peaceful and calm, Angry and tense, "Funny and playful, Scary and dark"].sort(() => Math.random() - 0.5),
      correctAnswer: "Peaceful and calm
    })
  },
  {
    id: G10-ENG-RDC-02",
    grade: "Grade 10,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Understanding Persuasive Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'Our environment is in danger. Every day, we lose more trees. It is time to act now before it is too late.' What persuasive technique is used?,
      options: [Appeal to urgency, Appeal to fear, Appeal to logic", "Appeal to entertainment].sort(() => Math.random() - 0.5),
      correctAnswer: Appeal to urgency"
    })
  },
  {
    id: "G10-ENG-RDC-03",
    grade: "Grade 10",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Character Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'At first, Mwangi was shy and reserved. But as he joined the drama club, he became more confident and outgoing.' How did Mwangi change?,
      options: ["He became more confident., He became more angry.", "He became lazy., He became a teacher."].sort(() => Math.random() - 0.5),
      correctAnswer: "He became more confident.
    })
  },
  {
    id: G10-ENG-RDC-04",
    grade: "Grade 10,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Identifying Bias",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read: 'The new model of this car is the greatest invention ever. It is clearly the best car on the market.' Is this statement unbiased?,
      options: [No, it is biased., Yes, it is a fact., Yes, it is neutral.", "No, it is scientific.].sort(() => Math.random() - 0.5),
      correctAnswer: No, it is biased."
    })
  },
  {
    id: "G10-ENG-RDC-05",
    grade: "Grade 10",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Drawing Conclusions,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Read: 'The Kikuyu community is the largest ethnic group in Kenya. They are known for their agricultural skills and rich oral traditions.' What conclusion can you draw?,
      options: [The Kikuyu are a significant and culturally rich group., The Kikuyu are a small group., "The Kikuyu are from Europe., The Kikuyu are a modern tribe."].sort(() => Math.random() - 0.5),
      correctAnswer: "The Kikuyu are a significant and culturally rich group.
    })
  },
  {
    id: G10-ENG-RDC-06",
    grade: "Grade 10,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Comparing Texts",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Read Text A: 'Kenya is a country in East Africa.' Read Text B: 'Kenya is the most beautiful country in the world.' How are these two texts different?,
      options: [Text A is a fact; Text B is an opinion., Both are facts., Both are opinions.", "Text A is an opinion; Text B is a fact.].sort(() => Math.random() - 0.5),
      correctAnswer: Text A is a fact; Text B is an opinion."
    })
  }
  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD SENIOR SECONDARY)
  // =========================================================================

  // --- TOPIC: NOUNS (5 Materials) ---
  {
    id: "G11-ENG-NOU-01",
    grade: "Grade 11",
    subject: "English",
    topic: "Nouns",
    subtopic: "Abstract Nouns in Literature,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "In the novel, the protagonist's greatest ____ was his fear of failure. Which abstract noun best fits the sentence?,
      options: [Weakness, Strength", "Power, Vision"].sort(() => Math.random() - 0.5),
      correctAnswer: "Weakness
    })
  },
  {
    id: G11-ENG-NOU-02",
    grade: "Grade 11,
    subject: English",
    topic: "Nouns,
    subtopic: "Compound Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which compound noun correctly names the person who designs and creates building structures?,
      options: [Architect, Builder, Engineer", "Plumber].sort(() => Math.random() - 0.5),
      correctAnswer: Architect"
    })
  },
  {
    id: "G11-ENG-NOU-03",
    grade: "Grade 11",
    subject: "English",
    topic: "Nouns",
    subtopic: "Collective Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What collective noun refers to a group of people gathered together for a religious ceremony?,
      options: [Congregation, Herd, "Flock, Pack"].sort(() => Math.random() - 0.5),
      correctAnswer: "Congregation
    })
  },
  {
    id: G11-ENG-NOU-04",
    grade: "Grade 11,
    subject: English",
    topic: "Nouns,
    subtopic: "Proper Nouns in East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which is a proper noun for the highest mountain in Africa, partially located in Kenya?,
      options: [Mount Kilimanjaro, Mount Kenya, Mount Everest", "Mount Atlas].sort(() => Math.random() - 0.5),
      correctAnswer: Mount Kilimanjaro"
    })
  },
  {
    id: "G11-ENG-NOU-05",
    grade: "Grade 11",
    subject: "English",
    topic: "Nouns",
    subtopic: "Countable vs Uncountable,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which of the following nouns is generally uncountable in English?,
      options: [Information, Chair, "Table, Book"].sort(() => Math.random() - 0.5),
      correctAnswer: "Information
    })
  },

  // --- topic: "VERBS (6 Materials) ---
  {
    id: G11-ENG-VER-01",
    grade: "Grade 11,
    subject: English",
    topic: "Verbs,
    subtopic: "Advanced Action Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which verb describes the action of skillfully persuading someone to do something?,
      options: [Convince, Force, Order", "Ignore].sort(() => Math.random() - 0.5),
      correctAnswer: Convince"
    })
  },
  {
    id: "G11-ENG-VER-02",
    grade: "Grade 11",
    subject: "English",
    topic: "Verbs",
    subtopic: "Active and Passive Voice,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Convert to passive voice: 'The government will implement the new policy.',
      options: [The new policy will be implemented by the government., The government will be implemented., "The policy will implement the government., The new policy was implemented."].sort(() => Math.random() - 0.5),
      correctAnswer: "The new policy will be implemented by the government.
    })
  },
  {
    id: G11-ENG-VER-03",
    grade: "Grade 11,
    subject: English",
    topic: "Verbs,
    subtopic: "Past Perfect Tense",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Complete the sentence: 'She realized she ____ him before.' (Past perfect of 'meet'),
      options: [had met, met, has met", "meets].sort(() => Math.random() - 0.5),
      correctAnswer: had met"
    })
  },
  {
    id: "G11-ENG-VER-04",
    grade: "Grade 11",
    subject: "English",
    topic: "Verbs",
    subtopic: "Reported Speech,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Reported speech: 'I have finished my homework,' he said. What is the correct reported form?,
      options: [He said he had finished his homework., He said he has finished his homework.", "He says he finished., He said he finishes."].sort(() => Math.random() - 0.5),
      correctAnswer: "He said he had finished his homework.
    })
  },
  {
    id: G11-ENG-VER-05",
    grade: "Grade 11,
    subject: English",
    topic: "Verbs,
    subtopic: "Conditional Sentences (Type 3)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Which conditional sentence is correct? 'If I ____ known, I would have helped.',
      options: [had, have, has", "having].sort(() => Math.random() - 0.5),
      correctAnswer: had"
    })
  },
  {
    id: "G11-ENG-VER-06",
    grade: "Grade 11",
    subject: "English",
    topic: "Verbs",
    subtopic: "Phrasal Verbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Select the phrasal verb that means 'to postpone or delay'.,
      options: [Put off, Give up, "Run out, Sit down"].sort(() => Math.random() - 0.5),
      correctAnswer: "Put off
    })
  },

  // --- topic: "ADJECTIVES (6 Materials) ---
  {
    id: G11-ENG-ADJ-01",
    grade: "Grade 11,
    subject: English",
    topic: "Adjectives,
    subtopic: "Comparative Adjectives (Irregular)",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the comparative adjective for the word 'bad'?,
      options: [Worse, Badder, Worst", "More bad].sort(() => Math.random() - 0.5),
      correctAnswer: Worse"
    })
  },
  {
    id: "G11-ENG-ADJ-02",
    grade: "Grade 11",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Superlative Adjectives (Irregular),
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Select the superlative form for 'far': 'This is the ____ distance I have ever run.',
      options: [farthest, farther, "far, more far"].sort(() => Math.random() - 0.5),
      correctAnswer: "farthest
    })
  },
  {
    id: G11-ENG-ADJ-03",
    grade: "Grade 11,
    subject: English",
    topic: "Adjectives,
    subtopic: "Possessive Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Complete the sentence: 'This is ____ company.' (Possessive for 'they'),
      options: [their, our, my", "your].sort(() => Math.random() - 0.5),
      correctAnswer: their"
    })
  },
  {
    id: "G11-ENG-ADJ-04",
    grade: "Grade 11",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quantity,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adjective indicates a very large, unspecified number?,
      options: [Numerous, Few", "Some, Any"].sort(() => Math.random() - 0.5),
      correctAnswer: "Numerous
    })
  },
  {
    id: G11-ENG-ADJ-05",
    grade: "Grade 11,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quality",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Which adjective describes a person who is deeply respected and admired by many?,
      options: [Distinguished, Ordinary, Common", "Unknown].sort(() => Math.random() - 0.5),
      correctAnswer: Distinguished"
    })
  },
  {
    id: "G11-ENG-ADJ-06",
    grade: "Grade 11",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Opinion,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which adjective expresses a strong positive opinion about a person's character?,
      options: [Admirable, Terrible, "Awful, Boring"].sort(() => Math.random() - 0.5),
      correctAnswer: "Admirable
    })
  },

  // --- topic: "ADVERBS (6 Materials) ---
  {
    id: G11-ENG-ADV-01",
    grade: "Grade 11,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Manner",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adverb describes how someone performs an action with extreme caution?,
      options: [Cautiously, Quickly, Slowly", "Gently].sort(() => Math.random() - 0.5),
      correctAnswer: Cautiously"
    })
  },
  {
    id: "G11-ENG-ADV-02",
    grade: "Grade 11",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Frequency,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb indicates that an action happens regularly?,
      options: [Usually, Never, "Sometimes, Now"].sort(() => Math.random() - 0.5),
      correctAnswer: "Usually
    })
  },
  {
    id: G11-ENG-ADV-03",
    grade: "Grade 11,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Time",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adverb indicates an action that happens immediately?,
      options: [Now, Later, Soon", "Yesterday].sort(() => Math.random() - 0.5),
      correctAnswer: Now"
    })
  },
  {
    id: "G11-ENG-ADV-04",
    grade: "Grade 11",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Place,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Which adverb indicates a location outside of the current area?,
      options: [Outside, Inside, "Here, There"].sort(() => Math.random() - 0.5),
      correctAnswer: "Outside
    })
  },
  {
    id: G11-ENG-ADV-05",
    grade: "Grade 11,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Degree",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adverb modifies the adjective? 'The view is ____ breathtaking.',
      options: [Absolutely, Now, There", "Often].sort(() => Math.random() - 0.5),
      correctAnswer: Absolutely"
    })
  },
  {
    id: "G11-ENG-ADV-06",
    grade: "Grade 11",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Purpose,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which adverb explains the reason behind an action? 'She woke up early ____ catch the train.',
      options: [To, For, "Because, So"].sort(() => Math.random() - 0.5),
      correctAnswer: "To
    })
  },

  // --- topic: "CONJUNCTIONS (6 Materials) ---
  {
    id: G11-ENG-CON-01",
    grade: "Grade 11,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Coordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which coordinating conjunction is used to show a reason or result? 'He was late, ____ he missed the beginning.',
      options: [so, but, and", "or].sort(() => Math.random() - 0.5),
      correctAnswer: so"
    })
  },
  {
    id: "G11-ENG-CON-02",
    grade: "Grade 11",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Subordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Complete: '____ you help me, I will finish the work faster.',
      options: [If, Because", "While, Unless"].sort(() => Math.random() - 0.5),
      correctAnswer: "If
    })
  },
  {
    id: G11-ENG-CON-03",
    grade: "Grade 11,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Correlative Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Select the correct correlative conjunction: '____ do I respect her, ____ I admire her.',
      options: [Not only ... but also, Either ... or, Neither ... nor", "If ... then].sort(() => Math.random() - 0.5),
      correctAnswer: Not only ... but also"
    })
  },
  {
    id: "G11-ENG-CON-04",
    grade: "Grade 11",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Coordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Which conjunction joins two alternatives? 'We can go to the movies ____ the park.',
      options: [or, but, "and, so"].sort(() => Math.random() - 0.5),
      correctAnswer: "or
    })
  },
  {
    id: G11-ENG-CON-05",
    grade: "Grade 11,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Subordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Complete: 'We will wait ____ she arrives.',
      options: [until, because, while", "unless].sort(() => Math.random() - 0.5),
      correctAnswer: until"
    })
  },
  {
    id: "G11-ENG-CON-06",
    grade: "Grade 11",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Conjunctive Adverbs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which conjunctive adverb adds information? 'She is a talented singer; ____, she is a great dancer.',
      options: [Moreover, However", "Therefore, Consequently"].sort(() => Math.random() - 0.5),
      correctAnswer: "Moreover
    })
  },

  // --- topic: "READING COMPREHENSION (6 Materials) ---
  {
    id: G11-ENG-RDC-01",
    grade: "Grade 11,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Analyzing Author's Bias",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Read: 'The new stadium is the best thing that has happened to this city. It will attract investors and tourists.' What is the author's bias?,
      options: [The author strongly supports the stadium., The author hates the stadium., The author is neutral.", "The author is against the city.].sort(() => Math.random() - 0.5),
      correctAnswer: The author strongly supports the stadium."
    })
  },
  {
    id: "G11-ENG-RDC-02",
    grade: "Grade 11",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Complex Characters,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Read: 'Kibet was a man of great ambition. He rose from poverty to become a successful businessman, but he lost all his friends along the way.' What is the complexity of Kibet?,
      options: [He is successful but lonely., He is poor and happy.", "He has many friends., He is a lazy man."].sort(() => Math.random() - 0.5),
      correctAnswer: "He is successful but lonely.
    })
  },
  {
    id: G11-ENG-RDC-03",
    grade: "Grade 11,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Identifying Satire",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Read: 'The government promised to build 10,000 new houses last year. So far, they have built 10.' What literary technique is used here?,
      options: [Satire, Metaphor, Simile", "Personification].sort(() => Math.random() - 0.5),
      correctAnswer: Satire"
    })
  },
  {
    id: "G11-ENG-RDC-04",
    grade: "Grade 11",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Understanding Dramatic Irony,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Read: 'The audience knew the villain was hiding behind the curtain, but the hero did not.' What literary device is this?,
      options: [Dramatic irony, Situational irony", "Verbal irony, Metaphor"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dramatic irony
    })
  },
  {
    id: G11-ENG-RDC-05",
    grade: "Grade 11,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Evaluating Arguments",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Read: 'We must reduce carbon emissions immediately. If we don't, global temperatures will rise, leading to devastating effects.' Is this a strong argument?,
      options: [Yes, it is logical and urgent., No, it is weak., No, it is funny.", "Yes, it is irrelevant.].sort(() => Math.random() - 0.5),
      correctAnswer: Yes, it is logical and urgent."
    })
  },
  {
    id: "G11-ENG-RDC-06",
    grade: "Grade 11",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Poetry,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Read the poem: 'The sun danced on the water / The waves sang a sweet melody.' What poetic device is used?,
      options: [Personification, Simile, "Metaphor, Alliteration"].sort(() => Math.random() - 0.5),
      correctAnswer: "Personification
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD SENIOR SECONDARY - COMPLETION)
  // =========================================================================

  // --- topic: "NOUNS (5 Materials) ---
  {
    id: G12-ENG-NOU-01",
    grade: "Grade 12,
    subject: English",
    topic: "Nouns,
    subtopic: "Abstract Nouns in Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Which abstract noun is essential for a democratic society?,
      options: [Freedom, Slavery, Fear", "Jealousy].sort(() => Math.random() - 0.5),
      correctAnswer: Freedom"
    })
  },
  {
    id: "G12-ENG-NOU-02",
    grade: "Grade 12",
    subject: "English",
    topic: "Nouns",
    subtopic: "Compound Nouns,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which compound noun refers to a person who takes part in an election?,
      options: [Voter, Citizen, "Resident, Leader"].sort(() => Math.random() - 0.5),
      correctAnswer: "Voter
    })
  },
  {
    id: G12-ENG-NOU-03",
    grade: "Grade 12,
    subject: English",
    topic: "Nouns,
    subtopic: "Collective Nouns in Politics",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " What collective noun refers to the group of people who make laws in a country?,
      options: [Parliament, Team, Herd", "Pack].sort(() => Math.random() - 0.5),
      correctAnswer: Parliament"
    })
  },
  {
    id: "G12-ENG-NOU-04",
    grade: "Grade 12",
    subject: "English",
    topic: "Nouns",
    subtopic: "Proper Nouns in East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which is a proper noun for the capital city of Tanzania?,
      options: [Dodoma, Nairobi, "Kampala, Kigali"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dodoma
    })
  },
  {
    id: G12-ENG-NOU-05",
    grade: "Grade 12,
    subject: English",
    topic: "Nouns,
    subtopic: "Countable and Uncountable Nouns",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which of the following nouns can be both countable and uncountable depending on context?,
      options: [Glass, Sand, Water", "Rice].sort(() => Math.random() - 0.5),
      correctAnswer: Glass"
    })
  },

  // --- TOPIC: VERBS (6 Materials) ---
  {
    id: "G12-ENG-VER-01",
    grade: "Grade 12",
    subject: "English",
    topic: "Verbs",
    subtopic: "Verbs in Formal Writing,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Which verb is most appropriate in formal writing to mean 'to put an end to something'?,
      options: [Terminate, Stop, "Finish, End"].sort(() => Math.random() - 0.5),
      correctAnswer: "Terminate
    })
  },
  {
    id: G12-ENG-VER-02",
    grade: "Grade 12,
    subject: English",
    topic: "Verbs,
    subtopic: "Active and Passive Voice",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Convert to passive voice: 'The committee approved the proposal.',
      options: [The proposal was approved by the committee., The proposal approves the committee., The committee was approved.", "The proposal is approving.].sort(() => Math.random() - 0.5),
      correctAnswer: The proposal was approved by the committee."
    })
  },
  {
    id: "G12-ENG-VER-03",
    grade: "Grade 12",
    subject: "English",
    topic: "Verbs",
    subtopic: "Past Perfect Tense,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Complete the sentence: 'By the time we arrived, they ____ dinner.' (Past perfect of 'serve'),
      options: [had served, served", "has served, serves"].sort(() => Math.random() - 0.5),
      correctAnswer: "had served
    })
  },
  {
    id: G12-ENG-VER-04",
    grade: "Grade 12,
    subject: English",
    topic: "Verbs,
    subtopic: "Reported Speech",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Reported speech: 'I will be there,' she said. What is the correct reported form?,
      options: [She said she would be there., She said she will be there., She says she is there.", "She said she was there.].sort(() => Math.random() - 0.5),
      correctAnswer: She said she would be there."
    })
  },
  {
    id: "G12-ENG-VER-05",
    grade: "Grade 12",
    subject: "English",
    topic: "Verbs",
    subtopic: "Mixed Conditionals,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Which mixed conditional is correct? 'If I ____ more careful, I wouldn't have lost it.',
      options: [had been, was", "am, is"].sort(() => Math.random() - 0.5),
      correctAnswer: "had been
    })
  },
  {
    id: G12-ENG-VER-06",
    grade: "Grade 12,
    subject: English",
    topic: "Verbs,
    subtopic: "Phrasal Verbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Select the phrasal verb that means 'to continue doing something despite difficulties'.,
      options: [Carry on, Give up, Run out", "Sit down].sort(() => Math.random() - 0.5),
      correctAnswer: Carry on"
    })
  },

  // --- TOPIC: ADJECTIVES (6 Materials) ---
  {
    id: "G12-ENG-ADJ-01",
    grade: "Grade 12",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Comparative Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the comparative adjective for the word 'important'?,
      options: [More important, Importanter, "Importantest, Most important"].sort(() => Math.random() - 0.5),
      correctAnswer: "More important
    })
  },
  {
    id: G12-ENG-ADJ-02",
    grade: "Grade 12,
    subject: English",
    topic: "Adjectives,
    subtopic: "Superlative Adjectives",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Select the superlative form: 'This is the ____ decision we have ever made.',
      options: [hardest, hard, harder", "more hard].sort(() => Math.random() - 0.5),
      correctAnswer: hardest"
    })
  },
  {
    id: "G12-ENG-ADJ-03",
    grade: "Grade 12",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Possessive Adjectives,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Complete the sentence: 'This is ____ final answer.' (Possessive for 'we'),
      options: [our, their, "my, your"].sort(() => Math.random() - 0.5),
      correctAnswer: "our
    })
  },
  {
    id: G12-ENG-ADJ-04",
    grade: "Grade 12,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Quantity",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adjective indicates a very small, specific number?,
      options: [Few, Many, Numerous", "Various].sort(() => Math.random() - 0.5),
      correctAnswer: Few"
    })
  },
  {
    id: "G12-ENG-ADJ-05",
    grade: "Grade 12",
    subject: "English",
    topic: "Adjectives",
    subtopic: "Adjectives of Quality,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Which adjective describes a person who has achieved great success?,
      options: [Accomplished, Ordinary, "Unknown, Common"].sort(() => Math.random() - 0.5),
      correctAnswer: "Accomplished
    })
  },
  {
    id: G12-ENG-ADJ-06",
    grade: "Grade 12,
    subject: English",
    topic: "Adjectives,
    subtopic: "Adjectives of Opinion",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Which adjective expresses a strong negative opinion about a policy?,
      options: [Flawed, Excellent, Wonderful", "Great].sort(() => Math.random() - 0.5),
      correctAnswer: Flawed"
    })
  },

  // --- TOPIC: ADVERBS (6 Materials) ---
  {
    id: "G12-ENG-ADV-01",
    grade: "Grade 12",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Manner,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Which adverb describes how someone performs an action with great skill?,
      options: [Expertly, Quickly, "Slowly, Gently"].sort(() => Math.random() - 0.5),
      correctAnswer: "Expertly
    })
  },
  {
    id: G12-ENG-ADV-02",
    grade: "Grade 12,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Frequency",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adverb indicates that an action happens frequently?,
      options: [Often, Never, Sometimes", "Now].sort(() => Math.random() - 0.5),
      correctAnswer: Often"
    })
  },
  {
    id: "G12-ENG-ADV-03",
    grade: "Grade 12",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Time,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Which adverb indicates an action that happened in the distant past?,
      options: [Long ago, Soon, "Later, Now"].sort(() => Math.random() - 0.5),
      correctAnswer: "Long ago
    })
  },
  {
    id: G12-ENG-ADV-04",
    grade: "Grade 12,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Place",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which adverb indicates a location that is far away?,
      options: [There, Here, Near", "Inside].sort(() => Math.random() - 0.5),
      correctAnswer: There"
    })
  },
  {
    id: "G12-ENG-ADV-05",
    grade: "Grade 12",
    subject: "English",
    topic: "Adverbs",
    subtopic: "Adverbs of Degree,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Which adverb modifies the adjective? 'The solution is ____ perfect.',
      options: [Almost, Now, "There, Often"].sort(() => Math.random() - 0.5),
      correctAnswer: "Almost
    })
  },
  {
    id: G12-ENG-ADV-06",
    grade: "Grade 12,
    subject: English",
    topic: "Adverbs,
    subtopic: "Adverbs of Purpose",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Which adverb explains the reason behind an action? 'She studied hard ____ pass the exam.',
      options: [To, For, Because", "So].sort(() => Math.random() - 0.5),
      correctAnswer: To"
    })
  },

  // --- TOPIC: CONJUNCTIONS (6 Materials) ---
  {
    id: "G12-ENG-CON-01",
    grade: "Grade 12",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Coordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which coordinating conjunction shows a causal relationship? 'He was hungry, ____ he ate a large meal.',
      options: [so, but", "and, or"].sort(() => Math.random() - 0.5),
      correctAnswer: "so
    })
  },
  {
    id: G12-ENG-CON-02",
    grade: "Grade 12,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Subordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Complete: '____ she apologized, he still refused to forgive her.',
      options: [Even though, Because, Since", "Unless].sort(() => Math.random() - 0.5),
      correctAnswer: Even though"
    })
  },
  {
    id: "G12-ENG-CON-03",
    grade: "Grade 12",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Correlative Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Select the correct correlative conjunction: '____ you take responsibility, ____ we can fix this problem.',
      options: [Only if ... then, Either ... or", "Neither ... nor, Not only ... but also"].sort(() => Math.random() - 0.5),
      correctAnswer: "Only if ... then
    })
  },
  {
    id: G12-ENG-CON-04",
    grade: "Grade 12,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Coordinating Conjunctions",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which conjunction joins two contrasting ideas? 'She is wealthy, ____ she is not content.',
      options: [but, and, or", "so].sort(() => Math.random() - 0.5),
      correctAnswer: but"
    })
  },
  {
    id: "G12-ENG-CON-05",
    grade: "Grade 12",
    subject: "English",
    topic: "Conjunctions",
    subtopic: "Subordinating Conjunctions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Complete: 'We will proceed ____ the plan is approved.',
      options: [provided, because, "while, unless"].sort(() => Math.random() - 0.5),
      correctAnswer: "provided
    })
  },
  {
    id: G12-ENG-CON-06",
    grade: "Grade 12,
    subject: English",
    topic: "Conjunctions,
    subtopic: "Conjunctive Adverbs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Which conjunctive adverb adds emphasis to a point? 'She is brilliant; ____, she is extremely dedicated.',
      options: [Furthermore, However, Therefore", "Consequently].sort(() => Math.random() - 0.5),
      correctAnswer: Furthermore"
    })
  },

  // --- TOPIC: READING COMPREHENSION (6 Materials) ---
  {
    id: "G12-ENG-RDC-01",
    grade: "Grade 12",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Analyzing Author's Argument,
    maxUses: 5,
    usageCount: 0,
    minWords: 65,",
    generate: () => ({
      text: "Read: 'The new education policy is a necessary step. It focuses on practical skills. Critics argue it is too expensive, but the long-term benefits outweigh the costs.' What is the author's main argument?,
      options: [The policy's benefits outweigh its costs., The policy is too expensive.", "The policy is bad., The policy is unpopular."].sort(() => Math.random() - 0.5),
      correctAnswer: "The policy's benefits outweigh its costs.
    })
  },
  {
    id: G12-ENG-RDC-02",
    grade: "Grade 12,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Evaluating Evidence",
    maxUses: 5,
    usageCount: 0,
    minWords: 65,
    generate: () => ({
      text: " Read: 'The report states that deforestation has increased by 20% in the last decade. This data comes from satellite imagery.' Is the evidence reliable?,
      options: [Yes, because it is based on satellite imagery., No, because it is fake., No, because it is too old.", "Yes, because it is based on opinions.].sort(() => Math.random() - 0.5),
      correctAnswer: Yes, because it is based on satellite imagery."
    })
  },
  {
    id: "G12-ENG-RDC-03",
    grade: "Grade 12",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Understanding Allegory,
    maxUses: 5,
    usageCount: 0,
    minWords: 65,",
    generate: () => ({
      text: "Read: 'The lion and the lamb lived together. The lion ruled with justice, and the lamb lived in peace.' What is the allegorical meaning of the lion?,
      options: [The lion represents power and leadership., The lion represents weakness.", "The lion represents fear., The lion represents poverty."].sort(() => Math.random() - 0.5),
      correctAnswer: "The lion represents power and leadership.
    })
  },
  {
    id: G12-ENG-RDC-04",
    grade: "Grade 12,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Analyzing Symbolism",
    maxUses: 5,
    usageCount: 0,
    minWords: 65,
    generate: () => ({
      text: " Read: 'The rising sun cast a golden light over the new city, signaling a new beginning.' What does the rising sun symbolize?,
      options: [Hope and a new beginning., The end of the world., A rainy day.", "A boring day.].sort(() => Math.random() - 0.5),
      correctAnswer: Hope and a new beginning."
    })
  },
  {
    id: "G12-ENG-RDC-05",
    grade: "Grade 12",
    subject: "English",
    topic: "Reading Comprehension",
    subtopic: "Counterarguments,
    maxUses: 5,
    usageCount: 0,
    minWords: 65,",
    generate: () => ({
      text: "Read: 'The city plans to build a new highway. Supporters say it will reduce traffic. Opponents argue it will destroy the environment.' What is a counterargument mentioned?,
      options: [It will destroy the environment., It will reduce traffic., "It will create jobs., It will save money."].sort(() => Math.random() - 0.5),
      correctAnswer: "It will destroy the environment.
    })
  },
  {
    id: G12-ENG-RDC-06",
    grade: "Grade 12,
    subject: English",
    topic: "Reading Comprehension,
    subtopic: "Analyzing Themes in Literature",
    maxUses: 5,
    usageCount: 0,
    minWords: 65,
    generate: () => ({
      text: " Read the theme: 'A person's true character is revealed in times of adversity.' Which quote best supports this theme?,
      options: ['When the going gets tough, the tough get going.', 'Money is the root of all evil.', 'The early bird catches the worm.'", "'Every cloud has a silver lining.'].sort(() => Math.random() - 0.5),
      correctAnswer: 'When the going gets tough, the tough get going.'"
    })
  }
];


