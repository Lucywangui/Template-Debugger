export const historyAndCitizenshipTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD HISTORY AND CITIZENSHIP SYLLABUS)
  // =========================================================================

  // --- INTRODUCTION TO HISTORY AND CITIZENSHIP (3 Materials) ---
  {
    id: "G10-HC-IC-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Introduction to History and Citizenship",
    subtopic: "Definition of History",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "History is the study of past events and human experiences that have shaped societies. Which of the following best defines history as an academic discipline?,
      options: [
        History is the systematic study of past events, people, and societies, focusing on change and continuity over time, and using evidence from various sources to reconstruct and interpret the past.,
        History is the memorization of dates and names of important people.,
        "History is the study of only political events.,
        History is the collection of myths and legends."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "History is the systematic study of past events, people, and societies, focusing on change and continuity over time, and using evidence from various sources to reconstruct and interpret the past.
    })
  },
  {
    id: G10-HC-IC-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Introduction to History and Citizenship,
    subtopic: "Sources of History",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Historians rely on various sources to reconstruct the past. Which of the following is a primary source that provides direct evidence about a historical event?,
      options: [
        A primary source is a first-hand account or direct evidence of a historical event, such as diaries, letters, photographs, government documents, and eyewitness testimonies from the period being studied.,
        Textbooks are primary sources.,
        Secondary sources are first-hand accounts.",
        "Documentaries are primary sources.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A primary source is a first-hand account or direct evidence of a historical event, such as diaries, letters, photographs, government documents, and eyewitness testimonies from the period being studied."
    })
  },
  {
    id: "G10-HC-IC-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Introduction to History and Citizenship",
    subtopic: "Importance of History,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Studying history is important for understanding the present and shaping the future. Which of the following is a reason why studying history is valuable for citizens?,
      options: [
        History provides insights into human behavior, helps citizens understand their identity and heritage, develops critical thinking skills, and enables societies to learn from past mistakes and successes.,
        History is only useful for historians and academics.,
        "History has no practical application in modern life.,
        History is only about memorizing facts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "History provides insights into human behavior, helps citizens understand their identity and heritage, develops critical thinking skills, and enables societies to learn from past mistakes and successes.
    })
  },

  // --- EARLY HUMAN CIVILIZATIONS (5 Materials) ---
  {
    id: G10-HC-EC-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Ancient Egyptian Civilization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Ancient Egypt was one of the most influential early civilizations. Which of the following was a major contribution of Ancient Egypt to world civilization?,
      options: [
        Ancient Egypt made significant contributions including the development of hieroglyphic writing, the construction of monumental architecture such as pyramids, and advancements in mathematics, medicine, and astronomy.,
        Ancient Egypt only contributed to architecture.,
        Ancient Egypt was not influential in writing.",
        "Ancient Egypt's only contribution was to art.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ancient Egypt made significant contributions including the development of hieroglyphic writing, the construction of monumental architecture such as pyramids, and advancements in mathematics, medicine, and astronomy."
    })
  },
  {
    id: "G10-HC-EC-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Early Human Civilizations",
    subtopic: "Mesopotamian Civilization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Mesopotamia, known as the 'cradle of civilization,' was home to several ancient empires. Which of the following was a major achievement of the Mesopotamian civilization?,
      options: [
        "Mesopotamia is credited with the invention of writing (cuneiform), the development of the wheel, the concept of the city-state, and the creation of the first legal codes such as the Code of Hammurabi.,
        Mesopotamia only contributed to agriculture.",
        "Mesopotamia had no legal system.,
        Mesopotamia did not have written language."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mesopotamia is credited with the invention of writing (cuneiform), the development of the wheel, the concept of the city-state, and the creation of the first legal codes such as the Code of Hammurabi.
    })
  },
  {
    id: G10-HC-EC-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Greek Civilization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Ancient Greece laid the foundations for Western civilization in many areas. Which of the following is a lasting contribution of Ancient Greek civilization?,
      options: [
        Ancient Greece contributed the concept of democracy, the development of philosophy (Socrates, Plato, Aristotle), advances in mathematics and science, and the creation of epic literature such as the Iliad and Odyssey.,
        Ancient Greece only contributed to art and sculpture.,
        Ancient Greece did not contribute to political thought.",
        "Ancient Greece's only legacy is in sports.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ancient Greece contributed the concept of democracy, the development of philosophy (Socrates, Plato, Aristotle), advances in mathematics and science, and the creation of epic literature such as the Iliad and Odyssey."
    })
  },
  {
    id: "G10-HC-EC-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Early Human Civilizations",
    subtopic: "Roman Civilization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Roman Empire was one of the most powerful and influential empires in history. Which of the following is a major contribution of the Roman civilization to modern society?,
      options: [
        The Roman civilization contributed republican government structures, Roman law and the legal system, engineering (roads, aqueducts, concrete), and the spread of Christianity throughout the empire.,
        Rome only contributed to military technology.,
        "Rome had no influence on modern law.,
        Rome's only contribution was to architecture."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Roman civilization contributed republican government structures, Roman law and the legal system, engineering (roads, aqueducts, concrete), and the spread of Christianity throughout the empire.
    })
  },
  {
    id: G10-HC-EC-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Ancient African Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Kingdom of Kush was a powerful ancient civilization in Africa. Which of the following describes an achievement of the Kingdom of Kush?,
      options: [
        The Kingdom of Kush was a major power in the Nile Valley, known for its ironworking technology, its control of trade routes, its powerful armies, and the construction of pyramids and other monuments.,
        Kush was not influential in trade.,
        Kush had no advanced technology.",
        "Kush was a small, insignificant kingdom.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kingdom of Kush was a major power in the Nile Valley, known for its ironworking technology, its control of trade routes, its powerful armies, and the construction of pyramids and other monuments."
    })
  },

  // --- KENYAN HISTORY (6 Materials) ---
  {
    id: "G10-HC-KH-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Pre-Colonial Communities,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Before colonization, Kenya was home to various communities with distinct social, economic, and political systems. Which of the following describes the traditional social organization of the Maasai community in pre-colonial Kenya?,
      options: [
        "The Maasai had a highly organized social structure based on age sets, where elders held authority and young men progressed through distinct age grades (warriors to elders), with a strong emphasis on pastoralism and cattle ownership.,
        The Maasai were farmers with no age-based organization.",
        "The Maasai had no distinct social structure.,
        The Maasai were primarily hunter-gatherers."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maasai had a highly organized social structure based on age sets, where elders held authority and young men progressed through distinct age grades (warriors to elders), with a strong emphasis on pastoralism and cattle ownership.
    })
  },
  {
    id: G10-HC-KH-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Pre-Colonial Communities",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Agikuyu community had a well-organized political and social system in pre-colonial Kenya. Which of the following was a key feature of the Agikuyu governance system?,
      options: [
        The Agikuyu had a council of elders (Kiama) that made decisions on behalf of the community, settled disputes, and managed community affairs, with the main political unit being the village (itura).,
        The Agikuyu had a centralized kingdom with a single ruler.,
        The Agikuyu had no formal governance system.",
        "The Agikuyu were ruled by a foreign power.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Agikuyu had a council of elders (Kiama) that made decisions on behalf of the community, settled disputes, and managed community affairs, with the main political unit being the village (itura)."
    })
  },
  {
    id: "G10-HC-KH-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Colonial Period,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The colonial period in Kenya had a profound impact on the country's political, economic, and social structures. Which of the following was a major effect of British colonial rule in Kenya?,
      options: [
        "British colonial rule led to the alienation of African land, the introduction of forced labor, the disruption of traditional social structures, and the establishment of a political system that excluded Africans from meaningful participation.,
        Colonial rule only affected economic activities.",
        "Colonial rule had no impact on African societies.,
        British colonial rule was beneficial to all communities."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "British colonial rule led to the alienation of African land, the introduction of forced labor, the disruption of traditional social structures, and the establishment of a political system that excluded Africans from meaningful participation.
    })
  },
  {
    id: G10-HC-KH-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Struggle for Independence",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Mau Mau uprising was a significant event in Kenya's struggle for independence. Which of the following best describes the Mau Mau movement and its objectives?,
      options: [
        The Mau Mau movement was a liberation struggle that aimed to reclaim land from European settlers, end colonial oppression, and achieve independence for Kenya through armed resistance and political mobilization.,
        The Mau Mau movement was a religious organization.,
        The Mau Mau movement sought to maintain colonial rule.",
        "The Mau Mau movement was only concerned with trade.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Mau Mau movement was a liberation struggle that aimed to reclaim land from European settlers, end colonial oppression, and achieve independence for Kenya through armed resistance and political mobilization."
    })
  },
  {
    id: "G10-HC-KH-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Struggle for Independence,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya achieved independence from British colonial rule on December 12, 1963. Which of the following contributed to the success of Kenya's independence struggle?,
      options: [
        Kenya's independence was achieved through a combination of armed resistance (Mau Mau), political activism, constitutional negotiations, and international pressure, which ultimately led to the British granting independence.,
        Kenya's independence was achieved solely through armed struggle.",
        "Kenya's independence was granted without any pressure.,
        Kenya's independence was achieved through diplomacy only."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's independence was achieved through a combination of armed resistance (Mau Mau), political activism, constitutional negotiations, and international pressure, which ultimately led to the British granting independence.
    })
  },
  {
    id: G10-HC-KH-06",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Key Nationalist Leaders",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Various leaders played significant roles in Kenya's struggle for independence. Which of the following statements best describes the role of Jomo Kenyatta in Kenya's independence movement?,
      options: [
        Jomo Kenyatta was a prominent nationalist leader who became the first President of independent Kenya. He played a key role in mobilizing Kenyans for independence and negotiating with the British for self-rule.,
        Jomo Kenyatta opposed independence for Kenya.,
        Jomo Kenyatta was a colonial administrator.",
        "Jomo Kenyatta was not involved in politics.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Jomo Kenyatta was a prominent nationalist leader who became the first President of independent Kenya. He played a key role in mobilizing Kenyans for independence and negotiating with the British for self-rule."
    })
  },

  // --- CITIZENSHIP AND GOVERNANCE (5 Materials) ---
  {
    id: "G10-HC-CG-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "The Constitution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 is the supreme law of the land. Which of the following is a key principle of the Constitution of Kenya 2010?,
      options: [
        The Constitution of Kenya 2010 is based on key principles including the rule of law, the protection of human rights, the separation of powers, devolution of power, and the principle of national values and governance.,
        The Constitution only addresses the executive branch.,
        "The Constitution does not protect human rights.,
        The Constitution was written without public participation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Constitution of Kenya 2010 is based on key principles including the rule of law, the protection of human rights, the separation of powers, devolution of power, and the principle of national values and governance.
    })
  },
  {
    id: G10-HC-CG-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Citizenship and Governance,
    subtopic: "Citizenship",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Citizenship confers certain rights and responsibilities on individuals. Which of the following is a civic responsibility of a citizen of Kenya?,
      options: [
        A civic responsibility of citizens includes paying taxes, participating in democratic processes (such as voting), obeying the law, and contributing to the development of the country.,
        Citizens have no responsibilities to the state.,
        Citizenship only confers rights, not responsibilities.",
        "Voting is optional and not a responsibility.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A civic responsibility of citizens includes paying taxes, participating in democratic processes (such as voting), obeying the law, and contributing to the development of the country."
    })
  },
  {
    id: "G10-HC-CG-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "Rights,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Bill of Rights in the Constitution of Kenya 2010 guarantees various rights. Which of the following is protected under the right to freedom of expression?,
      options: [
        The right to freedom of expression protects the right to hold opinions without interference, to seek, receive, and impart information and ideas through any media, subject to reasonable limitations such as defamation laws.,
        Freedom of expression allows unlimited speech without any restrictions.,
        "Freedom of expression only protects government officials.,
        Freedom of expression does not apply to the media."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The right to freedom of expression protects the right to hold opinions without interference, to seek, receive, and impart information and ideas through any media, subject to reasonable limitations such as defamation laws.
    })
  },
  {
    id: G10-HC-CG-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Citizenship and Governance,
    subtopic: "Good Governance",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Good governance is essential for the effective functioning of a state. Which of the following is a characteristic of good governance?,
      options: [
        Good governance is characterized by transparency, accountability, rule of law, participation, responsiveness, and inclusivity, ensuring that decisions are made in the best interest of all citizens.,
        Good governance involves rule by force.,
        Good governance requires secrecy in decision-making.",
        "Good governance only benefits the wealthy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Good governance is characterized by transparency, accountability, rule of law, participation, responsiveness, and inclusivity, ensuring that decisions are made in the best interest of all citizens."
    })
  },
  {
    id: "G10-HC-CG-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "Electoral Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Elections are a fundamental aspect of democratic governance. Which of the following is a key principle of a credible and free and fair electoral process?,
      options: [
        A credible electoral process requires an independent electoral commission, equal opportunity for all candidates, transparent voter registration, secret ballot voting, and impartial dispute resolution mechanisms.,
        Elections should be conducted without any oversight.,
        "A credible election does not require transparency.,
        Voter registration is not important for elections."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A credible electoral process requires an independent electoral commission, equal opportunity for all candidates, transparent voter registration, secret ballot voting, and impartial dispute resolution mechanisms.
    })
  },

  // --- AFRICAN HISTORY (5 Materials) ---
  {
    id: G10-HC-AH-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Pre-Colonial Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Kingdom of Aksum was an ancient African kingdom known for its wealth and power. Which of the following describes a major achievement of the Kingdom of Aksum?,
      options: [
        The Kingdom of Aksum was a major trading power that controlled trade routes across the Red Sea, developed its own script (Ge'ez), and was one of the first African kingdoms to adopt Christianity as the state religion.,
        Aksum had no trade networks.,
        Aksum did not have its own writing system.",
        "Aksum was a small, insignificant kingdom.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kingdom of Aksum was a major trading power that controlled trade routes across the Red Sea, developed its own script (Ge'ez), and was one of the first African kingdoms to adopt Christianity as the state religion."
    })
  },
  {
    id: "G10-HC-AH-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "African History",
    subtopic: "Pre-Colonial Kingdoms,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Empire of Mali was one of the largest and wealthiest African empires. Which of the following is a notable achievement of the Empire of Mali?,
      options: [
        The Empire of Mali was known for its immense wealth from gold and salt trade, its development of trade routes, and the creation of intellectual centers such as Timbuktu, which became a center of Islamic learning.,
        Mali had no significant trade.,
        "Timbuktu was not an intellectual center.,
        Mali was not wealthy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Empire of Mali was known for its immense wealth from gold and salt trade, its development of trade routes, and the creation of intellectual centers such as Timbuktu, which became a center of Islamic learning.
    })
  },
  {
    id: G10-HC-AH-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Colonization",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Scramble for Africa led to the colonization of most of the continent by European powers. Which of the following was a key event that formalized the division of Africa among European powers?,
      options: [
        The Berlin Conference of 1884-85 formalized the partition of Africa among European powers, establishing rules for the claiming of African territories without regard for African interests or boundaries.,
        The Berlin Conference was about African development.,
        African leaders were consulted at the Berlin Conference.",
        "The Berlin Conference ended colonization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Berlin Conference of 1884-85 formalized the partition of Africa among European powers, establishing rules for the claiming of African territories without regard for African interests or boundaries."
    })
  },
  {
    id: "G10-HC-AH-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "African History",
    subtopic: "African Resistance,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African communities resisted colonial rule in various ways. Which of the following is an example of armed resistance against colonial rule?,
      options: [
        The Maji Maji Rebellion in Tanganyika (1905-1907) was a significant armed resistance movement against German colonial rule, led by various ethnic groups who fought against forced labor and land alienation.,
        The Maji Maji Rebellion was peaceful.,
        "African communities did not resist colonial rule.,
        All resistance movements were unsuccessful."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maji Maji Rebellion in Tanganyika (1905-1907) was a significant armed resistance movement against German colonial rule, led by various ethnic groups who fought against forced labor and land alienation.
    })
  },
  {
    id: G10-HC-AH-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Independence Movements",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Ghana was the first African country south of the Sahara to gain independence. Which of the following statements about Ghana's independence is correct?,
      options: [
        Ghana gained independence from British colonial rule in 1957 under the leadership of Kwame Nkrumah, who became the first President. Ghana's independence inspired other African independence movements.,
        Ghana gained independence in 1960.,
        Ghana's independence was achieved peacefully.",
        "Ghana was the last country in Africa to gain independence.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ghana gained independence from British colonial rule in 1957 under the leadership of Kwame Nkrumah, who became the first President. Ghana's independence inspired other African independence movements."
    })
  },

  // --- WORLD HISTORY (5 Materials) ---
  {
    id: "G10-HC-WH-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "Industrial Revolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Industrial Revolution was a major turning point in world history. Which of the following was a key effect of the Industrial Revolution on society?,
      options: [
        The Industrial Revolution led to urbanization, the growth of factories, the rise of the working class, significant changes in labor conditions, and advances in transportation and communication that reshaped economies and societies.,
        The Industrial Revolution had no social impact.,
        "The Industrial Revolution only affected agriculture.,
        The Industrial Revolution prevented urbanization."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Industrial Revolution led to urbanization, the growth of factories, the rise of the working class, significant changes in labor conditions, and advances in transportation and communication that reshaped economies and societies.
    })
  },
  {
    id: G10-HC-WH-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "World History,
    subtopic: "World War I",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " World War I (1914-1918) had significant global consequences. Which of the following was a cause of World War I?,
      options: [
        World War I was caused by a combination of factors including nationalism, militarism, alliances, imperialism, and the assassination of Archduke Franz Ferdinand, which triggered a series of events leading to war.,
        World War I was caused by a single event.,
        World War I was caused by economic depression.",
        "World War I was caused by religious conflict.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: World War I was caused by a combination of factors including nationalism, militarism, alliances, imperialism, and the assassination of Archduke Franz Ferdinand, which triggered a series of events leading to war."
    })
  },
  {
    id: "G10-HC-WH-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "World War II,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "World War II (1939-1945) was the most devastating conflict in human history. Which of the following was a significant consequence of World War II?,
      options: [
        World War II led to the establishment of the United Nations, the division of Europe into East and West, the beginning of the Cold War, and the acceleration of decolonization in Africa and Asia.,
        World War II had no global consequences.,
        "World War II prevented decolonization.,
        World War II only affected Europe."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "World War II led to the establishment of the United Nations, the division of Europe into East and West, the beginning of the Cold War, and the acceleration of decolonization in Africa and Asia.
    })
  },
  {
    id: G10-HC-WH-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "World History,
    subtopic: "The Cold War",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Cold War was a period of geopolitical tension between the United States and the Soviet Union. Which of the following was a characteristic of the Cold War?,
      options: [
        The Cold War was characterized by political tension, military competition, proxy wars, the nuclear arms race, and the ideological struggle between capitalism (USA) and communism (USSR), without direct military confrontation between the superpowers.,
        The Cold War was a direct military conflict.,
        The Cold War only affected the superpowers.",
        "The Cold War was a peaceful period.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Cold War was characterized by political tension, military competition, proxy wars, the nuclear arms race, and the ideological struggle between capitalism (USA) and communism (USSR), without direct military confrontation between the superpowers."
    })
  },
  {
    id: "G10-HC-WH-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "Decolonization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Decolonization was the process by which colonies gained independence from colonial powers. Which of the following was a factor that contributed to decolonization in Africa?,
      options: [
        Decolonization was driven by nationalist movements, the weakening of European powers after World War II, the formation of the United Nations and its support for self-determination, and international pressure against colonialism.,
        Decolonization was solely caused by African wars.,
        "European powers willingly gave up their colonies.,
        Decolonization was not supported by the UN."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Decolonization was driven by nationalist movements, the weakening of European powers after World War II, the formation of the United Nations and its support for self-determination, and international pressure against colonialism.
    })
  },

  // --- LEADERSHIP AND GOVERNANCE IN KENYA (6 Materials) ---
  {
    id: G10-HC-LG-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Political Leadership",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya has had several political leaders since independence. Which of the following describes the leadership style and legacy of Jomo Kenyatta as Kenya's first President?,
      options: [
        Jomo Kenyatta led Kenya through the early years of independence, focusing on nation-building, economic development, and maintaining stability. His presidency is associated with the slogan 'Harambee' (pulling together) and the promotion of national unity.,
        Jomo Kenyatta was a military ruler.,
        Jomo Kenyatta opposed development.",
        "Jomo Kenyatta was a colonial leader.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Jomo Kenyatta led Kenya through the early years of independence, focusing on nation-building, economic development, and maintaining stability. His presidency is associated with the slogan 'Harambee' (pulling together) and the promotion of national unity."
    })
  },
  {
    id: "G10-HC-LG-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "Political Leadership,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "President Daniel Arap Moi led Kenya from 1978 to 2002. Which of the following was a significant feature of Moi's presidency?,
      options: [
        Moi's presidency was characterized by the introduction of the 'Nyayo' philosophy (peace, love, and unity), increased authoritarian rule, the shift to a single-party system in 1982, and later the reintroduction of multi-party politics in 1991 under pressure.,
        Moi introduced democracy immediately.,
        "Moi's presidency was peaceful throughout.,
        Moi's rule did not affect the political system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Moi's presidency was characterized by the introduction of the 'Nyayo' philosophy (peace, love, and unity), increased authoritarian rule, the shift to a single-party system in 1982, and later the reintroduction of multi-party politics in 1991 under pressure.
    })
  },
  {
    id: G10-HC-LG-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Devolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Devolution is a key feature of the Constitution of Kenya 2010. Which of the following is a major objective of devolution in Kenya?,
      options: [
        Devolution aims to bring governance closer to the people, enhance public participation, improve service delivery, promote equitable development across regions, and reduce power concentration at the national level.,
        Devolution only creates more government jobs.,
        Devolution does not improve service delivery.",
        "Devolution is the same as decentralization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Devolution aims to bring governance closer to the people, enhance public participation, improve service delivery, promote equitable development across regions, and reduce power concentration at the national level."
    })
  },
  {
    id: "G10-HC-LG-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "Devolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 established county governments. Which of the following is a function of county governments in Kenya?,
      options: [
        County governments are responsible for functions including agriculture, health services, trade development, county roads, pre-primary education, and environmental management, as outlined in the Constitution of Kenya 2010.,
        County governments are responsible for defense.,
        "County governments handle foreign affairs.,
        County governments are responsible for higher education."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "County governments are responsible for functions including agriculture, health services, trade development, county roads, pre-primary education, and environmental management, as outlined in the Constitution of Kenya 2010.
    })
  },
  {
    id: G10-HC-LG-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Elections",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Elections are conducted in Kenya at both national and county levels. Which of the following bodies is responsible for conducting elections in Kenya?,
      options: [
        The Independent Electoral and Boundaries Commission (IEBC) is the independent constitutional body responsible for conducting and supervising elections and referenda in Kenya.,
        The Judiciary conducts elections.,
        The Executive conducts elections.",
        "The Parliament conducts elections.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Independent Electoral and Boundaries Commission (IEBC) is the independent constitutional body responsible for conducting and supervising elections and referenda in Kenya."
    })
  },
  {
    id: "G10-HC-LG-06",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "National Values,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "National values are the principles that guide the conduct of individuals and institutions in Kenya. Which of the following is a national value enshrined in the Constitution of Kenya 2010?,
      options: [
        National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.,
        National values are not in the Constitution.,
        "National values are optional.,
        National values only apply to government officials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD HISTORY AND CITIZENSHIP SYLLABUS)
  // =========================================================================

  // --- KENYAN INDEPENDENCE AND POST-INDEPENDENCE HISTORY (5 Materials) ---
  {
    id: G11-HC-KH-01",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Independence",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya achieved independence on December 12, 1963. Which of the following was a key challenge faced by Kenya immediately after independence?,
      options: [
        After independence, Kenya faced challenges including integrating diverse ethnic groups, addressing land grievances, building a unified national identity, developing the economy, and establishing effective governance institutions.,
        Kenya had no challenges after independence.,
        Only economic challenges existed.",
        "Kenya's independence was achieved peacefully.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: After independence, Kenya faced challenges including integrating diverse ethnic groups, addressing land grievances, building a unified national identity, developing the economy, and establishing effective governance institutions."
    })
  },
  {
    id: "G11-HC-KH-02",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History",
    subtopic: "Post-Independence Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya has experienced significant social and economic development since independence. Which of the following has been a major economic development strategy in Kenya?,
      options: [
        Kenya's economic development strategies have included agricultural modernization, industrialization (the 'Sessional Paper No. 10' of 1965), the promotion of tourism, and more recently, the Vision 2030 development blueprint for transforming the economy.,
        Kenya has no development strategy.,
        "Only agriculture has been emphasized.,
        Vision 2030 is not a development strategy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's economic development strategies have included agricultural modernization, industrialization (the 'Sessional Paper No. 10' of 1965), the promotion of tourism, and more recently, the Vision 2030 development blueprint for transforming the economy.
    })
  },
  {
    id: G11-HC-KH-03",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Constitutional Reforms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya has undergone significant constitutional reforms since independence. Which of the following was a major constitutional reform in Kenya's history?,
      options: [
        The Constitution of Kenya 2010 was a major reform that introduced devolution, a Bill of Rights, an independent judiciary, a reformed electoral system, and various checks and balances to limit executive power.,
        Kenya's Constitution was never reformed.,
        The 2010 Constitution was only about the executive.",
        "The Constitution did not introduce devolution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Constitution of Kenya 2010 was a major reform that introduced devolution, a Bill of Rights, an independent judiciary, a reformed electoral system, and various checks and balances to limit executive power."
    })
  },
  {
    id: "G11-HC-KH-04",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History",
    subtopic: "Kenya's Political Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's political development has been influenced by various factors. Which of the following statements about the political development of Kenya is correct?,
      options: [
        Kenya's political development has been characterized by a transition from a multi-party system in the 1960s, to a de facto one-party state in the 1980s, and back to multi-party politics in the 1990s, with the 2010 Constitution establishing devolution and a more robust system of checks and balances.,
        Kenya has always had a multi-party system.,
        "Kenya has never had devolution.,
        Kenya has never experienced political transitions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's political development has been characterized by a transition from a multi-party system in the 1960s, to a de facto one-party state in the 1980s, and back to multi-party politics in the 1990s, with the 2010 Constitution establishing devolution and a more robust system of checks and balances.
    })
  },
  {
    id: G11-HC-KH-05",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Economic Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Economic development has been a focus of successive Kenyan governments. Which of the following sectors has been a significant driver of Kenya's economic growth?,
      options: [
        Agriculture has been a key driver of Kenya's economy, employing a majority of the population and producing major exports such as tea, coffee, horticulture, and cut flowers.,
        Agriculture is not important for Kenya's economy.,
        Only tourism drives Kenya's economy.",
        "Kenya's economy is not dependent on agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Agriculture has been a key driver of Kenya's economy, employing a majority of the population and producing major exports such as tea, coffee, horticulture, and cut flowers."
    })
  },

  // --- GOVERNANCE AND DEMOCRACY (5 Materials) ---
  {
    id: "G11-HC-GD-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Democratic Principles,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Democracy is a form of government based on the will of the people. Which of the following is a fundamental principle of democracy?,
      options: [
        Democracy is founded on principles including popular sovereignty, political equality, majority rule with minority rights, free and fair elections, and the protection of human rights and fundamental freedoms.,
        Democracy is based on rule by a single leader.,
        "Democracy does not require elections.,
        Democracy does not protect rights."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Democracy is founded on principles including popular sovereignty, political equality, majority rule with minority rights, free and fair elections, and the protection of human rights and fundamental freedoms.
    })
  },
  {
    id: G11-HC-GD-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Governance and Democracy,
    subtopic: "Electoral Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Free and fair elections are essential for democratic governance. Which of the following is a key component of a free and fair electoral process?,
      options: [
        Free and fair elections require an independent electoral management body, transparent voter registration, equal media access for candidates, secret ballot voting, and credible mechanisms for resolving electoral disputes.,
        Elections are free and fair without any oversight.,
        Voter registration is optional.",
        "Media access does not affect election fairness.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Free and fair elections require an independent electoral management body, transparent voter registration, equal media access for candidates, secret ballot voting, and credible mechanisms for resolving electoral disputes."
    })
  },
  {
    id: "G11-HC-GD-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Constitutionalism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Constitutionalism is the principle that government authority is derived from and limited by a constitution. Which of the following is a key feature of constitutionalism?,
      options: [
        Constitutionalism is characterized by the rule of law, the limitation of government power, the protection of individual rights, the separation of powers, and the accountability of government to the people.,
        Constitutionalism gives unlimited power to the government.,
        "Constitutionalism does not protect individual rights.,
        Constitutionalism is optional for governments."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constitutionalism is characterized by the rule of law, the limitation of government power, the protection of individual rights, the separation of powers, and the accountability of government to the people.
    })
  },
  {
    id: G11-HC-GD-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Governance and Democracy,
    subtopic: "Civil Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Civil society organizations play an important role in democratic governance. Which of the following is a function of civil society in a democratic society?,
      options: [
        Civil society organizations advocate for citizens' rights, hold governments accountable, provide civic education, and promote public participation in governance and decision-making.,
        Civil society has no role in democracy.,
        Civil society only advocates for the government.",
        "Civil society only provides services without advocating.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Civil society organizations advocate for citizens' rights, hold governments accountable, provide civic education, and promote public participation in governance and decision-making."
    })
  },
  {
    id: "G11-HC-GD-05",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Media and Democracy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A free media is essential for democratic governance. Which of the following is the role of media in a democratic society?,
      options: [
        Media plays a crucial role in democracy by informing citizens, providing a platform for public debate, exposing government wrongdoing, holding leaders accountable, and serving as a watchdog for the public interest.,
        Media has no role in democracy.,
        "Media only entertains citizens.,
        Media is controlled by the government."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Media plays a crucial role in democracy by informing citizens, providing a platform for public debate, exposing government wrongdoing, holding leaders accountable, and serving as a watchdog for the public interest.
    })
  },

  // --- HUMAN RIGHTS AND FREEDOMS (5 Materials) ---
  {
    id: G11-HC-HR-01",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Types of Rights",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Human rights are fundamental rights inherent to all human beings. Which of the following is a civil right protected under the Constitution of Kenya 2010?,
      options: [
        Civil rights include the right to freedom of expression, the right to assembly and association, the right to a fair trial, and the right to political participation, among others protected by the Constitution.,
        Civil rights only include economic rights.,
        Civil rights are not protected in Kenya.",
        "Civil rights are only for government officials.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Civil rights include the right to freedom of expression, the right to assembly and association, the right to a fair trial, and the right to political participation, among others protected by the Constitution."
    })
  },
  {
    id: "G11-HC-HR-02",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Human Rights and Freedoms",
    subtopic: "Economic and Social Rights,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Economic and social rights ensure access to essential services. Which of the following is an economic and social right protected in Kenya?,
      options: [
        Economic and social rights include the right to education, health, housing, food, and water, as recognized in the Constitution of Kenya 2010.,
        Economic and social rights are not protected.,
        "The right to education is not a right.,
        The right to health is optional."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Economic and social rights include the right to education, health, housing, food, and water, as recognized in the Constitution of Kenya 2010.
    })
  },
  {
    id: G11-HC-HR-03",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Protection Mechanisms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Various institutions protect human rights in Kenya. Which of the following is a national institution responsible for promoting and protecting human rights?,
      options: [
        The Kenya National Commission on Human Rights (KNCHR) is the national institution established under the Constitution to promote and protect human rights, investigate complaints, and monitor compliance with human rights standards.,
        The Police service protects human rights.,
        The Judiciary only handles criminal cases.",
        "The Executive is responsible for human rights.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kenya National Commission on Human Rights (KNCHR) is the national institution established under the Constitution to promote and protect human rights, investigate complaints, and monitor compliance with human rights standards."
    })
  },
  {
    id: "G11-HC-HR-04",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Human Rights and Freedoms",
    subtopic: "Right to Equality,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Equality and non-discrimination are fundamental human rights. Which of the following is prohibited under the principle of equality in Kenya?,
      options: [
        Discrimination on grounds of race, gender, religion, age, ethnicity, disability, or social status is prohibited under the Constitution of Kenya 2010, which guarantees equal treatment and protection for all citizens.,
        Discrimination is allowed in some cases.,
        "Only gender discrimination is prohibited.,
        The Constitution does not prohibit discrimination."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Discrimination on grounds of race, gender, religion, age, ethnicity, disability, or social status is prohibited under the Constitution of Kenya 2010, which guarantees equal treatment and protection for all citizens.
    })
  },
  {
    id: G11-HC-HR-05",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Access to Justice",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Access to justice is essential for the protection of human rights. Which of the following is a barrier to access to justice in Kenya?,
      options: [
        Barriers to access to justice in Kenya include the high cost of legal services, limited court infrastructure, geographical distance from courts, lack of legal awareness, and delays in the court system.,
        Access to justice is easy for all citizens.,
        There are no barriers to access to justice.",
        "Legal services are free for everyone.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Barriers to access to justice in Kenya include the high cost of legal services, limited court infrastructure, geographical distance from courts, lack of legal awareness, and delays in the court system."
    })
  },

  // --- NATIONAL INTEGRATION AND COHESION (4 Materials) ---
  {
    id: "G11-HC-NI-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "National Integration and Cohesion",
    subtopic: "Ethnic Diversity,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya is a diverse country with many ethnic communities. Which of the following is a challenge of ethnic diversity in Kenya?,
      options: [
        Ethnic diversity can lead to challenges such as ethnic competition, negative ethnicity, political mobilization along ethnic lines, and conflicts that undermine national unity and development.,
        Ethnic diversity has no challenges.,
        "Ethnic diversity is only a political issue.,
        Negative ethnicity does not exist in Kenya."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethnic diversity can lead to challenges such as ethnic competition, negative ethnicity, political mobilization along ethnic lines, and conflicts that undermine national unity and development.
    })
  },
  {
    id: G11-HC-NI-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "National Integration and Cohesion,
    subtopic: "National Unity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " National unity is essential for a country's stability and development. Which of the following is a way to promote national unity in a diverse country like Kenya?,
      options: [
        National unity can be promoted through inclusive governance, celebration of cultural diversity, a national curriculum that promotes shared values, equitable distribution of resources, and institutions that represent all communities.,
        National unity can only be promoted through force.,
        National unity is not achievable.",
        "Promoting diversity is harmful to national unity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: National unity can be promoted through inclusive governance, celebration of cultural diversity, a national curriculum that promotes shared values, equitable distribution of resources, and institutions that represent all communities."
    })
  },
  {
    id: "G11-HC-NI-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "National Integration and Cohesion",
    subtopic: "Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Conflicts are inevitable in diverse societies. Which of the following is an effective mechanism for conflict resolution in Kenya?,
      options: [
        Conflict resolution mechanisms in Kenya include the court system, alternative dispute resolution (ADR) such as mediation and arbitration, traditional conflict resolution methods, and institutions like the National Cohesion and Integration Commission (NCIC).,
        Only courts are used for conflict resolution.,
        "Traditional methods are not effective.,
        The NCIC is not a conflict resolution mechanism."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conflict resolution mechanisms in Kenya include the court system, alternative dispute resolution (ADR) such as mediation and arbitration, traditional conflict resolution methods, and institutions like the National Cohesion and Integration Commission (NCIC).
    })
  },
  {
    id: G11-HC-NI-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "National Integration and Cohesion,
    subtopic: "The National Anthem and Symbols",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " National symbols play a role in promoting national identity and cohesion. Which of the following is a national symbol of Kenya?,
      options: [
        National symbols of Kenya include the national flag, the national anthem, the coat of arms, the national currency (Kenyan shilling), and the national bird and flower (the lilac-breasted roller and the orchid).,
        The national symbols have no significance.,
        The national anthem is not a symbol.",
        "The coat of arms is not a national symbol.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: National symbols of Kenya include the national flag, the national anthem, the coat of arms, the national currency (Kenyan shilling), and the national bird and flower (the lilac-breasted roller and the orchid)."
    })
  },

  // --- KENYA'S FOREIGN POLICY (4 Materials) ---
  {
    id: "G11-HC-KF-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenya's Foreign Policy",
    subtopic: "International Relations,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's foreign policy has evolved since independence. Which of the following is a key principle of Kenya's foreign policy?,
      options: [
        Kenya's foreign policy is based on principles including the preservation of national sovereignty, peaceful coexistence with other states, non-interference in internal affairs, and the promotion of regional and international peace and security.,
        Kenya's foreign policy has no principles.,
        "Kenya promotes foreign intervention.,
        Kenya does not participate in international affairs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's foreign policy is based on principles including the preservation of national sovereignty, peaceful coexistence with other states, non-interference in internal affairs, and the promotion of regional and international peace and security.
    })
  },
  {
    id: G11-HC-KF-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenya's Foreign Policy,
    subtopic: "Diplomacy",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Diplomacy is the practice of managing international relations. Which of the following is a tool of diplomacy used by Kenya?,
      options: [
        Kenya uses various diplomatic tools including bilateral and multilateral negotiations, embassies and diplomatic missions, participation in international organizations, and economic and cultural diplomacy.,
        Diplomacy is only about negotiations.,
        Kenya only uses military tools.",
        "Diplomacy is not important for Kenya.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya uses various diplomatic tools including bilateral and multilateral negotiations, embassies and diplomatic missions, participation in international organizations, and economic and cultural diplomacy."
    })
  },
  {
    id: "G11-HC-KF-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenya's Foreign Policy",
    subtopic: "Regional Integration,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya is an active participant in regional integration initiatives. Which of the following is a regional organization that Kenya is a member of?,
      options: [
        Kenya is a member of the East African Community (EAC), the Intergovernmental Authority on Development (IGAD), and the African Union (AU), and actively participates in regional integration efforts.,
        Kenya is not a member of any regional organization.,
        "Kenya is only a member of the UN.,
        Kenya is not part of the EAC."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya is a member of the East African Community (EAC), the Intergovernmental Authority on Development (IGAD), and the African Union (AU), and actively participates in regional integration efforts.
    })
  },
  {
    id: G11-HC-KF-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenya's Foreign Policy,
    subtopic: "International Organizations",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Kenya participates in various international organizations. Which of the following is the purpose of the United Nations (UN)?,
      options: [
        The United Nations was established to maintain international peace and security, promote human rights, foster social and economic development, and provide a forum for international cooperation.,
        The UN only focuses on peace.,
        The UN does not promote development.",
        "The UN is only for superpowers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The United Nations was established to maintain international peace and security, promote human rights, foster social and economic development, and provide a forum for international cooperation."
    })
  },

  // --- GLOBAL ISSUES (4 Materials) ---
  {
    id: "G11-HC-GI-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Global Issues",
    subtopic: "Globalization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Globalization refers to the increasing interconnectedness of the world. Which of the following is a positive effect of globalization on developing countries like Kenya?,
      options: [
        Globalization provides opportunities for developing countries through access to international markets, foreign investment, technology transfer, and the exchange of ideas and information.,
        Globalization only benefits developed countries.,
        "Globalization has no positive effects.,
        Globalization reduces access to markets."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Globalization provides opportunities for developing countries through access to international markets, foreign investment, technology transfer, and the exchange of ideas and information.
    })
  },
  {
    id: G11-HC-GI-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Global Issues,
    subtopic: "Climate Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Climate change is a global issue with significant impacts on countries like Kenya. Which of the following is a major effect of climate change in Kenya?,
      options: [
        Climate change has led to increased frequency of droughts, unpredictable rainfall patterns, reduced agricultural productivity, water scarcity, and negative effects on food security and livelihoods in Kenya.,
        Climate change has no effect on Kenya.,
        Climate change benefits agriculture.",
        "Kenya is not affected by climate change.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Climate change has led to increased frequency of droughts, unpredictable rainfall patterns, reduced agricultural productivity, water scarcity, and negative effects on food security and livelihoods in Kenya."
    })
  },
  {
    id: "G11-HC-GI-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Global Issues",
    subtopic: "Sustainable Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Sustainable development aims to meet present needs without compromising future generations. Which of the following is a key pillar of sustainable development?,
      options: [
        Sustainable development is based on three pillars: economic development, social development, and environmental protection, which must be balanced to achieve long-term sustainability.,
        Sustainable development only focuses on the environment.,
        "Sustainable development only focuses on economics.,
        Sustainable development is not achievable."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sustainable development is based on three pillars: economic development, social development, and environmental protection, which must be balanced to achieve long-term sustainability.
    })
  },
  {
    id: G11-HC-GI-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Global Issues,
    subtopic: "International Cooperation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " International cooperation is essential for addressing global challenges. Which of the following is a global challenge that requires international cooperation?,
      options: [
        Global challenges such as climate change, terrorism, infectious diseases, food insecurity, and conflict require international cooperation and collective action to address effectively.,
        Global challenges can be solved by individual countries.,
        Climate change is not a global challenge.",
        "Terrorism is not a global challenge.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Global challenges such as climate change, terrorism, infectious diseases, food insecurity, and conflict require international cooperation and collective action to address effectively."
    })
  },

  // --- CONSTITUTION AND THE LAW (4 Materials) ---
  {
    id: "G11-HC-CL-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Constitution and the Law",
    subtopic: "The Constitution of Kenya 2010,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 is the supreme law of the land. Which of the following is a principle established by the Constitution?,
      options: [
        The Constitution of Kenya 2010 establishes principles including the sovereignty of the people, the rule of law, the separation of powers, devolution, and the protection of human rights and fundamental freedoms.,
        The Constitution does not establish new principles.,
        "The Constitution does not protect human rights.,
        The Constitution centralizes power."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Constitution of Kenya 2010 establishes principles including the sovereignty of the people, the rule of law, the separation of powers, devolution, and the protection of human rights and fundamental freedoms.
    })
  },
  {
    id: G11-HC-CL-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Constitution and the Law,
    subtopic: "Separation of Powers",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The separation of powers is a key feature of the Constitution of Kenya 2010. Which of the following describes the doctrine of separation of powers?,
      options: [
        The separation of powers divides government among three independent branches: the Legislature (Parliament), the Executive (the President and Cabinet), and the Judiciary (courts), each with distinct functions and checks on the others.,
        Separation of powers gives all power to the Executive.,
        Separation of powers is not part of the Constitution.",
        "The Legislature and Judiciary are the same branch.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The separation of powers divides government among three independent branches: the Legislature (Parliament), the Executive (the President and Cabinet), and the Judiciary (courts), each with distinct functions and checks on the others."
    })
  },
  {
    id: "G11-HC-CL-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Constitution and the Law",
    subtopic: "Rule of Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The rule of law is a fundamental principle of constitutional governance. Which of the following is an element of the rule of law?,
      options: [
        The rule of law requires that all persons and institutions are subject to and accountable under the law, that laws are clear and publicly known, that courts are independent and impartial, and that the government acts within the law.,
        The rule of law allows the government to act above the law.,
        "The rule of law is optional.,
        The rule of law does not require independent courts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The rule of law requires that all persons and institutions are subject to and accountable under the law, that laws are clear and publicly known, that courts are independent and impartial, and that the government acts within the law.
    })
  },
  {
    id: G11-HC-CL-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Constitution and the Law,
    subtopic: "The Judicial System",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The judicial system in Kenya interprets and applies the law. Which of the following is the highest court in Kenya?,
      options: [
        The Supreme Court of Kenya is the highest court in the country, with jurisdiction over constitutional matters, presidential petitions, and final appellate decisions on matters of public importance.,
        The Court of Appeal is the highest court in Kenya.,
        The High Court is the highest court in Kenya.",
        "The Magistrate's Court is the highest court in Kenya.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Supreme Court of Kenya is the highest court in the country, with jurisdiction over constitutional matters, presidential petitions, and final appellate decisions on matters of public importance."
    })
  },

  // --- PATRIOTISM AND NATIONAL VALUES (4 Materials) ---
  {
    id: "G11-HC-PV-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Patriotism and National Values",
    subtopic: "National Values,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "National values are the moral principles that guide the conduct of citizens and institutions. Which of the following is a national value enshrined in the Constitution of Kenya 2010?,
      options: [
        National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.,
        National values are not in the Constitution.,
        "National values are optional.,
        National values only apply to government officials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.
    })
  },
  {
    id: G11-HC-PV-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Patriotism and National Values,
    subtopic: "Patriotism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Patriotism is love and devotion to one's country. Which of the following is a way citizens can demonstrate patriotism?,
      options: [
        Citizens demonstrate patriotism by participating in the democratic process (voting), respecting national symbols, paying taxes, contributing to national development, and working to promote peace and unity.,
        Patriotism is only about celebrating national holidays.,
        Patriotism does not require civic participation.",
        "Paying taxes is not a demonstration of patriotism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Citizens demonstrate patriotism by participating in the democratic process (voting), respecting national symbols, paying taxes, contributing to national development, and working to promote peace and unity."
    })
  },
  {
    id: "G11-HC-PV-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Patriotism and National Values",
    subtopic: "Civic Responsibility,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Civic responsibility involves the duties of citizens to their country. Which of the following is a civic responsibility of every Kenyan citizen?,
      options: [
        Civic responsibilities include paying taxes, obeying the law, participating in the electoral process, protecting the environment, and contributing to the development of the community and the country.,
        Civic responsibilities are optional.,
        "Civic responsibilities only apply to government employees.,
        Civic responsibilities are not important."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Civic responsibilities include paying taxes, obeying the law, participating in the electoral process, protecting the environment, and contributing to the development of the community and the country.
    })
  },
  {
    id: G11-HC-PV-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Patriotism and National Values,
    subtopic: "National Cohesion",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " National cohesion is the unity and solidarity of citizens across different communities. Which of the following is an institution that promotes national cohesion in Kenya?,
      options: [
        The National Cohesion and Integration Commission (NCIC) was established to promote national cohesion and integration, address negative ethnicity, and foster peaceful coexistence among the diverse communities in Kenya.,
        The NCIC only handles legal matters.,
        The NCIC is not a government institution.",
        "The NCIC promotes division.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The National Cohesion and Integration Commission (NCIC) was established to promote national cohesion and integration, address negative ethnicity, and foster peaceful coexistence among the diverse communities in Kenya."
    })
  }`nexport const historyAndCitizenshipTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD HISTORY AND CITIZENSHIP SYLLABUS)
  // =========================================================================
  {
    id: "G10-HC-IC-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Introduction to History and Citizenship",
    subtopic: "Definition of History",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: "History is the study of past events and human experiences that have shaped societies. Which of the following best defines history as an academic discipline?,
      options: [
        History is the systematic study of past events, people, and societies, focusing on change and continuity over time, and using evidence from various sources to reconstruct and interpret the past.,
        History is the memorization of dates and names of important people.,
        "History is the study of only political events.,
        History is the collection of myths and legends."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "History is the systematic study of past events, people, and societies, focusing on change and continuity over time, and using evidence from various sources to reconstruct and interpret the past.
    })
  },
  {
    id: G10-HC-IC-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Introduction to History and Citizenship,
    subtopic: "Sources of History",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Historians rely on various sources to reconstruct the past. Which of the following is a primary source that provides direct evidence about a historical event?,
      options: [
        A primary source is a first-hand account or direct evidence of a historical event, such as diaries, letters, photographs, government documents, and eyewitness testimonies from the period being studied.,
        Textbooks are primary sources.,
        Secondary sources are first-hand accounts.",
        "Documentaries are primary sources.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A primary source is a first-hand account or direct evidence of a historical event, such as diaries, letters, photographs, government documents, and eyewitness testimonies from the period being studied."
    })
  },
  {
    id: "G10-HC-IC-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Introduction to History and Citizenship",
    subtopic: "Importance of History,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Studying history is important for understanding the present and shaping the future. Which of the following is a reason why studying history is valuable for citizens?,
      options: [
        History provides insights into human behavior, helps citizens understand their identity and heritage, develops critical thinking skills, and enables societies to learn from past mistakes and successes.,
        History is only useful for historians and academics.,
        "History has no practical application in modern life.,
        History is only about memorizing facts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "History provides insights into human behavior, helps citizens understand their identity and heritage, develops critical thinking skills, and enables societies to learn from past mistakes and successes.
    })
  },
  {
    id: G10-HC-EC-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Ancient Egyptian Civilization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Ancient Egypt was one of the most influential early civilizations. Which of the following was a major contribution of Ancient Egypt to world civilization?,
      options: [
        Ancient Egypt made significant contributions including the development of hieroglyphic writing, the construction of monumental architecture such as pyramids, and advancements in mathematics, medicine, and astronomy.,
        Ancient Egypt only contributed to architecture.,
        Ancient Egypt was not influential in writing.",
        "Ancient Egypt's only contribution was to art.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ancient Egypt made significant contributions including the development of hieroglyphic writing, the construction of monumental architecture such as pyramids, and advancements in mathematics, medicine, and astronomy."
    })
  },
  {
    id: "G10-HC-EC-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Early Human Civilizations",
    subtopic: "Mesopotamian Civilization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Mesopotamia, known as the 'cradle of civilization,' was home to several ancient empires. Which of the following was a major achievement of the Mesopotamian civilization?,
      options: [
        "Mesopotamia is credited with the invention of writing (cuneiform), the development of the wheel, the concept of the city-state, and the creation of the first legal codes such as the Code of Hammurabi.,
        Mesopotamia only contributed to agriculture.",
        "Mesopotamia had no legal system.,
        Mesopotamia did not have written language."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Mesopotamia is credited with the invention of writing (cuneiform), the development of the wheel, the concept of the city-state, and the creation of the first legal codes such as the Code of Hammurabi.
    })
  },
  {
    id: G10-HC-EC-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Greek Civilization",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Ancient Greece laid the foundations for Western civilization in many areas. Which of the following is a lasting contribution of Ancient Greek civilization?,
      options: [
        Ancient Greece contributed the concept of democracy, the development of philosophy (Socrates, Plato, Aristotle), advances in mathematics and science, and the creation of epic literature such as the Iliad and Odyssey.,
        Ancient Greece only contributed to art and sculpture.,
        Ancient Greece did not contribute to political thought.",
        "Ancient Greece's only legacy is in sports.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ancient Greece contributed the concept of democracy, the development of philosophy (Socrates, Plato, Aristotle), advances in mathematics and science, and the creation of epic literature such as the Iliad and Odyssey."
    })
  },
  {
    id: "G10-HC-EC-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Early Human Civilizations",
    subtopic: "Roman Civilization,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Roman Empire was one of the most powerful and influential empires in history. Which of the following is a major contribution of the Roman civilization to modern society?,
      options: [
        The Roman civilization contributed republican government structures, Roman law and the legal system, engineering (roads, aqueducts, concrete), and the spread of Christianity throughout the empire.,
        Rome only contributed to military technology.,
        "Rome had no influence on modern law.,
        Rome's only contribution was to architecture."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Roman civilization contributed republican government structures, Roman law and the legal system, engineering (roads, aqueducts, concrete), and the spread of Christianity throughout the empire.
    })
  },
  {
    id: G10-HC-EC-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Early Human Civilizations,
    subtopic: "Ancient African Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Kingdom of Kush was a powerful ancient civilization in Africa. Which of the following describes an achievement of the Kingdom of Kush?,
      options: [
        The Kingdom of Kush was a major power in the Nile Valley, known for its ironworking technology, its control of trade routes, its powerful armies, and the construction of pyramids and other monuments.,
        Kush was not influential in trade.,
        Kush had no advanced technology.",
        "Kush was a small, insignificant kingdom.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kingdom of Kush was a major power in the Nile Valley, known for its ironworking technology, its control of trade routes, its powerful armies, and the construction of pyramids and other monuments."
    })
  },
  {
    id: "G10-HC-KH-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Pre-Colonial Communities,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Before colonization, Kenya was home to various communities with distinct social, economic, and political systems. Which of the following describes the traditional social organization of the Maasai community in pre-colonial Kenya?,
      options: [
        "The Maasai had a highly organized social structure based on age sets, where elders held authority and young men progressed through distinct age grades (warriors to elders), with a strong emphasis on pastoralism and cattle ownership.,
        The Maasai were farmers with no age-based organization.",
        "The Maasai had no distinct social structure.,
        The Maasai were primarily hunter-gatherers."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maasai had a highly organized social structure based on age sets, where elders held authority and young men progressed through distinct age grades (warriors to elders), with a strong emphasis on pastoralism and cattle ownership.
    })
  },
  {
    id: G10-HC-KH-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Pre-Colonial Communities",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Agikuyu community had a well-organized political and social system in pre-colonial Kenya. Which of the following was a key feature of the Agikuyu governance system?,
      options: [
        The Agikuyu had a council of elders (Kiama) that made decisions on behalf of the community, settled disputes, and managed community affairs, with the main political unit being the village (itura).,
        The Agikuyu had a centralized kingdom with a single ruler.,
        The Agikuyu had no formal governance system.",
        "The Agikuyu were ruled by a foreign power.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Agikuyu had a council of elders (Kiama) that made decisions on behalf of the community, settled disputes, and managed community affairs, with the main political unit being the village (itura)."
    })
  },
  {
    id: "G10-HC-KH-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Colonial Period,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The colonial period in Kenya had a profound impact on the country's political, economic, and social structures. Which of the following was a major effect of British colonial rule in Kenya?,
      options: [
        "British colonial rule led to the alienation of African land, the introduction of forced labor, the disruption of traditional social structures, and the establishment of a political system that excluded Africans from meaningful participation.,
        Colonial rule only affected economic activities.",
        "Colonial rule had no impact on African societies.,
        British colonial rule was beneficial to all communities."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "British colonial rule led to the alienation of African land, the introduction of forced labor, the disruption of traditional social structures, and the establishment of a political system that excluded Africans from meaningful participation.
    })
  },
  {
    id: G10-HC-KH-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Struggle for Independence",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Mau Mau uprising was a significant event in Kenya's struggle for independence. Which of the following best describes the Mau Mau movement and its objectives?,
      options: [
        The Mau Mau movement was a liberation struggle that aimed to reclaim land from European settlers, end colonial oppression, and achieve independence for Kenya through armed resistance and political mobilization.,
        The Mau Mau movement was a religious organization.,
        The Mau Mau movement sought to maintain colonial rule.",
        "The Mau Mau movement was only concerned with trade.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Mau Mau movement was a liberation struggle that aimed to reclaim land from European settlers, end colonial oppression, and achieve independence for Kenya through armed resistance and political mobilization."
    })
  },
  {
    id: "G10-HC-KH-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Kenyan History",
    subtopic: "Struggle for Independence,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya achieved independence from British colonial rule on December 12, 1963. Which of the following contributed to the success of Kenya's independence struggle?,
      options: [
        Kenya's independence was achieved through a combination of armed resistance (Mau Mau), political activism, constitutional negotiations, and international pressure, which ultimately led to the British granting independence.,
        Kenya's independence was achieved solely through armed struggle.",
        "Kenya's independence was granted without any pressure.,
        Kenya's independence was achieved through diplomacy only."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's independence was achieved through a combination of armed resistance (Mau Mau), political activism, constitutional negotiations, and international pressure, which ultimately led to the British granting independence.
    })
  },
  {
    id: G10-HC-KH-06",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Kenyan History,
    subtopic: "Key Nationalist Leaders",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Various leaders played significant roles in Kenya's struggle for independence. Which of the following statements best describes the role of Jomo Kenyatta in Kenya's independence movement?,
      options: [
        Jomo Kenyatta was a prominent nationalist leader who became the first President of independent Kenya. He played a key role in mobilizing Kenyans for independence and negotiating with the British for self-rule.,
        Jomo Kenyatta opposed independence for Kenya.,
        Jomo Kenyatta was a colonial administrator.",
        "Jomo Kenyatta was not involved in politics.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Jomo Kenyatta was a prominent nationalist leader who became the first President of independent Kenya. He played a key role in mobilizing Kenyans for independence and negotiating with the British for self-rule."
    })
  },
  {
    id: "G10-HC-CG-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "The Constitution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 is the supreme law of the land. Which of the following is a key principle of the Constitution of Kenya 2010?,
      options: [
        The Constitution of Kenya 2010 is based on key principles including the rule of law, the protection of human rights, the separation of powers, devolution of power, and the principle of national values and governance.,
        The Constitution only addresses the executive branch.,
        "The Constitution does not protect human rights.,
        The Constitution was written without public participation."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Constitution of Kenya 2010 is based on key principles including the rule of law, the protection of human rights, the separation of powers, devolution of power, and the principle of national values and governance.
    })
  },
  {
    id: G10-HC-CG-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Citizenship and Governance,
    subtopic: "Citizenship",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Citizenship confers certain rights and responsibilities on individuals. Which of the following is a civic responsibility of a citizen of Kenya?,
      options: [
        A civic responsibility of citizens includes paying taxes, participating in democratic processes (such as voting), obeying the law, and contributing to the development of the country.,
        Citizens have no responsibilities to the state.,
        Citizenship only confers rights, not responsibilities.",
        "Voting is optional and not a responsibility.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: A civic responsibility of citizens includes paying taxes, participating in democratic processes (such as voting), obeying the law, and contributing to the development of the country."
    })
  },
  {
    id: "G10-HC-CG-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "Rights,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Bill of Rights in the Constitution of Kenya 2010 guarantees various rights. Which of the following is protected under the right to freedom of expression?,
      options: [
        The right to freedom of expression protects the right to hold opinions without interference, to seek, receive, and impart information and ideas through any media, subject to reasonable limitations such as defamation laws.,
        Freedom of expression allows unlimited speech without any restrictions.,
        "Freedom of expression only protects government officials.,
        Freedom of expression does not apply to the media."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The right to freedom of expression protects the right to hold opinions without interference, to seek, receive, and impart information and ideas through any media, subject to reasonable limitations such as defamation laws.
    })
  },
  {
    id: G10-HC-CG-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Citizenship and Governance,
    subtopic: "Good Governance",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Good governance is essential for the effective functioning of a state. Which of the following is a characteristic of good governance?,
      options: [
        Good governance is characterized by transparency, accountability, rule of law, participation, responsiveness, and inclusivity, ensuring that decisions are made in the best interest of all citizens.,
        Good governance involves rule by force.,
        Good governance requires secrecy in decision-making.",
        "Good governance only benefits the wealthy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Good governance is characterized by transparency, accountability, rule of law, participation, responsiveness, and inclusivity, ensuring that decisions are made in the best interest of all citizens."
    })
  },
  {
    id: "G10-HC-CG-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Citizenship and Governance",
    subtopic: "Electoral Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Elections are a fundamental aspect of democratic governance. Which of the following is a key principle of a credible and free and fair electoral process?,
      options: [
        A credible electoral process requires an independent electoral commission, equal opportunity for all candidates, transparent voter registration, secret ballot voting, and impartial dispute resolution mechanisms.,
        Elections should be conducted without any oversight.,
        "A credible election does not require transparency.,
        Voter registration is not important for elections."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "A credible electoral process requires an independent electoral commission, equal opportunity for all candidates, transparent voter registration, secret ballot voting, and impartial dispute resolution mechanisms.
    })
  },
  {
    id: G10-HC-AH-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Pre-Colonial Kingdoms",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The Kingdom of Aksum was an ancient African kingdom known for its wealth and power. Which of the following describes a major achievement of the Kingdom of Aksum?,
      options: [
        The Kingdom of Aksum was a major trading power that controlled trade routes across the Red Sea, developed its own script (Ge'ez), and was one of the first African kingdoms to adopt Christianity as the state religion.,
        Aksum had no trade networks.,
        Aksum did not have its own writing system.",
        "Aksum was a small, insignificant kingdom.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kingdom of Aksum was a major trading power that controlled trade routes across the Red Sea, developed its own script (Ge'ez), and was one of the first African kingdoms to adopt Christianity as the state religion."
    })
  },
  {
    id: "G10-HC-AH-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "African History",
    subtopic: "Pre-Colonial Kingdoms,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Empire of Mali was one of the largest and wealthiest African empires. Which of the following is a notable achievement of the Empire of Mali?,
      options: [
        The Empire of Mali was known for its immense wealth from gold and salt trade, its development of trade routes, and the creation of intellectual centers such as Timbuktu, which became a center of Islamic learning.,
        Mali had no significant trade.,
        "Timbuktu was not an intellectual center.,
        Mali was not wealthy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Empire of Mali was known for its immense wealth from gold and salt trade, its development of trade routes, and the creation of intellectual centers such as Timbuktu, which became a center of Islamic learning.
    })
  },
  {
    id: G10-HC-AH-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Colonization",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Scramble for Africa led to the colonization of most of the continent by European powers. Which of the following was a key event that formalized the division of Africa among European powers?,
      options: [
        The Berlin Conference of 1884-85 formalized the partition of Africa among European powers, establishing rules for the claiming of African territories without regard for African interests or boundaries.,
        The Berlin Conference was about African development.,
        African leaders were consulted at the Berlin Conference.",
        "The Berlin Conference ended colonization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Berlin Conference of 1884-85 formalized the partition of Africa among European powers, establishing rules for the claiming of African territories without regard for African interests or boundaries."
    })
  },
  {
    id: "G10-HC-AH-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "African History",
    subtopic: "African Resistance,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "African communities resisted colonial rule in various ways. Which of the following is an example of armed resistance against colonial rule?,
      options: [
        The Maji Maji Rebellion in Tanganyika (1905-1907) was a significant armed resistance movement against German colonial rule, led by various ethnic groups who fought against forced labor and land alienation.,
        The Maji Maji Rebellion was peaceful.,
        "African communities did not resist colonial rule.,
        All resistance movements were unsuccessful."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maji Maji Rebellion in Tanganyika (1905-1907) was a significant armed resistance movement against German colonial rule, led by various ethnic groups who fought against forced labor and land alienation.
    })
  },
  {
    id: G10-HC-AH-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "African History,
    subtopic: "Independence Movements",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Ghana was the first African country south of the Sahara to gain independence. Which of the following statements about Ghana's independence is correct?,
      options: [
        Ghana gained independence from British colonial rule in 1957 under the leadership of Kwame Nkrumah, who became the first President. Ghana's independence inspired other African independence movements.,
        Ghana gained independence in 1960.,
        Ghana's independence was achieved peacefully.",
        "Ghana was the last country in Africa to gain independence.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ghana gained independence from British colonial rule in 1957 under the leadership of Kwame Nkrumah, who became the first President. Ghana's independence inspired other African independence movements."
    })
  },
  {
    id: "G10-HC-WH-01",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "Industrial Revolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Industrial Revolution was a major turning point in world history. Which of the following was a key effect of the Industrial Revolution on society?,
      options: [
        The Industrial Revolution led to urbanization, the growth of factories, the rise of the working class, significant changes in labor conditions, and advances in transportation and communication that reshaped economies and societies.,
        The Industrial Revolution had no social impact.,
        "The Industrial Revolution only affected agriculture.,
        The Industrial Revolution prevented urbanization."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Industrial Revolution led to urbanization, the growth of factories, the rise of the working class, significant changes in labor conditions, and advances in transportation and communication that reshaped economies and societies.
    })
  },
  {
    id: G10-HC-WH-02",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "World History,
    subtopic: "World War I",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " World War I (1914-1918) had significant global consequences. Which of the following was a cause of World War I?,
      options: [
        World War I was caused by a combination of factors including nationalism, militarism, alliances, imperialism, and the assassination of Archduke Franz Ferdinand, which triggered a series of events leading to war.,
        World War I was caused by a single event.,
        World War I was caused by economic depression.",
        "World War I was caused by religious conflict.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: World War I was caused by a combination of factors including nationalism, militarism, alliances, imperialism, and the assassination of Archduke Franz Ferdinand, which triggered a series of events leading to war."
    })
  },
  {
    id: "G10-HC-WH-03",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "World War II,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "World War II (1939-1945) was the most devastating conflict in human history. Which of the following was a significant consequence of World War II?,
      options: [
        World War II led to the establishment of the United Nations, the division of Europe into East and West, the beginning of the Cold War, and the acceleration of decolonization in Africa and Asia.,
        World War II had no global consequences.,
        "World War II prevented decolonization.,
        World War II only affected Europe."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "World War II led to the establishment of the United Nations, the division of Europe into East and West, the beginning of the Cold War, and the acceleration of decolonization in Africa and Asia.
    })
  },
  {
    id: G10-HC-WH-04",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "World History,
    subtopic: "The Cold War",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Cold War was a period of geopolitical tension between the United States and the Soviet Union. Which of the following was a characteristic of the Cold War?,
      options: [
        The Cold War was characterized by political tension, military competition, proxy wars, the nuclear arms race, and the ideological struggle between capitalism (USA) and communism (USSR), without direct military confrontation between the superpowers.,
        The Cold War was a direct military conflict.,
        The Cold War only affected the superpowers.",
        "The Cold War was a peaceful period.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Cold War was characterized by political tension, military competition, proxy wars, the nuclear arms race, and the ideological struggle between capitalism (USA) and communism (USSR), without direct military confrontation between the superpowers."
    })
  },
  {
    id: "G10-HC-WH-05",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "World History",
    subtopic: "Decolonization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Decolonization was the process by which colonies gained independence from colonial powers. Which of the following was a factor that contributed to decolonization in Africa?,
      options: [
        Decolonization was driven by nationalist movements, the weakening of European powers after World War II, the formation of the United Nations and its support for self-determination, and international pressure against colonialism.,
        Decolonization was solely caused by African wars.,
        "European powers willingly gave up their colonies.,
        Decolonization was not supported by the UN."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Decolonization was driven by nationalist movements, the weakening of European powers after World War II, the formation of the United Nations and its support for self-determination, and international pressure against colonialism.
    })
  },
  {
    id: G10-HC-LG-01",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Political Leadership",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya has had several political leaders since independence. Which of the following describes the leadership style and legacy of Jomo Kenyatta as Kenya's first President?,
      options: [
        Jomo Kenyatta led Kenya through the early years of independence, focusing on nation-building, economic development, and maintaining stability. His presidency is associated with the slogan 'Harambee' (pulling together) and the promotion of national unity.,
        Jomo Kenyatta was a military ruler.,
        Jomo Kenyatta opposed development.",
        "Jomo Kenyatta was a colonial leader.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Jomo Kenyatta led Kenya through the early years of independence, focusing on nation-building, economic development, and maintaining stability. His presidency is associated with the slogan 'Harambee' (pulling together) and the promotion of national unity."
    })
  },
  {
    id: "G10-HC-LG-02",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "Political Leadership,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "President Daniel Arap Moi led Kenya from 1978 to 2002. Which of the following was a significant feature of Moi's presidency?,
      options: [
        Moi's presidency was characterized by the introduction of the 'Nyayo' philosophy (peace, love, and unity), increased authoritarian rule, the shift to a single-party system in 1982, and later the reintroduction of multi-party politics in 1991 under pressure.,
        Moi introduced democracy immediately.,
        "Moi's presidency was peaceful throughout.,
        Moi's rule did not affect the political system."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Moi's presidency was characterized by the introduction of the 'Nyayo' philosophy (peace, love, and unity), increased authoritarian rule, the shift to a single-party system in 1982, and later the reintroduction of multi-party politics in 1991 under pressure.
    })
  },
  {
    id: G10-HC-LG-03",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Devolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Devolution is a key feature of the Constitution of Kenya 2010. Which of the following is a major objective of devolution in Kenya?,
      options: [
        Devolution aims to bring governance closer to the people, enhance public participation, improve service delivery, promote equitable development across regions, and reduce power concentration at the national level.,
        Devolution only creates more government jobs.,
        Devolution does not improve service delivery.",
        "Devolution is the same as decentralization.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Devolution aims to bring governance closer to the people, enhance public participation, improve service delivery, promote equitable development across regions, and reduce power concentration at the national level."
    })
  },
  {
    id: "G10-HC-LG-04",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "Devolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 established county governments. Which of the following is a function of county governments in Kenya?,
      options: [
        County governments are responsible for functions including agriculture, health services, trade development, county roads, pre-primary education, and environmental management, as outlined in the Constitution of Kenya 2010.,
        County governments are responsible for defense.,
        "County governments handle foreign affairs.,
        County governments are responsible for higher education."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "County governments are responsible for functions including agriculture, health services, trade development, county roads, pre-primary education, and environmental management, as outlined in the Constitution of Kenya 2010.
    })
  },
  {
    id: G10-HC-LG-05",
    grade: "Grade 10,
    subject: History and Citizenship",
    topic: "Leadership and Governance in Kenya,
    subtopic: "Elections",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Elections are conducted in Kenya at both national and county levels. Which of the following bodies is responsible for conducting elections in Kenya?,
      options: [
        The Independent Electoral and Boundaries Commission (IEBC) is the independent constitutional body responsible for conducting and supervising elections and referenda in Kenya.,
        The Judiciary conducts elections.,
        The Executive conducts elections.",
        "The Parliament conducts elections.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Independent Electoral and Boundaries Commission (IEBC) is the independent constitutional body responsible for conducting and supervising elections and referenda in Kenya."
    })
  },
  {
    id: "G10-HC-LG-06",
    grade: "Grade 10",
    subject: "History and Citizenship",
    topic: "Leadership and Governance in Kenya",
    subtopic: "National Values,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "National values are the principles that guide the conduct of individuals and institutions in Kenya. Which of the following is a national value enshrined in the Constitution of Kenya 2010?,
      options: [
        National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.,
        National values are not in the Constitution.,
        "National values are optional.,
        National values only apply to government officials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD HISTORY AND CITIZENSHIP SYLLABUS)
  // =========================================================================
  {
    id: G11-HC-KH-01",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Independence",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya achieved independence on December 12, 1963. Which of the following was a key challenge faced by Kenya immediately after independence?,
      options: [
        After independence, Kenya faced challenges including integrating diverse ethnic groups, addressing land grievances, building a unified national identity, developing the economy, and establishing effective governance institutions.,
        Kenya had no challenges after independence.,
        Only economic challenges existed.",
        "Kenya's independence was achieved peacefully.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: After independence, Kenya faced challenges including integrating diverse ethnic groups, addressing land grievances, building a unified national identity, developing the economy, and establishing effective governance institutions."
    })
  },
  {
    id: "G11-HC-KH-02",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History",
    subtopic: "Post-Independence Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya has experienced significant social and economic development since independence. Which of the following has been a major economic development strategy in Kenya?,
      options: [
        Kenya's economic development strategies have included agricultural modernization, industrialization (the 'Sessional Paper No. 10' of 1965), the promotion of tourism, and more recently, the Vision 2030 development blueprint for transforming the economy.,
        Kenya has no development strategy.,
        "Only agriculture has been emphasized.,
        Vision 2030 is not a development strategy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's economic development strategies have included agricultural modernization, industrialization (the 'Sessional Paper No. 10' of 1965), the promotion of tourism, and more recently, the Vision 2030 development blueprint for transforming the economy.
    })
  },
  {
    id: G11-HC-KH-03",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Constitutional Reforms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya has undergone significant constitutional reforms since independence. Which of the following was a major constitutional reform in Kenya's history?,
      options: [
        The Constitution of Kenya 2010 was a major reform that introduced devolution, a Bill of Rights, an independent judiciary, a reformed electoral system, and various checks and balances to limit executive power.,
        Kenya's Constitution was never reformed.,
        The 2010 Constitution was only about the executive.",
        "The Constitution did not introduce devolution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Constitution of Kenya 2010 was a major reform that introduced devolution, a Bill of Rights, an independent judiciary, a reformed electoral system, and various checks and balances to limit executive power."
    })
  },
  {
    id: "G11-HC-KH-04",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History",
    subtopic: "Kenya's Political Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's political development has been influenced by various factors. Which of the following statements about the political development of Kenya is correct?,
      options: [
        Kenya's political development has been characterized by a transition from a multi-party system in the 1960s, to a de facto one-party state in the 1980s, and back to multi-party politics in the 1990s, with the 2010 Constitution establishing devolution and a more robust system of checks and balances.,
        Kenya has always had a multi-party system.,
        "Kenya has never had devolution.,
        Kenya has never experienced political transitions."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's political development has been characterized by a transition from a multi-party system in the 1960s, to a de facto one-party state in the 1980s, and back to multi-party politics in the 1990s, with the 2010 Constitution establishing devolution and a more robust system of checks and balances.
    })
  },
  {
    id: G11-HC-KH-05",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenyan Independence and Post-Independence History,
    subtopic: "Economic Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Economic development has been a focus of successive Kenyan governments. Which of the following sectors has been a significant driver of Kenya's economic growth?,
      options: [
        Agriculture has been a key driver of Kenya's economy, employing a majority of the population and producing major exports such as tea, coffee, horticulture, and cut flowers.,
        Agriculture is not important for Kenya's economy.,
        Only tourism drives Kenya's economy.",
        "Kenya's economy is not dependent on agriculture.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Agriculture has been a key driver of Kenya's economy, employing a majority of the population and producing major exports such as tea, coffee, horticulture, and cut flowers."
    })
  },
  {
    id: "G11-HC-GD-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Democratic Principles,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Democracy is a form of government based on the will of the people. Which of the following is a fundamental principle of democracy?,
      options: [
        Democracy is founded on principles including popular sovereignty, political equality, majority rule with minority rights, free and fair elections, and the protection of human rights and fundamental freedoms.,
        Democracy is based on rule by a single leader.,
        "Democracy does not require elections.,
        Democracy does not protect rights."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Democracy is founded on principles including popular sovereignty, political equality, majority rule with minority rights, free and fair elections, and the protection of human rights and fundamental freedoms.
    })
  },
  {
    id: G11-HC-GD-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Governance and Democracy,
    subtopic: "Electoral Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Free and fair elections are essential for democratic governance. Which of the following is a key component of a free and fair electoral process?,
      options: [
        Free and fair elections require an independent electoral management body, transparent voter registration, equal media access for candidates, secret ballot voting, and credible mechanisms for resolving electoral disputes.,
        Elections are free and fair without any oversight.,
        Voter registration is optional.",
        "Media access does not affect election fairness.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Free and fair elections require an independent electoral management body, transparent voter registration, equal media access for candidates, secret ballot voting, and credible mechanisms for resolving electoral disputes."
    })
  },
  {
    id: "G11-HC-GD-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Constitutionalism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Constitutionalism is the principle that government authority is derived from and limited by a constitution. Which of the following is a key feature of constitutionalism?,
      options: [
        Constitutionalism is characterized by the rule of law, the limitation of government power, the protection of individual rights, the separation of powers, and the accountability of government to the people.,
        Constitutionalism gives unlimited power to the government.,
        "Constitutionalism does not protect individual rights.,
        Constitutionalism is optional for governments."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Constitutionalism is characterized by the rule of law, the limitation of government power, the protection of individual rights, the separation of powers, and the accountability of government to the people.
    })
  },
  {
    id: G11-HC-GD-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Governance and Democracy,
    subtopic: "Civil Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Civil society organizations play an important role in democratic governance. Which of the following is a function of civil society in a democratic society?,
      options: [
        Civil society organizations advocate for citizens' rights, hold governments accountable, provide civic education, and promote public participation in governance and decision-making.,
        Civil society has no role in democracy.,
        Civil society only advocates for the government.",
        "Civil society only provides services without advocating.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Civil society organizations advocate for citizens' rights, hold governments accountable, provide civic education, and promote public participation in governance and decision-making."
    })
  },
  {
    id: "G11-HC-GD-05",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Governance and Democracy",
    subtopic: "Media and Democracy,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "A free media is essential for democratic governance. Which of the following is the role of media in a democratic society?,
      options: [
        Media plays a crucial role in democracy by informing citizens, providing a platform for public debate, exposing government wrongdoing, holding leaders accountable, and serving as a watchdog for the public interest.,
        Media has no role in democracy.,
        "Media only entertains citizens.,
        Media is controlled by the government."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Media plays a crucial role in democracy by informing citizens, providing a platform for public debate, exposing government wrongdoing, holding leaders accountable, and serving as a watchdog for the public interest.
    })
  },
  {
    id: G11-HC-HR-01",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Types of Rights",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Human rights are fundamental rights inherent to all human beings. Which of the following is a civil right protected under the Constitution of Kenya 2010?,
      options: [
        Civil rights include the right to freedom of expression, the right to assembly and association, the right to a fair trial, and the right to political participation, among others protected by the Constitution.,
        Civil rights only include economic rights.,
        Civil rights are not protected in Kenya.",
        "Civil rights are only for government officials.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Civil rights include the right to freedom of expression, the right to assembly and association, the right to a fair trial, and the right to political participation, among others protected by the Constitution."
    })
  },
  {
    id: "G11-HC-HR-02",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Human Rights and Freedoms",
    subtopic: "Economic and Social Rights,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Economic and social rights ensure access to essential services. Which of the following is an economic and social right protected in Kenya?,
      options: [
        Economic and social rights include the right to education, health, housing, food, and water, as recognized in the Constitution of Kenya 2010.,
        Economic and social rights are not protected.,
        "The right to education is not a right.,
        The right to health is optional."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Economic and social rights include the right to education, health, housing, food, and water, as recognized in the Constitution of Kenya 2010.
    })
  },
  {
    id: G11-HC-HR-03",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Protection Mechanisms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Various institutions protect human rights in Kenya. Which of the following is a national institution responsible for promoting and protecting human rights?,
      options: [
        The Kenya National Commission on Human Rights (KNCHR) is the national institution established under the Constitution to promote and protect human rights, investigate complaints, and monitor compliance with human rights standards.,
        The Police service protects human rights.,
        The Judiciary only handles criminal cases.",
        "The Executive is responsible for human rights.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Kenya National Commission on Human Rights (KNCHR) is the national institution established under the Constitution to promote and protect human rights, investigate complaints, and monitor compliance with human rights standards."
    })
  },
  {
    id: "G11-HC-HR-04",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Human Rights and Freedoms",
    subtopic: "Right to Equality,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Equality and non-discrimination are fundamental human rights. Which of the following is prohibited under the principle of equality in Kenya?,
      options: [
        Discrimination on grounds of race, gender, religion, age, ethnicity, disability, or social status is prohibited under the Constitution of Kenya 2010, which guarantees equal treatment and protection for all citizens.,
        Discrimination is allowed in some cases.,
        "Only gender discrimination is prohibited.,
        The Constitution does not prohibit discrimination."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Discrimination on grounds of race, gender, religion, age, ethnicity, disability, or social status is prohibited under the Constitution of Kenya 2010, which guarantees equal treatment and protection for all citizens.
    })
  },
  {
    id: G11-HC-HR-05",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Human Rights and Freedoms,
    subtopic: "Access to Justice",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Access to justice is essential for the protection of human rights. Which of the following is a barrier to access to justice in Kenya?,
      options: [
        Barriers to access to justice in Kenya include the high cost of legal services, limited court infrastructure, geographical distance from courts, lack of legal awareness, and delays in the court system.,
        Access to justice is easy for all citizens.,
        There are no barriers to access to justice.",
        "Legal services are free for everyone.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Barriers to access to justice in Kenya include the high cost of legal services, limited court infrastructure, geographical distance from courts, lack of legal awareness, and delays in the court system."
    })
  },
  {
    id: "G11-HC-NI-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "National Integration and Cohesion",
    subtopic: "Ethnic Diversity,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya is a diverse country with many ethnic communities. Which of the following is a challenge of ethnic diversity in Kenya?,
      options: [
        Ethnic diversity can lead to challenges such as ethnic competition, negative ethnicity, political mobilization along ethnic lines, and conflicts that undermine national unity and development.,
        Ethnic diversity has no challenges.,
        "Ethnic diversity is only a political issue.,
        Negative ethnicity does not exist in Kenya."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethnic diversity can lead to challenges such as ethnic competition, negative ethnicity, political mobilization along ethnic lines, and conflicts that undermine national unity and development.
    })
  },
  {
    id: G11-HC-NI-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "National Integration and Cohesion,
    subtopic: "National Unity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " National unity is essential for a country's stability and development. Which of the following is a way to promote national unity in a diverse country like Kenya?,
      options: [
        National unity can be promoted through inclusive governance, celebration of cultural diversity, a national curriculum that promotes shared values, equitable distribution of resources, and institutions that represent all communities.,
        National unity can only be promoted through force.,
        National unity is not achievable.",
        "Promoting diversity is harmful to national unity.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: National unity can be promoted through inclusive governance, celebration of cultural diversity, a national curriculum that promotes shared values, equitable distribution of resources, and institutions that represent all communities."
    })
  },
  {
    id: "G11-HC-NI-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "National Integration and Cohesion",
    subtopic: "Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Conflicts are inevitable in diverse societies. Which of the following is an effective mechanism for conflict resolution in Kenya?,
      options: [
        Conflict resolution mechanisms in Kenya include the court system, alternative dispute resolution (ADR) such as mediation and arbitration, traditional conflict resolution methods, and institutions like the National Cohesion and Integration Commission (NCIC).,
        Only courts are used for conflict resolution.,
        "Traditional methods are not effective.,
        The NCIC is not a conflict resolution mechanism."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conflict resolution mechanisms in Kenya include the court system, alternative dispute resolution (ADR) such as mediation and arbitration, traditional conflict resolution methods, and institutions like the National Cohesion and Integration Commission (NCIC).
    })
  },
  {
    id: G11-HC-NI-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "National Integration and Cohesion,
    subtopic: "The National Anthem and Symbols",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " National symbols play a role in promoting national identity and cohesion. Which of the following is a national symbol of Kenya?,
      options: [
        National symbols of Kenya include the national flag, the national anthem, the coat of arms, the national currency (Kenyan shilling), and the national bird and flower (the lilac-breasted roller and the orchid).,
        The national symbols have no significance.,
        The national anthem is not a symbol.",
        "The coat of arms is not a national symbol.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: National symbols of Kenya include the national flag, the national anthem, the coat of arms, the national currency (Kenyan shilling), and the national bird and flower (the lilac-breasted roller and the orchid)."
    })
  },
  {
    id: "G11-HC-KF-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenya's Foreign Policy",
    subtopic: "International Relations,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's foreign policy has evolved since independence. Which of the following is a key principle of Kenya's foreign policy?,
      options: [
        Kenya's foreign policy is based on principles including the preservation of national sovereignty, peaceful coexistence with other states, non-interference in internal affairs, and the promotion of regional and international peace and security.,
        Kenya's foreign policy has no principles.,
        "Kenya promotes foreign intervention.,
        Kenya does not participate in international affairs."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya's foreign policy is based on principles including the preservation of national sovereignty, peaceful coexistence with other states, non-interference in internal affairs, and the promotion of regional and international peace and security.
    })
  },
  {
    id: G11-HC-KF-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenya's Foreign Policy,
    subtopic: "Diplomacy",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Diplomacy is the practice of managing international relations. Which of the following is a tool of diplomacy used by Kenya?,
      options: [
        Kenya uses various diplomatic tools including bilateral and multilateral negotiations, embassies and diplomatic missions, participation in international organizations, and economic and cultural diplomacy.,
        Diplomacy is only about negotiations.,
        Kenya only uses military tools.",
        "Diplomacy is not important for Kenya.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya uses various diplomatic tools including bilateral and multilateral negotiations, embassies and diplomatic missions, participation in international organizations, and economic and cultural diplomacy."
    })
  },
  {
    id: "G11-HC-KF-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Kenya's Foreign Policy",
    subtopic: "Regional Integration,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya is an active participant in regional integration initiatives. Which of the following is a regional organization that Kenya is a member of?,
      options: [
        Kenya is a member of the East African Community (EAC), the Intergovernmental Authority on Development (IGAD), and the African Union (AU), and actively participates in regional integration efforts.,
        Kenya is not a member of any regional organization.,
        "Kenya is only a member of the UN.,
        Kenya is not part of the EAC."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya is a member of the East African Community (EAC), the Intergovernmental Authority on Development (IGAD), and the African Union (AU), and actively participates in regional integration efforts.
    })
  },
  {
    id: G11-HC-KF-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Kenya's Foreign Policy,
    subtopic: "International Organizations",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Kenya participates in various international organizations. Which of the following is the purpose of the United Nations (UN)?,
      options: [
        The United Nations was established to maintain international peace and security, promote human rights, foster social and economic development, and provide a forum for international cooperation.,
        The UN only focuses on peace.,
        The UN does not promote development.",
        "The UN is only for superpowers.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The United Nations was established to maintain international peace and security, promote human rights, foster social and economic development, and provide a forum for international cooperation."
    })
  },
  {
    id: "G11-HC-GI-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Global Issues",
    subtopic: "Globalization,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Globalization refers to the increasing interconnectedness of the world. Which of the following is a positive effect of globalization on developing countries like Kenya?,
      options: [
        Globalization provides opportunities for developing countries through access to international markets, foreign investment, technology transfer, and the exchange of ideas and information.,
        Globalization only benefits developed countries.,
        "Globalization has no positive effects.,
        Globalization reduces access to markets."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Globalization provides opportunities for developing countries through access to international markets, foreign investment, technology transfer, and the exchange of ideas and information.
    })
  },
  {
    id: G11-HC-GI-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Global Issues,
    subtopic: "Climate Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Climate change is a global issue with significant impacts on countries like Kenya. Which of the following is a major effect of climate change in Kenya?,
      options: [
        Climate change has led to increased frequency of droughts, unpredictable rainfall patterns, reduced agricultural productivity, water scarcity, and negative effects on food security and livelihoods in Kenya.,
        Climate change has no effect on Kenya.,
        Climate change benefits agriculture.",
        "Kenya is not affected by climate change.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Climate change has led to increased frequency of droughts, unpredictable rainfall patterns, reduced agricultural productivity, water scarcity, and negative effects on food security and livelihoods in Kenya."
    })
  },
  {
    id: "G11-HC-GI-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Global Issues",
    subtopic: "Sustainable Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Sustainable development aims to meet present needs without compromising future generations. Which of the following is a key pillar of sustainable development?,
      options: [
        Sustainable development is based on three pillars: economic development, social development, and environmental protection, which must be balanced to achieve long-term sustainability.,
        Sustainable development only focuses on the environment.,
        "Sustainable development only focuses on economics.,
        Sustainable development is not achievable."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Sustainable development is based on three pillars: economic development, social development, and environmental protection, which must be balanced to achieve long-term sustainability.
    })
  },
  {
    id: G11-HC-GI-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Global Issues,
    subtopic: "International Cooperation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " International cooperation is essential for addressing global challenges. Which of the following is a global challenge that requires international cooperation?,
      options: [
        Global challenges such as climate change, terrorism, infectious diseases, food insecurity, and conflict require international cooperation and collective action to address effectively.,
        Global challenges can be solved by individual countries.,
        Climate change is not a global challenge.",
        "Terrorism is not a global challenge.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Global challenges such as climate change, terrorism, infectious diseases, food insecurity, and conflict require international cooperation and collective action to address effectively."
    })
  },
  {
    id: "G11-HC-CL-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Constitution and the Law",
    subtopic: "The Constitution of Kenya 2010,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The Constitution of Kenya 2010 is the supreme law of the land. Which of the following is a principle established by the Constitution?,
      options: [
        The Constitution of Kenya 2010 establishes principles including the sovereignty of the people, the rule of law, the separation of powers, devolution, and the protection of human rights and fundamental freedoms.,
        The Constitution does not establish new principles.,
        "The Constitution does not protect human rights.,
        The Constitution centralizes power."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Constitution of Kenya 2010 establishes principles including the sovereignty of the people, the rule of law, the separation of powers, devolution, and the protection of human rights and fundamental freedoms.
    })
  },
  {
    id: G11-HC-CL-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Constitution and the Law,
    subtopic: "Separation of Powers",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The separation of powers is a key feature of the Constitution of Kenya 2010. Which of the following describes the doctrine of separation of powers?,
      options: [
        The separation of powers divides government among three independent branches: the Legislature (Parliament), the Executive (the President and Cabinet), and the Judiciary (courts), each with distinct functions and checks on the others.,
        Separation of powers gives all power to the Executive.,
        Separation of powers is not part of the Constitution.",
        "The Legislature and Judiciary are the same branch.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The separation of powers divides government among three independent branches: the Legislature (Parliament), the Executive (the President and Cabinet), and the Judiciary (courts), each with distinct functions and checks on the others."
    })
  },
  {
    id: "G11-HC-CL-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Constitution and the Law",
    subtopic: "Rule of Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The rule of law is a fundamental principle of constitutional governance. Which of the following is an element of the rule of law?,
      options: [
        The rule of law requires that all persons and institutions are subject to and accountable under the law, that laws are clear and publicly known, that courts are independent and impartial, and that the government acts within the law.,
        The rule of law allows the government to act above the law.,
        "The rule of law is optional.,
        The rule of law does not require independent courts."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The rule of law requires that all persons and institutions are subject to and accountable under the law, that laws are clear and publicly known, that courts are independent and impartial, and that the government acts within the law.
    })
  },
  {
    id: G11-HC-CL-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Constitution and the Law,
    subtopic: "The Judicial System",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The judicial system in Kenya interprets and applies the law. Which of the following is the highest court in Kenya?,
      options: [
        The Supreme Court of Kenya is the highest court in the country, with jurisdiction over constitutional matters, presidential petitions, and final appellate decisions on matters of public importance.,
        The Court of Appeal is the highest court in Kenya.,
        The High Court is the highest court in Kenya.",
        "The Magistrate's Court is the highest court in Kenya.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The Supreme Court of Kenya is the highest court in the country, with jurisdiction over constitutional matters, presidential petitions, and final appellate decisions on matters of public importance."
    })
  },
  {
    id: "G11-HC-PV-01",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Patriotism and National Values",
    subtopic: "National Values,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "National values are the moral principles that guide the conduct of citizens and institutions. Which of the following is a national value enshrined in the Constitution of Kenya 2010?,
      options: [
        National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.,
        National values are not in the Constitution.,
        "National values are optional.,
        National values only apply to government officials."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "National values include patriotism, national unity, social justice, integrity, transparency, accountability, democracy, the rule of law, and respect for human rights, as outlined in the Constitution of Kenya 2010.
    })
  },
  {
    id: G11-HC-PV-02",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Patriotism and National Values,
    subtopic: "Patriotism",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Patriotism is love and devotion to one's country. Which of the following is a way citizens can demonstrate patriotism?,
      options: [
        Citizens demonstrate patriotism by participating in the democratic process (voting), respecting national symbols, paying taxes, contributing to national development, and working to promote peace and unity.,
        Patriotism is only about celebrating national holidays.,
        Patriotism does not require civic participation.",
        "Paying taxes is not a demonstration of patriotism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Citizens demonstrate patriotism by participating in the democratic process (voting), respecting national symbols, paying taxes, contributing to national development, and working to promote peace and unity."
    })
  },
  {
    id: "G11-HC-PV-03",
    grade: "Grade 11",
    subject: "History and Citizenship",
    topic: "Patriotism and National Values",
    subtopic: "Civic Responsibility,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Civic responsibility involves the duties of citizens to their country. Which of the following is a civic responsibility of every Kenyan citizen?,
      options: [
        Civic responsibilities include paying taxes, obeying the law, participating in the electoral process, protecting the environment, and contributing to the development of the community and the country.,
        Civic responsibilities are optional.,
        "Civic responsibilities only apply to government employees.,
        Civic responsibilities are not important."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Civic responsibilities include paying taxes, obeying the law, participating in the electoral process, protecting the environment, and contributing to the development of the community and the country.
    })
  },
  {
    id: G11-HC-PV-04",
    grade: "Grade 11,
    subject: History and Citizenship",
    topic: "Patriotism and National Values,
    subtopic: "National Cohesion",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " National cohesion is the unity and solidarity of citizens across different communities. Which of the following is an institution that promotes national cohesion in Kenya?,
      options: [
        The National Cohesion and Integration Commission (NCIC) was established to promote national cohesion and integration, address negative ethnicity, and foster peaceful coexistence among the diverse communities in Kenya.,
        The NCIC only handles legal matters.,
        The NCIC is not a government institution.",
        "The NCIC promotes division.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The National Cohesion and Integration Commission (NCIC) was established to promote national cohesion and integration, address negative ethnicity, and foster peaceful coexistence among the diverse communities in Kenya."
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD HISTORY AND CITIZENSHIP SYLLABUS)
  // =========================================================================

  // --- CONTEMPORARY GLOBAL ISSUES (5 Materials) ---
  {
    id: "G12-HC-CG-01",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Contemporary Global Issues",
    subtopic: "Terrorism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Terrorism is a major global security challenge that affects countries worldwide. Which of the following is a significant driver of terrorism in the modern world?,
      options: [
        Political grievances, ideological extremism, socio-economic inequality, and political instability are significant drivers of terrorism that create conditions conducive to the recruitment of individuals into terrorist groups.,
        Terrorism is solely driven by religious extremism.,
        "Terrorism is only a problem in developing countries.,
        Terrorism is not influenced by socio-economic factors."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Political grievances, ideological extremism, socio-economic inequality, and political instability are significant drivers of terrorism that create conditions conducive to the recruitment of individuals into terrorist groups.
    })
  },
  {
    id: G12-HC-CG-02",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Contemporary Global Issues,
    subtopic: "Refugees and Displacement",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Refugee crises have become a significant global humanitarian challenge. Which of the following is the primary cause of forced displacement and refugee flows in Africa?,
      options: [
        Conflict and armed violence, political instability, persecution, and the effects of climate change are primary causes of forced displacement and refugee flows in Africa.,
        Economic migration is the primary cause of refugee flows.,
        Refugee flows are only caused by natural disasters.",
        "Political instability is not a cause of refugee flows.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Conflict and armed violence, political instability, persecution, and the effects of climate change are primary causes of forced displacement and refugee flows in Africa."
    })
  },
  {
    id: "G12-HC-CG-03",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Contemporary Global Issues",
    subtopic: "Human Trafficking,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Human trafficking is a serious violation of human rights and a global crime. Which of the following is a factor that makes individuals vulnerable to human trafficking?,
      options: [
        Poverty, lack of education, unemployment, political instability, and social marginalization increase individuals' vulnerability to exploitation and trafficking.,
        Human trafficking only targets women and children.,
        "Human trafficking is not influenced by socio-economic factors.,
        Education does not protect against trafficking."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Poverty, lack of education, unemployment, political instability, and social marginalization increase individuals' vulnerability to exploitation and trafficking.
    })
  },
  {
    id: G12-HC-CG-04",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Contemporary Global Issues,
    subtopic: "Global Governance",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Global governance refers to the collective management of global problems through international institutions and cooperation. Which of the following is a key institution of global governance?,
      options: [
        The United Nations (UN) is a key institution of global governance that provides a platform for international dialogue, peacekeeping, humanitarian assistance, and the development of international norms and standards.,
        The World Bank is a key institution of global governance.,
        The International Monetary Fund (IMF) is a key institution of global governance.",
        "All of the above are correct.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The United Nations (UN) is a key institution of global governance that provides a platform for international dialogue, peacekeeping, humanitarian assistance, and the development of international norms and standards."
    })
  },
  {
    id: "G12-HC-CG-05",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Contemporary Global Issues",
    subtopic: "Global Health Challenges,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Global health challenges require international cooperation for effective response. Which of the following is a major global health challenge that requires coordinated international action?,
      options: [
        Infectious diseases such as HIV/AIDS, tuberculosis, malaria, and emerging diseases such as COVID-19, as well as antimicrobial resistance, are major global health challenges that require coordinated international action.,
        Global health challenges are limited to developing countries.,
        "Infectious diseases are not global health challenges.,
        Antimicrobial resistance is not a global health concern."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Infectious diseases such as HIV/AIDS, tuberculosis, malaria, and emerging diseases such as COVID-19, as well as antimicrobial resistance, are major global health challenges that require coordinated international action.
    })
  },

  // --- KENYA'S DEVELOPMENT TRAJECTORY (5 Materials) ---
  {
    id: G12-HC-KD-01",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Kenya's Development Trajectory,
    subtopic: "Economic Development Since 1963",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya's economic development has gone through various phases since independence. Which of the following has been a key feature of Kenya's economic development strategy since 1963?,
      options: [
        Kenya's economic development strategy has included agricultural modernization, import substitution industrialization, tourism promotion, and more recently, the adoption of Vision 2030 as a long-term development blueprint for economic transformation and poverty reduction.,
        Kenya's economic development strategy has been static and unchanged.,
        Agriculture has not been a focus of economic development.",
        "Vision 2030 is not a development strategy.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya's economic development strategy has included agricultural modernization, import substitution industrialization, tourism promotion, and more recently, the adoption of Vision 2030 as a long-term development blueprint for economic transformation and poverty reduction."
    })
  },
  {
    id: "G12-HC-KD-02",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Kenya's Development Trajectory",
    subtopic: "Political Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's political development has been marked by significant milestones. Which of the following was a major milestone in Kenya's political development?,
      options: [
        The adoption of the Constitution of Kenya 2010 was a major milestone that established a comprehensive Bill of Rights, devolution, and a reformed governance structure, marking a new era in Kenya's democratic development.,
        The Constitution of 1963 was a major milestone in political development.,
        "The Constitution of 2010 only addressed executive power.,
        The 2010 Constitution did not include a Bill of Rights."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The adoption of the Constitution of Kenya 2010 was a major milestone that established a comprehensive Bill of Rights, devolution, and a reformed governance structure, marking a new era in Kenya's democratic development.
    })
  },
  {
    id: G12-HC-KD-03",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Kenya's Development Trajectory,
    subtopic: "Social Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya has made progress in social development since independence. Which of the following is an achievement in Kenya's social development?,
      options: [
        Kenya has made significant progress in improving access to education, with increased primary and secondary school enrollment, and the expansion of health services, including the introduction of free primary education and maternal health programs.,
        Kenya's social development has been stagnant.,
        Free primary education was not achieved in Kenya.",
        "Health services have not been expanded.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya has made significant progress in improving access to education, with increased primary and secondary school enrollment, and the expansion of health services, including the introduction of free primary education and maternal health programs."
    })
  },
  {
    id: "G12-HC-KD-04",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Kenya's Development Trajectory",
    subtopic: "Infrastructure Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Infrastructure development has been a focus of Kenya's development agenda. Which of the following is a major infrastructure project that has contributed to Kenya's development?,
      options: [
        The Standard Gauge Railway (SGR) is a major infrastructure project that has improved transportation connectivity, reduced travel time, and stimulated economic growth in Kenya, connecting Nairobi to the port of Mombasa.,
        Infrastructure development has not been a priority in Kenya.,
        "The SGR has not contributed to economic growth.,
        Roads are not important for development."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Standard Gauge Railway (SGR) is a major infrastructure project that has improved transportation connectivity, reduced travel time, and stimulated economic growth in Kenya, connecting Nairobi to the port of Mombasa.
    })
  },
  {
    id: G12-HC-KD-05",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Kenya's Development Trajectory,
    subtopic: "Challenges to Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Kenya faces various challenges that hinder its development. Which of the following is a major challenge to Kenya's development?,
      options: [
        Kenya faces challenges including high levels of poverty and inequality, corruption and governance issues, unemployment especially among the youth, environmental degradation, and vulnerability to climate change and shocks.,
        Kenya has no development challenges.,
        Corruption is not a development challenge.",
        "Youth unemployment is not a development challenge.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Kenya faces challenges including high levels of poverty and inequality, corruption and governance issues, unemployment especially among the youth, environmental degradation, and vulnerability to climate change and shocks."
    })
  },

  // --- PEACE AND CONFLICT RESOLUTION (5 Materials) ---
  {
    id: "G12-HC-PC-01",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Peace and Conflict Resolution",
    subtopic: "Causes of Conflict,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Conflicts can arise from various causes in society. Which of the following is a common cause of conflict in Kenyan communities?,
      options: [
        Causes of conflict in Kenyan communities include competition for resources (land, water, and pasture), ethnic tensions, political competition, socio-economic inequalities, and historical grievances.,
        Land disputes are the only cause of conflict.,
        "Ethnic tensions do not cause conflict.,
        Socio-economic inequalities do not lead to conflict."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Causes of conflict in Kenyan communities include competition for resources (land, water, and pasture), ethnic tensions, political competition, socio-economic inequalities, and historical grievances.
    })
  },
  {
    id: G12-HC-PC-02",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Peace and Conflict Resolution,
    subtopic: "Peacebuilding",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Peacebuilding involves measures to prevent, manage, and resolve conflicts. Which of the following is an element of peacebuilding in post-conflict situations?,
      options: [
        Peacebuilding includes promoting dialogue and reconciliation, addressing root causes of conflict, rebuilding institutions, supporting victims, and fostering social cohesion and trust among communities.,
        Peacebuilding only involves military intervention.,
        Peacebuilding does not address root causes.",
        "Peacebuilding is limited to conflict resolution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Peacebuilding includes promoting dialogue and reconciliation, addressing root causes of conflict, rebuilding institutions, supporting victims, and fostering social cohesion and trust among communities."
    })
  },
  {
    id: "G12-HC-PC-03",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Peace and Conflict Resolution",
    subtopic: "Reconciliation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Reconciliation is a crucial process in post-conflict situations. Which of the following is a key component of reconciliation in Kenya after the 2007/2008 post-election violence?,
      options: [
        The Truth, Justice and Reconciliation Commission (TJRC) was established in Kenya to investigate historical injustices, promote accountability, and foster reconciliation and healing among communities affected by political violence.,
        Reconciliation was not pursued after the 2007/2008 violence.,
        "The TJRC only addressed economic issues.,
        Reconciliation does not involve healing."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Truth, Justice and Reconciliation Commission (TJRC) was established in Kenya to investigate historical injustices, promote accountability, and foster reconciliation and healing among communities affected by political violence.
    })
  },
  {
    id: G12-HC-PC-04",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Peace and Conflict Resolution,
    subtopic: "Conflict Resolution Mechanisms",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Various mechanisms are used to resolve conflicts in Kenya. Which of the following is a traditional conflict resolution mechanism used by many Kenyan communities?,
      options: [
        Traditional conflict resolution mechanisms such as mediation by elders, community dialogue, and customary justice systems are used by many Kenyan communities to resolve disputes and maintain social harmony.,
        Traditional mechanisms are no longer used in Kenya.,
        Court systems are traditional mechanisms.",
        "Police intervention is a traditional mechanism.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Traditional conflict resolution mechanisms such as mediation by elders, community dialogue, and customary justice systems are used by many Kenyan communities to resolve disputes and maintain social harmony."
    })
  },
  {
    id: "G12-HC-PC-05",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Peace and Conflict Resolution",
    subtopic: "International Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "International organizations play a role in resolving conflicts. Which of the following is a role of the United Nations in conflict resolution?,
      options: [
        The United Nations plays a role in conflict resolution through peacekeeping operations, mediation and negotiation efforts, peacebuilding initiatives, and the imposition of sanctions to maintain international peace and security.,
        The UN only focuses on development.,
        "The UN does not engage in peacekeeping.,
        The UN is not involved in conflict resolution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The United Nations plays a role in conflict resolution through peacekeeping operations, mediation and negotiation efforts, peacebuilding initiatives, and the imposition of sanctions to maintain international peace and security.
    })
  },

  // --- GOOD GOVERNANCE AND ANTI-CORRUPTION (5 Materials) ---
  {
    id: G12-HC-GG-01",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Good Governance and Anti-Corruption,
    subtopic: "Corruption",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Corruption is a major governance challenge in Kenya. Which of the following is a form of corruption that undermines governance and development?,
      options: [
        Grand corruption involving high-level officials, embezzlement of public funds, bribery, nepotism, and procurement fraud are forms of corruption that undermine governance, development, and public trust.,
        Petty corruption is not a form of corruption.,
        Bribery is not a form of corruption.",
        "Nepotism is not a form of corruption.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Grand corruption involving high-level officials, embezzlement of public funds, bribery, nepotism, and procurement fraud are forms of corruption that undermine governance, development, and public trust."
    })
  },
  {
    id: "G12-HC-GG-02",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Good Governance and Anti-Corruption",
    subtopic: "Anti-Corruption Institutions,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya has established various institutions to fight corruption. Which of the following is the primary anti-corruption institution in Kenya?,
      options: [
        The Ethics and Anti-Corruption Commission (EACC) is the primary anti-corruption institution in Kenya, responsible for investigation and prosecution of corruption cases, and promoting integrity and ethical conduct.,
        The Judiciary is the primary anti-corruption institution.,
        "The Police service is the primary anti-corruption institution.,
        The Directorate of Criminal Investigations (DCI) is the primary anti-corruption institution."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Ethics and Anti-Corruption Commission (EACC) is the primary anti-corruption institution in Kenya, responsible for investigation and prosecution of corruption cases, and promoting integrity and ethical conduct.
    })
  },
  {
    id: G12-HC-GG-03",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Good Governance and Anti-Corruption,
    subtopic: "Ethics and Integrity",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Ethics and integrity are fundamental to good governance. Which of the following is an example of ethical behavior in public service?,
      options: [
        Ethical behavior in public service includes transparency in decision-making, accountability for actions, acting in the public interest, avoiding conflicts of interest, and upholding the highest standards of integrity.,
        Ethical behavior only applies to politicians.,
        Ethical behavior is optional in public service.",
        "Transparency is not a part of ethical behavior.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Ethical behavior in public service includes transparency in decision-making, accountability for actions, acting in the public interest, avoiding conflicts of interest, and upholding the highest standards of integrity."
    })
  },
  {
    id: "G12-HC-GG-04",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Good Governance and Anti-Corruption",
    subtopic: "Governance Reforms,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Governance reforms have been undertaken to improve accountability and transparency in Kenya. Which of the following is a governance reform introduced by the Constitution of Kenya 2010?,
      options: [
        The Constitution of Kenya 2010 introduced governance reforms including devolution, an independent judiciary, a reformed electoral system, and the establishment of independent commissions such as the EACC and the Public Service Commission.,
        The 2010 Constitution did not introduce any reforms.,
        "Devolution was not introduced by the 2010 Constitution.,
        Independent commissions were not established."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The Constitution of Kenya 2010 introduced governance reforms including devolution, an independent judiciary, a reformed electoral system, and the establishment of independent commissions such as the EACC and the Public Service Commission.
    })
  },
  {
    id: G12-HC-GG-05",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Good Governance and Anti-Corruption,
    subtopic: "Public Participation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Public participation is a key element of good governance. Which of the following is a mechanism for public participation in governance in Kenya?,
      options: [
        Mechanisms for public participation include public hearings, citizen forums, budget-making processes, public petitions, and participation in the electoral process and in community development projects.,
        Public participation is not important in governance.,
        Elections are not a form of public participation.",
        "Citizens cannot participate in governance.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Mechanisms for public participation include public hearings, citizen forums, budget-making processes, public petitions, and participation in the electoral process and in community development projects."
    })
  },

  // --- REGIONAL INTEGRATION (5 Materials) ---
  {
    id: "G12-HC-RI-01",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Regional Integration",
    subtopic: "East African Community,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "The East African Community (EAC) is a regional integration organization in East Africa. Which of the following is a benefit of the EAC for Kenya?,
      options: [
        The EAC provides benefits including expanded market access for Kenyan goods and services, increased trade and investment, and cooperation in areas such as infrastructure development, health, and education.,
        The EAC has no benefits for Kenya.,
        "The EAC restricts trade for Kenya.,
        The EAC only benefits Kenya."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "The EAC provides benefits including expanded market access for Kenyan goods and services, increased trade and investment, and cooperation in areas such as infrastructure development, health, and education.
    })
  },
  {
    id: G12-HC-RI-02",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Regional Integration,
    subtopic: "African Union",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The African Union (AU) is the principal continental organization in Africa. Which of the following is a key objective of the African Union?,
      options: [
        The African Union aims to promote peace, security, and stability, accelerate political and socio-economic integration, promote human rights, and achieve sustainable development and poverty eradication across Africa.,
        The AU only focuses on economic integration.,
        The AU does not promote human rights.",
        "The AU is only concerned with conflict resolution.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: The African Union aims to promote peace, security, and stability, accelerate political and socio-economic integration, promote human rights, and achieve sustainable development and poverty eradication across Africa."
    })
  },
  {
    id: "G12-HC-RI-03",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Regional Integration",
    subtopic: "Pan-Africanism,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Pan-Africanism is a movement that promotes solidarity and unity among African peoples. Which of the following was a key objective of the Pan-African movement in the 20th century?,
      options: [
        Pan-Africanism sought to promote African unity and solidarity, achieve independence for African countries from colonial rule, and advance the rights and dignity of people of African descent worldwide.,
        Pan-Africanism was only a cultural movement.,
        "Pan-Africanism was not concerned with independence.,
        Pan-Africanism was only active in the 1960s."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Pan-Africanism sought to promote African unity and solidarity, achieve independence for African countries from colonial rule, and advance the rights and dignity of people of African descent worldwide.
    })
  },
  {
    id: G12-HC-RI-04",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Regional Integration,
    subtopic: "IGAD",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The Intergovernmental Authority on Development (IGAD) is a regional organization in the Horn of Africa. Which of the following is a focus area of IGAD?,
      options: [
        IGAD focuses on promoting peace and security, drought management and environmental issues, and economic cooperation among member states in the Horn of Africa region.,
        IGAD is a trade organization only.,
        IGAD does not focus on peace and security.",
        "IGAD is not active in the Horn of Africa.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: IGAD focuses on promoting peace and security, drought management and environmental issues, and economic cooperation among member states in the Horn of Africa region."
    })
  },
  {
    id: "G12-HC-RI-05",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Regional Integration",
    subtopic: "Challenges to Integration,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Regional integration in Africa faces various challenges. Which of the following is a challenge to regional integration in East Africa?,
      options: [
        Challenges to regional integration include differences in economic development levels, political instability in some member states, weak infrastructure, overlapping membership in regional blocs, and conflicting national interests.,
        Regional integration faces no challenges.,
        "Political instability promotes regional integration.,
        Economic differences are not a challenge to integration."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Challenges to regional integration include differences in economic development levels, political instability in some member states, weak infrastructure, overlapping membership in regional blocs, and conflicting national interests.
    })
  },

  // --- ENVIRONMENTAL GOVERNANCE (4 Materials) ---
  {
    id: G12-HC-EG-01",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Environmental Governance,
    subtopic: "Environmental Policies",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Environmental governance involves the management of natural resources and protection of the environment. Which of the following is an environmental policy instrument in Kenya?,
      options: [
        Environmental laws and regulations, such as the Environmental Management and Coordination Act (EMCA), establish a legal framework for environmental protection, pollution control, and sustainable resource management in Kenya.,
        Environmental policies are not enforced in Kenya.,
        The EMCA only addresses wildlife conservation.",
        "Kenya does not have environmental laws.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Environmental laws and regulations, such as the Environmental Management and Coordination Act (EMCA), establish a legal framework for environmental protection, pollution control, and sustainable resource management in Kenya."
    })
  },
  {
    id: "G12-HC-EG-02",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Environmental Governance",
    subtopic: "Conservation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Conservation of natural resources is important for sustainable development. Which of the following is a conservation strategy in Kenya?,
      options: [
        Conservation strategies in Kenya include the establishment of national parks and reserves, community-based conservation initiatives, wildlife protection laws, and reforestation and afforestation programs.,
        Conservation strategies only apply to wildlife.,
        "Reforestation is not a conservation strategy.,
        Kenya does not have national parks."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Conservation strategies in Kenya include the establishment of national parks and reserves, community-based conservation initiatives, wildlife protection laws, and reforestation and afforestation programs.
    })
  },
  {
    id: G12-HC-EG-03",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Environmental Governance,
    subtopic: "Sustainable Resource Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Sustainable resource management ensures the long-term availability of natural resources. Which of the following is a principle of sustainable resource management?,
      options: [
        Sustainable resource management is based on principles including intergenerational equity, the precautionary principle, maintaining ecological balance, and integrating environmental considerations into decision-making.,
        Sustainable resource management means using all available resources.,
        Ecological balance is not a principle of sustainable resource management.",
        "Resource management does not require planning.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Sustainable resource management is based on principles including intergenerational equity, the precautionary principle, maintaining ecological balance, and integrating environmental considerations into decision-making."
    })
  },
  {
    id: "G12-HC-EG-04",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Environmental Governance",
    subtopic: "Climate Change Adaptation,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Climate change adaptation is essential for building resilience. Which of the following is a climate change adaptation strategy in Kenya?,
      options: [
        Climate change adaptation strategies in Kenya include drought-resistant crop varieties, water harvesting and conservation, early warning systems, and the diversification of livelihoods to reduce vulnerability to climate-related shocks.,
        Climate change adaptation is not needed in Kenya.,
        "Drought-resistant crops are not an adaptation strategy.,
        Water conservation is not a climate change strategy."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Climate change adaptation strategies in Kenya include drought-resistant crop varieties, water harvesting and conservation, early warning systems, and the diversification of livelihoods to reduce vulnerability to climate-related shocks.
    })
  },

  // --- CITIZENSHIP AND CIVIC ENGAGEMENT (3 Materials) ---
  {
    id: G12-HC-CC-01",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Citizenship and Civic Engagement,
    subtopic: "Active Citizenship",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Active citizenship involves the participation of individuals in the life of their community and country. Which of the following is a way citizens can engage actively in their communities?,
      options: [
        Active citizenship can be demonstrated through community service, volunteering, participation in community development projects, membership in community organizations, and engagement in democratic processes.,
        Active citizenship is limited to voting.,
        Community participation is not a form of active citizenship.",
        "Active citizenship is only for adults.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Active citizenship can be demonstrated through community service, volunteering, participation in community development projects, membership in community organizations, and engagement in democratic processes."
    })
  },
  {
    id: "G12-HC-CC-02",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "Citizenship and Civic Engagement",
    subtopic: "Civil Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Civil society organizations play a crucial role in democratic governance. Which of the following is a function of civil society organizations in Kenya?,
      options: [
        Civil society organizations advocate for policy change, provide services to communities, conduct civic education, monitor government performance, and promote human rights and democratic governance.,
        Civil society only provides services.,
        "Civil society does not advocate for policy change.,
        Civil society is not involved in civic education."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Civil society organizations advocate for policy change, provide services to communities, conduct civic education, monitor government performance, and promote human rights and democratic governance.
    })
  },
  {
    id: G12-HC-CC-03",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "Citizenship and Civic Engagement,
    subtopic: "Youth Participation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Youth participation is important for building a vibrant democracy. Which of the following is a platform for youth participation in governance in Kenya?,
      options: [
        Platforms for youth participation include youth councils, student organizations, the National Youth Service, and participation in political processes such as voting and youth representation in government structures.,
        Youth have no role in governance.,
        Youth councils are not a participation platform.",
        "Voting is not a form of youth participation.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Platforms for youth participation include youth councils, student organizations, the National Youth Service, and participation in political processes such as voting and youth representation in government structures."
    })
  },

  // --- THE FUTURE OF KENYA (3 Materials) ---
  {
    id: "G12-HC-FK-01",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "The Future of Kenya",
    subtopic: "Vision 2030,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya Vision 2030 is the country's long-term development blueprint. Which of the following is a pillar of Kenya Vision 2030?,
      options: [
        Kenya Vision 2030 is built on three pillars: the economic pillar (achieving sustained economic growth), the social pillar (improving quality of life), and the political pillar (good governance, democracy, and rule of law).,
        Vision 2030 only has an economic pillar.,
        "Vision 2030 does not address governance.,
        The political pillar is not part of Vision 2030."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya Vision 2030 is built on three pillars: the economic pillar (achieving sustained economic growth), the social pillar (improving quality of life), and the political pillar (good governance, democracy, and rule of law).
    })
  },
  {
    id: G12-HC-FK-02",
    grade: "Grade 12,
    subject: History and Citizenship",
    topic: "The Future of Kenya,
    subtopic: "Youth and National Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " Youth are crucial for Kenya's future development. Which of the following is a way that youth can contribute to national development?,
      options: [
        Youth contribute to national development through entrepreneurship and innovation, employment and productivity, civic engagement and community service, and the leadership they provide in shaping the future of the country.,
        Youth have no role in national development.,
        Entrepreneurship is not a contribution to development.",
        "Innovation does not contribute to national growth.
      ].sort(() => Math.random() - 0.5),
      correctAnswer: Youth contribute to national development through entrepreneurship and innovation, employment and productivity, civic engagement and community service, and the leadership they provide in shaping the future of the country."
    })
  },
  {
    id: "G12-HC-FK-03",
    grade: "Grade 12",
    subject: "History and Citizenship",
    topic: "The Future of Kenya",
    subtopic: "National Development Goals,
    maxUses: 5,
    usageCount: 0,
    minWords: 28,",
    generate: () => ({
      text: "Kenya's national development goals aim to transform the country. Which of the following is a priority area for Kenya's future development?,
      options: [
        Priority areas for Kenya's future development include poverty eradication, education and skills development, health and well-being, infrastructure development, environmental sustainability, and governance reforms.,
        Poverty is not a priority area for development.,
        "Education is not a priority for development.,
        Environmental sustainability is not a development priority."
      ].sort(() => Math.random() - 0.5),
      correctAnswer: "Priority areas for Kenya's future development include poverty eradication, education and skills development, health and well-being, infrastructure development, environmental sustainability, and governance reforms."
    })
  }

];


