// src/generators/creativeArtsAndSportsTemplates.ts
import { TemplateRule } from '../types/templateTypes';

export const creativeArtsAndSportsTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD CREATIVE ARTS AND SPORTS SYLLABUS)
  // =========================================================================

  // --- STRAND 1: FOUNDATIONS OF CREATIVE ARTS AND SPORTS ---

  // --- 1.1 INTRODUCTION TO CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: "G7-CAS-INT-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Introduction to Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Creative Arts and Sports is a multidisciplinary learning area. Which of the following is a category of Creative Arts and Sports?,
      options: ["Visual Arts", Mathematics", "Science, Languages"].sort(() => Math.random() - 0.5),
      correctAnswer: "Visual Arts
    })
  },
  {
    id: G7-CAS-INT-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Introduction to Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The Creative Arts and Sports curriculum is anchored in Howard Gardner's Multiple Intelligence theory. What does this theory recognize about learners?,
      options: ["That learners have diverse intelligences and learn in different ways.", That all learners learn the same way., That intelligence is fixed at birth.", "That only some learners are intelligent.].sort(() => Math.random() - 0.5),
      correctAnswer: That learners have diverse intelligences and learn in different ways."
    })
  },
  {
    id: "G7-CAS-INT-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Introduction to Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "John Dewey's Social Constructivism Theory informs the Creative Arts and Sports curriculum. What does Social Constructivism emphasize?,
      options: ["An immersive and participatory approach to learning.", Passive listening and note-taking.", "Learning in isolation., Memorizing facts and figures."].sort(() => Math.random() - 0.5),
      correctAnswer: "An immersive and participatory approach to learning.
    })
  },
  {
    id: G7-CAS-INT-04",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Introduction to Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The Creative Arts and Sports curriculum is organized into three strands. Which of the following is a strand in the Creative Arts and Sports curriculum?,
      options: ["Foundations of Creative Arts and Sports", Business of Creative Arts and Sports, History of Creative Arts and Sports", "Technology of Creative Arts and Sports].sort(() => Math.random() - 0.5),
      correctAnswer: Foundations of Creative Arts and Sports"
    })
  },

  // --- 1.2 COMPONENTS OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: "G7-CAS-COM-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "A story has several elements that make it complete and engaging. What are the four main elements of a story?,
      options: ["Character", Setting, Plot, and Theme, Introduction, Body, Conclusion, Moral", "Title, Author, Publisher, Year, Conflict, Climax, Resolution, Ending"].sort(() => Math.random() - 0.5),
      correctAnswer: "Character, Setting, Plot, and Theme
    })
  },
  {
    id: G7-CAS-COM-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Physical fitness is an important component of Creative Arts and Sports. Which of the following are components of physical fitness that involve performance?,
      options: ["Endurance and agility", Strength and flexibility, Speed and power", "Balance and coordination].sort(() => Math.random() - 0.5),
      correctAnswer: Endurance and agility"
    })
  },
  {
    id: "G7-CAS-COM-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Music notation is a system used to write down music. What is the name of the symbol placed at the beginning of a stave to indicate the pitch of the notes?,
      options: ["A clef", A note", "A rest, A bar"].sort(() => Math.random() - 0.5),
      correctAnswer: "A clef
    })
  },
  {
    id: G7-CAS-COM-04",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Dance is a form of creative expression with several elements. What are the five elements of dance according to Laban's movement analysis?,
      options: ["Body", Action, Space, Time, and Energy, Steps, Music, Costume, Lighting, and Stage, Jump, Turn, Spin, Leap, and Stomp", "Fast, Slow, High, Low, and Medium].sort(() => Math.random() - 0.5),
      correctAnswer: "Body", Action, Space, Time, and Energy"
    })
  },

  // --- STRAND 2: CREATING AND PERFORMING ---

  // --- 2.1 PICTURE MAKING (3 Materials) ---
  {
    id: "G7-CAS-PIC-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Picture Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Balance in a drawing refers to the visual weight of different elements. What type of balance is achieved when both sides of a drawing are the same?,
      options: ["Symmetrical balance", Asymmetrical balance", "Radial balance, Formal balance"].sort(() => Math.random() - 0.5),
      correctAnswer: "Symmetrical balance
    })
  },
  {
    id: G7-CAS-PIC-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Picture Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Picture making involves different techniques and media. What is the technique of creating an image by applying paint to a wet surface to achieve soft edges called?,
      options: ["Wet-on-wet technique", Dry brush technique, Splattering", "Stippling].sort(() => Math.random() - 0.5),
      correctAnswer: Wet-on-wet technique"
    })
  },
  {
    id: "G7-CAS-PIC-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Picture Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Dominance in picture composition refers to the element that attracts the viewer's attention first. Which principle of design refers to the element that stands out or commands attention?,
      options: ["Dominance", Unity", "Balance, Rhythm"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dominance
    })
  },

  // --- 2.2 RHYTHM (3 Materials) ---
  {
    id: G7-CAS-RHY-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Rhythm",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Rhythm is an essential element of music that involves patterns of sound and silence. What is the term for the basic rhythmic unit of time in music?,
      options: ["A beat", A note, A rest", "A bar].sort(() => Math.random() - 0.5),
      correctAnswer: A beat"
    })
  },
  {
    id: "G7-CAS-RHY-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Rhythm,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Note values in music tell us how long a note should be held. What is the note value that lasts for two beats in simple time?,
      options: ["A minim", A crotchet", "A semibreve, A quaver"].sort(() => Math.random() - 0.5),
      correctAnswer: "A minim
    })
  },
  {
    id: G7-CAS-RHY-03",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Rhythm",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Time signatures tell us how many beats are in each bar of music. What does the top number in a time signature indicate?,
      options: ["The number of beats in each bar", The type of note that gets one beat, The tempo of the music", "The key signature].sort(() => Math.random() - 0.5),
      correctAnswer: The number of beats in each bar"
    })
  },

  // --- 2.3 ATHLETICS AND SCULPTURE (3 Materials) ---
  {
    id: "G7-CAS-ATH-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Athletics and Sculpture,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Athletics is a sport that involves running, jumping, and throwing events. Which athletic event involves throwing a metal spear with a pointed tip as far as possible?,
      options: ["Javelin", Shot put", "Discus, Hammer throw"].sort(() => Math.random() - 0.5),
      correctAnswer: "Javelin
    })
  },
  {
    id: G7-CAS-ATH-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics and Sculpture",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Sculpture is the art of creating three-dimensional forms. What is the technique of creating a sculpture by adding material such as clay called?,
      options: ["Modelling", Carving, Casting", "Assembling].sort(() => Math.random() - 0.5),
      correctAnswer: Modelling"
    })
  },
  {
    id: "G7-CAS-ATH-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Athletics and Sculpture,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Sculptures can be made from different materials and using different techniques. What is the process of creating a sculpture by cutting away material called?,
      options: ["Carving", Modelling", "Casting, Assembling"].sort(() => Math.random() - 0.5),
      correctAnswer: "Carving
    })
  },

  // --- 2.4 MELODY (3 Materials) ---
  {
    id: G7-CAS-MEL-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Melody",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Melody is a sequence of notes that is pleasing to the ear. What is the term for the distance between two notes in music?,
      options: ["An interval", A scale, A chord", "A phrase].sort(() => Math.random() - 0.5),
      correctAnswer: An interval"
    })
  },
  {
    id: "G7-CAS-MEL-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Melody,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Scales are the building blocks of melody in music. What is the scale of G major in terms of its notes?,
      options: ["G", A, B, C, D, E, F♯, G, G, A, B, C, D, E, F, G", "G, A, B♭, C, D, E♭, F, G, G, A, B, C♯, D, E, F♯, G"].sort(() => Math.random() - 0.5),
      correctAnswer: "G, A, B, C, D, E, F♯, G
    })
  },
  {
    id: G7-CAS-MEL-03",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Melody",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The bass staff is used to write notes in the lower register. What is the name of the line that is added above or below the stave to extend its range called?,
      options: ["A ledger line", A bass line, A staff line", "A bar line].sort(() => Math.random() - 0.5),
      correctAnswer: A ledger line"
    })
  },

  // --- 2.5 HANDBALL (2 Materials) ---
  {
    id: "G7-CAS-HAN-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Handball,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Handball is a fast-paced team sport played with a ball. How many players are on the court for each team during a handball match?,
      options: ["7 players", 5 players", "11 players, 9 players"].sort(() => Math.random() - 0.5),
      correctAnswer: "7 players
    })
  },
  {
    id: G7-CAS-HAN-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Handball",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The goal area in handball has specific rules that players must follow. What is the area in front of the goal where only the goalkeeper is allowed?,
      options: ["The goal area", The penalty area, The center circle", "The sideline].sort(() => Math.random() - 0.5),
      correctAnswer: The goal area"
    })
  },

  // --- 2.6 MULTIMEDIA ART (3 Materials) ---
  {
    id: "G7-CAS-MUL-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Multimedia Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Multimedia art combines different forms of media to create a single artwork. Which of the following is an example of multimedia art?,
      options: ["A video installation with sound and visuals.", A drawing on paper.", "A painting on canvas., A sculpture in bronze."].sort(() => Math.random() - 0.5),
      correctAnswer: "A video installation with sound and visuals.
    })
  },
  {
    id: G7-CAS-MUL-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Multimedia Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Digital literacy skills are important for creating multimedia art. Why is digital literacy important for learning and production in Creative Arts and Sports?,
      options: ["It enables learners to use digital tools for creating and presenting art.", It is only useful for professional artists., It is not relevant to Creative Arts.", "It distracts from traditional art forms.].sort(() => Math.random() - 0.5),
      correctAnswer: It enables learners to use digital tools for creating and presenting art."
    })
  },
  {
    id: "G7-CAS-MUL-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Multimedia Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Storyboarding is an important skill in multimedia production. What is the purpose of creating a storyboard?,
      options: ["To plan and visualize the sequence of a production.", To create the final product.", "To sell the idea to investors., To write the script."].sort(() => Math.random() - 0.5),
      correctAnswer: "To plan and visualize the sequence of a production.
    })
  },

  // --- 2.7 DESCANT RECORDER (3 Materials) ---
  {
    id: G7-CAS-DES-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Descant Recorder",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "The descant recorder is a simple woodwind instrument often used in music education. How is sound produced on the descant recorder?,
      options: ["By blowing air across a mouthpiece.", By blowing into a reed., By buzzing the lips.", "By plucking strings.].sort(() => Math.random() - 0.5),
      correctAnswer: By blowing air across a mouthpiece."
    })
  },
  {
    id: "G7-CAS-DES-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Descant Recorder,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Correct finger placement is essential for playing the descant recorder. What happens if the holes on a descant recorder are not completely covered?,
      options: ["The note sounds airy or squeaks.", The note sounds perfect.", "The note sounds louder., The note sounds lower."].sort(() => Math.random() - 0.5),
      correctAnswer: "The note sounds airy or squeaks.
    })
  },
  {
    id: G7-CAS-DES-03",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Descant Recorder",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The descant recorder has a specific range of notes it can play. What is the range of notes on a standard descant recorder?,
      options: ["From C4 to C6", From C3 to C5, From G3 to G5", "From F4 to F6].sort(() => Math.random() - 0.5),
      correctAnswer: From C4 to C6"
    })
  },

  // --- 2.8 STORYTELLING AND ANIMATION (3 Materials) ---
  {
    id: "G7-CAS-STO-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Storytelling and Animation,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Storytelling is an art form that has been practiced for generations in Kenya. What is the importance of storytelling in preserving Kenyan culture?,
      options: ["It passes down traditions", values, and history from one generation to another., It is only for entertainment.", "It is a modern practice., It is not important in Kenya."].sort(() => Math.random() - 0.5),
      correctAnswer: "It passes down traditions, values, and history from one generation to another.
    })
  },
  {
    id: G7-CAS-STO-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Storytelling and Animation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Animation can be used to bring stories to life in a visual way. What is the term for the technique of creating the illusion of movement using a sequence of images?,
      options: ["Animation", Videography, Photography", "Digital art].sort(() => Math.random() - 0.5),
      correctAnswer: Animation"
    })
  },
  {
    id: "G7-CAS-STO-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Storytelling and Animation,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Traditional folktales often contain moral lessons. What is the term for a short story that teaches a moral lesson, often with animals as characters?,
      options: ["A fable", A legend", "A myth, A parable"].sort(() => Math.random() - 0.5),
      correctAnswer: "A fable
    })
  },

  // --- 2.9 FOOTBALL (2 Materials) ---
  {
    id: G7-CAS-FOO-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Football",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Football is one of the most popular sports in Kenya and worldwide. How many players are on the field for each team during a football match?,
      options: ["11 players", 7 players, 5 players", "9 players].sort(() => Math.random() - 0.5),
      correctAnswer: 11 players"
    })
  },
  {
    id: "G7-CAS-FOO-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Football,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Goalkeeping in football requires specific skills. What is the rule about the goalkeeper handling the ball in their own penalty area?,
      options: ["The goalkeeper can handle the ball with their hands.", The goalkeeper cannot use their hands.", "The goalkeeper can only use their feet., The goalkeeper cannot leave the goal line."].sort(() => Math.random() - 0.5),
      correctAnswer: "The goalkeeper can handle the ball with their hands.
    })
  },

  // --- 2.10 KENYAN FOLK SONGS (3 Materials) ---
  {
    id: G7-CAS-FOL-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Kenyan Folk Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Kenyan folk songs are an important part of the country's cultural heritage. What is the term for a traditional song that tells a story about a community's history or beliefs?,
      options: ["A folk song", A lullaby, A pop song", "A religious hymn].sort(() => Math.random() - 0.5),
      correctAnswer: A folk song"
    })
  },
  {
    id: "G7-CAS-FOL-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Kenyan Folk Songs,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Many Kenyan folk songs are accompanied by traditional instruments. Which of the following is a traditional instrument used in the accompaniment of Kenyan folk songs?,
      options: ["The nyatiti", The piano", "The guitar, The violin"].sort(() => Math.random() - 0.5),
      correctAnswer: "The nyatiti
    })
  },
  {
    id: G7-CAS-FOL-03",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Kenyan Folk Songs",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Call-and-response is a common feature of Kenyan folk songs. What is the call-and-response pattern in music?,
      options: ["A leader sings a phrase and the group responds.", Everyone sings the same part., Two people sing different parts.", "The music plays without vocals.].sort(() => Math.random() - 0.5),
      correctAnswer: A leader sings a phrase and the group responds."
    })
  },

  // --- 2.11 INDIGENOUS KENYAN CRAFT - BEADWORK (3 Materials) ---
  {
    id: "G7-CAS-BEA-01",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Craft - Beadwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Beadwork is a traditional craft practiced by many Kenyan communities. Which Kenyan community is especially known for their intricate beadwork?,
      options: ["The Maasai", The Luo", "The Kikuyu, The Swahili"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Maasai
    })
  },
  {
    id: G7-CAS-BEA-02",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Indigenous Kenyan Craft - Beadwork",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Beadwork serves many purposes in Kenyan communities. What is one of the main purposes of Maasai beadwork?,
      options: ["To signify social status and cultural identity.", To make clothing., To build houses.", "To make weapons.].sort(() => Math.random() - 0.5),
      correctAnswer: To signify social status and cultural identity."
    })
  },
  {
    id: "G7-CAS-BEA-03",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Craft - Beadwork,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Beadwork techniques vary across different communities. What is the technique of weaving beads together using a needle and thread called?,
      options: ["Bead weaving", Bead stringing", "Bead embroidery, Bead loom work"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bead weaving
    })
  },

  // --- STRAND 3: APPRECIATION ---

  // --- 3.1 ANALYSIS OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: G7-CAS-ANA-01",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Analysis of Creative Arts and Sports involves examining and understanding different aspects of art and sports. What is the purpose of analyzing a piece of art?,
      options: ["To understand its meaning", techniques, and impact., To determine its monetary value., To copy it.", "To criticize it.].sort(() => Math.random() - 0.5),
      correctAnswer: "To understand its meaning", techniques, and impact."
    })
  },
  {
    id: "G7-CAS-ANA-02",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Appreciation",
    subtopic: "Analysis of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Entrepreneurship has been embedded in the Creative Arts and Sports curriculum. Why is entrepreneurship important in Creative Arts and Sports?,
      options: ["It equips learners with skills to create careers and businesses in the arts.", It makes the subject harder.", "It is only for business students., It is not relevant to arts."].sort(() => Math.random() - 0.5),
      correctAnswer: "It equips learners with skills to create careers and businesses in the arts.
    })
  },
  {
    id: G7-CAS-ANA-03",
    grade: "Grade 7,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports play important social roles in society. Which of the following is a social role of Creative Arts and Sports?,
      options: ["Promoting social cohesion and cultural identity.", Making money., Only for entertainment.", "Replacing formal education.].sort(() => Math.random() - 0.5),
      correctAnswer: Promoting social cohesion and cultural identity."
    })
  },
  {
    id: "G7-CAS-ANA-04",
    grade: "Grade 7",
    subject: "Creative Arts and Sports",
    topic: "Appreciation",
    subtopic: "Analysis of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports contribute to the economy in various ways. What is the economic role of Creative Arts and Sports?,
      options: ["Creating employment and generating revenue.", Only for entertainment.", "Consuming resources., Distracting people from work."].sort(() => Math.random() - 0.5),
      correctAnswer: "Creating employment and generating revenue.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD CREATIVE ARTS AND SPORTS SYLLABUS)
  // =========================================================================

  // --- STRAND 1: FOUNDATIONS OF CREATIVE ARTS AND SPORTS ---

  // --- 1.1 ROLES OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: G8-CAS-ROL-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Roles of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Creative Arts and Sports play various roles in society. What is the social role of Creative Arts and Sports in promoting peace and harmony?,
      options: ["They bring people together through shared activities and cultural expression.", They create conflict., They are only for competition.", "They divide communities.].sort(() => Math.random() - 0.5),
      correctAnswer: They bring people together through shared activities and cultural expression."
    })
  },
  {
    id: "G8-CAS-ROL-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Roles of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Creative Arts and Sports have economic roles in society. How do Creative Arts and Sports contribute to poverty eradication?,
      options: ["By creating employment opportunities in the arts and sports industry.", By giving money to the poor.", "By reducing the cost of living., By increasing taxes."].sort(() => Math.random() - 0.5),
      correctAnswer: "By creating employment opportunities in the arts and sports industry.
    })
  },
  {
    id: G8-CAS-ROL-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Roles of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports help to preserve cultural heritage. What is the role of traditional dances in preserving culture?,
      options: ["They pass down stories", beliefs, and traditions from one generation to the next., They entertain tourists., They make people happy.", "They are only performed for celebrations.].sort(() => Math.random() - 0.5),
      correctAnswer: "They pass down stories", beliefs, and traditions from one generation to the next."
    })
  },
  {
    id: "G8-CAS-ROL-04",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Roles of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "A storyboard is a visual representation of the roles of Creative Arts and Sports. What is a storyboard used for in Creative Arts and Sports?,
      options: ["To visually highlight the roles and importance of Creative Arts and Sports in society.", To write a story.", "To draw a picture., To create a sculpture."].sort(() => Math.random() - 0.5),
      correctAnswer: "To visually highlight the roles and importance of Creative Arts and Sports in society.
    })
  },

  // --- 1.2 COMPONENTS OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: G8-CAS-COM-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "A verse is a form of creative writing with specific elements. What are the elements of a verse?,
      options: ["Character", theme, and setting, Rhyme, rhythm, and structure, Plot, conflict, and resolution", "Title, author, and date].sort(() => Math.random() - 0.5),
      correctAnswer: "Character", theme, and setting"
    })
  },
  {
    id: "G8-CAS-COM-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Fitness is an important component of Creative Arts and Sports. What are the components of physical fitness related to endurance and agility?,
      options: ["Endurance and agility", Strength and flexibility", "Speed and balance, Power and coordination"].sort(() => Math.random() - 0.5),
      correctAnswer: "Endurance and agility
    })
  },
  {
    id: G8-CAS-COM-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The G major scale is an important scale in music theory. What are the notes of the G major scale?,
      options: ["G", A, B, C, D, E, F♯, G, G, A, B♭, C, D, E♭, F, G, G, A, B, C♯, D, E, F♯, G", "G, A♭, B, C, D♭, E, F, G].sort(() => Math.random() - 0.5),
      correctAnswer: "G", A, B, C, D, E, F♯, G"
    })
  },
  {
    id: "G8-CAS-COM-04",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The bass staff is used in music notation for lower pitches. What is the symbol used at the beginning of the bass staff?,
      options: ["The bass clef", The treble clef", "The alto clef, The tenor clef"].sort(() => Math.random() - 0.5),
      correctAnswer: "The bass clef
    })
  },

  // --- STRAND 2: CREATING AND PERFORMING ---

  // --- 2.1 PICTURE MAKING (3 Materials) ---
  {
    id: G8-CAS-PIC-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Picture Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Picture making involves applying elements and principles of art. What is the principle of design that creates a sense of visual stability in a composition?,
      options: ["Balance", Rhythm, Unity", "Variety].sort(() => Math.random() - 0.5),
      correctAnswer: Balance"
    })
  },
  {
    id: "G8-CAS-PIC-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Picture Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Splattering is a painting technique used to create texture. What is the splattering technique in painting?,
      options: ["Flicking or spraying paint onto a surface to create a textured effect.", Applying thick layers of paint.", "Using a brush to spread paint smoothly., Painting in small dots."].sort(() => Math.random() - 0.5),
      correctAnswer: "Flicking or spraying paint onto a surface to create a textured effect.
    })
  },
  {
    id: G8-CAS-PIC-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Picture Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Proportion is an important principle in picture composition. What does proportion refer to in visual art?,
      options: ["The size relationship between different elements in a composition.", The use of different colors., The arrangement of shapes.", "The thickness of lines.].sort(() => Math.random() - 0.5),
      correctAnswer: The size relationship between different elements in a composition."
    })
  },

  // --- 2.2 RHYTHM (3 Materials) ---
  {
    id: "G8-CAS-RHY-01",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Rhythm,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Rhythm in music involves the organization of time. What is the term for a group of notes played together in a defined time period?,
      options: ["A bar", A beat", "A note, A rest"].sort(() => Math.random() - 0.5),
      correctAnswer: "A bar
    })
  },
  {
    id: G8-CAS-RHY-02",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Rhythm",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Semibreves, minims, crotchets, and quavers are different note values. What is the longest note value among semibreve, minim, crotchet, and quaver?,
      options: ["A semibreve", A minim, A crotchet", "A quaver].sort(() => Math.random() - 0.5),
      correctAnswer: A semibreve"
    })
  },
  {
    id: "G8-CAS-RHY-03",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Rhythm,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Grouping notes in simple time requires understanding the time signature. In 3/4 time, how many beats are there in each bar?,
      options: ["3 beats", 2 beats", "4 beats, 6 beats"].sort(() => Math.random() - 0.5),
      correctAnswer: "3 beats
    })
  },

  // --- 2.3 ATHLETICS AND MONTAGE (3 Materials) ---
  {
    id: G8-CAS-ATH-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics and Montage",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Athletics includes running, jumping, and throwing events. What is the term for the event where athletes run as fast as they can over a short distance?,
      options: ["Sprint", Distance run, Hurdles", "Relay].sort(() => Math.random() - 0.5),
      correctAnswer: Sprint"
    })
  },
  {
    id: "G8-CAS-ATH-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Athletics and Montage,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "A montage is a visual composition that combines different images. What is the purpose of creating a montage in Creative Arts?,
      options: ["To combine multiple images to create a unified message or narrative.", To create a sculpture.", "To paint a portrait., To write a story."].sort(() => Math.random() - 0.5),
      correctAnswer: "To combine multiple images to create a unified message or narrative.
    })
  },
  {
    id: G8-CAS-ATH-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics and Montage",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Montage techniques can be used in both art and sports. How is the concept of montage applied in sports analytics?,
      options: ["By combining different clips to analyze athletic performance.", By running faster., By jumping higher.", "By throwing further.].sort(() => Math.random() - 0.5),
      correctAnswer: By combining different clips to analyze athletic performance."
    })
  },

  // --- 2.4 MELODY (3 Materials) ---
  {
    id: "G8-CAS-MEL-01",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Melody,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Melody is the main tune or theme of a piece of music. What is the term for a short melodic phrase that is repeated throughout a piece?,
      options: ["A motif", A scale", "A chord, A harmony"].sort(() => Math.random() - 0.5),
      correctAnswer: "A motif
    })
  },
  {
    id: G8-CAS-MEL-02",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Melody",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Piano keyboards are used to demonstrate melody and harmony. What is the term for an accidental note that raises the pitch by a semitone?,
      options: ["A sharp", A flat, A natural", "A key signature].sort(() => Math.random() - 0.5),
      correctAnswer: A sharp"
    })
  },
  {
    id: "G8-CAS-MEL-03",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Melody,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Middle C is an important reference point on the piano keyboard. What is middle C on the piano?,
      options: ["The C note that is located in the middle of the piano keyboard.", The highest C on the piano.", "The lowest C on the piano., The C note that starts the scale."].sort(() => Math.random() - 0.5),
      correctAnswer: "The C note that is located in the middle of the piano keyboard.
    })
  },

  // --- 2.5 NETBALL (2 Materials) ---
  {
    id: G8-CAS-NET-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Netball",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Netball is a popular team sport in Kenya. How many players are on the court for each team during a netball match?,
      options: ["7 players", 5 players, 11 players", "9 players].sort(() => Math.random() - 0.5),
      correctAnswer: 7 players"
    })
  },
  {
    id: "G8-CAS-NET-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Netball,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Netball has specific positions with defined areas of play. Which player in netball is allowed to shoot goals?,
      options: ["Goal Shooter and Goal Attack", Goal Keeper and Goal Defence", "Centre, Wing Attack and Wing Defence"].sort(() => Math.random() - 0.5),
      correctAnswer: "Goal Shooter and Goal Attack
    })
  },

  // --- 2.6 MULTIMEDIA ART (3 Materials) ---
  {
    id: G8-CAS-MUL-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Multimedia Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Multimedia art integrates various forms of media. What is multimedia art?,
      options: ["Art that combines different media such as video", audio, and images., Art that uses only one material., Art that is only digital.", "Art that is painted.].sort(() => Math.random() - 0.5),
      correctAnswer: "Art that combines different media such as video", audio, and images."
    })
  },
  {
    id: "G8-CAS-MUL-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Multimedia Art,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "ICT skills are essential for creating multimedia art. How do digital literacy skills enhance multimedia art production?,
      options: ["They enable artists to use software", editing, and distribution tools., They are not needed for art.", "They make art more expensive., They limit creativity."].sort(() => Math.random() - 0.5),
      correctAnswer: "They enable artists to use software, editing, and distribution tools.
    })
  },
  {
    id: G8-CAS-MUL-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Multimedia Art",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Audio is an important component of multimedia art. What is the term for the background music used in a multimedia production?,
      options: ["Soundtrack", Dialogue, Sound effects", "Narration].sort(() => Math.random() - 0.5),
      correctAnswer: Soundtrack"
    })
  },

  // --- 2.7 DESCANT RECORDER (3 Materials) ---
  {
    id: "G8-CAS-DES-01",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Descant Recorder,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The descant recorder is often the first instrument taught in music education. What is the note produced when all holes on a descant recorder are closed?,
      options: ["G", C", "D, F"].sort(() => Math.random() - 0.5),
      correctAnswer: "G
    })
  },
  {
    id: G8-CAS-DES-02",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Descant Recorder",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Breathing technique is important when playing the descant recorder. What is the correct way to produce a sound on a descant recorder?,
      options: ["Blow softly and steadily through the mouthpiece.", Blow as hard as possible., Suck air through the mouthpiece.", "Hold the recorder against your chin.].sort(() => Math.random() - 0.5),
      correctAnswer: Blow softly and steadily through the mouthpiece."
    })
  },
  {
    id: "G8-CAS-DES-03",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Descant Recorder,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Articulation refers to how notes are started and ended on the descant recorder. What is the term for the technique of starting a note with the tongue on a recorder?,
      options: ["Tonguing", Blowing", "Fingering, Bowing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tonguing
    })
  },

  // --- 2.8 VERSE (3 Materials) ---
  {
    id: G8-CAS-VER-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Verse",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Verse is a form of creative writing often used in drama and literature. What is the term for a group of lines in a poem or verse?,
      options: ["A stanza", A paragraph, A chapter", "A sentence].sort(() => Math.random() - 0.5),
      correctAnswer: A stanza"
    })
  },
  {
    id: "G8-CAS-VER-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Verse,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Verses often express emotions and ideas through language. What is the literary device where words are repeated at the beginning of successive lines?,
      options: ["Anaphora", Alliteration", "Assonance, Onomatopoeia"].sort(() => Math.random() - 0.5),
      correctAnswer: "Anaphora
    })
  },
  {
    id: G8-CAS-VER-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Verse",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Verses are often used in theatrical performances. What is the term for a verse that is spoken in a play without musical accompaniment?,
      options: ["Spoken verse", Sung verse, Chanted verse", "Recited verse].sort(() => Math.random() - 0.5),
      correctAnswer: Spoken verse"
    })
  },

  // --- 2.9 ATHLETICS (JAVELIN) (2 Materials) ---
  {
    id: "G8-CAS-JAV-01",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Athletics - Javelin,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "The javelin is an athletic throwing event with specific rules. What is the javelin made of?,
      options: ["Metal or composite materials", Wood only", "Plastic only, Glass"].sort(() => Math.random() - 0.5),
      correctAnswer: "Metal or composite materials
    })
  },
  {
    id: G8-CAS-JAV-02",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics - Javelin",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The throwing technique in javelin requires specific movements. What is the correct angle at which the javelin should be released?,
      options: ["About 30-40 degrees", 90 degrees, 0 degrees", "180 degrees].sort(() => Math.random() - 0.5),
      correctAnswer: About 30-40 degrees"
    })
  },

  // --- 2.10 INDIGENOUS KENYAN CRAFT - BASKETRY (3 Materials) ---
  {
    id: "G8-CAS-BAS-01",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Craft - Basketry,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Basketry is a traditional Kenyan craft that uses local materials. What natural materials are commonly used for making baskets?,
      options: ["Sisal and reeds", Plastic", "Metal, Glass"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sisal and reeds
    })
  },
  {
    id: G8-CAS-BAS-02",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Indigenous Kenyan Craft - Basketry",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Kiondoo baskets are a famous Kenyan craft product. Which community is known for making Kiondoo baskets?,
      options: ["The Kikuyu community", The Luo community, The Maasai community", "The Swahili community].sort(() => Math.random() - 0.5),
      correctAnswer: The Kikuyu community"
    })
  },
  {
    id: "G8-CAS-BAS-03",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Craft - Basketry,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Basketry techniques vary depending on the type of basket being made. What is the weaving technique where materials are crossed over and under each other called?,
      options: ["Simple weaving", Coiling", "Twining, Plaiting"].sort(() => Math.random() - 0.5),
      correctAnswer: "Simple weaving
    })
  },

  // --- STRAND 3: APPRECIATION ---

  // --- 3.1 ANALYSIS OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: G8-CAS-ANA-01",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Analysis of Creative Arts and Sports helps in understanding their impact. Why is it important to analyze Creative Arts and Sports?,
      options: ["To understand their influence on society and culture.", To make them more expensive., To limit their reach.", "To make them less important.].sort(() => Math.random() - 0.5),
      correctAnswer: To understand their influence on society and culture."
    })
  },
  {
    id: "G8-CAS-ANA-02",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Appreciation",
    subtopic: "Analysis of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Ethics and etiquette are important in Creative Arts and Sports. Why is it important to embrace ethics and etiquette in Creative Arts and Sports?,
      options: ["It enhances good citizenship and professionalism.", It makes the activities easier.", "It is not relevant., It is only for competitions."].sort(() => Math.random() - 0.5),
      correctAnswer: "It enhances good citizenship and professionalism.
    })
  },
  {
    id: G8-CAS-ANA-03",
    grade: "Grade 8,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports can be used to address contemporary issues. How can Creative Arts and Sports be used to address Pertinent and Contemporary Issues?,
      options: ["By creating works that raise awareness about issues like health and environment.", By ignoring these issues., By focusing only on entertainment.", "By avoiding controversial topics.].sort(() => Math.random() - 0.5),
      correctAnswer: By creating works that raise awareness about issues like health and environment."
    })
  },
  {
    id: "G8-CAS-ANA-04",
    grade: "Grade 8",
    subject: "Creative Arts and Sports",
    topic: "Appreciation",
    subtopic: "Analysis of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Patriotism can be fostered through participation in Creative Arts and Sports. How do Creative Arts and Sports promote patriotism?,
      options: ["By celebrating Kenya's diverse cultures and national identity.", By focusing only on international trends.", "By ignoring local culture., By promoting division."].sort(() => Math.random() - 0.5),
      correctAnswer: "By celebrating Kenya's diverse cultures and national identity.
    })
  }
// src/generators/creativeArtsAndSportsTemplates.ts (CONTINUED - Grade 9)

// =========================================================================
// GRADE 9: 35 MATERIALS (KICD CREATIVE ARTS AND SPORTS SYLLABUS)
// =========================================================================

  // --- STRAND 1: FOUNDATIONS OF CREATIVE ARTS AND SPORTS ---

  // --- 1.1 CREATIVE ARTS AND SPORTS IN SOCIETY (4 Materials) ---
  {
    id: G9-CAS-SOC-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Creative Arts and Sports in Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Creative Arts and Sports play a vital role in shaping society. What is the role of Creative Arts and Sports in promoting national unity and cohesion?,
      options: ["They bring together people from different backgrounds through shared activities and cultural expressions.", They divide communities., They are only for entertainment.", "They promote competition only.].sort(() => Math.random() - 0.5),
      correctAnswer: They bring together people from different backgrounds through shared activities and cultural expressions."
    })
  },
  {
    id: "G9-CAS-SOC-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Creative Arts and Sports in Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Creative Arts and Sports contribute significantly to the economy. How do Creative Arts and Sports contribute to national economic development?,
      options: ["By generating revenue through tourism", events, and creative industries., By increasing government spending.", "By reducing employment., By limiting economic growth."].sort(() => Math.random() - 0.5),
      correctAnswer: "By generating revenue through tourism, events, and creative industries.
    })
  },
  {
    id: G9-CAS-SOC-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Creative Arts and Sports in Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports help preserve and promote cultural heritage. What is the importance of preserving traditional Kenyan art forms?,
      options: ["They maintain cultural identity and pass down knowledge to future generations.", They are outdated., They have no value in modern society.", "They are only for tourists.].sort(() => Math.random() - 0.5),
      correctAnswer: They maintain cultural identity and pass down knowledge to future generations."
    })
  },
  {
    id: "G9-CAS-SOC-04",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Creative Arts and Sports in Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Creative Arts and Sports can be used to address social issues. How can Creative Arts and Sports be used to promote environmental conservation?,
      options: ["By creating awareness through art performances and sporting events.", By ignoring environmental issues.", "By focusing only on entertainment., By promoting pollution."].sort(() => Math.random() - 0.5),
      correctAnswer: "By creating awareness through art performances and sporting events.
    })
  },

  // --- 1.2 COMPONENTS OF CREATIVE ARTS AND SPORTS (4 Materials) ---
  {
    id: G9-CAS-COM-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Film is a powerful medium of creative expression. What are the key elements of film production?,
      options: ["Script", directing, cinematography, editing, and sound., Only acting., Only music.", "Only visual effects.].sort(() => Math.random() - 0.5),
      correctAnswer: "Script", directing, cinematography, editing, and sound."
    })
  },
  {
    id: "G9-CAS-COM-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Harmony is an important concept in music. What is the term for the simultaneous sounding of two or more notes to create a pleasing effect?,
      options: ["Harmony", Melody", "Rhythm, Timbre"].sort(() => Math.random() - 0.5),
      correctAnswer: "Harmony
    })
  },
  {
    id: G9-CAS-COM-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports,
    subtopic: "Components of Creative Arts and Sports",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The E major scale is used in many musical compositions. What are the notes of the E major scale?,
      options: ["E", F♯, G♯, A, B, C♯, D♯, E, E, F, G, A, B, C, D, E, E, F♯, G, A, B♭, C, D, E", "E, F♯, G♯, A♯, B, C♯, D♯, E].sort(() => Math.random() - 0.5),
      correctAnswer: "E", F♯, G♯, A, B, C♯, D♯, E"
    })
  },
  {
    id: "G9-CAS-COM-04",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Foundations of Creative Arts and Sports",
    subtopic: "Components of Creative Arts and Sports,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The treble clef is used for higher-pitched instruments and voices. Where is middle C positioned on the treble staff?,
      options: ["On the first ledger line below the staff.", On the first ledger line above the staff.", "On the bottom line of the staff., On the top line of the staff."].sort(() => Math.random() - 0.5),
      correctAnswer: "On the first ledger line below the staff.
    })
  },

  // --- STRAND 2: CREATING AND PERFORMING ---

  // --- 2.1 PICTURE MAKING (3 Materials) ---
  {
    id: G9-CAS-PIC-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Picture Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Composition in picture making involves arranging elements harmoniously. What is the term for the principle of design that uses contrasting elements to draw attention?,
      options: ["Emphasis", Balance, Rhythm", "Proportion].sort(() => Math.random() - 0.5),
      correctAnswer: Emphasis"
    })
  },
  {
    id: "G9-CAS-PIC-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Picture Making,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Texture can be created in visual art through various techniques. What is the term for the technique of creating texture by applying thick layers of paint called?,
      options: ["Impasto", Sgraffito", "Grisaille, Chiaroscuro"].sort(() => Math.random() - 0.5),
      correctAnswer: "Impasto
    })
  },
  {
    id: G9-CAS-PIC-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Picture Making",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Perspective is a technique used to create depth in picture making. What is the type of perspective that uses two vanishing points called?,
      options: ["Two-point perspective", One-point perspective, Three-point perspective", "Atmospheric perspective].sort(() => Math.random() - 0.5),
      correctAnswer: Two-point perspective"
    })
  },

  // --- 2.2 RHYTHM AND MELODY (3 Materials) ---
  {
    id: "G9-CAS-RHY-01",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Rhythm and Melody,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Rhythm and melody are fundamental elements of music. What is the term for a rhythmic pattern that is repeated throughout a piece of music?,
      options: ["An ostinato", A motif", "A phrase, A cadence"].sort(() => Math.random() - 0.5),
      correctAnswer: "An ostinato
    })
  },
  {
    id: G9-CAS-RHY-02",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Rhythm and Melody",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Compound time signatures are used in various musical genres. What does the time signature 6/8 indicate?,
      options: ["There are 6 beats in a bar and the eighth note gets one beat.", There are 6 beats in a bar., There are 8 beats in a bar.", "There are 6 beats in a bar and the quarter note gets one beat.].sort(() => Math.random() - 0.5),
      correctAnswer: There are 6 beats in a bar and the eighth note gets one beat."
    })
  },
  {
    id: "G9-CAS-RHY-03",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Rhythm and Melody,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Syncopation is a rhythm technique used in many music styles. What is the term for a rhythmic pattern where the emphasis is placed on off-beats?,
      options: ["Syncopation", Accent", "Staccato, Legato"].sort(() => Math.random() - 0.5),
      correctAnswer: "Syncopation
    })
  },

  // --- 2.3 ATHLETICS (SHOT PUT) (3 Materials) ---
  {
    id: G9-CAS-SHO-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics - Shot Put",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Shot put is a field athletics event that involves putting a heavy spherical object. What is the weight of the shot put used by male athletes in senior competitions?,
      options: ["7.26 kg", 4 kg, 5 kg", "6 kg].sort(() => Math.random() - 0.5),
      correctAnswer: 7.26 kg"
    })
  },
  {
    id: "G9-CAS-SHO-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Athletics - Shot Put,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The shot put circle has specific dimensions and rules. What is the diameter of the shot put circle?,
      options: ["2.135 meters", 1.5 meters", "2.5 meters, 3 meters"].sort(() => Math.random() - 0.5),
      correctAnswer: "2.135 meters
    })
  },
  {
    id: G9-CAS-SHO-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Athletics - Shot Put",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The technique of putting the shot involves specific movements. What are the two main techniques used in shot put?,
      options: ["The glide and the spin (rotational) techniques.", The jump and the throw., The step and the push.", "The slide and the toss.].sort(() => Math.random() - 0.5),
      correctAnswer: The glide and the spin (rotational) techniques."
    })
  },

  // --- 2.4 HARMONY (3 Materials) ---
  {
    id: "G9-CAS-HAR-01",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Harmony,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Harmony is the combination of simultaneously sounded musical notes. What is the term for a group of three or more notes played together called?,
      options: ["A chord", A scale", "An interval, A phrase"].sort(() => Math.random() - 0.5),
      correctAnswer: "A chord
    })
  },
  {
    id: G9-CAS-HAR-02",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Harmony",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "There are different types of chords used in harmony. What is the term for a chord consisting of a root, third, and fifth?,
      options: ["A triad", A seventh chord, A ninth chord", "An inverted chord].sort(() => Math.random() - 0.5),
      correctAnswer: A triad"
    })
  },
  {
    id: "G9-CAS-HAR-03",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Harmony,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Chord progressions form the harmonic structure of a piece of music. What is the term for the movement from one chord to another in a piece of music?,
      options: ["Chord progression", Chord inversion", "Chord resolution, Chord substitution"].sort(() => Math.random() - 0.5),
      correctAnswer: "Chord progression
    })
  },

  // --- 2.5 VOLLEYBALL (2 Materials) ---
  {
    id: G9-CAS-VOL-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Volleyball",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Volleyball is a team sport played with a ball over a net. How many players are on the court for each team during a volleyball match?,
      options: ["6 players", 7 players, 5 players", "8 players].sort(() => Math.random() - 0.5),
      correctAnswer: 6 players"
    })
  },
  {
    id: "G9-CAS-VOL-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Volleyball,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Volleyball has specific fundamental skills that players must master. What are the six basic skills in volleyball?,
      options: ["Serving", Passing, Setting, Spiking, Blocking, and Digging., Running, Jumping, Throwing, Catching, Kicking, and Diving.", "Batting, Bowling, Fielding, Wicket Keeping, Catching, and Throwing., Dribbling, Shooting, Passing, Rebounding, Defense, and Offense."].sort(() => Math.random() - 0.5),
      correctAnswer: "Serving, Passing, Setting, Spiking, Blocking, and Digging.
    })
  },

  // --- 2.6 DIGITAL ART AND ANIMATION (3 Materials) ---
  {
    id: G9-CAS-DIG-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Digital Art and Animation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Digital art has become an essential form of creative expression. What is the term for the process of creating images using computer software and digital tools?,
      options: ["Digital art", Traditional art, Sculpture", "Printmaking].sort(() => Math.random() - 0.5),
      correctAnswer: Digital art"
    })
  },
  {
    id: "G9-CAS-DIG-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Digital Art and Animation,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Animation brings digital art to life through movement. What is the term for the technique of creating animation using computer software?,
      options: ["Computer animation", Stop-motion animation", "Cut-out animation, Clay animation"].sort(() => Math.random() - 0.5),
      correctAnswer: "Computer animation
    })
  },
  {
    id: G9-CAS-DIG-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Digital Art and Animation",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Digital art offers various tools and techniques for artists. What is the term for the digital representation of an image made up of pixels?,
      options: ["Raster graphics", Vector graphics, Pixel art", "3D modeling].sort(() => Math.random() - 0.5),
      correctAnswer: Raster graphics"
    })
  },

  // --- 2.7 DESCANT RECORDER (3 Materials) ---
  {
    id: "G9-CAS-DES-01",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Descant Recorder,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "The descant recorder is an important instrument in music education. What is the term for the technique of playing notes in a smooth, connected manner on the recorder?,
      options: ["Legato", Staccato", "Slur, Accent"].sort(() => Math.random() - 0.5),
      correctAnswer: "Legato
    })
  },
  {
    id: G9-CAS-DES-02",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Descant Recorder",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "The descant recorder has a specific fingering system. What is the name of the hole on the back of the recorder that is covered by the thumb?,
      options: ["The thumb hole", The back hole, The octave hole", "The speaker hole].sort(() => Math.random() - 0.5),
      correctAnswer: The thumb hole"
    })
  },
  {
    id: "G9-CAS-DES-03",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Descant Recorder,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "The recorder can play many different notes across its range. What is the term for producing a note by covering half of the thumb hole on the recorder?,
      options: ["Half-covering", Half-thumbing", "Pinching, Half-holing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Half-covering
    })
  },

  // --- 2.8 DRAMA AND FILM (3 Materials) ---
  {
    id: G9-CAS-DRA-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Drama and Film",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Drama and film are powerful forms of creative expression. What is the term for the written text of a play or film?,
      options: ["A script", A storyboard, A novel", "A poem].sort(() => Math.random() - 0.5),
      correctAnswer: A script"
    })
  },
  {
    id: "G9-CAS-DRA-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Drama and Film,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Kenyan film industry, known as 'Riverwood,' is growing steadily. What is the term for the Kenyan film industry?,
      options: ["Riverwood", Nollywood", "Bollywood, Hollywood"].sort(() => Math.random() - 0.5),
      correctAnswer: "Riverwood
    })
  },
  {
    id: G9-CAS-DRA-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Drama and Film",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Film production involves different stages from concept to distribution. What is the term for the stage of film production where the actual filming takes place?,
      options: ["Production", Pre-production, Post-production", "Distribution].sort(() => Math.random() - 0.5),
      correctAnswer: Production"
    })
  },

  // --- 2.9 BASKETBALL (2 Materials) ---
  {
    id: "G9-CAS-BAS-01",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Basketball,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Basketball is a popular sport played by many Kenyans. How many players are on the court for each team during a basketball match?,
      options: ["5 players", 6 players", "7 players, 11 players"].sort(() => Math.random() - 0.5),
      correctAnswer: "5 players
    })
  },
  {
    id: G9-CAS-BAS-02",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Basketball",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Basketball has specific rules and violations. What is the term for the violation of moving with the ball without dribbling?,
      options: ["Traveling", Double dribble, Carrying", "Pivot].sort(() => Math.random() - 0.5),
      correctAnswer: Traveling"
    })
  },

  // --- 2.10 INDIGENOUS KENYAN INSTRUMENTS (3 Materials) ---
  {
    id: "G9-CAS-IND-01",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Kenya has a rich variety of traditional musical instruments. Which of the following is a traditional Kenyan instrument used by the Luo community?,
      options: ["The nyatiti", The drum", "The shaker, The horn"].sort(() => Math.random() - 0.5),
      correctAnswer: "The nyatiti
    })
  },
  {
    id: G9-CAS-IND-02",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Creating and Performing,
    subtopic: "Indigenous Kenyan Instruments",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Traditional Kenyan instruments are made from locally available materials. What materials are commonly used to make the nyatiti?,
      options: ["Wood and cowhide", Plastic, Metal", "Glass].sort(() => Math.random() - 0.5),
      correctAnswer: Wood and cowhide"
    })
  },
  {
    id: "G9-CAS-IND-03",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Creating and Performing",
    subtopic: "Indigenous Kenyan Instruments,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Instruments are often used to accompany Kenyan folk songs. Which instrument is commonly used by the Maasai community to accompany their songs?,
      options: ["The ol-ng'om (harp)", The drum", "The shaker, The flute"].sort(() => Math.random() - 0.5),
      correctAnswer: "The ol-ng'om (harp)
    })
  },

  // --- STRAND 3: APPRECIATION ---

  // --- 3.1 ANALYSIS AND CRITIQUE (3 Materials) ---
  {
    id: G9-CAS-CRI-01",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis and Critique",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: "Art critique involves evaluating and analyzing artworks. What are the steps of art critique in order?,
      options: ["Description", Analysis, Interpretation, and Judgment., Interpretation, Description, Judgment, and Analysis., Judgment, Description, Analysis, and Interpretation.", "Analysis, Description, Interpretation, and Judgment.].sort(() => Math.random() - 0.5),
      correctAnswer: "Description", Analysis, Interpretation, and Judgment."
    })
  },
  {
    id: "G9-CAS-CRI-02",
    grade: "Grade 9",
    subject: "Creative Arts and Sports",
    topic: "Appreciation",
    subtopic: "Analysis and Critique,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: "Creative Arts and Sports can serve as career pathways. Which of the following is a potential career path in Creative Arts and Sports?,
      options: ["Graphic design", sports coaching, music production., Medicine only.", "Law only., Engineering only."].sort(() => Math.random() - 0.5),
      correctAnswer: "Graphic design, sports coaching, music production.
    })
  },
  {
    id: G9-CAS-CRI-03",
    grade: "Grade 9,
    subject: Creative Arts and Sports",
    topic: "Appreciation,
    subtopic: "Analysis and Critique",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: "Career skills in Creative Arts and Sports are valuable for the future. Why is it important for Grade 9 learners to develop career skills in Creative Arts and Sports?,
      options: ["To prepare them for career paths and entrepreneurship in these fields.", It is not important., Only for professional athletes.", "Only for artists.].sort(() => Math.random() - 0.5),
      correctAnswer: To prepare them for career paths and entrepreneurship in these fields."
    })
  }

];

