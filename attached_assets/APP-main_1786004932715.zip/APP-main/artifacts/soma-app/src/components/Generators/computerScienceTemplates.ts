export const computerScienceTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: INTRODUCTION TO COMPUTERS (4 Materials) ---
  {
    id: "G7-CS-INT-01",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Introduction to Computers",
    subtopic: "Definition of a Computer",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "A computer is an electronic device that processes data to produce information. Which of the following is a key characteristic of a computer?,
      options: [It can process data at very high speeds., It can think and make decisions like humans., "It does not need electricity to operate., It can only perform one task."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can process data at very high speeds.
    })
  },
  {
    id: G7-CS-INT-02",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Introduction to Computers,
    subtopic: "Types of Computers",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Computers can be classified based on their size and processing power. Which of the following is a type of computer based on size?,
      options: [Supercomputer, Lightweight computer, Visual computer", "Analytical computer].sort(() => Math.random() - 0.5),
      correctAnswer: Supercomputer"
    })
  },
  {
    id: "G7-CS-INT-03",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Introduction to Computers",
    subtopic: "Types of Computers,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Based on the type of data they process, computers can be categorized as analog, digital, or hybrid. What type of computer is a standard desktop PC?,
      options: ["Digital computer, Analog computer", "Hybrid computer, Mechanical computer"].sort(() => Math.random() - 0.5),
      correctAnswer: "Digital computer
    })
  },
  {
    id: G7-CS-INT-04",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Introduction to Computers,
    subtopic: "History of Computers",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The history of computers dates back to ancient counting devices. Which of the following is considered one of the earliest computing devices?,
      options: [The Abacus, The Smartphone, The Laptop", "The Tablet].sort(() => Math.random() - 0.5),
      correctAnswer: The Abacus"
    })
  },

  // --- MADA: COMPUTER HARDWARE (5 Materials) ---
  {
    id: "G7-CS-HWR-01",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Hardware",
    subtopic: "Input Devices,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Input devices are used to enter data and instructions into a computer. Which of the following is an input device?,
      options: [A keyboard, A monitor, "A printer, A speaker"].sort(() => Math.random() - 0.5),
      correctAnswer: "A keyboard
    })
  },
  {
    id: G7-CS-HWR-02",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Hardware,
    subtopic: "Input Devices",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A scanner is a common input device used in schools and offices. What is the primary function of a scanner?,
      options: [To convert hard-copy documents into digital format., To print documents., To display images.", "To play sound.].sort(() => Math.random() - 0.5),
      correctAnswer: To convert hard-copy documents into digital format."
    })
  },
  {
    id: "G7-CS-HWR-03",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Hardware",
    subtopic: "Output Devices,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Output devices display or produce the results of computer processing. Which of the following is an output device?,
      options: [A monitor, A mouse, "A microphone, A scanner"].sort(() => Math.random() - 0.5),
      correctAnswer: "A monitor
    })
  },
  {
    id: G7-CS-HWR-04",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Hardware,
    subtopic: "Output Devices",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A printer is a common output device that produces a hard copy of information. Which type of printer is commonly used in schools and small offices?,
      options: [Inkjet printer, Laser printer, Dot matrix printer", "3D printer].sort(() => Math.random() - 0.5),
      correctAnswer: Inkjet printer"
    })
  },
  {
    id: "G7-CS-HWR-05",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Hardware",
    subtopic: "Storage Devices,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Storage devices are used to save data permanently or temporarily. Which of the following is a common example of secondary storage?,
      options: [USB flash drive, RAM, "CPU cache, ROM"].sort(() => Math.random() - 0.5),
      correctAnswer: "USB flash drive
    })
  },

  // --- MADA: COMPUTER SOFTWARE (4 Materials) ---
  {
    id: G7-CS-SWR-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Software,
    subtopic: "System Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Computer software is a set of instructions that tells the computer what to do. Which of the following is an example of system software?,
      options: [An operating system, Microsoft Word, Adobe Photoshop", "Google Chrome].sort(() => Math.random() - 0.5),
      correctAnswer: An operating system"
    })
  },
  {
    id: "G7-CS-SWR-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Software",
    subtopic: "Application Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Application software is designed to help users perform specific tasks. Which of the following is an example of application software?,
      options: [MS Excel, Windows 10, "macOS, Linux"].sort(() => Math.random() - 0.5),
      correctAnswer: "MS Excel
    })
  },
  {
    id: G7-CS-SWR-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Software,
    subtopic: "System Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Device drivers are a type of system software. What is the main function of a device driver?,
      options: [To enable the operating system to communicate with a hardware device., To create documents., To browse the internet.", "To edit images.].sort(() => Math.random() - 0.5),
      correctAnswer: To enable the operating system to communicate with a hardware device."
    })
  },
  {
    id: "G7-CS-SWR-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Software",
    subtopic: "Application Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Utility software is a type of system software designed to help manage and optimize the computer. Which of the following is an example of utility software?,
      options: [Antivirus software, Microsoft Word, "Google Chrome, Adobe Reader"].sort(() => Math.random() - 0.5),
      correctAnswer: "Antivirus software
    })
  },

  // --- MADA: OPERATING SYSTEMS (4 Materials) ---
  {
    id: G7-CS-OS-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Operating Systems,
    subtopic: "Functions of an Operating System",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " An operating system (OS) is the most important software on a computer. What is the primary function of an operating system?,
      options: [It manages the computer's hardware and software resources., It creates documents., It edits videos.", "It plays games.].sort(() => Math.random() - 0.5),
      correctAnswer: It manages the computer's hardware and software resources."
    })
  },
  {
    id: "G7-CS-OS-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Operating Systems",
    subtopic: "Functions of an Operating System,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The operating system provides a user interface (UI) that allows users to interact with the computer. What is the difference between a GUI and a CLI?,
      options: [GUI uses icons and graphics, while CLI uses text commands., GUI uses text, while CLI uses graphics., "They are the same., GUI is only for Windows, CLI is only for Linux."].sort(() => Math.random() - 0.5),
      correctAnswer: "GUI uses icons and graphics, while CLI uses text commands.
    })
  },
  {
    id: G7-CS-OS-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Operating Systems,
    subtopic: "Examples of Operating Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " There are many different operating systems available for computers and mobile devices. Which of the following is a popular mobile operating system?,
      options: [Android, Windows 10, macOS", "Linux].sort(() => Math.random() - 0.5),
      correctAnswer: Android"
    })
  },
  {
    id: "G7-CS-OS-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Operating Systems",
    subtopic: "File Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "One of the key functions of an operating system is file management. How does an OS organize files on a computer?,
      options: [It creates a hierarchical system of folders and directories., It stores all files in a single list., "It does not organize files., It uses color codes to organize files."].sort(() => Math.random() - 0.5),
      correctAnswer: "It creates a hierarchical system of folders and directories.
    })
  },

  // --- MADA: WORD PROCESSING (4 Materials) ---
  {
    id: G7-CS-WP-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Word Processing,
    subtopic: "Creating a Document",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Word processing software is used to create, edit, and format text-based documents. What is the first step to create a new document in MS Word?,
      options: [Click on 'File' and select 'New'., Turn off the computer., Click the mouse twice.", "Plug in the printer.].sort(() => Math.random() - 0.5),
      correctAnswer: Click on 'File' and select 'New'."
    })
  },
  {
    id: "G7-CS-WP-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Word Processing",
    subtopic: "Typing and Formatting Text,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "After typing text in a word processor, you can format it to make it look professional. Which feature would you use to make text bold and italic?,
      options: [Bold and Italic buttons, Spell Check", "Page Setup, Print Preview"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bold and Italic buttons
    })
  },
  {
    id: G7-CS-WP-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Word Processing,
    subtopic: "Inserting Images and Tables",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " MS Word allows you to enhance your document by adding images and tables. Where do you find the option to insert a picture in MS Word?,
      options: [From the 'Insert' tab., From the 'Home' tab., From the 'Design' tab.", "From the 'File' menu.].sort(() => Math.random() - 0.5),
      correctAnswer: From the 'Insert' tab."
    })
  },
  {
    id: "G7-CS-WP-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Word Processing",
    subtopic: "Saving and Printing a Document,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Once you have finished working on a document, it is important to save your work. What is the keyboard shortcut for saving a document in most programs?,
      options: [Ctrl + S, Ctrl + P", "Ctrl + C, Ctrl + V"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ctrl + S
    })
  },

  // --- MADA: SPREADSHEETS (4 Materials) ---
  {
    id: G7-CS-SS-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Spreadsheets,
    subtopic: "Introduction to Spreadsheets",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " A spreadsheet is an electronic document used to store and analyze data in rows and columns. What is the basic unit of a spreadsheet called?,
      options: [A cell, A row, A column", "A sheet].sort(() => Math.random() - 0.5),
      correctAnswer: A cell"
    })
  },
  {
    id: "G7-CS-SS-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Spreadsheets",
    subtopic: "Entering Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "To enter data into a spreadsheet, you need to click on a cell and type. How are rows and columns labeled in a typical spreadsheet like MS Excel?,
      options: [Rows are labeled with numbers and columns with letters., Rows are labeled with letters and columns with numbers.", "Both are labeled with numbers., Both are labeled with letters."].sort(() => Math.random() - 0.5),
      correctAnswer: "Rows are labeled with numbers and columns with letters.
    })
  },
  {
    id: G7-CS-SS-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Spreadsheets,
    subtopic: "Basic Formulas",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Formulas are used to perform calculations in a spreadsheet. What formula would you use to add the values in cells A1 and B1?,
      options: [=A1+B1, =A1*B1, =A1-B1", "=A1/B1].sort(() => Math.random() - 0.5),
      correctAnswer: =A1+B1"
    })
  },
  {
    id: "G7-CS-SS-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Spreadsheets",
    subtopic: "Basic Formulas,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "MS Excel has built-in functions to help you calculate data quickly. Which function would you use to find the average of a range of numbers?,
      options: [AVERAGE, SUM, "MAX, MIN"].sort(() => Math.random() - 0.5),
      correctAnswer: "AVERAGE
    })
  },

  // --- MADA: PRESENTATIONS (3 Materials) ---
  {
    id: G7-CS-PRES-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Presentations,
    subtopic: "Creating a Presentation",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Presentation software like MS PowerPoint is used to create slideshows for presentations. What is a slide in a presentation?,
      options: [A single page or screen in the presentation., A video clip., A piece of audio.", "A spreadsheet.].sort(() => Math.random() - 0.5),
      correctAnswer: A single page or screen in the presentation."
    })
  },
  {
    id: "G7-CS-PRES-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Presentations",
    subtopic: "Adding Transitions and Animations,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Transitions and animations are used to make presentations more engaging. What is the difference between a transition and an animation in MS PowerPoint?,
      options: [A transition is applied to slides, while an animation is applied to objects on a slide., They are the same., "Animation is applied to slides, while transition is applied to objects., Neither is used in PowerPoint."].sort(() => Math.random() - 0.5),
      correctAnswer: "A transition is applied to slides, while an animation is applied to objects on a slide.
    })
  },
  {
    id: G7-CS-PRES-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Presentations,
    subtopic: "Inserting Text and Images",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " To create a good presentation, you must insert text and images on your slides. Where would you click to insert a new slide in MS PowerPoint?,
      options: [The 'New Slide' button on the 'Home' tab., The 'File' menu., The 'Insert' tab.", "The 'View' tab.].sort(() => Math.random() - 0.5),
      correctAnswer: The 'New Slide' button on the 'Home' tab."
    })
  },

  // --- MADA: THE INTERNET (3 Materials) ---
  {
    id: "G7-CS-NET-01",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "The Internet",
    subtopic: "Introduction to the Internet,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The internet is a global network that connects millions of computers. What is the main purpose of the internet?,
      options: [To connect people and share information globally., To replace television., "To replace books., To make phone calls."].sort(() => Math.random() - 0.5),
      correctAnswer: "To connect people and share information globally.
    })
  },
  {
    id: G7-CS-NET-02",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "The Internet,
    subtopic: "Browsing and Search Engines",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " To find information on the internet, we use web browsers and search engines. What is the primary function of a web browser?,
      options: [To access and display web pages., To create a new email account., To print documents.", "To edit photos.].sort(() => Math.random() - 0.5),
      correctAnswer: To access and display web pages."
    })
  },
  {
    id: "G7-CS-NET-03",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "The Internet",
    subtopic: "Browsing and Search Engines,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A search engine helps you find specific information on the World Wide Web. Which of the following is a popular search engine?,
      options: [Google, Windows, "MS Word, PowerPoint"].sort(() => Math.random() - 0.5),
      correctAnswer: "Google
    })
  },

  // --- MADA: EMAIL (4 Materials) ---
  {
    id: G7-CS-EMA-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Email,
    subtopic: "Creating an Email Account",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Email is one of the most common methods of digital communication. What is the first step to start using email?,
      options: [Create an email account., Buy a computer., Install an antivirus.", "Connect a printer.].sort(() => Math.random() - 0.5),
      correctAnswer: Create an email account."
    })
  },
  {
    id: "G7-CS-EMA-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Email",
    subtopic: "Composing and Sending an Email,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Once you have an email account, you can send messages to others. What are the main components of an email message?,
      options: [To, Subject, and Body, To, CC, and BCC", "Subject and Attachments, Body and Signature"].sort(() => Math.random() - 0.5),
      correctAnswer: "To, Subject, and Body
    })
  },
  {
    id: G7-CS-EMA-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Email,
    subtopic: "Reading and Replying to Emails",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " When you receive an email, you can read it and reply to the sender. What button do you click to send a response back to the person who emailed you?,
      options: [Reply, Forward, Delete", "Spam].sort(() => Math.random() - 0.5),
      correctAnswer: Reply"
    })
  },
  {
    id: "G7-CS-EMA-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Email",
    subtopic: "Managing the Inbox,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Managing your email inbox helps you stay organized. Which folder is used to store important emails you want to keep for future reference?,
      options: [Inbox, Trash, "Sent, Junk"].sort(() => Math.random() - 0.5),
      correctAnswer: "Inbox
    })
  },

  // --- MADA: COMPUTER ETHICS (4 Materials) ---
  {
    id: G7-CS-ETH-01",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Ethics,
    subtopic: "Responsible Use of Computers",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Computer ethics refers to the moral principles that guide the use of computers and the internet. What is one rule for responsible computer use?,
      options: [Respect the privacy of others online., Share everyone's passwords., Use computers only for games.", "Ignore copyright laws.].sort(() => Math.random() - 0.5),
      correctAnswer: Respect the privacy of others online."
    })
  },
  {
    id: "G7-CS-ETH-02",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Ethics",
    subtopic: "Cyberbullying,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Cyberbullying is the use of digital technology to harass, threaten, or embarrass another person. What should you do if you experience cyberbullying?,
      options: ["Tell a trusted adult and block the bully., Ignore it completely.", "Reply with angry messages., Share your password with them."].sort(() => Math.random() - 0.5),
      correctAnswer: "Tell a trusted adult and block the bully.
    })
  },
  {
    id: G7-CS-ETH-03",
    grade: "Grade 7,
    subject: Computer Science",
    topic: "Computer Ethics,
    subtopic: "Privacy and Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Protecting your privacy online is an important part of computer ethics. What is a safe practice when using social media?,
      options: [Keep your personal information private., Share your home address publicly., Post photos of your ID card.", "Accept friend requests from strangers.].sort(() => Math.random() - 0.5),
      correctAnswer: Keep your personal information private."
    })
  },
  {
    id: "G7-CS-ETH-04",
    grade: "Grade 7",
    subject: "Computer Science",
    topic: "Computer Ethics",
    subtopic: "Privacy and Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Using strong passwords is one way to protect your online accounts. Which of the following would make a strong password?,
      options: [A mix of letters, numbers, and symbols., Your name and birthdate., "The word 'password'., Your phone number."].sort(() => Math.random() - 0.5),
      correctAnswer: "A mix of letters, numbers, and symbols.
    })
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: COMPUTER HARDWARE (ADVANCED) (4 Materials) ---
  {
    id: G8-CS-HWR-01",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Computer Hardware (Advanced),
    subtopic: "The CPU (Control Unit", ALU, Registers)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The CPU is often called the 'brain' of the computer. Which part of the CPU performs arithmetic and logic operations?,
      options: [The ALU, The Control Unit, The Registers", "The Cache].sort(() => Math.random() - 0.5),
      correctAnswer: The ALU"
    })
  },
  {
    id: "G8-CS-HWR-02",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Computer Hardware (Advanced)",
    subtopic: "The CPU (Control Unit, ALU, Registers),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Control Unit is responsible for directing the operations of the CPU. What is the primary role of the Control Unit?,
      options: [To fetch, decode, and execute instructions., To store data permanently., "To perform mathematical calculations., To connect to the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "To fetch, decode, and execute instructions.
    })
  },
  {
    id: G8-CS-HWR-03",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Computer Hardware (Advanced),
    subtopic: "Memory (RAM", ROM, Cache)",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Computers have different types of memory. What is the main difference between RAM and ROM?,
      options: [RAM is volatile (data is lost when powered off), while ROM is non-volatile (data is retained)., RAM is non-volatile, while ROM is volatile., They are the same.", "RAM is read-only, while ROM is read-write.].sort(() => Math.random() - 0.5),
      correctAnswer: RAM is volatile (data is lost when powered off), while ROM is non-volatile (data is retained)."
    })
  },
  {
    id: "G8-CS-HWR-04",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Computer Hardware (Advanced)",
    subtopic: "Motherboard Components,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The motherboard is the main circuit board of a computer. What is the function of the motherboard?,
      options: [It connects all the internal components together., It stores all files permanently., "It performs all mathematical calculations., It connects to the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "It connects all the internal components together.
    })
  },

  // --- MADA: SOFTWARE (ADVANCED) (4 Materials) ---
  {
    id: G8-CS-SWR-01",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Software (Advanced),
    subtopic: "Open-source vs. Proprietary Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Software can be classified based on its licensing. What is the main difference between open-source and proprietary software?,
      options: [Open-source software is free to use and modify, while proprietary software requires a license., Open-source software is always paid., Proprietary software is always free.", "There is no difference.].sort(() => Math.random() - 0.5),
      correctAnswer: Open-source software is free to use and modify, while proprietary software requires a license."
    })
  },
  {
    id: "G8-CS-SWR-02",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Software (Advanced)",
    subtopic: "Utility Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Utility software helps in managing the computer's performance and security. Which of the following is an example of utility software?,
      options: [Disk cleanup, Microsoft Word, "Google Chrome, Adobe Photoshop"].sort(() => Math.random() - 0.5),
      correctAnswer: "Disk cleanup
    })
  },
  {
    id: G8-CS-SWR-03",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Software (Advanced),
    subtopic: "Utility Software",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Compression software is a type of utility software. What is the main purpose of file compression?,
      options: [To reduce the size of a file., To delete files permanently., To create a backup.", "To encrypt files.].sort(() => Math.random() - 0.5),
      correctAnswer: To reduce the size of a file."
    })
  },
  {
    id: "G8-CS-SWR-04",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Software (Advanced)",
    subtopic: "Utility Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Antivirus software is a crucial utility for computer security. How does antivirus software protect a computer?,
      options: [It scans for and removes viruses and malware., It helps users play games., "It edits documents., It creates spreadsheets."].sort(() => Math.random() - 0.5),
      correctAnswer: "It scans for and removes viruses and malware.
    })
  },

  // --- MADA: OPERATING SYSTEMS (ADVANCED) (3 Materials) ---
  {
    id: G8-CS-OS-01",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Operating Systems (Advanced),
    subtopic: "File Management Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The OS organizes files using file management systems. What is the purpose of a directory structure?,
      options: [To organize and locate files easily., To make files harder to find., To delete files automatically.", "To keep files encrypted.].sort(() => Math.random() - 0.5),
      correctAnswer: To organize and locate files easily."
    })
  },
  {
    id: "G8-CS-OS-02",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Operating Systems (Advanced)",
    subtopic: "File Management Systems,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Creating and organizing folders is a key part of file management. What is the best practice for organizing your files on a computer?,
      options: [Create a logical folder system based on topics or projects., Save all files on the desktop., "Save all files with random names., Never use folders."].sort(() => Math.random() - 0.5),
      correctAnswer: "Create a logical folder system based on topics or projects.
    })
  },
  {
    id: G8-CS-OS-03",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Operating Systems (Advanced),
    subtopic: "File Management Systems",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The operating system also manages file permissions. What is the difference between 'Read-only' and 'Read-Write' access?,
      options: [Read-only allows viewing, while Read-Write allows viewing and editing., Read-only allows editing, while Read-Write allows viewing., They are the same.", "Read-only is for administrators only.].sort(() => Math.random() - 0.5),
      correctAnswer: Read-only allows viewing, while Read-Write allows viewing and editing."
    })
  },

  // --- MADA: WORD PROCESSING (ADVANCED) (4 Materials) ---
  {
    id: "G8-CS-WP-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Word Processing (Advanced)",
    subtopic: "Inserting Tables,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Tables are often used in documents to organize information clearly. How do you insert a table in MS Word?,
      options: [From the 'Insert' tab using the 'Table' dropdown., From the 'Home' tab., "From the 'View' tab., From the 'File' menu."].sort(() => Math.random() - 0.5),
      correctAnswer: "From the 'Insert' tab using the 'Table' dropdown.
    })
  },
  {
    id: G8-CS-WP-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Word Processing (Advanced),
    subtopic: "Headers and Footers",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Headers and footers appear at the top and bottom of each page. What information is commonly placed in a header or footer?,
      options: [Page numbers, document titles, and dates., The user's name., The computer's serial number.", "The operating system version.].sort(() => Math.random() - 0.5),
      correctAnswer: Page numbers, document titles, and dates."
    })
  },
  {
    id: "G8-CS-WP-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Word Processing (Advanced)",
    subtopic: "Mail Merge,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Mail merge is a powerful feature in MS Word used to create personalized letters. When would you use mail merge?,
      options: [To send the same letter to multiple recipients with their own names and addresses., To insert a table., "To add headers and footers., To insert an image."].sort(() => Math.random() - 0.5),
      correctAnswer: "To send the same letter to multiple recipients with their own names and addresses.
    })
  },
  {
    id: G8-CS-WP-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Word Processing (Advanced),
    subtopic: "Mail Merge",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " When using mail merge, you need a data source and a main document. What is the main document in mail merge?,
      options: [The template with placeholders for personalized information., The list of recipients., The document you print.", "The final email.].sort(() => Math.random() - 0.5),
      correctAnswer: The template with placeholders for personalized information."
    })
  },

  // --- MADA: SPREADSHEETS (ADVANCED) (4 Materials) ---
  {
    id: "G8-CS-SS-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Spreadsheets (Advanced)",
    subtopic: "Sorting and Filtering Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sorting and filtering are essential tools for analyzing data in spreadsheets. What is the purpose of sorting data?,
      options: [To arrange data in a specific order., To delete data., "To create a graph., To save the file."].sort(() => Math.random() - 0.5),
      correctAnswer: "To arrange data in a specific order.
    })
  },
  {
    id: G8-CS-SS-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Spreadsheets (Advanced),
    subtopic: "Sorting and Filtering Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The IF function is a logical function in Excel. What is the syntax of the IF function?,
      options: [=IF(condition, value_if_true, value_if_false), =IF(value_if_true, condition, value_if_false), =IF(value_if_true, value_if_false, condition)", "=IF(condition, value_if_false, value_if_true)].sort(() => Math.random() - 0.5),
      correctAnswer: =IF(condition, value_if_true, value_if_false)"
    })
  },
  {
    id: "G8-CS-SS-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Spreadsheets (Advanced)",
    subtopic: "Creating Charts,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Charts provide a visual representation of data in a spreadsheet. Which type of chart is best for showing data trends over time?,
      options: [Line chart, Pie chart, "Bar chart, Scatter plot"].sort(() => Math.random() - 0.5),
      correctAnswer: "Line chart
    })
  },
  {
    id: G8-CS-SS-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Spreadsheets (Advanced),
    subtopic: "Creating Charts",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Which type of chart is used to compare categories of data side-by-side?,
      options: [Bar chart, Line chart, Pie chart", "Area chart].sort(() => Math.random() - 0.5),
      correctAnswer: Bar chart"
    })
  },

  // --- MADA: DATABASES (4 Materials) ---
  {
    id: "G8-CS-DB-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Databases",
    subtopic: "Introduction to Databases,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "A database is a structured collection of data. What is the purpose of a database?,
      options: [To store and organize large amounts of data efficiently., To create documents., "To edit photos., To play games."].sort(() => Math.random() - 0.5),
      correctAnswer: "To store and organize large amounts of data efficiently.
    })
  },
  {
    id: G8-CS-DB-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Databases,
    subtopic: "Tables", Records, and Fields",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Data in a database is stored in tables. What is the difference between a record and a field in a database table?,
      options: [A record is a row, and a field is a column., A record is a column, and a field is a row., They are the same.", "A record is a cell, and a field is a row.].sort(() => Math.random() - 0.5),
      correctAnswer: A record is a row, and a field is a column."
    })
  },
  {
    id: "G8-CS-DB-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Databases",
    subtopic: "Primary Keys,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A primary key is a field that uniquely identifies each record in a table. What is the purpose of a primary key?,
      options: [To ensure that each record can be uniquely identified., To delete records., "To sort records., To add records."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure that each record can be uniquely identified.
    })
  },
  {
    id: G8-CS-DB-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Databases,
    subtopic: "Creating a Database",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " MS Access is a popular database management system. What is the first step to create a new database in MS Access?,
      options: [Open MS Access and click on 'Blank Database'., Open Microsoft Word., Open Excel.", "Create a new folder.].sort(() => Math.random() - 0.5),
      correctAnswer: Open MS Access and click on 'Blank Database'."
    })
  },

  // --- MADA: THE INTERNET (ADVANCED) (4 Materials) ---
  {
    id: "G8-CS-NET-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "The Internet (Advanced)",
    subtopic: "URLs and Domain Names,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A URL is an address used to locate a resource on the web. What does URL stand for?,
      options: [Uniform Resource Locator, Universal Resource Locator, "Uniform Resource Link, Universal Resource Link"].sort(() => Math.random() - 0.5),
      correctAnswer: "Uniform Resource Locator
    })
  },
  {
    id: G8-CS-NET-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "The Internet (Advanced),
    subtopic: "HTTP and HTTPS",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Web pages are transmitted over the internet using protocols. What is the difference between HTTP and HTTPS?,
      options: [HTTPS is a secure version of HTTP, encrypted for security., HTTP is secure, while HTTPS is not., They are the same.", "HTTP is used for email, while HTTPS is used for web pages.].sort(() => Math.random() - 0.5),
      correctAnswer: HTTPS is a secure version of HTTP, encrypted for security."
    })
  },
  {
    id: "G8-CS-NET-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "The Internet (Advanced)",
    subtopic: "IP Addresses,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Every device on the internet has an IP address. What is an IP address?,
      options: [A unique numerical label assigned to each device on a network., A web address., "A domain name., A type of software."].sort(() => Math.random() - 0.5),
      correctAnswer: "A unique numerical label assigned to each device on a network.
    })
  },
  {
    id: G8-CS-NET-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "The Internet (Advanced),
    subtopic: "IP Addresses",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " An example of an IP address is 192.168.1.1. What is the main purpose of an IP address?,
      options: [To identify and locate devices on a network., To store files., To send emails.", "To browse the web.].sort(() => Math.random() - 0.5),
      correctAnswer: To identify and locate devices on a network."
    })
  },

  // --- MADA: EMAIL (ADVANCED) (4 Materials) ---
  {
    id: "G8-CS-EMA-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Email (Advanced)",
    subtopic: "Adding Attachments,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "When sending an email, you can attach files like documents or images. What is the typical icon used for adding an attachment in an email client?,
      options: [A paperclip icon, A star icon", "A heart icon, An arrow icon"].sort(() => Math.random() - 0.5),
      correctAnswer: "A paperclip icon
    })
  },
  {
    id: G8-CS-EMA-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Email (Advanced),
    subtopic: "Using CC and BCC",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Email clients allow you to send a copy of a message to other recipients using the CC and BCC fields. What is the difference between CC and BCC?,
      options: [CC recipients are visible to all, while BCC recipients are hidden from other recipients., CC recipients are hidden, BCC recipients are visible., They are the same.", "CC is used for file attachments, BCC is for images.].sort(() => Math.random() - 0.5),
      correctAnswer: CC recipients are visible to all, while BCC recipients are hidden from other recipients."
    })
  },
  {
    id: "G8-CS-EMA-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Email (Advanced)",
    subtopic: "Organizing Emails into Folders,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Organizing emails into folders is an important part of managing your inbox. Why is it beneficial to create folders for your emails?,
      options: [It helps you sort, find, and manage your messages effectively., It deletes all your emails., "It increases your storage space., It prevents you from sending emails."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps you sort, find, and manage your messages effectively.
    })
  },
  {
    id: G8-CS-EMA-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Email (Advanced),
    subtopic: "Organizing Emails into Folders",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " What is the purpose of the 'Sent' folder in an email client?,
      options: [It stores copies of messages you have sent., It stores received messages., It stores drafts of emails.", "It deletes old emails.].sort(() => Math.random() - 0.5),
      correctAnswer: It stores copies of messages you have sent."
    })
  },

  // --- MADA: COMPUTER SECURITY (4 Materials) ---
  {
    id: "G8-CS-SEC-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Computer Security",
    subtopic: "Passwords,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Passwords are the first line of defense for your accounts. Which of the following is the best practice for creating a password?,
      options: [Use a long, complex mix of characters., Use your name., "Use the word 'password'., Use your birthdate."].sort(() => Math.random() - 0.5),
      correctAnswer: "Use a long, complex mix of characters.
    })
  },
  {
    id: G8-CS-SEC-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Computer Security,
    subtopic: "Firewalls",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A firewall is a network security system that monitors and controls incoming and outgoing network traffic. What is the main purpose of a firewall?,
      options: [To block unauthorized access to a network., To increase internet speed., To create new software.", "To edit files.].sort(() => Math.random() - 0.5),
      correctAnswer: To block unauthorized access to a network."
    })
  },
  {
    id: "G8-CS-SEC-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Computer Security",
    subtopic: "Antivirus Software,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Antivirus software is essential for protecting your computer. What is the main function of antivirus software?,
      options: [To detect and remove harmful software like viruses., To create new files., "To increase computer speed., To connect to the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "To detect and remove harmful software like viruses.
    })
  },
  {
    id: G8-CS-SEC-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Computer Security,
    subtopic: "Avoiding Phishing Scams",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Phishing is a fraudulent attempt to obtain sensitive information. What should you do if you receive a suspicious email asking for your password?,
      options: [Delete it and do not click any links., Reply with your password., Forward it to all your friends.", "Click the link to see what happens.].sort(() => Math.random() - 0.5),
      correctAnswer: Delete it and do not click any links."
    })
  },

  // --- MADA: DATA REPRESENTATION (4 Materials) ---
  {
    id: "G8-CS-DAT-01",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Data Representation",
    subtopic: "Binary Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Computers understand data using binary numbers. What is a binary number system?,
      options: [A system that uses only two digits: 0 and 1., A system that uses ten digits: 0 to 9., "A system that uses letters., A system that uses symbols."].sort(() => Math.random() - 0.5),
      correctAnswer: "A system that uses only two digits: 0 and 1.
    })
  },
  {
    id: G8-CS-DAT-02",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Data Representation,
    subtopic: "Bits and Bytes",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The smallest unit of data in a computer is a bit. What is a byte?,
      options: [A group of 8 bits., A group of 16 bits., A group of 32 bits.", "A group of 4 bits.].sort(() => Math.random() - 0.5),
      correctAnswer: A group of 8 bits."
    })
  },
  {
    id: "G8-CS-DAT-03",
    grade: "Grade 8",
    subject: "Computer Science",
    topic: "Data Representation",
    subtopic: "Bits and Bytes,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Computers use binary to store numbers and text. What is the binary representation of the decimal number 5?,
      options: [101, 110, "111, 100"].sort(() => Math.random() - 0.5),
      correctAnswer: "101
    })
  },
  {
    id: G8-CS-DAT-04",
    grade: "Grade 8,
    subject: Computer Science",
    topic: "Data Representation,
    subtopic: "Bits and Bytes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " If 1 byte = 8 bits, how many bits are there in 4 bytes?,
      options: [32 bits, 16 bits, 64 bits", "8 bits].sort(() => Math.random() - 0.5),
      correctAnswer: 32 bits"
    })
  }
  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: INTRODUCTION TO PROGRAMMING (5 Materials) ---
  {
    id: "G9-CS-PROG-01",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Introduction to Programming",
    subtopic: "Algorithms,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "An algorithm is a set of step-by-step instructions used to solve a problem. Which of the following is a characteristic of a good algorithm?,
      options: [It must be precise and finite., It can be infinite., "It does not need to be clear., It only works for complex problems."].sort(() => Math.random() - 0.5),
      correctAnswer: "It must be precise and finite.
    })
  },
  {
    id: G9-CS-PROG-02",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Introduction to Programming,
    subtopic: "Flowcharts",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A flowchart is a diagrammatic representation of an algorithm. What shape is used in a flowchart to indicate a decision or condition?,
      options: [A diamond shape, An oval shape, A rectangle shape", "A parallelogram shape].sort(() => Math.random() - 0.5),
      correctAnswer: A diamond shape"
    })
  },
  {
    id: "G9-CS-PROG-03",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Introduction to Programming",
    subtopic: "Pseudocode,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Pseudocode is a simplified, informal way of writing an algorithm. What is the primary purpose of using pseudocode?,
      options: [To plan and design logic before coding., To execute the program directly.", "To test the program's speed., To create the user interface."].sort(() => Math.random() - 0.5),
      correctAnswer: "To plan and design logic before coding.
    })
  },
  {
    id: G9-CS-PROG-04",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Introduction to Programming,
    subtopic: "Algorithms",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Algorithms can be expressed using natural language, pseudocode, or flowcharts. What is the advantage of using a flowchart over natural language?,
      options: [It visualizes the logic clearly and helps identify errors., It is faster to write., It uses English words.", "It can be compiled directly.].sort(() => Math.random() - 0.5),
      correctAnswer: It visualizes the logic clearly and helps identify errors."
    })
  },
  {
    id: "G9-CS-PROG-05",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Introduction to Programming",
    subtopic: "Basic Programming Concepts,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "All programming languages share common concepts. Which of the following is a fundamental building block of any program?,
      options: [Variables and data types, The monitor, "The printer, The router"].sort(() => Math.random() - 0.5),
      correctAnswer: "Variables and data types
    })
  },

  // --- MADA: PROGRAMMING BASICS (4 Materials) ---
  {
    id: G9-CS-BAS-01",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Programming Basics,
    subtopic: "Variables",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " A variable is a named memory location used to store data. In Python, which of the following is a valid variable name?,
      options: [student_age, 2nd_year, class-name", "student age].sort(() => Math.random() - 0.5),
      correctAnswer: student_age"
    })
  },
  {
    id: "G9-CS-BAS-02",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Programming Basics",
    subtopic: "Data Types,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Data types specify the type of data a variable can hold. What is the data type of the value 'Hello, World!' in Python?,
      options: [String, Integer", "Float, Boolean"].sort(() => Math.random() - 0.5),
      correctAnswer: "String
    })
  },
  {
    id: G9-CS-BAS-03",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Programming Basics,
    subtopic: "Operators",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Operators are used to perform operations on values. Which of the following is an arithmetic operator in Python?,
      options: [+, &&, ==", "!=].sort(() => Math.random() - 0.5),
      correctAnswer: +"
    })
  },
  {
    id: "G9-CS-BAS-04",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Programming Basics",
    subtopic: "Input and Output,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Most programs receive input from the user and produce output. Which Python function is used to get input from the user?,
      options: [input(), print(), "read(), scan()"].sort(() => Math.random() - 0.5),
      correctAnswer: "input()
    })
  },

  // --- MADA: CONTROL STRUCTURES (5 Materials) ---
  {
    id: G9-CS-CON-01",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Control Structures,
    subtopic: "Sequential Control",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Control structures dictate the flow of execution in a program. What is a sequence in programming?,
      options: [Statements executed one after another., A block of code that repeats., A decision-making statement.", "A loop.].sort(() => Math.random() - 0.5),
      correctAnswer: Statements executed one after another."
    })
  },
  {
    id: "G9-CS-CON-02",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Control Structures",
    subtopic: "Selection (if/else),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Selection structures allow a program to make decisions. In Python, what keyword is used to start a selection structure?,
      options: [if, for", "while, def"].sort(() => Math.random() - 0.5),
      correctAnswer: "if
    })
  },
  {
    id: G9-CS-CON-03",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Control Structures,
    subtopic: "Selection (if/else)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The else statement is used in conjunction with an if statement. What does the 'else' block do?,
      options: [It executes when the 'if' condition is false., It executes when the 'if' condition is true., It always executes.", "It ends the program.].sort(() => Math.random() - 0.5),
      correctAnswer: It executes when the 'if' condition is false."
    })
  },
  {
    id: "G9-CS-CON-04",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Control Structures",
    subtopic: "Iteration (Loops),
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Iteration allows a block of code to be repeated. Which type of loop is used when you know exactly how many times you want to repeat a block?,
      options: [For loop, While loop, "Do-while loop, Infinite loop"].sort(() => Math.random() - 0.5),
      correctAnswer: "For loop
    })
  },
  {
    id: G9-CS-CON-05",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Control Structures,
    subtopic: "Iteration (Loops)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The while loop is used when the number of iterations is not known beforehand. What condition causes a while loop to stop executing?,
      options: [When the condition becomes false., When it reaches the end of the file., After 100 iterations.", "When the user types 'stop'.].sort(() => Math.random() - 0.5),
      correctAnswer: When the condition becomes false."
    })
  },

  // --- MADA: HTML AND WEB DESIGN (5 Materials) ---
  {
    id: "G9-CS-HTML-01",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "HTML and Web Design",
    subtopic: "Structure of a Web Page,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "HTML is the standard markup language for creating web pages. What does HTML stand for?,
      options: [HyperText Markup Language, HighTech Modern Language, "HyperTool Markup Language, Home Text Markup Language"].sort(() => Math.random() - 0.5),
      correctAnswer: "HyperText Markup Language
    })
  },
  {
    id: G9-CS-HTML-02",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "HTML and Web Design,
    subtopic: "HTML Tags",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " HTML uses tags to structure content. Which tag is used to define the title of the document?,
      options: [<title>, <head>, <body>", "<h1>].sort(() => Math.random() - 0.5),
      correctAnswer: <title>"
    })
  },
  {
    id: "G9-CS-HTML-03",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "HTML and Web Design",
    subtopic: "HTML Tags,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "HTML headings are used to structure content. Which of the following represents the largest heading tag?,
      options: [<h1>, <h2>, "<h3>, <h6>"].sort(() => Math.random() - 0.5),
      correctAnswer: "<h1>
    })
  },
  {
    id: G9-CS-HTML-04",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "HTML and Web Design,
    subtopic: "HTML Tags",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " In HTML, the <p> tag is used for paragraphs. What other tags can be used to format text in HTML?,
      options: [<b> and <i>, <div> and <span>, <img> and <a>", "<head> and <body>].sort(() => Math.random() - 0.5),
      correctAnswer: <b> and <i>"
    })
  },
  {
    id: "G9-CS-HTML-05",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "HTML and Web Design",
    subtopic: "Web Page Structure,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A well-structured web page includes a <head> and a <body> section. What type of information is placed in the <head> section of an HTML document?,
      options: [Metadata, title, and links to stylesheets., The visible content of the page., "JavaScript functions., Images and videos."].sort(() => Math.random() - 0.5),
      correctAnswer: "Metadata, title, and links to stylesheets.
    })
  },

  // --- MADA: COMPUTER NETWORKS (5 Materials) ---
  {
    id: G9-CS-NET-01",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Computer Networks,
    subtopic: "Types of Networks",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Computer networks are classified by size and scope. Which network type covers a small area like a single building or classroom?,
      options: [LAN (Local Area Network), WAN (Wide Area Network), MAN (Metropolitan Area Network)", "PAN (Personal Area Network)].sort(() => Math.random() - 0.5),
      correctAnswer: LAN (Local Area Network)"
    })
  },
  {
    id: "G9-CS-NET-02",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Computer Networks",
    subtopic: "Network Topologies,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Network topology refers to the physical layout of a network. In which topology are all devices connected to a single central cable?,
      options: [Bus topology, Star topology, "Ring topology, Mesh topology"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bus topology
    })
  },
  {
    id: G9-CS-NET-03",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Computer Networks,
    subtopic: "Network Topologies",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " In a star topology, all devices connect to a central hub or switch. What is an advantage of the star topology?,
      options: [If one cable fails, only that device is affected., It uses the least amount of cable., It is the simplest to set up.", "It is the fastest.].sort(() => Math.random() - 0.5),
      correctAnswer: If one cable fails, only that device is affected."
    })
  },
  {
    id: "G9-CS-NET-04",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Computer Networks",
    subtopic: "Network Topologies,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "In a ring topology, data travels in a circular path from one device to the next. What is a disadvantage of the ring topology?,
      options: [A failure in one device can bring down the entire network., It is the most secure.", "It is the cheapest., It is the fastest."].sort(() => Math.random() - 0.5),
      correctAnswer: "A failure in one device can bring down the entire network.
    })
  },
  {
    id: G9-CS-NET-05",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Computer Networks,
    subtopic: "Network Devices",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Routers and switches are essential devices in computer networks. What is the main function of a router?,
      options: [To connect different networks and forward data packets., To connect devices within the same network., To amplify a wireless signal.", "To store data permanently.].sort(() => Math.random() - 0.5),
      correctAnswer: To connect different networks and forward data packets."
    })
  },

  // --- MADA: INTERNET CONCEPTS (5 Materials) ---
  {
    id: "G9-CS-INT-01",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Internet Concepts",
    subtopic: "Bandwidth and Broadband,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Bandwidth determines how much data can be transferred over a network in a given time. What is the main difference between broadband and narrowband?,
      options: [Broadband supports high-speed data transmission, while narrowband supports slower speeds., Broadband is for data, narrowband is for voice., "They are the same., Broadband is only for fiber cables."].sort(() => Math.random() - 0.5),
      correctAnswer: "Broadband supports high-speed data transmission, while narrowband supports slower speeds.
    })
  },
  {
    id: G9-CS-INT-02",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Internet Concepts,
    subtopic: "Mobile Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Mobile data allows users to access the internet via cellular networks. What technology is commonly used for high-speed mobile internet in Kenya?,
      options: [4G and 5G, Bluetooth, Infrared", "Wi-Fi].sort(() => Math.random() - 0.5),
      correctAnswer: 4G and 5G"
    })
  },
  {
    id: "G9-CS-INT-03",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Internet Concepts",
    subtopic: "WWW vs Internet,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The internet and the World Wide Web are often confused. What is the relationship between the internet and the World Wide Web?,
      options: [The World Wide Web is a service that runs on the internet infrastructure., They are exactly the same., "The internet is a service on the web., The web is older than the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "The World Wide Web is a service that runs on the internet infrastructure.
    })
  },
  {
    id: G9-CS-INT-04",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Internet Concepts,
    subtopic: "Internet Services",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The internet provides many services, including email, file transfer, and web browsing. Which protocol is used for transferring files over the internet?,
      options: [FTP (File Transfer Protocol), HTTP, SMTP", "DNS].sort(() => Math.random() - 0.5),
      correctAnswer: FTP (File Transfer Protocol)"
    })
  },
  {
    id: "G9-CS-INT-05",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Internet Concepts",
    subtopic: "Search Engines,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Search engines help users find information on the web by indexing web pages. What is a key factor that determines the order of search results?,
      options: [Relevance and page ranking., The length of the web page., "The color of the page., The date the page was created."].sort(() => Math.random() - 0.5),
      correctAnswer: "Relevance and page ranking.
    })
  },

  // --- MADA: SOCIAL MEDIA AND SAFETY (5 Materials) ---
  {
    id: G9-CS-SOC-01",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Social Media and Safety,
    subtopic: "Uses of Social Media",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Social media platforms have become an integral part of daily life. Which of the following is a positive use of social media?,
      options: [Sharing information and staying connected., Spreading rumors., Cyberbullying.", "Posting private information publicly.].sort(() => Math.random() - 0.5),
      correctAnswer: Sharing information and staying connected."
    })
  },
  {
    id: "G9-CS-SOC-02",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Social Media and Safety",
    subtopic: "Cyberbullying,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Cyberbullying is the use of digital technology to harass or intimidate others. What is the first step to take if you are a victim of cyberbullying?,
      options: [Block the bully and inform a trusted adult., Retaliate by posting hurtful comments., "Share your password with the bully., Ignore it and hope it stops."].sort(() => Math.random() - 0.5),
      correctAnswer: "Block the bully and inform a trusted adult.
    })
  },
  {
    id: G9-CS-SOC-03",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Social Media and Safety,
    subtopic: "Online Safety",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Online safety involves protecting your personal information from misuse. What is a best practice for sharing on social media?,
      options: [Set your profile to private and only add people you know., Share your home address and phone number., Accept friend requests from strangers.", "Post photos of your ID card.].sort(() => Math.random() - 0.5),
      correctAnswer: Set your profile to private and only add people you know."
    })
  },
  {
    id: "G9-CS-SOC-04",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Social Media and Safety",
    subtopic: "Online Safety,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the main purpose of privacy settings on social media platforms?,
      options: [To control who can see your posts and information., To allow everyone to see your data., "To make your profile public., To advertise your data to companies."].sort(() => Math.random() - 0.5),
      correctAnswer: "To control who can see your posts and information.
    })
  },
  {
    id: G9-CS-SOC-05",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Social Media and Safety,
    subtopic: "Digital Footprint",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A digital footprint is the trace of data you leave behind when using the internet. Why is it important to be mindful of your digital footprint?,
      options: [It can affect future opportunities, such as employment., It doesn't matter., It disappears automatically.", "It only matters for celebrities.].sort(() => Math.random() - 0.5),
      correctAnswer: It can affect future opportunities, such as employment."
    })
  },

  // --- MADA: DATA SECURITY (5 Materials) ---
  {
    id: "G9-CS-SEC-01",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Data Security",
    subtopic: "Encryption,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Encryption is a key technique used to protect data. What is the purpose of encryption?,
      options: [To convert readable data into an unreadable format to prevent unauthorized access., To compress data., "To delete data., To speed up the computer."].sort(() => Math.random() - 0.5),
      correctAnswer: "To convert readable data into an unreadable format to prevent unauthorized access.
    })
  },
  {
    id: G9-CS-SEC-02",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Data Security,
    subtopic: "Biometrics",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Biometric authentication uses unique physical traits to verify a person's identity. Which of the following is an example of a biometric method?,
      options: [Fingerprint scanning, Using a password, Using a PIN", "Using a security question].sort(() => Math.random() - 0.5),
      correctAnswer: Fingerprint scanning"
    })
  },
  {
    id: "G9-CS-SEC-03",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Data Security",
    subtopic: "Two-Factor Authentication,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Two-factor authentication (2FA) adds an extra layer of security. What does 2FA require in addition to a password?,
      options: [A second verification method, like a code sent to your phone., Your birthdate., "Your mother's maiden name., Your pet's name."].sort(() => Math.random() - 0.5),
      correctAnswer: "A second verification method, like a code sent to your phone.
    })
  },
  {
    id: G9-CS-SEC-04",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Data Security,
    subtopic: "Data Privacy",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Data privacy is concerned with protecting personal information from misuse. What is the GDPR?,
      options: [The General Data Protection Regulation, a law protecting data privacy., A type of software., A computer language.", "A type of CPU.].sort(() => Math.random() - 0.5),
      correctAnswer: The General Data Protection Regulation, a law protecting data privacy."
    })
  },
  {
    id: "G9-CS-SEC-05",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Data Security",
    subtopic: "Data Privacy,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is a common risk of sharing too much personal information online?,
      options: [Identity theft and data misuse., Faster internet speed., "Better search results., Higher social media engagement."].sort(() => Math.random() - 0.5),
      correctAnswer: "Identity theft and data misuse.
    })
  },

  // --- MADA: EMERGING TECHNOLOGIES (5 Materials) ---
  {
    id: G9-CS-EMG-01",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Emerging Technologies,
    subtopic: "Artificial Intelligence (AI)",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Artificial Intelligence (AI) is a field of computer science that mimics human intelligence. Which of the following is an application of AI?,
      options: [Virtual assistants like Siri and Alexa., A basic calculator., A text editor.", "An antivirus program.].sort(() => Math.random() - 0.5),
      correctAnswer: Virtual assistants like Siri and Alexa."
    })
  },
  {
    id: "G9-CS-EMG-02",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Emerging Technologies",
    subtopic: "Internet of Things (IoT),
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Internet of Things (IoT) refers to everyday objects connected to the internet. What is an example of an IoT device?,
      options: [A smart thermostat, A standard light bulb, "A book, A chair"].sort(() => Math.random() - 0.5),
      correctAnswer: "A smart thermostat
    })
  },
  {
    id: G9-CS-EMG-03",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Emerging Technologies,
    subtopic: "Cloud Computing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Cloud computing allows users to access data and services over the internet. What is a main benefit of cloud computing?,
      options: [You can access data from anywhere with an internet connection., It requires expensive hardware., It is slower than local storage.", "It only works on Windows.].sort(() => Math.random() - 0.5),
      correctAnswer: You can access data from anywhere with an internet connection."
    })
  },
  {
    id: "G9-CS-EMG-04",
    grade: "Grade 9",
    subject: "Computer Science",
    topic: "Emerging Technologies",
    subtopic: "Big Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Big data refers to extremely large datasets that can be analyzed for patterns and trends. Why is big data important for businesses?,
      options: [It helps them understand customer behavior and make better decisions., It slows down their systems., "It is not useful., It stores old files."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps them understand customer behavior and make better decisions.
    })
  },
  {
    id: G9-CS-EMG-05",
    grade: "Grade 9,
    subject: Computer Science",
    topic: "Emerging Technologies,
    subtopic: "Machine Learning",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Machine learning is a subset of AI that enables computers to learn from data without explicit programming. What is a real-world application of machine learning?,
      options: [Recommendation systems on Netflix and YouTube., A simple calculator., A word processor.", "A firewall.].sort(() => Math.random() - 0.5),
      correctAnswer: Recommendation systems on Netflix and YouTube."
    })
  },

  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: ADVANCED PROGRAMMING (4 Materials) ---
  {
    id: "G10-CS-ADV-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Advanced Programming",
    subtopic: "Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Functions are reusable blocks of code that perform a specific task. In Python, which keyword is used to define a function?,
      options: [def, function", "void, return"].sort(() => Math.random() - 0.5),
      correctAnswer: "def
    })
  },
  {
    id: G10-CS-ADV-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Advanced Programming,
    subtopic: "Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A function can accept input values called parameters. What is the difference between a parameter and an argument?,
      options: [Parameters are defined in the function, while arguments are the values passed to it., They are the same., Arguments are defined in the function.", "Parameters are passed to the function.].sort(() => Math.random() - 0.5),
      correctAnswer: Parameters are defined in the function, while arguments are the values passed to it."
    })
  },
  {
    id: "G10-CS-ADV-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Advanced Programming",
    subtopic: "Lists and Arrays,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Lists are used to store multiple values in a single variable. In Python, what is the index of the first element in a list?,
      options: [0, 1", "-1, None"].sort(() => Math.random() - 0.5),
      correctAnswer: "0
    })
  },
  {
    id: G10-CS-ADV-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Advanced Programming,
    subtopic: "File Handling",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " File handling allows a program to read from or write to files. Which Python function is used to open a file for reading?,
      options: [open('file.txt', 'r'), read('file.txt'), file('file.txt')", "open('file.txt', 'w')].sort(() => Math.random() - 0.5),
      correctAnswer: open('file.txt', 'r')"
    })
  },

  // --- MADA: OOP CONCEPTS (4 Materials) ---
  {
    id: "G10-CS-OOP-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "OOP Concepts",
    subtopic: "Classes and Objects,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Object-Oriented Programming (OOP) is a programming paradigm based on the concept of objects. What is a class in OOP?,
      options: [A blueprint for creating objects., A specific instance of an object., "A type of variable., A function."].sort(() => Math.random() - 0.5),
      correctAnswer: "A blueprint for creating objects.
    })
  },
  {
    id: G10-CS-OOP-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "OOP Concepts,
    subtopic: "Classes and Objects",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " In OOP, an object is a specific instance of a class. What are the two main elements of a class?,
      options: [Attributes (data) and methods (functions)., Variables and constants., Loops and conditions.", "Functions and modules.].sort(() => Math.random() - 0.5),
      correctAnswer: Attributes (data) and methods (functions)."
    })
  },
  {
    id: "G10-CS-OOP-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "OOP Concepts",
    subtopic: "Inheritance,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Inheritance allows a class to inherit properties and methods from another class. What is the purpose of inheritance in OOP?,
      options: [To promote code reuse., To delete attributes., "To hide data., To create variables."].sort(() => Math.random() - 0.5),
      correctAnswer: "To promote code reuse.
    })
  },
  {
    id: G10-CS-OOP-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "OOP Concepts,
    subtopic: "Polymorphism",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Polymorphism means 'many forms' and allows objects of different classes to be treated as objects of a common superclass. What is an example of polymorphism?,
      options: [A single method that behaves differently depending on the object calling it., A method that does nothing., A method that only works with numbers.", "A method that deletes data.].sort(() => Math.random() - 0.5),
      correctAnswer: A single method that behaves differently depending on the object calling it."
    })
  },

  // --- MADA: DATABASE MANAGEMENT (4 Materials) ---
  {
    id: "G10-CS-DB-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Database Management",
    subtopic: "SQL Introduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "SQL (Structured Query Language) is used to manage and manipulate relational databases. What command is used to retrieve data from a database table?,
      options: [SELECT, INSERT, "UPDATE, DELETE"].sort(() => Math.random() - 0.5),
      correctAnswer: "SELECT
    })
  },
  {
    id: G10-CS-DB-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Database Management,
    subtopic: "SQL Introduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The WHERE clause is used to filter records in SQL. What does the following SQL statement do? 'SELECT * FROM Students WHERE Grade = 'A'',
      options: [It retrieves only the students with a grade of 'A'., It deletes students with grade 'A'., It updates students with grade 'A'.", "It inserts a new student.].sort(() => Math.random() - 0.5),
      correctAnswer: It retrieves only the students with a grade of 'A'."
    })
  },
  {
    id: "G10-CS-DB-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Database Management",
    subtopic: "SQL Introduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "SQL commands can be used to modify data in a database. Which SQL command is used to add new records to a table?,
      options: [INSERT INTO, SELECT, "UPDATE, DELETE"].sort(() => Math.random() - 0.5),
      correctAnswer: "INSERT INTO
    })
  },
  {
    id: G10-CS-DB-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Database Management,
    subtopic: "SQL Introduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The UPDATE command is used to modify existing records in a database. Which clause should always be used with an UPDATE statement?,
      options: [WHERE, SELECT, INSERT", "DELETE].sort(() => Math.random() - 0.5),
      correctAnswer: WHERE"
    })
  },

  // --- MADA: SYSTEM DEVELOPMENT LIFE CYCLE (4 Materials) ---
  {
    id: "G10-CS-SDLC-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "System Development Life Cycle",
    subtopic: "Phases of SDLC,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The System Development Life Cycle (SDLC) is a process used to develop information systems. What is the first phase of the SDLC?,
      options: [Planning and Analysis, Design, "Implementation, Maintenance"].sort(() => Math.random() - 0.5),
      correctAnswer: "Planning and Analysis
    })
  },
  {
    id: G10-CS-SDLC-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "System Development Life Cycle,
    subtopic: "Phases of SDLC",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " In the SDLC, the design phase involves creating the architecture and specifications for the system. What is an output of the design phase?,
      options: [A system design document., The actual code., A user manual.", "A maintenance plan.].sort(() => Math.random() - 0.5),
      correctAnswer: A system design document."
    })
  },
  {
    id: "G10-CS-SDLC-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "System Development Life Cycle",
    subtopic: "Phases of SDLC,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The implementation phase involves writing the actual code. What is the final phase of the SDLC before the system is released?,
      options: [Testing, Design, "Analysis, Planning"].sort(() => Math.random() - 0.5),
      correctAnswer: "Testing
    })
  },
  {
    id: G10-CS-SDLC-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "System Development Life Cycle,
    subtopic: "Phases of SDLC",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The SDLC is often represented as a Waterfall model. What is the main disadvantage of the Waterfall model?,
      options: [It is difficult to return to a previous phase once completed., It is too fast., It involves too many users.", "It is fully flexible.].sort(() => Math.random() - 0.5),
      correctAnswer: It is difficult to return to a previous phase once completed."
    })
  },

  // --- MADA: WEB DEVELOPMENT (4 Materials) ---
  {
    id: "G10-CS-WEB-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Web Development",
    subtopic: "CSS Introduction,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "CSS (Cascading Style Sheets) is used to style web pages. What does CSS control?,
      options: [The layout, colors, and fonts of a web page., The structure of the page., "The data stored on the server., The page's title."].sort(() => Math.random() - 0.5),
      correctAnswer: "The layout, colors, and fonts of a web page.
    })
  },
  {
    id: G10-CS-WEB-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Web Development,
    subtopic: "CSS Introduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " CSS uses selectors to target HTML elements. Which CSS selector is used to target an element by its ID?,
      options: [#id, .class, *", "element].sort(() => Math.random() - 0.5),
      correctAnswer: #id"
    })
  },
  {
    id: "G10-CS-WEB-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Web Development",
    subtopic: "JavaScript Basics,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "JavaScript is a scripting language used to add interactivity to web pages. Where is JavaScript code typically placed in an HTML document?,
      options: [Inside <script> tags in the <head> or at the end of the <body>., Inside <style> tags., "Inside <link> tags., Inside <meta> tags."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inside <script> tags in the <head> or at the end of the <body>.
    })
  },
  {
    id: G10-CS-WEB-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Web Development,
    subtopic: "JavaScript Basics",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " JavaScript uses events to respond to user actions. Which event is triggered when a user clicks on an HTML element?,
      options: [onclick, onload, onmouseover", "onkeydown].sort(() => Math.random() - 0.5),
      correctAnswer: onclick"
    })
  },

  // --- MADA: COMPUTER NETWORKS (OSI AND TCP/IP) (4 Materials) ---
  {
    id: "G10-CS-NET-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Computer Networks",
    subtopic: "The OSI Model,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The OSI model is a conceptual framework for understanding network communication. How many layers are there in the OSI model?,
      options: [7 layers, 5 layers, "4 layers, 6 layers"].sort(() => Math.random() - 0.5),
      correctAnswer: "7 layers
    })
  },
  {
    id: G10-CS-NET-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Computer Networks,
    subtopic: "The OSI Model",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The transport layer is responsible for reliable data transfer. Which protocol operates at the transport layer?,
      options: [TCP (Transmission Control Protocol), IP (Internet Protocol), HTTP (HyperText Transfer Protocol)", "FTP (File Transfer Protocol)].sort(() => Math.random() - 0.5),
      correctAnswer: TCP (Transmission Control Protocol)"
    })
  },
  {
    id: "G10-CS-NET-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Computer Networks",
    subtopic: "The TCP/IP Model,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The TCP/IP model is the suite of protocols used on the internet. How many layers are there in the TCP/IP model?,
      options: [4 layers, 7 layers, "5 layers, 6 layers"].sort(() => Math.random() - 0.5),
      correctAnswer: "4 layers
    })
  },
  {
    id: G10-CS-NET-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Computer Networks,
    subtopic: "The TCP/IP Model",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The application layer in the TCP/IP model handles high-level protocols. Which of the following is a protocol at the application layer?,
      options: [HTTP (HyperText Transfer Protocol), TCP, IP", "ICMP].sort(() => Math.random() - 0.5),
      correctAnswer: HTTP (HyperText Transfer Protocol)"
    })
  },

  // --- MADA: CYBERSECURITY (4 Materials) ---
  {
    id: "G10-CS-SEC-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Cybersecurity",
    subtopic: "Types of Malware,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Malware is a broad category of malicious software. Which type of malware replicates itself and spreads to other computers?,
      options: [A virus, A Trojan horse, "Spyware, Ransomware"].sort(() => Math.random() - 0.5),
      correctAnswer: "A virus
    })
  },
  {
    id: G10-CS-SEC-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Cybersecurity,
    subtopic: "Phishing",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Phishing attacks attempt to deceive users into revealing sensitive information. What should you do if you receive a suspicious email?,
      options: [Do not click any links and report it as spam., Reply with your password., Forward it to your contacts.", "Click the link to see what it does.].sort(() => Math.random() - 0.5),
      correctAnswer: Do not click any links and report it as spam."
    })
  },
  {
    id: "G10-CS-SEC-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Cybersecurity",
    subtopic: "Ransomware,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ransomware is a type of malware that encrypts a user's files and demands payment for their release. What is the best defense against ransomware?,
      options: [Regular backups and strong security practices., Paying the ransom., "Ignoring the problem., Deleting the files."].sort(() => Math.random() - 0.5),
      correctAnswer: "Regular backups and strong security practices.
    })
  },
  {
    id: G10-CS-SEC-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Cybersecurity,
    subtopic: "Prevention Strategies",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Preventing cyber attacks involves a combination of strategies. Which of the following is a key preventive measure?,
      options: [Using strong passwords, enabling 2FA, and keeping software updated., Sharing your password with friends., Disabling firewalls.", "Using the same password for all accounts.].sort(() => Math.random() - 0.5),
      correctAnswer: Using strong passwords, enabling 2FA, and keeping software updated."
    })
  },

  // --- MADA: NETWORK ADMINISTRATION (4 Materials) ---
  {
    id: "G10-CS-ADM-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Network Administration",
    subtopic: "IP Addressing,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Network administrators manage IP addresses to connect devices. What is the difference between a static IP and a dynamic IP?,
      options: [A static IP does not change, while a dynamic IP can change., A static IP changes often, while a dynamic IP is permanent., "They are the same., A static IP is for phones, a dynamic IP is for computers."].sort(() => Math.random() - 0.5),
      correctAnswer: "A static IP does not change, while a dynamic IP can change.
    })
  },
  {
    id: G10-CS-ADM-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Network Administration,
    subtopic: "Subnetting",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Subnetting is the practice of dividing a network into smaller, more manageable subnetworks. What is a primary benefit of subnetting?,
      options: [It improves network performance and security., It slows down the network., It creates more IP addresses.", "It removes the need for routers.].sort(() => Math.random() - 0.5),
      correctAnswer: It improves network performance and security."
    })
  },
  {
    id: "G10-CS-ADM-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Network Administration",
    subtopic: "DNS and DHCP,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "DNS and DHCP are two critical services for network administration. What is the primary function of DNS?,
      options: [To translate domain names into IP addresses., To assign dynamic IP addresses to devices., "To route packets., To encrypt data."].sort(() => Math.random() - 0.5),
      correctAnswer: "To translate domain names into IP addresses.
    })
  },
  {
    id: G10-CS-ADM-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Network Administration,
    subtopic: "DNS and DHCP",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " DHCP stands for Dynamic Host Configuration Protocol. What is its main purpose?,
      options: [To assign IP addresses to devices automatically., To translate domain names., To secure network traffic.", "To manage databases.].sort(() => Math.random() - 0.5),
      correctAnswer: To assign IP addresses to devices automatically."
    })
  },

  // --- MADA: ETHICAL HACKING (4 Materials) ---
  {
    id: "G10-CS-HACK-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Ethical Hacking",
    subtopic: "White Hat vs Black Hat,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Ethical hacking is the practice of using hacking skills to improve security. What is the difference between a white hat and a black hat hacker?,
      options: [A white hat is ethical and uses skills to protect systems, while a black hat is unethical and hacks for malicious purposes., They are the same., "A white hat hacks for money, a black hat for fun., A white hat is unethical, a black hat is ethical."].sort(() => Math.random() - 0.5),
      correctAnswer: "A white hat is ethical and uses skills to protect systems, while a black hat is unethical and hacks for malicious purposes.
    })
  },
  {
    id: G10-CS-HACK-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Ethical Hacking,
    subtopic: "White Hat vs Black Hat",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ethical hackers often use penetration testing to find vulnerabilities. What is penetration testing?,
      options: [Simulated cyber attacks to identify security weaknesses., Testing the speed of the network., Installing antivirus software.", "Deleting files to free up space.].sort(() => Math.random() - 0.5),
      correctAnswer: Simulated cyber attacks to identify security weaknesses."
    })
  },
  {
    id: "G10-CS-HACK-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Ethical Hacking",
    subtopic: "Grey Hat Hacking,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Grey hat hackers fall between white hats and black hats. They may hack without permission but without malicious intent. What is the risk of grey hat hacking?,
      options: [They may break laws even if their intentions are good., They are always legal., "They are always unethical., They are harmless."].sort(() => Math.random() - 0.5),
      correctAnswer: "They may break laws even if their intentions are good.
    })
  },
  {
    id: G10-CS-HACK-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Ethical Hacking,
    subtopic: "Ethical Hacking",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ethical hackers are in high demand in the cybersecurity industry. What is a key responsibility of an ethical hacker?,
      options: [To report vulnerabilities to the organization to help fix them., To exploit vulnerabilities for personal gain., To sell vulnerabilities to other hackers.", "To ignore security issues.].sort(() => Math.random() - 0.5),
      correctAnswer: To report vulnerabilities to the organization to help fix them."
    })
  },

  // --- MADA: DIGITAL FORENSICS (4 Materials) ---
  {
    id: "G10-CS-FOR-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Digital Forensics",
    subtopic: "Gathering Digital Evidence,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Digital forensics involves the investigation of digital evidence to solve crimes. What is the first step in a digital forensics investigation?,
      options: [Securing and preserving the digital evidence., Analyzing the data., "Writing a report., Forming a hypothesis."].sort(() => Math.random() - 0.5),
      correctAnswer: "Securing and preserving the digital evidence.
    })
  },
  {
    id: G10-CS-FOR-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Digital Forensics,
    subtopic: "Gathering Digital Evidence",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A forensic image is a bit-by-bit copy of a storage device. Why do forensic investigators use forensic images rather than standard file copies?,
      options: [It preserves metadata and deleted files., It is faster., It uses less storage space.", "It is easier to transfer.].sort(() => Math.random() - 0.5),
      correctAnswer: It preserves metadata and deleted files."
    })
  },
  {
    id: "G10-CS-FOR-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "Digital Forensics",
    subtopic: "Analyzing Digital Evidence,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Forensic analysis involves examining digital evidence to find clues. What should investigators consider when examining digital evidence?,
      options: [The integrity and chain of custody of the evidence., The color of the device., "The age of the device., The brand of the device."].sort(() => Math.random() - 0.5),
      correctAnswer: "The integrity and chain of custody of the evidence.
    })
  },
  {
    id: G10-CS-FOR-04",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "Digital Forensics,
    subtopic: "Analyzing Digital Evidence",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Digital forensics is used in both criminal and corporate investigations. What is a common reason for a corporate digital forensics investigation?,
      options: [To investigate data breaches or employee misconduct., To test the network speed., To install new software.", "To create a backup.].sort(() => Math.random() - 0.5),
      correctAnswer: To investigate data breaches or employee misconduct."
    })
  },

  // --- MADA: E-COMMERCE (3 Materials) ---
  {
    id: "G10-CS-ECO-01",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "E-Commerce",
    subtopic: "Introduction to E-Commerce,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "E-commerce refers to the buying and selling of goods and services over the internet. What is the main advantage of e-commerce?,
      options: [Convenience and global reach., Limited availability., "Slow transactions., Higher costs."].sort(() => Math.random() - 0.5),
      correctAnswer: "Convenience and global reach.
    })
  },
  {
    id: G10-CS-ECO-02",
    grade: "Grade 10,
    subject: Computer Science",
    topic: "E-Commerce,
    subtopic: "Introduction to E-Commerce",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " E-commerce is commonly classified by the participants in the transaction. What does B2B stand for?,
      options: [Business to Business, Business to Consumer, Consumer to Business", "Consumer to Consumer].sort(() => Math.random() - 0.5),
      correctAnswer: Business to Business"
    })
  },
  {
    id: "G10-CS-ECO-03",
    grade: "Grade 10",
    subject: "Computer Science",
    topic: "E-Commerce",
    subtopic: "Security in E-Commerce,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Security is a major concern in e-commerce. Which technology is commonly used to secure online transactions?,
      options: [SSL/TLS encryption, FTP, "HTTP, Telnet"].sort(() => Math.random() - 0.5),
      correctAnswer: "SSL/TLS encryption
    })
  }
  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: ADVANCED PROGRAMMING (4 Materials) ---
  {
    id: G11-CS-ADV-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Advanced Programming,
    subtopic: "Recursion",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Recursion is a programming technique where a function calls itself. What is a common problem that is best solved using recursion?,
      options: [Calculating factorial of a number., Sorting an array., Finding the maximum in a list.", "Opening a file.].sort(() => Math.random() - 0.5),
      correctAnswer: Calculating factorial of a number."
    })
  },
  {
    id: "G11-CS-ADV-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Advanced Programming",
    subtopic: "2D Arrays,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "2D arrays are used to represent data in a grid format, like a table. Which of the following is a common use of a 2D array?,
      options: [Storing a chessboard or a matrix., Storing a list of names.", "Storing a single number., Storing a string of text."].sort(() => Math.random() - 0.5),
      correctAnswer: "Storing a chessboard or a matrix.
    })
  },
  {
    id: G11-CS-ADV-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Advanced Programming,
    subtopic: "File Handling (CSV)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " CSV (Comma-Separated Values) is a common file format for storing tabular data. How can you read a CSV file in Python?,
      options: [Using the 'csv' module or pandas library., Using the 'os' module., Using the 'sys' module.", "Using the 'math' module.].sort(() => Math.random() - 0.5),
      correctAnswer: Using the 'csv' module or pandas library."
    })
  },
  {
    id: "G11-CS-ADV-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Advanced Programming",
    subtopic: "File Handling (JSON),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "JSON (JavaScript Object Notation) is a lightweight data interchange format. Which Python library is used to work with JSON data?,
      options: [json, csv, "os, math"].sort(() => Math.random() - 0.5),
      correctAnswer: "json
    })
  },

  // --- MADA: DATA STRUCTURES (4 Materials) ---
  {
    id: G11-CS-DS-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Data Structures,
    subtopic: "Stacks",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A stack is a linear data structure that follows the LIFO (Last In, First Out) principle. Which operation is used to remove an element from the top of the stack?,
      options: [Pop, Push, Peek", "IsEmpty].sort(() => Math.random() - 0.5),
      correctAnswer: Pop"
    })
  },
  {
    id: "G11-CS-DS-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Data Structures",
    subtopic: "Queues,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A queue is a linear data structure that follows the FIFO (First In, First Out) principle. Which operation is used to add an element to the back of the queue?,
      options: [Enqueue, Dequeue", "Peek, IsFull"].sort(() => Math.random() - 0.5),
      correctAnswer: "Enqueue
    })
  },
  {
    id: G11-CS-DS-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Data Structures,
    subtopic: "Linked Lists",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A linked list is a linear data structure where each element points to the next. What is an advantage of a linked list over an array?,
      options: [It can grow or shrink dynamically., It uses less memory., It is faster to access elements.", "It cannot store data.].sort(() => Math.random() - 0.5),
      correctAnswer: It can grow or shrink dynamically."
    })
  },
  {
    id: "G11-CS-DS-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Data Structures",
    subtopic: "Trees,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A tree is a hierarchical data structure with a root node and child nodes. What is a common application of a binary tree?,
      options: [Binary Search Trees (BST) for efficient searching., Storing a list of names., "Calculating averages., Reading files."].sort(() => Math.random() - 0.5),
      correctAnswer: "Binary Search Trees (BST) for efficient searching.
    })
  },

  // --- MADA: ALGORITHMS (4 Materials) ---
  {
    id: G11-CS-ALG-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Algorithms,
    subtopic: "Sorting Algorithms (Bubble Sort)",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Bubble sort is a simple sorting algorithm that repeatedly steps through the list, comparing adjacent elements. What is the time complexity of bubble sort in the worst case?,
      options: [O(n²), O(n log n), O(n)", "O(1)].sort(() => Math.random() - 0.5),
      correctAnswer: O(n²)"
    })
  },
  {
    id: "G11-CS-ALG-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Algorithms",
    subtopic: "Sorting Algorithms (Merge Sort),
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Merge sort is a divide-and-conquer algorithm that recursively divides the list into halves. What is the time complexity of merge sort?,
      options: [O(n log n), O(n²), "O(n), O(1)"].sort(() => Math.random() - 0.5),
      correctAnswer: "O(n log n)
    })
  },
  {
    id: G11-CS-ALG-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Algorithms,
    subtopic: "Sorting Algorithms (Quick Sort)",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Quick sort is another divide-and-conquer algorithm that uses a pivot element. In the worst case, what is the time complexity of quick sort?,
      options: [O(n²), O(n log n), O(n)", "O(1)].sort(() => Math.random() - 0.5),
      correctAnswer: O(n²)"
    })
  },
  {
    id: "G11-CS-ALG-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Algorithms",
    subtopic: "Searching Algorithms,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Binary search is an efficient algorithm for finding an element in a sorted list. What is the time complexity of binary search?,
      options: [O(log n), O(n), "O(n log n), O(n²)"].sort(() => Math.random() - 0.5),
      correctAnswer: "O(log n)
    })
  },

  // --- MADA: SOFTWARE ENGINEERING (4 Materials) ---
  {
    id: G11-CS-SE-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Software Engineering,
    subtopic: "Agile Methodology",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Agile methodology is a popular approach to software development. What is a key principle of Agile?,
      options: [Iterative development and responding to change., A strict, linear process with no changes., Focusing only on documentation.", "Avoiding customer feedback.].sort(() => Math.random() - 0.5),
      correctAnswer: Iterative development and responding to change."
    })
  },
  {
    id: "G11-CS-SE-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Software Engineering",
    subtopic: "Testing (Unit and Integration),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Testing is a critical phase in software engineering. What is the difference between unit testing and integration testing?,
      options: [Unit testing checks individual components, while integration testing checks how components work together., They are the same., "Unit testing is done at the end, integration testing is done at the beginning., Unit testing is for web apps, integration testing is for mobile apps."].sort(() => Math.random() - 0.5),
      correctAnswer: "Unit testing checks individual components, while integration testing checks how components work together.
    })
  },
  {
    id: G11-CS-SE-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Software Engineering,
    subtopic: "Waterfall Model",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The Waterfall model is a traditional, sequential approach to software development. What is a major disadvantage of the Waterfall model?,
      options: [It is difficult to make changes once a phase is completed., It is too flexible., It is too fast.", "It involves too many users.].sort(() => Math.random() - 0.5),
      correctAnswer: It is difficult to make changes once a phase is completed."
    })
  },
  {
    id: "G11-CS-SE-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Software Engineering",
    subtopic: "Testing (System),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "System testing is performed on the complete, integrated system. What is the main goal of system testing?,
      options: [To verify that the system meets its requirements., To test individual functions.", "To test the user interface., To test the database."].sort(() => Math.random() - 0.5),
      correctAnswer: "To verify that the system meets its requirements.
    })
  },

  // --- MADA: ADVANCED WEB DEVELOPMENT (4 Materials) ---
  {
    id: G11-CS-WEB-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Advanced Web Development,
    subtopic: "Responsive Design",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Responsive web design ensures that web pages look good on all devices. Which CSS technique is used to make a layout responsive?,
      options: [Media queries, Float, Position: absolute", "Display: block].sort(() => Math.random() - 0.5),
      correctAnswer: Media queries"
    })
  },
  {
    id: "G11-CS-WEB-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Advanced Web Development",
    subtopic: "JavaScript Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "JavaScript events are actions that can be detected by the browser. Which event triggers when a user clicks an HTML element?,
      options: [onclick, onload, "onmouseover, onkeydown"].sort(() => Math.random() - 0.5),
      correctAnswer: "onclick
    })
  },
  {
    id: G11-CS-WEB-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Advanced Web Development,
    subtopic: "DOM Manipulation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " DOM manipulation allows JavaScript to interact with HTML elements. Which method is used to select an element by its ID?,
      options: [document.getElementById(), document.getElementsByClassName(), document.querySelector()", "document.getElementsByTagName()].sort(() => Math.random() - 0.5),
      correctAnswer: document.getElementById()"
    })
  },
  {
    id: "G11-CS-WEB-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Advanced Web Development",
    subtopic: "DOM Manipulation,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "JavaScript can also add new elements to the DOM. Which method is used to create a new HTML element?,
      options: [document.createElement(), document.getElementById(), "document.querySelector(), document.removeChild()"].sort(() => Math.random() - 0.5),
      correctAnswer: "document.createElement()
    })
  },

  // --- MADA: DATABASE MANAGEMENT (4 Materials) ---
  {
    id: G11-CS-DB-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Database Management,
    subtopic: "Normalization (1NF)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Normalization is used to reduce data redundancy and improve data integrity. What is the first normal form (1NF)?,
      options: [Each table cell must contain a single atomic value., The table must have a primary key., There must be no transitive dependencies.", "All non-key attributes must depend on the primary key.].sort(() => Math.random() - 0.5),
      correctAnswer: Each table cell must contain a single atomic value."
    })
  },
  {
    id: "G11-CS-DB-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Database Management",
    subtopic: "Normalization (2NF and 3NF),
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Second normal form (2NF) builds on 1NF. What additional condition must a table meet to be in 2NF?,
      options: [It must have no partial dependencies on a composite primary key., It must have no transitive dependencies., "Every table cell must contain a single value., It must have a foreign key."].sort(() => Math.random() - 0.5),
      correctAnswer: "It must have no partial dependencies on a composite primary key.
    })
  },
  {
    id: G11-CS-DB-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Database Management,
    subtopic: "Normalization (3NF)",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Third normal form (3NF) eliminates transitive dependencies. What is a transitive dependency?,
      options: [A non-key attribute that depends on another non-key attribute., A dependency between two key attributes., A dependency between a primary key and a non-key attribute.", "A dependency between foreign keys.].sort(() => Math.random() - 0.5),
      correctAnswer: A non-key attribute that depends on another non-key attribute."
    })
  },
  {
    id: "G11-CS-DB-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Database Management",
    subtopic: "Table Relationships,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Tables in a relational database are linked through relationships. Which relationship allows a single record in one table to be associated with many records in another table?,
      options: [One-to-Many, One-to-One, "Many-to-Many, None of the above"].sort(() => Math.random() - 0.5),
      correctAnswer: "One-to-Many
    })
  },

  // --- MADA: COMPUTER SECURITY (4 Materials) ---
  {
    id: G11-CS-SEC-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Computer Security,
    subtopic: "Cryptography",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Cryptography is the practice of securing information through encryption. Which of the following is an example of symmetric encryption?,
      options: [AES (Advanced Encryption Standard), RSA (Rivest-Shamir-Adleman), ECC (Elliptic Curve Cryptography)", "DSA (Digital Signature Algorithm)].sort(() => Math.random() - 0.5),
      correctAnswer: AES (Advanced Encryption Standard)"
    })
  },
  {
    id: "G11-CS-SEC-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Computer Security",
    subtopic: "Cryptography,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Asymmetric encryption uses two keys: a public key and a private key. What is the primary use of asymmetric encryption?,
      options: [Key exchange and digital signatures., Symmetric encryption., "Hashing., Data compression."].sort(() => Math.random() - 0.5),
      correctAnswer: "Key exchange and digital signatures.
    })
  },
  {
    id: G11-CS-SEC-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Computer Security,
    subtopic: "Digital Signatures",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Digital signatures are used to verify the authenticity and integrity of digital messages. What technology is used to create a digital signature?,
      options: [Asymmetric encryption (RSA, ECC)., Symmetric encryption (AES)., Hashing alone.", "Compression.].sort(() => Math.random() - 0.5),
      correctAnswer: Asymmetric encryption (RSA, ECC)."
    })
  },
  {
    id: "G11-CS-SEC-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Computer Security",
    subtopic: "Digital Certificates,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Digital certificates are used to verify the identity of a website or entity. What is the role of a Certificate Authority (CA)?,
      options: [To issue and manage digital certificates., To encrypt data., "To create passwords., To design software."].sort(() => Math.random() - 0.5),
      correctAnswer: "To issue and manage digital certificates.
    })
  },

  // --- MADA: VIRTUALIZATION AND CLOUD COMPUTING (4 Materials) ---
  {
    id: G11-CS-VIR-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Virtualization and Cloud Computing,
    subtopic: "Virtual Machines",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A virtual machine (VM) is a software emulation of a physical computer. What is the primary purpose of virtualization?,
      options: [To run multiple operating systems on a single physical machine., To speed up the computer., To replace the operating system.", "To delete files.].sort(() => Math.random() - 0.5),
      correctAnswer: To run multiple operating systems on a single physical machine."
    })
  },
  {
    id: "G11-CS-VIR-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Virtualization and Cloud Computing",
    subtopic: "Hypervisors,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A hypervisor is the software that creates and manages virtual machines. Which of the following is a type of hypervisor?,
      options: [Type 1 (bare-metal) and Type 2 (hosted)., Type A and Type B., "Type X and Type Y., Type Alpha and Type Beta."].sort(() => Math.random() - 0.5),
      correctAnswer: "Type 1 (bare-metal) and Type 2 (hosted).
    })
  },
  {
    id: G11-CS-VIR-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Virtualization and Cloud Computing,
    subtopic: "Cloud Service Models",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Cloud computing services are categorized into three main models. What does SaaS stand for?,
      options: [Software as a Service, Systems as a Service, Security as a Service", "Storage as a Service].sort(() => Math.random() - 0.5),
      correctAnswer: Software as a Service"
    })
  },
  {
    id: "G11-CS-VIR-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Virtualization and Cloud Computing",
    subtopic: "Cloud Service Models,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "IaaS (Infrastructure as a Service) and PaaS (Platform as a Service) are other cloud models. What is the main difference between IaaS and PaaS?,
      options: [IaaS provides virtualized hardware, while PaaS provides a platform for developing applications., They are the same., "PaaS provides hardware, IaaS provides a platform., IaaS is for storage, PaaS is for computing."].sort(() => Math.random() - 0.5),
      correctAnswer: "IaaS provides virtualized hardware, while PaaS provides a platform for developing applications.
    })
  },

  // --- MADA: ETHICS IN IT (4 Materials) ---
  {
    id: G11-CS-ETH-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Ethics in IT,
    subtopic: "Professional Codes of Conduct",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " IT professionals are expected to follow ethical guidelines and codes of conduct. What is a key principle in the ACM Code of Ethics?,
      options: [Act in the public interest and protect the privacy of users., Maximize profits for the company., Share all data publicly.", "Ignore user complaints.].sort(() => Math.random() - 0.5),
      correctAnswer: Act in the public interest and protect the privacy of users."
    })
  },
  {
    id: "G11-CS-ETH-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Ethics in IT",
    subtopic: "Copyright and Intellectual Property,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Copyright law protects the ownership of creative works. Which of the following is a violation of copyright law?,
      options: [Unauthorized sharing or copying of software., Using open-source software legally., "Purchasing a legitimate license., Reading the documentation."].sort(() => Math.random() - 0.5),
      correctAnswer: "Unauthorized sharing or copying of software.
    })
  },
  {
    id: G11-CS-ETH-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Ethics in IT,
    subtopic: "Software Piracy",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Software piracy is the unauthorized copying, distribution, or use of software. Why is software piracy harmful to the industry?,
      options: [It deprives developers of revenue and stifles innovation., It helps developers., It is a victimless crime.", "It makes software cheaper.].sort(() => Math.random() - 0.5),
      correctAnswer: It deprives developers of revenue and stifles innovation."
    })
  },
  {
    id: "G11-CS-ETH-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Ethics in IT",
    subtopic: "Intellectual Property,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Intellectual property refers to creations of the mind, such as inventions and software. How can a company protect its intellectual property?,
      options: [Through patents, copyrights, and trademarks., By keeping it a secret.", "By sharing it publicly., By using it only once."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through patents, copyrights, and trademarks.
    })
  },

  // --- MADA: ARTIFICIAL INTELLIGENCE (4 Materials) ---
  {
    id: G11-CS-AI-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Artificial Intelligence,
    subtopic: "Neural Networks",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Neural networks are computing systems inspired by the human brain. Which of the following is a key component of a neural network?,
      options: [Neurons, layers, and weights., A database., A text editor.", "A web browser.].sort(() => Math.random() - 0.5),
      correctAnswer: Neurons, layers, and weights."
    })
  },
  {
    id: "G11-CS-AI-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Artificial Intelligence",
    subtopic: "Machine Learning,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Machine learning is a subset of AI where systems learn from data. What are the three main types of machine learning?,
      options: [Supervised, unsupervised, and reinforcement learning., Fast, slow, and medium learning., "Static, dynamic, and interactive learning., Linear, quadratic, and exponential learning."].sort(() => Math.random() - 0.5),
      correctAnswer: "Supervised, unsupervised, and reinforcement learning.
    })
  },
  {
    id: G11-CS-AI-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Artificial Intelligence,
    subtopic: "NLP (Natural Language Processing)",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Natural Language Processing (NLP) is a branch of AI focused on human-computer interaction. What is an application of NLP?,
      options: [Language translation and sentiment analysis., Calculating numbers., Drawing graphics.", "Playing music.].sort(() => Math.random() - 0.5),
      correctAnswer: Language translation and sentiment analysis."
    })
  },
  {
    id: "G11-CS-AI-04",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Artificial Intelligence",
    subtopic: "Neural Networks,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Deep learning uses multi-layered neural networks to analyze complex data. What is a real-world application of deep learning?,
      options: [Image and speech recognition., Simple arithmetic., "Text editing., Browsing the web."].sort(() => Math.random() - 0.5),
      correctAnswer: "Image and speech recognition.
    })
  },

  // --- MADA: DATA ANALYTICS (3 Materials) ---
  {
    id: G11-CS-DAT-01",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Data Analytics,
    subtopic: "Big Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Big data refers to extremely large datasets that require special techniques to process. What is one of the main challenges of big data?,
      options: [Storing, processing, and analyzing the data efficiently., Finding enough data., Deleting old data.", "Making data smaller.].sort(() => Math.random() - 0.5),
      correctAnswer: Storing, processing, and analyzing the data efficiently."
    })
  },
  {
    id: "G11-CS-DAT-02",
    grade: "Grade 11",
    subject: "Computer Science",
    topic: "Data Analytics",
    subtopic: "Data Mining,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Data mining is the process of discovering patterns in large datasets. What is a common application of data mining?,
      options: [Market basket analysis (finding products often bought together)., Calculating averages., "Sorting data., Creating a new database."].sort(() => Math.random() - 0.5),
      correctAnswer: "Market basket analysis (finding products often bought together).
    })
  },
  {
    id: G11-CS-DAT-03",
    grade: "Grade 11,
    subject: Computer Science",
    topic: "Data Analytics,
    subtopic: "Data Visualization",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Data visualization involves presenting data in graphical formats to make it easier to understand. What is a popular tool for data visualization?,
      options: [Tableau, Microsoft Word, Excel (basic tables only)", "Notepad].sort(() => Math.random() - 0.5),
      correctAnswer: Tableau"
    })
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD COMPUTER SCIENCE SYLLABUS)
  // =========================================================================

  // --- MADA: DATA STRUCTURES (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-DS-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Data Structures (Advanced)",
    subtopic: "Stacks and Queues (Applications),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Stacks and queues are fundamental data structures used in many applications. Which application uses a stack to manage function calls?,
      options: [The call stack in programming languages., Managing print jobs., "Storing browser history., A queue for network packets."].sort(() => Math.random() - 0.5),
      correctAnswer: "The call stack in programming languages.
    })
  },
  {
    id: G12-CS-DS-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Data Structures (Advanced),
    subtopic: "Linked Lists (Implementation)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A linked list can be singly linked or doubly linked. What is the main difference between a singly linked list and a doubly linked list?,
      options: [A doubly linked list has pointers to both the next and previous nodes, while a singly linked list only points to the next node., They are the same., A singly linked list is faster.", "A doubly linked list uses less memory.].sort(() => Math.random() - 0.5),
      correctAnswer: A doubly linked list has pointers to both the next and previous nodes, while a singly linked list only points to the next node."
    })
  },
  {
    id: "G12-CS-DS-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Data Structures (Advanced)",
    subtopic: "Trees (Binary Trees),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A binary tree is a tree where each node has at most two children. What is a Binary Search Tree (BST)?,
      options: [A binary tree where the left child is less than the parent and the right child is greater., A tree with only one child., "A tree with no children., A tree that is not organized."].sort(() => Math.random() - 0.5),
      correctAnswer: "A binary tree where the left child is less than the parent and the right child is greater.
    })
  },
  {
    id: G12-CS-DS-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Data Structures (Advanced),
    subtopic: "Graphs",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A graph is a data structure consisting of nodes (vertices) and edges. What is the difference between a directed and an undirected graph?,
      options: [A directed graph has edges with a direction, while an undirected graph has edges without direction., They are the same., A directed graph has no edges.", "An undirected graph has only one node.].sort(() => Math.random() - 0.5),
      correctAnswer: A directed graph has edges with a direction, while an undirected graph has edges without direction."
    })
  },

  // --- MADA: ALGORITHMS (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-ALG-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Algorithms (Advanced)",
    subtopic: "Recursion,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Recursion is a technique where a function calls itself to solve a problem. What is a base case in recursion?,
      options: [A condition that stops the recursion., The first recursive call., "The last recursive call., An infinite loop."].sort(() => Math.random() - 0.5),
      correctAnswer: "A condition that stops the recursion.
    })
  },
  {
    id: G12-CS-ALG-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Algorithms (Advanced),
    subtopic: "Sorting Algorithms (Merge Sort)",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Merge sort is a divide-and-conquer algorithm that is efficient for sorting large datasets. What is the time complexity of merge sort in the worst case?,
      options: [O(n log n), O(n²), O(n)", "O(1)].sort(() => Math.random() - 0.5),
      correctAnswer: O(n log n)"
    })
  },
  {
    id: "G12-CS-ALG-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Algorithms (Advanced)",
    subtopic: "Searching Algorithms (Binary Search),
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Binary search is a highly efficient search algorithm for sorted data. What is a prerequisite for using binary search?,
      options: [The data must be sorted., The data must be unsorted., "The data must be large., The data must be small."].sort(() => Math.random() - 0.5),
      correctAnswer: "The data must be sorted.
    })
  },
  {
    id: G12-CS-ALG-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Algorithms (Advanced),
    subtopic: "Searching Algorithms (Linear Search)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Linear search is a simple search algorithm that checks each element in a list. When is linear search preferred over binary search?,
      options: [When the list is small or unsorted., When the list is large., When the list is sorted.", "When the list is empty.].sort(() => Math.random() - 0.5),
      correctAnswer: When the list is small or unsorted."
    })
  },

  // --- MADA: SOFTWARE ENGINEERING (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-SE-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Software Engineering (Advanced)",
    subtopic: "SDLC (Planning and Analysis),
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The SDLC (Software Development Life Cycle) is a process for building software. What is the purpose of the planning and analysis phase?,
      options: [To define the scope, objectives, and requirements of the project., To write the actual code., "To test the software., To maintain the software."].sort(() => Math.random() - 0.5),
      correctAnswer: "To define the scope, objectives, and requirements of the project.
    })
  },
  {
    id: G12-CS-SE-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Software Engineering (Advanced),
    subtopic: "SDLC (Implementation and Testing)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The implementation phase is where the software is actually built. What is the goal of the testing phase in the SDLC?,
      options: [To identify and fix bugs before release., To create the user manual., To design the user interface.", "To plan the project.].sort(() => Math.random() - 0.5),
      correctAnswer: To identify and fix bugs before release."
    })
  },
  {
    id: "G12-CS-SE-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Software Engineering (Advanced)",
    subtopic: "SDLC (Maintenance),
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The final phase of the SDLC is maintenance. What does the maintenance phase involve?,
      options: [Updating and supporting the software after its release., Writing the first draft., "Designing the software., Planning the project."].sort(() => Math.random() - 0.5),
      correctAnswer: "Updating and supporting the software after its release.
    })
  },
  {
    id: G12-CS-SE-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Software Engineering (Advanced),
    subtopic: "Waterfall vs Agile",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Agile and Waterfall are two common software development methodologies. Which methodology is more suitable for projects with rapidly changing requirements?,
      options: [Agile, Waterfall, Both", "Neither].sort(() => Math.random() - 0.5),
      correctAnswer: Agile"
    })
  },

  // --- MADA: ADVANCED WEB DEVELOPMENT (4 Materials) ---
  {
    id: "G12-CS-WEB-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Advanced Web Development",
    subtopic: "HTML5 and CSS3,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "HTML5 and CSS3 are the latest versions of the core web technologies. What is the key difference between HTML and CSS?,
      options: [HTML defines the structure of the page, while CSS defines the layout and styling., HTML defines the layout, CSS defines the structure., "They are the same., HTML is for design, CSS is for content."].sort(() => Math.random() - 0.5),
      correctAnswer: "HTML defines the structure of the page, while CSS defines the layout and styling.
    })
  },
  {
    id: G12-CS-WEB-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Advanced Web Development,
    subtopic: "JavaScript and DOM Manipulation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " JavaScript is used to add interactivity to web pages. What does DOM stand for in web development?,
      options: [Document Object Model, Document Object Module, Data Object Model", "Digital Object Model].sort(() => Math.random() - 0.5),
      correctAnswer: Document Object Model"
    })
  },
  {
    id: "G12-CS-WEB-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Advanced Web Development",
    subtopic: "JavaScript APIs,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "JavaScript can interact with browser APIs to access device features. Which API is used to get a user's current location?,
      options: [Geolocation API, Web Storage API, "Canvas API, Fetch API"].sort(() => Math.random() - 0.5),
      correctAnswer: "Geolocation API
    })
  },
  {
    id: G12-CS-WEB-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Advanced Web Development,
    subtopic: "Web APIs and JSON",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Web APIs allow websites to interact with external services. What format is commonly used to send and receive data from Web APIs?,
      options: [JSON (JavaScript Object Notation), XML, CSV", "HTML].sort(() => Math.random() - 0.5),
      correctAnswer: JSON (JavaScript Object Notation)"
    })
  },

  // --- MADA: DATABASE MANAGEMENT (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-DB-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Database Management (Advanced)",
    subtopic: "SQL Joins,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "SQL joins are used to combine rows from two or more tables. Which join returns all records when there is a match in either table?,
      options: [FULL OUTER JOIN, INNER JOIN, "LEFT JOIN, RIGHT JOIN"].sort(() => Math.random() - 0.5),
      correctAnswer: "FULL OUTER JOIN
    })
  },
  {
    id: G12-CS-DB-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Database Management (Advanced),
    subtopic: "SQL Joins",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " An INNER JOIN returns only records that have matching values in both tables. What is the main difference between an INNER JOIN and a LEFT JOIN?,
      options: [A LEFT JOIN returns all records from the left table, even if there is no match., An INNER JOIN returns all records from both tables., A LEFT JOIN is the same as an INNER JOIN.", "An INNER JOIN only works with one table.].sort(() => Math.random() - 0.5),
      correctAnswer: A LEFT JOIN returns all records from the left table, even if there is no match."
    })
  },
  {
    id: "G12-CS-DB-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Database Management (Advanced)",
    subtopic: "SQL Aggregation,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "SQL aggregate functions are used to perform calculations on data. Which function is used to count the number of rows in a table?,
      options: [COUNT(), SUM(), "AVG(), MAX()"].sort(() => Math.random() - 0.5),
      correctAnswer: "COUNT()
    })
  },
  {
    id: G12-CS-DB-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Database Management (Advanced),
    subtopic: "SQL Aggregation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The GROUP BY clause is used with aggregate functions to group results. What does the following SQL statement do? SELECT COUNT(*), Grade FROM Students GROUP BY Grade,
      options: [It counts the number of students in each grade., It counts the total number of students., It deletes students.", "It updates grades.].sort(() => Math.random() - 0.5),
      correctAnswer: It counts the number of students in each grade."
    })
  },

  // --- MADA: CYBERSECURITY (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-SEC-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Cybersecurity (Advanced)",
    subtopic: "Security Policies,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Security policies define the rules and procedures for protecting an organization's assets. What is the purpose of an Acceptable Use Policy (AUP)?,
      options: [To outline the rules for how employees may use company resources., To create a new password., "To set up a firewall., To install antivirus software."].sort(() => Math.random() - 0.5),
      correctAnswer: "To outline the rules for how employees may use company resources.
    })
  },
  {
    id: G12-CS-SEC-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Cybersecurity (Advanced),
    subtopic: "Incident Response",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Incident response is a structured approach to handling security breaches. What is the first step in an incident response plan?,
      options: [Preparation and detection., Containment., Eradication.", "Recovery.].sort(() => Math.random() - 0.5),
      correctAnswer: Preparation and detection."
    })
  },
  {
    id: "G12-CS-SEC-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Cybersecurity (Advanced)",
    subtopic: "Incident Response,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "After a security incident is contained and eradicated, the final step is recovery. What does the recovery phase involve?,
      options: [Restoring systems and returning to normal operations., Detecting the incident.", "Preventing the incident., Analyzing the incident."].sort(() => Math.random() - 0.5),
      correctAnswer: "Restoring systems and returning to normal operations.
    })
  },
  {
    id: G12-CS-SEC-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Cybersecurity (Advanced),
    subtopic: "Security Threats",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Organizations face a wide range of security threats today. Which of the following is a common security threat to both individuals and businesses?,
      options: [Phishing attacks, Low internet speed, Outdated hardware", "Poor web design].sort(() => Math.random() - 0.5),
      correctAnswer: Phishing attacks"
    })
  },

  // --- MADA: NETWORK ADMINISTRATION (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-NET-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Network Administration (Advanced)",
    subtopic: "IP Addressing and Subnetting,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Subnetting is the practice of dividing a network into smaller subnetworks. What is the purpose of a subnet mask?,
      options: [To identify which part of an IP address is the network address and which part is the host address., To make the network faster., "To encrypt data., To connect to the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "To identify which part of an IP address is the network address and which part is the host address.
    })
  },
  {
    id: G12-CS-NET-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Network Administration (Advanced),
    subtopic: "VLANs",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A VLAN (Virtual Local Area Network) is a logical grouping of devices on a network. What is one benefit of using VLANs?,
      options: [They improve network security and reduce broadcast traffic., They make the network physically larger., They remove the need for switches.", "They replace routers.].sort(() => Math.random() - 0.5),
      correctAnswer: They improve network security and reduce broadcast traffic."
    })
  },
  {
    id: "G12-CS-NET-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Network Administration (Advanced)",
    subtopic: "DNS and DHCP,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "DNS and DHCP are essential services for network administration. What is the main purpose of DNS (Domain Name System)?,
      options: [To translate human-readable domain names into IP addresses., To assign IP addresses dynamically., "To encrypt network traffic., To manage user passwords."].sort(() => Math.random() - 0.5),
      correctAnswer: "To translate human-readable domain names into IP addresses.
    })
  },
  {
    id: G12-CS-NET-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Network Administration (Advanced),
    subtopic: "DHCP",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " DHCP (Dynamic Host Configuration Protocol) automates the assignment of IP addresses. What is a benefit of using DHCP?,
      options: [It reduces the administrative burden of manual IP configuration., It slows down the network., It increases security risks.", "It makes IP addresses permanent.].sort(() => Math.random() - 0.5),
      correctAnswer: It reduces the administrative burden of manual IP configuration."
    })
  },

  // --- MADA: CLOUD COMPUTING (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-CLD-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Cloud Computing (Advanced)",
    subtopic: "Cloud Deployment Models,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Cloud computing offers several deployment models. What is a public cloud?,
      options: [A cloud infrastructure shared by multiple organizations, accessible over the internet., A cloud used by a single organization., "A cloud that is physically on-premises., A cloud that is not connected to the internet."].sort(() => Math.random() - 0.5),
      correctAnswer: "A cloud infrastructure shared by multiple organizations, accessible over the internet.
    })
  },
  {
    id: G12-CS-CLD-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Cloud Computing (Advanced),
    subtopic: "Cloud Deployment Models",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A private cloud is dedicated to a single organization. What is the main benefit of a private cloud compared to a public cloud?,
      options: [Greater control, security, and privacy., Lower cost., Faster speed.", "Global accessibility.].sort(() => Math.random() - 0.5),
      correctAnswer: Greater control, security, and privacy."
    })
  },
  {
    id: "G12-CS-CLD-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Cloud Computing (Advanced)",
    subtopic: "Virtualization,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Virtualization is the foundation of cloud computing. What is the role of a hypervisor in a virtualized environment?,
      options: [It manages and runs the virtual machines., It creates the network., "It stores data., It encrypts data."].sort(() => Math.random() - 0.5),
      correctAnswer: "It manages and runs the virtual machines.
    })
  },
  {
    id: G12-CS-CLD-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Cloud Computing (Advanced),
    subtopic: "Cloud Service Models",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " IaaS, PaaS, and SaaS are the three main cloud service models. What is the main difference between IaaS and PaaS?,
      options: [IaaS provides virtualized hardware, while PaaS provides a platform for developing applications., They are the same., PaaS provides hardware, IaaS provides a platform.", "IaaS is for storage, PaaS is for computing.].sort(() => Math.random() - 0.5),
      correctAnswer: IaaS provides virtualized hardware, while PaaS provides a platform for developing applications."
    })
  },

  // --- MADA: ETHICS IN IT (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-ETH-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Ethics in IT (Advanced)",
    subtopic: "Ethical Dilemmas,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "IT professionals often face ethical dilemmas. Which of the following is an example of an ethical dilemma in IT?,
      options: [The conflict between user privacy and data monitoring., Choosing a font color., "Deciding which computer to buy., Updating the operating system."].sort(() => Math.random() - 0.5),
      correctAnswer: "The conflict between user privacy and data monitoring.
    })
  },
  {
    id: G12-CS-ETH-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Ethics in IT (Advanced),
    subtopic: "Artificial Intelligence Ethics",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The ethics of Artificial Intelligence is a growing concern. What is an ethical issue associated with AI?,
      options: [Bias in AI algorithms and job displacement., Too much data storage., Slow processing speeds.", "High electricity consumption.].sort(() => Math.random() - 0.5),
      correctAnswer: Bias in AI algorithms and job displacement."
    })
  },
  {
    id: "G12-CS-ETH-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Ethics in IT (Advanced)",
    subtopic: "Intellectual Property,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Intellectual property laws protect inventions and creative works. What is a patent?,
      options: [A legal protection for an invention., A legal protection for a book., "A legal protection for a song., A legal protection for a company."].sort(() => Math.random() - 0.5),
      correctAnswer: "A legal protection for an invention.
    })
  },
  {
    id: G12-CS-ETH-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Ethics in IT (Advanced),
    subtopic: "Professional Responsibility",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " IT professionals have a responsibility to uphold ethical standards. What should an IT professional do if they discover a security vulnerability?,
      options: [Report it responsibly to the organization or users., Ignore it., Exploit it for personal gain.", "Share it publicly immediately.].sort(() => Math.random() - 0.5),
      correctAnswer: Report it responsibly to the organization or users."
    })
  },

  // --- MADA: EMERGING TECHNOLOGIES (ADVANCED) (4 Materials) ---
  {
    id: "G12-CS-EMG-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Emerging Technologies (Advanced)",
    subtopic: "Blockchain,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Blockchain technology is a decentralized digital ledger that records transactions. What is the main feature of blockchain that ensures security?,
      options: [Its decentralized, immutable, and cryptographic nature., Its speed., "Its simplicity., Its low cost."].sort(() => Math.random() - 0.5),
      correctAnswer: "Its decentralized, immutable, and cryptographic nature.
    })
  },
  {
    id: G12-CS-EMG-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Emerging Technologies (Advanced),
    subtopic: "Cryptocurrencies",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Cryptocurrencies like Bitcoin use blockchain technology. What is a major advantage of cryptocurrencies?,
      options: [Decentralization and lower transaction fees., High transaction fees., Government control.", "Physical coins.].sort(() => Math.random() - 0.5),
      correctAnswer: Decentralization and lower transaction fees."
    })
  },
  {
    id: "G12-CS-EMG-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Emerging Technologies (Advanced)",
    subtopic: "Quantum Computing,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Quantum computing is an emerging technology that uses quantum bits (qubits) to process information. What is a potential application of quantum computing?,
      options: [Solving complex problems faster, such as cryptography and drug discovery., Word processing., "Browsing the internet., Playing simple games."].sort(() => Math.random() - 0.5),
      correctAnswer: "Solving complex problems faster, such as cryptography and drug discovery.
    })
  },
  {
    id: G12-CS-EMG-04",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Emerging Technologies (Advanced),
    subtopic: "Emerging Technologies",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Emerging technologies like AI, IoT, and blockchain are transforming industries. What is the role of governments and organizations in adopting these technologies?,
      options: [They must establish ethical guidelines and invest in infrastructure., They should ignore them., They should ban them.", "They should only use them for profit.].sort(() => Math.random() - 0.5),
      correctAnswer: They must establish ethical guidelines and invest in infrastructure."
    })
  },

  // --- MADA: DATA ANALYTICS (ADVANCED) (3 Materials) ---
  {
    id: "G12-CS-DAT-01",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Data Analytics (Advanced)",
    subtopic: "Business Intelligence,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Business intelligence (BI) involves tools and strategies for analyzing business data. What is the primary goal of business intelligence?,
      options: [To help organizations make better data-driven decisions., To delete all data., "To make data private., To slow down the system."].sort(() => Math.random() - 0.5),
      correctAnswer: "To help organizations make better data-driven decisions.
    })
  },
  {
    id: G12-CS-DAT-02",
    grade: "Grade 12,
    subject: Computer Science",
    topic: "Data Analytics (Advanced),
    subtopic: "Data Visualization (Advanced)",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Data visualization is the graphical representation of data to communicate insights. What is an advantage of using dashboards in business analytics?,
      options: [They provide a real-time, visual snapshot of key performance indicators (KPIs)., They are hard to use., They only show static data.", "They are not useful.].sort(() => Math.random() - 0.5),
      correctAnswer: They provide a real-time, visual snapshot of key performance indicators (KPIs)."
    })
  },
  {
    id: "G12-CS-DAT-03",
    grade: "Grade 12",
    subject: "Computer Science",
    topic: "Data Analytics (Advanced)",
    subtopic: "Data Storytelling,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Data storytelling is the practice of communicating data insights through narrative and visuals. Why is data storytelling important?,
      options: [It makes complex data understandable and actionable for decision-makers., It is only for entertainment., "It is only for scientists., It is not necessary."].sort(() => Math.random() - 0.5),
      correctAnswer: "It makes complex data understandable and actionable for decision-makers."
    })
  }

];


