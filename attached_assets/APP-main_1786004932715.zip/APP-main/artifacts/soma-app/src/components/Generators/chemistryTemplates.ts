export const chemistryTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD CHEMISTRY SYLLABUS)
  // =========================================================================

  // --- MADA: INTRODUCTION TO CHEMISTRY (4 Materials) ---
  {
    id: "G10-CHE-INT-01",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Introduction to Chemistry",
    subtopic: "The Scientific Method",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: "Chemistry is the branch of science that studies the composition, structure, and properties of matter. What is the very first step in the scientific method?,
      options: ["Making an observation about the natural world., Forming a hypothesis.", "Conducting an experiment., Drawing a conclusion."].sort(() => Math.random() - 0.5),
      correctAnswer: "Making an observation about the natural world.
    })
  },
  {
    id: G10-CHE-INT-02",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Introduction to Chemistry,
    subtopic: "Laboratory Safety and Apparatus",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Safety is paramount in a chemistry laboratory. Which of the following is a mandatory safety measure when heating a liquid in a test tube?,
      options: [Pointing the test tube away from yourself and others., Looking directly into the test tube., Holding the test tube with bare hands.", "Wearing shorts and open-toed shoes.].sort(() => Math.random() - 0.5),
      correctAnswer: Pointing the test tube away from yourself and others."
    })
  },
  {
    id: "G10-CHE-INT-03",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Introduction to Chemistry",
    subtopic: "Separation Techniques,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Mixtures can be separated using various physical techniques. Which technique would be best used to separate a mixture of salt and water?,
      options: [Distillation, Filtration, "Magnetic separation, Decantation"].sort(() => Math.random() - 0.5),
      correctAnswer: "Distillation
    })
  },
  {
    id: G10-CHE-INT-04",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Introduction to Chemistry,
    subtopic: "Separation Techniques",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Paper chromatography is used to separate mixtures based on the differences in how substances move along a paper. What is the mobile phase in paper chromatography?,
      options: [The liquid solvent that moves up the paper., The paper itself., The solid mixture being separated.", "The beaker.].sort(() => Math.random() - 0.5),
      correctAnswer: The liquid solvent that moves up the paper."
    })
  },

  // --- MADA: ATOMIC STRUCTURE (5 Materials) ---
  {
    id: "G10-CHE-ATO-01",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Atomic Structure",
    subtopic: "Subatomic Particles,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "An atom is composed of three main subatomic particles. Which of these particles has no electrical charge?,
      options: [Neutron, Proton, "Electron, Positron"].sort(() => Math.random() - 0.5),
      correctAnswer: "Neutron
    })
  },
  {
    id: G10-CHE-ATO-02",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Atomic Structure,
    subtopic: "Subatomic Particles",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The atomic number of an element is equal to the number of protons in its nucleus. What is the atomic number of an atom that has 12 protons, 12 neutrons, and 12 electrons?,
      options: [12, 24, 36", "0].sort(() => Math.random() - 0.5),
      correctAnswer: 12"
    })
  },
  {
    id: "G10-CHE-ATO-03",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Atomic Structure",
    subtopic: "Mass Number,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The mass number of an atom is the total number of protons and neutrons in its nucleus. What is the mass number of a carbon atom with 6 protons and 6 neutrons?,
      options: [12, 6, "18, 24"].sort(() => Math.random() - 0.5),
      correctAnswer: "12
    })
  },
  {
    id: G10-CHE-ATO-04",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Atomic Structure,
    subtopic: "Isotopes",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Isotopes are atoms of the same element that have the same number of protons but different numbers of neutrons. Which of the following represents a pair of isotopes?,
      options: [Carbon-12 and Carbon-14, Oxygen-16 and Nitrogen-14, Hydrogen-1 and Helium-4", "Lithium-7 and Beryllium-9].sort(() => Math.random() - 0.5),
      correctAnswer: Carbon-12 and Carbon-14"
    })
  },
  {
    id: "G10-CHE-ATO-05",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Atomic Structure",
    subtopic: "Electronic Configuration,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Electrons are arranged in shells or energy levels around the nucleus. Which electron shell can hold a maximum of 8 electrons?,
      options: [The second shell (L-shell), The first shell (K-shell), "The third shell (M-shell), The fourth shell (N-shell)"].sort(() => Math.random() - 0.5),
      correctAnswer: "The second shell (L-shell)
    })
  },

  // --- MADA: CHEMICAL BONDING (4 Materials) ---
  {
    id: G10-CHE-BON-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Bonding,
    subtopic: "Ionic Bonding",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Ionic bonds are formed by the transfer of electrons from a metal to a non-metal. Which of the following compounds is formed by ionic bonding?,
      options: [Sodium chloride (NaCl), Water (H₂O), Carbon dioxide (CO₂)", "Methane (CH₄)].sort(() => Math.random() - 0.5),
      correctAnswer: Sodium chloride (NaCl)"
    })
  },
  {
    id: "G10-CHE-BON-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Chemical Bonding",
    subtopic: "Covalent Bonding,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Covalent bonds are formed by the sharing of electrons between non-metals. Which of the following molecules is held together by covalent bonds?,
      options: [Hydrogen gas (H₂), Potassium bromide (KBr), "Magnesium oxide (MgO), Iron (Fe)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hydrogen gas (H₂)
    })
  },
  {
    id: G10-CHE-BON-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Bonding,
    subtopic: "Properties of Ionic Compounds",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Ionic compounds have distinct physical properties due to their strong ionic bonds. Which of the following is a characteristic property of an ionic compound?,
      options: [They have high melting and boiling points., They are soft and easily deformed., They are poor conductors of electricity when dissolved in water.", "They have low melting points.].sort(() => Math.random() - 0.5),
      correctAnswer: They have high melting and boiling points."
    })
  },
  {
    id: "G10-CHE-BON-04",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Chemical Bonding",
    subtopic: "Properties of Covalent Compounds,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Covalent compounds typically have different properties from ionic compounds. Which of the following is a typical property of simple covalent compounds?,
      options: [They have low melting and boiling points., They are hard and brittle., "They conduct electricity when dissolved in water., They have high melting points."].sort(() => Math.random() - 0.5),
      correctAnswer: "They have low melting and boiling points.
    })
  },

  // --- MADA: CHEMICAL EQUATIONS (4 Materials) ---
  {
    id: G10-CHE-EQU-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Equations,
    subtopic: "Writing Chemical Equations",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " A chemical equation is a shorthand representation of a chemical reaction. What do the symbols (s), (l), (g), and (aq) represent in a chemical equation?,
      options: [Solid, liquid, gas, and aqueous (dissolved in water)., Strong, light, good, and average., Solution, liquid, gas, and acid.", "Sodium, lithium, gold, and aqua.].sort(() => Math.random() - 0.5),
      correctAnswer: Solid, liquid, gas, and aqueous (dissolved in water)."
    })
  },
  {
    id: "G10-CHE-EQU-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Chemical Equations",
    subtopic: "Balancing Chemical Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A chemical equation must be balanced to satisfy the Law of Conservation of Mass. What is the balanced equation for the reaction between hydrogen and oxygen to form water?,
      options: [2H₂ + O₂ → 2H₂O, H₂ + O₂ → H₂O, "H₂ + O₂ → 2H₂O, 2H₂ + 2O₂ → 2H₂O"].sort(() => Math.random() - 0.5),
      correctAnswer: "2H₂ + O₂ → 2H₂O
    })
  },
  {
    id: G10-CHE-EQU-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Equations,
    subtopic: "Types of Chemical Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " A combustion reaction involves a substance reacting rapidly with oxygen to produce heat and light. Which of the following is a combustion reaction?,
      options: [CH₄ + 2O₂ → CO₂ + 2H₂O, CaCO₃ → CaO + CO₂, NaCl + AgNO₃ → AgCl + NaNO₃", "Fe + CuSO₄ → FeSO₄ + Cu].sort(() => Math.random() - 0.5),
      correctAnswer: CH₄ + 2O₂ → CO₂ + 2H₂O"
    })
  },
  {
    id: "G10-CHE-EQU-04",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Chemical Equations",
    subtopic: "Types of Chemical Reactions,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "A decomposition reaction is one where a single compound breaks down into two or more simpler substances. Which of the following is a decomposition reaction?,
      options: [2HgO → 2Hg + O₂, Mg + 2HCl → MgCl₂ + H₂, "2H₂ + O₂ → 2H₂O, NaOH + HCl → NaCl + H₂O"].sort(() => Math.random() - 0.5),
      correctAnswer: "2HgO → 2Hg + O₂
    })
  },

  // --- MADA: STOICHIOMETRY (4 Materials) ---
  {
    id: G10-CHE-STO-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Stoichiometry,
    subtopic: "The Mole Concept",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Stoichiometry deals with the quantitative relationships in chemical reactions. What is the definition of one mole of a substance?,
      options: [The amount of substance that contains Avogadro's number of particles., The mass of 1 liter of the substance., The volume of 1 mole of gas at STP.", "The number of atoms in 12 grams of carbon-12.].sort(() => Math.random() - 0.5),
      correctAnswer: The amount of substance that contains Avogadro's number of particles."
    })
  },
  {
    id: "G10-CHE-STO-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Stoichiometry",
    subtopic: "Molar Mass,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Molar mass is the mass of one mole of a substance. What is the molar mass of water (H₂O)? (Atomic masses: H = 1, O = 16),
      options: [18 g/mol, 16 g/mol", "20 g/mol, 14 g/mol"].sort(() => Math.random() - 0.5),
      correctAnswer: "18 g/mol
    })
  },
  {
    id: G10-CHE-STO-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Stoichiometry,
    subtopic: "Simple Molar Calculations",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " How many moles are present in 4 grams of helium gas (He)? (Molar mass of He = 4 g/mol),
      options: [1 mole, 2 moles, 0.5 moles", "4 moles].sort(() => Math.random() - 0.5),
      correctAnswer: 1 mole"
    })
  },
  {
    id: "G10-CHE-STO-04",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Stoichiometry",
    subtopic: "Stoichiometric Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In the reaction 2Mg + O₂ → 2MgO, how many moles of magnesium oxide (MgO) are produced from 2 moles of magnesium (Mg)?,
      options: [2 moles, 1 mole", "4 moles, 3 moles"].sort(() => Math.random() - 0.5),
      correctAnswer: "2 moles
    })
  },

  // --- MADA: ACIDS, BASES, AND SALTS (4 Materials) ---
  {
    id: G10-CHE-ACID-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Acids, Bases, and Salts,
    subtopic: "Properties of Acids",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Acids are a common group of chemicals with distinctive properties. Which of the following is a characteristic property of acids?,
      options: [They have a sour taste and turn blue litmus red., They have a bitter taste and turn red litmus blue., They are slippery to touch.", "They have a pH greater than 7.].sort(() => Math.random() - 0.5),
      correctAnswer: They have a sour taste and turn blue litmus red."
    })
  },
  {
    id: "G10-CHE-ACID-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Acids", Bases, and Salts",
    subtopic: "Properties of Bases,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Bases are substances that neutralize acids. Which of the following is a common property of bases?,
      options: [They have a bitter taste and feel slippery., They have a sour taste., "They turn blue litmus red., They have a pH less than 7."].sort(() => Math.random() - 0.5),
      correctAnswer: "They have a bitter taste and feel slippery.
    })
  },
  {
    id: G10-CHE-ACID-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Acids, Bases, and Salts,
    subtopic: "The pH Scale",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The pH scale is used to measure the acidity or alkalinity of a solution. What pH value would indicate a neutral solution?,
      options: [7, 0, 14", "1].sort(() => Math.random() - 0.5),
      correctAnswer: 7"
    })
  },
  {
    id: "G10-CHE-ACID-04",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Acids", Bases, and Salts",
    subtopic: "Neutralization Reactions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A neutralization reaction occurs when an acid and a base react to form a salt and water. What is the salt formed when hydrochloric acid (HCl) reacts with sodium hydroxide (NaOH)?,
      options: [Sodium chloride (NaCl), Sodium carbonate (Na₂CO₃), "Calcium chloride (CaCl₂), Sodium sulfate (Na₂SO₄)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sodium chloride (NaCl)
    })
  },

  // --- MADA: STRUCTURE AND PROPERTIES OF MATTER (4 Materials) ---
  {
    id: G10-CHE-STR-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Structure and Properties of Matter,
    subtopic: "States of Matter",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Matter exists in three main states: solid, liquid, and gas. Which state has a definite shape and volume?,
      options: [Solid, Liquid, Gas", "Plasma].sort(() => Math.random() - 0.5),
      correctAnswer: Solid"
    })
  },
  {
    id: "G10-CHE-STR-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Structure and Properties of Matter",
    subtopic: "Changes of State,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Matter can change state when energy is added or removed. What is the name of the process where a liquid changes into a gas at its boiling point?,
      options: [Evaporation, Melting, "Condensation, Freezing"].sort(() => Math.random() - 0.5),
      correctAnswer: "Evaporation
    })
  },
  {
    id: G10-CHE-STR-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Structure and Properties of Matter,
    subtopic: "Changes of State",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " When a solid changes directly into a gas without passing through the liquid state, the process is called sublimation. Which substance is known to undergo sublimation at room temperature?,
      options: [Dry ice (solid CO₂), Water ice, Salt", "Sugar].sort(() => Math.random() - 0.5),
      correctAnswer: Dry ice (solid CO₂)"
    })
  },
  {
    id: "G10-CHE-STR-04",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Structure and Properties of Matter",
    subtopic: "Solutions,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "A solution is a homogeneous mixture of a solute dissolved in a solvent. In a sugar-water solution, which substance is the solvent?,
      options: [Water, Sugar", "Sucrose, Glucose"].sort(() => Math.random() - 0.5),
      correctAnswer: "Water
    })
  },

  // --- MADA: CHEMICAL REACTIONS (3 Materials) ---
  {
    id: G10-CHE-REA-01",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Reactions,
    subtopic: "Displacement Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A displacement reaction involves a more reactive element replacing a less reactive element from its compound. Which metal will displace copper from copper sulfate solution?,
      options: [Zinc, Silver, Gold", "Platinum].sort(() => Math.random() - 0.5),
      correctAnswer: Zinc"
    })
  },
  {
    id: "G10-CHE-REA-02",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Chemical Reactions",
    subtopic: "Decomposition Reactions,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "A decomposition reaction breaks down a compound into simpler substances. Which compound decomposes to produce calcium oxide and carbon dioxide when heated?,
      options: [Calcium carbonate (CaCO₃), Sodium chloride (NaCl), "Potassium nitrate (KNO₃), Copper sulfate (CuSO₄)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Calcium carbonate (CaCO₃)
    })
  },
  {
    id: G10-CHE-REA-03",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Chemical Reactions,
    subtopic: "Combination Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " A combination reaction is where two or more reactants combine to form a single product. What is the product when sulfur combines with oxygen to form sulfur dioxide?,
      options: [SO₂, SO₃, H₂SO₄", "SO].sort(() => Math.random() - 0.5),
      correctAnswer: SO₂"
    })
  },

  // --- MADA: WATER AND SOLUTIONS (3 Materials) ---
  {
    id: "G10-CHE-WAT-01",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Water and Solutions",
    subtopic: "Properties of Water,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Water is a unique compound with many essential properties for life. What property of water allows it to dissolve a wide variety of substances?,
      options: [Its polarity, Its high boiling point, "Its low density, Its color"].sort(() => Math.random() - 0.5),
      correctAnswer: "Its polarity
    })
  },
  {
    id: G10-CHE-WAT-02",
    grade: "Grade 10,
    subject: Chemistry",
    topic: "Water and Solutions,
    subtopic: "Solubility",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Solubility refers to the maximum amount of solute that can dissolve in a given amount of solvent at a specific temperature. What generally happens to the solubility of most solids as temperature increases?,
      options: [It increases., It decreases., It stays the same.", "It fluctuates randomly.].sort(() => Math.random() - 0.5),
      correctAnswer: It increases."
    })
  },
  {
    id: "G10-CHE-WAT-03",
    grade: "Grade 10",
    subject: "Chemistry",
    topic: "Water and Solutions",
    subtopic: "Factors Affecting Solubility,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Several factors affect the rate at which a solute dissolves in a solvent. Which of the following would increase the rate of dissolving a solid solute?,
      options: [Stirring the mixture, Lowering the temperature, "Increasing the particle size of the solute, Decreasing the surface area"].sort(() => Math.random() - 0.5),
      correctAnswer: "Stirring the mixture
    })
  },

  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD CHEMISTRY SYLLABUS)
  // =========================================================================

  // --- MADA: ATOMIC STRUCTURE AND PERIODICITY (5 Materials) ---
  {
    id: G11-CHE-ATO-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Atomic Structure and Periodicity,
    subtopic: "Electron Configuration",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The electron configuration of an atom describes the arrangement of electrons in its shells and subshells. What is the electron configuration of sodium (Na), which has 11 electrons?,
      options: [2, 8, 1, 2, 8, 2, 2, 8, 3", "2, 8, 0].sort(() => Math.random() - 0.5),
      correctAnswer: 2, 8, 1"
    })
  },
  {
    id: "G11-CHE-ATO-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Atomic Structure and Periodicity",
    subtopic: "Atomic and Ionic Radius,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Atomic radius is the distance from the nucleus to the outermost electron shell. Which of the following trends describes atomic radius across a period from left to right?,
      options: [It generally decreases., It generally increases., "It stays the same., It fluctuates."].sort(() => Math.random() - 0.5),
      correctAnswer: "It generally decreases.
    })
  },
  {
    id: G11-CHE-ATO-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Atomic Structure and Periodicity,
    subtopic: "Ionization Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Ionization energy is the energy required to remove an electron from an atom in its gaseous state. Which of the following elements has the highest ionization energy?,
      options: [Helium (He), Lithium (Li), Beryllium (Be)", "Boron (B)].sort(() => Math.random() - 0.5),
      correctAnswer: Helium (He)"
    })
  },
  {
    id: "G11-CHE-ATO-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Atomic Structure and Periodicity",
    subtopic: "Electronegativity,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Electronegativity is a measure of an atom's ability to attract electrons in a chemical bond. Which element has the highest electronegativity?,
      options: [Fluorine (F), Oxygen (O), "Nitrogen (N), Carbon (C)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fluorine (F)
    })
  },
  {
    id: G11-CHE-ATO-05",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Atomic Structure and Periodicity,
    subtopic: "Periodic Trends",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " The periodic table is arranged in periods (rows) and groups (columns). What is the general trend for electronegativity moving down a group in the periodic table?,
      options: [It decreases., It increases., It stays the same.", "It fluctuates.].sort(() => Math.random() - 0.5),
      correctAnswer: It decreases."
    })
  },

  // --- MADA: CHEMICAL BONDING AND STRUCTURE (5 Materials) ---
  {
    id: "G11-CHE-BON-01",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Bonding and Structure",
    subtopic: "Giant Ionic Lattices,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Ionic compounds form giant ionic lattices held together by strong electrostatic forces. What is the name of the ionic lattice formed by sodium chloride?,
      options: [A face-centered cubic lattice, A simple cubic lattice, "A body-centered cubic lattice, A hexagonal lattice"].sort(() => Math.random() - 0.5),
      correctAnswer: "A face-centered cubic lattice
    })
  },
  {
    id: G11-CHE-BON-02",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Bonding and Structure,
    subtopic: "Covalent Networks",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Diamond and graphite are two allotropes of carbon with different structures. What makes diamond one of the hardest known materials?,
      options: [Its giant covalent network where each carbon atom forms four strong covalent bonds., Its weak van der Waals forces., Its metallic bonds.", "Its ionic bonds.].sort(() => Math.random() - 0.5),
      correctAnswer: Its giant covalent network where each carbon atom forms four strong covalent bonds."
    })
  },
  {
    id: "G11-CHE-BON-03",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Bonding and Structure",
    subtopic: "Molecular Geometry (VSEPR Theory),
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "VSEPR (Valence Shell Electron Pair Repulsion) theory is used to predict the shapes of molecules. What is the shape of a molecule with two bonding pairs and no lone pairs on the central atom?,
      options: [Linear, Bent, "Trigonal planar, Tetrahedral"].sort(() => Math.random() - 0.5),
      correctAnswer: "Linear
    })
  },
  {
    id: G11-CHE-BON-04",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Bonding and Structure,
    subtopic: "Molecular Geometry (VSEPR Theory)",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " What is the molecular geometry of water (H₂O), which has two bonding pairs and two lone pairs on the central oxygen atom?,
      options: [Bent or V-shaped, Linear, Trigonal planar", "Tetrahedral].sort(() => Math.random() - 0.5),
      correctAnswer: Bent or V-shaped"
    })
  },
  {
    id: "G11-CHE-BON-05",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Bonding and Structure",
    subtopic: "Intermolecular Forces,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Intermolecular forces are the forces between molecules. Which of the following is the strongest type of intermolecular force?,
      options: [Hydrogen bonding, Dipole-dipole forces, "London dispersion forces, Ionic bonds"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hydrogen bonding
    })
  },

  // --- MADA: STOICHIOMETRY (4 Materials) ---
  {
    id: G11-CHE-STO-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Stoichiometry,
    subtopic: "Mass-Mass Calculations",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Stoichiometric calculations often involve converting between masses of reactants and products. What is the first step in a mass-mass calculation?,
      options: [Convert the mass of the given substance to moles., Balance the chemical equation., Convert the moles of the given substance to moles of the desired substance.", "Convert the moles of the desired substance to mass.].sort(() => Math.random() - 0.5),
      correctAnswer: Balance the chemical equation."
    })
  },
  {
    id: "G11-CHE-STO-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Stoichiometry",
    subtopic: "Mass-Mass Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In the reaction: 2H₂ + O₂ → 2H₂O, how many grams of water are produced when 4 grams of hydrogen (H₂) react with excess oxygen? (Molar masses: H = 1, O = 16),
      options: ["36 g, 18 g", "72 g, 4 g"].sort(() => Math.random() - 0.5),
      correctAnswer: "36 g
    })
  },
  {
    id: G11-CHE-STO-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Stoichiometry,
    subtopic: "Limiting Reactants",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " In a chemical reaction, the limiting reactant determines the amount of product formed. What is a limiting reactant?,
      options: [The reactant that is completely consumed first, stopping the reaction., The reactant that is in excess., The reactant that has the highest concentration.", "The reactant that is the catalyst.].sort(() => Math.random() - 0.5),
      correctAnswer: The reactant that is completely consumed first, stopping the reaction."
    })
  },
  {
    id: "G11-CHE-STO-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Stoichiometry",
    subtopic: "Percentage Yield,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Percentage yield is a measure of the efficiency of a chemical reaction. How is percentage yield calculated?,
      options: [(Actual yield / Theoretical yield) × 100, (Theoretical yield / Actual yield) × 100, "Actual yield - Theoretical yield, Actual yield + Theoretical yield"].sort(() => Math.random() - 0.5),
      correctAnswer: "(Actual yield / Theoretical yield) × 100
    })
  },

  // --- MADA: CHEMICAL KINETICS (4 Materials) ---
  {
    id: G11-CHE-KIN-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Kinetics,
    subtopic: "Rates of Reaction",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Chemical kinetics is the study of the rates of chemical reactions. What is the rate of a reaction?,
      options: [The change in concentration of a reactant or product per unit time., The total amount of product formed., The energy required for a reaction to occur.", "The temperature of the reaction.].sort(() => Math.random() - 0.5),
      correctAnswer: The change in concentration of a reactant or product per unit time."
    })
  },
  {
    id: "G11-CHE-KIN-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Kinetics",
    subtopic: "Factors Affecting Reaction Rate,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Several factors influence the rate of a chemical reaction. Which of the following will generally increase the rate of a reaction?,
      options: [Increasing the temperature., Decreasing the concentration of reactants., "Decreasing the surface area of solids., Adding an inhibitor."].sort(() => Math.random() - 0.5),
      correctAnswer: "Increasing the temperature.
    })
  },
  {
    id: G11-CHE-KIN-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Kinetics,
    subtopic: "Factors Affecting Reaction Rate",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Catalysts are used to speed up reactions without being consumed. How does a catalyst increase the rate of a reaction?,
      options: [By providing an alternative reaction pathway with a lower activation energy., By increasing the temperature of the reaction., By increasing the concentration of reactants.", "By decreasing the surface area.].sort(() => Math.random() - 0.5),
      correctAnswer: By providing an alternative reaction pathway with a lower activation energy."
    })
  },
  {
    id: "G11-CHE-KIN-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Kinetics",
    subtopic: "Factors Affecting Reaction Rate,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Increasing the surface area of a solid reactant will speed up the reaction. Why does increasing surface area increase reaction rate?,
      options: [It provides more contact points for collisions between particles., It increases the temperature., "It increases the concentration of reactants., It adds a catalyst."].sort(() => Math.random() - 0.5),
      correctAnswer: "It provides more contact points for collisions between particles.
    })
  },

  // --- MADA: CHEMICAL EQUILIBRIUM (4 Materials) ---
  {
    id: G11-CHE-EQU-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Equilibrium,
    subtopic: "Dynamic Equilibrium",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A reaction is in dynamic equilibrium when the forward and reverse reactions occur at the same rate. At equilibrium, what can be said about the concentrations of reactants and products?,
      options: [They remain constant over time., They are always equal., They are continuously increasing.", "They are continuously decreasing.].sort(() => Math.random() - 0.5),
      correctAnswer: They remain constant over time."
    })
  },
  {
    id: "G11-CHE-EQU-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Equilibrium",
    subtopic: "Le Chatelier's Principle,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Le Chatelier's principle states that if a change is made to a system at equilibrium, the system will shift to counteract that change. If the concentration of a reactant is increased, how will the equilibrium shift?,
      options: ["It will shift to the right (towards products) to use up the reactant., It will shift to the left (towards reactants).", "It will not shift., It will shift randomly."].sort(() => Math.random() - 0.5),
      correctAnswer: "It will shift to the right (towards products) to use up the reactant.
    })
  },
  {
    id: G11-CHE-EQU-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Chemical Equilibrium,
    subtopic: "Le Chatelier's Principle",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " For the reaction: N₂(g) + 3H₂(g) ⇌ 2NH₃(g) + heat, what happens to the equilibrium if the temperature is increased?,
      options: [It shifts to the left (endothermic direction)., It shifts to the right (exothermic direction)., It stays the same.", "It stops reacting.].sort(() => Math.random() - 0.5),
      correctAnswer: It shifts to the left (endothermic direction)."
    })
  },
  {
    id: "G11-CHE-EQU-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Chemical Equilibrium",
    subtopic: "Le Chatelier's Principle,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Pressure changes can also affect equilibrium in gas phase reactions. For the reaction N₂(g) + 3H₂(g) ⇌ 2NH₃(g), what happens if the pressure is increased?,
      options: [The equilibrium shifts to the side with fewer moles of gas (right)., The equilibrium shifts to the side with more moles of gas (left).", "The equilibrium shifts randomly., The equilibrium stays the same."].sort(() => Math.random() - 0.5),
      correctAnswer: "The equilibrium shifts to the side with fewer moles of gas (right).
    })
  },

  // --- MADA: ACIDS AND BASES (4 Materials) ---
  {
    id: G11-CHE-ACID-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Acids and Bases,
    subtopic: "Strong vs Weak Acids and Bases",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Acids can be classified as either strong or weak based on their degree of ionization in water. Which of the following is a strong acid?,
      options: [Hydrochloric acid (HCl), Acetic acid (CH₃COOH), Carbonic acid (H₂CO₃)", "Phosphoric acid (H₃PO₄)].sort(() => Math.random() - 0.5),
      correctAnswer: Hydrochloric acid (HCl)"
    })
  },
  {
    id: "G11-CHE-ACID-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Acids and Bases",
    subtopic: "Strong vs Weak Acids and Bases,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Similarly, bases can be classified as strong or weak. Which of the following is a strong base?,
      options: [Sodium hydroxide (NaOH), Ammonia (NH₃)", "Calcium hydroxide (Ca(OH)₂), Potassium carbonate (K₂CO₃)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sodium hydroxide (NaOH)
    })
  },
  {
    id: G11-CHE-ACID-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Acids and Bases,
    subtopic: "pH Calculations",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " pH is a measure of the acidity or alkalinity of a solution. What is the pH of a solution with a hydrogen ion concentration of 1 × 10⁻³ mol/L?,
      options: [3, 11, 7", "10].sort(() => Math.random() - 0.5),
      correctAnswer: 3"
    })
  },
  {
    id: "G11-CHE-ACID-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Acids and Bases",
    subtopic: "Buffer Solutions,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "A buffer solution is a solution that resists changes in pH when small amounts of acid or base are added. What two components are typically found in a buffer solution?,
      options: [A weak acid and its conjugate base., A strong acid and a strong base., "A weak acid and a strong base., A strong acid and its conjugate base."].sort(() => Math.random() - 0.5),
      correctAnswer: "A weak acid and its conjugate base.
    })
  },

  // --- MADA: REDOX REACTIONS (4 Materials) ---
  {
    id: G11-CHE-RED-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Redox Reactions,
    subtopic: "Oxidation and Reduction",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Redox reactions involve the transfer of electrons between species. What is the definition of oxidation?,
      options: [The loss of electrons., The gain of electrons., The loss of oxygen.", "The gain of hydrogen.].sort(() => Math.random() - 0.5),
      correctAnswer: The loss of electrons."
    })
  },
  {
    id: "G11-CHE-RED-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Redox Reactions",
    subtopic: "Oxidizing and Reducing Agents,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "In a redox reaction, one species is oxidized and another is reduced. What is an oxidizing agent?,
      options: [A substance that causes oxidation by accepting electrons., A substance that causes reduction by donating electrons.", "A substance that is oxidized., A substance that is reduced."].sort(() => Math.random() - 0.5),
      correctAnswer: "A substance that causes oxidation by accepting electrons.
    })
  },
  {
    id: G11-CHE-RED-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Redox Reactions,
    subtopic: "Oxidizing and Reducing Agents",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " In the reaction Zn + CuSO₄ → ZnSO₄ + Cu, which substance is oxidized and acts as the reducing agent?,
      options: [Zinc (Zn), Copper sulfate (CuSO₄), Zinc sulfate (ZnSO₄)", "Copper (Cu)].sort(() => Math.random() - 0.5),
      correctAnswer: Zinc (Zn)"
    })
  },
  {
    id: "G11-CHE-RED-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Redox Reactions",
    subtopic: "Balancing Redox Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Balancing redox equations requires ensuring both mass and charge are conserved. What method is commonly used to balance redox equations in acidic or basic solutions?,
      options: [The half-reaction method, The molar mass method, "The limiting reactant method, The empirical formula method"].sort(() => Math.random() - 0.5),
      correctAnswer: "The half-reaction method
    })
  },

  // --- MADA: ORGANIC CHEMISTRY (5 Materials) ---
  {
    id: G11-CHE-ORG-01",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Organic Chemistry,
    subtopic: "Introduction to Hydrocarbons",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Organic chemistry is the study of carbon compounds. Which of the following is the simplest hydrocarbon?,
      options: [Methane (CH₄), Ethane (C₂H₆), Propane (C₃H₈)", "Butane (C₄H₁₀)].sort(() => Math.random() - 0.5),
      correctAnswer: Methane (CH₄)"
    })
  },
  {
    id: "G11-CHE-ORG-02",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Organic Chemistry",
    subtopic: "Alkanes,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Alkanes are saturated hydrocarbons containing only single bonds. What is the general formula for alkanes?,
      options: [CₙH₂ₙ₊₂, CₙH₂ₙ, "CₙH₂ₙ₋₂, CₙHₙ"].sort(() => Math.random() - 0.5),
      correctAnswer: "CₙH₂ₙ₊₂
    })
  },
  {
    id: G11-CHE-ORG-03",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Organic Chemistry,
    subtopic: "Alkenes and Alkynes",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Alkenes and alkynes are unsaturated hydrocarbons. Which family of hydrocarbons contains a carbon-carbon double bond?,
      options: [Alkenes, Alkanes, Alkynes", "Aromatics].sort(() => Math.random() - 0.5),
      correctAnswer: Alkenes"
    })
  },
  {
    id: "G11-CHE-ORG-04",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Organic Chemistry",
    subtopic: "Naming Alkenes,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Alkenes are named using the suffix '-ene'. What is the correct IUPAC name for the alkene with the molecular formula C₂H₄?,
      options: [Ethene, Ethane, "Ethyne, Ethanol"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethene
    })
  },
  {
    id: G11-CHE-ORG-05",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Organic Chemistry,
    subtopic: "Functional Groups",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Functional groups are specific atoms or groups of atoms within molecules that determine their chemical properties. Which functional group is found in alcohols?,
      options: [Hydroxyl group (-OH), Carbonyl group (C=O), Carboxyl group (COOH)", "Amino group (NH₂)].sort(() => Math.random() - 0.5),
      correctAnswer: Hydroxyl group (-OH)"
    })
  },

  // --- MADA: PRACTICAL CHEMISTRY (4 Materials) ---
  {
    id: "G11-CHE-PRA-01",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Practical Chemistry",
    subtopic: "Titration,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Titration is a common laboratory technique used to determine the concentration of an unknown solution. What is the point in a titration where the indicator changes color called?,
      options: [The endpoint, The equivalence point, "The starting point, The end point"].sort(() => Math.random() - 0.5),
      correctAnswer: "The endpoint
    })
  },
  {
    id: G11-CHE-PRA-02",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Practical Chemistry,
    subtopic: "Titration",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " In an acid-base titration, an indicator is used to detect the endpoint. What is a common indicator used in strong acid-strong base titrations?,
      options: [Phenolphthalein, Methyl orange, Universal indicator", "Bromothymol blue].sort(() => Math.random() - 0.5),
      correctAnswer: Phenolphthalein"
    })
  },
  {
    id: "G11-CHE-PRA-03",
    grade: "Grade 11",
    subject: "Chemistry",
    topic: "Practical Chemistry",
    subtopic: "Qualitative Analysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Qualitative analysis is used to identify the ions present in a solution. Which test is used to detect the presence of carbonate ions (CO₃²⁻)?,
      options: [Adding dilute acid and testing the gas produced with limewater., Adding silver nitrate solution., "Adding barium chloride solution., Using a flame test."].sort(() => Math.random() - 0.5),
      correctAnswer: "Adding dilute acid and testing the gas produced with limewater.
    })
  },
  {
    id: G11-CHE-PRA-04",
    grade: "Grade 11,
    subject: Chemistry",
    topic: "Practical Chemistry,
    subtopic: "Qualitative Analysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " Halide ions can be identified by precipitation reactions with silver nitrate. What is the color of the precipitate formed when silver nitrate is added to a solution containing chloride ions?,
      options: [White precipitate, Cream precipitate, Yellow precipitate", "Brown precipitate].sort(() => Math.random() - 0.5),
      correctAnswer: White precipitate"
    })
  }
  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD CHEMISTRY SYLLABUS)
  // =========================================================================

  // --- MADA: ADVANCED ORGANIC CHEMISTRY (4 Materials) ---
  {
    id: "G12-CHE-ORG-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Advanced Organic Chemistry",
    subtopic: "Arenes (Benzene),
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Benzene is the simplest arene, with a unique ring structure. What is the structural feature that gives benzene its stability?,
      options: [Its delocalized electrons (resonance)., Its strong C-C bonds.", "Its double bonds are fixed., Its lack of hydrogen atoms."].sort(() => Math.random() - 0.5),
      correctAnswer: "Its delocalized electrons (resonance).
    })
  },
  {
    id: G12-CHE-ORG-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Advanced Organic Chemistry,
    subtopic: "Phenols",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Phenol is an organic compound with a hydroxyl group (-OH) attached to a benzene ring. Which property distinguishes phenol from simple alcohols?,
      options: [It is acidic due to the resonance stabilization of the phenoxide ion., It is basic., It has no reaction with water.", "It is completely unreactive.].sort(() => Math.random() - 0.5),
      correctAnswer: It is acidic due to the resonance stabilization of the phenoxide ion."
    })
  },
  {
    id: "G12-CHE-ORG-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Advanced Organic Chemistry",
    subtopic: "Polymers,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Polymers are large molecules made by linking many smaller monomers. What is the difference between addition polymers and condensation polymers?,
      options: [Addition polymers are made without the loss of a small molecule, while condensation polymers lose a small molecule like water., They are the same., "Addition polymers lose water, condensation polymers do not., Addition polymers are natural, condensation polymers are synthetic."].sort(() => Math.random() - 0.5),
      correctAnswer: "Addition polymers are made without the loss of a small molecule, while condensation polymers lose a small molecule like water.
    })
  },
  {
    id: G12-CHE-ORG-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Advanced Organic Chemistry,
    subtopic: "Polymers",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nylon is a well-known synthetic polymer used in fabrics. What type of reaction is used to produce nylon?,
      options: [Condensation polymerization, Addition polymerization, Free radical polymerization", "Cationic polymerization].sort(() => Math.random() - 0.5),
      correctAnswer: Condensation polymerization"
    })
  },

  // --- MADA: THERMODYNAMICS (4 Materials) ---
  {
    id: "G12-CHE-THE-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Thermodynamics",
    subtopic: "Enthalpy,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Enthalpy (H) is a thermodynamic quantity representing the total heat content of a system. What does a negative ΔH value indicate in a chemical reaction?,
      options: [The reaction is exothermic (releases heat)., The reaction is endothermic (absorbs heat)., "The reaction is at equilibrium., The reaction produces no heat."].sort(() => Math.random() - 0.5),
      correctAnswer: "The reaction is exothermic (releases heat).
    })
  },
  {
    id: G12-CHE-THE-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Thermodynamics,
    subtopic: "Entropy",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Entropy (S) is a measure of the disorder of a system. Which of the following changes would result in a decrease in entropy (ΔS < 0)?,
      options: [Condensation of a gas into a liquid., Evaporation of a liquid., Melting of a solid.", "Expansion of a gas.].sort(() => Math.random() - 0.5),
      correctAnswer: Condensation of a gas into a liquid."
    })
  },
  {
    id: "G12-CHE-THE-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Thermodynamics",
    subtopic: "Gibbs Free Energy,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Gibbs free energy (ΔG) determines whether a reaction is spontaneous. What condition is necessary for a reaction to be spontaneous at constant temperature and pressure?,
      options: [ΔG must be negative., ΔG must be positive., "ΔG must be zero., ΔS must be negative."].sort(() => Math.random() - 0.5),
      correctAnswer: "ΔG must be negative.
    })
  },
  {
    id: G12-CHE-THE-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Thermodynamics,
    subtopic: "Gibbs Free Energy",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The relationship between Gibbs free energy, enthalpy, and entropy is given by ΔG = ΔH - TΔS. If a reaction has a negative ΔH and a positive ΔS, what can you conclude about the reaction?,
      options: [It is spontaneous at all temperatures., It is non-spontaneous at all temperatures., It is only spontaneous at high temperatures.", "It is only spontaneous at low temperatures.].sort(() => Math.random() - 0.5),
      correctAnswer: It is spontaneous at all temperatures."
    })
  },

  // --- MADA: ELECTROCHEMISTRY (4 Materials) ---
  {
    id: "G12-CHE-ELC-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Electrochemistry",
    subtopic: "Electrolysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Electrolysis is the process of using electricity to drive a non-spontaneous chemical reaction. In the electrolysis of molten sodium chloride, what is produced at the cathode?,
      options: [Sodium metal, Chlorine gas", "Hydrogen gas, Oxygen gas"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sodium metal
    })
  },
  {
    id: G12-CHE-ELC-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Electrochemistry,
    subtopic: "Galvanic Cells",
    maxUses: 5,
    usageCount: 0,
    minWords: 24,
    generate: () => ({
      text: " A galvanic (voltaic) cell converts chemical energy into electrical energy. In a galvanic cell, which electrode does oxidation occur at?,
      options: [The anode, The cathode, The salt bridge", "The external circuit].sort(() => Math.random() - 0.5),
      correctAnswer: The anode"
    })
  },
  {
    id: "G12-CHE-ELC-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Electrochemistry",
    subtopic: "Standard Electrode Potentials,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Standard electrode potentials (E°) allow chemists to predict the direction of redox reactions. What is the standard hydrogen electrode (SHE) used for?,
      options: [As a reference electrode with an assigned potential of 0.00 V., To measure the pH of a solution., "To measure the concentration of hydrogen., To produce hydrogen gas."].sort(() => Math.random() - 0.5),
      correctAnswer: "As a reference electrode with an assigned potential of 0.00 V.
    })
  },
  {
    id: G12-CHE-ELC-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Electrochemistry,
    subtopic: "Faraday's Laws of Electrolysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Faraday's first law of electrolysis states that the mass of a substance deposited at an electrode is directly proportional to the quantity of electricity passed. What is the charge of one mole of electrons?,
      options: [96,500 coulombs, 1 coulomb, 6.02 × 10²³ coulombs", "22.4 coulombs].sort(() => Math.random() - 0.5),
      correctAnswer: 96,500 coulombs"
    })
  },

  // --- MADA: CHEMICAL KINETICS (4 Materials) ---
  {
    id: "G12-CHE-KIN-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Chemical Kinetics",
    subtopic: "Rate Laws and Order of Reactions,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Rate laws express the relationship between reaction rate and the concentration of reactants. If the rate law is: Rate = k[A][B]², what is the overall order of the reaction?,
      options: [3rd order, 2nd order", "1st order, 0th order"].sort(() => Math.random() - 0.5),
      correctAnswer: "3rd order
    })
  },
  {
    id: G12-CHE-KIN-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Chemical Kinetics,
    subtopic: "Rate Laws and Order of Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " The integrated rate law for a first-order reaction is ln[A]t = -kt + ln[A]₀. Which graph would produce a straight line for a first-order reaction?,
      options: [A plot of ln[A] against time., A plot of [A] against time., A plot of 1/[A] against time.", "A plot of [A]² against time.].sort(() => Math.random() - 0.5),
      correctAnswer: A plot of ln[A] against time."
    })
  },
  {
    id: "G12-CHE-KIN-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Chemical Kinetics",
    subtopic: "Arrhenius Equation,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "The Arrhenius equation relates the rate constant to temperature and activation energy: k = Ae^(-Ea/RT). What does 'Ea' represent in this equation?,
      options: [The activation energy of the reaction., The frequency factor., "The rate constant., The temperature in Kelvin."].sort(() => Math.random() - 0.5),
      correctAnswer: "The activation energy of the reaction.
    })
  },
  {
    id: G12-CHE-KIN-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Chemical Kinetics,
    subtopic: "Arrhenius Equation",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " According to the Arrhenius equation, what happens to the rate constant (k) when the temperature (T) increases?,
      options: [The rate constant increases., The rate constant decreases., The rate constant stays the same.", "The activation energy increases.].sort(() => Math.random() - 0.5),
      correctAnswer: The rate constant increases."
    })
  },

  // --- MADA: CHEMICAL EQUILIBRIUM (4 Materials) ---
  {
    id: "G12-CHE-EQU-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Chemical Equilibrium",
    subtopic: "The Equilibrium Constant (Kc),
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "The equilibrium constant (Kc) is a measure of the extent of a reaction at equilibrium. For the reaction aA + bB ⇌ cC + dD, how is Kc expressed?,
      options: [Kc = [C]^c[D]^d / [A]^a[B]^b, Kc = [A]^a[B]^b / [C]^c[D]^d", "Kc = [A]^a + [B]^b / [C]^c + [D]^d, Kc = [A] + [B] / [C] + [D]"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kc = [C]^c[D]^d / [A]^a[B]^b
    })
  },
  {
    id: G12-CHE-EQU-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Chemical Equilibrium,
    subtopic: "The Equilibrium Constant (Kc)",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " What does a large value of Kc (e.g., Kc > 10³) indicate about the reaction at equilibrium?,
      options: [The products are favored over the reactants., The reactants are favored over the products., The reaction is at a 50/50 mix.", "The reaction does not reach equilibrium.].sort(() => Math.random() - 0.5),
      correctAnswer: The products are favored over the reactants."
    })
  },
  {
    id: "G12-CHE-EQU-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Chemical Equilibrium",
    subtopic: "Kp (Equilibrium Constant in Terms of Pressure),
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "For gaseous reactions, the equilibrium constant can be expressed in terms of partial pressures (Kp). How does Kp differ from Kc?,
      options: [Kp is used for gases and involves partial pressures, while Kc is used for concentrations., They are the same.", "Kp is used for solids., Kc is used for liquids."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kp is used for gases and involves partial pressures, while Kc is used for concentrations.
    })
  },
  {
    id: G12-CHE-EQU-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Chemical Equilibrium,
    subtopic: "Solubility Product (Ksp)",
    maxUses: 5,
    usageCount: 0,
    minWords: 28,
    generate: () => ({
      text: " The solubility product (Ksp) is the equilibrium constant for the dissolution of a sparingly soluble salt. For CaF₂(s) ⇌ Ca²⁺(aq) + 2F⁻(aq), what is the Ksp expression?,
      options: [Ksp = [Ca²⁺][F⁻]², Ksp = [Ca²⁺][F⁻], Ksp = [Ca²⁺] + [F⁻]²", "Ksp = [Ca²⁺]²[F⁻]].sort(() => Math.random() - 0.5),
      correctAnswer: Ksp = [Ca²⁺][F⁻]²"
    })
  },

  // --- MADA: FURTHER ACIDS AND BASES (4 Materials) ---
  {
    id: "G12-CHE-ACID-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Further Acids and Bases",
    subtopic: "Weak Acid pH Calculations,
    maxUses: 5,
    usageCount: 0,
    minWords: 27,",
    generate: () => ({
      text: "Calculating the pH of a weak acid requires the acid dissociation constant (Ka). What is the general formula for the pH of a weak acid (HA)?,
      options: [pH = ½(pKa - log[HA]), pH = pKa + log[HA], "pH = -log[H⁺], pH = pKa + 1"].sort(() => Math.random() - 0.5),
      correctAnswer: "pH = ½(pKa - log[HA])
    })
  },
  {
    id: G12-CHE-ACID-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Further Acids and Bases,
    subtopic: "Buffer Solutions",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " A buffer solution maintains a relatively constant pH. The Henderson-Hasselbalch equation is used to calculate the pH of a buffer: pH = pKa + log([A⁻]/[HA]). What does [A⁻] represent in this equation?,
      options: [The concentration of the conjugate base., The concentration of the weak acid., The concentration of hydrogen ions.", "The concentration of hydroxide ions.].sort(() => Math.random() - 0.5),
      correctAnswer: The concentration of the conjugate base."
    })
  },
  {
    id: "G12-CHE-ACID-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Further Acids and Bases",
    subtopic: "Hydrolysis,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Hydrolysis is the reaction of a salt with water. What happens when a salt of a strong acid and a weak base (e.g., NH₄Cl) is dissolved in water?,
      options: [The solution becomes acidic., The solution becomes basic.", "The solution remains neutral., The salt precipitates out."].sort(() => Math.random() - 0.5),
      correctAnswer: "The solution becomes acidic.
    })
  },
  {
    id: G12-CHE-ACID-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Further Acids and Bases,
    subtopic: "Hydrolysis",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " When a salt of a weak acid and a strong base (e.g., CH₃COONa) is dissolved in water, the solution is basic. What is the chemical reason for this?,
      options: [The anion of the weak acid reacts with water to produce OH⁻ ions., The cation of the strong base reacts with water to produce H⁺., The salt does not dissolve.", "The salt is neutral.].sort(() => Math.random() - 0.5),
      correctAnswer: The anion of the weak acid reacts with water to produce OH⁻ ions."
    })
  },

  // --- MADA: ORGANIC REACTIONS (4 Materials) ---
  {
    id: "G12-CHE-REA-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Organic Reactions",
    subtopic: "Nucleophilic Substitution,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Nucleophilic substitution reactions are common in alkyl halides. What is a nucleophile?,
      options: [An electron-rich species that seeks a positive center., An electron-deficient species that seeks a negative center., "A positively charged ion., A neutral molecule with no charge."].sort(() => Math.random() - 0.5),
      correctAnswer: "An electron-rich species that seeks a positive center.
    })
  },
  {
    id: G12-CHE-REA-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Organic Reactions,
    subtopic: "Nucleophilic Substitution",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " The reaction between bromoethane and sodium hydroxide is a nucleophilic substitution. What is the product of this reaction?,
      options: [Ethanol, Ethene, Ethane", "Ethanoic acid].sort(() => Math.random() - 0.5),
      correctAnswer: Ethanol"
    })
  },
  {
    id: "G12-CHE-REA-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Organic Reactions",
    subtopic: "Addition Reactions,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Alkenes undergo addition reactions due to their double bond. What is the product of the addition reaction between ethene (C₂H₄) and hydrogen gas (H₂) in the presence of a catalyst?,
      options: [Ethane (C₂H₆), Ethanol (C₂H₅OH), "Ethyne (C₂H₂), Polyethylene"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethane (C₂H₆)
    })
  },
  {
    id: G12-CHE-REA-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Organic Reactions,
    subtopic: "Elimination Reactions",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Elimination reactions involve the removal of a small molecule from a larger one. What is the product of the elimination reaction of ethanol (C₂H₅OH) in the presence of a concentrated acid and high temperature?,
      options: [Ethene (C₂H₄), Ethane (C₂H₆), Ethanoic acid (CH₃COOH)", "Ethyl ethanoate].sort(() => Math.random() - 0.5),
      correctAnswer: Ethene (C₂H₄)"
    })
  },

  // --- MADA: APPLICATIONS OF CHEMISTRY (4 Materials) ---
  {
    id: "G12-CHE-APP-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Applications of Chemistry",
    subtopic: "Polymers in Daily Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "Polymers have a wide range of uses in daily life. Which polymer is commonly used to make plastic bottles and packaging materials?,
      options: [Polyethylene, Nylon, "Teflon, Bakelite"].sort(() => Math.random() - 0.5),
      correctAnswer: "Polyethylene
    })
  },
  {
    id: G12-CHE-APP-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Applications of Chemistry,
    subtopic: "Dyes and Pigments",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Synthetic dyes are widely used in the textile industry. What is the main advantage of synthetic dyes over natural dyes?,
      options: [They are more color-fast and cheaper to produce., They fade quickly., They are harder to make.", "They are only available in a few colors.].sort(() => Math.random() - 0.5),
      correctAnswer: They are more color-fast and cheaper to produce."
    })
  },
  {
    id: "G12-CHE-APP-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Applications of Chemistry",
    subtopic: "Soaps and Detergents,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Soaps and detergents are cleansing agents. What is the chemical difference between soap and detergent?,
      options: [Soap is a sodium or potassium salt of a fatty acid, while detergent is a synthetic surfactant., They are exactly the same., "Detergent is a salt of a fatty acid., Soap is synthetic."].sort(() => Math.random() - 0.5),
      correctAnswer: "Soap is a sodium or potassium salt of a fatty acid, while detergent is a synthetic surfactant.
    })
  },
  {
    id: G12-CHE-APP-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Applications of Chemistry,
    subtopic: "Drugs and Pharmaceuticals",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Chemistry is essential in the development of pharmaceuticals. What does the term 'generic drug' mean?,
      options: [A drug that is equivalent to a brand-name drug but is sold under its chemical name., A drug that is illegal., A drug that is made of natural ingredients.", "A drug that is only available by prescription.].sort(() => Math.random() - 0.5),
      correctAnswer: A drug that is equivalent to a brand-name drug but is sold under its chemical name."
    })
  },

  // --- MADA: ENVIRONMENTAL CHEMISTRY (4 Materials) ---
  {
    id: "G12-CHE-ENV-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Environmental Chemistry",
    subtopic: "Atmospheric Pollution,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Air pollution is a major environmental issue. Which gas is primarily responsible for acid rain?,
      options: [Sulfur dioxide (SO₂), Carbon dioxide (CO₂), "Oxygen (O₂), Nitrogen (N₂)"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sulfur dioxide (SO₂)
    })
  },
  {
    id: G12-CHE-ENV-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Environmental Chemistry,
    subtopic: "Atmospheric Pollution",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Greenhouse gases trap heat in the atmosphere, contributing to global warming. Which of the following is a greenhouse gas?,
      options: [Carbon dioxide (CO₂), Oxygen (O₂), Nitrogen (N₂)", "Argon (Ar)].sort(() => Math.random() - 0.5),
      correctAnswer: Carbon dioxide (CO₂)"
    })
  },
  {
    id: "G12-CHE-ENV-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Environmental Chemistry",
    subtopic: "Water Pollution,
    maxUses: 5,
    usageCount: 0,
    minWords: 26,",
    generate: () => ({
      text: "Water pollution is caused by various contaminants. Which of the following is a common water pollutant?,
      options: [Fertilizer runoff (nitrates and phosphates), Pure water, "Sand, Air"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fertilizer runoff (nitrates and phosphates)
    })
  },
  {
    id: G12-CHE-ENV-04",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Environmental Chemistry,
    subtopic: "Green Chemistry",
    maxUses: 5,
    usageCount: 0,
    minWords: 27,
    generate: () => ({
      text: " Green chemistry aims to design chemical processes that reduce environmental impact. What is one principle of green chemistry?,
      options: [Using renewable feedstocks and minimizing waste., Using toxic chemicals to speed up reactions., Throwing away waste without treatment.", "Focusing only on profit.].sort(() => Math.random() - 0.5),
      correctAnswer: Using renewable feedstocks and minimizing waste."
    })
  },

  // --- MADA: PRACTICAL ORGANIC CHEMISTRY (3 Materials) ---
  {
    id: "G12-CHE-PRA-01",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Practical Organic Chemistry",
    subtopic: "Preparation of Ethanol,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Ethanol can be prepared by the fermentation of sugars. What is the chemical equation for the fermentation of glucose?,
      options: [C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂, C₆H₁₂O₆ → C₂H₅OH + CO₂, "C₆H₁₂O₆ → 3C₂H₅OH, C₆H₁₂O₆ → 2CH₃COOH"].sort(() => Math.random() - 0.5),
      correctAnswer: "C₆H₁₂O₆ → 2C₂H₅OH + 2CO₂
    })
  },
  {
    id: G12-CHE-PRA-02",
    grade: "Grade 12,
    subject: Chemistry",
    topic: "Practical Organic Chemistry,
    subtopic: "Preparation of Esters",
    maxUses: 5,
    usageCount: 0,
    minWords: 26,
    generate: () => ({
      text: " Esters are commonly prepared by the reaction between an alcohol and a carboxylic acid in the presence of a catalyst. What type of reaction is this?,
      options: [Esterification (Condensation), Combustion, Substitution", "Addition].sort(() => Math.random() - 0.5),
      correctAnswer: Esterification (Condensation)"
    })
  },
  {
    id: "G12-CHE-PRA-03",
    grade: "Grade 12",
    subject: "Chemistry",
    topic: "Practical Organic Chemistry",
    subtopic: "Preparation of Esters,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Ethyl ethanoate (CH₃COOC₂H₅) is a common ester with a fruity smell. What is the name of the acid used to prepare ethyl ethanoate?,
      options: [Ethanoic acid, Methanoic acid, "Propanoic acid, Butanoic acid"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethanoic acid"
    })
  }

];


