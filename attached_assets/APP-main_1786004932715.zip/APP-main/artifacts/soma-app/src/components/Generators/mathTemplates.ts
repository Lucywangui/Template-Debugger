export const mathTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 1: 35 MATERIALS (KICD MATHEMATICS SYLLABUS)
  // =========================================================================

  // --- MADA: NUMBERS (COUNTING) (5 Materials) ---
  {
    id: "G1-MAT-NUM-01",
    grade: "Grade 1",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Counting Objects 1-10",
    maxUses: 5,
    usageCount: 0,
    minWords: 10,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = a + Math.floor(Math.random() * 3) + 1;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`If you have ${a} oranges and your mother gives you ${b} more, how many oranges do you have in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-NUM-02,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Counting Objects 1-10",
    maxUses: 5,
    usageCount: 0,
    minWords: 10,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 1;
      const b = Math.floor(Math.random() * 3) + 1;
      const correct = a + b;
      const opts = [correct, correct+2, correct-1, correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${a} children playing under a tree. If ${b} more children join them, how many children are now under the tree?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-NUM-03,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Number Names 1-10,
    maxUses: 5,
    usageCount: 0,
    minWords: 8,",
    generate: () => {
      const num = Math.floor(Math.random() * 9) + 1;
      const names = [One", "Two, Three", "Four, Five", "Six, Seven", "Eight, Nine", "Ten];
      const correct = names[num-1];
      const opts = [correct, names[(num+1)%10], names[(num+2)%10], names[(num+3)%10]].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the correct word for the number ${num}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G1-MAT-NUM-04,
    grade: Grade 1,
    subject: Mathematics,
    topic: "Numbers,
    subtopic: "Writing Numerals",
    maxUses: 5,
    usageCount: 0,
    minWords: 8,
    generate: () => {
      const num = Math.floor(Math.random() * 9) + 1;
      const names = ["One, Two", "Three, Four", "Five, Six", "Seven, Eight", "Nine, Ten"];
      const correct = String(num);
      const opts = [correct, String(num+1), String(num+2), String(num-1)].sort(() => Math.random() - 0.5);
      return {
        text: "`How do you write the number for the word ${names[num-1]}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G1-MAT-NUM-05,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Comparing Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 1;
      const b = Math.floor(Math.random() * 8) + 1;
      const correct = a === b ? "Equal to : (a > b ? Greater than" : "Less than);
      const opts = [Greater than", "Less than, Equal to", "Not sure].sort(() => Math.random() - 0.5);
      return {
        text: "`Compare these numbers: ${a} and ${b}. Is ${a} greater than, less than, or equal to ${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: ADDITION (5 Materials) ---
  {
    id: G1-MAT-ADD-01,
    grade: Grade 1,
    subject: Mathematics,
    topic: "Addition,
    subtopic: "Adding Numbers Up to 10",
    maxUses: 5,
    usageCount: 0,
    minWords: 10,
    generate: () => {
      const a = Math.floor(Math.random() * 7) + 1;
      const b = Math.floor(Math.random() * (9 - a)) + 1;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-ADD-02,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding Numbers Up to 10,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const a = Math.floor(Math.random() * 7) + 1;
      const b = Math.floor(Math.random() * (9 - a)) + 1;
      const correct = a + b;
      const opts = [correct, correct+2", correct-1", correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`A boy has ${a} marbles. He finds ${b} more marbles on the ground. How many marbles does he have now?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-ADD-03,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding Numbers Up to 10",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * (9 - a)) + 1;
      const correct = a + b;
      const opts = [correct, correct+2, correct-1, correct-2].sort(() => Math.random() - 0.5);
      return {
        text: "`A basket has ${a} apples. If you put ${b} more apples inside, how many apples are in the basket now?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-ADD-04,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding Numbers Up to 10,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 7) + 1;
      const b = Math.floor(Math.random() * (9 - a)) + 1;
      const correct = a + b;
      const opts = [correct, correct+1", correct-2", correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`A farmer has ${a} cows. He buys ${b} more cows. How many cows does the farmer have in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-ADD-05,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding Zero",
    maxUses: 5,
    usageCount: 0,
    minWords: 11,
    generate: () => {
      const a = Math.floor(Math.random() * 9) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct+2, correct-1].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} plus 0?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: SUBTRACTION (5 Materials) ---
  {
    id: G1-MAT-SUB-01,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting Numbers Up to 10,
    maxUses: 5,
    usageCount: 0,
    minWords: 11,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 2;
      const b = Math.floor(Math.random() * (a - 1)) + 1;
      const correct = a - b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-SUB-02,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting Numbers Up to 10",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 2;
      const b = Math.floor(Math.random() * (a - 1)) + 1;
      const correct = a - b;
      const opts = [correct, correct+2, correct-1, correct-2].sort(() => Math.random() - 0.5);
      return {
        text: "`A garden has ${a} flowers. If you pick ${b} flowers, how many flowers remain in the garden?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-SUB-03,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting Numbers Up to 10,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 2;
      const b = Math.floor(Math.random() * (a - 1)) + 1;
      const correct = a - b;
      const opts = [correct, correct+1", correct-2", correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`A teacher has ${a} books. She gives ${b} books to a student. How many books does the teacher have left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-SUB-04,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting Numbers Up to 10",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 2;
      const b = Math.floor(Math.random() * (a - 1)) + 1;
      const correct = a - b;
      const opts = [correct, correct+2, correct-1, correct-3].sort(() => Math.random() - 0.5);
      return {
        text: "`A hen laid ${a} eggs. If ${b} eggs hatch, how many eggs are left unhatched?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G1-MAT-SUB-05,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting Zero,
    maxUses: 5,
    usageCount: 0,
    minWords: 11,
    generate: () => {
      const a = Math.floor(Math.random() * 9) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct+2", correct-1].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus 0?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MEASUREMENT (LENGTH & MASS) (5 Materials) ---
  {
    id: G1-MAT-MEA-01,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Length (Long vs Short)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = ["A long snake, A short pencil", "A long train, A short ant"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is considered a long object?`,
        options: options,
        correctAnswer: A long train
      };
    }
  },
  {
    id: G1-MAT-MEA-02,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Length (Long vs Short)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = ["A short ant, A long whale", "A short caterpillar, A long tree"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is considered a short object?`,
        options: options,
        correctAnswer: A short ant
      };
    }
  },
  {
    id: G1-MAT-MEA-03,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Mass (Heavy vs Light)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = ["A heavy rock, A light feather", "A heavy elephant, A light balloon"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a heavy object?`,
        options: options,
        correctAnswer: A heavy rock
      };
    }
  },
  {
    id: G1-MAT-MEA-04,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Mass (Heavy vs Light)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = ["A light paper, A heavy table", "A light feather, A heavy book"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a light object?`,
        options: options,
        correctAnswer: A light feather
      };
    }
  },
  {
    id: G1-MAT-MEA-05,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Capacity (Holds More/Less)",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const options = ["A small cup, A large pot", "A small glass, A large barrel"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following holds the least amount of water?`,
        options: options,
        correctAnswer: A small cup
      };
    }
  },

  // --- MADA: GEOMETRY (SHAPES) (5 Materials) ---
  {
    id: G1-MAT-GEO-01,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying Circles",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const options = ["A ball, A square box", "A triangular roof, A rectangular door"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these objects has a round shape?`,
        options: options,
        correctAnswer: A ball
      };
    }
  },
  {
    id: G1-MAT-GEO-02,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying Squares",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const options = ["A square window, A round clock", "A triangular sign, A rectangular door"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these objects has the shape of a square?`,
        options: options,
        correctAnswer: A square window
      };
    }
  },
  {
    id: G1-MAT-GEO-03,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying Triangles",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const options = ["A triangular tent, A round plate", "A square box, A rectangular bed"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these objects is shaped like a triangle?`,
        options: options,
        correctAnswer: A triangular tent
      };
    }
  },
  {
    id: G1-MAT-GEO-04,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying Rectangles",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const options = ["A rectangular book, A round coin", "A triangular pizza, A square tile"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these objects is shaped like a rectangle?`,
        options: options,
        correctAnswer: A rectangular book
      };
    }
  },
  {
    id: G1-MAT-GEO-05,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Drawing Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const options = ["Square, Triangle", "Rectangle, Circle"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which shape has four equal sides?`,
        options: options,
        correctAnswer: Square
      };
    }
  },

  // --- MADA: TIME (5 Materials) ---
  {
    id: G1-MAT-TIM-01,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Telling Time (O'Clock)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`${hour} o'clock`, `${hour+1} o'clock`, `${hour-1} o'clock`, `${hour+2} o'clock`].sort(() => Math.random() - 0.5);
      return {
        text: "`If the clock shows the time exactly at ${hour}:00, what is the correct way to say the time?`,
        options: options,
        correctAnswer: `${hour} o'clock`
      };
    }
  },
  {
    id: G1-MAT-TIM-02,
    grade: Grade 1",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Telling Time (O'Clock),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`${hour} o'clock`, `${hour+2} o'clock`", `${hour-1} o'clock`", `${hour+3} o'clock`].sort(() => Math.random() - 0.5);
      return {
        text: "`The long hand of the clock is pointing at 12. The short hand is pointing at ${hour}. What time is it?`,
        options: options,
        correctAnswer: `${hour} o'clock`
      };
    }
  },
  {
    id: G1-MAT-TIM-03,
    grade: "Grade 1,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Days of the Week",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const days = ["Sunday, Monday", "Tuesday, Wednesday", "Thursday, Friday", "Saturday];
      const idx = Math.floor(Math.random() * 7);
      const correct = days[idx];
      const opts = [correct, days[(idx+1)%7], days[(idx+2)%7], days[(idx+3)%7]].sort(() => Math.random() - 0.5);
      return {
        text: "`What day of the week comes right after ${days[(idx+6)%7]}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G1-MAT-TIM-04,
    grade: Grade 1,
    subject: Mathematics,
    topic: "Time,
    subtopic: "Days of the Week",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const options = ["Friday, Monday", "Sunday, Thursday"].sort(() => Math.random() - 0.5);
      return {
        text: "`If today is Wednesday, what day of the week will it be tomorrow?`,
        options: options,
        correctAnswer: Thursday
      };
    }
  },
  {
    id: G1-MAT-TIM-05,
    grade: Grade 1,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Months of the Year",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const months = ["January, February", "March, April", "May, June", "July, August", "September, October", "November, December"];
      const idx = Math.floor(Math.random() * 12);
      const correct = months[idx];
      const opts = [correct, months[(idx+1)%12], months[(idx+2)%12], months[(idx+3)%12]].sort(() => Math.random() - 0.5);
      return {
        text: "`Which month of the year comes immediately after ${months[(idx+11)%12]}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // =========================================================================
  // GRADE 2: 35 MATERIALS (KICD MATHEMATICS SYLLABUS)
  // =========================================================================

  // --- MADA: NUMBERS (COUNTING TO 100) (5 Materials) ---
  {
    id: G2-MAT-NUM-01,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Counting Forward to 50,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const start = Math.floor(Math.random() * 20) + 10;
      const correct = start + 1;
      const opts = [correct, correct+2", correct-1", correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`Count forward from ${start}. What is the very next number?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-NUM-02,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Counting Backward from 20",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const start = Math.floor(Math.random() * 10) + 11;
      const correct = start - 1;
      const opts = [correct, correct+2, correct-2, correct+1].sort(() => Math.random() - 0.5);
      return {
        text: "`Count backward from ${start}. What is the number that comes just before it?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-NUM-03,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Number Names 11-50,
    maxUses: 5,
    usageCount: 0,
    minWords: 9,",
    generate: () => {
      const num = Math.floor(Math.random() * 40) + 11;
      const names = [Eleven", "Twelve, Thirteen", "Fourteen, Fifteen", "Sixteen, Seventeen", "Eighteen, Nineteen", "Twenty,
        Twenty-One", "Twenty-Two, Twenty-Three", "Twenty-Four, Twenty-Five", "Twenty-Six, Twenty-Seven", "Twenty-Eight, Twenty-Nine", "Thirty,
        Thirty-One", "Thirty-Two, Thirty-Three", "Thirty-Four, Thirty-Five", "Thirty-Six, Thirty-Seven", "Thirty-Eight, Thirty-Nine", "Forty,
        Forty-One", "Forty-Two, Forty-Three", "Forty-Four, Forty-Five", "Forty-Six, Forty-Seven", "Forty-Eight, Forty-Nine", "Fifty
      ];
      const correct = names[num-11];
      const opts = [correct, names[(num-11+5)%40], names[(num-11+10)%40], names[(num-11+15)%40]].sort(() => Math.random() - 0.5);
      return {
        text: "`How do you write the number ${num} in words?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G2-MAT-NUM-04,
    grade: Grade 2,
    subject: Mathematics,
    topic: "Numbers,
    subtopic: "Comparing Numbers 11-100",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 80) + 11;
      const b = Math.floor(Math.random() * 80) + 11;
      const correct = a === b ? "Equal to : (a > b ? Greater than" : "Less than);
      const opts = [Greater than", "Less than, Equal to", "Not sure].sort(() => Math.random() - 0.5);
      return {
        text: "`Compare the numbers ${a} and ${b}. Is ${a} greater than, less than, or equal to ${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G2-MAT-NUM-05,
    grade: Grade 2,
    subject: Mathematics,
    topic: "Numbers,
    subtopic: "Place Value (Tens and Ones)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const tens = Math.floor(Math.random() * 9) + 1;
      const ones = Math.floor(Math.random() * 9);
      const num = tens*10 + ones;
      const options = [`${tens} tens and ${ones} ones`, `${ones} tens and ${tens} ones`, `${tens+1} tens`, `${ones+1} ones`].sort(() => Math.random() - 0.5);
      return {
        text: "`The number ${num} is made up of how many tens and ones?`,
        options: options,
        correctAnswer: `${tens} tens and ${ones} ones`
      };
    }
  },

  // --- MADA: ADDITION (2-DIGIT NUMBERS) (5 Materials) ---
  {
    id: G2-MAT-ADD-01,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 2-Digit Numbers (No Carrying),
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 40) + 10;
      const b = Math.floor(Math.random() * 40) + 10;
      const correct = a + b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-ADD-02,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 2-Digit Numbers (With Carrying)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 25;
      const b = Math.floor(Math.random() * (99 - a)) + 1;
      const correct = a + b;
      const opts = [correct, correct+2, correct-1, correct-3].sort(() => Math.random() - 0.5);
      return {
        text: "`Add ${a} and ${b}. What is the total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-ADD-03,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 2-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 20;
      const b = Math.floor(Math.random() * 50) + 20;
      const correct = a + b;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`A shopkeeper has ${a} oranges in the morning. By evening, he gets ${b} more oranges. How many oranges does he have at the end of the day?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-ADD-04,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 2-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 40) + 10;
      const b = Math.floor(Math.random() * 40) + 10;
      const correct = a + b;
      const opts = [correct, correct+3, correct-2, correct+1].sort(() => Math.random() - 0.5);
      return {
        text: "`A class has ${a} boys and ${b} girls. How many students are in the class in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-ADD-05,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding Multiples of 10,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 9) + 1;
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = (a+b)*10;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} tens and ${b} tens?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: SUBTRACTION (2-DIGIT NUMBERS) (5 Materials) ---
  {
    id: G2-MAT-SUB-01,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 2-Digit Numbers (No Borrowing)",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 40) + 10;
      const a = b + Math.floor(Math.random() * 40) + 10;
      const correct = a - b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-SUB-02,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 2-Digit Numbers (With Borrowing),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const b = Math.floor(Math.random() * 50) + 20;
      const a = b + Math.floor(Math.random() * 30) + 10;
      const correct = a - b;
      const opts = [correct, correct+2", correct-1", correct-3].sort(() => Math.random() - 0.5);
      return {
        text: "`Subtract ${b} from ${a}. What is the result?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-SUB-03,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 2-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const b = Math.floor(Math.random() * 30) + 10;
      const a = b + Math.floor(Math.random() * 40) + 10;
      const correct = a - b;
      const opts = [correct, correct+5, correct-5, correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`A bucket has ${a} liters of water. If you pour out ${b} liters, how much water is left in the bucket?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-SUB-04,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 2-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 50) + 30;
      const left = Math.floor(Math.random() * (total - 10)) + 5;
      const taken = total - left;
      const opts = [taken, taken+2", taken-2", taken+5].sort(() => Math.random() - 0.5);
      return {
        text: "`A basket has ${total} mangoes. After eating some, ${left} mangoes are left. How many mangoes were eaten?`,
        options: opts.map(String),
        correctAnswer: String(taken)
      };
    }
  },
  {
    id: G2-MAT-SUB-05,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting Multiples of 10",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 9) + 1;
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = (a-b)*10;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} tens minus ${b} tens?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MULTIPLICATION (INTRO TO TIMES TABLES) (5 Materials) ---
  {
    id: G2-MAT-MUL-01,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Intro to Times Tables (2x, 3x),
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 3) + 2;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = a * b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MUL-02,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Intro to Times Tables (2x", 3x)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 2 * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A double is when you multiply a number by 2. What is the double of ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MUL-03,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Intro to Times Tables (2x, 3x),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const groups = Math.floor(Math.random() * 4) + 2;
      const items = Math.floor(Math.random() * 4) + 2;
      const correct = groups * items;
      const opts = [correct, correct+3", correct-3", correct+5].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${groups} groups of children. Each group has ${items} children. How many children are there in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MUL-04,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Intro to Times Tables (2x", 3x)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const rows = Math.floor(Math.random() * 4) + 2;
      const columns = Math.floor(Math.random() * 4) + 2;
      const correct = rows * columns;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangular field has ${rows} rows of plants and ${columns} plants in each row. How many plants are there in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MUL-05,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Intro to Times Tables (2x, 3x),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 3 * b;
      const opts = [correct, correct+3", correct-3", correct+6].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the product of 3 and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (SYMMETRY) (5 Materials) ---
  {
    id: G2-MAT-GEO-01,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying Symmetrical Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const options = ["Square, Triangle", "Rectangle, Circle"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these shapes can be folded in half to make two equal parts?`,
        options: options,
        correctAnswer: Square
      };
    }
  },
  {
    id: G2-MAT-GEO-02,
    grade: Grade 2,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Lines of Symmetry",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const options = ["A line of symmetry, A curved line", "A broken line, A zig-zag line"].sort(() => Math.random() - 0.5);
      return {
        text: "`What do you call the imaginary line that divides a shape into two mirror images?`,
        options: options,
        correctAnswer: A line of symmetry
      };
    }
  },
  {
    id: G2-MAT-GEO-03,
    grade: Grade 2,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Symmetry in the Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = ["A human face, A river", "A cloud, A stone"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these natural objects has a line of symmetry?`,
        options: options,
        correctAnswer: A human face
      };
    }
  },
  {
    id: G2-MAT-GEO-04,
    grade: Grade 2,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Drawing Symmetrical Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const options = ["Complete the other half, Draw a square", "Draw a circle, Draw a line"].sort(() => Math.random() - 0.5);
      return {
        text: "`What do you do to make a shape symmetrical if you only have one half?`,
        options: options,
        correctAnswer: Complete the other half
      };
    }
  },
  {
    id: G2-MAT-GEO-05,
    grade: Grade 2,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Non-Symmetrical Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const options = ["A triangle, A circle", "A square, A star"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following shapes is NOT symmetrical?`,
        options: options,
        correctAnswer: A star
      };
    }
  },

  // --- MADA: TIME (HALF PAST) (5 Materials) ---
  {
    id: G2-MAT-TIM-01,
    grade: Grade 2,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Telling Time to the Half Hour",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`Half past ${hour}`, `${hour} o'clock`, `Quarter past ${hour}`, `Quarter to ${hour}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The long hand of the clock is pointing at 6, and the short hand is pointing between ${hour} and ${hour+1}. What time is it?`,
        options: options,
        correctAnswer: `Half past ${hour}`
      };
    }
  },
  {
    id: G2-MAT-TIM-02,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Telling Time to the Half Hour,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`Half past ${hour}`, `Half past ${hour+1}`", `Half past ${hour-1}`", `Half past ${hour+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`If the time is half past ${hour}, what will the time be in one hour?`,
        options: options,
        correctAnswer: `Half past ${hour+1}`
      };
    }
  },
  {
    id: G2-MAT-TIM-03,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Telling Time to the Half Hour",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`Half past ${hour}`, `${hour} o'clock`, `Quarter past ${hour}`, `Quarter to ${hour}`].sort(() => Math.random() - 0.5);
      return {
        text: "`It is half past ${hour}. What time is it in digital format (e.g., 3:30)?`,
        options: options,
        correctAnswer: `Half past ${hour}`
      };
    }
  },
  {
    id: G2-MAT-TIM-04,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Telling Time to the Half Hour,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const options = [`Half past ${hour}`, `Half past ${hour+2}`", `Half past ${hour+1}`", `Half past ${hour-1}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The time is 7:30. How would you say this in words?`,
        options: options,
        correctAnswer: `Half past 7`
      };
    }
  },
  {
    id: G2-MAT-TIM-05,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Time in Daily Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const options = [`Half past 7`, `6 o'clock`, `Half past 8`, `7 o'clock`].sort(() => Math.random() - 0.5);
      return {
        text: "`You wake up at 7:00 in the morning. What is another way to say this time?`,
        options: options,
        correctAnswer: `7 o'clock`
      };
    }
  },

  // --- MADA: MONEY (KENYAN CURRENCY) (5 Materials) ---
  {
    id: G2-MAT-MON-01,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Identifying Kenyan Coins,
    maxUses: 5,
    usageCount: 0,
    minWords: 11,",
    generate: () => {
      const options = [1 shilling", "5 shillings, 10 shillings", "20 shillings].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a coin used in Kenya?`,
        options: options,
        correctAnswer: 10 shillings
      };
    }
  },
  {
    id: G2-MAT-MON-02,
    grade: "Grade 2",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Identifying Kenyan Banknotes,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,",
    generate: () => {
      const options = [50 shillings", "100 shillings, 200 shillings", "500 shillings].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a Kenyan banknote?`,
        options: options,
        correctAnswer: 50 shillings
      };
    }
  },
  {
    id: G2-MAT-MON-03,
    grade: "Grade 2",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Adding Money in KES,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = (Math.floor(Math.random() * 4) + 1) * 100;
      const b = (Math.floor(Math.random() * 4) + 1) * 100;
      const correct = a + b;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`If you have ${a} KES and your mother gives you ${b} KES, how much money do you have in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MON-04,
    grade: "Grade 2,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Subtracting Money in KES",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const total = (Math.floor(Math.random() * 5) + 2) * 100;
      const spent = (Math.floor(Math.random() * (total/100 - 1)) + 1) * 100;
      const correct = total - spent;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`You have ${total} KES. You buy a book for ${spent} KES. How much money do you have left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G2-MAT-MON-05,
    grade: Grade 2",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Money in Real Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => {
      const options = [100 shillings", "50 shillings, 200 shillings", "500 shillings].sort(() => Math.random() - 0.5);
      return {
        text: "`If you need to buy a loaf of bread for 50 shillings, which bill should you give the shopkeeper?`,
        options: options,
        correctAnswer: 50 shillings
      };
    }
  }
  // =========================================================================
  // GRADE 3: 35 MATERIALS (KICD MATHEMATICS SYLLABUS)
  // =========================================================================

  // --- MADA: NUMBERS (Counting, Place Value, Comparing) (5 Materials) ---
  {
    id: G3-MAT-NUM-01,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Counting to 1,000,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const start = Math.floor(Math.random() * 100) + 500;
      const correct = start + 1;
      const opts = [correct, correct+2", correct-1", correct+3].sort(() => Math.random() - 0.5);
      return {
        text: "`Count forward from ${start}. What is the very next number?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-NUM-02,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Place Value (Hundreds", Tens, Ones)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const h = Math.floor(Math.random() * 9) + 1;
      const t = Math.floor(Math.random() * 9);
      const o = Math.floor(Math.random() * 9);
      const num = h * 100 + t * 10 + o;
      const options = [`${h} hundreds, ${t} tens, ${o} ones`, `${t} hundreds, ${h} tens`, `${o} hundreds`, `${h+1} hundreds`].sort(() => Math.random() - 0.5);
      return {
        text: "`The number ${num} is made up of how many hundreds, tens, and ones?`,
        options: options,
        correctAnswer: `${h} hundreds, ${t} tens, ${o} ones`
      };
    }
  },
  {
    id: G3-MAT-NUM-03,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Comparing Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,",
    generate: () => {
      const a = Math.floor(Math.random() * 900) + 100;
      const b = Math.floor(Math.random() * 900) + 100;
      const correct = a === b ? Equal to" : (a > b ? "Greater than : Less than");
      const opts = ["Greater than, Less than", "Equal to, Not sure"].sort(() => Math.random() - 0.5);
      return {
        text: "`Compare the numbers ${a} and ${b}. Is ${a} greater than, less than, or equal to ${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G3-MAT-NUM-04,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Ordering Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 900) + 100;
      const b = a + Math.floor(Math.random() * 100) + 10;
      const c = b + Math.floor(Math.random() * 100) + 10;
      const options = [`${a}, ${b}, ${c}`, `${b}, ${a}, ${c}`, `${c}, ${b}, ${a}`, `${a}", ${c}", ${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Arrange these numbers in ascending order: ${a}, ${b}, ${c}.`,
        options: options,
        correctAnswer: `${a}, ${b}, ${c}`
      };
    }
  },
  {
    id: G3-MAT-NUM-05,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Writing Numbers in Words",
    maxUses: 5,
    usageCount: 0,
    minWords: 10,
    generate: () => {
      const num = Math.floor(Math.random() * 900) + 100;
      const words = ["One Hundred, Two Hundred", "Three Hundred, Four Hundred", "Five Hundred, Six Hundred", "Seven Hundred, Eight Hundred", "Nine Hundred];
      const h = Math.floor(num/100);
      const correct = words[h-1] + (num%100 !== 0 ? ` and ${num%100}` : );
      const opts = [correct, words[h%9], words[(h+1)%9], "One Thousand].sort(() => Math.random() - 0.5);
      return {
        text: "`How do you write the number ${num} in words?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: ADDITION (3-Digit Numbers) (5 Materials) ---
  {
    id: G3-MAT-ADD-01,
    grade: Grade 3,
    subject: Mathematics,
    topic: "Addition,
    subtopic: "Adding 3-Digit Numbers (No Carrying)",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 400) + 100;
      const b = Math.floor(Math.random() * 400) + 100;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-ADD-02,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 3-Digit Numbers (With Carrying),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 400) + 100;
      const b = Math.floor(Math.random() * (899 - a)) + 100;
      const correct = a + b;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`Add ${a} and ${b}. What is the total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-ADD-03,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 3-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 500) + 100;
      const b = Math.floor(Math.random() * 500) + 100;
      const correct = a + b;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A factory makes ${a} toys on Monday and ${b} toys on Tuesday. How many toys does it make in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-ADD-04,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 3-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 400) + 100;
      const b = Math.floor(Math.random() * 400) + 100;
      const correct = a + b;
      const opts = [correct, correct+3", correct-2", correct+1].sort(() => Math.random() - 0.5);
      return {
        text: "`A school has ${a} boys and ${b} girls. How many students are in the school in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-ADD-05,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 3-Digit Numbers (Word Problems)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 300) + 100;
      const b = Math.floor(Math.random() * (899 - a)) + 100;
      const correct = a + b;
      const opts = [correct, correct+2, correct-3, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A farmer harvested ${a} kg of maize in the morning and ${b} kg in the afternoon. How many kg of maize did he harvest in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: SUBTRACTION (3-Digit Numbers) (5 Materials) ---
  {
    id: G3-MAT-SUB-01,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 3-Digit Numbers (No Borrowing),
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 400) + 100;
      const a = b + Math.floor(Math.random() * 400) + 100;
      const correct = a - b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-SUB-02,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 3-Digit Numbers (With Borrowing)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const b = Math.floor(Math.random() * 400) + 100;
      const a = b + Math.floor(Math.random() * 400) + 100;
      const correct = a - b;
      const opts = [correct, correct+5, correct-5, correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`Subtract ${b} from ${a}. What is the result?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-SUB-03,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 3-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 600) + 300;
      const taken = Math.floor(Math.random() * (total - 100)) + 100;
      const correct = total - taken;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A water tank holds ${total} liters. If ${taken} liters are used, how many liters are left in the tank?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-SUB-04,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 3-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 500) + 300;
      const left = Math.floor(Math.random() * (total - 100)) + 100;
      const removed = total - left;
      const opts = [removed, removed+5, removed-5, removed+10].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} beans. After removing some, ${left} beans remain. How many beans were removed?`,
        options: opts.map(String),
        correctAnswer: String(removed)
      };
    }
  },
  {
    id: G3-MAT-SUB-05,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 3-Digit Numbers (Word Problems),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 500) + 200;
      const b = Math.floor(Math.random() * (a - 100)) + 100;
      const correct = a - b;
      const opts = [correct, correct+2", correct-3", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A book has ${a} pages. A student has already read ${b} pages. How many pages does he have left to read?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MULTIPLICATION (Times Tables 2, 3, 4, 5) (5 Materials) ---
  {
    id: G3-MAT-MUL-01,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Times Table of 2",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 2 * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 2 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MUL-02,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Times Table of 3,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 3 * b;
      const opts = [correct, correct+3", correct-3", correct+6].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 3 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MUL-03,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Times Table of 4",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 4 * b;
      const opts = [correct, correct+4, correct-4, correct+8].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 4 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MUL-04,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Times Table of 5,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = 5 * b;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 5 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MUL-05,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Multiplication Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const rows = Math.floor(Math.random() * 4) + 2;
      const cols = Math.floor(Math.random() * 4) + 2;
      const correct = rows * cols;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A classroom has ${rows} rows of desks. Each row has ${cols} desks. How many desks are in the classroom?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DIVISION (Sharing and Grouping) (5 Materials) ---
  {
    id: G3-MAT-DIV-01,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Sharing (Dividing into equal groups),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const total = Math.floor(Math.random() * 4) + 4;
      const groups = Math.floor(Math.random() * (total - 1)) + 2;
      const correct = Math.floor(total / groups);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${total} cookies to be shared equally among ${groups} children. How many cookies will each child get?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-DIV-02,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Division,
    subtopic: "Grouping (Finding the number of groups)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 6;
      const each = Math.floor(Math.random() * (total - 1)) + 2;
      const correct = Math.floor(total / each);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A box holds ${total} pencils. If each student gets ${each} pencils, how many students can receive pencils?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-DIV-03,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Dividing 2-Digit by 1-Digit,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const total = Math.floor(Math.random() * 4) + 4;
      const groups = 2;
      const correct = Math.floor(total / groups);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${total} divided by ${groups}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-DIV-04,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Division,
    subtopic: "Division Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 6;
      const groups = Math.floor(Math.random() * (total - 1)) + 2;
      const correct = Math.floor(total / groups);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A farmer has ${total} eggs. He packs them into boxes. Each box holds ${groups} eggs. How many boxes does he need?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-DIV-05,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Division Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 4) + 4;
      const groups = 2;
      const correct = Math.floor(total / groups);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${total} chairs to be arranged in ${groups} equal rows. How many chairs will be in each row?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: FRACTIONS (Proper Fractions) (5 Materials) ---
  {
    id: G3-MAT-FRA-01,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Halves (1/2)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["1/2, 1/4", "1/3, 1"].sort(() => Math.random() - 0.5);
      return {
        text: "`If you cut a cake into two equal parts, what fraction represents one part?`,
        options: opts,
        correctAnswer: 1/2
      };
    }
  },
  {
    id: G3-MAT-FRA-02,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Quarters (1/4)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["1/4, 1/2", "1/3, 1/5"].sort(() => Math.random() - 0.5);
      return {
        text: "`If you cut a water melon into four equal parts, what fraction represents one part?`,
        options: opts,
        correctAnswer: 1/4
      };
    }
  },
  {
    id: G3-MAT-FRA-03,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Thirds (1/3)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["1/3, 1/2", "1/4, 1/6"].sort(() => Math.random() - 0.5);
      return {
        text: "`If you cut a pizza into three equal parts, what fraction represents one part?`,
        options: opts,
        correctAnswer: 1/3
      };
    }
  },
  {
    id: G3-MAT-FRA-04,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Writing Fractions from Pictures",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 4) + 2;
      const shaded = Math.floor(Math.random() * (total - 1)) + 1;
      const correct = `${shaded}/${total}`;
      const opts = [correct, `${shaded+1}/${total}`, `${shaded}/${total+1}`, `${shaded-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${total} equal parts in a shape. ${shaded} parts are colored. What fraction is colored?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G3-MAT-FRA-05,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Fractions",
    subtopic: "Fractions in Real Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => {
      const opts = [1/2 of a pizza", "A whole pizza, 1/4 of a pizza", "1/3 of a pizza].sort(() => Math.random() - 0.5);
      return {
        text: "`If you share a pizza equally with your friend, what fraction of the pizza do you eat?`,
        options: opts,
        correctAnswer: 1/2 of a pizza
      };
    }
  },

  // --- MADA: MEASUREMENTS (Length and Capacity) (5 Materials) ---
  {
    id: G3-MAT-MEA-01,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Length (Meters and Centimeters),
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 9) + 1;
      const opts = [`${a}m ${b}cm`, `${a+1}m ${b}cm`", `${a}m ${b+2}cm`", `${a}m ${b+1}cm`].sort(() => Math.random() - 0.5);
      return {
        text: "`Convert ${a} meters and ${b} centimeters into a single written measurement.`,
        options: opts,
        correctAnswer: `${a}m ${b}cm`
      };
    }
  },
  {
    id: G3-MAT-MEA-02,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Lengths",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["3 meters, 2 meters", "5 meters, 1 meter"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these is the longest length?`,
        options: opts,
        correctAnswer: 5 meters
      };
    }
  },
  {
    id: G3-MAT-MEA-03,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Capacity (Liters and Milliliters)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["1 liter, 100 ml", "500 ml, 2 liters"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these is the smallest capacity?`,
        options: opts,
        correctAnswer: 100 ml
      };
    }
  },
  {
    id: G3-MAT-MEA-04,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Comparing Capacities",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["A large bucket, A small cup", "A kettle, A bottle"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these holds the most water?`,
        options: opts,
        correctAnswer: A large bucket
      };
    }
  },
  {
    id: G3-MAT-MEA-05,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Measurement,
    subtopic: "Measurement Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A stick is ${a} meters long. Another stick is ${b} meters long. If you put them end to end, what is the total length?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Shapes and Angles) (5 Materials) ---
  {
    id: G3-MAT-GEO-01,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Identifying 2D Shapes,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,",
    generate: () => {
      const opts = [Square", "Circle, Triangle", "Rectangle].sort(() => Math.random() - 0.5);
      return {
        text: "`Which shape has 4 equal sides?`,
        options: opts,
        correctAnswer: Square
      };
    }
  },
  {
    id: G3-MAT-GEO-02,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Identifying 2D Shapes,
    maxUses: 5,
    usageCount: 0,
    minWords: 12,",
    generate: () => {
      const opts = [Triangle", "Circle, Square", "Rectangle].sort(() => Math.random() - 0.5);
      return {
        text: "`Which shape has 3 corners and 3 sides?`,
        options: opts,
        correctAnswer: Triangle
      };
    }
  },
  {
    id: G3-MAT-GEO-03,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Identifying 3D Shapes,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,",
    generate: () => {
      const opts = [Cube", "Sphere, Cylinder", "Cuboid].sort(() => Math.random() - 0.5);
      return {
        text: "`Which 3D shape has 6 equal square faces?`,
        options: opts,
        correctAnswer: Cube
      };
    }
  },
  {
    id: G3-MAT-GEO-04,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Introduction to Angles,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [Corner", "Line, Curve", "Side].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the point where two sides of a shape meet called?`,
        options: opts,
        correctAnswer: Corner
      };
    }
  },
  {
    id: G3-MAT-GEO-05,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Geometry in the Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [A round plate", "A square window, A triangular roof", "A rectangular book].sort(() => Math.random() - 0.5);
      return {
        text: "`Which object has a circular shape?`,
        options: opts,
        correctAnswer: A round plate
      };
    }
  },

  // --- MADA: TIME (Quarter Past and Quarter To) (5 Materials) ---
  {
    id: G3-MAT-TIM-01,
    grade: "Grade 3",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Quarter Past,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const opts = [`Quarter past ${hour}`, `Half past ${hour}`", `${hour} o'clock`", `Quarter to ${hour}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The long hand of the clock is pointing at 3, and the short hand is pointing just past ${hour}. What time is it?`,
        options: opts,
        correctAnswer: `Quarter past ${hour}`
      };
    }
  },
  {
    id: G3-MAT-TIM-02,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Quarter To",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const opts = [`Quarter to ${hour+1}`, `Quarter past ${hour}`, `Half past ${hour}`, `${hour} o'clock`].sort(() => Math.random() - 0.5);
      return {
        text: "`The long hand of the clock is pointing at 9, and the short hand is pointing just before ${hour+1}. What time is it?`,
        options: opts,
        correctAnswer: `Quarter to ${hour+1}`
      };
    }
  },
  {
    id: G3-MAT-TIM-03,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Reading the Clock,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const opts = [`Half past ${hour}`, `Quarter past ${hour}`", `${hour} o'clock`", `Quarter to ${hour}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The long hand is pointing at 6, and the short hand is pointing between ${hour} and ${hour+1}. What time is it?`,
        options: opts,
        correctAnswer: `Half past ${hour}`
      };
    }
  },
  {
    id: G3-MAT-TIM-04,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Time,
    subtopic: "Time Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const opts = [`Quarter past ${hour}`, `Half past ${hour}`, `${hour} o'clock`, `Quarter to ${hour}`].sort(() => Math.random() - 0.5);
      return {
        text: "`School starts at quarter past ${hour}. What time does the clock show?`,
        options: opts,
        correctAnswer: `Quarter past ${hour}`
      };
    }
  },
  {
    id: G3-MAT-TIM-05,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Time Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const hour = Math.floor(Math.random() * 12) + 1;
      const opts = [`Quarter to ${hour+1}`, `Half past ${hour}`", `Quarter past ${hour}`", `${hour} o'clock`].sort(() => Math.random() - 0.5);
      return {
        text: "`Lunch break is at quarter to ${hour+1}. What time does the clock show?`,
        options: opts,
        correctAnswer: `Quarter to ${hour+1}`
      };
    }
  },

  // --- MADA: MONEY (Adding and Subtracting KES) (5 Materials) ---
  {
    id: G3-MAT-MON-01,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Identifying Kenyan Money",
    maxUses: 5,
    usageCount: 0,
    minWords: 12,
    generate: () => {
      const opts = ["50 shillings, 10 shillings", "100 shillings, 200 shillings"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a Kenyan banknote?`,
        options: opts,
        correctAnswer: 50 shillings
      };
    }
  },
  {
    id: G3-MAT-MON-02,
    grade: Grade 3,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Adding Money in KES",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = (Math.floor(Math.random() * 9) + 1) * 100;
      const b = (Math.floor(Math.random() * 9) + 1) * 100;
      const correct = a + b;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`If you have ${a} KES and your father gives you ${b} KES, how much money do you have in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MON-03,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Subtracting Money in KES,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const total = (Math.floor(Math.random() * 9) + 2) * 100;
      const spent = (Math.floor(Math.random() * (total/100 - 1)) + 1) * 100;
      const correct = total - spent;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`You have ${total} KES. You buy a bag for ${spent} KES. How much money do you have left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MON-04,
    grade: "Grade 3,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Money Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const price = (Math.floor(Math.random() * 9) + 1) * 100;
      const given = price + (Math.floor(Math.random() * 4) + 1) * 100;
      const correct = given - price;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`A book costs ${price} KES. You pay with a ${given} KES note. How much change should you receive?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G3-MAT-MON-05,
    grade: Grade 3",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Money in Real Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const total = (Math.floor(Math.random() * 9) + 1) * 100;
      const price = (Math.floor(Math.random() * (total/100 - 1)) + 1) * 100;
      const correct = total - price;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`You have ${total} KES. You want to buy a toy that costs ${price} KES. How much money will you have left after buying the toy?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD MATHEMATICS SYLLABUS)
  // =========================================================================

  // --- MADA: NUMBERS (Place Value up to 100,000) (5 Materials) ---
  {
    id: G4-MAT-NUM-01,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Place Value up to 100",000",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const t = Math.floor(Math.random() * 9) + 1; // Ten-thousands
      const th = Math.floor(Math.random() * 9); // Thousands
      const h = Math.floor(Math.random() * 9); // Hundreds
      const te = Math.floor(Math.random() * 9); // Tens
      const o = Math.floor(Math.random() * 9); // Ones
      const num = t * 10000 + th * 1000 + h * 100 + te * 10 + o;
      const options = [
        `${t} ten-thousands, ${th} thousands, ${h} hundreds, ${te} tens, ${o} ones`,
        `${th} ten-thousands, ${t} thousands`,
        `${h} ten-thousands`,
        `${num+1}`
      ].sort(() => Math.random() - 0.5);
      return {
        text: "`The number ${num} is made up of how many ten-thousands, thousands, hundreds, tens, and ones?`,
        options: options,
        correctAnswer: `${t} ten-thousands, ${th} thousands, ${h} hundreds, ${te} tens, ${o} ones`
      };
    }
  },
  {
    id: G4-MAT-NUM-02,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Reading and Writing Numbers in Words,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => {
      const num = Math.floor(Math.random() * 90000) + 10000;
      const words = [Ten", "Twenty, Thirty", "Forty, Fifty", "Sixty, Seventy", "Eighty, Ninety"];
      const t = Math.floor(num/10000);
      const rest = num % 10000;
      const correct = words[t-1] + " Thousand + (rest !== 0 ? ` ${rest}` : );
      const opts = [correct, words[t%9] + " Thousand, One Hundred Thousand", words[(t+1)%9] + " Thousand].sort(() => Math.random() - 0.5);
      return {
        text: "`How do you write the number ${num} in words?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-NUM-03,
    grade: Grade 4,
    subject: Mathematics,
    topic: "Numbers,
    subtopic: "Comparing Numbers up to 100",000",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 90000) + 10000;
      const b = Math.floor(Math.random() * 90000) + 10000;
      const correct = a === b ? "Equal to : (a > b ? Greater than" : "Less than);
      const opts = [Greater than", "Less than, Equal to", "Not sure].sort(() => Math.random() - 0.5);
      return {
        text: "`Compare the numbers ${a} and ${b}. Is ${a} greater than, less than, or equal to ${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-NUM-04,
    grade: Grade 4,
    subject: Mathematics,
    topic: "Numbers,
    subtopic: "Ordering Numbers up to 100",000",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 90000) + 10000;
      const b = a + Math.floor(Math.random() * 10000) + 1000;
      const c = b + Math.floor(Math.random() * 10000) + 1000;
      const options = [`${a}, ${b}, ${c}`, `${b}, ${a}, ${c}`, `${c}, ${b}, ${a}`, `${a}, ${c}, ${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Arrange these numbers in ascending order: ${a}, ${b}, ${c}.`,
        options: options,
        correctAnswer: `${a}, ${b}, ${c}`
      };
    }
  },
  {
    id: G4-MAT-NUM-05,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Writing Numbers in Words (100,000),
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => {
      const num = Math.floor(Math.random() * 90000) + 10000;
      const words = [Ten", "Twenty, Thirty", "Forty, Fifty", "Sixty, Seventy", "Eighty, Ninety"];
      const t = Math.floor(num/10000);
      const rest = num % 10000;
      const correct = words[t-1] + " Thousand + (rest !== 0 ? ` ${rest}` : );
      const opts = [correct, words[t%9] + " Thousand, One Hundred Thousand", words[(t+1)%9] + " Thousand].sort(() => Math.random() - 0.5);
      return {
        text: "`Write the number ${num} in words.`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: ADDITION (4-Digit Numbers) (5 Materials) ---
  {
    id: G4-MAT-ADD-01,
    grade: Grade 4,
    subject: Mathematics,
    topic: "Addition,
    subtopic: "Adding 4-Digit Numbers (No Carrying)",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 4000) + 1000;
      const b = Math.floor(Math.random() * 4000) + 1000;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-ADD-02,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 4-Digit Numbers (With Carrying),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 4000) + 1000;
      const b = Math.floor(Math.random() * (8999 - a)) + 1000;
      const correct = a + b;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Add ${a} and ${b}. What is the total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-ADD-03,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 4-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 5000) + 1000;
      const b = Math.floor(Math.random() * 5000) + 1000;
      const correct = a + b;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`A store sold ${a} items last week and ${b} items this week. How many items did they sell in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-ADD-04,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Addition",
    subtopic: "Adding 4-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 4000) + 1000;
      const b = Math.floor(Math.random() * 4000) + 1000;
      const correct = a + b;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`A school has ${a} students in the morning stream and ${b} students in the afternoon stream. How many students are there in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-ADD-05,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Addition,
    subtopic: "Adding 4-Digit Numbers (Word Problems)",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 4000) + 1000;
      const b = Math.floor(Math.random() * (8999 - a)) + 1000;
      const correct = a + b;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A farmer harvested ${a} kg of maize and ${b} kg of beans. How many kg of produce did he harvest in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: SUBTRACTION (4-Digit Numbers) (5 Materials) ---
  {
    id: G4-MAT-SUB-01,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 4-Digit Numbers (No Borrowing),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const b = Math.floor(Math.random() * 4000) + 1000;
      const a = b + Math.floor(Math.random() * 4000) + 1000;
      const correct = a - b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-SUB-02,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 4-Digit Numbers (With Borrowing)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const b = Math.floor(Math.random() * 4000) + 1000;
      const a = b + Math.floor(Math.random() * 4000) + 1000;
      const correct = a - b;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Subtract ${b} from ${a}. What is the result?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-SUB-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 4-Digit Numbers,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const total = Math.floor(Math.random() * 6000) + 3000;
      const used = Math.floor(Math.random() * (total - 1000)) + 1000;
      const correct = total - used;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`A fuel tank holds ${total} liters. ${used} liters are used. How many liters are left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-SUB-04,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Subtraction,
    subtopic: "Subtracting 4-Digit Numbers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const total = Math.floor(Math.random() * 5000) + 3000;
      const left = Math.floor(Math.random() * (total - 1000)) + 1000;
      const removed = total - left;
      const opts = [removed, removed+100, removed-100, removed+200].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag contains ${total} stones. After removing some, ${left} stones remain. How many stones were removed?`,
        options: opts.map(String),
        correctAnswer: String(removed)
      };
    }
  },
  {
    id: G4-MAT-SUB-05,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Subtraction",
    subtopic: "Subtracting 4-Digit Numbers (Word Problems),
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 5000) + 2000;
      const read = Math.floor(Math.random() * (total - 1000)) + 1000;
      const correct = total - read;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`A book has ${total} pages. A student has read ${read} pages. How many pages are left to read?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MULTIPLICATION (Times Tables 2-6) (5 Materials) ---
  {
    id: G4-MAT-MUL-01,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Times Table of 2",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = 2 * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 2 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MUL-02,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Times Table of 3,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = 3 * b;
      const opts = [correct, correct+3", correct-3", correct+6].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 3 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MUL-03,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Times Table of 4",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = 4 * b;
      const opts = [correct, correct+4, correct-4, correct+8].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 4 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MUL-04,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Multiplication",
    subtopic: "Times Table of 5,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = 5 * b;
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 5 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MUL-05,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Multiplication,
    subtopic: "Times Table of 6",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const b = Math.floor(Math.random() * 9) + 1;
      const correct = 6 * b;
      const opts = [correct, correct+6, correct-6, correct+12].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 6 times ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DIVISION (Dividing 2-Digit by 1-Digit) (5 Materials) ---
  {
    id: G4-MAT-DIV-01,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Dividing 2-Digit by 1-Digit,
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const d = Math.floor(Math.random() * 8) + 2;
      const q = Math.floor(Math.random() * 5) + 2;
      const total = d * q;
      const opts = [q, q+1", q-1", q+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${total} divided by ${d}?`,
        options: opts.map(String),
        correctAnswer: String(q)
      };
    }
  },
  {
    id: G4-MAT-DIV-02,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Division,
    subtopic: "Dividing 2-Digit by 1-Digit",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const d = Math.floor(Math.random() * 8) + 2;
      const q = Math.floor(Math.random() * 5) + 2;
      const total = d * q;
      const opts = [q, q+2, q-1, q+3].sort(() => Math.random() - 0.5);
      return {
        text: "`${total} students are sitting in ${d} equal rows. How many students are in each row?`,
        options: opts.map(String),
        correctAnswer: String(q)
      };
    }
  },
  {
    id: G4-MAT-DIV-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Division Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const d = Math.floor(Math.random() * 8) + 2;
      const q = Math.floor(Math.random() * 5) + 2;
      const total = d * q;
      const opts = [q, q+1", q-1", q+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A baker baked ${total} loaves of bread. He puts them into ${d} baskets. How many loaves are in each basket?`,
        options: opts.map(String),
        correctAnswer: String(q)
      };
    }
  },
  {
    id: G4-MAT-DIV-04,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Division,
    subtopic: "Division Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const d = Math.floor(Math.random() * 7) + 3;
      const q = Math.floor(Math.random() * 4) + 2;
      const total = d * q;
      const opts = [q, q+1, q-1, q+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A farmer has ${total} oranges to share equally among ${d} children. How many oranges does each child get?`,
        options: opts.map(String),
        correctAnswer: String(q)
      };
    }
  },
  {
    id: G4-MAT-DIV-05,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Division",
    subtopic: "Division Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const d = Math.floor(Math.random() * 6) + 2;
      const q = Math.floor(Math.random() * 4) + 2;
      const total = d * q;
      const opts = [q, q+1", q-1", q+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A box contains ${total} pens. They are shared equally among ${d} students. How many pens does each student get?`,
        options: opts.map(String),
        correctAnswer: String(q)
      };
    }
  },

  // --- MADA: FRACTIONS (Proper Fractions) (5 Materials) ---
  {
    id: G4-MAT-FRA-01,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Writing Fractions",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["1/2, 1/3", "1/4, 1/5"].sort(() => Math.random() - 0.5);
      return {
        text: "`What fraction represents one part of a whole divided into 3 equal parts?`,
        options: opts,
        correctAnswer: 1/3
      };
    }
  },
  {
    id: G4-MAT-FRA-02,
    grade: Grade 4,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Writing Fractions from Diagrams",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = Math.floor(Math.random() * 4) + 2;
      const shaded = Math.floor(Math.random() * (total - 1)) + 1;
      const correct = `${shaded}/${total}`;
      const opts = [correct, `${shaded+1}/${total}`, `${shaded}/${total+1}`, `${shaded-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A shape is divided into ${total} equal parts. ${shaded} parts are shaded. What fraction is shaded?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-FRA-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Fractions",
    subtopic: "Equivalent Fractions,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => {
      const opts = [1/2", "2/4, 3/4", "1/4].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of these fractions is equivalent to 1/2?`,
        options: opts,
        correctAnswer: 2/4
      };
    }
  },
  {
    id: G4-MAT-FRA-04,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Fractions",
    subtopic: "Adding Fractions with the Same Denominator,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const d = Math.floor(Math.random() * 3) + 3;
      const a = Math.floor(Math.random() * (d-1)) + 1;
      const b = Math.floor(Math.random() * (d-a)) + 1;
      const correct = `${a+b}/${d}`;
      const opts = [correct, `${a+b+1}/${d}`", `${a+b}/${d+1}`", `${a+b-1}/${d}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a}/${d} and ${b}/${d}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-FRA-05,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Fractions in Real Life",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const opts = ["1/4 of the pizza, 1/2 of the pizza", "1/3 of the pizza, Whole pizza"].sort(() => Math.random() - 0.5);
      return {
        text: "`If a pizza is cut into 4 equal slices and you eat 1 slice, what fraction of the pizza did you eat?`,
        options: opts,
        correctAnswer: 1/4 of the pizza
      };
    }
  },

  // --- MADA: DECIMALS (Introduction to Tenths) (5 Materials) ---
  {
    id: G4-MAT-DEC-01,
    grade: Grade 4,
    subject: Mathematics",
    topic: "Decimals,
    subtopic: "Introduction to Tenths",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const opts = ["0.1, 0.2", "0.5, 1.0"].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the decimal representation of one tenth?`,
        options: opts,
        correctAnswer: 0.1
      };
    }
  },
  {
    id: G4-MAT-DEC-02,
    grade: Grade 4,
    subject: Mathematics",
    topic: "Decimals,
    subtopic: "Writing Tenths as Decimals",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const num = Math.floor(Math.random() * 9) + 1;
      const correct = `0.${num}`;
      const opts = [correct, `0.${num+1}`, `0.${num-1}`, `1.${num}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Write ${num} tenths as a decimal.`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-DEC-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Decimals",
    subtopic: "Adding Decimals (Tenths),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = `0.${a+b}`;
      const opts = [correct, `0.${a+b+1}`", `0.${a+b-1}`", `0.${a+b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of 0.${a} and 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-DEC-04,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Decimals,
    subtopic: "Subtracting Decimals (Tenths)",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const a = Math.floor(Math.random() * 8) + 1;
      const b = Math.floor(Math.random() * a) + 1;
      const correct = `0.${a-b}`;
      const opts = [correct, `0.${a-b+1}`, `0.${a-b-1}`, `0.${a-b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the result of 0.${a} minus 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G4-MAT-DEC-05,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Decimals",
    subtopic: "Decimals in Real Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [0.5 kg", "0.1 kg, 1 kg", "2 kg].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag of sugar weighs 0.5 kg. Which decimal represents this?`,
        options: opts,
        correctAnswer: 0.5 kg
      };
    }
  },

  // --- MADA: MEASUREMENTS (Length, Mass, Capacity) (5 Materials) ---
  {
    id: G4-MAT-MEA-01,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Length (Km, m, cm),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [Kilometers", "Meters, Centimeters", "Millimeters].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the best unit to measure the distance between two cities?`,
        options: opts,
        correctAnswer: Kilometers
      };
    }
  },
  {
    id: G4-MAT-MEA-02,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Length (Km, m, cm),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [500 meters", "500 centimeters, 5 kilometers", "500 millimeters].sort(() => Math.random() - 0.5);
      return {
        text: "`Which is the longest length?`,
        options: opts,
        correctAnswer: 5 kilometers
      };
    }
  },
  {
    id: G4-MAT-MEA-03,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Mass (Kg, g),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [Kilograms", "Grams, Tons", "Milligrams].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the best unit to measure the weight of a person?`,
        options: opts,
        correctAnswer: Kilograms
      };
    }
  },
  {
    id: G4-MAT-MEA-04,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Capacity (L, ml),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [Liters", "Milliliters, Gallons", "Cups].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the best unit to measure the amount of water in a swimming pool?`,
        options: opts,
        correctAnswer: Liters
      };
    }
  },
  {
    id: G4-MAT-MEA-05,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Measurement",
    subtopic: "Measurement Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = a + b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A rope is ${a} meters long. Another rope is ${b} meters long. What is the total length of both ropes?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Perimeter and Area) (5 Materials) ---
  {
    id: G4-MAT-GEO-01,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying 2D Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 13,
    generate: () => {
      const opts = ["Square, Circle", "Triangle, Rectangle"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which shape has 2 pairs of equal sides and 4 right angles?`,
        options: opts,
        correctAnswer: Rectangle
      };
    }
  },
  {
    id: G4-MAT-GEO-02,
    grade: Grade 4,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Perimeter of Simple Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 2;
      const b = Math.floor(Math.random() * 5) + 2;
      const correct = 2 * (a + b);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangle has a length of ${a} cm and a width of ${b} cm. What is its perimeter?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-GEO-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Area of Squares and Rectangles,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = a * b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangle has a length of ${a} cm and a width of ${b} cm. What is its area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-GEO-04,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Identifying 3D Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => {
      const opts = ["Cube, Sphere", "Cylinder, Cuboid"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which 3D shape has a circular base and a curved surface?`,
        options: opts,
        correctAnswer: Cylinder
      };
    }
  },
  {
    id: G4-MAT-GEO-05,
    grade: Grade 4,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Geometry Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 2;
      const correct = a * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A square has a side length of ${a} cm. What is its area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: TIME (am/pm and 24-Hour Clock) (5 Materials) ---
  {
    id: G4-MAT-TIM-01,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Reading Time (am/pm),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [8:00 am", "8:00 pm, 7:00 am", "7:00 pm].sort(() => Math.random() - 0.5);
      return {
        text: "`If the time is 8 o'clock in the morning, how is it written?`,
        options: opts,
        correctAnswer: 8:00 am
      };
    }
  },
  {
    id: G4-MAT-TIM-02,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Reading Time (am/pm),
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [3:00 pm", "3:00 am, 4:00 pm", "2:00 pm].sort(() => Math.random() - 0.5);
      return {
        text: "`If the time is 3 o'clock in the afternoon, how is it written?`,
        options: opts,
        correctAnswer: 3:00 pm
      };
    }
  },
  {
    id: G4-MAT-TIM-03,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Converting 24-Hour Clock,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [15:00", "14:00, 16:00", "13:00].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 3:00 pm in 24-hour format?`,
        options: opts,
        correctAnswer: 15:00
      };
    }
  },
  {
    id: G4-MAT-TIM-04,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Converting 24-Hour Clock,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => {
      const opts = [10:00 pm", "10:00 am, 9:00 pm", "9:00 am].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 22:00 in am/pm format?`,
        options: opts,
        correctAnswer: 10:00 pm
      };
    }
  },
  {
    id: G4-MAT-TIM-05,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Time",
    subtopic: "Time Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => {
      const opts = [1 hour", "2 hours, 30 minutes", "45 minutes].sort(() => Math.random() - 0.5);
      return {
        text: "`If school starts at 8:00 am and ends at 3:00 pm, how long is the school day?`,
        options: opts,
        correctAnswer: 7 hours
      };
    }
  },

  // --- MADA: MONEY (Adding and Subtracting KES) (5 Materials) ---
  {
    id: G4-MAT-MON-01,
    grade: "Grade 4",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Adding Money in KES,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = (Math.floor(Math.random() * 9) + 1) * 100;
      const b = (Math.floor(Math.random() * 9) + 1) * 100;
      const correct = a + b;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`If you have ${a} KES and receive ${b} KES, how much money do you have in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MON-02,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Subtracting Money in KES",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const total = (Math.floor(Math.random() * 9) + 2) * 100;
      const spent = (Math.floor(Math.random() * (total/100 - 1)) + 1) * 100;
      const correct = total - spent;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`You have ${total} KES. You spend ${spent} KES on a book. How much money do you have left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MON-03,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Money Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const price = (Math.floor(Math.random() * 9) + 1) * 100;
      const given = price + (Math.floor(Math.random() * 4) + 1) * 100;
      const correct = given - price;
      const opts = [correct, correct+100", correct-100", correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`A shirt costs ${price} KES. You pay with a ${given} KES note. How much change should you receive?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MON-04,
    grade: "Grade 4,
    subject: Mathematics",
    topic: "Money,
    subtopic: "Money Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const total = (Math.floor(Math.random() * 9) + 1) * 100;
      const price = (Math.floor(Math.random() * (total/100 - 1)) + 1) * 100;
      const correct = total - price;
      const opts = [correct, correct+100, correct-100, correct+200].sort(() => Math.random() - 0.5);
      return {
        text: "`You have ${total} KES. A toy costs ${price} KES. How much money will you have left?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G4-MAT-MON-05,
    grade: Grade 4",
    subject: "Mathematics",
    topic: "Money",
    subtopic: "Money in Real Life,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => {
      const options = [The total cost is 1200 KES.", "The total cost is 1000 KES., The total cost is 1400 KES.", "The total cost is 800 KES.].sort(() => Math.random() - 0.5);
      return {
        text: "`A book costs 500 KES and a bag costs 700 KES. What is the total cost?`,
        options: options,
        correctAnswer: The total cost is 1200 KES.
      };
    }
  }
  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD JUNIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: NUMBERS (INTEGERS) (5 Materials) ---
  {
    id: G7-MAT-INT-01,
    grade: "Grade 7",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Integers (Positive and Negative),
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const opts = [`-${a}`, `${a}`", `-${b}`", `${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following is a negative integer?`,
        options: opts,
        correctAnswer: `-${a}`
      };
    }
  },
  {
    id: G7-MAT-INT-02,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Integers (Positive and Negative)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 20) - 10;
      const opts = [a, a+1, a-1, a+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the integer that is 2 less than ${a+2}?`,
        options: opts.map(String),
        correctAnswer: String(a)
      };
    }
  },
  {
    id: G7-MAT-INT-03,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Adding Integers,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a + b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-INT-04,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Subtracting Integers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 20) + 1;
      const b = Math.floor(Math.random() * (a - 1)) + 1;
      const correct = a - b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-INT-05,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Operations on Integers,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a + b;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`If you gain ${a} points and then lose ${b} points, what is your final score?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: FRACTIONS (Operations) (5 Materials) ---
  {
    id: G7-MAT-FRA-01,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Adding Fractions (Different Denominators)",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = `${a+b}/6`;
      const opts = [correct, `${a+b+1}/6`, `${a+b}/7`, `${a+b-1}/6`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of ${a}/6 and ${b}/6?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-FRA-02,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Fractions",
    subtopic: "Subtracting Fractions (Different Denominators),
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * a) + 1;
      const correct = `${a-b}/6`;
      const opts = [correct, `${a-b+1}/6`", `${a-b}/7`", `${a-b-1}/6`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the result of ${a}/6 minus ${b}/6?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-FRA-03,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Multiplying Fractions",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = `${a*b}/${5*5}`;
      const opts = [correct, `${a*b+1}/${25}`, `${a*b}/26`, `${a*b-1}/${25}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the product of ${a}/5 and ${b}/5?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-FRA-04,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Fractions",
    subtopic: "Dividing Fractions,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = `${a}/${b}`;
      const opts = [correct, `${a+1}/${b}`", `${a}/${b+1}`", `${a-1}/${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a}/5 divided by ${b}/5?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-FRA-05,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Fractions,
    subtopic: "Fractions Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const correct = `${a+b}`;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`If you eat ${a}/10 of a cake and your friend eats ${b}/10, what fraction of the cake has been eaten in total?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DECIMALS (Operations) (4 Materials) ---
  {
    id: G7-MAT-DEC-01,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Decimals",
    subtopic: "Adding Decimals,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 100) + 1;
      const b = Math.floor(Math.random() * 100) + 1;
      const correct = `0.${a+b}`;
      const opts = [correct, `0.${a+b+1}`", `0.${a+b-1}`", `0.${a+b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of 0.${a} and 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-DEC-02,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Decimals,
    subtopic: "Subtracting Decimals",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 100) + 10;
      const b = Math.floor(Math.random() * (a-1)) + 1;
      const correct = `0.${a-b}`;
      const opts = [correct, `0.${a-b+1}`, `0.${a-b-1}`, `0.${a-b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the result of 0.${a} minus 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-DEC-03,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Decimals",
    subtopic: "Multiplying Decimals,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = `0.${a*b}`;
      const opts = [correct, `0.${a*b+1}`", `0.${a*b-1}`", `0.${a*b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the product of 0.${a} and 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-DEC-04,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Decimals,
    subtopic: "Dividing Decimals",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = `0.${a/b}`;
      const opts = [correct, `0.${a/b+1}`, `0.${a/b-1}`, `0.${a/b+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`What is 0.${a} divided by 0.${b}?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: ALGEBRA (Expressions and Equations) (5 Materials) ---
  {
    id: G7-MAT-ALG-01,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Simplifying Algebraic Expressions,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 5 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify the expression: 3x + 2x, where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-ALG-02,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Simplifying Algebraic Expressions",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = 4 * a + 3 * b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify the expression: 4p + 3q, where p = ${a} and q = ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-ALG-03,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Solving Linear Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: x + ${5} = ${a + 5}`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-ALG-04,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Solving Linear Equations",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: 2x = ${2 * a}`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-ALG-05,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Solving Linear Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for y: y - ${5} = ${a - 5}`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Angles and Lines) (5 Materials) ---
  {
    id: G7-MAT-GEO-01,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Angles on a Straight Line",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 80) + 10;
      const correct = 180 - a;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Two angles lie on a straight line. One angle is ${a}°. What is the other angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-GEO-02,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Angles at a Point,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 100) + 20;
      const b = Math.floor(Math.random() * (180 - a - 10)) + 10;
      const correct = 360 - a - b;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Angles at a point sum to 360°. Two angles are ${a}° and ${b}°. What is the third angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-GEO-03,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Vertically Opposite Angles",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 80) + 10;
      const correct = a;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Vertically opposite angles are equal. If one angle is ${a}°, what is the opposite angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-GEO-04,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Angles in Triangles,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 60) + 20;
      const b = Math.floor(Math.random() * (120 - a - 10)) + 10;
      const correct = 180 - a - b;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`In a triangle, two angles are ${a}° and ${b}°. What is the third angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-GEO-05,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Geometry Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 60) + 20;
      const b = Math.floor(Math.random() * (120 - a - 10)) + 10;
      const correct = 180 - a - b;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A triangle has angles measuring ${a}° and ${b}°. What is the measure of the third angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MEASUREMENTS (Perimeter, Area, Volume) (5 Materials) ---
  {
    id: G7-MAT-MEA-01,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Area of Composite Shapes,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 2;
      const b = Math.floor(Math.random() * 10) + 2;
      const correct = a * b;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangle has length ${a}m and width ${b}m. What is its area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-MEA-02,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Perimeter of Composite Shapes",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 2;
      const b = Math.floor(Math.random() * 10) + 2;
      const correct = 2 * (a + b);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangle has length ${a}m and width ${b}m. What is its perimeter?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-MEA-03,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Volume of Cubes and Cuboids,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A cube has a side length of ${a}cm. What is its volume?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-MEA-04,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Volume of Cubes and Cuboids",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = a * b * h;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cuboid has length ${a}cm, width ${b}cm, and height ${h}cm. What is its volume?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-MEA-05,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Measurements Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cube-shaped container has sides of ${a}m. What is its volume in cubic meters?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DATA HANDLING (Statistics) (5 Materials) ---
  {
    id: G7-MAT-DAT-01,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mean",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const c = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor((a + b + c) / 3);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mean of the numbers: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-DAT-02,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Median,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 5) + 1;
      const c = b + Math.floor(Math.random() * 5) + 1;
      const correct = b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the median of the sorted numbers: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-DAT-03,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mode",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mode of the data set: ${a}, ${a}, ${a+1}, ${a+2}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-DAT-04,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Range,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const correct = b - a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the range of the data set: ${a}, ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G7-MAT-DAT-05,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Interpreting Pie Charts",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 90) + 10;
      const correct = a;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A pie chart shows a slice of ${a}°. What fraction of the pie is this slice?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Introduction) (5 Materials) ---
  {
    id: G7-MAT-PRO-01,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Introduction to Probability,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${a} red balls and ${total-a} blue balls. What is the probability of picking a red ball?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-PRO-02,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Introduction to Probability",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total+1}`, `1/${total-1}`, `1/${total+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. What is the probability of rolling a 1?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-PRO-03,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability of Simple Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total+2}`", `1/${total-2}`", `1/${total+4}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} identical balls. What is the probability of picking a specific ball?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-PRO-04,
    grade: "Grade 7,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability of Simple Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`, `${a}/${total+1}`, `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A jar has ${a} green marbles and ${total-a} red marbles. What is the probability of picking a green marble?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G7-MAT-PRO-05,
    grade: Grade 7",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total+1}`", `1/${total-1}`", `1/${total+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag contains ${total} different fruits. What is the probability of picking a specific fruit?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD JUNIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: NUMBERS (Operations and Roots) (5 Materials) ---
  {
    id: G8-MAT-NUM-01,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Operations on Integers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a - b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is ${a} minus ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-NUM-02,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Operations on Integers,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a * b;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the product of ${a} and ${b}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-NUM-03,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Square Roots",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the square root of ${a*a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-NUM-04,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Cube Roots,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the cube root of ${a*a*a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-NUM-05,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Operations on Square Roots",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify the expression: √${a*a*4}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: ALGEBRA (Expanding and Factoring) (5 Materials) ---
  {
    id: G8-MAT-ALG-01,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Expanding Algebraic Expressions,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 5 * a + 10;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Expand the expression: 5(x + 2), where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-ALG-02,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Expanding Algebraic Expressions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = 3 * a + 3 * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Expand the expression: 3(x + y), where x = ${a} and y = ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-ALG-03,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Factorization (Common Factors),
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 4 * (a + 2);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Factorize the expression: 4x + 8, where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-ALG-04,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Factorization (Common Factors)",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = 6 * a + 6 * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Factorize the expression: 6x + 6y, where x = ${a} and y = ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-ALG-05,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Factorization (Common Factors),
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 7 * (a - 3);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Factorize the expression: 7x - 21, where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: RATIOS AND PROPORTIONS (5 Materials) ---
  {
    id: G8-MAT-RAT-01,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Ratios and Proportions,
    subtopic: "Introduction to Ratios",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = `${a}:${b}`;
      const opts = [correct, `${a+1}:${b}`, `${a}:${b+1}`, `${a-1}:${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify the ratio ${a*2}:${b*2}.`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-RAT-02,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Ratios and Proportions",
    subtopic: "Ratios Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = `${a}:${b}`;
      const opts = [correct, `${a+1}:${b}`", `${a}:${b+1}`", `${a-1}:${b}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A class has ${a} boys and ${b} girls. What is the ratio of boys to girls?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-RAT-03,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Ratios and Proportions,
    subtopic: "Solving Proportions",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a * b;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve the proportion: x / ${a} = ${b} / 1.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-RAT-04,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Ratios and Proportions",
    subtopic: "Solving Proportions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const c = Math.floor(Math.random() * 10) + 1;
      const correct = a * c / b;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: ${a} / ${b} = x / ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-RAT-05,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Ratios and Proportions,
    subtopic: "Percentage Increase and Decrease",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 100) + 50;
      const p = Math.floor(Math.random() * 20) + 5;
      const correct = a + (a * p / 100);
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`Increase ${a} by ${p}%. What is the new value?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Circles) (5 Materials) ---
  {
    id: G8-MAT-GEO-01,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Parts of a Circle,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => {
      const opts = [Radius", "Diameter, Circumference", "Chord].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the distance around a circle called?`,
        options: opts,
        correctAnswer: Circumference
      };
    }
  },
  {
    id: G8-MAT-GEO-02,
    grade: "Grade 8",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Parts of a Circle,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => {
      const opts = [Radius", "Diameter, Circumference", "Pi (π)].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the ratio of circumference to diameter called?`,
        options: opts,
        correctAnswer: Pi (π)
      };
    }
  },
  {
    id: G8-MAT-GEO-03,
    grade: "Grade 8",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Calculating Circumference,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const r = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(2 * 3.14 * r);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A circle has a radius of ${r}cm. What is its circumference? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-GEO-04,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Calculating Area of a Circle",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const r = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(3.14 * r * r);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A circle has a radius of ${r}cm. What is its area? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-GEO-05,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Geometry Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const r = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(2 * 3.14 * r);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`The radius of a circle is ${r}m. What is the distance around it? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MEASUREMENTS (Surface Area and Volume) (5 Materials) ---
  {
    id: G8-MAT-MEA-01,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Surface Area of Cubes",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = 6 * a * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A cube has side length ${a}cm. What is its surface area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-MEA-02,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Surface Area of Cuboids,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const b = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = 2 * (a*b + b*h + h*a);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cuboid has length ${a}cm, width ${b}cm, and height ${h}cm. What is its surface area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-MEA-03,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Volume of Cylinders",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const r = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(3.14 * r * r * h);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cylinder has radius ${r}cm and height ${h}cm. What is its volume? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-MEA-04,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Measurements Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const r = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(2 * 3.14 * r * h);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cylindrical can has radius ${r}cm and height ${h}cm. What is its surface area? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-MEA-05,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Volume of Cylinders",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const r = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(3.14 * r * r * h);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cylinder has radius ${r}m and height ${h}m. What is its volume in cubic meters? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DATA HANDLING (Grouped Data) (5 Materials) ---
  {
    id: G8-MAT-DAT-01,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Creating Frequency Tables,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const c = b + Math.floor(Math.random() * 10) + 1;
      const correct = a + b + c;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A frequency table has values ${a}, ${b}, ${c}. What is the total frequency?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-DAT-02,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mean of Grouped Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const c = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor((a + b + c) / 3);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mean of the data: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-DAT-03,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Median of Grouped Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const c = b + Math.floor(Math.random() * 10) + 1;
      const correct = b;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the median of the data: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-DAT-04,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mode of Grouped Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mode of the data: ${a}, ${a}, ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G8-MAT-DAT-05,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Data Handling Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 10;
      const b = Math.floor(Math.random() * 50) + 10;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+5", correct-5", correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`The ages of two students are ${a} and ${b}. What is their average age?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Combined Events) (5 Materials) ---
  {
    id: G8-MAT-PRO-01,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Complementary Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${total - a}/${total}`;
      const opts = [correct, `${total - a + 1}/${total}`, `${total - a}/${total + 1}`, `${total - a - 1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The probability of an event is ${a}/${total}. What is the probability of its complement?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-PRO-02,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Complementary Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const total = 10;
      const correct = `${total - a}/${total}`;
      const opts = [correct, `${total - a + 1}/${total}`", `${total - a}/${total + 1}`", `${total - a - 1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${a} red marbles and ${total-a} blue marbles in a bag. What is the probability of NOT picking a red marble?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-PRO-03,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability of Combined Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 4;
      const correct = `1/${total * total}`;
      const opts = [correct, `1/${total * total + 1}`, `1/${total * total - 1}`, `1/${total * total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} balls. Two balls are drawn one after the other with replacement. What is the probability of drawing a specific ball twice?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-PRO-04,
    grade: Grade 8",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability of Combined Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 4;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`", `1/${total - 1}`", `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} different balls. Two balls are drawn. What is the probability that the second ball is the same as the first?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G8-MAT-PRO-05,
    grade: "Grade 8,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`, `1/${total - 1}`, `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. What is the probability of rolling a prime number if only 1 is prime?`,
        options: opts,
        correctAnswer: correct
      };
    }
  }
  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD SENIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: NUMBERS (Integers, Roots) (5 Materials) ---
  {
    id: G9-MAT-INT-01,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Operations on Integers,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a * b + a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Calculate the value of (${a} × ${b}) + ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-INT-02,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Operations on Integers",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a * b - b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Calculate the value of (${a} × ${b}) - ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-INT-03,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Square Roots,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the square of ${a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-INT-04,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Numbers,
    subtopic: "Cube Roots",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the cube of ${a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-INT-05,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Numbers",
    subtopic: "Operations on Roots,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify: √(4 × ${a*a}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: ALGEBRA (Equations and Quadratic) (5 Materials) ---
  {
    id: G9-MAT-ALG-01,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Simplifying Algebraic Expressions",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 3 * a + 2;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify: 2x + x + 2, where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-ALG-02,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Simplifying Algebraic Expressions,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 4 * a - 3;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify: 5x - x - 3, where x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-ALG-03,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Solving Linear Equations",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: 2x + 3 = ${2 * a + 3}`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-ALG-04,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Solving Linear Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: 4x - 1 = ${4 * a - 1}`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-ALG-05,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Solving Quadratic Equations (Factorization)",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: x² - ${a*a} = 0`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Polygons and Angles) (5 Materials) ---
  {
    id: G9-MAT-GEO-01,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Sum of Angles in a Polygon,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const sides = Math.floor(Math.random() * 4) + 4;
      const correct = (sides - 2) * 180;
      const opts = [correct, correct+10", correct-10", correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the sum of interior angles of a ${sides}-sided polygon?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-GEO-02,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Sum of Angles in a Polygon",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const sides = Math.floor(Math.random() * 4) + 4;
      const correct = (sides - 2) * 180 / sides;
      const opts = [correct, correct+5, correct-5, correct+10].sort(() => Math.random() - 0.5);
      return {
        text: "`What is the measure of each interior angle of a regular ${sides}-sided polygon?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-GEO-03,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Properties of Polygons,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => {
      const opts = [Pentagon", "Hexagon, Heptagon", "Octagon].sort(() => Math.random() - 0.5);
      return {
        text: "`Which polygon has 7 sides?`,
        options: opts,
        correctAnswer: Heptagon
      };
    }
  },
  {
    id: G9-MAT-GEO-04,
    grade: "Grade 9",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Area of Composite Shapes,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 2;
      const b = Math.floor(Math.random() * 10) + 2;
      const correct = a * b + Math.floor(a/2) * Math.floor(b/2);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A rectangle has dimensions ${a}m × ${b}m. Inside, there is a smaller rectangle of half the dimensions. What is the area of the remaining shape?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-GEO-05,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Geometry Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const sides = Math.floor(Math.random() * 4) + 4;
      const correct = (sides - 2) * 180;
      const opts = [correct, correct+10, correct-10, correct+20].sort(() => Math.random() - 0.5);
      return {
        text: "`A polygon has ${sides} sides. What is the sum of its interior angles?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MEASUREMENTS (Volume and Surface Area) (5 Materials) ---
  {
    id: G9-MAT-MEA-01,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Volume of Composite Solids,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a + Math.floor(a/2) * Math.floor(a/2) * Math.floor(a/2);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A large cube of side ${a}m has a smaller cube of half the side placed on top. What is the total volume?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-MEA-02,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Volume of Composite Solids",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a + a * a * a;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cube of side ${a}m is attached to another cube of the same size. What is the total volume?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-MEA-03,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Surface Area of Composite Solids,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = 6 * a * a + 6 * a * a;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Two cubes of side ${a}m are joined together. What is the total surface area?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-MEA-04,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Measurements Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = a * a * a + a * a * a;
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A tank is made of two identical cubes joined together. Each cube has a side of ${a}m. What is the total volume of the tank?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-MEA-05,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Surface Area Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = 6 * a * a + 6 * a * a;
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`A cube of side ${a}m is attached to another cube of the same size. What is the total surface area of the new shape?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: DATA HANDLING (Grouped Data) (5 Materials) ---
  {
    id: G9-MAT-DAT-01,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mean of Grouped Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const c = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor((a + b + c) / 3);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mean of: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-DAT-02,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Median of Grouped Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const c = b + Math.floor(Math.random() * 10) + 1;
      const correct = b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the median of: ${a}, ${b}, ${c}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-DAT-03,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Mode of Grouped Data",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mode of: ${a}, ${a}, ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-DAT-04,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Data Handling",
    subtopic: "Range of Grouped Data,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const correct = b - a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the range of: ${a}, ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-DAT-05,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Data Handling,
    subtopic: "Data Handling Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 10;
      const b = Math.floor(Math.random() * 50) + 10;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`The scores of two students are ${a} and ${b}. What is their average score?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Simple and Complementary) (5 Materials) ---
  {
    id: G9-MAT-PRO-01,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Simple Probability,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${a} red balls and ${total-a} blue balls. What is the probability of picking a red ball?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G9-MAT-PRO-02,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Simple Probability",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total+1}`, `1/${total-1}`, `1/${total+2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. What is the probability of rolling a specific number?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G9-MAT-PRO-03,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Complementary Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${total - a}/${total}`;
      const opts = [correct, `${total - a + 1}/${total}`", `${total - a}/${total + 1}`", `${total - a - 1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`The probability of an event is ${a}/${total}. What is the probability of its complement?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G9-MAT-PRO-04,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Complementary Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const total = 10;
      const correct = `${total - a}/${total}`;
      const opts = [correct, `${total - a + 1}/${total}`, `${total - a}/${total + 1}`, `${total - a - 1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`There are ${a} green marbles in a bag of ${total}. What is the probability of NOT picking a green marble?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G9-MAT-PRO-05,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`", `1/${total - 1}`", `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} different colored balls. What is the probability of picking a specific color?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: TRIGONOMETRY (Introduction) (5 Materials) ---
  {
    id: G9-MAT-TRI-01,
    grade: "Grade 9,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Introduction to Sine", Cosine, Tangent",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const opts = ["Sine, Cosine", "Tangent, Cotangent"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which trigonometric ratio is defined as Opposite/Hypotenuse?`,
        options: opts,
        correctAnswer: Sine
      };
    }
  },
  {
    id: G9-MAT-TRI-02,
    grade: Grade 9,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Introduction to Sine", Cosine, Tangent",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const opts = ["Sine, Cosine", "Tangent, Cotangent"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which trigonometric ratio is defined as Adjacent/Hypotenuse?`,
        options: opts,
        correctAnswer: Cosine
      };
    }
  },
  {
    id: G9-MAT-TRI-03,
    grade: Grade 9,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Introduction to Sine", Cosine, Tangent",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const opts = ["Sine, Cosine", "Tangent, Cotangent"].sort(() => Math.random() - 0.5);
      return {
        text: "`Which trigonometric ratio is defined as Opposite/Adjacent?`,
        options: opts,
        correctAnswer: Tangent
      };
    }
  },
  {
    id: G9-MAT-TRI-04,
    grade: Grade 9,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Finding Trigonometric Ratios",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a * a + 1);
      const opts = [correct, correct+0.1, correct-0.1, correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a triangle, the opposite side is ${a} and the hypotenuse is ${a*a + 1}. What is sin(θ)?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G9-MAT-TRI-05,
    grade: Grade 9",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometry Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a * a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`A ladder leans against a wall. The opposite side is ${a}m and the hypotenuse is ${a*a + 1}m. What is the sine of the angle?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // =========================================================================
  // GRADE 10: 35 MATERIALS (KICD SENIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: ALGEBRA (Quadratic Equations, Functions) (5 Materials) ---
  {
    id: G10-MAT-ALG-01,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Quadratic Equations (Factorization)",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: x² - ${a*a} = 0`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-ALG-02,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Quadratic Equations (Formula Method),
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x using the formula: x² - ${a*a} = 0`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-ALG-03,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Quadratic Equations (Word Problems)",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`The area of a square is ${a*a}. What is the length of one side?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-ALG-04,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Linear Functions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 3 * a + 5;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Evaluate f(x) = 3x + 5 at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-ALG-05,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Linear Functions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a - 3;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Evaluate f(x) = 2x - 3 at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: TRIGONOMETRY (Ratios and Triangles) (5 Materials) ---
  {
    id: G10-MAT-TRI-01,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Ratios,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a * a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a right triangle, opposite = ${a}, hypotenuse = ${a*a + 1}. What is sin(θ)?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-TRI-02,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Trigonometric Ratios",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a * a + 1);
      const opts = [correct, correct+0.1, correct-0.1, correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a right triangle, adjacent = ${a}, hypotenuse = ${a*a + 1}. What is cos(θ)?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-TRI-03,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Ratios,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a right triangle, opposite = ${a}, adjacent = ${a+1}. What is tan(θ)?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-TRI-04,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Solving Right-Angled Triangles",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a * a + 1);
      const opts = [correct, correct+0.1, correct-0.1, correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`A triangle has opposite ${a} and hypotenuse ${a*a + 1}. Find sin(θ).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-TRI-05,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometry Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a / (a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`A tree casts a shadow. The height of the tree is ${a}m and the shadow is ${a+1}m. What is the tangent of the angle of elevation?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: GEOMETRY (Coordinate Geometry) (5 Materials) ---
  {
    id: G10-MAT-GEO-01,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Midpoint of a Line Segment",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the midpoint of the line segment from ${a} to ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-GEO-02,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Gradient of a Line,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = (b - a) / (a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the gradient of the line through (${a}, ${a}) and (${a+1}, ${b}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-GEO-03,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Distance Formula",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a*a + a*a));
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the distance between (0, 0) and (${a}, ${a}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-GEO-04,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Geometry",
    subtopic: "Distance Formula,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a*a + 1));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the distance between (0, 0) and (${a}, 1).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-GEO-05,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Geometry,
    subtopic: "Coordinate Geometry Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor((a + 1) / 2);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the midpoint of the points (0, 0) and (${a+1}, ${a+1}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: MEASUREMENTS (Sectors, Spheres, Cones) (5 Materials) ---
  {
    id: G10-MAT-MEA-01,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Area of a Sector,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(3.14 * a * a * a / 360);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the area of a sector with radius ${a} and angle ${a}°. (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-MEA-02,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Area of a Sector",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(3.14 * a * a * 60 / 360);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the area of a 60° sector with radius ${a}. (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-MEA-03,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Volume of a Sphere,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(4/3 * 3.14 * a * a * a);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the volume of a sphere with radius ${a}. (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-MEA-04,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Measurements,
    subtopic: "Volume of a Cone",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const h = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(1/3 * 3.14 * a * a * h);
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the volume of a cone with radius ${a} and height ${h}. (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-MEA-05,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Measurements",
    subtopic: "Measurements Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 5) + 1;
      const correct = Math.floor(4/3 * 3.14 * a * a * a);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A ball has a radius of ${a}cm. What is its volume? (Use π = 3.14)`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: STATISTICS (Measures of Dispersion) (5 Materials) ---
  {
    id: G10-MAT-STA-01,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Range",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = a + Math.floor(Math.random() * 10) + 1;
      const correct = b - a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the range of the data: ${a}, ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-STA-02,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Standard Deviation,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the standard deviation of the data: ${a}, ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-STA-03,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Standard Deviation",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the standard deviation of the data: ${a}, ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-STA-04,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Statistics Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 10;
      const b = Math.floor(Math.random() * 50) + 10;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+2", correct-2", correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Two students scored ${a} and ${b}. What is the average?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G10-MAT-STA-05,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Statistics Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 10;
      const b = Math.floor(Math.random() * 50) + 10;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`The range of a dataset is ${b - a}. What is the standard deviation if the mean is ${correct}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Compound Events, Tree Diagrams) (5 Materials) ---
  {
    id: G10-MAT-PRO-01,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Compound Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 4;
      const correct = `1/${total * total}`;
      const opts = [correct, `1/${total * total + 1}`", `1/${total * total - 1}`", `1/${total * total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} balls. Two balls are drawn one after the other with replacement. What is the probability of drawing a specific ball twice?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G10-MAT-PRO-02,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Compound Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 6) + 4;
      const correct = `1/${total * total}`;
      const opts = [correct, `1/${total * total + 1}`, `1/${total * total - 1}`, `1/${total * total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. It is rolled twice. What is the probability of rolling a specific number twice?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G10-MAT-PRO-03,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability Tree Diagrams,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`", `1/${total - 1}`", `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} different fruits. What is the probability of picking a specific fruit?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G10-MAT-PRO-04,
    grade: "Grade 10,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability Tree Diagrams",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`, `1/${total - 1}`, `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. What is the probability of rolling a prime number if only 1 is prime?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G10-MAT-PRO-05,
    grade: Grade 10",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Probability Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`", `1/${total - 1}`", `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A bag has ${total} red balls and ${total} blue balls. What is the probability of picking two red balls with replacement?`,
        options: opts,
        correctAnswer: correct
      };
    }
  }
  // =========================================================================
  // GRADE 11: 35 MATERIALS (KICD SENIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: ALGEBRA (Quadratic Equations, Inequalities) (5 Materials) ---
  {
    id: G11-MAT-ALG-01,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Quadratic Equations (Advanced)",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a + b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: x² - ${a+b}x + ${a*b} = 0.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-ALG-02,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Quadratic Equations (Advanced),
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: 2x² - ${2*a*a} = 0.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-ALG-03,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Inequalities",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a + 5;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: x + 5 > ${a + 4}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-ALG-04,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Inequalities,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a - 3;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for x: 2x - 3 < ${2*a - 3}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-ALG-05,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Systems of Equations",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve the system: x + y = ${a+3}, x - y = ${a-3}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: TRIGONOMETRY (Identities and Equations) (5 Materials) ---
  {
    id: G11-MAT-TRI-01,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Identities,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify: sin(θ) × sin(θ) + cos(θ) × cos(θ), where θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-TRI-02,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Trigonometric Identities",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Evaluate: sin(θ) × cos(θ) when θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-TRI-03,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Identities,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Prove that sin(θ) / cos(θ) = tan(θ), where θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-TRI-04,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Sine and Cosine Rules",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a triangle, the sine rule states that a/sin(A) = b/sin(B). If a = ${a} and A = 30°, what is b if B = 60°?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-TRI-05,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Sine and Cosine Rules,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a triangle, the cosine rule states that c² = a² + b² - 2ab cos(C). If a = ${a}, b = ${a+1}, and C = 60°, what is c²?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: CALCULUS (Differentiation) (5 Materials) ---
  {
    id: G11-MAT-CAL-01,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Introduction to Differentiation",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Differentiate f(x) = x² at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-CAL-02,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Calculus",
    subtopic: "Power Rule,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 3 * a * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Differentiate f(x) = x³ at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-CAL-03,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Power Rule",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 4 * a * a * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Differentiate f(x) = x⁴ at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-CAL-04,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Calculus",
    subtopic: "Power Rule,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 5 * a * a * a * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Differentiate f(x) = x⁵ at x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-CAL-05,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Differentiation Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a + 3;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`The position of a particle is s(t) = t² + 3t. What is its velocity at t = ${a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: VECTORS (Introduction) (5 Materials) ---
  {
    id: G11-MAT-VEC-01,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Introduction to Vectors,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => {
      const opts = [Magnitude", "Direction, Scalar", "Vector].sort(() => Math.random() - 0.5);
      return {
        text: "`Which of the following has both magnitude and direction?`,
        options: opts,
        correctAnswer: Vector
      };
    }
  },
  {
    id: G11-MAT-VEC-02,
    grade: "Grade 11",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Vector Addition,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a + b;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the sum of vectors (${a}, 0) and (${b}, 0).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-VEC-03,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Vectors,
    subtopic: "Vector Subtraction",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const correct = a - b;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the difference of vectors (${a}, 0) and (${b}, 0).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-VEC-04,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Vector Addition and Subtraction,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const b = Math.floor(Math.random() * 10) + 1;
      const c = Math.floor(Math.random() * 10) + 1;
      const correct = a + b - c;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the result of vector (${a}, 0) + (${b}, 0) - (${c}, 0).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-VEC-05,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Vectors,
    subtopic: "Vectors Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a + a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`A vector has magnitude ${a}. If it is doubled, what is the new magnitude?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Advanced) (5 Materials) ---
  {
    id: G11-MAT-PRO-01,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Mutually Exclusive Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Two events are mutually exclusive. If P(A) = ${a}/${total}, what is P(A and B)?`,
        options: opts,
        correctAnswer: 0
      };
    }
  },
  {
    id: "G11-MAT-PRO-02",
    grade: "Grade 11",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Mutually Exclusive Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Two events are mutually exclusive. If P(A) = ${a}/${total}, what is P(A or B)?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G11-MAT-PRO-03,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Independent Events",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a*a}/${total*total}`;
      const opts = [correct, `${a*a+1}/${total*total}`, `${a*a}/${total*total+1}`, `${a*a-1}/${total*total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Two events are independent. If P(A) = ${a}/${total}, what is P(A and A)?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G11-MAT-PRO-04,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Independent Events,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Two events are independent. If P(A) = ${a}/${total}, what is P(A and B)?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G11-MAT-PRO-05,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const total = Math.floor(Math.random() * 10) + 5;
      const correct = `1/${total}`;
      const opts = [correct, `1/${total + 1}`, `1/${total - 1}`, `1/${total + 2}`].sort(() => Math.random() - 0.5);
      return {
        text: "`A die has ${total} faces. What is the probability of rolling a prime number if only 1 is prime?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },

  // --- MADA: STATISTICS (Measures of Dispersion) (5 Materials) ---
  {
    id: G11-MAT-STA-01,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Standard Deviation,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the standard deviation of the data: ${a}, ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-STA-02,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Standard Deviation",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the standard deviation of the data: ${a}, ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-STA-03,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Standard Deviation,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the standard deviation of the data: ${a}, ${a+1}, ${a+2}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-STA-04,
    grade: "Grade 11,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Standard Deviation",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 50) + 10;
      const b = Math.floor(Math.random() * 50) + 10;
      const correct = Math.floor((a + b) / 2);
      const opts = [correct, correct+2, correct-2, correct+4].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the mean and standard deviation of the data: ${a}, ${b}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G11-MAT-STA-05,
    grade: Grade 11",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Statistics Word Problems,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`The range of a dataset is ${a}. What is the standard deviation if the mean is ${a}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // =========================================================================
  // GRADE 12: 35 MATERIALS (KICD SENIOR SECONDARY MATHEMATICS)
  // =========================================================================

  // --- MADA: ALGEBRA (Rational Expressions, Partial Fractions) (5 Materials) ---
  {
    id: G12-MAT-ALG-01,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Rational Expressions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a + 1;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify the rational expression: x² - ${a*a} / (x - ${a}), where x = ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-ALG-02,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Rational Expressions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 1;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Simplify: (x + ${a}) / (x + ${a}), where x = ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-ALG-03,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Partial Fractions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 1 / (a + 1);
      const opts = [correct, correct+0.1, correct-0.1, correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`Decompose into partial fractions: 1 / (x - ${a})(x - ${a+1}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-ALG-04,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Algebra",
    subtopic: "Partial Fractions,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 1 / (a + 1);
      const opts = [correct, correct+0.1", correct-0.1", correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the partial fraction decomposition of 1 / (x² - ${a*a}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-ALG-05,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Algebra,
    subtopic: "Partial Fractions",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 1 / (a + 1);
      const opts = [correct, correct+0.1, correct-0.1, correct+0.2].sort(() => Math.random() - 0.5);
      return {
        text: "`Decompose 1 / (x - ${a})(x - ${a+1}) into partial fractions.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: TRIGONOMETRY (Proofs and Equations) (5 Materials) ---
  {
    id: G12-MAT-TRI-01,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Proofs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Prove that sin²(θ) + cos²(θ) = 1 for θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-TRI-02,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Trigonometric Proofs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Prove that sin(2θ) = 2sin(θ)cos(θ) for θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-TRI-03,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Trigonometric Proofs,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Prove that cos(2θ) = cos²(θ) - sin²(θ) for θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-TRI-04,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Trigonometry,
    subtopic: "Trigonometric Proofs",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = 2 * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Prove that tan(θ) = sin(θ)/cos(θ) for θ = ${a}°.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-TRI-05,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Trigonometry",
    subtopic: "Solving Trigonometric Equations,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Solve for θ: sin(θ) = ${a/10}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: CALCULUS (Integration) (5 Materials) ---
  {
    id: G12-MAT-CAL-01,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Introduction to Integration",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a * a / 3;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Integrate f(x) = x² from 0 to ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-CAL-02,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Calculus",
    subtopic: "Power Rule,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a * a * a / 4;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Integrate f(x) = x³ from 0 to ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-CAL-03,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Integration",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a * a * a * a / 5;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Integrate f(x) = x⁴ from 0 to ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-CAL-04,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Calculus",
    subtopic: "Area Under a Curve,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a * a / 3;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the area under the curve f(x) = x² from x = 0 to x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-CAL-05,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Calculus,
    subtopic: "Area Under a Curve",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a * a * a / 4;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the area under the curve f(x) = x³ from x = 0 to x = ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: VECTORS (Magnitude and Direction) (5 Materials) ---
  {
    id: G12-MAT-VEC-01,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Magnitude of a Vector,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a*a + a*a));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the magnitude of the vector (${a}, ${a}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-VEC-02,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Vectors,
    subtopic: "Direction of a Vector",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the direction of the vector (${a}, 0).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-VEC-03,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Magnitude of a Vector,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(Math.sqrt(a*a + 1));
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the magnitude of the vector (${a}, 1).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-VEC-04,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Vectors,
    subtopic: "Scalar Product",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a + a * a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the scalar product of vectors (${a}, ${a}) and (${a}, ${a}).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-VEC-05,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Vectors",
    subtopic: "Scalar Product,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a * a + 1;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Find the scalar product of vectors (${a}, 1) and (${a}, 1).`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: PROBABILITY (Conditional, Binomial) (5 Materials) ---
  {
    id: G12-MAT-PRO-01,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Conditional Probability",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/${total}`;
      const opts = [correct, `${a+1}/${total}`, `${a}/${total+1}`, `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`Given P(A) = ${a}/${total}, what is P(A|A)?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G12-MAT-PRO-02,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Conditional Probability,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const total = a + Math.floor(Math.random() * 10) + 1;
      const correct = `${a}/{total}`;
      const opts = [correct, `${a+1}/${total}`", `${a}/${total+1}`", `${a-1}/${total}`].sort(() => Math.random() - 0.5);
      return {
        text: "`If P(A and B) = ${a}/${total}, and P(B) = ${a+1}/${total}, what is P(A|B)?`,
        options: opts,
        correctAnswer: correct
      };
    }
  },
  {
    id: G12-MAT-PRO-03,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Binomial Distribution",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a binomial distribution, if n = ${a} and p = 0.5, what is the expected value?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-PRO-04,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Probability",
    subtopic: "Binomial Distribution,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = Math.floor(a / 2);
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a binomial distribution, if n = ${a} and p = 0.5, what is the variance?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-PRO-05,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Probability,
    subtopic: "Probability Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a binomial experiment with n = ${a} and p = 0.5, what is the probability of exactly ${a/2} successes?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },

  // --- MADA: STATISTICS (Normal Distribution) (5 Materials) ---
  {
    id: G12-MAT-STA-01,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Z-Scores,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Given a mean of ${a} and a standard deviation of 1, find the z-score of ${a}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-STA-02,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Z-Scores",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a + 1;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`Given a mean of ${a} and a standard deviation of 1, find the z-score of ${a+1}.`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-STA-03,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Normal Distribution,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1", correct-1", correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a normal distribution, 68% of data falls within 1 standard deviation. If the mean is ${a}, what is the range?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-STA-04,
    grade: "Grade 12,
    subject: Mathematics",
    topic: "Statistics,
    subtopic: "Normal Distribution",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a normal distribution, 95% of data falls within 2 standard deviations. If the mean is ${a}, what is the range?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  },
  {
    id: G12-MAT-STA-05,
    grade: Grade 12",
    subject: "Mathematics",
    topic: "Statistics",
    subtopic: "Statistics Word Problems",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => {
      const a = Math.floor(Math.random() * 10) + 1;
      const correct = a;
      const opts = [correct, correct+1, correct-1, correct+2].sort(() => Math.random() - 0.5);
      return {
        text: "`In a normal distribution", the mean is ${a} and the standard deviation is 1. What is the z-score of ${a+1}?`,
        options: opts.map(String),
        correctAnswer: String(correct)
      };
    }
  }

];


