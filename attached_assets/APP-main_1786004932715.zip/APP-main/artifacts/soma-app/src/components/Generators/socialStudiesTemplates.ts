export const socialStudiesTemplates: TemplateRule[] = [
  // =========================================================================
  // GRADE 4: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (6 Materials) ---
  {
    id: "G4-SST-ENV-01",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Physical Features",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: "Kenya has many physical features, including mountains, valleys, rivers, and lakes. Which of the following is a famous mountain found in Kenya?,
      options: ["Mount Kenya, Mount Kilimanjaro", "Mount Everest, Mount Atlas"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mount Kenya
    })
  },
  {
    id: G4-SST-ENV-02",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Physical Features",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Great Rift Valley is a major physical feature that runs through Kenya. What type of physical feature is the Great Rift Valley?,
      options: [A valley, A mountain, A river", "A lake].sort(() => Math.random() - 0.5),
      correctAnswer: A valley"
    })
  },
  {
    id: "G4-SST-ENV-03",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Weather and Climate,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Weather refers to the condition of the atmosphere at a specific time and place. Which of the following is an element of weather?,
      options: [Temperature, Population, "Culture, Government"].sort(() => Math.random() - 0.5),
      correctAnswer: "Temperature
    })
  },
  {
    id: G4-SST-ENV-04",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Weather and Climate",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Climate is the average weather conditions of a place over a long period. What type of climate is most common in the coastal region of Kenya?,
      options: [Tropical climate, Desert climate, Temperate climate", "Polar climate].sort(() => Math.random() - 0.5),
      correctAnswer: Tropical climate"
    })
  },
  {
    id: "G4-SST-ENV-05",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Seasons,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya experiences two main seasons: the dry season and the rainy season. During which season do farmers plant their crops?,
      options: [The rainy season, The dry season, "The cold season, The hot season"].sort(() => Math.random() - 0.5),
      correctAnswer: "The rainy season
    })
  },
  {
    id: G4-SST-ENV-06",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Seasons",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The dry season in Kenya is characterized by hot temperatures and little rainfall. How do farmers cope with the dry season?,
      options: [They use irrigation and water conservation., They stop farming entirely., They wait for the next season.", "They move to cities.].sort(() => Math.random() - 0.5),
      correctAnswer: They use irrigation and water conservation."
    })
  },

  // --- MADA: OUR COMMUNITY (5 Materials) ---
  {
    id: "G4-SST-COM-01",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "People and Their Activities,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "People in different communities engage in various economic activities. What is the main economic activity of people living near water bodies?,
      options: [Fishing, Farming, "Mining, Trading"].sort(() => Math.random() - 0.5),
      correctAnswer: "Fishing
    })
  },
  {
    id: G4-SST-COM-02",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "People and Their Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Farming is a major economic activity in Kenya. Which of the following is a type of farming practiced in Kenya?,
      options: [Crop farming, Industrial farming, Urban farming", "Desert farming].sort(() => Math.random() - 0.5),
      correctAnswer: Crop farming"
    })
  },
  {
    id: "G4-SST-COM-03",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "People and Their Activities,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Trade involves the buying and selling of goods and services. What is the main benefit of trade between communities?,
      options: [It allows communities to access goods they cannot produce., It makes communities isolated., "It causes conflicts., It reduces cultural diversity."].sort(() => Math.random() - 0.5),
      correctAnswer: "It allows communities to access goods they cannot produce.
    })
  },
  {
    id: G4-SST-COM-04",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Types of Settlements",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Settlements are places where people live. Which of the following is a type of settlement found in Kenya?,
      options: [Urban settlements, Aquatic settlements, Aerial settlements", "Subterranean settlements].sort(() => Math.random() - 0.5),
      correctAnswer: Urban settlements"
    })
  },
  {
    id: "G4-SST-COM-05",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Types of Settlements,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Urban settlements are characterized by high population density and development. What is an example of an urban settlement in Kenya?,
      options: [Nairobi, A rural village, "A farm, A fishing camp"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nairobi
    })
  },

  // --- MADA: CULTURE AND HERITAGE (5 Materials) ---
  {
    id: G4-SST-CUL-01",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Cultural Practices",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Culture refers to the beliefs, customs, and practices of a group of people. Which of the following is an example of a cultural practice in Kenya?,
      options: [Traditional dances, Driving cars, Using computers", "Wearing formal suits].sort(() => Math.random() - 0.5),
      correctAnswer: Traditional dances"
    })
  },
  {
    id: "G4-SST-CUL-02",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Cultural Practices,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different communities in Kenya have their own traditional foods. Which of the following is a traditional Kenyan food?,
      options: [Ugali, Pizza, "Sushi, Pasta"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ugali
    })
  },
  {
    id: G4-SST-CUL-03",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Cultural Practices",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Music and dance are important parts of Kenyan culture. Why are traditional dances performed in Kenyan communities?,
      options: [To celebrate ceremonies and festivals., To make money., To scare away enemies.", "To show off skills.].sort(() => Math.random() - 0.5),
      correctAnswer: To celebrate ceremonies and festivals."
    })
  },
  {
    id: "G4-SST-CUL-04",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Language and Greetings,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenya is a multilingual country with many local languages. How do different languages reflect the cultural diversity of Kenya?,
      options: [They represent the different ethnic groups and their traditions., They cause confusion., "They are all the same., They are only used in cities."].sort(() => Math.random() - 0.5),
      correctAnswer: "They represent the different ethnic groups and their traditions.
    })
  },
  {
    id: G4-SST-CUL-05",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Language and Greetings",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Greetings are an important part of Kenyan culture. What is a common greeting in Swahili used to say 'Hello'?,
      options: [Jambo, Kwaheri, Habari", "Tafadhali].sort(() => Math.random() - 0.5),
      correctAnswer: Jambo"
    })
  },

  // --- MADA: SOCIAL RELATIONS (4 Materials) ---
  {
    id: "G4-SST-SOC-01",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Getting Along with Others,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Social relations involve how people interact with each other. What is one way to maintain good social relations with others?,
      options: [By being respectful and listening to others., By being selfish., "By ignoring others., By competing with others."].sort(() => Math.random() - 0.5),
      correctAnswer: "By being respectful and listening to others.
    })
  },
  {
    id: G4-SST-SOC-02",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Respect for Elders",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " In Kenyan culture, elders are highly respected. Why is it important to respect elders in our community?,
      options: [They have wisdom and experience to share., They are rich., They are powerful.", "They are famous.].sort(() => Math.random() - 0.5),
      correctAnswer: They have wisdom and experience to share."
    })
  },
  {
    id: "G4-SST-SOC-03",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Sharing and Helping,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Sharing and helping others are key values in our community. How does sharing resources benefit the community?,
      options: [It strengthens community bonds., It causes jealousy., "It makes people lazy., It reduces resources."].sort(() => Math.random() - 0.5),
      correctAnswer: "It strengthens community bonds.
    })
  },
  {
    id: G4-SST-SOC-04",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Sharing and Helping",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Helping others is a way of showing compassion and kindness. How can you help a friend who is in need?,
      options: [By listening to them and offering support., By ignoring them., By laughing at them.", "By telling them to solve their own problems.].sort(() => Math.random() - 0.5),
      correctAnswer: By listening to them and offering support."
    })
  },

  // --- MADA: OUR NATION (5 Materials) ---
  {
    id: "G4-SST-NAT-01",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's Location,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Kenya is located in East Africa. Which of the following countries shares a border with Kenya?,
      options: [Tanzania, Egypt, "South Africa, Morocco"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tanzania
    })
  },
  {
    id: G4-SST-NAT-02",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's Location",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Kenya is bordered by five countries. Which of the following is NOT a neighboring country of Kenya?,
      options: [Ethiopia, Somalia, Uganda", "Mozambique].sort(() => Math.random() - 0.5),
      correctAnswer: Mozambique"
    })
  },
  {
    id: "G4-SST-NAT-03",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's Counties,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenya is divided into 47 counties for administrative purposes. Who is the head of a county government?,
      options: [The Governor, The President, "The Senator, The Member of Parliament"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Governor
    })
  },
  {
    id: G4-SST-NAT-04",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "National Symbols",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " National symbols represent the identity of a nation. What is the national symbol of Kenya that appears on the flag?,
      options: [The Maasai shield and spears, The lion, The elephant", "The sunrise].sort(() => Math.random() - 0.5),
      correctAnswer: The Maasai shield and spears"
    })
  },
  {
    id: "G4-SST-NAT-05",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "National Symbols,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Kenyan national anthem is a symbol of unity and pride. What is the main theme of the Kenyan national anthem?,
      options: [Unity, peace, and prosperity, War and conquest, "Wealth and power, Fame and glory"].sort(() => Math.random() - 0.5),
      correctAnswer: "Unity, peace, and prosperity
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: G4-SST-CIT-01",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Rights and Responsibilities",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Citizenship comes with both rights and responsibilities. What is an example of a right that every Kenyan citizen has?,
      options: [The right to education, The right to enslave others, The right to ignore the law", "The right to discriminate].sort(() => Math.random() - 0.5),
      correctAnswer: The right to education"
    })
  },
  {
    id: "G4-SST-CIT-02",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Rights and Responsibilities,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "With rights come responsibilities. What is a responsibility of every Kenyan citizen?,
      options: [To obey the law, To ignore the law, "To evade taxes, To discriminate against others"].sort(() => Math.random() - 0.5),
      correctAnswer: "To obey the law
    })
  },
  {
    id: G4-SST-CIT-03",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "The Kenyan Constitution",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Kenyan Constitution is the supreme law of the land. What is the purpose of the Constitution?,
      options: [It guides how the country is governed and protects citizens' rights., It is just a document., It only applies to leaders.", "It is only for lawyers.].sort(() => Math.random() - 0.5),
      correctAnswer: It guides how the country is governed and protects citizens' rights."
    })
  },
  {
    id: "G4-SST-CIT-04",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "The Kenyan Constitution,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Constitution outlines the rights and freedoms of every citizen. What is one of the fundamental rights enshrined in the Kenyan Constitution?,
      options: [The right to life, The right to ignore others, "The right to discriminate, The right to enslave others"].sort(() => Math.random() - 0.5),
      correctAnswer: "The right to life
    })
  },

  // --- MADA: OUR RESOURCES (4 Materials) ---
  {
    id: G4-SST-RES-01",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Natural Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Natural resources are resources found in nature. Which of the following is a natural resource in Kenya?,
      options: [Water, Plastic, Steel", "Concrete].sort(() => Math.random() - 0.5),
      correctAnswer: Water"
    })
  },
  {
    id: "G4-SST-RES-02",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Natural Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Land is a valuable natural resource in Kenya. How is land used in our community?,
      options: [For farming, settlement, and construction., For burning waste., "For storing water., For recreation only."].sort(() => Math.random() - 0.5),
      correctAnswer: "For farming, settlement, and construction.
    })
  },
  {
    id: G4-SST-RES-03",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Natural Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Forests are important natural resources. What is the main benefit of forests to the community?,
      options: [They provide timber and regulate climate., They cause flooding., They are just for animals.", "They are not useful.].sort(() => Math.random() - 0.5),
      correctAnswer: They provide timber and regulate climate."
    })
  },
  {
    id: "G4-SST-RES-04",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Natural Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Minerals are another type of natural resource. Which of the following minerals is mined in Kenya?,
      options: [Soda ash, Gold, "Diamonds, Platinum"].sort(() => Math.random() - 0.5),
      correctAnswer: "Soda ash
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G4-SST-TRA-01",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Ways of Moving People and Goods",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Transport is the movement of people and goods from one place to another. Which of the following is a means of transport?,
      options: [Road, Sea, Rail", "Air].sort(() => Math.random() - 0.5),
      correctAnswer: Road"
    })
  },
  {
    id: "G4-SST-TRA-02",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Ways of Moving People and Goods,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Different types of transport are used for different purposes. Which type of transport is best for moving large quantities of goods over long distances?,
      options: [Rail transport, Road transport, "Air transport, Water transport"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rail transport
    })
  },
  {
    id: G4-SST-TRA-03",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Ways of Sending Information",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Communication is the process of sending and receiving information. Which of the following is a traditional way of sending information?,
      options: [Smoke signals, Email, SMS", "Social media].sort(() => Math.random() - 0.5),
      correctAnswer: Smoke signals"
    })
  },
  {
    id: "G4-SST-TRA-04",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Ways of Sending Information,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Modern communication has made it easier to share information. Which of the following is a modern method of communication?,
      options: [Mobile phones, Smoke signals, "Town criers, Drum beating"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mobile phones
    })
  },

  // --- MADA: HISTORY (3 Materials) ---
  {
    id: G4-SST-HIS-01",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "History,
    subtopic: "History of Our School",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Every school has a history of how it began and grew over time. Why is it important to learn about the history of our school?,
      options: [To appreciate its heritage and the people who founded it., To forget about it., To know how to close it.", "To change its name.].sort(() => Math.random() - 0.5),
      correctAnswer: To appreciate its heritage and the people who founded it."
    })
  },
  {
    id: "G4-SST-HIS-02",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "History",
    subtopic: "History of Our Community,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Understanding the history of our community helps us know where we came from. Who can we ask to learn about the history of our community?,
      options: [The elders, The police, "The teachers, The doctors"].sort(() => Math.random() - 0.5),
      correctAnswer: "The elders
    })
  },
  {
    id: G4-SST-HIS-03",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "History,
    subtopic: "History of Our Community",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Learning about the history of our community helps us understand our culture and traditions. What is one benefit of knowing your community's history?,
      options: [It helps build a sense of identity and belonging., It causes conflicts., It makes people forget the present.", "It is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: It helps build a sense of identity and belonging."
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: "G4-SST-GOV-01",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "What is Governance?,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Governance refers to the way a country or community is led and managed. What is the purpose of good governance?,
      options: [To ensure justice, peace, and development., To make people poor., "To cause conflicts., To ignore the needs of citizens."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure justice, peace, and development.
    })
  },
  {
    id: G4-SST-GOV-02",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "What is Governance?",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " In a democratic society, leaders are chosen by the people through elections. Why is it important to participate in elections?,
      options: [To choose leaders who will represent the people's interests., To avoid responsibility., To stay at home.", "To support corruption.].sort(() => Math.random() - 0.5),
      correctAnswer: To choose leaders who will represent the people's interests."
    })
  },
  {
    id: "G4-SST-GOV-03",
    grade: "Grade 4",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Leaders in Our Community,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "There are different levels of leadership in our community. Who is the leader of a village or location?,
      options: [The chief, The governor, "The president, The member of parliament"].sort(() => Math.random() - 0.5),
      correctAnswer: "The chief
    })
  },
  {
    id: G4-SST-GOV-04",
    grade: "Grade 4,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Leaders in Our Community",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " County governments are responsible for local administration. Which of the following is a role of the county government?,
      options: [Providing health services and maintaining roads., Collecting taxes from the citizens., Making national laws.", "Overseeing the military.].sort(() => Math.random() - 0.5),
      correctAnswer: Providing health services and maintaining roads."
    })
  },

  // =========================================================================
  // GRADE 5: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (5 Materials) ---
  {
    id: "G5-SST-ENV-01",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Climate and Vegetation,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya has diverse vegetation due to different climates. Which type of vegetation is found in the coastal region of Kenya?,
      options: [Tropical rainforest, Savannah grassland, "Desert vegetation, Mediterranean vegetation"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tropical rainforest
    })
  },
  {
    id: G5-SST-ENV-02",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Climate and Vegetation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The savannah region is characterized by tall grasses and scattered trees. What type of climate is associated with the savannah?,
      options: [Warm and dry, Cold and wet, Hot and humid", "Cool and dry].sort(() => Math.random() - 0.5),
      correctAnswer: Warm and dry"
    })
  },
  {
    id: "G5-SST-ENV-03",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Land Use,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Land is used for various activities such as farming, settlement, and mining. How does urbanization affect land use?,
      options: ["It leads to conversion of natural land into built-up areas., It preserves natural land.", "It reduces population growth., It increases forest cover."].sort(() => Math.random() - 0.5),
      correctAnswer: "It leads to conversion of natural land into built-up areas.
    })
  },
  {
    id: G5-SST-ENV-04",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Land Use",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Farming is a major land use activity in Kenya. What is the main crop grown in the highland areas of Kenya?,
      options: [Tea, Maize, Coffee", "Sugarcane].sort(() => Math.random() - 0.5),
      correctAnswer: Tea"
    })
  },
  {
    id: "G5-SST-ENV-05",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Land Use,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Mining is another activity that uses land. Which of the following is mined in Kenya?,
      options: [Gold, Coal, "Diamonds, Silver"].sort(() => Math.random() - 0.5),
      correctAnswer: "Gold
    })
  },

  // --- MADA: OUR COMMUNITY (4 Materials) ---
  {
    id: G5-SST-COM-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Population Distribution",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Population distribution refers to how people are spread across a region. Where is the population most densely distributed in Kenya?,
      options: [Urban areas, Desert areas, Mountain peaks", "Remote rural areas].sort(() => Math.random() - 0.5),
      correctAnswer: Urban areas"
    })
  },
  {
    id: "G5-SST-COM-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Population Distribution,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which of the following factors contributes to a high population density in a region?,
      options: [Availability of resources and economic opportunities., Harsh climate., "Lack of water., Poor infrastructure."].sort(() => Math.random() - 0.5),
      correctAnswer: "Availability of resources and economic opportunities.
    })
  },
  {
    id: G5-SST-COM-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Settlement Patterns",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Settlement patterns describe how people arrange their homes. What is a clustered settlement pattern?,
      options: [Homes are built close together in a group., Homes are spread far apart., Homes are arranged in a line.", "Homes are built on hilltops.].sort(() => Math.random() - 0.5),
      correctAnswer: Homes are built close together in a group."
    })
  },
  {
    id: "G5-SST-COM-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Settlement Patterns,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the main factor that influences the type of settlement pattern in a given area?,
      options: [The availability of resources and safety., The size of the population., "The number of schools., The presence of roads."].sort(() => Math.random() - 0.5),
      correctAnswer: "The availability of resources and safety.
    })
  },

  // --- MADA: CULTURE AND HERITAGE (4 Materials) ---
  {
    id: G5-SST-CUL-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Festivals and Ceremonies",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Festivals are celebrations that bring communities together. What is an example of a traditional festival in Kenya?,
      options: [The Maasai Eunoto ceremony, Christmas, Eid", "Easter].sort(() => Math.random() - 0.5),
      correctAnswer: The Maasai Eunoto ceremony"
    })
  },
  {
    id: "G5-SST-CUL-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Festivals and Ceremonies,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Religious festivals are also celebrated in Kenya. What is the significance of festivals like Christmas and Eid in Kenyan society?,
      options: [They promote social cohesion and cultural exchange., They are only for religious leaders., "They are not important., They divide people."].sort(() => Math.random() - 0.5),
      correctAnswer: "They promote social cohesion and cultural exchange.
    })
  },
  {
    id: G5-SST-CUL-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Languages and Customs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Kenya is home to over 40 different ethnic groups, each with its own language and customs. Why is it important to preserve these languages?,
      options: [To maintain cultural identity and heritage., To create confusion., To make people forget their roots.", "To isolate ethnic groups.].sort(() => Math.random() - 0.5),
      correctAnswer: To maintain cultural identity and heritage."
    })
  },
  {
    id: "G5-SST-CUL-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Languages and Customs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Customs are traditions that have been passed down through generations. What is the importance of customs in a community?,
      options: [They provide a sense of belonging and continuity., They are outdated., "They are just superstitions., They divide people."].sort(() => Math.random() - 0.5),
      correctAnswer: "They provide a sense of belonging and continuity.
    })
  },

  // --- MADA: SOCIAL RELATIONS (4 Materials) ---
  {
    id: G5-SST-SOC-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Conflict Resolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Conflicts can arise in any community. What is the best way to resolve a conflict between two individuals?,
      options: [By communicating and seeking a mutual agreement., By fighting., By ignoring the problem.", "By involving the police immediately.].sort(() => Math.random() - 0.5),
      correctAnswer: By communicating and seeking a mutual agreement."
    })
  },
  {
    id: "G5-SST-SOC-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Peace and Unity,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Peace and unity are essential for the development of any nation. Why is unity important in a diverse country like Kenya?,
      options: [It allows people to live and work together harmoniously., It causes competition., "It makes people jealous., It reduces cultural diversity."].sort(() => Math.random() - 0.5),
      correctAnswer: "It allows people to live and work together harmoniously.
    })
  },
  {
    id: G5-SST-SOC-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Conflict Resolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Mediation is a conflict resolution method where a third party helps the conflicting parties find a solution. What is the role of a mediator?,
      options: [To facilitate dialogue and help both sides reach an agreement., To take sides., To impose a solution.", "To ignore the conflict.].sort(() => Math.random() - 0.5),
      correctAnswer: To facilitate dialogue and help both sides reach an agreement."
    })
  },
  {
    id: "G5-SST-SOC-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the difference between negotiation and mediation in conflict resolution?,
      options: [Negotiation involves parties directly discussing their issues, while mediation involves a third party., Negotiation involves a third party, while mediation does not., "They are the same., Negotiation is only for serious conflicts."].sort(() => Math.random() - 0.5),
      correctAnswer: "Negotiation involves parties directly discussing their issues, while mediation involves a third party.
    })
  },

  // --- MADA: OUR NATION (5 Materials) ---
  {
    id: G5-SST-NAT-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Physical Features",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Great Rift Valley is a major physical feature in Kenya. How was the Great Rift Valley formed?,
      options: [It was formed by the movement of tectonic plates., It was formed by a river., It was formed by a volcano.", "It was formed by human activity.].sort(() => Math.random() - 0.5),
      correctAnswer: It was formed by the movement of tectonic plates."
    })
  },
  {
    id: "G5-SST-NAT-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Physical Features",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: "Mount Kenya is the highest mountain in Kenya and the second highest in Africa. What type of mountain is Mount Kenya?,
      options: [A volcanic mountain, A fold mountain, "A block mountain, A residual mountain"].sort(() => Math.random() - 0.5),
      correctAnswer: "A volcanic mountain
    })
  },
  {
    id: G5-SST-NAT-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Major Towns and Cities",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Kenya has several major towns and cities. Which of the following is the second largest city in Kenya?,
      options: [Mombasa, Nairobi, Kisumu", "Nakuru].sort(() => Math.random() - 0.5),
      correctAnswer: Mombasa"
    })
  },
  {
    id: "G5-SST-NAT-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Major Towns and Cities,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which of the following is a major town located in the Rift Valley region of Kenya?,
      options: [Nakuru, Nairobi, "Mombasa, Kisumu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nakuru
    })
  },
  {
    id: G5-SST-NAT-05",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "National Values",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " National values are the principles that guide the behavior of citizens. What are some national values in Kenya?,
      options: [Patriotism, unity, respect, and integrity., Greed, selfishness, and corruption., Competition and jealousy.", "Fear and distrust.].sort(() => Math.random() - 0.5),
      correctAnswer: Patriotism, unity, respect, and integrity."
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: "G5-SST-CIT-01",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "National Values and Patriotism,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Patriotism is a national value that involves love for one's country. How can a citizen demonstrate patriotism?,
      options: [By respecting the national flag and anthem., By leaving the country., "By ignoring national events., By not paying taxes."].sort(() => Math.random() - 0.5),
      correctAnswer: "By respecting the national flag and anthem.
    })
  },
  {
    id: G5-SST-CIT-02",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "National Values and Patriotism",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Kenyan flag is a national symbol. What do the colors of the Kenyan flag represent?,
      options: [Black represents the people; red represents the blood shed for independence; green represents the land; white represents peace., Black represents the night; red represents the sun; green represents the grass; white represents the snow., Black represents death; red represents war; green represents money; white represents purity.", "Black represents the sky; red represents the soil; green represents the trees; white represents clouds.].sort(() => Math.random() - 0.5),
      correctAnswer: Black represents the people; red represents the blood shed for independence; green represents the land; white represents peace."
    })
  },
  {
    id: "G5-SST-CIT-03",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "National Values and Patriotism,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is the role of citizens in upholding national values in Kenya?,
      options: [To practice them in daily life and encourage others., To ignore them., "To criticize them., To only follow them when convenient."].sort(() => Math.random() - 0.5),
      correctAnswer: "To practice them in daily life and encourage others.
    })
  },
  {
    id: G5-SST-CIT-04",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "National Values and Patriotism",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Respect for the national flag and anthem is a sign of patriotism. What is the proper way to behave when the national anthem is played?,
      options: [Stand up straight and show respect., Sit down and talk loudly., Walk away.", "Ignore it.].sort(() => Math.random() - 0.5),
      correctAnswer: Stand up straight and show respect."
    })
  },

  // --- MADA: OUR RESOURCES (5 Materials) ---
  {
    id: "G5-SST-RES-01",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Forestry,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Forests are important natural resources. What is the main benefit of forests to the environment?,
      options: [They provide habitat for wildlife and help regulate the climate., They cause floods., "They block the sun., They consume water."].sort(() => Math.random() - 0.5),
      correctAnswer: "They provide habitat for wildlife and help regulate the climate.
    })
  },
  {
    id: G5-SST-RES-02",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Forestry",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Deforestation is the clearing of forests. What is one effect of deforestation on the environment?,
      options: [Loss of habitat for wildlife and increased soil erosion., Increased rainfall., Improved air quality.", "Increased biodiversity.].sort(() => Math.random() - 0.5),
      correctAnswer: Loss of habitat for wildlife and increased soil erosion."
    })
  },
  {
    id: "G5-SST-RES-03",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Wildlife,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya is famous for its wildlife. Where are most wildlife animals found in Kenya?,
      options: [National parks and game reserves., Cities and towns., "Deserts., Ocean."].sort(() => Math.random() - 0.5),
      correctAnswer: "National parks and game reserves.
    })
  },
  {
    id: G5-SST-RES-04",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Wildlife",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the importance of wildlife conservation in Kenya?,
      options: [It preserves biodiversity and promotes tourism., It reduces tourism., It destroys the environment.", "It increases pollution.].sort(() => Math.random() - 0.5),
      correctAnswer: It preserves biodiversity and promotes tourism."
    })
  },
  {
    id: "G5-SST-RES-05",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Minerals,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenya has several mineral resources. Which of the following is a mineral mined in the Rift Valley region?,
      options: [Soda ash, Gold, "Coal, Diamonds"].sort(() => Math.random() - 0.5),
      correctAnswer: "Soda ash
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G5-SST-TRA-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Modern Methods of Transport",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Modern transport methods have made movement easier. Which of the following is a modern method of transport?,
      options: [Airplanes, Donkeys, Canoes", "Carts].sort(() => Math.random() - 0.5),
      correctAnswer: Airplanes"
    })
  },
  {
    id: "G5-SST-TRA-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Modern Methods of Transport,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Which mode of transport is most suitable for travel between the mainland and islands?,
      options: [Water transport, Road transport, "Rail transport, Air transport"].sort(() => Math.random() - 0.5),
      correctAnswer: "Water transport
    })
  },
  {
    id: G5-SST-TRA-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Modern Methods of Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Communication has evolved rapidly over time. What is one advantage of modern methods of communication?,
      options: [They allow instant sharing of information across long distances., They are slow., They are expensive.", "They are difficult to use.].sort(() => Math.random() - 0.5),
      correctAnswer: They allow instant sharing of information across long distances."
    })
  },
  {
    id: "G5-SST-TRA-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Modern Methods of Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the main disadvantage of relying solely on modern communication methods like the internet?,
      options: [They are not accessible to everyone, especially in remote areas., They are free., "They are always reliable., They don't require any technology."].sort(() => Math.random() - 0.5),
      correctAnswer: "They are not accessible to everyone, especially in remote areas.
    })
  },

  // --- MADA: HISTORY (4 Materials) ---
  {
    id: G5-SST-HIS-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "History,
    subtopic: "History of Our County",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Learning about the history of our county helps us understand its development. Where can we find information about the history of our county?,
      options: [County archives and museums, The police station, The supermarket", "The airport].sort(() => Math.random() - 0.5),
      correctAnswer: County archives and museums"
    })
  },
  {
    id: "G5-SST-HIS-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "History",
    subtopic: "History of Our Region,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is the importance of preserving oral history in a community?,
      options: [It ensures that the traditions and stories of the past are passed on to future generations., It is not important., "It is only for entertainment., It is only for old people."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures that the traditions and stories of the past are passed on to future generations.
    })
  },
  {
    id: G5-SST-HIS-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "History,
    subtopic: "History of Our Region",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Why is it important to study the history of the region where you live?,
      options: [To understand how the region has developed over time and appreciate its cultural heritage., To change the region's name., To create conflicts.", "To forget about the past.].sort(() => Math.random() - 0.5),
      correctAnswer: To understand how the region has developed over time and appreciate its cultural heritage."
    })
  },
  {
    id: "G5-SST-HIS-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "History",
    subtopic: "History of Our Region,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the role of elders in preserving the history of a community?,
      options: [They pass down oral traditions, stories, and customs to younger generations., They only focus on the future., "They are not involved in history., They only care about politics."].sort(() => Math.random() - 0.5),
      correctAnswer: "They pass down oral traditions, stories, and customs to younger generations.
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: G5-SST-GOV-01",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Structure of Government",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Kenyan government is structured into three levels. What are the three levels of government in Kenya?,
      options: [National, county, and local government., National, regional, and local., Federal, state, and local.", "National, provincial, and city.].sort(() => Math.random() - 0.5),
      correctAnswer: National, county, and local government."
    })
  },
  {
    id: "G5-SST-GOV-02",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Structure of Government,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The national government handles matters of national importance, such as defense, foreign relations, and national economic policy. What are some of the responsibilities of the national government?,
      options: ["Defense, foreign affairs, and national economic policy., Local roads and waste management.", "Education and health services., Market regulation."].sort(() => Math.random() - 0.5),
      correctAnswer: "Defense, foreign affairs, and national economic policy.
    })
  },
  {
    id: G5-SST-GOV-03",
    grade: "Grade 5,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Structure of Government",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " County governments are responsible for local administration. What is the role of the county government in Kenya?,
      options: [To manage county-level services such as health, roads, and agriculture., To make national laws., To conduct foreign policy.", "To manage the military.].sort(() => Math.random() - 0.5),
      correctAnswer: To manage county-level services such as health, roads, and agriculture."
    })
  },
  {
    id: "G5-SST-GOV-04",
    grade: "Grade 5",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Structure of Government,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Local government is the lowest level of administration. What is the role of the local government in a community?,
      options: [To manage local issues like waste collection and community development., To manage the economy of the country., "To conduct international trade., To run the national army."].sort(() => Math.random() - 0.5),
      correctAnswer: "To manage local issues like waste collection and community development.
    })
  }
  // =========================================================================
  // GRADE 6: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (5 Materials) ---
  {
    id: G6-SST-ENV-01",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Conservation of the Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Conservation of the environment is essential for sustainability. What is the best way to conserve water in a community?,
      options: [By collecting rainwater and using it wisely., By wasting water., By using only well water.", "By dumping waste into water sources.].sort(() => Math.random() - 0.5),
      correctAnswer: By collecting rainwater and using it wisely."
    })
  },
  {
    id: "G6-SST-ENV-02",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Conservation of the Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Tree planting is an important method of environmental conservation. What is the main benefit of planting trees?,
      options: [Trees absorb carbon dioxide and provide oxygen., Trees block the sun., "Trees use up all the water., Trees make the land dry."].sort(() => Math.random() - 0.5),
      correctAnswer: "Trees absorb carbon dioxide and provide oxygen.
    })
  },
  {
    id: G6-SST-ENV-03",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Conservation of the Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Recycling is a way to reduce waste and conserve resources. Which of the following can be recycled?,
      options: [Plastic and paper, Food waste, Human waste", "Rubble].sort(() => Math.random() - 0.5),
      correctAnswer: Plastic and paper"
    })
  },
  {
    id: "G6-SST-ENV-04",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Conservation of the Environment,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Reducing the use of non-biodegradable materials is a way to conserve the environment. What is an example of a non-biodegradable material?,
      options: [Plastic bags, Paper, "Wood, Cotton"].sort(() => Math.random() - 0.5),
      correctAnswer: "Plastic bags
    })
  },
  {
    id: G6-SST-ENV-05",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Conservation of the Environment",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " What is the main role of communities in conserving the environment?,
      options: [To reduce waste and promote sustainable practices., To burn waste., To dump waste into rivers.", "To ignore environmental issues.].sort(() => Math.random() - 0.5),
      correctAnswer: To reduce waste and promote sustainable practices."
    })
  },

  // --- MADA: OUR COMMUNITY (5 Materials) ---
  {
    id: "G6-SST-COM-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urbanization,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Urbanization refers to the movement of people from rural areas to urban centers. What is the main cause of urbanization in Kenya?,
      options: [Search for better jobs and services., Search for better land for farming., "Search for better schools., Search for better weather."].sort(() => Math.random() - 0.5),
      correctAnswer: "Search for better jobs and services.
    })
  },
  {
    id: G6-SST-COM-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Urbanization",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Rapid urbanization can lead to several challenges. What is one negative effect of urbanization?,
      options: [Increased pressure on housing and infrastructure., Increased job opportunities., Improved healthcare.", "Increased clean water supply.].sort(() => Math.random() - 0.5),
      correctAnswer: Increased pressure on housing and infrastructure."
    })
  },
  {
    id: "G6-SST-COM-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urbanization,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "How can the government address the challenges associated with urbanization?,
      options: [By improving urban planning and providing adequate housing., By increasing taxes., "By stopping migration to cities., By ignoring the problem."].sort(() => Math.random() - 0.5),
      correctAnswer: "By improving urban planning and providing adequate housing.
    })
  },
  {
    id: G6-SST-COM-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Rural-Urban Migration",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Rural-urban migration is the movement of people from rural areas to cities. What is one effect of rural-urban migration on rural areas?,
      options: [It leads to a shortage of labor in rural areas., It increases population density in rural areas., It improves infrastructure in rural areas.", "It increases agricultural production.].sort(() => Math.random() - 0.5),
      correctAnswer: It leads to a shortage of labor in rural areas."
    })
  },
  {
    id: "G6-SST-COM-05",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Rural-Urban Migration,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "People migrate from rural areas to urban areas for various reasons. Which of the following is a 'push factor' that drives people away from rural areas?,
      options: [Poor employment opportunities, Good schools, "Better healthcare, Modern entertainment"].sort(() => Math.random() - 0.5),
      correctAnswer: "Poor employment opportunities
    })
  },

  // --- MADA: CULTURE AND HERITAGE (5 Materials) ---
  {
    id: G6-SST-CUL-01",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "African Cultures and Customs",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Africa is rich in diverse cultures and customs. Which of the following is an example of a traditional African custom?,
      options: [Communal living and sharing of resources, Individualism, Exclusive social clubs", "Lack of community interaction].sort(() => Math.random() - 0.5),
      correctAnswer: Communal living and sharing of resources"
    })
  },
  {
    id: "G6-SST-CUL-02",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "African Cultures and Customs,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Traditional African societies had their own governance systems. What was the role of the council of elders in many African communities?,
      options: [To settle disputes and give guidance., To fight wars., "To collect taxes., To rule without question."].sort(() => Math.random() - 0.5),
      correctAnswer: "To settle disputes and give guidance.
    })
  },
  {
    id: G6-SST-CUL-03",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Globalization and Culture",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Globalization has led to the spread of ideas and cultures across the world. What is a positive effect of globalization on culture?,
      options: [It promotes cultural exchange and understanding., It destroys all local cultures., It makes everyone the same.", "It increases cultural isolation.].sort(() => Math.random() - 0.5),
      correctAnswer: It promotes cultural exchange and understanding."
    })
  },
  {
    id: "G6-SST-CUL-04",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Globalization and Culture,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is a negative effect of globalization on local cultures in Kenya?,
      options: [It can lead to the loss of traditional languages and customs., It strengthens local languages., "It promotes local festivals., It increases the use of local materials."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can lead to the loss of traditional languages and customs.
    })
  },
  {
    id: G6-SST-CUL-05",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Preserving African Culture",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Preserving African culture is important for future generations. How can we preserve our cultural heritage in the face of globalization?,
      options: [By teaching traditional languages and customs in schools., By ignoring globalization., By rejecting modern technology.", "By only speaking English.].sort(() => Math.random() - 0.5),
      correctAnswer: By teaching traditional languages and customs in schools."
    })
  },

  // --- MADA: SOCIAL RELATIONS (5 Materials) ---
  {
    id: "G6-SST-SOC-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Human Rights,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Human rights are the basic rights and freedoms that belong to every person. Which document outlines the fundamental human rights?,
      options: [The UN Declaration of Human Rights, The Kenyan Constitution, "The Bible, The Quran"].sort(() => Math.random() - 0.5),
      correctAnswer: "The UN Declaration of Human Rights
    })
  },
  {
    id: G6-SST-SOC-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Human Rights",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Every human being has the right to life, liberty, and security. Why are human rights important in a society?,
      options: [They ensure that all people are treated with dignity and respect., They only apply to certain people., They are optional.", "They are not important.].sort(() => Math.random() - 0.5),
      correctAnswer: They ensure that all people are treated with dignity and respect."
    })
  },
  {
    id: "G6-SST-SOC-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Responsibilities of Citizens,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "With rights come responsibilities. What is one responsibility of a citizen in a democratic society?,
      options: [To pay taxes and follow the law., To ignore the law., "To avoid paying taxes., To demand rights without fulfilling responsibilities."].sort(() => Math.random() - 0.5),
      correctAnswer: "To pay taxes and follow the law.
    })
  },
  {
    id: G6-SST-SOC-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Responsibilities of Citizens",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Voting in elections is both a right and a responsibility. Why is it important for citizens to participate in elections?,
      options: [It ensures the people choose their leaders and have a say in governance., It is not important., It is only for the rich.", "It is only for the educated.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures the people choose their leaders and have a say in governance."
    })
  },
  {
    id: "G6-SST-SOC-05",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Responsibilities of Citizens,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the relationship between rights and responsibilities in a democratic society?,
      options: [Rights and responsibilities are interconnected; enjoying rights requires fulfilling responsibilities., Rights are more important than responsibilities., "Responsibilities are not important., Rights and responsibilities are not related."].sort(() => Math.random() - 0.5),
      correctAnswer: "Rights and responsibilities are interconnected; enjoying rights requires fulfilling responsibilities.
    })
  },

  // --- MADA: OUR NATION (5 Materials) ---
  {
    id: G6-SST-NAT-01",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Economic Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Kenya has a diverse economy based on various economic activities. Which of the following is a major economic activity in Kenya?,
      options: [Agriculture, Mining, Banking", "Information Technology].sort(() => Math.random() - 0.5),
      correctAnswer: Agriculture"
    })
  },
  {
    id: "G6-SST-NAT-02",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Economic Activities,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tourism is a major contributor to Kenya's economy. What is the main attraction for tourists visiting Kenya?,
      options: [National parks and wildlife, Shopping malls, "The stock exchange, Deserts"].sort(() => Math.random() - 0.5),
      correctAnswer: "National parks and wildlife
    })
  },
  {
    id: G6-SST-NAT-03",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Economic Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Manufacturing is another important economic activity in Kenya. What is one product manufactured in Kenya?,
      options: [Cement, Electronics, Cars", "Aircraft].sort(() => Math.random() - 0.5),
      correctAnswer: Cement"
    })
  },
  {
    id: "G6-SST-NAT-04",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Economic Activities,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Mining is practiced in various parts of Kenya. Which mineral is mined in the Magadi area?,
      options: [Soda ash, Gold, "Coal, Oil"].sort(() => Math.random() - 0.5),
      correctAnswer: "Soda ash
    })
  },
  {
    id: G6-SST-NAT-05",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Economic Activities",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the main challenge facing the agricultural sector in Kenya today?,
      options: [Climate change and unpredictable rainfall., Cheap imports., Lack of land.", "High population growth.].sort(() => Math.random() - 0.5),
      correctAnswer: Climate change and unpredictable rainfall."
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: "G6-SST-CIT-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "The Kenyan Constitution,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Kenyan Constitution is the supreme law of the land. Who is the head of state in Kenya according to the Constitution?,
      options: [The President, The Prime Minister, "The King, The Governor"].sort(() => Math.random() - 0.5),
      correctAnswer: "The President
    })
  },
  {
    id: G6-SST-CIT-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "The Kenyan Constitution",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Kenyan Constitution guarantees certain rights to its citizens. What is the right to education?,
      options: [The right to free and compulsory basic education., The right to university education., The right to private schooling.", "The right to choose any school.].sort(() => Math.random() - 0.5),
      correctAnswer: The right to free and compulsory basic education."
    })
  },
  {
    id: "G6-SST-CIT-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Democratic Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Elections are a key feature of a democratic society. Why are elections important for the country?,
      options: [They allow citizens to choose their representatives., They are just a formality., "They are only for certain people., They are not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "They allow citizens to choose their representatives.
    })
  },
  {
    id: G6-SST-CIT-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Democratic Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the role of the Independent Electoral and Boundaries Commission (IEBC) in Kenya?,
      options: [To conduct and manage elections in Kenya., To make laws., To appoint judges.", "To manage foreign affairs.].sort(() => Math.random() - 0.5),
      correctAnswer: To conduct and manage elections in Kenya."
    })
  },

  // --- MADA: OUR RESOURCES (4 Materials) ---
  {
    id: "G6-SST-RES-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Energy Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya has various energy resources. Which of the following is a renewable energy source?,
      options: [Geothermal, Coal, "Oil, Natural gas"].sort(() => Math.random() - 0.5),
      correctAnswer: "Geothermal
    })
  },
  {
    id: G6-SST-RES-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Energy Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is the main advantage of using renewable energy sources like solar and wind power?,
      options: [They are environmentally friendly and inexhaustible., They are very expensive., They are not efficient.", "They are not available in Kenya.].sort(() => Math.random() - 0.5),
      correctAnswer: They are environmentally friendly and inexhaustible."
    })
  },
  {
    id: "G6-SST-RES-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Energy Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Water resources are also vital for Kenya's development. What is the main source of water for irrigation in Kenya?,
      options: [Rivers and lakes, The ocean, "Rainwater only, Boreholes only"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rivers and lakes
    })
  },
  {
    id: G6-SST-RES-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Water Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " How can we ensure the sustainable use of water resources in Kenya?,
      options: [By conserving water and protecting catchment areas., By using water recklessly., By dumping waste into rivers.", "By wasting water daily.].sort(() => Math.random() - 0.5),
      correctAnswer: By conserving water and protecting catchment areas."
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: "G6-SST-TRA-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Impact on Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Transport and communication play a vital role in society. How does transport contribute to the economy of a country?,
      options: [It facilitates trade and movement of goods and people., It only causes pollution., "It is not important., It reduces economic growth."].sort(() => Math.random() - 0.5),
      correctAnswer: "It facilitates trade and movement of goods and people.
    })
  },
  {
    id: G6-SST-TRA-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Impact on Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The development of transport infrastructure, such as roads and railways, has both positive and negative impacts. What is a positive impact of building a new railway line?,
      options: [It reduces travel time and transport costs., It increases traffic congestion., It causes noise pollution.", "It destroys the environment.].sort(() => Math.random() - 0.5),
      correctAnswer: It reduces travel time and transport costs."
    })
  },
  {
    id: "G6-SST-TRA-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Impact on Society,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Communication technology has transformed the way people interact. What is one social impact of mobile phones in Kenya?,
      options: [They have improved connectivity and access to information., They have reduced social interaction., "They have caused isolation., They have made people lazy."].sort(() => Math.random() - 0.5),
      correctAnswer: "They have improved connectivity and access to information.
    })
  },
  {
    id: G6-SST-TRA-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Impact on Society",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is one challenge of rapid growth in transport and communication in urban areas?,
      options: [Traffic congestion and environmental pollution., Reduced connectivity., Lack of roads.", "High internet speed.].sort(() => Math.random() - 0.5),
      correctAnswer: Traffic congestion and environmental pollution."
    })
  },

  // --- MADA: HISTORY (4 Materials) ---
  {
    id: "G6-SST-HIS-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Colonial Period in Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenya was colonized by the British in the late 19th century. What was the main reason for the colonization of Kenya?,
      options: [To exploit resources and establish trade routes., To spread Christianity., "To establish democratic governments., To build schools."].sort(() => Math.random() - 0.5),
      correctAnswer: "To exploit resources and establish trade routes.
    })
  },
  {
    id: G6-SST-HIS-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "History,
    subtopic: "Colonial Period in Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " During the colonial period, the British established their administration in Kenya. What was the effect of colonialism on the Kenyan people?,
      options: [Loss of land and political rights., Improved governance., Increased freedom.", "Economic prosperity.].sort(() => Math.random() - 0.5),
      correctAnswer: Loss of land and political rights."
    })
  },
  {
    id: "G6-SST-HIS-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Struggle for Independence,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The struggle for independence in Kenya was marked by resistance and political movements. Which group of fighters is famously known for leading the Mau Mau rebellion?,
      options: [The Mau Mau fighters, The Kikuyu Central Association, "The Kenya African Union, The British Army"].sort(() => Math.random() - 0.5),
      correctAnswer: "The Mau Mau fighters
    })
  },
  {
    id: G6-SST-HIS-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "History,
    subtopic: "Struggle for Independence",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kenya gained independence on December 12, 1963. What was the name of the first President of independent Kenya?,
      options: [Jomo Kenyatta, Daniel arap Moi, Mwai Kibaki", "Uhuru Kenyatta].sort(() => Math.random() - 0.5),
      correctAnswer: Jomo Kenyatta"
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: "G6-SST-GOV-01",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Three Arms of Government,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "The Kenyan government is divided into three arms: the Executive, the Legislature, and the Judiciary. What is the main role of the Executive arm of government?,
      options: ["To implement and enforce laws., To make laws.", "To interpret laws., To appoint judges."].sort(() => Math.random() - 0.5),
      correctAnswer: "To implement and enforce laws.
    })
  },
  {
    id: G6-SST-GOV-02",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Three Arms of Government",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The Legislature is responsible for making laws in Kenya. Which institution is the main legislative body in Kenya?,
      options: [The Parliament, The Senate, The National Assembly", "The Judiciary].sort(() => Math.random() - 0.5),
      correctAnswer: The Parliament"
    })
  },
  {
    id: "G6-SST-GOV-03",
    grade: "Grade 6",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Three Arms of Government,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Judiciary is the third arm of government. What is the main function of the Judiciary in Kenya?,
      options: [To interpret the law and settle disputes., To make laws., "To execute laws., To manage the army."].sort(() => Math.random() - 0.5),
      correctAnswer: "To interpret the law and settle disputes.
    })
  },
  {
    id: G6-SST-GOV-04",
    grade: "Grade 6,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Three Arms of Government",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The three arms of government operate on the principle of separation of powers. Why is the separation of powers important in a democracy?,
      options: [It ensures that no single arm becomes too powerful., It allows one arm to control the others., It makes government inefficient.", "It is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures that no single arm becomes too powerful."
    })
  },

  // =========================================================================
  // GRADE 7: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (5 Materials) ---
  {
    id: "G7-SST-ENV-01",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Climate Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Climate change is a global challenge affecting Kenya. What is the main cause of climate change?,
      options: [Emission of greenhouse gases., Natural climate cycles., "Volcanic eruptions., Solar flares."].sort(() => Math.random() - 0.5),
      correctAnswer: "Emission of greenhouse gases.
    })
  },
  {
    id: G7-SST-ENV-02",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Climate Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Climate change has led to extreme weather events in Kenya. What is one effect of climate change in Kenya?,
      options: [Droughts and flooding, Increased rainfall, Cooler temperatures", "Less wind].sort(() => Math.random() - 0.5),
      correctAnswer: Droughts and flooding"
    })
  },
  {
    id: "G7-SST-ENV-03",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Climate Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "How can communities in Kenya adapt to the effects of climate change?,
      options: [By planting drought-resistant crops and conserving water., By ignoring the problem., "By moving to other countries., By increasing greenhouse gas emissions."].sort(() => Math.random() - 0.5),
      correctAnswer: "By planting drought-resistant crops and conserving water.
    })
  },
  {
    id: G7-SST-ENV-04",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Environmental Degradation",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Environmental degradation refers to the damage caused to the environment. What is one cause of environmental degradation in Kenya?,
      options: [Deforestation, Afforestation, Recycling", "Tree planting].sort(() => Math.random() - 0.5),
      correctAnswer: Deforestation"
    })
  },
  {
    id: "G7-SST-ENV-05",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Environmental Degradation,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the main effect of deforestation on the environment in Kenya?,
      options: [Loss of biodiversity and soil erosion., Increased rainfall., "Improved air quality., Increased wildlife population."].sort(() => Math.random() - 0.5),
      correctAnswer: "Loss of biodiversity and soil erosion.
    })
  },

  // --- MADA: OUR COMMUNITY (5 Materials) ---
  {
    id: G7-SST-COM-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Population Growth",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Population growth is the increase in the number of people in a given area. Which of the following is a result of rapid population growth?,
      options: [Strain on resources and infrastructure., Improved quality of life., Increased forest cover.", "Decreased demand for housing.].sort(() => Math.random() - 0.5),
      correctAnswer: Strain on resources and infrastructure."
    })
  },
  {
    id: "G7-SST-COM-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Population Growth,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is one way to manage rapid population growth?,
      options: [Family planning and education., Encouraging larger families., "Stopping immigration., Ignoring the problem."].sort(() => Math.random() - 0.5),
      correctAnswer: "Family planning and education.
    })
  },
  {
    id: G7-SST-COM-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Urban Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Urban planning is the process of designing and organizing urban areas. Why is urban planning important for cities in Kenya?,
      options: [It ensures sustainable development and adequate infrastructure., It increases urban sprawl., It is not important.", "It only benefits the rich.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures sustainable development and adequate infrastructure."
    })
  },
  {
    id: "G7-SST-COM-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urban Planning,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What are the main challenges facing urban areas in Kenya due to poor urban planning?,
      options: [Traffic congestion and housing shortages., More open spaces., "Better roads., Increased forest cover."].sort(() => Math.random() - 0.5),
      correctAnswer: "Traffic congestion and housing shortages.
    })
  },
  {
    id: G7-SST-COM-05",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Urban Planning",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " How can the government improve urban planning in Kenyan cities?,
      options: [By enforcing zoning laws and improving public transport., By building more shopping malls., By reducing taxes.", "By limiting population growth.].sort(() => Math.random() - 0.5),
      correctAnswer: By enforcing zoning laws and improving public transport."
    })
  },

  // --- MADA: CULTURE AND HERITAGE (4 Materials) ---
  {
    id: "G7-SST-CUL-01",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Cultural Diversity and Unity,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kenya is a culturally diverse country with over 40 ethnic groups. Why is cultural diversity a strength for Kenya?,
      options: [It enriches the nation's cultural heritage and promotes unity., It causes divisions., "It makes governance difficult., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It enriches the nation's cultural heritage and promotes unity.
    })
  },
  {
    id: G7-SST-CUL-02",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Cultural Diversity and Unity",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " How can Kenyans maintain unity despite their cultural diversity?,
      options: [By embracing national values and respecting each other's cultures., By focusing on differences., By isolating different groups.", "By promoting only one culture.].sort(() => Math.random() - 0.5),
      correctAnswer: By embracing national values and respecting each other's cultures."
    })
  },
  {
    id: "G7-SST-CUL-03",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Preserving Cultural Heritage,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Cultural heritage refers to the traditions, customs, and artifacts passed down through generations. Why is preserving cultural heritage important?,
      options: ["It helps maintain a sense of identity and belonging., It is outdated.", "It is only for old people., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It helps maintain a sense of identity and belonging.
    })
  },
  {
    id: G7-SST-CUL-04",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Preserving Cultural Heritage",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " What is one way to preserve cultural heritage in Kenya?,
      options: [By documenting oral traditions and teaching them in schools., By ignoring the past., By focusing only on modern culture.", "By discouraging traditional practices.].sort(() => Math.random() - 0.5),
      correctAnswer: By documenting oral traditions and teaching them in schools."
    })
  },

  // --- MADA: SOCIAL RELATIONS (4 Materials) ---
  {
    id: "G7-SST-SOC-01",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Social Justice and Equity,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Social justice is the fair distribution of resources and opportunities in a society. What is the goal of social justice?,
      options: [To ensure that all people have equal rights and opportunities., To favor certain groups., "To ignore the poor., To create inequality."].sort(() => Math.random() - 0.5),
      correctAnswer: "To ensure that all people have equal rights and opportunities.
    })
  },
  {
    id: G7-SST-SOC-02",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Social Justice and Equity",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which of the following is a barrier to achieving social justice in Kenya?,
      options: [Corruption and inequality., Equal access to education., Fair distribution of resources.", "Good governance.].sort(() => Math.random() - 0.5),
      correctAnswer: Corruption and inequality."
    })
  },
  {
    id: "G7-SST-SOC-03",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Social Justice and Equity,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the role of the government in promoting social justice in Kenya?,
      options: [To create policies that reduce inequality and protect the vulnerable., To promote inequality., "To ignore the needs of the poor., To favor the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "To create policies that reduce inequality and protect the vulnerable.
    })
  },
  {
    id: G7-SST-SOC-04",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Gender Equality",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Gender equality means that both men and women have equal rights and opportunities. What is one way to promote gender equality in Kenya?,
      options: [By providing equal access to education and jobs., By favoring men., By favoring women.", "By ignoring the issue.].sort(() => Math.random() - 0.5),
      correctAnswer: By providing equal access to education and jobs."
    })
  },

  // --- MADA: OUR NATION (5 Materials) ---
  {
    id: "G7-SST-NAT-01",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's Position in East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "Kenya is one of the six member states of the East African Community (EAC). What is the EAC?,
      options: [A regional intergovernmental organization of East African countries., A political party., "A military alliance., A religious organization."].sort(() => Math.random() - 0.5),
      correctAnswer: "A regional intergovernmental organization of East African countries.
    })
  },
  {
    id: G7-SST-NAT-02",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's Position in East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Which country is a member of the East African Community (EAC)?,
      options: [Uganda, South Africa, Nigeria", "Egypt].sort(() => Math.random() - 0.5),
      correctAnswer: Uganda"
    })
  },
  {
    id: "G7-SST-NAT-03",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Regional Integration,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Regional integration is the process of countries coming together to form a larger economic or political bloc. What is one benefit of regional integration for Kenya?,
      options: [It promotes trade and economic growth., It reduces national sovereignty., "It increases isolation., It limits cultural exchange."].sort(() => Math.random() - 0.5),
      correctAnswer: "It promotes trade and economic growth.
    })
  },
  {
    id: G7-SST-NAT-04",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Regional Integration",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is one challenge facing regional integration in East Africa?,
      options: [Differences in national policies and infrastructure., Shared currency., Common language.", "Uniform education systems.].sort(() => Math.random() - 0.5),
      correctAnswer: Differences in national policies and infrastructure."
    })
  },
  {
    id: "G7-SST-NAT-05",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Regional Integration,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "How does Kenya benefit from being a member of the EAC?,
      options: [Through increased trade, shared infrastructure, and political cooperation., By losing its sovereignty., "By reducing its foreign policy., By isolating itself from the rest of Africa."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through increased trade, shared infrastructure, and political cooperation.
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: G7-SST-CIT-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Role of Citizens in Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Citizens play a crucial role in the development of their country. What is one way citizens can contribute to national development?,
      options: [By paying taxes and participating in civic activities., By avoiding responsibilities., By ignoring the law.", "By not voting.].sort(() => Math.random() - 0.5),
      correctAnswer: By paying taxes and participating in civic activities."
    })
  },
  {
    id: "G7-SST-CIT-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Role of Citizens in Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is the role of volunteerism in community development?,
      options: [It provides free labor and supports community initiatives., It is not important., "It is only for students., It is only for the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "It provides free labor and supports community initiatives.
    })
  },
  {
    id: G7-SST-CIT-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Role of Citizens in Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " How can citizens hold the government accountable for its actions?,
      options: [By participating in democratic processes and demanding transparency., By ignoring the government., By not voting.", "By staying silent.].sort(() => Math.random() - 0.5),
      correctAnswer: By participating in democratic processes and demanding transparency."
    })
  },
  {
    id: "G7-SST-CIT-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Role of Citizens in Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the importance of civic education in Kenya?,
      options: [It teaches citizens about their rights, responsibilities, and how to participate in governance., It is not important., "It is only for politicians., It is only for students."].sort(() => Math.random() - 0.5),
      correctAnswer: "It teaches citizens about their rights, responsibilities, and how to participate in governance.
    })
  },

  // --- MADA: OUR RESOURCES (4 Materials) ---
  {
    id: G7-SST-RES-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Sustainable Utilization of Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Sustainable utilization of resources means using them in a way that meets present needs without compromising the future. What is an example of sustainable resource use?,
      options: [Using renewable energy sources like solar and wind., Overfishing., Deforestation.", "Polluting rivers.].sort(() => Math.random() - 0.5),
      correctAnswer: Using renewable energy sources like solar and wind."
    })
  },
  {
    id: "G7-SST-RES-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Sustainable Utilization of Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is one benefit of sustainable resource utilization for Kenya?,
      options: [It ensures long-term economic growth and environmental conservation., It leads to resource depletion., "It causes environmental degradation., It reduces biodiversity."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures long-term economic growth and environmental conservation.
    })
  },
  {
    id: G7-SST-RES-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Conservation of Natural Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " How can communities contribute to the conservation of natural resources?,
      options: [By engaging in reforestation and protecting water sources., By wasting resources., By dumping waste into rivers.", "By ignoring environmental policies.].sort(() => Math.random() - 0.5),
      correctAnswer: By engaging in reforestation and protecting water sources."
    })
  },
  {
    id: "G7-SST-RES-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Conservation of Natural Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 19,",
    generate: () => ({
      text: "What is the role of the government in the conservation of natural resources in Kenya?,
      options: [To enforce environmental laws and promote sustainable practices., To exploit resources without limits., "To ignore environmental issues., To reduce forest cover."].sort(() => Math.random() - 0.5),
      correctAnswer: "To enforce environmental laws and promote sustainable practices.
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G7-SST-TRA-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Role in Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Transport and communication play a vital role in the development of a country. How does improved transport infrastructure contribute to economic development?,
      options: [It reduces the cost of moving goods and connects markets., It increases the cost of goods., It creates trade barriers.", "It limits access to markets.].sort(() => Math.random() - 0.5),
      correctAnswer: It reduces the cost of moving goods and connects markets."
    })
  },
  {
    id: "G7-SST-TRA-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Role in Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the impact of modern communication technologies on development in rural areas?,
      options: [They improve access to information and services., They isolate rural communities., "They are not accessible in rural areas., They slow down development."].sort(() => Math.random() - 0.5),
      correctAnswer: "They improve access to information and services.
    })
  },
  {
    id: G7-SST-TRA-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Role in Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " Which of the following is a challenge to the development of transport infrastructure in Kenya?,
      options: [Limited funding and terrain difficulties., Excessive funding., Easy terrain.", "High government support.].sort(() => Math.random() - 0.5),
      correctAnswer: Limited funding and terrain difficulties."
    })
  },
  {
    id: "G7-SST-TRA-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Role in Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Why is access to reliable communication important for economic development in Kenya?,
      options: [It facilitates trade, improves efficiency, and enables e-commerce., It is not important., "It only benefits large companies., It is only for urban areas."].sort(() => Math.random() - 0.5),
      correctAnswer: "It facilitates trade, improves efficiency, and enables e-commerce.
    })
  },

  // --- MADA: HISTORY (4 Materials) ---
  {
    id: G7-SST-HIS-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "History,
    subtopic: "Pre-colonial East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Before the arrival of Europeans, East Africa was home to several kingdoms and empires. Which of the following was a major pre-colonial kingdom in East Africa?,
      options: [The Buganda Kingdom, The Roman Empire, The British Empire", "The Egyptian Empire].sort(() => Math.random() - 0.5),
      correctAnswer: The Buganda Kingdom"
    })
  },
  {
    id: "G7-SST-HIS-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Pre-colonial East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Trade routes played a major role in the history of East Africa. What was the main item traded along the East African coast?,
      options: [Ivory, Gold, "Spices, Silk"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ivory
    })
  },
  {
    id: G7-SST-HIS-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "History,
    subtopic: "Pre-colonial East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Bantu migration was a significant event in the history of East Africa. What was the main reason for the Bantu migration?,
      options: [Search for fertile land and better resources., Wars and conflicts., Religious reasons.", "Climate change.].sort(() => Math.random() - 0.5),
      correctAnswer: Search for fertile land and better resources."
    })
  },
  {
    id: "G7-SST-HIS-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Pre-colonial East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Swahili people developed a unique culture along the East African coast. What was the main influence on the Swahili culture?,
      options: [A blend of African, Arab, and Persian cultures., British colonialism., "Portuguese invasion., Indian traders."].sort(() => Math.random() - 0.5),
      correctAnswer: "A blend of African, Arab, and Persian cultures.
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: G7-SST-GOV-01",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Role of the Judiciary",
    maxUses: 5,
    usageCount: 0,
    minWords: 19,
    generate: () => ({
      text: " The Judiciary plays a vital role in good governance in Kenya. What is the main function of the Judiciary?,
      options: [To interpret the law and ensure justice., To make laws., To execute laws.", "To manage the military.].sort(() => Math.random() - 0.5),
      correctAnswer: To interpret the law and ensure justice."
    })
  },
  {
    id: "G7-SST-GOV-02",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Role of the Judiciary,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the importance of an independent Judiciary in a democratic society?,
      options: [It ensures fair and impartial application of the law., It allows the executive to control the courts., "It is not important., It only benefits the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures fair and impartial application of the law.
    })
  },
  {
    id: G7-SST-GOV-03",
    grade: "Grade 7,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Rule of Law",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The rule of law means that everyone, including the government, is subject to the law. Why is the rule of law important for good governance?,
      options: [It ensures accountability and protects citizens' rights., It allows the government to act without limits., It is not important.", "It only protects the rich.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures accountability and protects citizens' rights."
    })
  },
  {
    id: "G7-SST-GOV-04",
    grade: "Grade 7",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Rule of Law,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "How does the rule of law promote peace and stability in a society?,
      options: [By ensuring that everyone is treated fairly and justice is served., By allowing the powerful to break the law., "By ignoring the rights of citizens., By favoring the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "By ensuring that everyone is treated fairly and justice is served.
    })
  }
  // =========================================================================
  // GRADE 8: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (5 Materials) ---
  {
    id: G8-SST-ENV-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Environmental Degradation",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Environmental degradation refers to the deterioration of the environment through depletion of resources and destruction of ecosystems. Which of the following is a major cause of environmental degradation in Kenya?,
      options: [Deforestation and industrial pollution., Afforestation and recycling., Rainwater harvesting.", "Solar energy production.].sort(() => Math.random() - 0.5),
      correctAnswer: Deforestation and industrial pollution."
    })
  },
  {
    id: "G8-SST-ENV-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Environmental Degradation,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Pollution is a key aspect of environmental degradation. What is the main source of air pollution in urban areas of Kenya?,
      options: [Vehicle emissions and industrial processes., Planting trees., "Cleaning streets., Recycling waste."].sort(() => Math.random() - 0.5),
      correctAnswer: "Vehicle emissions and industrial processes.
    })
  },
  {
    id: G8-SST-ENV-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Environmental Degradation",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Water pollution is a serious problem in many parts of Kenya. What is the main cause of water pollution in Kenyan rivers and lakes?,
      options: [Industrial waste and agricultural runoff., Rainfall., Solar radiation.", "Wind erosion.].sort(() => Math.random() - 0.5),
      correctAnswer: Industrial waste and agricultural runoff."
    })
  },
  {
    id: "G8-SST-ENV-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Environmental Management,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Environmental management involves the responsible use and protection of the environment. What is the role of the National Environment Management Authority (NEMA) in Kenya?,
      options: [To enforce environmental laws and promote sustainable practices., To increase pollution., "To promote deforestation., To ignore environmental issues."].sort(() => Math.random() - 0.5),
      correctAnswer: "To enforce environmental laws and promote sustainable practices.
    })
  },
  {
    id: G8-SST-ENV-05",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Environmental Management",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " Global warming is a pressing environmental issue. What is one of the main effects of global warming on Kenya?,
      options: [Increased frequency of droughts and floods., Lower temperatures., Increased rainfall.", "Reduced wind speeds.].sort(() => Math.random() - 0.5),
      correctAnswer: Increased frequency of droughts and floods."
    })
  },

  // --- MADA: OUR COMMUNITY (5 Materials) ---
  {
    id: "G8-SST-COM-01",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Social Challenges,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Communities in Kenya face various social challenges. Which of the following is a major social challenge facing Kenyan communities today?,
      options: [Poverty and unemployment., High birth rates only., "Lack of media., Overabundance of resources."].sort(() => Math.random() - 0.5),
      correctAnswer: "Poverty and unemployment.
    })
  },
  {
    id: G8-SST-COM-02",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Social Challenges",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Inequality is a significant social issue in Kenya. What is the main driver of inequality in the country?,
      options: [Unequal access to education and economic opportunities., Equal distribution of wealth., Strong social safety nets.", "Universal healthcare.].sort(() => Math.random() - 0.5),
      correctAnswer: Unequal access to education and economic opportunities."
    })
  },
  {
    id: "G8-SST-COM-03",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Social Challenges,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "How can the government address the challenge of unemployment in Kenya?,
      options: [By promoting entrepreneurship and investing in job-creating industries., By increasing taxes., "By reducing education funding., By ignoring the issue."].sort(() => Math.random() - 0.5),
      correctAnswer: "By promoting entrepreneurship and investing in job-creating industries.
    })
  },
  {
    id: G8-SST-COM-04",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Solutions to Social Challenges",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What role can civil society organizations play in addressing social challenges in Kenya?,
      options: [They can advocate for policy change and provide community-based solutions., They can ignore the issues., They can exploit the vulnerable.", "They can create more challenges.].sort(() => Math.random() - 0.5),
      correctAnswer: They can advocate for policy change and provide community-based solutions."
    })
  },
  {
    id: "G8-SST-COM-05",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Solutions to Social Challenges,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the role of education in overcoming social challenges?,
      options: [Education empowers individuals and provides skills to break the cycle of poverty., Education is not helpful., "Education only benefits the rich., Education creates more problems."].sort(() => Math.random() - 0.5),
      correctAnswer: "Education empowers individuals and provides skills to break the cycle of poverty.
    })
  },

  // --- MADA: CULTURE AND HERITAGE (4 Materials) ---
  {
    id: G8-SST-CUL-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Preserving Cultural Heritage",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Cultural heritage includes tangible and intangible artifacts inherited from the past. Which of the following is an example of intangible cultural heritage?,
      options: [Oral traditions and traditional dances., A historical building., A museum artifact.", "An ancient manuscript.].sort(() => Math.random() - 0.5),
      correctAnswer: Oral traditions and traditional dances."
    })
  },
  {
    id: "G8-SST-CUL-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Preserving Cultural Heritage,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "What is the role of museums in preserving cultural heritage?,
      options: [Museums display and protect historical artifacts and educate the public about heritage., Museums replace traditional cultures., "Museums only entertain visitors., Museums only focus on modern art."].sort(() => Math.random() - 0.5),
      correctAnswer: "Museums display and protect historical artifacts and educate the public about heritage.
    })
  },
  {
    id: G8-SST-CUL-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Preserving Cultural Heritage",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Heritage sites are important places of cultural, historical, or natural significance. What is the best way to protect heritage sites in Kenya?,
      options: [By enforcing strict laws against vandalism and promoting sustainable tourism., By allowing unrestricted access to visitors., By ignoring them.", "By selling them to private investors.].sort(() => Math.random() - 0.5),
      correctAnswer: By enforcing strict laws against vandalism and promoting sustainable tourism."
    })
  },
  {
    id: "G8-SST-CUL-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Preserving Cultural Heritage,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Why is it important for the government to invest in the preservation of cultural heritage?,
      options: [It protects national identity, promotes tourism, and educates future generations., It is a waste of resources., "It only benefits the rich., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It protects national identity, promotes tourism, and educates future generations.
    })
  },

  // --- MADA: SOCIAL RELATIONS (4 Materials) ---
  {
    id: G8-SST-SOC-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Gender Equality and Inclusion",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Gender equality is a fundamental human right. What is the main benefit of achieving gender equality in Kenya?,
      options: [It allows both men and women to contribute fully to the economy and society., It favors women over men., It favors men over women.", "It reduces economic growth.].sort(() => Math.random() - 0.5),
      correctAnswer: It allows both men and women to contribute fully to the economy and society."
    })
  },
  {
    id: "G8-SST-SOC-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Gender Equality and Inclusion,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is one of the main challenges to achieving gender equality in Kenya?,
      options: [Cultural norms and stereotypes that limit women's opportunities., Over-representation of women in decision-making., "Equal access to education., Strong legal protections."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cultural norms and stereotypes that limit women's opportunities.
    })
  },
  {
    id: G8-SST-SOC-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Gender Equality and Inclusion",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Inclusion involves ensuring that all people, including those with disabilities, have equal access to opportunities. Why is inclusion important in society?,
      options: [It ensures that everyone can participate fully and contribute to development., It is not necessary., It only benefits the rich.", "It causes division.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures that everyone can participate fully and contribute to development."
    })
  },
  {
    id: "G8-SST-SOC-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Rights of Persons with Disabilities,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Kenyan Constitution protects the rights of persons with disabilities. What is one right that persons with disabilities are entitled to?,
      options: [The right to accessible infrastructure and equal opportunities., The right to be ignored., "The right to be excluded from society., The right to discrimination."].sort(() => Math.random() - 0.5),
      correctAnswer: "The right to accessible infrastructure and equal opportunities.
    })
  },

  // --- MADA: OUR NATION (4 Materials) ---
  {
    id: G8-SST-NAT-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's International Relations",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kenya maintains diplomatic relations with many countries around the world. What is the purpose of Kenya's foreign policy?,
      options: [To promote peace, trade, and international cooperation., To isolate Kenya from the rest of the world., To dominate other countries.", "To refuse international aid.].sort(() => Math.random() - 0.5),
      correctAnswer: To promote peace, trade, and international cooperation."
    })
  },
  {
    id: "G8-SST-NAT-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's International Relations,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Kenya is a member of the United Nations (UN). What is the primary role of the UN in international affairs?,
      options: [To maintain international peace and security., To promote war., "To control the world., To favor rich countries."].sort(() => Math.random() - 0.5),
      correctAnswer: "To maintain international peace and security.
    })
  },
  {
    id: G8-SST-NAT-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's International Relations",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Kenya is also a member of the African Union (AU). What is the main objective of the African Union?,
      options: [To promote unity, solidarity, and development among African countries., To promote division in Africa., To colonize other countries.", "To favor European countries.].sort(() => Math.random() - 0.5),
      correctAnswer: To promote unity, solidarity, and development among African countries."
    })
  },
  {
    id: "G8-SST-NAT-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's International Relations,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Kenya plays an active role in peacekeeping missions around the world. Why is Kenya's participation in peacekeeping important?,
      options: [It contributes to global peace and strengthens Kenya's international reputation., It is a waste of resources., "It weakens Kenya's military., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It contributes to global peace and strengthens Kenya's international reputation.
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: G8-SST-CIT-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Participating in Democratic Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Participating in democratic processes is a fundamental duty of citizens. What is the most direct way for citizens to participate in democracy?,
      options: [Voting in elections., Watching the news., Reading newspapers.", "Talking to friends.].sort(() => Math.random() - 0.5),
      correctAnswer: Voting in elections."
    })
  },
  {
    id: "G8-SST-CIT-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Participating in Democratic Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Devolution is the transfer of power from the national government to the county governments. What is the main benefit of devolution in Kenya?,
      options: [It brings government services closer to the people and promotes local development., It makes the national government weaker., "It increases bureaucracy., It reduces public participation."].sort(() => Math.random() - 0.5),
      correctAnswer: "It brings government services closer to the people and promotes local development.
    })
  },
  {
    id: G8-SST-CIT-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Participating in Democratic Processes",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " What are the main roles of county governments in Kenya under devolution?,
      options: [They manage healthcare, early childhood education, and county roads., They manage national defense., They conduct foreign policy.", "They manage the national budget.].sort(() => Math.random() - 0.5),
      correctAnswer: They manage healthcare, early childhood education, and county roads."
    })
  },
  {
    id: "G8-SST-CIT-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Participating in Democratic Processes,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Citizens can also participate in democracy beyond voting. What is another way citizens can influence government decisions?,
      options: [By attending public forums, petitions, and peaceful protests., By ignoring politics., "By bribing officials., By staying silent."].sort(() => Math.random() - 0.5),
      correctAnswer: "By attending public forums, petitions, and peaceful protests.
    })
  },

  // --- MADA: OUR RESOURCES (4 Materials) ---
  {
    id: G8-SST-RES-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Conservation of Natural Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Conservation of natural resources is essential for sustainable development. What is the goal of conservation?,
      options: [To protect and preserve resources for current and future generations., To exploit resources without limits., To sell resources to other countries.", "To ignore environmental concerns.].sort(() => Math.random() - 0.5),
      correctAnswer: To protect and preserve resources for current and future generations."
    })
  },
  {
    id: "G8-SST-RES-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Conservation of Natural Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What role does the Kenya Forest Service play in resource conservation?,
      options: [They manage, protect, and conserve forests in Kenya., They promote deforestation., "They encourage logging., They ignore forest conservation."].sort(() => Math.random() - 0.5),
      correctAnswer: "They manage, protect, and conserve forests in Kenya.
    })
  },
  {
    id: G8-SST-RES-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Conservation of Natural Resources",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " What is one of the main threats to wildlife conservation in Kenya?,
      options: [Poaching and habitat loss., Increased animal populations., Strong anti-poaching laws.", "Wildlife sanctuaries.].sort(() => Math.random() - 0.5),
      correctAnswer: Poaching and habitat loss."
    })
  },
  {
    id: "G8-SST-RES-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Conservation of Natural Resources,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "How can communities contribute to the conservation of wildlife in Kenya?,
      options: [By reporting poaching and participating in eco-tourism., By hunting animals., "By selling ivory., By ignoring conservation efforts."].sort(() => Math.random() - 0.5),
      correctAnswer: "By reporting poaching and participating in eco-tourism.
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G8-SST-TRA-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Future Trends in Transport",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The future of transport is moving towards sustainability and efficiency. What is an emerging trend in the transport sector in Kenya?,
      options: [The adoption of electric vehicles and e-mobility., The increased use of animal-drawn carts., The decline of road networks.", "The reduction of public transport.].sort(() => Math.random() - 0.5),
      correctAnswer: The adoption of electric vehicles and e-mobility."
    })
  },
  {
    id: "G8-SST-TRA-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Future Trends in Transport,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "What is the main benefit of transitioning to e-mobility in Kenya?,
      options: [It reduces greenhouse gas emissions and reliance on fossil fuels., It increases pollution., "It is more expensive., It is less efficient."].sort(() => Math.random() - 0.5),
      correctAnswer: "It reduces greenhouse gas emissions and reliance on fossil fuels.
    })
  },
  {
    id: G8-SST-TRA-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Future Trends in Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The future of communication is being shaped by rapid technological advancements. What is one of the latest trends in communication technology in Kenya?,
      options: [5G networks and fiber optic internet., Smoke signals., Town criers.", "Drum beating.].sort(() => Math.random() - 0.5),
      correctAnswer: 5G networks and fiber optic internet."
    })
  },
  {
    id: "G8-SST-TRA-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Future Trends in Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The rise of digital communication has transformed how people live and work. What is one risk associated with the increasing use of digital communication?,
      options: [Cybersecurity threats and data privacy concerns., No risks., "Increased face-to-face communication., Less dependency on technology."].sort(() => Math.random() - 0.5),
      correctAnswer: "Cybersecurity threats and data privacy concerns.
    })
  },

  // --- MADA: HISTORY (4 Materials) ---
  {
    id: G8-SST-HIS-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "History,
    subtopic: "Post-colonial Kenya",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Kenya gained independence in 1963 and began the process of nation-building. What was one of the main challenges facing Kenya after independence?,
      options: [National unity and economic development., Overpopulation., Lack of natural resources.", "Dependence on foreign aid.].sort(() => Math.random() - 0.5),
      correctAnswer: National unity and economic development."
    })
  },
  {
    id: "G8-SST-HIS-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Post-colonial Kenya,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The post-colonial period in Kenya saw significant political and economic changes. What major political change occurred in Kenya in 2010?,
      options: [The adoption of a new constitution., The end of multi-party politics., "The return to colonial rule., The abolition of the presidency."].sort(() => Math.random() - 0.5),
      correctAnswer: "The adoption of a new constitution.
    })
  },
  {
    id: G8-SST-HIS-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "History,
    subtopic: "Post-colonial Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The post-colonial period in Africa was characterized by the struggle for political and economic independence. What was the main challenge facing many African countries after independence?,
      options: [Political instability and economic underdevelopment., Rapid industrialization., Strong democratic institutions.", "Economic prosperity.].sort(() => Math.random() - 0.5),
      correctAnswer: Political instability and economic underdevelopment."
    })
  },
  {
    id: "G8-SST-HIS-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Post-colonial Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The formation of the Organization of African Unity (OAU) was a significant event in post-colonial Africa. What was the primary goal of the OAU?,
      options: [To promote unity and solidarity among African states., To promote division., "To colonize other countries., To favor European countries."].sort(() => Math.random() - 0.5),
      correctAnswer: "To promote unity and solidarity among African states.
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: G8-SST-GOV-01",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Role of the Executive and Legislature",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " The Executive and the Legislature are two key institutions of governance in Kenya. What is the primary role of the Executive arm?,
      options: [To implement and enforce laws., To make laws., To interpret laws.", "To appoint judges.].sort(() => Math.random() - 0.5),
      correctAnswer: To implement and enforce laws."
    })
  },
  {
    id: "G8-SST-GOV-02",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Role of the Executive and Legislature,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "The Legislature, or Parliament, is the law-making body of Kenya. What is the main function of Parliament?,
      options: ["To debate and pass laws., To execute laws.", "To interpret laws., To appoint judges."].sort(() => Math.random() - 0.5),
      correctAnswer: "To debate and pass laws.
    })
  },
  {
    id: G8-SST-GOV-03",
    grade: "Grade 8,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Role of the Executive and Legislature",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " The Executive and Legislature must work together to ensure good governance. What is the role of the Ethics and Anti-Corruption Commission (EACC) in Kenya?,
      options: [To investigate and combat corruption., To promote corruption., To favor the rich.", "To ignore ethical violations.].sort(() => Math.random() - 0.5),
      correctAnswer: To investigate and combat corruption."
    })
  },
  {
    id: "G8-SST-GOV-04",
    grade: "Grade 8",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Role of the Executive and Legislature,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Why is the principle of separation of powers important for good governance in Kenya?,
      options: [It ensures that no single branch of government becomes too powerful., It allows one branch to control the others., "It makes government inefficient., It is not important."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures that no single branch of government becomes too powerful.
    })
  },

  // =========================================================================
  // GRADE 9: 35 MATERIALS (KICD SOCIAL STUDIES SYLLABUS)
  // =========================================================================

  // --- MADA: OUR ENVIRONMENT (5 Materials) ---
  {
    id: G9-SST-ENV-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Global Environmental Issues",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Global environmental issues, such as climate change and ozone depletion, require international cooperation. What is the main cause of ozone depletion?,
      options: [The release of chlorofluorocarbons (CFCs) into the atmosphere., The increase in tree planting., The reduction of greenhouse gases.", "The use of solar energy.].sort(() => Math.random() - 0.5),
      correctAnswer: The release of chlorofluorocarbons (CFCs) into the atmosphere."
    })
  },
  {
    id: "G9-SST-ENV-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "Global Environmental Issues,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Paris Agreement is an international treaty on climate change. What is the main goal of the Paris Agreement?,
      options: [To limit global warming to below 2°C., To increase global temperatures., "To promote the use of fossil fuels., To ignore climate change."].sort(() => Math.random() - 0.5),
      correctAnswer: "To limit global warming to below 2°C.
    })
  },
  {
    id: G9-SST-ENV-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "Global Environmental Issues",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " What is one of the main effects of climate change on developing countries in Africa?,
      options: [Increased droughts, floods, and food insecurity., Lower temperatures., Increased rainfall.", "Reduced wind speeds.].sort(() => Math.random() - 0.5),
      correctAnswer: Increased droughts, floods, and food insecurity."
    })
  },
  {
    id: "G9-SST-ENV-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Environment",
    subtopic: "International Environmental Agreements,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "International environmental agreements are important for addressing global issues. What is the role of the United Nations Environment Programme (UNEP) in environmental governance?,
      options: [To coordinate global environmental efforts and promote sustainable development., To increase pollution., "To promote deforestation., To ignore environmental issues."].sort(() => Math.random() - 0.5),
      correctAnswer: "To coordinate global environmental efforts and promote sustainable development.
    })
  },
  {
    id: G9-SST-ENV-05",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Environment,
    subtopic: "International Environmental Agreements",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " How can countries work together to mitigate the effects of climate change?,
      options: [By sharing technology, financing green projects, and reducing emissions., By competing with each other., By ignoring the problem.", "By increasing their emissions.].sort(() => Math.random() - 0.5),
      correctAnswer: By sharing technology, financing green projects, and reducing emissions."
    })
  },

  // --- MADA: OUR COMMUNITY (5 Materials) ---
  {
    id: "G9-SST-COM-01",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urban Planning and Sustainable Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Sustainable urban planning aims to create cities that are environmentally, socially, and economically sustainable. What is a key principle of sustainable urban planning?,
      options: ["Creating green spaces and promoting public transport., Building more roads.", "Increasing urban sprawl., Ignoring environmental concerns."].sort(() => Math.random() - 0.5),
      correctAnswer: "Creating green spaces and promoting public transport.
    })
  },
  {
    id: G9-SST-COM-02",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Urban Planning and Sustainable Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " What is the concept of a 'smart city'?,
      options: [A city that uses technology to improve the quality of life and manage urban resources efficiently., A city that ignores technology., A city that is overcrowded.", "A city that has no services.].sort(() => Math.random() - 0.5),
      correctAnswer: A city that uses technology to improve the quality of life and manage urban resources efficiently."
    })
  },
  {
    id: "G9-SST-COM-03",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urban Planning and Sustainable Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "What is one of the main challenges facing urban areas in Kenya today?,
      options: [Inadequate housing and poor infrastructure., Overabundance of housing., "Excessively clean streets., Low population density."].sort(() => Math.random() - 0.5),
      correctAnswer: "Inadequate housing and poor infrastructure.
    })
  },
  {
    id: G9-SST-COM-04",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Community,
    subtopic: "Urban Planning and Sustainable Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " What is the role of the government in promoting sustainable urban development?,
      options: [To invest in infrastructure, enforce zoning laws, and promote green building practices., To ignore urban issues., To focus only on rural areas.", "To discourage investment in cities.].sort(() => Math.random() - 0.5),
      correctAnswer: To invest in infrastructure, enforce zoning laws, and promote green building practices."
    })
  },
  {
    id: "G9-SST-COM-05",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Community",
    subtopic: "Urban Planning and Sustainable Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Why is citizen participation important in urban planning?,
      options: [It ensures that the community's needs and interests are taken into account., It slows down development., "It is not important., It only benefits the rich."].sort(() => Math.random() - 0.5),
      correctAnswer: "It ensures that the community's needs and interests are taken into account.
    })
  },

  // --- MADA: CULTURE AND HERITAGE (4 Materials) ---
  {
    id: G9-SST-CUL-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Globalization and Cultural Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Globalization has led to cultural change around the world. What is one positive effect of globalization on culture?,
      options: [It promotes cultural exchange and access to global ideas., It destroys all local cultures., It makes everyone the same.", "It increases cultural isolation.].sort(() => Math.random() - 0.5),
      correctAnswer: It promotes cultural exchange and access to global ideas."
    })
  },
  {
    id: "G9-SST-CUL-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Globalization and Cultural Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "What is one negative effect of globalization on local cultures?,
      options: [It can lead to the erosion of local languages and traditions., It strengthens local languages., "It promotes local festivals., It increases the use of local materials."].sort(() => Math.random() - 0.5),
      correctAnswer: "It can lead to the erosion of local languages and traditions.
    })
  },
  {
    id: G9-SST-CUL-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Culture and Heritage,
    subtopic: "Globalization and Cultural Change",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The influence of media has played a significant role in spreading global culture. What is a potential danger of the media's influence on culture in Kenya?,
      options: [It can promote cultural homogenization and overshadow local values., It promotes diversity., It supports local traditions.", "It has no effect.].sort(() => Math.random() - 0.5),
      correctAnswer: It can promote cultural homogenization and overshadow local values."
    })
  },
  {
    id: "G9-SST-CUL-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Culture and Heritage",
    subtopic: "Globalization and Cultural Change,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "How can Kenyans preserve their cultural identity in the age of globalization?,
      options: [By celebrating their traditions, speaking their languages, and passing on their heritage., By rejecting global culture., "By only using English., By ignoring their past."].sort(() => Math.random() - 0.5),
      correctAnswer: "By celebrating their traditions, speaking their languages, and passing on their heritage.
    })
  },

  // --- MADA: SOCIAL RELATIONS (4 Materials) ---
  {
    id: G9-SST-SOC-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Peace and Conflict Resolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Peace is essential for development and social stability. What is one of the main causes of conflict in society?,
      options: [Inequality and competition over resources., Shared interests., Strong governments.", "Equal opportunities.].sort(() => Math.random() - 0.5),
      correctAnswer: Inequality and competition over resources."
    })
  },
  {
    id: "G9-SST-SOC-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Peace and Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "What is the best way to resolve a conflict between two communities?,
      options: [Through dialogue, negotiation, and mediation., Through violence., "Through ignoring the problem., Through legal threats."].sort(() => Math.random() - 0.5),
      correctAnswer: "Through dialogue, negotiation, and mediation.
    })
  },
  {
    id: G9-SST-SOC-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Social Relations,
    subtopic: "Peace and Conflict Resolution",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " The United Nations plays a crucial role in peacekeeping around the world. What is the main purpose of UN peacekeeping missions?,
      options: [To maintain peace and security in conflict-affected areas., To take sides in conflicts., To support rebel groups.", "To ignore conflicts.].sort(() => Math.random() - 0.5),
      correctAnswer: To maintain peace and security in conflict-affected areas."
    })
  },
  {
    id: "G9-SST-SOC-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Social Relations",
    subtopic: "Peace and Conflict Resolution,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "What is the role of civil society in promoting peace in a community?,
      options: [They can promote dialogue, provide education, and advocate for peaceful resolution., They can promote violence., "They can ignore conflicts., They can take sides in conflicts."].sort(() => Math.random() - 0.5),
      correctAnswer: "They can promote dialogue, provide education, and advocate for peaceful resolution.
    })
  },

  // --- MADA: OUR NATION (4 Materials) ---
  {
    id: G9-SST-NAT-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's National Development Goals",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Kenya has set ambitious development goals to achieve by 2030. What is the name of Kenya's long-term development blueprint?,
      options: [Vision 2030, Vision 2020, Vision 2050", "Vision 2040].sort(() => Math.random() - 0.5),
      correctAnswer: Vision 2030"
    })
  },
  {
    id: "G9-SST-NAT-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's National Development Goals,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Sustainable Development Goals (SDGs) are a global framework for development. Which SDG focuses on ensuring access to clean water and sanitation?,
      options: [SDG 6 (Clean Water and Sanitation), SDG 1 (No Poverty), "SDG 4 (Quality Education), SDG 8 (Decent Work)"].sort(() => Math.random() - 0.5),
      correctAnswer: "SDG 6 (Clean Water and Sanitation)
    })
  },
  {
    id: G9-SST-NAT-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Nation,
    subtopic: "Kenya's National Development Goals",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " What is one of Kenya's main economic blueprints for achieving development?,
      options: [The Big Four Agenda (Manufacturing, Affordable Housing, Universal Healthcare, Food Security)., The Big Five Agenda., The Three Pillars Agenda.", "The Rural Development Program.].sort(() => Math.random() - 0.5),
      correctAnswer: The Big Four Agenda (Manufacturing, Affordable Housing, Universal Healthcare, Food Security)."
    })
  },
  {
    id: "G9-SST-NAT-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Nation",
    subtopic: "Kenya's National Development Goals,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "Achieving national development goals requires collaboration between the government and citizens. What is the role of citizens in achieving Vision 2030?,
      options: [To work hard, pay taxes, and participate in development projects., To rely on the government alone., "To ignore development goals., To avoid civic responsibilities."].sort(() => Math.random() - 0.5),
      correctAnswer: "To work hard, pay taxes, and participate in development projects.
    })
  },

  // --- MADA: CITIZENSHIP (4 Materials) ---
  {
    id: G9-SST-CIT-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Active Citizenship",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Active citizenship involves participating in community and national affairs. What is an example of active citizenship?,
      options: [Volunteering in community projects and participating in civic forums., Ignoring social issues., Not voting.", "Staying at home.].sort(() => Math.random() - 0.5),
      correctAnswer: Volunteering in community projects and participating in civic forums."
    })
  },
  {
    id: "G9-SST-CIT-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Active Citizenship,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "Civil society organizations play a key role in promoting active citizenship. What is the role of civil society in a democratic society?,
      options: [To advocate for citizens' rights and hold the government accountable., To support the government without question., "To ignore public issues., To limit citizen participation."].sort(() => Math.random() - 0.5),
      correctAnswer: "To advocate for citizens' rights and hold the government accountable.
    })
  },
  {
    id: G9-SST-CIT-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Citizenship,
    subtopic: "Active Citizenship",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " What is the role of social responsibility in active citizenship?,
      options: [It encourages citizens to take responsibility for the well-being of their communities., It encourages selfishness., It promotes greed.", "It discourages community involvement.].sort(() => Math.random() - 0.5),
      correctAnswer: It encourages citizens to take responsibility for the well-being of their communities."
    })
  },
  {
    id: "G9-SST-CIT-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Citizenship",
    subtopic: "Active Citizenship,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "How can citizens advocate for change in their communities?,
      options: [By organizing forums, signing petitions, and working with local leaders., By staying silent., "By ignoring problems., By blaming the government."].sort(() => Math.random() - 0.5),
      correctAnswer: "By organizing forums, signing petitions, and working with local leaders.
    })
  },

  // --- MADA: OUR RESOURCES (4 Materials) ---
  {
    id: G9-SST-RES-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Economic Resources and Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Economic resources are the inputs used to produce goods and services. What is the relationship between resource utilization and economic development?,
      options: [Efficient resource utilization drives economic growth., Resource utilization has no impact., Resource utilization slows growth.", "Resource utilization is irrelevant.].sort(() => Math.random() - 0.5),
      correctAnswer: Efficient resource utilization drives economic growth."
    })
  },
  {
    id: "G9-SST-RES-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Economic Resources and Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 21,",
    generate: () => ({
      text: "The Blue Economy is a concept that focuses on the sustainable use of ocean resources for economic growth. Why is the Blue Economy important for Kenya?,
      options: [Kenya has a vast coastline and ocean resources that can drive development., Kenya does not have a coastline., "The Blue Economy is not relevant., The Blue Economy only benefits landlocked countries."].sort(() => Math.random() - 0.5),
      correctAnswer: "Kenya has a vast coastline and ocean resources that can drive development.
    })
  },
  {
    id: G9-SST-RES-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Our Resources,
    subtopic: "Economic Resources and Development",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " Green energy is derived from renewable sources and has a lower environmental impact. Why is the transition to green energy important for Kenya's development?,
      options: [It reduces reliance on fossil fuels and promotes sustainable growth., It increases pollution., It is more expensive.", "It is less efficient.].sort(() => Math.random() - 0.5),
      correctAnswer: It reduces reliance on fossil fuels and promotes sustainable growth."
    })
  },
  {
    id: "G9-SST-RES-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Our Resources",
    subtopic: "Economic Resources and Development,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "What is one of the main challenges facing the sustainable development of Kenya's resources?,
      options: [Overexploitation and climate change., Abundance of resources., "Low population., Stable climate."].sort(() => Math.random() - 0.5),
      correctAnswer: "Overexploitation and climate change.
    })
  },

  // --- MADA: TRANSPORT AND COMMUNICATION (4 Materials) ---
  {
    id: G9-SST-TRA-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Technology and Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Technology has revolutionized the way we communicate. What is the role of Information and Communication Technology (ICT) in Kenya's development?,
      options: [ICT drives economic growth and improves access to services., ICT has no role., ICT slows development.", "ICT is not important.].sort(() => Math.random() - 0.5),
      correctAnswer: ICT drives economic growth and improves access to services."
    })
  },
  {
    id: "G9-SST-TRA-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Technology and Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "Cybersecurity is an emerging issue in the digital age. Why is cybersecurity important for individuals and businesses in Kenya?,
      options: [It protects sensitive data and prevents cybercrime., It is not important., "It only benefits large companies., It has no impact on privacy."].sort(() => Math.random() - 0.5),
      correctAnswer: "It protects sensitive data and prevents cybercrime.
    })
  },
  {
    id: G9-SST-TRA-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Transport and Communication,
    subtopic: "Technology and Communication",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " The use of mobile technology has become widespread in Kenya. What is the impact of mobile technology on agriculture in Kenya?,
      options: [It provides farmers with market information and weather updates., It has no impact., It reduces agricultural output.", "It makes farming more difficult.].sort(() => Math.random() - 0.5),
      correctAnswer: It provides farmers with market information and weather updates."
    })
  },
  {
    id: "G9-SST-TRA-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Transport and Communication",
    subtopic: "Technology and Communication,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "What are the main challenges of using technology for communication in rural Kenya?,
      options: [Limited access to infrastructure, low digital literacy, and high costs., High internet speed., "High digital literacy., Low costs."].sort(() => Math.random() - 0.5),
      correctAnswer: "Limited access to infrastructure, low digital literacy, and high costs.
    })
  },

  // --- MADA: HISTORY (4 Materials) ---
  {
    id: G9-SST-HIS-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "History,
    subtopic: "Colonial and Post-colonial East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 22,
    generate: () => ({
      text: " East Africa experienced colonialism in the late 19th and early 20th centuries. Which European country colonized Kenya?,
      options: [Britain, Germany, France", "Portugal].sort(() => Math.random() - 0.5),
      correctAnswer: Britain"
    })
  },
  {
    id: "G9-SST-HIS-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Colonial and Post-colonial East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 23,",
    generate: () => ({
      text: "The struggle for independence in East Africa was driven by various independence movements. Who was a key leader in the fight for Kenya's independence?,
      options: [Jomo Kenyatta, Julius Nyerere, "Milton Obote, Kwame Nkrumah"].sort(() => Math.random() - 0.5),
      correctAnswer: "Jomo Kenyatta
    })
  },
  {
    id: G9-SST-HIS-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "History,
    subtopic: "Colonial and Post-colonial East Africa",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " What was the main challenge faced by East African countries in the post-colonial period?,
      options: [Political instability, economic underdevelopment, and nation-building., Rapid industrialization., Strong democratic institutions.", "Economic prosperity.].sort(() => Math.random() - 0.5),
      correctAnswer: Political instability, economic underdevelopment, and nation-building."
    })
  },
  {
    id: "G9-SST-HIS-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "History",
    subtopic: "Colonial and Post-colonial East Africa,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The formation of the East African Community (EAC) in the post-colonial period was a significant development. What was the main goal of the EAC?,
      options: [To promote regional integration and cooperation., To promote division., "To colonize other countries., To favor European countries."].sort(() => Math.random() - 0.5),
      correctAnswer: "To promote regional integration and cooperation.
    })
  },

  // --- MADA: GOOD GOVERNANCE (4 Materials) ---
  {
    id: G9-SST-GOV-01",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Leadership and Integrity",
    maxUses: 5,
    usageCount: 0,
    minWords: 21,
    generate: () => ({
      text: " Leadership and integrity are essential for good governance. What is the role of integrity in public leadership?,
      options: [It ensures accountability, transparency, and trust., It allows leaders to act without ethics., It is not important.", "It only benefits the rich.].sort(() => Math.random() - 0.5),
      correctAnswer: It ensures accountability, transparency, and trust."
    })
  },
  {
    id: "G9-SST-GOV-02",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Leadership and Integrity,
    maxUses: 5,
    usageCount: 0,
    minWords: 22,",
    generate: () => ({
      text: "The Kenyan Constitution outlines the leadership and integrity requirements for public office. What is one requirement for leadership in Kenya?,
      options: [Ethical conduct, transparency, and accountability., Wealth., "Fame., Political connections."].sort(() => Math.random() - 0.5),
      correctAnswer: "Ethical conduct, transparency, and accountability.
    })
  },
  {
    id: G9-SST-GOV-03",
    grade: "Grade 9,
    subject: Social Studies",
    topic: "Good Governance,
    subtopic: "Leadership and Integrity",
    maxUses: 5,
    usageCount: 0,
    minWords: 23,
    generate: () => ({
      text: " What is the role of citizens in demanding good governance from their leaders?,
      options: [By holding leaders accountable and participating in democratic processes., By staying silent., By ignoring corruption.", "By supporting leaders without question.].sort(() => Math.random() - 0.5),
      correctAnswer: By holding leaders accountable and participating in democratic processes."
    })
  },
  {
    id: "G9-SST-GOV-04",
    grade: "Grade 9",
    subject: "Social Studies",
    topic: "Good Governance",
    subtopic: "Leadership and Integrity,
    maxUses: 5,
    usageCount: 0,
    minWords: 24,",
    generate: () => ({
      text: "What is the role of transparency and accountability in promoting good governance?,
      options: [They ensure that the government acts openly and is answerable to the people., They promote corruption., "They are not important., They only benefit the government."].sort(() => Math.random() - 0.5),
      correctAnswer: "They ensure that the government acts openly and is answerable to the people."
    })
  }

];


