export const kiswahiliTemplates: TemplateRule[] = [
  // =========================================================================
  // DARASA LA 1: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G1-SWA-NOM-01",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino: Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: "Ni neno lipi kati ya haya linalotaja mtu anayefundisha watoto shuleni?,
      options: [Mwalimu, Mpishi, "Dereva, Fundi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mwalimu
    })
  },
  {
    id: G1-SWA-NOM-02",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino: Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno lipi linalotaja mtu anayetibu wagonjwa hospitalini?,
      options: [Daktari, Mwalimu, Mkulima", "Mfanyakazi].sort(() => Math.random() - 0.5),
      correctAnswer: Daktari"
    })
  },
  {
    id: "G1-SWA-NOM-03",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino: Wanyama,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Ni mnyama gani kati ya hawa anayepanda na kutoa maziwa?,
      options: [Ng'ombe, Simba, "Kiboko, Chui"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ng'ombe
    })
  },
  {
    id: G1-SWA-NOM-04",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino: Wanyama",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Ni mnyama gani anayeruka angani na kuimba kwa sauti nzuri?,
      options: [Ndege, Paka, Mbwa", "Samaki].sort(() => Math.random() - 0.5),
      correctAnswer: Ndege"
    })
  },
  {
    id: "G1-SWA-NOM-05",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino: Vitu,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Kati ya vitu hivi, kipi kinatumiwa kuandikia ubaoni?,
      options: [Chaki, Kalamu", "Karatasi, Kibao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Chaki
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G1-SWA-VIT-01",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusafisha sakafu kwa ufagio?,
      options: [Kufagia, Kupika, Kusoma", "Kuimba].sort(() => Math.random() - 0.5),
      correctAnswer: Kufagia"
    })
  },
  {
    id: "G1-SWA-VIT-02",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Ni kitendo gani unachofanya unapotaka kujifunza maneno mapya?,
      options: [Kusoma, Kucheza, "Kulala, Kula"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kusoma
    })
  },
  {
    id: G1-SWA-VIT-03",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Kitendo gani kinafanywa wakati wa kupumzika usiku?,
      options: [Kulala, Kukimbia, Kupanda", "Kupika].sort(() => Math.random() - 0.5),
      correctAnswer: Kulala"
    })
  },
  {
    id: "G1-SWA-VIT-04",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Shule,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Ni kitendo gani unachofanya unapopaka rangi kwenye karatasi?,
      options: [Kuchora, Kukata, "Kushona, Kupiga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuchora
    })
  },
  {
    id: G1-SWA-VIT-05",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Shule",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kuonyesha wengine kuwa na furaha?,
      options: [Kucheka, Kulila, Kuogopa", "Kukaa].sort(() => Math.random() - 0.5),
      correctAnswer: Kucheka"
    })
  },

  // --- MADA: VIUNGO (5 Materials) ---
  {
    id: "G1-SWA- VIU-01",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 14,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuona?,
      options: [Macho, Mikono, "Mguu, Pua"].sort(() => Math.random() - 0.5),
      correctAnswer: "Macho
    })
  },
  {
    id: G1-SWA- VIU-02",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 14,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kusikia sauti?,
      options: [Masikio, Mdomo, Pua", "Kidevu].sort(() => Math.random() - 0.5),
      correctAnswer: Masikio"
    })
  },
  {
    id: "G1-SWA- VIU-03",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kunusa harufu?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },
  {
    id: G1-SWA- VIU-04",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kutembea?,
      options: [Mguu, Mkono, Kichwa", "Tumbo].sort(() => Math.random() - 0.5),
      correctAnswer: Mguu"
    })
  },
  {
    id: "G1-SWA- VIU-05",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuongea na kula?,
      options: [Mdomo, Jicho, "Pua, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mdomo
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G1-SWA-WIN-01",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Neno 'kalamu' linapokuwa wingi, unasemaje?,
      options: [Kalamu, Kalamu, Kalamu", "Kalamu].sort(() => Math.random() - 0.5),
      correctAnswer: Kalamu"
    })
  },
  {
    id: "G1-SWA-WIN-02",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 15,",
    generate: () => ({
      text: "Neno 'kitabu' linapokuwa wingi, unasemaje?,
      options: [Vitabu, Kitabu", "Vitabu, Vitabu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vitabu
    })
  },
  {
    id: G1-SWA-WIN-03",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Neno 'mtoto' linapokuwa wingi, unasemaje?,
      options: [Watoto, Mtoto, Watoto", "Mtoto].sort(() => Math.random() - 0.5),
      correctAnswer: Watoto"
    })
  },
  {
    id: "G1-SWA-WIN-04",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Neno 'nyumba' linapokuwa wingi, unasemaje?,
      options: [Nyumba, Nyumba", "Nyumba, Nyumba"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nyumba
    })
  },
  {
    id: G1-SWA-WIN-05",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno 'tunda' linapokuwa wingi, unasemaje?,
      options: [Matunda, Tunda, Matunda", "Tunda].sort(() => Math.random() - 0.5),
      correctAnswer: Matunda"
    })
  },

  // --- MADA: USOMAJI (Reading Comprehension) (5 Materials) ---
  {
    id: "G1-SWA-USE-01",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Soma: 'Juma ni mvulana mdogo. Ana miaka sita. Ameenda shule na rafiki yake.' Juma ana umri gani?,
      options: [Miaka sita, Miaka saba, "Miaka tano, Miaka nane"].sort(() => Math.random() - 0.5),
      correctAnswer: "Miaka sita
    })
  },
  {
    id: G1-SWA-USE-02",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 35,
    generate: () => ({
      text: " Soma: 'Mama ameenda sokoni. Alinunua matunda na mboga. Alirudi nyumbani kunapika chakula.' Mama alinunua nini sokoni?,
      options: [Matunda na mboga, Nyama na samaki, Viazi na mchele", "Sukari na chai].sort(() => Math.random() - 0.5),
      correctAnswer: Matunda na mboga"
    })
  },
  {
    id: "G1-SWA-USE-03",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 35,",
    generate: () => ({
      text: "Soma: 'Kuku ni ndege wa nyumbani. Hutoa mayai na nyama. Watu huwatunza kwa kupeleka chakula.' Kuku hutoa nini?,
      options: [Mayai na nyama, Maziwa, "Asali, Pamba"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mayai na nyama
    })
  },
  {
    id: G1-SWA-USE-04",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 40,
    generate: () => ({
      text: " Soma: 'Mvua ilinyesha sana. Maji yalijaa barabarani. Watoto walicheza kwenye maji.' Watoto walifanya nini?,
      options: [Walicheza kwenye maji, Walikwenda shule, Walikula chakula", "Walilala].sort(() => Math.random() - 0.5),
      correctAnswer: Walicheza kwenye maji"
    })
  },
  {
    id: "G1-SWA-USE-05",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 40,",
    generate: () => ({
      text: "Soma: 'Mchungaji ana kondoo wengi. Yeye huwachunga kila siku. Kondoo hutoa sufu na nyama.' Mchungaji anafanya nini kila siku?,
      options: [Anawachunga kondoo, Anapika chakula, "Anaendesha gari, Anaandika barua"].sort(() => Math.random() - 0.5),
      correctAnswer: "Anawachunga kondoo
    })
  },

  // --- MADA: MAISHA YA KILA SIKU (Daily Life) (5 Materials) ---
  {
    id: G1-SWA-MAI-01",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Maisha ya Kila Siku,
    subtopic: "Mazoea ya Asubuhi",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Asubuhi unapoamka, ni jambo gani la kwanza unalofanya?,
      options: [Kusali na kunawa, Kula chakula, Kwenda shule", "Kucheza].sort(() => Math.random() - 0.5),
      correctAnswer: Kusali na kunawa"
    })
  },
  {
    id: "G1-SWA-MAI-02",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Maisha ya Kila Siku",
    subtopic: "Mazoea ya Asubuhi,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Unapotoka shule, ni jambo gani unalofanya kwanza?,
      options: [Kucheza na marafiki, Kupika chakula", "Kusoma vitabu, Kwenda sokoni"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kucheza na marafiki
    })
  },
  {
    id: G1-SWA-MAI-03",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Maisha ya Kila Siku,
    subtopic: "Mazoea ya Jioni",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Jioni unapokaa nyumbani, unapenda kufanya nini?,
      options: [Kusoma vitabu, Kucheza mpira, Kupanda miti", "Kupika chakula].sort(() => Math.random() - 0.5),
      correctAnswer: Kusoma vitabu"
    })
  },
  {
    id: "G1-SWA-MAI-04",
    grade: "Grade 1",
    subject: "Kiswahili",
    topic: "Maisha ya Kila Siku",
    subtopic: "Mazoea ya Shule,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Shuleni, ni kitu gani unachotumia kuandika?,
      options: [Kalamu, Kikombe", "Kibao, Karatasi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kalamu
    })
  },
  {
    id: G1-SWA-MAI-05",
    grade: "Grade 1,
    subject: Kiswahili",
    topic: "Maisha ya Kila Siku,
    subtopic: "Mazoea ya Shule",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Mwalimu wako anapokuuliza swali, unapaswa kufanya nini?,
      options: [Inua mkono, Kukaa kimya, Kulala", "Kutoka nje].sort(() => Math.random() - 0.5),
      correctAnswer: Inua mkono"
    })
  },

  // =========================================================================
  // DARASA LA 2: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G2-SWA-NOM-01",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mtu anayefanya kazi ya kuendesha gari?,
      options: [Dereva, Mwalimu, "Daktari, Mkulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dereva
    })
  },
  {
    id: G2-SWA-NOM-02",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni neno lipi linalotaja mtu anayeuza vitu sokoni?,
      options: [Mfanyabiashara, Mwalimu, Mshonaji", "Mfundi].sort(() => Math.random() - 0.5),
      correctAnswer: Mfanyabiashara"
    })
  },
  {
    id: "G2-SWA-NOM-03",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Wanyama,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Ni mnyama gani anayejulikana kwa kuwa mwaminifu na kucheza na mtu?,
      options: [Mbwa, Paka, "Ng'ombe, Kuku"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mbwa
    })
  },
  {
    id: G2-SWA-NOM-04",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Wanyama",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni mnyama gani anayeishi mwituni na ana milia ya rangi nyeusi na nyeupe?,
      options: [Zebra, Simba, Tembo", "Twiga].sort(() => Math.random() - 0.5),
      correctAnswer: Zebra"
    })
  },
  {
    id: "G2-SWA-NOM-05",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Mahali,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mahali pa kuoga?,
      options: [Bafu, Jikoni, "Sebuleni, Choo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bafu
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G2-SWA-VIT-01",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusafisha vyombo vya kulia?,
      options: [Kunawa, Kupika, Kusoma", "Kucheza].sort(() => Math.random() - 0.5),
      correctAnswer: Kunawa"
    })
  },
  {
    id: "G2-SWA-VIT-02",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kutengeneza nguo?,
      options: [Kushona, Kupika, "Kutengeneza, Kufagia"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kushona
    })
  },
  {
    id: G2-SWA-VIT-03",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 15,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kutembea polepole?,
      options: [Kutembea, Kukimbia, Kuruka", "Kupanda].sort(() => Math.random() - 0.5),
      correctAnswer: Kutembea"
    })
  },
  {
    id: "G2-SWA-VIT-04",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kusema kwa sauti?,
      options: [Kuzungumza, Kuinama, "Kupanda, Kukaa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuzungumza
    })
  },
  {
    id: G2-SWA-VIT-05",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kufurahi sana?,
      options: [Kufurahi, Kulila, Kuogopa", "Kukaa kimya].sort(() => Math.random() - 0.5),
      correctAnswer: Kufurahi"
    })
  },

  // --- MADA: VIUNGO VYA MWILI (5 Materials) ---
  {
    id: "G2-SWA- MWI-01",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kunusa harufu?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },
  {
    id: G2-SWA- MWI-02",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuona?,
      options: [Macho, Mikono, Mguu", "Pua].sort(() => Math.random() - 0.5),
      correctAnswer: Macho"
    })
  },
  {
    id: "G2-SWA- MWI-03",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kusikia sauti?,
      options: [Masikio, Mdomo, "Pua, Kidevu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Masikio
    })
  },
  {
    id: G2-SWA- MWI-04",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuongea na kula?,
      options: [Mdomo, Jicho, Pua", "Sikio].sort(() => Math.random() - 0.5),
      correctAnswer: Mdomo"
    })
  },
  {
    id: "G2-SWA- MWI-05",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kutembea?,
      options: [Mguu, Mkono, "Kichwa, Tumbo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mguu
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G2-SWA-WIN-01",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno 'mwaka' linapokuwa wingi, unasemaje?,
      options: [Miaka, Mwaka, Miaka", "Mwaka].sort(() => Math.random() - 0.5),
      correctAnswer: Miaka"
    })
  },
  {
    id: "G2-SWA-WIN-02",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 16,",
    generate: () => ({
      text: "Neno 'jambo' linapokuwa wingi, unasemaje?,
      options: [Mambo, Jambo", "Mambo, Jambo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mambo
    })
  },
  {
    id: G2-SWA-WIN-03",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 16,
    generate: () => ({
      text: " Neno 'rafiki' linapokuwa wingi, unasemaje?,
      options: [Rafiki, Rafiki, Rafiki", "Rafiki].sort(() => Math.random() - 0.5),
      correctAnswer: Rafiki"
    })
  },
  {
    id: "G2-SWA-WIN-04",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Neno 'kisima' linapokuwa wingi, unasemaje?,
      options: [Visima, Kisima", "Visima, Kisima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Visima
    })
  },
  {
    id: G2-SWA-WIN-05",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno 'kikombe' linapokuwa wingi, unasemaje?,
      options: [Vikombe, Kikombe, Vikombe", "Kikombe].sort(() => Math.random() - 0.5),
      correctAnswer: Vikombe"
    })
  },

  // --- MADA: USOMAJI (5 Materials) ---
  {
    id: "G2-SWA-USE-01",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 35,",
    generate: () => ({
      text: "Soma: 'Mama alipika ugali na nyama ya kuku. Watoto walikula kwa shauku. Waliishia kwa kunywa juisi.' Watoto walikula nini?,
      options: [Ugali na nyama, Ugali na samaki, "Wali na matunda, Chapati na mboga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ugali na nyama
    })
  },
  {
    id: G2-SWA-USE-02",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 40,
    generate: () => ({
      text: " Soma: 'Shule yetu ina mti mkubwa. Watoto wanapenda kucheza chini yake. Mti hutoa kivuli cha baridi.' Watoto wanapenda kufanya nini chini ya mti?,
      options: [Kucheza, Kulala, Kula", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kucheza"
    })
  },
  {
    id: "G2-SWA-USE-03",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 40,",
    generate: () => ({
      text: "Soma: 'Mvulana aliyekuwa mvivu aliacha kufanya kazi. Siku moja, baba yake alimwita na kumwonya.' Nini kilifanyika baada ya mvulana kuonywa?,
      options: [Alianza kufanya kazi, Aliendelea kuwa mvivu", "Alikwenda kulala, Alikwenda sokoni"].sort(() => Math.random() - 0.5),
      correctAnswer: "Alianza kufanya kazi
    })
  },
  {
    id: G2-SWA-USE-04",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 40,
    generate: () => ({
      text: " Soma: 'Kiboko ni mnyama mkubwa anayeishi majini. Yeye hula majani na kuwa na nguvu nyingi.' Kiboko anaishi wapi?,
      options: [Majini, Mwituni, Msituni", "Sokoni].sort(() => Math.random() - 0.5),
      correctAnswer: Majini"
    })
  },
  {
    id: "G2-SWA-USE-05",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 45,",
    generate: () => ({
      text: "Soma: 'Mwalimu alisema, 'Msichana anayesoma kwa bidii atafaulu.'' Ni nini kilichosema mwalimu?,
      options: [Msichana anayesoma kwa bidii atafaulu, Wavulana ndio wenye akili", "Wasichana hawapendi kusoma, Kusoma sio muhimu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Msichana anayesoma kwa bidii atafaulu
    })
  },

  // --- MADA: MAAZIMIO (Shughuli) (5 Materials) ---
  {
    id: G2-SWA-SHU-01",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Maazimio,
    subtopic: "Shughuli za Nyumbani",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na mama nyumbani?,
      options: [Kupika, Kulala, Kucheza", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kupika"
    })
  },
  {
    id: "G2-SWA-SHU-02",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Maazimio",
    subtopic: "Shughuli za Nyumbani,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Ni shughuli ipi inayofanywa na baba nyumbani?,
      options: [Kutengeneza, Kucheza, "Kulala, Kusoma"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kutengeneza
    })
  },
  {
    id: G2-SWA-SHU-03",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Maazimio,
    subtopic: "Shughuli za Nyumbani",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na mtoto nyumbani?,
      options: [Kucheza, Kupika, Kutengeneza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kucheza"
    })
  },
  {
    id: "G2-SWA-SHU-04",
    grade: "Grade 2",
    subject: "Kiswahili",
    topic: "Maazimio",
    subtopic: "Shughuli za Shule,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni shughuli ipi inayofanywa shuleni na mwalimu?,
      options: [Kufundisha, Kulala, "Kucheza, Kutengeneza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kufundisha
    })
  },
  {
    id: G2-SWA-SHU-05",
    grade: "Grade 2,
    subject: Kiswahili",
    topic: "Maazimio,
    subtopic: "Shughuli za Shule",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na wanafunzi shuleni?,
      options: [Kusoma, Kupika, Kutengeneza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kusoma"
    })
  }
  // =========================================================================
  // DARASA LA 3: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G3-SWA-NOM-01",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mtu anayetengeneza samaki?,
      options: [Mvuvi, Mkulima, "Mwalimu, Mshonaji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mvuvi
    })
  },
  {
    id: G3-SWA-NOM-02",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni neno lipi linalotaja mtu anayesaidia wagonjwa kupona?,
      options: [Daktari, Mwalimu, Mkulima", "Mshonaji].sort(() => Math.random() - 0.5),
      correctAnswer: Daktari"
    })
  },
  {
    id: "G3-SWA-NOM-03",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Wanyama,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Ni mnyama gani anayejulikana kwa sauti yake ya 'naku'?,
      options: [Kuku, Ng'ombe, "Mbwa, Paka"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuku
    })
  },
  {
    id: G3-SWA-NOM-04",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Mahali",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Ni neno lipi linalotaja mahali pa kuoshea nguo?,
      options: [Mto, Jikoni, Bafu", "Choo].sort(() => Math.random() - 0.5),
      correctAnswer: Mto"
    })
  },
  {
    id: "G3-SWA-NOM-05",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Vitu,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Ni neno lipi linalotaja chombo cha kulia ambacho hutengenezwa kwa udongo?,
      options: [Kikombe, Kikombe, "Sahani, Sufuria"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kikombe
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G3-SWA-VIT-01",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kupanda mlima?,
      options: [Kupanda, Kushuka, Kukimbia", "Kuruka].sort(() => Math.random() - 0.5),
      correctAnswer: Kupanda"
    })
  },
  {
    id: "G3-SWA-VIT-02",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kukata kuni?,
      options: [Kukata, Kupika, "Kusoma, Kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kukata
    })
  },
  {
    id: G3-SWA-VIT-03",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusafisha sahani?,
      options: [Kunawa, Kupika, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kunawa"
    })
  },
  {
    id: "G3-SWA-VIT-04",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kukusanya matunda?,
      options: [Kuvuna, Kupanda, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuvuna
    })
  },
  {
    id: G3-SWA-VIT-05",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kuandika barua?,
      options: [Kuandika, Kusoma, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kuandika"
    })
  },

  // --- MADA: VIUNGO (5 Materials) ---
  {
    id: "G3-SWA-VIU-01",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kwa kunusa harufu ya chakula?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },
  {
    id: G3-SWA-VIU-02",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Viungo,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuona vitabu?,
      options: [Macho, Mikono, Mguu", "Pua].sort(() => Math.random() - 0.5),
      correctAnswer: Macho"
    })
  },
  {
    id: "G3-SWA-VIU-03",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuongea?,
      options: [Mdomo, Jicho, "Pua, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mdomo
    })
  },
  {
    id: G3-SWA-VIU-04",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Viungo,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kusikia sauti?,
      options: [Masikio, Mdomo, Pua", "Kidevu].sort(() => Math.random() - 0.5),
      correctAnswer: Masikio"
    })
  },
  {
    id: "G3-SWA-VIU-05",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kutembea?,
      options: [Mguu, Mkono, "Kichwa, Tumbo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mguu
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G3-SWA-WIN-01",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno 'zawadi' linapokuwa wingi, unasemaje?,
      options: [Zawadi, Zawadi, Zawadi", "Zawadi].sort(() => Math.random() - 0.5),
      correctAnswer: Zawadi"
    })
  },
  {
    id: "G3-SWA-WIN-02",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Neno 'barua' linapokuwa wingi, unasemaje?,
      options: [Barua, Barua", "Barua, Barua"].sort(() => Math.random() - 0.5),
      correctAnswer: "Barua
    })
  },
  {
    id: G3-SWA-WIN-03",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno 'ndizi' linapokuwa wingi, unasemaje?,
      options: [Ndizi, Ndizi, Ndizi", "Ndizi].sort(() => Math.random() - 0.5),
      correctAnswer: Ndizi"
    })
  },
  {
    id: "G3-SWA-WIN-04",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 17,",
    generate: () => ({
      text: "Neno 'kijiji' linapokuwa wingi, unasemaje?,
      options: [Vijiji, Kijiji", "Vijiji, Kijiji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vijiji
    })
  },
  {
    id: G3-SWA-WIN-05",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 17,
    generate: () => ({
      text: " Neno 'gari' linapokuwa wingi, unasemaje?,
      options: [Magari, Gari, Magari", "Gari].sort(() => Math.random() - 0.5),
      correctAnswer: Magari"
    })
  },

  // --- MADA: USOMAJI (5 Materials) ---
  {
    id: "G3-SWA-USE-01",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 40,",
    generate: () => ({
      text: "Soma: 'Mama alinunua maziwa na mayai sokoni. Alirudi nyumbani na kuwapa watoto wakati wa chakula cha mchana.' Mama alinunua nini sokoni?,
      options: [Maziwa na mayai, Ugali na nyama, "Sukari na chai, Matunda na mboga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maziwa na mayai
    })
  },
  {
    id: G3-SWA-USE-02",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 45,
    generate: () => ({
      text: " Soma: 'Juma alikuwa mgonjwa. Daktari alimpa dawa. Siku tatu baadaye, alipona na kurudi shule.' Juma alipona baada ya siku ngapi?,
      options: [Siku tatu, Siku tano, Siku saba", "Siku nne].sort(() => Math.random() - 0.5),
      correctAnswer: Siku tatu"
    })
  },
  {
    id: "G3-SWA-USE-03",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 40,",
    generate: () => ({
      text: "Soma: 'Mkulima alilima shamba lake. Alipanda mbegu za mahindi. Baada ya miezi mitatu, alivuna mazao mengi.' Mkulima alipanda nini?,
      options: [Mahindi, Matunda", "Mboga, Mchele"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mahindi
    })
  },
  {
    id: G3-SWA-USE-04",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 45,
    generate: () => ({
      text: " Soma: 'Wanafunzi walienda mtaani kwa ajili ya matembezi. Walicheza na marafiki zao. Walirudi shule kwa furaha.' Wanafunzi walienda wapi?,
      options: [Mtaani, Sokoni, Msituni", "Jikoni].sort(() => Math.random() - 0.5),
      correctAnswer: Mtaani"
    })
  },
  {
    id: "G3-SWA-USE-05",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 45,",
    generate: () => ({
      text: "Soma: 'Kisima maji ni muhimu sana. Watu hutumia maji kwa kunywa, kuosha, na kupikia.' Maji hutumika kwa nini?,
      options: ["Kunywa, kuosha, na kupikia, Kucheza, kulala, na kulima", "Kusoma, kuandika, na kufagia, Kupanda, kuvuna, na kutengeneza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kunywa, kuosha, na kupikia
    })
  },

  // --- MADA: SHUGHULI (5 Materials) ---
  {
    id: G3-SWA-SHU-01",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Shughuli,
    subtopic: "Shughuli za Nyumbani",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na mama nyumbani?,
      options: [Kupika, Kulala, Kucheza", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kupika"
    })
  },
  {
    id: "G3-SWA-SHU-02",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Shughuli",
    subtopic: "Shughuli za Nyumbani,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni shughuli ipi inayofanywa na baba nyumbani?,
      options: [Kutengeneza, Kucheza, "Kulala, Kusoma"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kutengeneza
    })
  },
  {
    id: G3-SWA-SHU-03",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Shughuli,
    subtopic: "Shughuli za Nyumbani",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na mtoto nyumbani?,
      options: [Kucheza, Kupika, Kutengeneza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kucheza"
    })
  },
  {
    id: "G3-SWA-SHU-04",
    grade: "Grade 3",
    subject: "Kiswahili",
    topic: "Shughuli",
    subtopic: "Shughuli za Shule,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni shughuli ipi inayofanywa shuleni na mwalimu?,
      options: [Kufundisha, Kulala, "Kucheza, Kutengeneza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kufundisha
    })
  },
  {
    id: G3-SWA-SHU-05",
    grade: "Grade 3,
    subject: Kiswahili",
    topic: "Shughuli,
    subtopic: "Shughuli za Shule",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni shughuli ipi inayofanywa na wanafunzi shuleni?,
      options: [Kusoma, Kupika, Kutengeneza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kusoma"
    })
  },

  // =========================================================================
  // DARASA LA 4: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G4-SWA-NOM-01",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mtu anayepanda mboga za maji?,
      options: [Mkulima, Mvuvi, "Mwalimu, Mshonaji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mkulima
    })
  },
  {
    id: G4-SWA-NOM-02",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni neno lipi linalotaja mtu anayeandika habari za gazeti?,
      options: [Mwandishi, Mwalimu, Mkulima", "Mshonaji].sort(() => Math.random() - 0.5),
      correctAnswer: Mwandishi"
    })
  },
  {
    id: "G4-SWA-NOM-03",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Wanyama,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni mnyama gani anayeishi mwituni na ana pembe?,
      options: [Tembo, Simba, "Chui, Twiga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tembo
    })
  },
  {
    id: G4-SWA-NOM-04",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Mahali",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni neno lipi linalotaja mahali pa kusomea vitabu?,
      options: [Maktaba, Jikoni, Sebuleni", "Choo].sort(() => Math.random() - 0.5),
      correctAnswer: Maktaba"
    })
  },
  {
    id: "G4-SWA-NOM-05",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Vitu,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja chombo cha usafiri wa angani?,
      options: [Ndege, Gari, "Treni, Basi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ndege
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G4-SWA-VIT-01",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kukusanya mavuno?,
      options: [Kuvuna, Kupanda, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kuvuna"
    })
  },
  {
    id: "G4-SWA-VIT-02",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kuosha vyombo?,
      options: [Kunawa, Kupika, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kunawa
    })
  },
  {
    id: G4-SWA-VIT-03",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kutengeneza samaki?,
      options: [Kupika, Kusoma, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kupika"
    })
  },
  {
    id: "G4-SWA-VIT-04",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kusafisha nguo?,
      options: [Kuosha, Kupika, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuosha
    })
  },
  {
    id: G4-SWA-VIT-05",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kuandika habari?,
      options: [Kuandika, Kusoma, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kuandika"
    })
  },

  // --- MADA: VIUNGO (5 Materials) ---
  {
    id: "G4-SWA-VIU-01",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kwa kunusa maua?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },
  {
    id: G4-SWA-VIU-02",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Viungo,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuona picha?,
      options: [Macho, Mikono, Mguu", "Pua].sort(() => Math.random() - 0.5),
      correctAnswer: Macho"
    })
  },
  {
    id: "G4-SWA-VIU-03",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuongea?,
      options: [Mdomo, Jicho, "Pua, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mdomo
    })
  },
  {
    id: G4-SWA-VIU-04",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Viungo,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kusikia muziki?,
      options: [Masikio, Mdomo, Pua", "Kidevu].sort(() => Math.random() - 0.5),
      correctAnswer: Masikio"
    })
  },
  {
    id: "G4-SWA-VIU-05",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Viungo",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kutembea?,
      options: [Mguu, Mkono, "Kichwa, Tumbo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mguu
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G4-SWA-WIN-01",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'taifa' linapokuwa wingi, unasemaje?,
      options: [Mataifa, Taifa, Mataifa", "Taifa].sort(() => Math.random() - 0.5),
      correctAnswer: Mataifa"
    })
  },
  {
    id: "G4-SWA-WIN-02",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'tunda' linapokuwa wingi, unasemaje?,
      options: [Matunda, Tunda", "Matunda, Tunda"].sort(() => Math.random() - 0.5),
      correctAnswer: "Matunda
    })
  },
  {
    id: G4-SWA-WIN-03",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'kitu' linapokuwa wingi, unasemaje?,
      options: [Vitu, Kitu, Vitu", "Kitu].sort(() => Math.random() - 0.5),
      correctAnswer: Vitu"
    })
  },
  {
    id: "G4-SWA-WIN-04",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'nyumba' linapokuwa wingi, unasemaje?,
      options: [Nyumba, Nyumba", "Nyumba, Nyumba"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nyumba
    })
  },
  {
    id: G4-SWA-WIN-05",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'jambo' linapokuwa wingi, unasemaje?,
      options: [Mambo, Jambo, Mambo", "Jambo].sort(() => Math.random() - 0.5),
      correctAnswer: Mambo"
    })
  },

  // --- MADA: USOMAJI (5 Materials) ---
  {
    id: "G4-SWA-USE-01",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 45,",
    generate: () => ({
      text: "Soma: 'Mke wa mkulima alipanda mboga. Alipanda sukuma wiki, michicha, na biringanya. Mazao yalikuwa mengi.' Mke wa mkulima alipanda nini?,
      options: ["Sukuma wiki, michicha, na biringanya, Mahindi na mchele", "Matunda na mboga, Viazi na magimbi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sukuma wiki, michicha, na biringanya
    })
  },
  {
    id: G4-SWA-USE-02",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Msafiri alitembea kwa muda mrefu. Alichoka sana. Aliamua kupumzika chini ya mti. Baadaye, aliendelea na safari yake.' Msafiri alifanya nini baada ya kuchoka?,
      options: [Alipumzika chini ya mti, Alikwenda kulala, Alikwenda sokoni", "Alirudi nyumbani].sort(() => Math.random() - 0.5),
      correctAnswer: Alipumzika chini ya mti"
    })
  },
  {
    id: "G4-SWA-USE-03",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Soma: 'Wanafunzi waliandaa shughuli ya kusherehekea siku ya uhuru. Waliimba nyimbo za taifa. Waliandika insha.' Wanafunzi walifanya nini?,
      options: [Waliimba na kuandika insha, Walicheza na kulala, "Walikula na kunywa, Walitembea na kuimba"].sort(() => Math.random() - 0.5),
      correctAnswer: "Waliimba na kuandika insha
    })
  },
  {
    id: G4-SWA-USE-04",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Mlima Kilimanjaro ni mlima mrefu sana. Uko nchini Tanzania. Ni mlima unaopendwa na wapandaji kutoka duniani kote.' Mlima Kilimanjaro uko wapi?,
      options: [Tanzania, Kenya, Uganda", "Rwanda].sort(() => Math.random() - 0.5),
      correctAnswer: Tanzania"
    })
  },
  {
    id: "G4-SWA-USE-05",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Soma: 'Kila mtu ana ndoto. Watu wengine wanatamani kuwa walimu. Wengine wanatamani kuwa madaktari. Ndoto ni muhimu.' Ni nini kilichosemwa kuhusu ndoto?,
      options: [Kila mtu ana ndoto, Watu hawana ndoto, "Ndoto ni za watu wachache, Ndoto si muhimu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kila mtu ana ndoto
    })
  },

  // --- MADA: MAISHA (5 Materials) ---
  {
    id: G4-SWA-MAI-01",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Maisha,
    subtopic: "Mazoea ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Wakati wa chakula, ni jambo gani muhimu kufanya?,
      options: [Kula kwa taratibu, Kukimbia, Kulala", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kula kwa taratibu"
    })
  },
  {
    id: "G4-SWA-MAI-02",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Maisha",
    subtopic: "Mazoea ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Kabla ya kulala, ni jambo gani la mwisho unalofanya?,
      options: [Kusali na kunawa, Kula chakula", "Kusoma kitabu, Kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kusali na kunawa
    })
  },
  {
    id: G4-SWA-MAI-03",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Maisha,
    subtopic: "Mazoea ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Wakati wa sikukuu, ni jambo gani watu wanapenda kufanya?,
      options: [Kuimba na kucheza, Kulala, Kusoma", "Kupanda miti].sort(() => Math.random() - 0.5),
      correctAnswer: Kuimba na kucheza"
    })
  },
  {
    id: "G4-SWA-MAI-04",
    grade: "Grade 4",
    subject: "Kiswahili",
    topic: "Maisha",
    subtopic: "Mazoea ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni jambo gani muhimu kufanya baada ya kutumia choo?,
      options: [Kunawa mikono, Kula chakula, "Kusoma, Kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kunawa mikono
    })
  },
  {
    id: G4-SWA-MAI-05",
    grade: "Grade 4,
    subject: Kiswahili",
    topic: "Maisha,
    subtopic: "Mazoea ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni jambo gani muhimu kufanya kabla ya kula chakula?,
      options: [Kunawa mikono, Kukimbia, Kulala", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kunawa mikono"
    })
  }
  // =========================================================================
  // DARASA LA 5: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G5-SWA-NOM-01",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mtu anayefanya kazi ya kutengeneza nguo?,
      options: [Mshonaji, Mwalimu, "Daktari, Mkulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mshonaji
    })
  },
  {
    id: G5-SWA-NOM-02",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Wanyama",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni mnyama gani anayejulikana kwa kuwa na shingo ndefu sana?,
      options: [Twiga, Tembo, Simba", "Chui].sort(() => Math.random() - 0.5),
      correctAnswer: Twiga"
    })
  },
  {
    id: "G5-SWA-NOM-03",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Mahali,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mahali pa kuhifadhi vitabu vya shule?,
      options: [Maktaba, Jikoni, "Sebuleni, Choo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maktaba
    })
  },
  {
    id: G5-SWA-NOM-04",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Vitu",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni neno lipi linalotaja chombo cha usafiri kinachotumia reli?,
      options: [Treni, Gari, Ndege", "Basi].sort(() => Math.random() - 0.5),
      correctAnswer: Treni"
    })
  },
  {
    id: "G5-SWA-NOM-05",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Hali,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja hali ya kuwa na nguvu?,
      options: [Nguvu, Uzuri, "Wema, Raha"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nguvu
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G5-SWA-VIT-01",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kuandika insha ndefu?,
      options: [Kuandika, Kusoma, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kuandika"
    })
  },
  {
    id: "G5-SWA-VIT-02",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kupanda miti kwa ajili ya mazingira?,
      options: [Kupanda, Kukata, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kupanda
    })
  },
  {
    id: G5-SWA-VIT-03",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusafisha mazingira?,
      options: [Kusafisha, Kupika, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kusafisha"
    })
  },
  {
    id: "G5-SWA-VIT-04",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kuandaa chakula kwa ajili ya sherehe?,
      options: [Kupika, Kusoma, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kupika
    })
  },
  {
    id: G5-SWA-VIT-05",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusoma hadithi ya kitabu?,
      options: [Kusoma, Kuandika, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kusoma"
    })
  },

  // --- MADA: VIUNGO VYA MWILI (5 Materials) ---
  {
    id: "G5-SWA-VIU-01",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kusikia muziki?,
      options: [Masikio, Mdomo, "Pua, Jicho"].sort(() => Math.random() - 0.5),
      correctAnswer: "Masikio
    })
  },
  {
    id: G5-SWA-VIU-02",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuona vizuri?,
      options: [Macho, Mikono, Mguu", "Pua].sort(() => Math.random() - 0.5),
      correctAnswer: Macho"
    })
  },
  {
    id: "G5-SWA-VIU-03",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuongea kwa sauti?,
      options: [Mdomo, Jicho, "Pua, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mdomo
    })
  },
  {
    id: G5-SWA-VIU-04",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kutembea kwa miguu?,
      options: [Miguu, Mikono, Kichwa", "Tumbo].sort(() => Math.random() - 0.5),
      correctAnswer: Miguu"
    })
  },
  {
    id: "G5-SWA-VIU-05",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kunusa harufu ya vyakula?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G5-SWA-WIN-01",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'kiazi' linapokuwa wingi, unasemaje?,
      options: [Viazi, Kiazi, Viazi", "Kiazi].sort(() => Math.random() - 0.5),
      correctAnswer: Viazi"
    })
  },
  {
    id: "G5-SWA-WIN-02",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'kikapu' linapokuwa wingi, unasemaje?,
      options: [Vikapu, Kikapu", "Vikapu, Kikapu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Vikapu
    })
  },
  {
    id: G5-SWA-WIN-03",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'kisima' linapokuwa wingi, unasemaje?,
      options: [Visima, Kisima, Visima", "Kisima].sort(() => Math.random() - 0.5),
      correctAnswer: Visima"
    })
  },
  {
    id: "G5-SWA-WIN-04",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'dawa' linapokuwa wingi, unasemaje?,
      options: [Dawa, Dawa", "Dawa, Dawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Dawa
    })
  },
  {
    id: G5-SWA-WIN-05",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'sukari' linapokuwa wingi, unasemaje?,
      options: [Sukari, Sukari, Sukari", "Sukari].sort(() => Math.random() - 0.5),
      correctAnswer: Sukari"
    })
  },

  // --- MADA: USOMAJI (5 Materials) ---
  {
    id: "G5-SWA-USE-01",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 45,",
    generate: () => ({
      text: "Soma: 'Aliyeandika insha nzuri sana alipewa zawadi na mwalimu. Insha hiyo iliongelea mazingira.' Nani alipewa zawadi?,
      options: [Aliyeandika insha nzuri, Mwalimu, "Rafiki wa mwalimu, Mkuu wa shule"].sort(() => Math.random() - 0.5),
      correctAnswer: "Aliyeandika insha nzuri
    })
  },
  {
    id: G5-SWA-USE-02",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Watu wengi wanapenda kutembelea Mlima Kenya. Mlima huu ni mrefu na una barafu. Wapandaji huvaa nguo nzito.' Wapandaji huvaa nguo gani?,
      options: [Nguo nzito, Nguo nyepesi, Nguo za maji", "Nguo za mchezo].sort(() => Math.random() - 0.5),
      correctAnswer: Nguo nzito"
    })
  },
  {
    id: "G5-SWA-USE-03",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Soma: 'Mama alinunua kuku na samaki sokoni. Baada ya kupika, aliwapa watoto wake. Watoto walikula kwa furaha.' Mama alinunua nini sokoni?,
      options: [Kuku na samaki, Ugali na nyama", "Matunda na mboga, Sukari na chai"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuku na samaki
    })
  },
  {
    id: G5-SWA-USE-04",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Mwanafunzi aliyechelewa shule aliomba msamaha kwa mwalimu. Mwalimu alimwomba afanye kazi ya ziada.' Mwanafunzi alifanya nini baada ya kuchelewa?,
      options: [Aliomba msamaha, Alikimbia, Alilala", "Alikwenda nyumbani].sort(() => Math.random() - 0.5),
      correctAnswer: Aliomba msamaha"
    })
  },
  {
    id: "G5-SWA-USE-05",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Soma: 'Wanafunzi waliandaa shughuli ya kusherehekea uhuru. Waliimba, wakacheza na kuandika insha.' Wanafunzi walifanya nini?,
      options: [Kuimba, kucheza na kuandika insha, Kulala na kusoma", "Kukimbia na kuimba, Kupanda miti na kulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuimba, kucheza na kuandika insha
    })
  },

  // --- MADA: SHUGHULI ZA NYUMBANI (5 Materials) ---
  {
    id: G5-SWA-SHU-01",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Mama",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Mama anapofanya kazi ya kupika, anatumia nini?,
      options: [Sufuria, Kalamu, Kibao", "Ufagio].sort(() => Math.random() - 0.5),
      correctAnswer: Sufuria"
    })
  },
  {
    id: "G5-SWA-SHU-02",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Shughuli za Nyumbani",
    subtopic: "Kazi za Baba,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Baba anapofanya kazi ya kutengeneza samaki, anatumia nini?,
      options: [Kisu, Sufuria", "Kalamu, Ufagio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kisu
    })
  },
  {
    id: G5-SWA-SHU-03",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Watoto",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Watoto wanaweza kusaidia wazazi wao kwa kufanya nini nyumbani?,
      options: [Kufagia, Kulala, Kucheza", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kufagia"
    })
  },
  {
    id: "G5-SWA-SHU-04",
    grade: "Grade 5",
    subject: "Kiswahili",
    topic: "Shughuli za Nyumbani",
    subtopic: "Shughuli za Pamoja,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni shughuli ipi inayoweza kufanywa na familia nzima?,
      options: [Kupanda miti, Kulala, "Kusoma, Kucheza mpira"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kupanda miti
    })
  },
  {
    id: G5-SWA-SHU-05",
    grade: "Grade 5,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Jikoni",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jikoni, ni chombo gani kinachotumika kwa kupika supu?,
      options: [Sufuria, Kibao, Kalamu", "Ufagio].sort(() => Math.random() - 0.5),
      correctAnswer: Sufuria"
    })
  },

  // =========================================================================
  // DARASA LA 6: 35 MATERIALS (MTAA WA KICD)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (5 Materials) ---
  {
    id: "G6-SWA-NOM-01",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mtu anayesaidia wagonjwa katika hospitali?,
      options: [Muuguzi, Daktari, "Mwalimu, Mkulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Muuguzi
    })
  },
  {
    id: G6-SWA-NOM-02",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Wanyama",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni mnyama gani anayejulikana kwa kuwa na milia nyeusi na nyeupe?,
      options: [Zebra, Simba, Chui", "Tembo].sort(() => Math.random() - 0.5),
      correctAnswer: Zebra"
    })
  },
  {
    id: "G6-SWA-NOM-03",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Mahali,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mahali pa kuhifadhi magari?,
      options: [Gereji, Jikoni, "Sebuleni, Choo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Gereji
    })
  },
  {
    id: G6-SWA-NOM-04",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Vitu",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Ni neno lipi linalotaja chombo cha usafiri cha majini?,
      options: [Mashua, Gari, Ndege", "Treni].sort(() => Math.random() - 0.5),
      correctAnswer: Mashua"
    })
  },
  {
    id: "G6-SWA-NOM-05",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Hali,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni neno lipi linalotaja hali ya kuwa na utulivu?,
      options: [Amani, Nguvu, "Uzuri, Wema"].sort(() => Math.random() - 0.5),
      correctAnswer: "Amani
    })
  },

  // --- MADA: VITENDO (5 Materials) ---
  {
    id: G6-SWA-VIT-01",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kukata nyasi?,
      options: [Kukata, Kupanda, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kukata"
    })
  },
  {
    id: "G6-SWA-VIT-02",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kuosha magari?,
      options: [Kuosha, Kupanda, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuosha
    })
  },
  {
    id: G6-SWA-VIT-03",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kusoma hadithi kwa makini?,
      options: [Kusoma, Kuandika, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kusoma"
    })
  },
  {
    id: "G6-SWA-VIT-04",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Vitendo",
    subtopic: "Matendo ya Kila Siku,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno lipi linaelezea kitendo cha kutengeneza samaki?,
      options: [Kupika, Kusoma, "Kucheza, Kulala"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kupika
    })
  },
  {
    id: G6-SWA-VIT-05",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Vitendo,
    subtopic: "Matendo ya Kila Siku",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno lipi linaelezea kitendo cha kupanda mlima kwa ajili ya matembezi?,
      options: [Kupanda, Kukata, Kucheza", "Kulala].sort(() => Math.random() - 0.5),
      correctAnswer: Kupanda"
    })
  },

  // --- MADA: VIUNGO VYA MWILI (5 Materials) ---
  {
    id: "G6-SWA-VIU-01",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kusikia sauti za mazingira?,
      options: [Masikio, Mdomo, "Pua, Jicho"].sort(() => Math.random() - 0.5),
      correctAnswer: "Masikio
    })
  },
  {
    id: G6-SWA-VIU-02",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kuona mandhari nzuri?,
      options: [Macho, Mikono, Mguu", "Pua].sort(() => Math.random() - 0.5),
      correctAnswer: Macho"
    })
  },
  {
    id: "G6-SWA-VIU-03",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kuongea kwa sauti?,
      options: [Mdomo, Jicho, "Pua, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mdomo
    })
  },
  {
    id: G6-SWA-VIU-04",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Viungo vya Mwili,
    subtopic: "Sehemu za Mwili",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Sehemu ipi ya mwili inatumiwa kutembea kwa miguu?,
      options: [Miguu, Mikono, Kichwa", "Tumbo].sort(() => Math.random() - 0.5),
      correctAnswer: Miguu"
    })
  },
  {
    id: "G6-SWA-VIU-05",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Viungo vya Mwili",
    subtopic: "Sehemu za Mwili,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Sehemu ipi ya mwili inatumiwa kunusa harufu ya chakula?,
      options: [Pua, Mdomo, "Jicho, Sikio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Pua
    })
  },

  // --- MADA: WINGI NA UMOJA (5 Materials) ---
  {
    id: G6-SWA-WIN-01",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'kibao' linapokuwa wingi, unasemaje?,
      options: [Mabao, Kibao, Mabao", "Kibao].sort(() => Math.random() - 0.5),
      correctAnswer: Mabao"
    })
  },
  {
    id: "G6-SWA-WIN-02",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'msimu' linapokuwa wingi, unasemaje?,
      options: [Misimu, Msimu", "Misimu, Msimu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Misimu
    })
  },
  {
    id: G6-SWA-WIN-03",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'shamba' linapokuwa wingi, unasemaje?,
      options: [Mashamba, Shamba, Mashamba", "Shamba].sort(() => Math.random() - 0.5),
      correctAnswer: Mashamba"
    })
  },
  {
    id: "G6-SWA-WIN-04",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Wingi na Umoja",
    subtopic: "Kuunda Wingi,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Neno 'kiongozi' linapokuwa wingi, unasemaje?,
      options: [Viongozi, Kiongozi", "Viongozi, Kiongozi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Viongozi
    })
  },
  {
    id: G6-SWA-WIN-05",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Wingi na Umoja,
    subtopic: "Kuunda Wingi",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Neno 'ukuta' linapokuwa wingi, unasemaje?,
      options: [Kuta, Ukuta, Kuta", "Ukuta].sort(() => Math.random() - 0.5),
      correctAnswer: Kuta"
    })
  },

  // --- MADA: USOMAJI (5 Materials) ---
  {
    id: "G6-SWA-USE-01",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Soma: 'Wanafunzi walienda mtaani kusafisha mazingira. Walikusanya takataka. Walipanda miti. Mazingira yakawa mazuri.' Wanafunzi walifanya nini mtaani?,
      options: [Kusafisha mazingira, Kulala, "Kusoma, Kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kusafisha mazingira
    })
  },
  {
    id: G6-SWA-USE-02",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Soma: 'Mama alipika chakula cha jioni. Alitengeneza ugali na sukuma wiki. Familia yake ilikula kwa furaha.' Familia ya mama ilikula nini?,
      options: [Ugali na sukuma wiki, Ugali na nyama, Wali na samaki", "Chapati na mboga].sort(() => Math.random() - 0.5),
      correctAnswer: Ugali na sukuma wiki"
    })
  },
  {
    id: "G6-SWA-USE-03",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Soma: 'Mlima Kilimanjaro ni mlima mrefu sana. Uko Tanzania. Wapandaji wanapanda mlima huu kwa shauku.' Mlima Kilimanjaro uko wapi?,
      options: [Tanzania, Kenya, "Uganda, Rwanda"].sort(() => Math.random() - 0.5),
      correctAnswer: "Tanzania
    })
  },
  {
    id: G6-SWA-USE-04",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Soma: 'Mwanafunzi aliyekuwa na bidii alipata alama za juu. Alisoma kwa kujituma. Mwalimu alimwongeza.' Nani alipata alama za juu?,
      options: [Mwanafunzi aliyekuwa na bidii, Mwanafunzi mvivu, Mwalimu", "Mkuu wa shule].sort(() => Math.random() - 0.5),
      correctAnswer: Mwanafunzi aliyekuwa na bidii"
    })
  },
  {
    id: "G6-SWA-USE-05",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mshairi aliandika shairi kuhusu uzuri wa mazingira. Shairi hilo liliwafanya watu wapende kuhifadhi mazingira.' Shairi hilo liliwafanya watu wapende kufanya nini?,
      options: [Kuhifadhi mazingira, Kukata miti, "Kutupa takataka, Kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuhifadhi mazingira
    })
  },

  // --- MADA: SHUGHULI ZA NYUMBANI (5 Materials) ---
  {
    id: G6-SWA-SHU-01",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Mama",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Mama anapofanya kazi ya kupika, anachukua chombo gani kwanza?,
      options: [Sufuria, Kalamu, Kibao", "Ufagio].sort(() => Math.random() - 0.5),
      correctAnswer: Sufuria"
    })
  },
  {
    id: "G6-SWA-SHU-02",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Shughuli za Nyumbani",
    subtopic: "Kazi za Baba,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Baba anapofanya kazi ya kutengeneza samaki, anachukua chombo gani?,
      options: [Kisu, Sufuria", "Kalamu, Ufagio"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kisu
    })
  },
  {
    id: G6-SWA-SHU-03",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Watoto",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Watoto wanaweza kusaidia wazazi kwa kufanya nini?,
      options: [Kufagia, Kulala, Kucheza", "Kusoma].sort(() => Math.random() - 0.5),
      correctAnswer: Kufagia"
    })
  },
  {
    id: "G6-SWA-SHU-04",
    grade: "Grade 6",
    subject: "Kiswahili",
    topic: "Shughuli za Nyumbani",
    subtopic: "Shughuli za Pamoja,
    maxUses: 5,
    usageCount: 0,
    minWords: 18,",
    generate: () => ({
      text: "Ni shughuli ipi inayoweza kufanywa na familia nzima?,
      options: [Kupanda miti, Kulala, "Kusoma, Kucheza mpira"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kupanda miti
    })
  },
  {
    id: G6-SWA-SHU-05",
    grade: "Grade 6,
    subject: Kiswahili",
    topic: "Shughuli za Nyumbani,
    subtopic: "Kazi za Jikoni",
    maxUses: 5,
    usageCount: 0,
    minWords: 18,
    generate: () => ({
      text: " Jikoni, ni chombo gani kinachotumika kwa kupika?,
      options: [Sufuria, Kibao, Kalamu", "Ufagio].sort(() => Math.random() - 0.5),
      correctAnswer: Sufuria"
    })
  }
  // =========================================================================
  // DARASA LA 7: 35 MATERIALS (KICD JUNIOR SECONDARY)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (Aina za Nomino) (5 Materials) ---
  {
    id: "G7-SWA-NOM-01",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Watu,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni neno lipi kati ya haya linalotaja mtu anayefanya kazi ya kuendesha ndege?,
      options: [Rubani, Mwalimu, "Daktari, Mkulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Rubani
    })
  },
  {
    id: G7-SWA-NOM-02",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Mahali",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni neno lipi linalotaja mahali pa kuogelea?,
      options: [Bwawa, Jikoni, Sebuleni", "Choo].sort(() => Math.random() - 0.5),
      correctAnswer: Bwawa"
    })
  },
  {
    id: "G7-SWA-NOM-03",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Vitu,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni neno lipi linalotaja chombo kinachotumiwa kwa kupima joto la mwili?,
      options: [Kipimajoto, Kipimashimo, "Kipimawaya, Kipimakaa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kipimajoto
    })
  },
  {
    id: G7-SWA-NOM-04",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Hali",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni neno lipi linalotaja hali ya kuwa na imani na ujasiri?,
      options: [Ushujaa, Uzuri, Uvivu", "Woga].sort(() => Math.random() - 0.5),
      correctAnswer: Ushujaa"
    })
  },
  {
    id: "G7-SWA-NOM-05",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Makundi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Kundi la watu wanaoimba pamoja huitwa nini?,
      options: [Kwaya, Kamati, "Jeshi, Kundi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwaya
    })
  },

  // --- MADA: SARUFI - VITENDO (Nyakati) (5 Materials) ---
  {
    id: G7-SWA-VIT-01",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Wakati Uliopita",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Jana, mwalimu ____ darasani kwa saa moja.' (Tumia wakati uliopita wa 'kukaa'),
      options: [alikaa, atakaa, anakaa", "kaa].sort(() => Math.random() - 0.5),
      correctAnswer: alikaa"
    })
  },
  {
    id: "G7-SWA-VIT-02",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Wakati Uliopo,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Sasa hivi, watoto ____ sokoni.' (Tumia wakati uliopo wa 'kuenda'),
      options: [wanaenda, walienda", "wataenda, waenda"].sort(() => Math.random() - 0.5),
      correctAnswer: "wanaenda
    })
  },
  {
    id: G7-SWA-VIT-03",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Wakati Ujao",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Kesho, sisi ____ shule mapema.' (Tumia wakati ujao wa 'kuenda'),
      options: [tutaenda, tulienda, tunaenda", "tuenda].sort(() => Math.random() - 0.5),
      correctAnswer: tutaenda"
    })
  },
  {
    id: "G7-SWA-VIT-04",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Wakati Uliopita,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia wakati uliopita: 'Mwezi uliopita, wazazi ____ mkutano.' (Tumia wakati uliopita wa 'kuhudhuria'),
      options: [walihudhuria, wanahudhuria", "watahudhuria, huhudhuria"].sort(() => Math.random() - 0.5),
      correctAnswer: "walihudhuria
    })
  },
  {
    id: G7-SWA-VIT-05",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Wakati Uliopo",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia wakati uliopo: 'Sasa, sisi ____ somo la Kiswahili.' (Tumia wakati uliopo wa 'kujifunza'),
      options: [tunajifunza, tulijifunza, tutajifunza", "jifunza].sort(() => Math.random() - 0.5),
      correctAnswer: tunajifunza"
    })
  },

  // --- MADA: SARUFI - VIWAKILISHI (5 Materials) ---
  {
    id: "G7-SWA-VIW-01",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Nafsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ndiye mtoto wangu.' (Tumia kiwakilishi cha nafsi ya kwanza umoja),
      options: [Mimi, Wewe, "Yeye, Sisi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mimi
    })
  },
  {
    id: G7-SWA-VIW-02",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Nafsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ndio wanafunzi wa darasa hili.' (Tumia kiwakilishi cha nafsi ya pili wingi),
      options: [Nyinyi, Sisi, Wao", "Mimi].sort(() => Math.random() - 0.5),
      correctAnswer: Nyinyi"
    })
  },
  {
    id: "G7-SWA-VIW-03",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Kuonyesha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ vitabu nilivyonunua jana.' (Tumia kiwakilishi cha kuonyesha cha karibu),
      options: [Hivi, Vile, "Hii, Huo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hivi
    })
  },
  {
    id: G7-SWA-VIW-04",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Kuuliza",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia kiwakilishi sahihi: '____ mtu aliyepiga mlango?',
      options: [Nani, Kipi, Wapi", "Lini].sort(() => Math.random() - 0.5),
      correctAnswer: Nani"
    })
  },
  {
    id: "G7-SWA-VIW-05",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Umiliki,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Hii ni ____ fedha.' (Tumia kiwakilishi cha umiliki cha nafsi ya tatu umoja),
      options: [yake, yangu, "yako, yetu"].sort(() => Math.random() - 0.5),
      correctAnswer: "yake
    })
  },

  // --- MADA: SARUFI - VIVUMISHI (5 Materials) ---
  {
    id: G7-SWA-VIV-01",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Sifa",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni vivumishi vipi katika sentensi: 'Mwanafunzi mwerevu alipata alama nzuri.'?,
      options: [Mwerevu, nzuri, Mwanafunzi, alama, Alipata, mwerevu", "Mwerevu, alama].sort(() => Math.random() - 0.5),
      correctAnswer: Mwerevu, nzuri"
    })
  },
  {
    id: "G7-SWA-VIV-02",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Idadi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia vivumishi vya idadi: '____ wanafunzi walikuja.' (Maana: wachache),
      options: [Wachache, Wengi, "Wote, Kila"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wachache
    })
  },
  {
    id: G7-SWA-VIV-03",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Kuuliza",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ kitabu ni chako?' (Tumia vivumishi vya kuuliza),
      options: [Kipi, Nani, Wapi", "Lini].sort(() => Math.random() - 0.5),
      correctAnswer: Kipi"
    })
  },
  {
    id: "G7-SWA-VIV-04",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Umiliki,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia vivumishi vya umiliki: 'Hii ni ____ kazi.' (Maana: kazi yangu),
      options: [yangu, yake, "yako, yetu"].sort(() => Math.random() - 0.5),
      correctAnswer: "yangu
    })
  },
  {
    id: G7-SWA-VIV-05",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Jinsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni vivumishi vipi katika sentensi: 'Wanafunzi wazuri wanasoma kwa bidii.'?,
      options: [Wazuri, bidii, Wanafunzi, wazuri, Wanasoma, bidii", "Wazuri, wanasoma].sort(() => Math.random() - 0.5),
      correctAnswer: Wazuri, bidii"
    })
  },

  // --- MADA: MATUMIZI YA LUCHA (Methali, Vitendawili) (5 Materials) ---
  {
    id: "G7-SWA-MET-01",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Methali ipi inafaa kwa mtu anayesema kwamba hana shida na matatizo?,
      options: [Mwenye njaa hajali wali wa mwenzake., Haraka haraka haina baraka., "Mkono wa mwenzako usiupande., Acha mwenye mkuki ampige."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mwenye njaa hajali wali wa mwenzake.
    })
  },
  {
    id: G7-SWA-MET-02",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., Mwenye njaa hajali wali wa mwenzake.", "Acha mwenye mkuki ampige.].sort(() => Math.random() - 0.5),
      correctAnswer: Mkono wa mwenzako usiupande."
    })
  },
  {
    id: "G7-SWA-MET-03",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Mti, Kalamu", "Ufagio, Kibao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mti
    })
  },
  {
    id: G7-SWA-MET-04",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Kalamu, Mti, Ufagio", "Kibao].sort(() => Math.random() - 0.5),
      correctAnswer: Kalamu"
    })
  },
  {
    id: "G7-SWA-MET-05",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na hasira kali'?,
      options: [Kuwa na joto, Kuwa na baridi, "Kuwa na mvua, Kuwa na theluji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na joto
    })
  },

  // --- MADA: USOMAJI (Kuelewa na Kubainisha) (5 Materials) ---
  {
    id: G7-SWA-USE-01",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Soma: 'Baba alinunua gari jipya. Gari hili lina nguvu nyingi. Inaweza kusafiri umbali mrefu bila kujaa mafuta.' Gari jipya lina nguvu gani?,
      options: [Inaweza kusafiri umbali mrefu, Inaweza kuruka, Inaweza kuogelea", "Inaweza kupanda miti].sort(() => Math.random() - 0.5),
      correctAnswer: Inaweza kusafiri umbali mrefu"
    })
  },
  {
    id: "G7-SWA-USE-02",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Wakati wa ukame, maji ni adimu sana. Watu wana lazima wahifadhi maji. Wanatumia maji kwa akili.' Ni nini kinachofanyika wakati wa ukame?,
      options: [Maji ni adimu, Maji ni mengi", "Watu wanapanda miti, Watu wanakula sana"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maji ni adimu
    })
  },
  {
    id: G7-SWA-USE-03",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Mwalimu aliwaambia wanafunzi kwamba kusoma ni muhimu. Alisema kwamba wale wanaosoma kwa bidii watafanikiwa.' Nini alisema mwalimu?,
      options: [Wale wanaosoma kwa bidii watafanikiwa, Kusoma ni jambo baya, Kusoma ni jambo la kupoteza muda", "Kusoma ni jambo la kufurahisha tu].sort(() => Math.random() - 0.5),
      correctAnswer: Wale wanaosoma kwa bidii watafanikiwa"
    })
  },
  {
    id: "G7-SWA-USE-04",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kubainisha Maandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mji wa Nairobi ni mji mkuu wa Kenya. Umetambulika kwa uteuzi wake wa makampuni na wageni wengi.' Ni sifa gani za Nairobi?,
      options: [Ni mji mkuu na umejulikana kwa makampuni, Ni mji mdogo, "Ni mji wa wageni, Ni mji wa wakulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ni mji mkuu na umejulikana kwa makampuni
    })
  },
  {
    id: G7-SWA-USE-05",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma kwa Makini",
    maxUses: 5,
    usageCount: 0,
    minWords: 65,
    generate: () => ({
      text: " Soma: 'Mkongwe wa Kiswahili, alitamka kwamba lugha hii inatakiwa kuthaminiwa. Alipendekeza kwamba watoto wanatakiwa kuijifunza tangu wakiwa wadogo.' Nini alipendekeza mzungumzaji?,
      options: [Watoto wanatakiwa kujifunza Kiswahili tangu wakiwa wadogo, Kiswahili ni lugha ya kigeni, Kiswahili haijathaminiwa", "Watoto wanatakiwa kuijifunza Kiingereza tu].sort(() => Math.random() - 0.5),
      correctAnswer: Watoto wanatakiwa kujifunza Kiswahili tangu wakiwa wadogo"
    })
  },

  // --- MADA: UANDISHI (Insha, Barua, Taarifa) (5 Materials) ---
  {
    id: "G7-SWA-AND-01",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoandika insha, ni jambo lipi la kwanza kuzingatia?,
      options: [Utangulizi, Hitimisho", "Mada, Tahadhari"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mada
    })
  },
  {
    id: G7-SWA-AND-02",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Barua rasmi",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoandika barua rasmi, ni jambo lipi la kwanza kuandika?,
      options: [Anwani ya mpokeaji, Salamu, Mada", "Tarehe].sort(() => Math.random() - 0.5),
      correctAnswer: Anwani ya mpokeaji"
    })
  },
  {
    id: "G7-SWA-AND-03",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Barua rasmi,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Barua rasmi inaisha na nini?,
      options: [Sahihi, Tarehe, "Anwani, Salamu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sahihi
    })
  },
  {
    id: G7-SWA-AND-04",
    grade: "Grade 7,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Taarifa",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Taarifa inapaswa kuandikwa kwa lugha gani?,
      options: [Lugha rasmi, Lugha ya mitaani, Lugha ya kawaida", "Lugha ya kifasihi].sort(() => Math.random() - 0.5),
      correctAnswer: Lugha rasmi"
    })
  },
  {
    id: "G7-SWA-AND-05",
    grade: "Grade 7",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, "Tahadhari, mada, hitimisho, Mada, ufafanuzi, malengo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utangulizi, mwili, hitimisho
    })
  },

  // =========================================================================
  // DARASA LA 8: 35 MATERIALS (KICD JUNIOR SECONDARY)
  // =========================================================================

  // --- MADA: SARUFI - NOMINO (Aina za Nomino) (5 Materials) ---
  {
    id: G8-SWA-NOM-01",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Watu",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni neno lipi linalotaja mtu anayesimamia mahakama?,
      options: [Hakimu, Mwalimu, Daktari", "Mkulima].sort(() => Math.random() - 0.5),
      correctAnswer: Hakimu"
    })
  },
  {
    id: "G8-SWA-NOM-02",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Mahali,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni neno lipi linalotaja mahali pa kuogelea?,
      options: [Bwawa, Jikoni, "Sebuleni, Choo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Bwawa
    })
  },
  {
    id: G8-SWA-NOM-03",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Vitu",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni neno lipi linalotaja chombo kinachotumiwa kwa kupima uzito?,
      options: [Mizani, Kipimajoto, Kipimashimo", "Kipimawaya].sort(() => Math.random() - 0.5),
      correctAnswer: Mizani"
    })
  },
  {
    id: "G8-SWA-NOM-04",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Nomino za Hali,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni neno lipi linalotaja hali ya kuwa na upendo na urafiki?,
      options: [Upendo, Ushujaa, "Uvivu, Woga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Upendo
    })
  },
  {
    id: G8-SWA-NOM-05",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Nomino za Makundi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Kundi la wapanda ndege huitwa nini?,
      options: [Wrubani, Waalimu, Wakulima", "Wanafunzi].sort(() => Math.random() - 0.5),
      correctAnswer: Wrubani"
    })
  },

  // --- MADA: SARUFI - VITENDO (Nyakati) (5 Materials) ---
  {
    id: "G8-SWA-VIT-01",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Wakati Uliopita,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Juzi, mama ____ chakula kitamu.' (Tumia wakati uliopita wa 'kupika'),
      options: [alipika, atapika", "anapika, pika"].sort(() => Math.random() - 0.5),
      correctAnswer: "alipika
    })
  },
  {
    id: G8-SWA-VIT-02",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Wakati Uliopo",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Sasa, wageni ____ nyumbani.' (Tumia wakati uliopo wa 'kukaa'),
      options: [wanakaa, walikaa, watakaa", "kaa].sort(() => Math.random() - 0.5),
      correctAnswer: wanakaa"
    })
  },
  {
    id: "G8-SWA-VIT-03",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Wakati Ujao,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Kesho, sisi ____ maktaba.' (Tumia wakati ujao wa 'kuenda'),
      options: [tutaenda, tulienda", "tunaenda, tuenda"].sort(() => Math.random() - 0.5),
      correctAnswer: "tutaenda
    })
  },
  {
    id: G8-SWA-VIT-04",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Wakati Uliopita",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Mwezi uliopita, wafanyabiashara ____ mikutano.' (Tumia wakati uliopita wa 'kuhudhuria'),
      options: [walihudhuria, wanahudhuria, watahudhuria", "huhudhuria].sort(() => Math.random() - 0.5),
      correctAnswer: walihudhuria"
    })
  },
  {
    id: "G8-SWA-VIT-05",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Wakati Uliopo,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Sasa, ni watu wengi ____ mjini.' (Tumia wakati uliopo wa 'kuishi'),
      options: [wanaishi, waliishi", "wataishi, ishi"].sort(() => Math.random() - 0.5),
      correctAnswer: "wanaishi
    })
  },

  // --- MADA: SARUFI - VIWAKILISHI (5 Materials) ---
  {
    id: G8-SWA-VIW-01",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Nafsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ndio wageni wetu.' (Tumia kiwakilishi cha nafsi ya tatu wingi),
      options: [Wao, Sisi, Nyinyi", "Mimi].sort(() => Math.random() - 0.5),
      correctAnswer: Wao"
    })
  },
  {
    id: "G8-SWA-VIW-02",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Nafsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ndio mtoto wao.' (Tumia kiwakilishi cha nafsi ya tatu umoja),
      options: [Yeye, Mimi, "Wewe, Sisi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Yeye
    })
  },
  {
    id: G8-SWA-VIW-03",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Kuonyesha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ nguo nilizonunua jana.' (Tumia kiwakilishi cha kuonyesha cha karibu),
      options: [Hizi, Zile, Hii", "Huo].sort(() => Math.random() - 0.5),
      correctAnswer: Hizi"
    })
  },
  {
    id: "G8-SWA-VIW-04",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Kuuliza,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia kiwakilishi sahihi: '____ kitu kilichoanguka?',
      options: [Nini, Nani, "Wapi, Lini"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nini
    })
  },
  {
    id: G8-SWA-VIW-05",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Umiliki",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Hii ni ____ shule.' (Tumia kiwakilishi cha umiliki cha nafsi ya kwanza wingi),
      options: [yetu, yangu, yako", "yake].sort(() => Math.random() - 0.5),
      correctAnswer: yetu"
    })
  },

  // --- MADA: SARUFI - VIVUMISHI (5 Materials) ---
  {
    id: "G8-SWA-VIV-01",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Sifa,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni vivumishi vipi katika sentensi: 'Wanafunzi wazuri wanasoma kwa bidii.'?,
      options: [Wazuri, wanasoma, Wanafunzi, wazuri, "Wazuri, bidii, Wanasoma, bidii"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wazuri, wanasoma
    })
  },
  {
    id: G8-SWA-VIV-02",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Idadi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia vivumishi vya idadi: '____ watu walihudhuria sherehe.' (Maana: wengi),
      options: [Wengi, Wachache, Wote", "Kila].sort(() => Math.random() - 0.5),
      correctAnswer: Wengi"
    })
  },
  {
    id: "G8-SWA-VIV-03",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Kuuliza,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ watu walikuja?' (Tumia vivumishi vya kuuliza),
      options: [Wangapi, Wapi, "Lini, Nani"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wangapi
    })
  },
  {
    id: G8-SWA-VIV-04",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Umiliki",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia vivumishi vya umiliki: 'Hii ni ____ kazi.' (Maana: kazi yako),
      options: [yako, yangu, yake", "yetu].sort(() => Math.random() - 0.5),
      correctAnswer: yako"
    })
  },
  {
    id: "G8-SWA-VIV-05",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Jinsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni vivumishi vipi katika sentensi: 'Mwanafunzi mwenye bidii alipata alama nzuri.'?,
      options: [Mwenye bidii, nzuri, Mwanafunzi, alama, "Alipata, mwenye bidii, Mwenye bidii, alama"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mwenye bidii, nzuri
    })
  },

  // --- MADA: MATUMIZI YA LUCHA (Methali, Vitendawili) (5 Materials) ---
  {
    id: G8-SWA-MET-01",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Methali ipi inafaa kwa mtu anayesema kwamba hawezi kusaidia mtu mwingine?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., Mwenye njaa hajali wali wa mwenzake.", "Acha mwenye mkuki ampige.].sort(() => Math.random() - 0.5),
      correctAnswer: Mkono wa mwenzako usiupande."
    })
  },
  {
    id: "G8-SWA-MET-02",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., "Mwenye njaa hajali wali wa mwenzake., Acha mwenye mkuki ampige."].sort(() => Math.random() - 0.5),
      correctAnswer: "Haraka haraka haina baraka.
    })
  },
  {
    id: G8-SWA-MET-03",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Mti, Kalamu, Ufagio", "Kibao].sort(() => Math.random() - 0.5),
      correctAnswer: Mti"
    })
  },
  {
    id: "G8-SWA-MET-04",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Kalamu, Mti", "Ufagio, Kibao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kalamu
    })
  },
  {
    id: G8-SWA-MET-05",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na upendo mwingi'?,
      options: [Kuwa na joto, Kuwa na baridi, Kuwa na mvua", "Kuwa na theluji].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na joto"
    })
  },

  // --- MADA: USOMAJI (Kuelewa na Kubainisha) (5 Materials) ---
  {
    id: "G8-SWA-USE-01",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Soma: 'Mama alinunua chakula sokoni. Alinunua ugali, sukuma wiki, na samaki. Alipika chakula cha jioni kwa watoto wake.' Mama alinunua nini sokoni?,
      options: ["Ugali, sukuma wiki, na samaki, Ugali na nyama", "Wali na matunda, Chapati na mboga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ugali, sukuma wiki, na samaki
    })
  },
  {
    id: G8-SWA-USE-02",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma na Kuelewa",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Wakati wa msimu wa mvua, mazingira ni mazuri sana. Mimea inakua kwa haraka. Watu wanapenda kufanya shughuli nje.' Ni nini kinachofanyika wakati wa msimu wa mvua?,
      options: [Mimea inakua kwa haraka, Mazingira ni mabaya, Mimea inakauka", "Watu wanakaa ndani].sort(() => Math.random() - 0.5),
      correctAnswer: Mimea inakua kwa haraka"
    })
  },
  {
    id: "G8-SWA-USE-03",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma na Kuelewa,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mwalimu aliwaambia wanafunzi kwamba kusoma ni muhimu. Alisema kwamba wale wanaosoma kwa bidii watafanikiwa.' Nini alisema mwalimu?,
      options: [Wale wanaosoma kwa bidii watafanikiwa, Kusoma ni jambo baya, "Kusoma ni jambo la kupoteza muda, Kusoma ni jambo la kufurahisha tu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wale wanaosoma kwa bidii watafanikiwa
    })
  },
  {
    id: G8-SWA-USE-04",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kubainisha Maandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Mji wa Mombasa ni mji wa pwani. Umejulikana kwa bandari yake na historia ndefu ya uislamu.' Ni sifa gani za Mombasa?,
      options: [Ni mji wa pwani na umejulikana kwa bandari, Ni mji wa mlima, Ni mji wa wageni", "Ni mji wa wakulima].sort(() => Math.random() - 0.5),
      correctAnswer: Ni mji wa pwani na umejulikana kwa bandari"
    })
  },
  {
    id: "G8-SWA-USE-05",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma kwa Makini,
    maxUses: 5,
    usageCount: 0,
    minWords: 65,",
    generate: () => ({
      text: "Soma: 'Mwandishi wa habari alisema kwamba wanafunzi wanatakiwa kuwa na uwezo wa kutumia lugha ya Kiswahili katika maisha yao ya kila siku. Alisema kwamba hii itawasaidia katika siku za usoni.' Ni nini alisema mwandishi?,
      options: [Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku, Kiswahili ni lugha ya kigeni, "Kiswahili haijathaminiwa, Wanafunzi wanatakiwa kutumia Kiingereza tu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku
    })
  },

  // --- MADA: UANDISHI (Insha, Barua, Taarifa) (5 Materials) ---
  {
    id: G8-SWA-AND-01",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoandika insha, ni jambo lipi la mwisho kuandika?,
      options: [Hitimisho, Utangulizi, Mada", "Tahadhari].sort(() => Math.random() - 0.5),
      correctAnswer: Hitimisho"
    })
  },
  {
    id: "G8-SWA-AND-02",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Barua rasmi,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoandika barua rasmi, ni jambo lipi la mwisho kuandika?,
      options: [Sahihi, Anwani ya mpokeaji", "Salamu, Mada"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sahihi
    })
  },
  {
    id: G8-SWA-AND-03",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Barua rasmi",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Barua rasmi inaisha na nini?,
      options: [Sahihi, Tarehe, Anwani", "Salamu].sort(() => Math.random() - 0.5),
      correctAnswer: Sahihi"
    })
  },
  {
    id: "G8-SWA-AND-04",
    grade: "Grade 8",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Taarifa,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Taarifa inapaswa kuandikwa kwa lugha gani?,
      options: [Lugha rasmi, Lugha ya mitaani, "Lugha ya kawaida, Lugha ya kifasihi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Lugha rasmi
    })
  },
  {
    id: G8-SWA-AND-05",
    grade: "Grade 8,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, Tahadhari, mada, hitimisho", "Mada, ufafanuzi, malengo].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi, mwili, hitimisho"
    })
  }
  // =========================================================================
  // DARASA LA 9: 35 MATERIALS (KICD SENIOR SECONDARY - BEGINNING)
  // =========================================================================

  // --- MADA: SARUFI - VIAMBISHI (5 Materials) ---
  {
    id: "G9-SWA-VIA-01",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Muda,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Mimi ____enda sokoni.' (Tumia kiambishi cha wakati uliopo kwa nafsi ya kwanza umoja),
      options: [na, li, "ta, me"].sort(() => Math.random() - 0.5),
      correctAnswer: "na
    })
  },
  {
    id: G9-SWA-VIA-02",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Muda",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Sisi ____soma kitabu hiki.' (Tumia kiambishi cha wakati uliopita kwa nafsi ya kwanza wingi),
      options: [li, na, ta", "me].sort(() => Math.random() - 0.5),
      correctAnswer: li"
    })
  },
  {
    id: "G9-SWA-VIA-03",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Muda,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Wao ____tembea mtaani.' (Tumia kiambishi cha wakati ujao kwa nafsi ya tatu wingi),
      options: [ta, na, "li, me"].sort(() => Math.random() - 0.5),
      correctAnswer: "ta
    })
  },
  {
    id: G9-SWA-VIA-04",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Muda",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Yeye ____cheza mpira.' (Tumia kiambishi cha wakati uliopo kwa nafsi ya tatu umoja),
      options: [na, li, ta", "me].sort(() => Math.random() - 0.5),
      correctAnswer: na"
    })
  },
  {
    id: "G9-SWA-VIA-05",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Muda,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Nyinyi ____enda shule.' (Tumia kiambishi cha wakati uliopita kwa nafsi ya pili wingi),
      options: [li, na, "ta, me"].sort(() => Math.random() - 0.5),
      correctAnswer: "li
    })
  },

  // --- MADA: SARUFI - VIUNGO (5 Materials) ---
  {
    id: G9-SWA-VIU-01",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viungo vya Kuunganisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ushirikiano, tutafanikiwa.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo, Kwa kuwa", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G9-SWA-VIU-02",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viungo vya Kuunganisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ kulikuwa na mvua, tulikwenda mtaani.' (Tumia kiungo cha kuonyesha sababu),
      options: [Kwa sababu, Kwa hivyo", "Ingawa, Kwa kuwa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa sababu
    })
  },
  {
    id: G9-SWA-VIU-03",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viungo vya Kuunganisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ukweli, mambo ni magumu.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G9-SWA-VIU-04",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viungo vya Kuunganisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ watoto, shule ni muhimu.' (Tumia kiungo cha kuonyesha lengo),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G9-SWA-VIU-05",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viungo vya Kuunganisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ kazi hii, tunahitaji muda mwingi.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },

  // --- MADA: SARUFI - VIWAKILISHI (5 Materials) ---
  {
    id: "G9-SWA-VIW-01",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Nafsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ndio mwanafunzi wa darasa hili.' (Tumia kiwakilishi cha nafsi ya pili umoja),
      options: [Wewe, Mimi, "Yeye, Sisi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wewe
    })
  },
  {
    id: G9-SWA-VIW-02",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Nafsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ndio wapendwa wangu.' (Tumia kiwakilishi cha nafsi ya kwanza wingi),
      options: [Sisi, Mimi, Wewe", "Wao].sort(() => Math.random() - 0.5),
      correctAnswer: Sisi"
    })
  },
  {
    id: "G9-SWA-VIW-03",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Kuonyesha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ kitabu nilichokisoma jana.' (Tumia kiwakilishi cha kuonyesha cha karibu),
      options: [Hiki, Kile, "Hii, Huo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hiki
    })
  },
  {
    id: G9-SWA-VIW-04",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Kuuliza",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia kiwakilishi sahihi: '____ mtu aliyepiga mlango?',
      options: [Nani, Kipi, Wapi", "Lini].sort(() => Math.random() - 0.5),
      correctAnswer: Nani"
    })
  },
  {
    id: "G9-SWA-VIW-05",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Umiliki,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Hii ni ____ fedha.' (Tumia kiwakilishi cha umiliki cha nafsi ya tatu umoja),
      options: [yake, yangu, "yako, yetu"].sort(() => Math.random() - 0.5),
      correctAnswer: "yake
    })
  },

  // --- MADA: SARUFI - VIVUMISHI (5 Materials) ---
  {
    id: G9-SWA-VIV-01",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Sifa",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni vivumishi vipi katika sentensi: 'Mwanafunzi mwerevu alipata alama nzuri.'?,
      options: [Mwerevu, nzuri, Mwanafunzi, alama, Alipata, mwerevu", "Mwerevu, alama].sort(() => Math.random() - 0.5),
      correctAnswer: Mwerevu, nzuri"
    })
  },
  {
    id: "G9-SWA-VIV-02",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Idadi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia vivumishi vya idadi: '____ wanafunzi walikuja.' (Maana: wachache),
      options: [Wachache, Wengi, "Wote, Kila"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wachache
    })
  },
  {
    id: G9-SWA-VIV-03",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Kuuliza",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ kitabu ni chako?' (Tumia vivumishi vya kuuliza),
      options: [Kipi, Nani, Wapi", "Lini].sort(() => Math.random() - 0.5),
      correctAnswer: Kipi"
    })
  },
  {
    id: "G9-SWA-VIV-04",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Umiliki,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia vivumishi vya umiliki: 'Hii ni ____ kazi.' (Maana: kazi yangu),
      options: [yangu, yake, "yako, yetu"].sort(() => Math.random() - 0.5),
      correctAnswer: "yangu
    })
  },
  {
    id: G9-SWA-VIV-05",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Jinsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Ni vivumishi vipi katika sentensi: 'Wanafunzi wazuri wanasoma kwa bidii.'?,
      options: [Wazuri, bidii, Wanafunzi, wazuri, Wanasoma, bidii", "Wazuri, wanasoma].sort(() => Math.random() - 0.5),
      correctAnswer: Wazuri, bidii"
    })
  },

  // --- MADA: MATUMIZI YA LUGHA (Methali, Nahau, Vitendawili) (5 Materials) ---
  {
    id: "G9-SWA-MET-01",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., "Mwenye njaa hajali wali wa mwenzake., Acha mwenye mkuki ampige."].sort(() => Math.random() - 0.5),
      correctAnswer: "Mkono wa mwenzako usiupande.
    })
  },
  {
    id: G9-SWA-MET-02",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., Mwenye njaa hajali wali wa mwenzake.", "Acha mwenye mkuki ampige.].sort(() => Math.random() - 0.5),
      correctAnswer: Haraka haraka haina baraka."
    })
  },
  {
    id: "G9-SWA-MET-03",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Mti, Kalamu", "Ufagio, Kibao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mti
    })
  },
  {
    id: G9-SWA-MET-04",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Kalamu, Mti, Ufagio", "Kibao].sort(() => Math.random() - 0.5),
      correctAnswer: Kalamu"
    })
  },
  {
    id: "G9-SWA-MET-05",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na hasira kali'?,
      options: [Kuwa na joto, Kuwa na baridi, "Kuwa na mvua, Kuwa na theluji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na joto
    })
  },

  // --- MADA: USOMAJI (Kuelewa, Kubainisha) (5 Materials) ---
  {
    id: G9-SWA-USE-01",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kuelewa maandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Kazi ya mwalimu ni kufundisha wanafunzi. Mwalimu lazima awe na uvumilivu na upendo kwa wanafunzi.' Ni sifa gani za mwalimu?,
      options: [Uvumilivu na upendo, Nguvu na ukali, Uwezo wa kuogopa", "Uwezo wa kucheza].sort(() => Math.random() - 0.5),
      correctAnswer: Uvumilivu na upendo"
    })
  },
  {
    id: "G9-SWA-USE-02",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kubainisha maandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 55,",
    generate: () => ({
      text: "Soma: 'Mji wa Mombasa ni mji wa pwani. Umejulikana kwa bandari yake na historia ndefu ya uislamu.' Ni sifa gani za Mombasa?,
      options: [Ni mji wa pwani na umejulikana kwa bandari, Ni mji wa mlima, "Ni mji wa wageni, Ni mji wa wakulima"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ni mji wa pwani na umejulikana kwa bandari
    })
  },
  {
    id: G9-SWA-USE-03",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma kwa makini",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Mwandishi alisema kwamba wanafunzi wanatakiwa kuwa na uwezo wa kutumia lugha ya Kiswahili katika maisha yao ya kila siku.' Ni nini alisema mwandishi?,
      options: [Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku, Kiswahili ni lugha ya kigeni, Kiswahili haijathaminiwa", "Wanafunzi wanatakiwa kutumia Kiingereza tu].sort(() => Math.random() - 0.5),
      correctAnswer: Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku"
    })
  },
  {
    id: "G9-SWA-USE-04",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kuelewa maandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Soma: 'Mama alinunua chakula sokoni. Alinunua ugali, sukuma wiki, na samaki.' Mama alinunua nini sokoni?,
      options: ["Ugali, sukuma wiki, na samaki, Ugali na nyama", "Wali na matunda, Chapati na mboga"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ugali, sukuma wiki, na samaki
    })
  },
  {
    id: G9-SWA-USE-05",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kusoma kwa makini",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Mwandishi wa habari alisema kwamba wanafunzi wanatakiwa kuwa na uwezo wa kutumia lugha ya Kiswahili katika maisha yao ya kila siku.' Ni nini alisema mwandishi?,
      options: [Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku, Kiswahili ni lugha ya kigeni, Kiswahili haijathaminiwa", "Wanafunzi wanatakiwa kutumia Kiingereza tu].sort(() => Math.random() - 0.5),
      correctAnswer: Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku"
    })
  },

  // --- MADA: UANDISHI (Insha, Barua, Taarifa) (5 Materials) ---
  {
    id: "G9-SWA-AND-01",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoandika insha, ni jambo lipi la kwanza kuzingatia?,
      options: [Mada, Hitimisho", "Utangulizi, Tahadhari"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mada
    })
  },
  {
    id: G9-SWA-AND-02",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Barua rasmi",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoandika barua rasmi, ni jambo lipi la kwanza kuandika?,
      options: [Anwani ya mpokeaji, Tarehe, Salamu", "Mada].sort(() => Math.random() - 0.5),
      correctAnswer: Anwani ya mpokeaji"
    })
  },
  {
    id: "G9-SWA-AND-03",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Barua rasmi,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Barua rasmi inaisha na nini?,
      options: [Sahihi, Tarehe, "Anwani, Salamu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sahihi
    })
  },
  {
    id: G9-SWA-AND-04",
    grade: "Grade 9,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Taarifa",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Taarifa inapaswa kuandikwa kwa lugha gani?,
      options: [Lugha rasmi, Lugha ya mitaani, Lugha ya kawaida", "Lugha ya kifasihi].sort(() => Math.random() - 0.5),
      correctAnswer: Lugha rasmi"
    })
  },
  {
    id: "G9-SWA-AND-05",
    grade: "Grade 9",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, "Tahadhari, mada, hitimisho, Mada, ufafanuzi, malengo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utangulizi, mwili, hitimisho
    })
  },

  // =========================================================================
  // DARASA LA 10: 35 MATERIALS (KICD SENIOR SECONDARY - CONTINUED)
  // =========================================================================

  // --- MADA: SARUFI - VIAMBISHI (5 Materials) ---
  {
    id: G10-SWA-VIA-01",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Muda",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Mimi ____enda sokoni.' (Tumia kiambishi cha wakati uliopo kwa nafsi ya kwanza umoja),
      options: [na, li, ta", "me].sort(() => Math.random() - 0.5),
      correctAnswer: na"
    })
  },
  {
    id: "G10-SWA-VIA-02",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Muda,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Sisi ____soma kitabu hiki.' (Tumia kiambishi cha wakati uliopita kwa nafsi ya kwanza wingi),
      options: [li, na, "ta, me"].sort(() => Math.random() - 0.5),
      correctAnswer: "li
    })
  },
  {
    id: G10-SWA-VIA-03",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Muda",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Wao ____tembea mtaani.' (Tumia kiambishi cha wakati ujao kwa nafsi ya tatu wingi),
      options: [ta, na, li", "me].sort(() => Math.random() - 0.5),
      correctAnswer: ta"
    })
  },
  {
    id: "G10-SWA-VIA-04",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Muda,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: 'Yeye ____cheza mpira.' (Tumia kiambishi cha wakati uliopo kwa nafsi ya tatu umoja),
      options: [na, li, "ta, me"].sort(() => Math.random() - 0.5),
      correctAnswer: "na
    })
  },
  {
    id: G10-SWA-VIA-05",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Muda",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Nyinyi ____enda shule.' (Tumia kiambishi cha wakati uliopita kwa nafsi ya pili wingi),
      options: [li, na, ta", "me].sort(() => Math.random() - 0.5),
      correctAnswer: li"
    })
  },

  // --- MADA: SARUFI - VIUNGO (5 Materials) ---
  {
    id: "G10-SWA-VIU-01",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viungo vya Kuunganisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ushirikiano, tutafanikiwa.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G10-SWA-VIU-02",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viungo vya Kuunganisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ kulikuwa na mvua, tulikwenda mtaani.' (Tumia kiungo cha kuonyesha sababu),
      options: [Kwa sababu, Kwa hivyo, Ingawa", "Kwa kuwa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa sababu"
    })
  },
  {
    id: "G10-SWA-VIU-03",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viungo vya Kuunganisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ukweli, mambo ni magumu.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G10-SWA-VIU-04",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viungo vya Kuunganisha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ watoto, shule ni muhimu.' (Tumia kiungo cha kuonyesha lengo),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G10-SWA-VIU-05",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viungo vya Kuunganisha,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ kazi hii, tunahitaji muda mwingi.' (Tumia kiungo cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },

  // --- MADA: SARUFI - VIWAKILISHI (5 Materials) ---
  {
    id: G10-SWA-VIW-01",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Nafsi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ndio mwanafunzi wa darasa hili.' (Tumia kiwakilishi cha nafsi ya pili umoja),
      options: [Wewe, Mimi, Yeye", "Sisi].sort(() => Math.random() - 0.5),
      correctAnswer: Wewe"
    })
  },
  {
    id: "G10-SWA-VIW-02",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Nafsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ndio wapendwa wangu.' (Tumia kiwakilishi cha nafsi ya kwanza wingi),
      options: [Sisi, Mimi, "Wewe, Wao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Sisi
    })
  },
  {
    id: G10-SWA-VIW-03",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Kuonyesha",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ kitabu nilichokisoma jana.' (Tumia kiwakilishi cha kuonyesha cha karibu),
      options: [Hiki, Kile, Hii", "Huo].sort(() => Math.random() - 0.5),
      correctAnswer: Hiki"
    })
  },
  {
    id: "G10-SWA-VIW-04",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viwakilishi vya Kuuliza,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Tumia kiwakilishi sahihi: '____ mtu aliyepiga mlango?',
      options: [Nani, Kipi, "Wapi, Lini"].sort(() => Math.random() - 0.5),
      correctAnswer: "Nani
    })
  },
  {
    id: G10-SWA-VIW-05",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viwakilishi vya Umiliki",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: 'Hii ni ____ fedha.' (Tumia kiwakilishi cha umiliki cha nafsi ya tatu umoja),
      options: [yake, yangu, yako", "yetu].sort(() => Math.random() - 0.5),
      correctAnswer: yake"
    })
  },

  // --- MADA: SARUFI - VIVUMISHI (5 Materials) ---
  {
    id: "G10-SWA-VIV-01",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Sifa,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni vivumishi vipi katika sentensi: 'Mwanafunzi mwerevu alipata alama nzuri.'?,
      options: [Mwerevu, nzuri, Mwanafunzi, alama, "Alipata, mwerevu, Mwerevu, alama"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mwerevu, nzuri
    })
  },
  {
    id: G10-SWA-VIV-02",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Idadi",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia vivumishi vya idadi: '____ wanafunzi walikuja.' (Maana: wachache),
      options: [Wachache, Wengi, Wote", "Kila].sort(() => Math.random() - 0.5),
      correctAnswer: Wachache"
    })
  },
  {
    id: "G10-SWA-VIV-03",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Kuuliza,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ kitabu ni chako?' (Tumia vivumishi vya kuuliza),
      options: [Kipi, Nani, "Wapi, Lini"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kipi
    })
  },
  {
    id: G10-SWA-VIV-04",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Vivumishi vya Umiliki",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Tumia vivumishi vya umiliki: 'Hii ni ____ kazi.' (Maana: kazi yangu),
      options: [yangu, yake, yako", "yetu].sort(() => Math.random() - 0.5),
      correctAnswer: yangu"
    })
  },
  {
    id: "G10-SWA-VIV-05",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Vivumishi vya Jinsi,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Ni vivumishi vipi katika sentensi: 'Wanafunzi wazuri wanasoma kwa bidii.'?,
      options: [Wazuri, bidii, Wanafunzi, wazuri, "Wanasoma, bidii, Wazuri, wanasoma"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wazuri, bidii
    })
  },

  // --- MADA: MATUMIZI YA LUGHA (Methali, Nahau, Vitendawili) (5 Materials) ---
  {
    id: G10-SWA-MET-01",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Methali",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., Mwenye njaa hajali wali wa mwenzake.", "Acha mwenye mkuki ampige.].sort(() => Math.random() - 0.5),
      correctAnswer: Mkono wa mwenzako usiupande."
    })
  },
  {
    id: "G10-SWA-MET-02",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Methali,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Methali ipi inafaa kwa mtu anayesema kwamba hawezi kuwa na shida na mtu anayempa?,
      options: [Mkono wa mwenzako usiupande., Haraka haraka haina baraka., "Mwenye njaa hajali wali wa mwenzake., Acha mwenye mkuki ampige."].sort(() => Math.random() - 0.5),
      correctAnswer: "Haraka haraka haina baraka.
    })
  },
  {
    id: G10-SWA-MET-03",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Vitendawili",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Mti, Kalamu, Ufagio", "Kibao].sort(() => Math.random() - 0.5),
      correctAnswer: Mti"
    })
  },
  {
    id: "G10-SWA-MET-04",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Vitendawili,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Vitendawili: 'Nina mguu mmoja, lakini nina miguu mingi? Nini mimi?',
      options: [Kalamu, Mti", "Ufagio, Kibao"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kalamu
    })
  },
  {
    id: G10-SWA-MET-05",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na hasira kali'?,
      options: [Kuwa na joto, Kuwa na baridi, Kuwa na mvua", "Kuwa na theluji].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na joto"
    })
  },

  // --- MADA: USOMAJI (Kuelewa, Kubainisha) (5 Materials) ---
  {
    id: "G10-SWA-USE-01",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kuelewa maandishi,
    maxUses: 5,
    usageCount: 0,
    minWords: 50,",
    generate: () => ({
      text: "Soma: 'Kazi ya mwalimu ni kufundisha wanafunzi. Mwalimu lazima awe na uvumilivu na upendo kwa wanafunzi.' Ni sifa gani za mwalimu?,
      options: [Uvumilivu na upendo, Nguvu na ukali, "Uwezo wa kuogopa, Uwezo wa kucheza"].sort(() => Math.random() - 0.5),
      correctAnswer: "Uvumilivu na upendo
    })
  },
  {
    id: G10-SWA-USE-02",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kubainisha maandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 55,
    generate: () => ({
      text: " Soma: 'Mji wa Mombasa ni mji wa pwani. Umejulikana kwa bandari yake na historia ndefu ya uislamu.' Ni sifa gani za Mombasa?,
      options: [Ni mji wa pwani na umejulikana kwa bandari, Ni mji wa mlima, Ni mji wa wageni", "Ni mji wa wakulima].sort(() => Math.random() - 0.5),
      correctAnswer: Ni mji wa pwani na umejulikana kwa bandari"
    })
  },
  {
    id: "G10-SWA-USE-03",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma kwa makini,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mwandishi alisema kwamba wanafunzi wanatakiwa kuwa na uwezo wa kutumia lugha ya Kiswahili katika maisha yao ya kila siku.' Ni nini alisema mwandishi?,
      options: [Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku, Kiswahili ni lugha ya kigeni, "Kiswahili haijathaminiwa, Wanafunzi wanatakiwa kutumia Kiingereza tu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku
    })
  },
  {
    id: G10-SWA-USE-04",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Kuelewa maandishi",
    maxUses: 5,
    usageCount: 0,
    minWords: 50,
    generate: () => ({
      text: " Soma: 'Mama alinunua chakula sokoni. Alinunua ugali, sukuma wiki, na samaki.' Mama alinunua nini sokoni?,
      options: [Ugali, sukuma wiki, na samaki, Ugali na nyama, Wali na matunda", "Chapati na mboga].sort(() => Math.random() - 0.5),
      correctAnswer: Ugali, sukuma wiki, na samaki"
    })
  },
  {
    id: "G10-SWA-USE-05",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Kusoma kwa makini,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mwandishi wa habari alisema kwamba wanafunzi wanatakiwa kuwa na uwezo wa kutumia lugha ya Kiswahili katika maisha yao ya kila siku.' Ni nini alisema mwandishi?,
      options: [Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku, Kiswahili ni lugha ya kigeni, "Kiswahili haijathaminiwa, Wanafunzi wanatakiwa kutumia Kiingereza tu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wanafunzi wanatakiwa kutumia Kiswahili katika maisha ya kila siku
    })
  },

  // --- MADA: UANDISHI (Insha, Barua, Taarifa) (5 Materials) ---
  {
    id: G10-SWA-AND-01",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoandika insha, ni jambo lipi la kwanza kuzingatia?,
      options: [Mada, Hitimisho, Utangulizi", "Tahadhari].sort(() => Math.random() - 0.5),
      correctAnswer: Mada"
    })
  },
  {
    id: "G10-SWA-AND-02",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Barua rasmi,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoandika barua rasmi, ni jambo lipi la kwanza kuandika?,
      options: [Anwani ya mpokeaji, Tarehe", "Salamu, Mada"].sort(() => Math.random() - 0.5),
      correctAnswer: "Anwani ya mpokeaji
    })
  },
  {
    id: G10-SWA-AND-03",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Barua rasmi",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Barua rasmi inaisha na nini?,
      options: [Sahihi, Tarehe, Anwani", "Salamu].sort(() => Math.random() - 0.5),
      correctAnswer: Sahihi"
    })
  },
  {
    id: "G10-SWA-AND-04",
    grade: "Grade 10",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Taarifa,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Taarifa inapaswa kuandikwa kwa lugha gani?,
      options: [Lugha rasmi, Lugha ya mitaani, "Lugha ya kawaida, Lugha ya kifasihi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Lugha rasmi
    })
  },
  {
    id: G10-SWA-AND-05",
    grade: "Grade 10,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, Tahadhari, mada, hitimisho", "Mada, ufafanuzi, malengo].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi, mwili, hitimisho"
    })
  }
  // =========================================================================
  // DARASA LA 11: 35 MATERIALS (KICD SENIOR SECONDARY - ADVANCED)
  // =========================================================================

  // --- MADA: SARUFI - VIAMBISHI NA UUNDAJI WA MANENO (5 Materials) ---
  {
    id: "G11-SWA-VIA-01",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Uhusiano,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ kwa ajili ya shughuli hii, twende.' (Tumia kiambishi cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G11-SWA-VIA-02",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Uhusiano",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ ukweli, tunapaswa kuwa waangalifu.' (Tumia kiambishi cha kuonyesha sababu),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G11-SWA-VIA-03",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Uhusiano,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ watoto wetu, tunajitahidi.' (Tumia kiambishi cha kuonyesha lengo),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G11-SWA-VIA-04",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Uundaji wa Maneno",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Undo neno: 'Mtoto anayependa kusoma' unaitwaje kwa Kiswahili?,
      options: [Msomaji, Mwalimu, Mwandishi", "Mwanafunzi].sort(() => Math.random() - 0.5),
      correctAnswer: Msomaji"
    })
  },
  {
    id: "G11-SWA-VIA-05",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Uundaji wa Maneno,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Undo neno: 'Mtu anayefanya kazi ya kutengeneza viatu' unaitwaje?,
      options: [Mshonaji viatu, Mtengenezaji viatu, "Muuzaji viatu, Mfanyabiashara"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mshonaji viatu
    })
  },

  // --- MADA: FASIHI - TATHMINI YA MAANDISHI (5 Materials) ---
  {
    id: G11-SWA-FAS-01",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Fasihi,
    subtopic: "Tathmini ya Mashairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Soma ubeti wa shairi: 'Mlima mrefu kweli, umo katika nchi yetu, Wapandaji hupanda kwa bidii.' Ni kipi kilichojadiliwa katika shairi hili?,
      options: [Mlima mrefu na wapandaji, Nchi yetu, Wapandaji wa mlima", "Mlima na nchi].sort(() => Math.random() - 0.5),
      correctAnswer: Mlima mrefu na wapandaji"
    })
  },
  {
    id: "G11-SWA-FAS-02",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Fasihi",
    subtopic: "Tathmini ya Mashairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Katika shairi, 'Maji ni uzima', tamthilia hii ina maana gani?,
      options: ["Maji ni muhimu kwa uhai, Maji ni ya kupendeza", "Maji ni ya kuogelea, Maji ni ya kusafisha"].sort(() => Math.random() - 0.5),
      correctAnswer: "Maji ni muhimu kwa uhai
    })
  },
  {
    id: G11-SWA-FAS-03",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Fasihi,
    subtopic: "Tathmini ya Mashairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Katika shairi, 'Mti ni nguzo ya msitu', ni nini maana ya tamthilia hii?,
      options: [Mti ni muhimu kwa msitu, Mti ni mrefu, Mti ni mdogo", "Mti ni wa kupanda].sort(() => Math.random() - 0.5),
      correctAnswer: Mti ni muhimu kwa msitu"
    })
  },
  {
    id: "G11-SWA-FAS-04",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Fasihi",
    subtopic: "Tathmini ya Mashairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Katika shairi, 'Wapendwa wote wako mbali', nini maana ya shairi hili?,
      options: ["Wapendwa wako mbali, Wapendwa wako karibu", "Wapendwa wako nyumbani, Wapendwa wako shuleni"].sort(() => Math.random() - 0.5),
      correctAnswer: "Wapendwa wako mbali
    })
  },
  {
    id: G11-SWA-FAS-05",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Fasihi,
    subtopic: "Tathmini ya Mashairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Katika shairi, 'Mvua ni baraka', nini maana ya tamthilia hii?,
      options: [Mvua ni ya kufurahisha, Mvua ni ya kuogopa, Mvua ni ya kusafisha", "Mvua ni ya kupanda].sort(() => Math.random() - 0.5),
      correctAnswer: Mvua ni ya kufurahisha"
    })
  },

  // --- MADA: MATUMIZI YA LUGHA - NAHAU (5 Materials) ---
  {
    id: "G11-SWA-NAH-01",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na shauku kubwa'?,
      options: [Kuwa na joto, Kuwa na baridi, "Kuwa na mvua, Kuwa na theluji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na joto
    })
  },
  {
    id: G11-SWA-NAH-02",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na uzito'?,
      options: [Kuwa na uzito, Kuwa na shauku, Kuwa na huzuni", "Kuwa na furaha].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na uzito"
    })
  },
  {
    id: "G11-SWA-NAH-03",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na upendo mwingi'?,
      options: [Kuwa na joto, Kuwa na baridi, "Kuwa na mvua, Kuwa na theluji"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na joto
    })
  },
  {
    id: G11-SWA-NAH-04",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na woga'?,
      options: [Kuwa na woga, Kuwa na shauku, Kuwa na huzuni", "Kuwa na furaha].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na woga"
    })
  },
  {
    id: "G11-SWA-NAH-05",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na nguvu'?,
      options: [Kuwa na nguvu, Kuwa na shauku, "Kuwa na huzuni, Kuwa na furaha"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na nguvu
    })
  },

  // --- MADA: USOMAJI - UFAHAMU WA KINA (5 Materials) ---
  {
    id: G11-SWA-USE-01",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Ufahamu wa Kina",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Uchumi wa nchi unategemea kilimo na utalii. Kilimo hutoa chakula na kazi. Utalii unaingiza fedha nyingi.' Ni nini kinachotajwa kama misingi ya uchumi?,
      options: [Kilimo na utalii, Kilimo pekee, Utalii pekee", "Kilimo na biashara].sort(() => Math.random() - 0.5),
      correctAnswer: Kilimo na utalii"
    })
  },
  {
    id: "G11-SWA-USE-02",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Ufahamu wa Kina,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Lugha ya Kiswahili ni lugha muhimu katika Afrika ya Mashariki. Inatumika katika biashara, shule, na mawasiliano ya kila siku.' Ni nini kinachotajwa kuhusu Kiswahili?,
      options: ["Ni muhimu katika Afrika ya Mashariki, Ni lugha ya kigeni", "Ni lugha ya mitaani, Ni lugha ya shule tu"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ni muhimu katika Afrika ya Mashariki
    })
  },
  {
    id: G11-SWA-USE-03",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Ufahamu wa Kina",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Ujamaa ni mfumo wa kijamii unaolenga usawa na ushirikiano. Unawezesha watu kuishi kwa amani na kufanya kazi pamoja.' Ni nini kinachotajwa kuhusu Ujamaa?,
      options: [Unaolenga usawa na ushirikiano, Unaolenga ubinafsi, Unaolenga ubaguzi", "Unaolenga ukweli].sort(() => Math.random() - 0.5),
      correctAnswer: Unaolenga usawa na ushirikiano"
    })
  },
  {
    id: "G11-SWA-USE-04",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Ufahamu wa Kina,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Mazingira ni muhimu kwa uhai. Ni muhimu kuyalinda ili yaweze kutoa uhai kwa vizazi vijavyo.' Ni nini kinachotajwa kuhusu mazingira?,
      options: [Ni muhimu kwa uhai na inapaswa kulindwa, Ni muhimu kwa uhai, "Inapaswa kulindwa, Ni muhimu kwa uhai na inapaswa kulindwa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Ni muhimu kwa uhai na inapaswa kulindwa
    })
  },
  {
    id: G11-SWA-USE-05",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Ufahamu wa Kina",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Elimu ni ufunguo wa maisha. Inajenga uwezo wa mtu kufikia malengo. Ni muhimu kwa maendeleo ya jamii.' Ni nini kinachotajwa kuhusu elimu?,
      options: [Ni ufunguo wa maisha, Inajenga uwezo wa mtu, Ni muhimu kwa maendeleo ya jamii", "Yote yaliyotajwa].sort(() => Math.random() - 0.5),
      correctAnswer: Yote yaliyotajwa"
    })
  },

  // --- MADA: UANDISHI - KUBORESHA INSA (5 Materials) ---
  {
    id: "G11-SWA-AND-01",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Kuboresha Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoboresha insha, ni jambo lipi la kwanza kuzingatia?,
      options: [Utangulizi, Hitimisho", "Mada, Tahadhari"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mada
    })
  },
  {
    id: G11-SWA-AND-02",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Kuboresha Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoboresha insha, ni jambo lipi la mwisho kuzingatia?,
      options: [Hitimisho, Utangulizi, Mada", "Tahadhari].sort(() => Math.random() - 0.5),
      correctAnswer: Hitimisho"
    })
  },
  {
    id: "G11-SWA-AND-03",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Kuboresha Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, "Tahadhari, mada, hitimisho, Mada, ufafanuzi, malengo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utangulizi, mwili, hitimisho
    })
  },
  {
    id: G11-SWA-AND-04",
    grade: "Grade 11,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Kuboresha Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoboresha insha, ni jambo lipi la mwisho kuzingatia?,
      options: [Hitimisho, Utangulizi, Mada", "Tahadhari].sort(() => Math.random() - 0.5),
      correctAnswer: Hitimisho"
    })
  },
  {
    id: "G11-SWA-AND-05",
    grade: "Grade 11",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Kuboresha Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, "Tahadhari, mada, hitimisho, Mada, ufafanuzi, malengo"].sort(() => Math.random() - 0.5),
      correctAnswer: "Utangulizi, mwili, hitimisho
    })
  },

  // =========================================================================
  // DARASA LA 12: 35 MATERIALS (KICD SENIOR SECONDARY - COMPLETION)
  // =========================================================================

  // --- MADA: SARUFI - VIAMBISHI NA UUNDAJI WA MANENO (5 Materials) ---
  {
    id: G12-SWA-VIA-01",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Uhusiano",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ upendo, maisha yana furaha.' (Tumia kiambishi cha kuonyesha sababu),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G12-SWA-VIA-02",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Viambishi vya Kuonyesha Uhusiano,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Jaza pengo: '____ ushirikiano, tutafanikiwa.' (Tumia kiambishi cha kuonyesha masharti),
      options: [Kwa, Kwa hivyo", "Kwa sababu, Ingawa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kwa
    })
  },
  {
    id: G12-SWA-VIA-03",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Viambishi vya Kuonyesha Uhusiano",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Jaza pengo: '____ watoto, tunajitahidi.' (Tumia kiambishi cha kuonyesha lengo),
      options: [Kwa, Kwa hivyo, Kwa sababu", "Ingawa].sort(() => Math.random() - 0.5),
      correctAnswer: Kwa"
    })
  },
  {
    id: "G12-SWA-VIA-04",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Sarufi",
    subtopic: "Uundaji wa Maneno,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Undo neno: 'Mtu anayependa kusafiri' unaitwaje kwa Kiswahili?,
      options: [Msafiri, Mwalimu, "Mwandishi, Mwanafunzi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Msafiri
    })
  },
  {
    id: G12-SWA-VIA-05",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Sarufi,
    subtopic: "Uundaji wa Maneno",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Undo neno: 'Mtu anayefanya kazi ya kutengeneza magari' unaitwaje?,
      options: [Mfundi magari, Mtengenezaji magari, Muuzaji magari", "Mfanyabiashara].sort(() => Math.random() - 0.5),
      correctAnswer: Mfundi magari"
    })
  },

  // --- MADA: FASIHI - TATHMINI YA MAANDISHI (5 Materials) ---
  {
    id: "G12-SWA-FAS-01",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Fasihi",
    subtopic: "Tathmini ya Mashairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Soma ubeti wa shairi: 'Mlima mrefu kweli, umo katika nchi yetu, Wapandaji hupanda kwa bidii.' Ni kipi kilichojadiliwa katika shairi hili?,
      options: ["Mlima mrefu na wapandaji, Nchi yetu", "Wapandaji wa mlima, Mlima na nchi"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mlima mrefu na wapandaji
    })
  },
  {
    id: G12-SWA-FAS-02",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Fasihi,
    subtopic: "Tathmini ya Mashairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Katika shairi, 'Maji ni uzima', tamthilia hii ina maana gani?,
      options: [Maji ni muhimu kwa uhai, Maji ni ya kupendeza, Maji ni ya kuogelea", "Maji ni ya kusafisha].sort(() => Math.random() - 0.5),
      correctAnswer: Maji ni muhimu kwa uhai"
    })
  },
  {
    id: "G12-SWA-FAS-03",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Fasihi",
    subtopic: "Tathmini ya Mashairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Katika shairi, 'Mti ni nguzo ya msitu', ni nini maana ya tamthilia hii?,
      options: ["Mti ni muhimu kwa msitu, Mti ni mrefu", "Mti ni mdogo, Mti ni wa kupanda"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mti ni muhimu kwa msitu
    })
  },
  {
    id: G12-SWA-FAS-04",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Fasihi,
    subtopic: "Tathmini ya Mashairi",
    maxUses: 5,
    usageCount: 0,
    minWords: 30,
    generate: () => ({
      text: " Katika shairi, 'Wapendwa wote wako mbali', nini maana ya shairi hili?,
      options: [Wapendwa wako mbali, Wapendwa wako karibu, Wapendwa wako nyumbani", "Wapendwa wako shuleni].sort(() => Math.random() - 0.5),
      correctAnswer: Wapendwa wako mbali"
    })
  },
  {
    id: "G12-SWA-FAS-05",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Fasihi",
    subtopic: "Tathmini ya Mashairi,
    maxUses: 5,
    usageCount: 0,
    minWords: 30,",
    generate: () => ({
      text: "Katika shairi, 'Mvua ni baraka', nini maana ya tamthilia hii?,
      options: ["Mvua ni ya kufurahisha, Mvua ni ya kuogopa", "Mvua ni ya kusafisha, Mvua ni ya kupanda"].sort(() => Math.random() - 0.5),
      correctAnswer: "Mvua ni ya kufurahisha
    })
  },

  // --- MADA: MATUMIZI YA LUGHA - NAHAU (5 Materials) ---
  {
    id: G12-SWA-NAH-01",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na shauku kubwa'?,
      options: [Kuwa na joto, Kuwa na baridi, Kuwa na mvua", "Kuwa na theluji].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na joto"
    })
  },
  {
    id: "G12-SWA-NAH-02",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na uzito'?,
      options: [Kuwa na uzito, Kuwa na shauku, "Kuwa na huzuni, Kuwa na furaha"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na uzito
    })
  },
  {
    id: G12-SWA-NAH-03",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na upendo mwingi'?,
      options: [Kuwa na joto, Kuwa na baridi, Kuwa na mvua", "Kuwa na theluji].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na joto"
    })
  },
  {
    id: "G12-SWA-NAH-04",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Matumizi ya Lugha",
    subtopic: "Nahau,
    maxUses: 5,
    usageCount: 0,
    minWords: 20,",
    generate: () => ({
      text: "Nahau ipi ina maana ya 'kuwa na woga'?,
      options: [Kuwa na woga, Kuwa na shauku, "Kuwa na huzuni, Kuwa na furaha"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kuwa na woga
    })
  },
  {
    id: G12-SWA-NAH-05",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Matumizi ya Lugha,
    subtopic: "Nahau",
    maxUses: 5,
    usageCount: 0,
    minWords: 20,
    generate: () => ({
      text: " Nahau ipi ina maana ya 'kuwa na nguvu'?,
      options: [Kuwa na nguvu, Kuwa na shauku, Kuwa na huzuni", "Kuwa na furaha].sort(() => Math.random() - 0.5),
      correctAnswer: Kuwa na nguvu"
    })
  },

  // --- MADA: USOMAJI - UFAHAMU WA KINA (5 Materials) ---
  {
    id: "G12-SWA-USE-01",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Ufahamu wa Kina,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Uchumi wa nchi unategemea kilimo na utalii. Kilimo hutoa chakula na kazi. Utalii unaingiza fedha nyingi.' Ni nini kinachotajwa kama misingi ya uchumi?,
      options: [Kilimo na utalii, Kilimo pekee, "Utalii pekee, Kilimo na biashara"].sort(() => Math.random() - 0.5),
      correctAnswer: "Kilimo na utalii
    })
  },
  {
    id: G12-SWA-USE-02",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Ufahamu wa Kina",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Lugha ya Kiswahili ni lugha muhimu katika Afrika ya Mashariki. Inatumika katika biashara, shule, na mawasiliano ya kila siku.' Ni nini kinachotajwa kuhusu Kiswahili?,
      options: [Ni muhimu katika Afrika ya Mashariki, Ni lugha ya kigeni, Ni lugha ya mitaani", "Ni lugha ya shule tu].sort(() => Math.random() - 0.5),
      correctAnswer: Ni muhimu katika Afrika ya Mashariki"
    })
  },
  {
    id: "G12-SWA-USE-03",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Ufahamu wa Kina,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Ujamaa ni mfumo wa kijamii unaolenga usawa na ushirikiano. Unawezesha watu kuishi kwa amani na kufanya kazi pamoja.' Ni nini kinachotajwa kuhusu Ujamaa?,
      options: [Unaolenga usawa na ushirikiano, Unaolenga ubinafsi, "Unaolenga ubaguzi, Unaolenga ukweli"].sort(() => Math.random() - 0.5),
      correctAnswer: "Unaolenga usawa na ushirikiano
    })
  },
  {
    id: G12-SWA-USE-04",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Usomaji,
    subtopic: "Ufahamu wa Kina",
    maxUses: 5,
    usageCount: 0,
    minWords: 60,
    generate: () => ({
      text: " Soma: 'Mazingira ni muhimu kwa uhai. Ni muhimu kuyalinda ili yaweze kutoa uhai kwa vizazi vijavyo.' Ni nini kinachotajwa kuhusu mazingira?,
      options: [Ni muhimu kwa uhai na inapaswa kulindwa, Ni muhimu kwa uhai, Inapaswa kulindwa", "Ni muhimu kwa uhai na inapaswa kulindwa].sort(() => Math.random() - 0.5),
      correctAnswer: Ni muhimu kwa uhai na inapaswa kulindwa"
    })
  },
  {
    id: "G12-SWA-USE-05",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Usomaji",
    subtopic: "Ufahamu wa Kina,
    maxUses: 5,
    usageCount: 0,
    minWords: 60,",
    generate: () => ({
      text: "Soma: 'Elimu ni ufunguo wa maisha. Inajenga uwezo wa mtu kufikia malengo. Ni muhimu kwa maendeleo ya jamii.' Ni nini kinachotajwa kuhusu elimu?,
      options: [Ni ufunguo wa maisha, Inajenga uwezo wa mtu, "Ni muhimu kwa maendeleo ya jamii, Yote yaliyotajwa"].sort(() => Math.random() - 0.5),
      correctAnswer: "Yote yaliyotajwa
    })
  },

  // --- MADA: UANDISHI - KUBORESHA INSA (5 Materials) ---
  {
    id: G12-SWA-AND-01",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Kuboresha Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Unapoboresha insha, ni jambo lipi la kwanza kuzingatia?,
      options: [Utangulizi, Hitimisho, Mada", "Tahadhari].sort(() => Math.random() - 0.5),
      correctAnswer: Mada"
    })
  },
  {
    id: "G12-SWA-AND-02",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Kuboresha Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoboresha insha, ni jambo lipi la mwisho kuzingatia?,
      options: [Hitimisho, Utangulizi", "Mada, Tahadhari"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hitimisho
    })
  },
  {
    id: G12-SWA-AND-03",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Kuboresha Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, Tahadhari, mada, hitimisho", "Mada, ufafanuzi, malengo].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi, mwili, hitimisho"
    })
  },
  {
    id: "G12-SWA-AND-04",
    grade: "Grade 12",
    subject: "Kiswahili",
    topic: "Uandishi",
    subtopic: "Kuboresha Insha,
    maxUses: 5,
    usageCount: 0,
    minWords: 25,",
    generate: () => ({
      text: "Unapoboresha insha, ni jambo lipi la mwisho kuzingatia?,
      options: [Hitimisho, Utangulizi", "Mada, Tahadhari"].sort(() => Math.random() - 0.5),
      correctAnswer: "Hitimisho
    })
  },
  {
    id: G12-SWA-AND-05",
    grade: "Grade 12,
    subject: Kiswahili",
    topic: "Uandishi,
    subtopic: "Kuboresha Insha",
    maxUses: 5,
    usageCount: 0,
    minWords: 25,
    generate: () => ({
      text: " Insha nzuri inapaswa kuwa na nini?,
      options: [Utangulizi, mwili, hitimisho, Salamu, anwani, tarehe, Tahadhari, mada, hitimisho", "Mada, ufafanuzi, malengo].sort(() => Math.random() - 0.5),
      correctAnswer: Utangulizi, mwili, hitimisho"
    })
  }
];


